"""Installed Pixhawk handler characterization with in-memory effect boundaries."""

import hashlib
import logging
import math
import struct
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone


MANAGER_ID = 17
FIXTURE_UTC = datetime(2026, 10, 15, 12, 0, 0, 987654, tzinfo=timezone.utc)
MAX_MESSAGES = 16
MAX_LOGS = 16


class FixtureComplete(BaseException):
    pass


class FixtureEffectViolation(BaseException):
    pass


def _require(condition, description):
    if not condition:
        raise AssertionError(description)


def _json_value(value):
    if isinstance(value, float) and not math.isfinite(value):
        return {'nonfinite': 'nan' if math.isnan(value) else ('+inf' if value > 0 else '-inf')}
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {key: _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    return value


def _float32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]


class _RejectWrite:
    def __init__(self):
        self.attempts = 0

    def write(self, data):
        self.attempts += 1
        raise FixtureEffectViolation('MAVLink fixture attempted write')


class _LogCapture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.events = []
        self.overflow = False

    def emit(self, record):
        if record.levelno < logging.WARNING and not record.exc_info:
            return
        if len(self.events) >= MAX_LOGS:
            self.overflow = True
            return
        self.events.append({
            'level': record.levelname,
            'message': record.getMessage()[:240],
            'exception': record.exc_info[0].__name__ if record.exc_info else None,
        })


@contextmanager
def _capture_logs():
    root = logging.getLogger()
    handlers, level, disabled = root.handlers, root.level, root.disabled
    capture = _LogCapture()
    root.handlers = [capture]
    root.setLevel(logging.DEBUG)
    root.disabled = False
    try:
        yield capture
    finally:
        root.handlers = handlers
        root.setLevel(level)
        root.disabled = disabled
        capture.close()


class _RecordingPublisher:
    def __init__(self):
        self.messages = []
        self.faults = []

    def publish(self, topic, message):
        if len(self.messages) >= MAX_MESSAGES:
            self.faults.append('publication-bound')
            raise FixtureEffectViolation('publication bound')
        try:
            payload = message.SerializeToString()
        except Exception as error:
            self.faults.append('serialization-' + type(error).__name__)
            raise
        self.messages.append((topic, payload))


class _FiniteConnection:
    def __init__(self, frames, sink, parser_dialect):
        _require(0 < len(frames) <= MAX_MESSAGES, 'fixture frame bound')
        self.frames = tuple(frames)
        self.parser = parser_dialect.MAVLink(sink)
        self.parser_dialect = parser_dialect
        self.index = 0
        self.received = []

    def recv_msg(self):
        if self.index == len(self.frames):
            raise FixtureComplete()
        frame = self.frames[self.index]
        self.index += 1
        encoder_dialect, payload, label = frame
        record = {
            'index': self.index,
            'label': label,
            'wire_protocol': {0xfe: '1.0', 0xfd: '2.0'}[payload[0]],
            'wire_magic': payload[0],
            'encoder_dialect': encoder_dialect.__name__,
            'decoder_dialect': self.parser_dialect.__name__,
            'decoder_protocol': self.parser_dialect.WIRE_PROTOCOL_VERSION,
            'wire_length': len(payload),
            'wire_sha256': hashlib.sha256(payload).hexdigest(),
            'arrival_monotonic': time.monotonic(),
        }
        self.received.append(record)
        try:
            message = self.parser.parse_char(payload)
        except Exception as error:
            record['parse_error'] = type(error).__name__
            raise
        _require(message is not None, 'complete frame did not decode')
        record.update({
            'message_type': message.get_type(),
            'source_system': message.get_srcSystem(),
            'source_component': message.get_srcComponent(),
            'sequence': message.get_seq(),
            'source_timestamps': {name: getattr(message, name)
                                  for name in ('time_boot_ms', 'time_usec')
                                  if hasattr(message, name)},
            'decoded_fields': {name: getattr(message, name)
                               for name in message.get_fieldnames()},
        })
        return message


def _subscriber_owner(subscriber):
    owner = object.__new__(subscriber._PointingSubscriber)
    owner._closing = threading.Event()
    owner._fault = None
    owner._state = threading.Lock()
    owner._rejected = 0
    owner.pix_id = MANAGER_ID
    owner.pix_status = {}
    owner.started = False
    return owner


def run_cases():
    """Run after the caller has admitted installed origins and effect controls."""
    from dataclasses import asdict
    from pixhawk import pixhawk_manager as manager
    from pixhawk import pixhawk_pb2
    from pixhawk import pixhawk_subscriber as subscriber
    from pixhawk.constants import Topics, time_format_tzone
    from pixhawk.pixhawk_msg import pixhawk_pb2data
    from pymavlink.dialects.v10 import ardupilotmega as v10
    from pymavlink.dialects.v20 import ardupilotmega as v20

    source = {
        'manager': manager.__file__,
        'subscriber': subscriber.__file__,
        'protobuf': pixhawk_pb2.__file__,
        'mavlink_v10': v10.__file__,
        'mavlink_v20': v20.__file__,
    }
    source_fields = tuple(field.name for field in pixhawk_pb2.fused_msg.DESCRIPTOR.fields)
    sink = _RejectWrite()
    active_evidence = {}

    def frame(kind, *, dialect=v20, source_system=42, source_component=1,
              sequence=0, corrupt=False, **changes):
        defaults = {
            'heartbeat': dict(type=2, autopilot=3, base_mode=0, custom_mode=0,
                              system_status=3, mavlink_version=3),
            'attitude': dict(time_boot_ms=12000, roll=.25, pitch=-.5, yaw=.75,
                             rollspeed=0., pitchspeed=0., yawspeed=0.),
            'gps_raw_int': dict(time_usec=12000000, fix_type=4, lat=421234567,
                                lon=-712345678, alt=12345, eph=100, epv=200,
                                vel=300, cog=400, satellites_visible=18),
            'gps2_raw': dict(time_usec=12001000, fix_type=5, lat=331234567,
                             lon=-812345678, alt=54321, eph=110, epv=210,
                             vel=310, cog=410, satellites_visible=19,
                             dgps_numch=3, dgps_age=20),
            'global_position_int': dict(time_boot_ms=12002, lat=431234567,
                                        lon=-722345678, alt=23456,
                                        relative_alt=4567, vx=10, vy=20, vz=30,
                                        hdg=23456),
        }
        values = defaults[kind].copy()
        if dialect is v20 and kind in ('gps_raw_int', 'gps2_raw'):
            values['yaw'] = 12345 if kind == 'gps_raw_int' else 23456
        values.update(changes)
        message = getattr(dialect, 'MAVLink_' + kind + '_message')(**values)
        encoder = dialect.MAVLink(sink, srcSystem=source_system, srcComponent=source_component)
        encoder.seq = sequence
        payload = bytes(message.pack(encoder))
        if corrupt:
            payload = payload[:-1] + bytes([payload[-1] ^ 1])
        return dialect, payload, kind + ('-bad-crc' if corrupt else '')

    def execute(frames, *, expected_exceptions=(), parser_dialect=v20):
        owner = object.__new__(manager.PixhawkManager)
        owner.simulate_hw = False
        owner.pix_id = MANAGER_ID
        owner._datamsg = None
        owner.connection = _FiniteConnection(frames, sink, parser_dialect)
        owner.messenger = _RecordingPublisher()
        calls = []

        class FixtureDatetime:
            @classmethod
            def now(cls, tz):
                _require(tz is timezone.utc, 'manager requested non-UTC fixture time')
                value = FIXTURE_UTC + timedelta(seconds=len(calls))
                calls.append(value)
                return value

        original_datetime = manager.datetime
        evidence = {'wire_inputs': owner.connection.received, 'expected_legacy_logs': [],
                    'publications': [], 'callback_results': [],
                    'parser_dialect': parser_dialect.__name__,
                    'parser_reused_for_all_frames': True,
                    'decoder_scope': 'Explicit fixed parser receiving complete in-memory frames; no mavutil protocol auto-negotiation or fragmented-stream qualification.'}
        active_evidence.update(evidence)
        completed = False
        try:
            manager.datetime = FixtureDatetime
            with _capture_logs() as logs:
                try:
                    owner.run()
                except FixtureComplete:
                    completed = True
                finally:
                    evidence['expected_legacy_logs'].extend(logs.events)
            _require(completed, 'manager did not reach finite fixture boundary')
            _require(not logs.overflow, 'captured log bound exceeded')
            _require(not owner.messenger.faults, 'publisher boundary recorded failure')
            _require(sink.attempts == 0, 'MAVLink write was attempted')
            warnings = [item for item in logs.events if item['exception'] is None]
            _require(warnings == [{'level': 'WARNING', 'message': 'Incomplete Message',
                                   'exception': None}], 'unexpected manager warnings')
            errors = [item for item in logs.events if item['exception'] is not None]
            _require(tuple(item['exception'] for item in errors) == tuple(expected_exceptions),
                     'unexpected manager exception types or count')
            for item in errors:
                _require(item['level'] == 'ERROR', 'unexpected exception log level')
                if item['exception'] == 'AttributeError':
                    _require("has no attribute 'yaw'" in item['message'],
                             'unexpected missing attribute failure')
                elif item['exception'] == 'MAVError':
                    _require('CRC' in item['message'], 'unexpected MAVLink parser failure')
        finally:
            manager.datetime = original_datetime

        publications = []
        for topic, payload in owner.messenger.messages:
            _require(topic == Topics.DATA_MSG + '_' + str(MANAGER_ID), 'wrong publication topic')
            message = pixhawk_pb2.fused_msg()
            message.ParseFromString(payload)
            publications.append(message)
            evidence['publications'].append({
                'topic': topic,
                'payload_length': len(payload),
                'payload_sha256': hashlib.sha256(payload).hexdigest(),
                'fields': {name: getattr(message, name) for name in source_fields},
            })
            client = _subscriber_owner(subscriber)
            client._receive_data(payload, '')
            accepted = MANAGER_ID in client.pix_status
            evidence['callback_results'].append({
                'accepted': accepted,
                'rejected_messages': client._rejected,
                'row': asdict(pixhawk_pb2data(client.pix_status[MANAGER_ID])) if accepted else None,
            })
            _require(not client._state.locked(), 'callback retained state lock')
            _require(client._fault is None, 'callback acquired logging fault')
        evidence['final_unpublished_fields'] = (
            asdict(owner._datamsg) if owner._datamsg is not None else None)
        evidence['fixture_utc_calls'] = calls
        active_evidence.update(evidence)
        return publications, owner._datamsg, evidence

    def single(frames, *, expected_exceptions=(), accepted=True, parser_dialect=v20):
        messages, pending, evidence = execute(frames, expected_exceptions=expected_exceptions,
                                             parser_dialect=parser_dialect)
        _require(len(messages) == 1, 'expected exactly one assembled publication')
        _require(messages[0].pix_id == MANAGER_ID, 'configured manager ID changed')
        _require(evidence['callback_results'][0]['accepted'] is accepted,
                 'unexpected strict callback disposition')
        _require(evidence['callback_results'][0]['rejected_messages'] == (0 if accepted else 1),
                 'unexpected strict callback rejection count')
        return messages[0], pending, evidence

    def expect_fields(message, **values):
        for name, value in values.items():
            _require(getattr(message, name) == _float32(value), 'field mismatch: ' + name)

    def complete_v2():
        message, pending, evidence = single([
            frame('heartbeat'), frame('attitude'), frame('gps_raw_int'),
            frame('gps2_raw'), frame('global_position_int'), frame('attitude', roll=1.),
        ])
        expect_fields(message, roll=.25, pitch=-.5, yaw=.75, gpsStatus=4, gpsVis=18,
                      gpsYaw=12345, gps2Status=5, gps2Vis=19, gps2Yaw=23456,
                      lat=431234567 * 1e-7, lon=-722345678 * 1e-7,
                      alt=23456 * 1e-3, hdg=23456, gps_time=0)
        _require(message.pc_time == FIXTURE_UTC.strftime(time_format_tzone), 'aggregate UTC mismatch')
        _require(pending.roll == 1., 'trailing ATTITUDE did not start next aggregate')
        evidence['semantics'] = 'Previous ATTITUDE aggregate publishes on next ATTITUDE; radians, degrees, metres and centidegrees are preserved as implemented.'
        return evidence

    def position_arrival_order():
        message, _, evidence = single([
            frame('attitude'), frame('global_position_int'), frame('gps_raw_int'),
            frame('gps2_raw'), frame('attitude'),
        ])
        expect_fields(message, lat=421234567 * 1e-7, lon=-712345678 * 1e-7,
                      alt=12345 * 1e-3, hdg=23456)
        evidence['semantics'] = 'Later raw primary GPS replaces global estimated position while global heading remains.'
        return evidence

    def secondary_position_ignored():
        message, _, evidence = single([frame('attitude'), frame('gps2_raw'), frame('attitude')])
        expect_fields(message, lat=0, lon=0, alt=0, hdg=0, gps2Status=5, gps2Vis=19, gps2Yaw=23456)
        evidence['semantics'] = 'Secondary GPS position is discarded; selected secondary status, count and yaw remain.'
        return evidence

    def pre_attitude_discarded():
        message, _, evidence = single([
            frame('gps_raw_int'), frame('gps2_raw'), frame('global_position_int'),
            frame('attitude'), frame('attitude'),
        ])
        expect_fields(message, gpsStatus=0, gpsVis=0, gpsYaw=0, gps2Status=0,
                      gps2Vis=0, gps2Yaw=0, lat=0, lon=0, alt=0, hdg=0)
        evidence['semantics'] = 'GPS and global position received before first ATTITUDE are discarded.'
        return evidence

    def attitude_only_defaults():
        message, _, evidence = single([frame('attitude'), frame('attitude')])
        expect_fields(message, gpsStatus=0, gpsVis=0, gpsYaw=0, gps2Status=0,
                      gps2Vis=0, gps2Yaw=0, gps_time=0, lat=0, lon=0, alt=0, hdg=0)
        evidence['semantics'] = 'Incomplete aggregate numeric defaults publish and pass strict callback; acceptance does not establish component presence.'
        return evidence

    def final_aggregate_unpublished():
        messages, pending, evidence = execute([
            frame('heartbeat'), frame('attitude'), frame('gps_raw_int'),
            frame('gps2_raw'), frame('global_position_int'),
        ])
        _require(messages == [], 'final aggregate published without next ATTITUDE')
        _require(pending.gpsStatus == 4 and pending.gps2Status == 5,
                 'final aggregate did not retain GPS data')
        _require(pending.lat == 431234567 * 1e-7, 'final global position missing')
        evidence['semantics'] = 'Complete final aggregate stays unpublished when no later ATTITUDE arrives.'
        return evidence

    def mixed_sources_heartbeat_ignored():
        message, _, evidence = single([
            frame('heartbeat', source_system=42, source_component=1, sequence=11),
            frame('attitude', source_system=77, source_component=191, sequence=12),
            frame('gps_raw_int', source_system=43, source_component=2, sequence=13),
            frame('gps2_raw', source_system=44, source_component=3, sequence=14),
            frame('global_position_int', source_system=45, source_component=4, sequence=15),
            frame('attitude', source_system=55, source_component=5, sequence=16),
        ])
        expect_fields(message, roll=.25, gpsStatus=4, gps2Status=5, lat=431234567 * 1e-7)
        _require([item['source_system'] for item in evidence['wire_inputs']] == [42, 77, 43, 44, 45, 55],
                 'real decoded source identities changed')
        _require([item['source_component'] for item in evidence['wire_inputs']] == [1, 191, 2, 3, 4, 5],
                 'real decoded component identities changed')
        _require([item['sequence'] for item in evidence['wire_inputs']] == list(range(11, 17)),
                 'real decoded sequence values changed')
        _require(not {'source_system', 'source_component', 'sequence', 'source_session'} & set(source_fields),
                 'unexpected source identity schema fields')
        evidence['semantics'] = 'Mixed decoded systems/components and heartbeat identity do not gate aggregate assembly; configured manager ID 17 remains the output ID.'
        return evidence

    def source_times_ignored():
        message, _, evidence = single([
            frame('attitude', time_boot_ms=60000),
            frame('gps_raw_int', time_usec=1),
            frame('gps2_raw', time_usec=1700000000000000),
            frame('global_position_int', time_boot_ms=1),
            frame('attitude', time_boot_ms=10),
        ])
        expect_fields(message, gps_time=0, lat=431234567 * 1e-7)
        _require(message.pc_time == FIXTURE_UTC.strftime(time_format_tzone), 'source time replaced receipt UTC')
        _require(not {'time_boot_ms', 'time_usec'} & set(source_fields), 'unexpected sensor time fields')
        evidence['semantics'] = 'Old, boot-relative, epoch-like and regressing source times remain fixture evidence only; aggregate UTC is local ATTITUDE receipt time.'
        return evidence

    def no_fix_and_sentinels():
        message, _, evidence = single([
            frame('attitude'),
            frame('gps_raw_int', fix_type=0, satellites_visible=255, yaw=65535),
            frame('gps2_raw', fix_type=1, satellites_visible=255, yaw=0),
            frame('global_position_int', lat=910000000, lon=1810000000, alt=-12345, hdg=65535),
            frame('attitude'),
        ])
        expect_fields(message, gpsStatus=0, gpsVis=255, gpsYaw=65535, gps2Status=1,
                      gps2Vis=255, gps2Yaw=0, lat=91, lon=181, alt=-12.345, hdg=65535)
        evidence['semantics'] = 'No-fix indicators, unknown satellite count, unavailable yaw/heading and impossible geodetic coordinates remain finite and pass strict callback.'
        return evidence

    def north_yaw_preserved():
        message, _, evidence = single([
            frame('attitude'), frame('gps_raw_int', yaw=36000),
            frame('gps2_raw', yaw=36000), frame('global_position_int', hdg=0),
            frame('attitude'),
        ])
        expect_fields(message, gpsYaw=36000, gps2Yaw=36000, hdg=0)
        evidence['semantics'] = 'GPS north sentinel 36000 remains centidegrees without zero normalization; global heading zero remains separate.'
        return evidence

    def nonfinite_attitude_rejected_downstream():
        message, _, evidence = single([
            frame('attitude', roll=float('nan'), pitch=float('inf'), yaw=float('-inf')),
            frame('gps_raw_int'), frame('gps2_raw'), frame('global_position_int'), frame('attitude'),
        ], accepted=False)
        _require(math.isnan(message.roll) and message.pitch == float('inf')
                 and message.yaw == float('-inf'), 'nonfinite ATTITUDE did not reach protobuf')
        evidence['semantics'] = 'Manager publishes nonfinite ATTITUDE unchanged; strict callback rejects that protobuf before updating selected state.'
        return evidence

    def v1_missing_yaw_partial_update():
        message, _, evidence = single([
            frame('attitude', dialect=v10), frame('global_position_int', dialect=v10),
            frame('gps_raw_int', dialect=v10, fix_type=2, satellites_visible=9,
                  lat=510000000, lon=100000000, alt=99999),
            frame('gps2_raw', dialect=v10, fix_type=1, satellites_visible=255),
            frame('attitude', dialect=v10),
        ], expected_exceptions=('AttributeError', 'AttributeError'), parser_dialect=v10)
        expect_fields(message, gpsStatus=2, gpsVis=9, gpsYaw=0,
                      gps2Status=1, gps2Vis=255, gps2Yaw=0,
                      lat=431234567 * 1e-7, lon=-722345678 * 1e-7,
                      alt=23456 * 1e-3, hdg=23456)
        _require(all(item['wire_protocol'] == '1.0' for item in evidence['wire_inputs']),
                 'v1 parser fixture contained a different wire version')
        evidence['semantics'] = 'Fixed v1 decoder yields GPS objects without yaw: fix/count mutate before caught AttributeErrors, yaw defaults remain zero, and prior global coordinates/heading survive the skipped primary position update.'
        return evidence

    def v1_wire_decoded_by_v2_defaults_yaw():
        message, _, evidence = single([
            frame('attitude', dialect=v10), frame('global_position_int', dialect=v10),
            frame('gps_raw_int', dialect=v10, fix_type=2, satellites_visible=9,
                  lat=510000000, lon=100000000, alt=99999),
            frame('gps2_raw', dialect=v10, fix_type=1, satellites_visible=255),
            frame('attitude', dialect=v10),
        ], parser_dialect=v20)
        expect_fields(message, gpsStatus=2, gpsVis=9, gpsYaw=0,
                      gps2Status=1, gps2Vis=255, gps2Yaw=0,
                      lat=51, lon=10, alt=99999 * 1e-3, hdg=23456)
        _require(all(item['wire_protocol'] == '1.0' and item['decoder_protocol'] == '2.0'
                     for item in evidence['wire_inputs']), 'wire and decoder versions were conflated')
        for item in evidence['wire_inputs']:
            if item['message_type'] in ('GPS_RAW_INT', 'GPS2_RAW'):
                _require(item['decoded_fields']['yaw'] == 0, 'v2 decoder did not default missing wire yaw')
        evidence['semantics'] = 'Fixed v2 decoder accepts v1 frames and supplies yaw extension zero; manager reaches primary position update without the fixed-v1 decoder AttributeError. This does not test mavutil parser selection.'
        return evidence

    def protobuf_precision_and_utc():
        message, _, evidence = single([
            frame('attitude', roll=.1, pitch=.2, yaw=-.3), frame('gps_raw_int'),
            frame('gps2_raw'), frame('attitude'),
        ])
        expect_fields(message, roll=.1, pitch=.2, yaw=-.3, lat=421234567 * 1e-7,
                      lon=-712345678 * 1e-7, alt=12345 * 1e-3)
        _require(message.lat != 421234567 * 1e-7, 'fixture did not expose float32 latitude rounding')
        converted = pixhawk_pb2data(message)
        _require(converted.pc_time.tzinfo is timezone.utc and converted.pc_time.microsecond == 0,
                 'protobuf conversion did not yield whole-second UTC')
        evidence['latitude_float32_error_degrees'] = message.lat - 421234567 * 1e-7
        evidence['semantics'] = 'Protobuf float32 rounds converted coordinates; aggregate UTC serialization drops fixture receipt microseconds.'
        return evidence

    def bad_frame_recovery():
        message, _, evidence = single([
            frame('attitude'), frame('gps_raw_int', corrupt=True), frame('gps2_raw'),
            frame('global_position_int'), frame('attitude'),
        ], expected_exceptions=('MAVError',))
        expect_fields(message, gpsStatus=0, gpsVis=0, gpsYaw=0, gps2Status=5,
                      lat=431234567 * 1e-7)
        _require(evidence['wire_inputs'][1].get('parse_error') == 'MAVError',
                 'corrupt real MAVLink frame was not rejected by decoder')
        evidence['semantics'] = 'Bad CRC raises real decoder MAVError; the same complete-frame parser continues, manager catches the error and later publishes remaining components with missing primary defaults. Fragmentation and mavutil auto-negotiation are excluded.'
        return evidence

    def strict_callback_negatives():
        def body(**changes):
            values = dict(pix_id=MANAGER_ID, pc_time=FIXTURE_UTC.strftime(time_format_tzone), roll=.25)
            values.update(changes)
            return pixhawk_pb2.fused_msg(**values).SerializeToString()

        valid = body()
        samples = (
            ('truncated-protobuf', b'\x80', ''),
            ('wrong-manager-id', body(pix_id=MANAGER_ID + 1), ''),
            ('oversized-body', b'x' * 4097, ''),
            ('nonexact-bytes', bytearray(valid), ''),
            ('invalid-time', body(pc_time='invalid UTC'), ''),
            ('non-utc-time', body(pc_time='2026-10-15 12:00:00 GMT'), ''),
            ('oversized-time', body(pc_time='x' * 65 + ' UTC'), ''),
            ('nonfinite-field', body(alt=float('nan')), ''),
            ('wrong-identifier', valid, 'wrong'),
        )
        owner = _subscriber_owner(subscriber)
        evidence = {'negative_callback_results': []}
        active_evidence.update(evidence)
        with _capture_logs() as logs:
            for index, (label, payload, identifier) in enumerate(samples, 1):
                owner._receive_data(payload, identifier)
                _require(owner._rejected == index, 'callback rejection mismatch: ' + label)
                _require(owner.pix_status == {}, 'invalid callback mutated selected state: ' + label)
                _require(not owner._state.locked(), 'invalid callback retained state lock')
                evidence['negative_callback_results'].append({
                    'label': label, 'rejected_messages': owner._rejected, 'selected_state_empty': True,
                })
            owner._receive_data(valid, '')
        _require(not logs.events and not logs.overflow, 'unexpected callback warning or error')
        _require(MANAGER_ID in owner.pix_status and owner._rejected == len(samples),
                 'valid callback did not recover after invalid bodies')
        _require(owner._fault is None, 'callback negatives acquired fault')
        evidence['negative_count'] = len(samples)
        evidence['valid_after_negatives'] = asdict(pixhawk_pb2data(owner.pix_status[MANAGER_ID]))
        evidence['semantics'] = 'Actual strict callback rejects malformed, wrong-ID, oversized, wrong-type, invalid-time, nonfinite and wrong-identifier inputs; valid data remains usable afterward.'
        return evidence

    cases = (
        complete_v2, position_arrival_order, secondary_position_ignored,
        pre_attitude_discarded, attitude_only_defaults, final_aggregate_unpublished,
        mixed_sources_heartbeat_ignored, source_times_ignored, no_fix_and_sentinels,
        north_yaw_preserved, nonfinite_attitude_rejected_downstream,
        v1_missing_yaw_partial_update, v1_wire_decoded_by_v2_defaults_yaw,
        protobuf_precision_and_utc,
        bad_frame_recovery, strict_callback_negatives,
    )
    results = []
    for case in cases:
        active_evidence.clear()
        try:
            observations = case()
            results.append({'name': case.__name__, 'status': 'PASS', 'observations': observations})
        except Exception as error:
            results.append({'name': case.__name__, 'status': 'FAIL',
                            'error_type': type(error).__name__, 'error': str(error)[:240],
                            'observations': dict(active_evidence)})
    passed = sum(item['status'] == 'PASS' for item in results)
    return _json_value({
        'status': 'PASS' if passed == len(cases) and sink.attempts == 0 else 'FAIL',
        'scenario_count': len(cases), 'passed': passed, 'failed': len(cases) - passed,
        'mavlink_write_attempts': sink.attempts,
        'fixture_manager_id': MANAGER_ID,
        'module_origins': source,
        'protobuf_fields': source_fields,
        'scope': 'Offline installed handler, fixed-dialect complete-frame MAVLink decoding, protobuf and strict callback characterization only. No mavutil protocol auto-negotiation, fragmented-stream qualification, manager/subscriber/transport construction, broker, device, manager lifecycle, navigation admission or firmware qualification.',
        'cases': results,
    })
