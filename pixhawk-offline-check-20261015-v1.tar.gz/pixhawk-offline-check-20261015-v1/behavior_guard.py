"""Narrow additions for the installed offline Pixhawk receive-loop fixture."""

import ast
import builtins
import errno
import hashlib
import importlib._bootstrap_external as external
import os
from pathlib import Path
import pwd
import stat
import sys
import types

from pi_guard import CheckGuard, require
from ctypes_initialization import CtypesInitialization, _call_offsets


class ActiveModules:
    def __init__(self):
        self.namespaces = {}
        self.active_modules = self.namespaces

    def exact_binding(self, unused, code):
        row = self.namespaces.get(id(code))
        if row is None or row[0] is not code:
            return None
        unused_code, namespace, module, spec, loader, loading = row
        frame = sys._getframe(1)
        for unused in range(96):
            if frame is None or frame is loading:
                break
            frame = frame.f_back
        if (frame is loading and type(module) is types.ModuleType
                and sys.modules.get(spec.name) is module and vars(module) is namespace
                and namespace.get('__spec__') is spec and spec._initializing is True
                and namespace.get('__loader__') is loader and spec.loader is loader
                and type(loader) is external.SourceFileLoader
                and loader.__dict__ == dict(name=spec.name, path=spec.origin)
                and loading.f_locals.get('self') is loader
                and loading.f_locals.get('module') is module
                and loading.f_locals.get('code') is code):
            return namespace
        return None


class BehaviorGuard(CheckGuard):
    MODE = 'offline-pixhawk'

    def __init__(self, files, directories, native, stdlib, package_site, profile='host'):
        super().__init__(files, directories, native)
        self.stdlib, self.site = Path(stdlib), Path(package_site)
        profiles = {
            'host': 'a31058a86719567745b80200dcc40218663e7516026a79ac0911d97c67574f71',
            'pi': '608671c6b49e5e027e3348fcf492718c33f69f919d99f4ff170522c40bd4c550',
        }
        require(profile in profiles, 'unsupported ctypes source profile')
        self.ctypes_sha = profiles[profile]
        self.METADATA = ActiveModules()
        self.ctypes_init = CtypesInitialization(self)
        self.selected = {
            str(self.stdlib / 'ctypes/__init__.py'): self.ctypes_sha,
            str(self.site / 'numpy/_core/_internal.py'): '07cb7a9b1bda0e8bb113e08e474d74bf8fcf507373385f261e015ab513e52569',
            str(self.site / 'pymavlink/mavutil.py'): 'da6f010fed963a63d4b819e734a938c0db84293ccf12e6a427882bfd19b8593b',
            str(self.site / 'pymavlink/mavexpression.py'): 'f48702b4f326a83939a03badfe93187331d03b486eabb253ceda5245aab89429',
        }
        self.sources, self.expected = {}, {}
        for path, expected in self.selected.items():
            payload = Path(path).read_bytes()
            require(hashlib.sha256(payload).hexdigest() == expected,
                    'unreviewed import source: ' + path)
            self.sources[path] = payload
            self.expected[path] = compile(payload, path, 'exec', dont_inherit=True)
        self.loader_exec = external._LoaderBasics.exec_module
        self.loader_exec_code = self.loader_exec.__code__
        self.loader_type = external.SourceFileLoader
        self.path_module, self.open_function = os.path, builtins.open
        self.expanduser = os.path.expanduser
        self.expanduser_code = self.expanduser.__code__
        self.expanduser_namespace = self.expanduser.__globals__
        self.home = Path(pwd.getpwuid(os.getuid()).pw_dir)
        require('HOME' not in os.environ, 'fixed environment must not supply HOME')
        self.home_chain = self.directory_identity(str(self.home))
        require(self.home_chain is not None, 'ordinary passwd HOME ancestors required')
        self.home_targets = tuple(str(self.home / '.pymavlink' / name)
                                  for name in ('mavextra.py', 'custom_mode_map.json'))
        self.absence_chain = self.directory_identity(str(self.home / '.pymavlink'), missing=True)
        require(self.absence_chain is not None, 'ordinary optional-hook parent required')
        self.verify_home_absence()
        self.home_receipts = []
        self.classifier_negatives = []
        path = str(self.site / 'pymavlink/mavutil.py')
        nodes = [node for node in ast.walk(ast.parse(self.sources[path]))
                 if isinstance(node, ast.Call) and ast.unparse(node) == 'open(_custom_mode_map_path)']
        require(len(nodes) == 1, 'exact optional-map call required')
        self.home_node = nodes[0]
        self.home_offsets = None

    def verify_home_absence(self):
        require(self.directory_identity(str(self.home)) == self.home_chain
                and self.directory_identity(str(self.home / '.pymavlink'), missing=True) == self.absence_chain,
                'optional-hook ancestor changed')
        for path in (str(self.home / '.pymavlink'), *self.home_targets):
            try:
                self.real_lstat(path)
            except FileNotFoundError as error:
                require(error.errno == errno.ENOENT and error.filename == path,
                        'genuine optional-hook absence required')
            else:
                raise RuntimeError('optional pymavlink hook exists; separate review required')

    def bind_exec(self, code, caller):
        path = code.co_filename
        if path not in self.selected:
            return
        frame = caller
        for unused in range(4):
            if frame is None or frame.f_code is self.loader_exec_code:
                break
            frame = frame.f_back
        require(frame is not None and frame.f_code is self.loader_exec_code
                and external._LoaderBasics.exec_module is self.loader_exec
                and self.loader_exec.__code__ is self.loader_exec_code
                and frame.f_globals is self.loader_exec.__globals__, 'real source loader required')
        module, loader = frame.f_locals.get('module'), frame.f_locals.get('self')
        require(type(module) is types.ModuleType and type(loader) is self.loader_type,
                'exact source module and loader required')
        ns = vars(module)
        spec = ns.get('__spec__')
        require(spec is not None and spec._initializing is True and spec.loader is loader
                and spec.origin == path and ns.get('__file__') == path
                and sys.modules.get(spec.name) is module and frame.f_locals.get('code') is code
                and code == self.expected[path], 'loaded import code/source mismatch')
        require(not any(row[0].co_filename == path for row in self.METADATA.namespaces.values()),
                'guarded initialization replay')
        self.METADATA.namespaces[id(code)] = (code, ns, module, spec, loader, frame)
        self.ctypes_init.bind_code(path, self.sources[path], code)
        if path.endswith('/pymavlink/mavutil.py'):
            self.home_offsets = _call_offsets(code, self.home_node)

    def home_eligible(self, path, mode, flags, frame):
        if (path != self.home_targets[1] or mode != 'r' or flags != os.O_CLOEXEC
                or self.home_receipts or frame is None or self.home_offsets is None):
            return False
        ns = self.METADATA.exact_binding(self.METADATA.active_modules, frame.f_code)
        row = self.METADATA.namespaces.get(id(frame.f_code))
        parent = frame.f_back
        return (ns is not None and frame.f_globals is ns
                and row is not None and parent is not None and parent.f_back is row[5]
                and parent.f_code is external._bootstrap._call_with_frames_removed.__code__
                and ns.get('__file__') == str(self.site / 'pymavlink/mavutil.py')
                and frame.f_lasti in self.home_offsets
                and ns.get('_custom_mode_map_path') == path
                and os.path is self.path_module and os.path.expanduser is self.expanduser
                and self.expanduser.__code__ is self.expanduser_code
                and self.expanduser.__globals__ is self.expanduser_namespace
                and builtins.open is self.open_function and ns.get('expanduser') is self.expanduser
                and ns.get('os') is os and 'open' not in ns
                and ns.get('__builtins__') is vars(builtins) and 'HOME' not in os.environ)

    def home_negatives(self, args, caller):
        def altered(**changes):
            values = {key: getattr(caller, key) for key in ('f_code', 'f_globals', 'f_lasti', 'f_back')}
            return types.SimpleNamespace(**dict(values, **changes))
        eligible = lambda frame=caller: self.home_eligible(args[0], args[1], args[2], frame)
        for label, frame in (
            ('code-copy', altered(f_code=caller.f_code.replace())),
            ('namespace-copy', altered(f_globals=dict(caller.f_globals))),
            ('callsite', altered(f_lasti=-1)), ('loader-lifetime', altered(f_back=None))):
            require(not eligible(frame) and eligible(), 'HOME negative failed')
            self.classifier_negatives.append(label)
        namespace = caller.f_globals
        spec = namespace['__spec__']
        for label, key in (('spec', '__spec__'), ('loader', '__loader__')):
            saved = namespace[key]
            try:
                namespace[key] = None
                rejected = not eligible()
            finally:
                namespace[key] = saved
            require(rejected and eligible(), 'HOME identity negative failed')
            self.classifier_negatives.append(label)
        saved = spec._initializing
        try:
            spec._initializing = False
            rejected = not eligible()
        finally:
            spec._initializing = saved
        require(rejected and eligible(), 'HOME initializer negative failed')
        self.classifier_negatives.append('inactive-spec')
        self.home_receipts.append({'classifier': True})
        try:
            require(not eligible(), 'HOME replay negative failed')
        finally:
            self.home_receipts.pop()
        self.classifier_negatives.append('replay')
        saved = self.home_chain
        try:
            self.home_chain = ()
            try:
                self.verify_home_absence()
            except RuntimeError:
                self.classifier_negatives.append('changed-parent')
            else:
                raise AssertionError('changed parent admitted')
        finally:
            self.home_chain = saved
        for label, outcome in (
            ('regular', types.SimpleNamespace(st_mode=stat.S_IFREG | 0o644)),
            ('symlink', types.SimpleNamespace(st_mode=stat.S_IFLNK | 0o777)),
            ('permission', PermissionError(errno.EACCES, 'fixture', args[0])),
            ('nondirectory', NotADirectoryError(errno.ENOTDIR, 'fixture', args[0])),
            ('different-target', FileNotFoundError(errno.ENOENT, 'fixture', args[0] + '.other'))):
            require(not self.genuine_absence(outcome, args[0]), 'absence outcome negative failed')
            self.classifier_negatives.append(label)

    @staticmethod
    def genuine_absence(error, path):
        return type(error) is FileNotFoundError and error.errno == errno.ENOENT and error.filename == path

    def audit(self, event, args):
        caller = sys._getframe(1) if event in ('exec', 'ctypes.dlopen', 'open') else None
        if event == 'exec':
            self.bind_exec(args[0], caller)
        if event == 'ctypes.dlopen' and self.ctypes_init.permit(event, args, caller):
            return
        if event == 'open' and self.home_eligible(args[0], args[1], args[2], caller):
            self.home_negatives(args, caller)
            changed = types.SimpleNamespace(f_code=caller.f_code.replace(), f_globals=caller.f_globals,
                f_lasti=caller.f_lasti, f_back=caller.f_back)
            for name, path, mode, flags, frame in (
                ('wrong-path', args[0] + '.other', args[1], args[2], caller),
                ('write', args[0], 'w', os.O_WRONLY, caller),
                ('cloned-code', args[0], args[1], args[2], changed),
                ('outside-initialization', args[0], args[1], args[2], None)):
                require(not self.home_eligible(path, mode, flags, frame), 'HOME classifier escaped')
                self.classifier_negatives.append(name)
            self.verify_home_absence()
            try:
                self.real_lstat(args[0])
            except FileNotFoundError as error:
                require(self.genuine_absence(error, args[0]), 'exact absence required')
                self.home_receipts.append(dict(path=args[0], source=caller.f_code.co_filename,
                    source_sha256=self.selected[caller.f_code.co_filename],
                    byte_access=False, actual_errno=error.errno))
                raise
            self.deny('optional-home-hook-appeared')
        return super().audit(event, args)

    def absent_import_cache(self, path, frame):
        if (frame is not None and frame.f_code is BehaviorGuard.audit.__code__
                and frame.f_globals is globals() and frame.f_locals.get('self') is self):
            frame = frame.f_back
        return super().absent_import_cache(path, frame)

    def finish_behavior(self):
        self.finish()
        self.verify_home_absence()
        require(len(self.home_receipts) == 1 and len(self.ctypes_init.observations) == 1,
                'required import observations absent')
        require('pymavlink.mavuser' not in sys.modules, 'unadmitted pymavlink extension')
        module = sys.modules['pymavlink.mavutil']
        require(module.AP_MAV_TYPE_MODE_MAP is module.AP_MAV_TYPE_MODE_MAP_DEFAULT
                and '_json_mode_map' not in vars(module) and '_custom_mode_map' not in vars(module),
                'custom mode map adopted')
        require(all(self.METADATA.exact_binding(self.METADATA.active_modules, row[0]) is None
                    for row in self.METADATA.namespaces.values()), 'live module initializer')
        return dict(home_absence=self.home_receipts, home_classifier_negatives=self.classifier_negatives,
                    ctypes_initialization=self.ctypes_init.observations,
                    ctypes_negatives=self.ctypes_init.negative_controls)
