"""Fixed Pi binding and protected offline Pixhawk handler execution."""

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

HERE = Path(os.path.abspath(__file__)).parent
APP = Path('/home/admin/satgs-pi-test/satgs-app-manager')
BASE_SHA = 'dd905f46e6b5a1b5a0e5a7f7aadc28272fc0910e465fe6dd4f57c4391edae80b'
INPUTS = frozenset(('pi_target.py', 'pi_guard.py', 'behavior_target.py', 'behavior_guard.py',
    'ctypes_initialization.py', 'pixhawk_cases.py', 'recording.py', 'expected-target.json',
    'run_pixhawk_checks.py', 'run_pixhawk_checks.sh', 'README.md', 'export-provenance.json',
    'reference/NOTICES.md', 'reference/tools/check_installed.py',
    'reference/requirements/development-constraints.txt', 'reference/config/station.example.json'))
CASE_NAMES = (
    'complete_v2', 'position_arrival_order', 'secondary_position_ignored',
    'pre_attitude_discarded', 'attitude_only_defaults', 'final_aggregate_unpublished',
    'mixed_sources_heartbeat_ignored', 'source_times_ignored', 'no_fix_and_sentinels',
    'north_yaw_preserved', 'nonfinite_attitude_rejected_downstream',
    'v1_missing_yaw_partial_update', 'v1_wire_decoded_by_v2_defaults_yaw',
    'protobuf_precision_and_utc', 'bad_frame_recovery', 'strict_callback_negatives')
TRANSPORT = 'NOT RUN: offline in-memory frames, no device or broker'


def load(path, name, expected):
    import types
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise RuntimeError('support module identity changed')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec', dont_inherit=True), vars(module))
    return module


target = load(HERE / 'pi_target.py', 'pi_target', BASE_SHA)
require = target.require


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def support_inputs():
    rows = {}
    for line in target.read(HERE / 'SHA256SUMS').decode('ascii').splitlines():
        digest, name = line.split('  ')
        require(name in INPUTS and name not in rows and len(digest) == 64
                and all(c in '0123456789abcdef' for c in digest), 'invalid support inventory')
        row = target.identity(HERE / name)
        require(row['sha256'] == digest, 'support inventory mismatch: ' + name)
        rows[name] = row
    require(set(rows) == INPUTS, 'incomplete support inventory')
    actual = set()
    for path in HERE.rglob('*'):
        target.ordinary(path)
        if path.is_file():
            actual.add(str(path.relative_to(HERE)))
        else:
            require(path.is_dir(), 'nonregular support member')
    require(actual == INPUTS | {'SHA256SUMS'}, 'unexpected support file')
    return rows


def profile():
    value = target.parse_json(target.read(HERE / 'expected-target.json'))
    require(value['schema'] == 'pixhawk-offline-target.v1'
            and value['application'] == str(APP)
            and value['application_commit'] == target.SOURCE_COMMIT, 'wrong target profile')
    return value


def validate_binding(binding):
    target.validate_binding(binding)
    expected = profile()
    require(binding['environment']['root'] == str(APP), 'wrong application environment')
    require(canonical(binding['environment']) == expected['environment_sha256']
            and len(binding['environment']['files']) == expected['environment_files'],
            'application differs from the accepted Pi installation; do not reinstall to bypass')
    require(canonical(binding['facts']['stdlib']) == expected['stdlib_sha256']
            and len(binding['facts']['stdlib']['files']) == expected['stdlib_files'],
            'target stdlib differs from the accepted Pi binding')
    require(binding['behavior']['support'] == support_inputs()
            and binding['behavior']['profile'] == expected, 'behavior support changed')
    for path, digest in expected['native_extensions'].items():
        require(binding['environment']['files'][path]['sha256'] == digest, 'native extension drift')


def prepare_binding(attempt):
    require(dict(os.environ) == target.ENV, 'fixed clean environment required')
    pins = support_inputs()
    root = APP.parent
    log, exit_file = root / 'install-manager-attempt-1/output.log', root / 'install-manager-attempt-1/exit.txt'
    args = SimpleNamespace(application=APP, source=HERE / 'reference', install_log=log,
        install_log_sha=target.sha(log), install_exit=exit_file, install_exit_sha=target.sha(exit_file))
    binding = target.bind_existing(args)
    binding['facts']['native_status'] = (
        'base CPython/stdlib binding; behavior profile separately admits four installed extensions '
        'and trusts their native loader dependencies, not arbitrary FFI')
    binding['behavior'] = dict(support=pins, profile=profile(),
        scope='offline installed handling; four explicitly bound installed extensions',
        protection='Python API/audit with trusted bound CPython/stdlib and selected native libraries; not syscall isolation')
    validate_binding(binding)
    path = Path(attempt) / 'binding.json'
    target.write(path, binding)
    return dict(binding=path, binding_sha=target.sha(path))


def policy_inputs(binding):
    files, directories, native = set(), set(), set()
    for tree in (binding['facts']['stdlib'], binding['environment']):
        root = Path(tree['root'])
        files.update(str(root / name) for name in tree['files'])
        directories.update(str(root / name) for name in tree['directories'])
    stdlib_tree = binding['facts']['stdlib']
    stdlib = Path(stdlib_tree['root'])
    files.update(row['resolved'] for row in stdlib_tree['links'].values())
    native.update(str(stdlib / name) for name in stdlib_tree['files']
                  if name.startswith('lib-dynload/') and name.endswith('.so'))
    native.update(row['resolved'] for name, row in stdlib_tree['links'].items()
                  if name.startswith('lib-dynload/') and name.endswith('.so'))
    files.update(row['path'] for row in binding['behavior']['support'].values())
    files.add(str(HERE / 'SHA256SUMS'))
    directories.update(str((HERE / name).parent) for name in INPUTS)
    files.add(str(Path(sys.base_prefix) / 'pyvenv.cfg'))
    selected = {str(APP / name): digest for name, digest in profile()['native_extensions'].items()}
    native.update(selected)
    return files, directories, native, selected


def cache_binding(binding):
    result = dict(binding)
    result['source_inputs'] = dict(binding['source_inputs'], **binding['behavior']['support'])
    return result


def versions(package_site):
    distributions = list(importlib.metadata.distributions(path=[str(package_site)]))
    installed = {item.metadata['Name'].lower(): item for item in distributions}
    require(len(installed) == len(distributions) == 31, 'installed distribution set mismatch')
    require(all(Path(item.locate_file('')).resolve() == package_site for item in distributions),
            'distribution origin mismatch')
    wanted = dict(pymavlink='2.4.49', numpy='2.2.6', PyYAML='6.0.3', fastcrc='0.3.4',
                  pyserial='3.5', protobuf='6.33.6')
    actual = {name: installed[name.lower()].version for name in wanted}
    require(actual == wanted, 'selected dependency versions changed')
    return actual


def validate_child(value, binding, mode):
    expected = profile()
    selected = {str(APP / name): digest for name, digest in expected['native_extensions'].items()}
    require(value['selected_native'] == selected, 'child native admission mismatch')
    site = APP / 'lib/python3.11/site-packages'
    required = {name: name.replace('.', '/') + '.py' for name in (
        'pixhawk.pixhawk_manager', 'pixhawk.pixhawk_subscriber', 'pixhawk.pixhawk_pb2',
        'pixhawk.pixhawk_msg', 'pymavlink.mavutil', 'pymavlink.mavexpression',
        'pymavlink.dialects.v10.ardupilotmega', 'pymavlink.dialects.v20.ardupilotmega')}
    required.update({name: name + '/__init__.py' for name in ('numpy', 'fastcrc', 'yaml', 'serial')})
    origins = value['origins']
    require(set(required) <= set(origins), 'required installed origins missing')
    require(all(origins[name]['path'] == str(site / path) for name, path in required.items()),
            'module-to-source binding mismatch')
    for name, row in origins.items():
        path = Path(row['path'])
        require(path.is_absolute() and str(path) == row['path'] and '..' not in path.parts
                and site in path.parents, 'installed origin escaped application: ' + name)
        relative = str(path.relative_to(APP))
        require(row['sha256'] == binding['environment']['files'][relative]['sha256'],
                'installed origin hash mismatch: ' + name)
    require({row['path'] for row in origins.values() if row['path'].endswith('.so')} == set(selected),
            'child native import membership mismatch')
    require(value['application_imports'] is True and value['native_application_loading'] is True
            and value['target_execution'] is True and value['operational_constructors_called'] is False
            and value['navigation'] == 'NOT QUALIFIED' and value['physical_state'] == 'NOT OBSERVED'
            and value['transport'] == TRANSPORT and value['time_synchronization'] == 'UNCONFIRMED',
            'child scope mismatch')
    startup = value['site']
    require(startup['prefix'] == str(APP) and startup['user_site'] is False
            and startup['path'] == binding['facts']['pre_site_path'] + [str(site)]
            and startup['before']['user_site'] is None
            and startup['before']['path'] == binding['facts']['pre_site_path'],
            'genuine guarded site result mismatch')
    require(value['versions'] == dict(pymavlink='2.4.49', numpy='2.2.6', PyYAML='6.0.3',
                fastcrc='0.3.4', pyserial='3.5', protobuf='6.33.6'), 'child versions mismatch')
    receipts = value['control_receipts']
    ctypes_hash = '608671c6b49e5e027e3348fcf492718c33f69f919d99f4ff170522c40bd4c550'
    numpy_hash = '07cb7a9b1bda0e8bb113e08e474d74bf8fcf507373385f261e015ab513e52569'
    observations = receipts['ctypes_initialization']
    require(len(observations) == 1, 'ctypes initialization count mismatch')
    observed = observations[0]
    require(observed['event'] == 'ctypes.dlopen' and observed['argument'] is None
            and type(observed['count']) is int and observed['count'] == 1
            and observed['ctypes_source_sha256'] == ctypes_hash
            and observed['numpy_source_sha256'] == numpy_hash
            and observed['scope'] == 'current-process-handle-initialization-only',
            'ctypes initialization receipt mismatch')
    helper = load(HERE / 'ctypes_initialization.py', 'receipt_selector',
                  binding['behavior']['support']['ctypes_initialization.py']['sha256'])
    selector = helper.CtypesInitialization(SimpleNamespace(
        stdlib=Path(binding['facts']['stdlib']['root']), site=site, ctypes_sha=ctypes_hash))
    for path, digest in ((helper.CTYPES, ctypes_hash), (helper.NUMPY_INTERNAL, numpy_hash)):
        raw = target.read(path)
        require(hashlib.sha256(raw).hexdigest() == digest, 'receipt source changed')
        selector.bind_code(path, raw, compile(raw, path, 'exec', dont_inherit=True))
    for field, offsets in (('initializer_offset', selector.initializer_sites),
                           ('module_offset', selector.module_sites),
                           ('numpy_import_offset', selector.numpy_sites)):
        require(type(observed[field]) is int and observed[field] in offsets,
                'ctypes receipt callsite mismatch')
    negatives = receipts['ctypes_negatives']
    require([row['name'] for row in negatives] == [
        'equal-code-not-identity', 'wrong-namespace', 'wrong-call-offset',
        'wrong-library-argument', 'module-code-not-identity', 'initialization-replay']
        and all(row['denied_by_classifier'] is True and row['native_execution'] is False
                for row in negatives), 'ctypes negative controls mismatch')
    import pwd
    optional_path = str(Path(pwd.getpwuid(os.getuid()).pw_dir) / '.pymavlink/custom_mode_map.json')
    require(len(receipts['home_absence']) == 1
            and receipts['home_absence'][0]['byte_access'] is False
            and type(receipts['home_absence'][0]['actual_errno']) is int,
            'HOME absence receipt types mismatch')
    require(receipts['home_absence'] == [dict(path=optional_path,
        source=str(site / 'pymavlink/mavutil.py'),
        source_sha256='da6f010fed963a63d4b819e734a938c0db84293ccf12e6a427882bfd19b8593b',
        byte_access=False, actual_errno=2)], 'HOME absence receipt mismatch')
    require(receipts['home_classifier_negatives'] == [
        'code-copy', 'namespace-copy', 'callsite', 'loader-lifetime', 'spec', 'loader',
        'inactive-spec', 'replay', 'changed-parent', 'regular', 'symlink', 'permission',
        'nondirectory', 'different-target', 'wrong-path', 'write', 'cloned-code',
        'outside-initialization'], 'HOME negative controls mismatch')
    target.validate_cache_receipts(value['cache_absence'], cache_binding(binding))
    if mode == 'offline':
        behavior = value['behavior']
        require(all(type(behavior[name]) is int for name in
                    ('scenario_count', 'passed', 'failed', 'mavlink_write_attempts'))
                and behavior['status'] == 'PASS' and behavior['scenario_count'] == 16
                and behavior['passed'] == 16 and behavior['failed'] == 0
                and behavior['mavlink_write_attempts'] == 0
                and tuple(row['name'] for row in behavior['cases']) == CASE_NAMES
                and all(row['status'] == 'PASS' for row in behavior['cases']),
                'handler characterization failed')
    else:
        require('behavior' not in value, 'admission ran handler scenarios')


def child(args):
    binding = target.load_json(args.binding, args.binding_sha)
    validate_binding(binding)
    require(Path(sys.executable) == APP / 'bin/python' and dict(os.environ) == target.ENV,
            'wrong interpreter or environment')
    if args.mode == 'offline':
        admission = target.load_json(args.admission, args.admission_sha)
        require(admission['status'] == 'pass' and admission['mode'] == 'admit'
                and admission['binding_sha256'] == args.binding_sha, 'matching admission required')
    pins = binding['behavior']['support']
    files, directories, native, selected = policy_inputs(binding)
    package_site = target.startup_policy(APP)
    target.reject_application_imports(APP)
    load(HERE / 'pi_guard.py', 'pi_guard', pins['pi_guard.py']['sha256'])
    load(HERE / 'ctypes_initialization.py', 'ctypes_initialization', pins['ctypes_initialization.py']['sha256'])
    extension = load(HERE / 'behavior_guard.py', 'behavior_guard', pins['behavior_guard.py']['sha256'])
    guard = extension.BehaviorGuard(files, directories, native,
        Path(binding['facts']['stdlib']['root']), package_site, profile='pi')
    guard.activate()
    count = guard.probes()
    require(count == 41, 'base protection probes changed')
    startup = target.initialize_site(APP, binding['facts']['pre_site_path'], [package_site],
                                     binding['facts']['stdlib'])
    target.check_origins(files, native)
    target.reject_application_imports(APP)
    from pixhawk import pixhawk_manager, pixhawk_subscriber, pixhawk_pb2
    from pymavlink.dialects.v10 import ardupilotmega as v10
    from pymavlink.dialects.v20 import ardupilotmega as v20
    selected_versions = versions(package_site)
    result = dict(status='pass', mode=args.mode, binding_sha256=args.binding_sha,
        application_imports=True, native_application_loading=True, selected_native=selected,
        site=startup, versions=selected_versions, target_execution=True,
        navigation='NOT QUALIFIED', physical_state='NOT OBSERVED',
        transport=TRANSPORT,
        time_synchronization='UNCONFIRMED', operational_constructors_called=False)
    if args.mode == 'offline':
        cases = load(HERE / 'pixhawk_cases.py', 'pixhawk_cases', pins['pixhawk_cases.py']['sha256'])
        result['behavior'] = cases.run_cases()
        if result['behavior']['status'] != 'PASS':
            result['status'] = 'failed'
    guard.phase = 'negative'
    import ctypes
    for kind, action in (
        ('live-api', lambda: ctypes.CDLL(None)),
        ('audit-dispatch', lambda: sys.audit('ctypes.dlsym', 0, 'unadmitted_symbol')),
        ('live-api', lambda: open(str(guard.home / '.pymavlink/custom_mode_map.json'))),
    ):
        guard.probe_kind = kind
        before = len(guard.denials)
        try:
            action()
        except PermissionError:
            require(len(guard.denials) == before + 1, 'missing negative denial')
            count += 1
        else:
            raise RuntimeError('post-initialization escape admitted')
    guard.phase = 'runtime'
    result['control_receipts'] = guard.finish_behavior()
    target.check_origins(files, native)
    result['negative_controls'] = count
    result['cache_absence'] = guard.cache_receipts()
    target.validate_cache_receipts(result['cache_absence'], cache_binding(binding))
    result['origins'] = {}
    for name, module in tuple(sys.modules.items()):
        path = getattr(module, '__file__', None)
        if path and str(package_site) + '/' in path:
            resolved = str(Path(path).resolve())
            result['origins'][name] = dict(path=resolved, sha256=target.sha(resolved))
    require({row['path'] for row in result['origins'].values() if row['path'].endswith('.so')}
            == set(selected), 'native extension import set differs')
    guard.finish()
    print(json.dumps({'child_result': result}, sort_keys=True, allow_nan=False), flush=True)
    return 0 if result['status'] == 'pass' else 1


def run_phase(mode, binding, binding_sha, records, admission=None, admission_sha=None):
    require(mode in ('admit', 'offline'), 'unsupported mode')
    bound = target.load_json(binding, binding_sha)
    validate_binding(bound)
    argv = [str(APP / 'bin/python'), '-I', '-B', '-S', str(HERE / 'behavior_target.py'),
            '_child', '--mode', mode, '--binding', str(binding), '--binding-sha', binding_sha]
    if mode == 'offline':
        prior = target.load_json(admission, admission_sha)
        require(prior['status'] == 'pass' and prior['mode'] == 'admit'
                and prior['binding_sha256'] == binding_sha, 'matching completed admission required')
        argv += ['--admission', str(admission), '--admission-sha', admission_sha]
    observed = target.supervise(argv, Path(records), cwd=HERE, environment=target.ENV, timeout=60)
    result = dict(status='failed', mode=mode, binding_sha256=binding_sha, supervision=observed,
                  binding_after='failed')
    try:
        validate_binding(bound)
        result['binding_after'] = 'pass'
        require(target.supervision_passed(observed), 'protected child failed; retain raw records')
        require(not target.read(Path(records) / 'stderr'), 'child emitted stderr')
        messages = [target.parse_json(line) for line in target.read(Path(records) / 'stdout').splitlines()]
        require(not any(row.get('denial_overflow') for row in messages), 'denial overflow')
        denied = [row['denied_effect'] for row in messages if 'denied_effect' in row]
        completions = [row['child_result'] for row in messages if 'child_result' in row]
        require(len(completions) == 1 and len(messages) == len(denied) + 1,
                'unexpected child output')
        value = completions[0]
        require(value['status'] == 'pass' and value['mode'] == mode
                and value['binding_sha256'] == binding_sha
                and type(value['negative_controls']) is int and value['negative_controls'] == 44
                and len(denied) == 44 and all(row['phase'] == 'negative' for row in denied),
                'child completion or runtime denial failed')
        require(sum(row['kind'] == 'live-api' for row in denied) == 40
                and sum(row['kind'] == 'audit-dispatch' for row in denied) == 4,
                'protection-probe classification mismatch')
        validate_child(value, bound, mode)
        result.update(status='pass', child=value)
    finally:
        target.write(Path(records) / ('admission.json' if mode == 'admit' else 'check.json'), result)
    return result


def main():
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode, 'isolated startup required')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('_child',))
    parser.add_argument('--mode', choices=('admit', 'offline'), required=True)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--binding-sha', required=True)
    parser.add_argument('--admission', type=Path)
    parser.add_argument('--admission-sha')
    return child(parser.parse_args())


if __name__ == '__main__':
    raise SystemExit(main())
