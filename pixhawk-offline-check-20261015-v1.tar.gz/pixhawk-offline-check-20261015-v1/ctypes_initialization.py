"""One genuine NumPy-triggered ctypes initializer, not general foreign-function authority."""
import ast
import dis
import hashlib
import sys
import types
from pathlib import Path

CTYPES = NUMPY_INTERNAL = None
HASHES = {}


def _call_offsets(code, node):
    positions = (node.lineno, node.end_lineno, node.col_offset, node.end_col_offset)
    instructions = list(dis.get_instructions(code, show_caches=True))
    offsets = set()
    for index, item in enumerate(instructions):
        if item.opname == 'CALL' and tuple(item.positions) == positions:
            offsets.add(item.offset)
            for following in instructions[index + 1:]:
                if following.opname != 'CACHE':
                    break
                offsets.add(following.offset)
    if not offsets:
        raise RuntimeError('reviewed call offset not found')
    return frozenset(offsets)


def descendants(code):
    yield code
    for item in code.co_consts:
        if isinstance(item, types.CodeType):
            yield from descendants(item)


class CtypesInitialization:
    def __init__(self, guard):
        global CTYPES, NUMPY_INTERNAL, HASHES
        CTYPES = str(guard.stdlib / 'ctypes/__init__.py')
        NUMPY_INTERNAL = str(guard.site / 'numpy/_core/_internal.py')
        HASHES = {
            CTYPES: guard.ctypes_sha,
            NUMPY_INTERNAL: '07cb7a9b1bda0e8bb113e08e474d74bf8fcf507373385f261e015ab513e52569',
        }
        self.guard = guard
        self.module = self.initializer = self.numpy_module = None
        self.module_sites = self.initializer_sites = self.numpy_sites = frozenset()
        self.observations = []
        self.negative_controls = []

    def bind_code(self, path, payload, code):
        if path not in HASHES:
            return
        if hashlib.sha256(payload).hexdigest() != HASHES[path]:
            raise RuntimeError('reviewed ctypes initialization source drift')
        tree = ast.parse(payload, filename=path)
        if path == NUMPY_INTERNAL:
            imports = [node for node in ast.walk(tree) if isinstance(node, ast.Import)
                       and len(node.names) == 1 and node.names[0].name == 'ctypes'
                       and node.names[0].asname is None]
            if len(imports) != 1:
                raise RuntimeError('one exact NumPy ctypes import required')
            node = imports[0]
            sites = [item.offset for item in dis.get_instructions(code, show_caches=True)
                     if item.opname == 'IMPORT_NAME' and item.argval == 'ctypes'
                     and tuple(item.positions) == (node.lineno, node.end_lineno, node.col_offset, node.end_col_offset)]
            if len(sites) != 1 or self.numpy_module is not None:
                raise RuntimeError('one initial NumPy module/code binding required')
            self.numpy_module, self.numpy_sites = code, frozenset(sites)
            return
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'CDLL')
        initializer = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == '__init__')
        init_code = next(item for item in descendants(code) if item.co_qualname == 'CDLL.__init__')
        calls = [node for node in ast.walk(initializer) if isinstance(node, ast.Call)
                 and ast.unparse(node) == '_dlopen(self._name, mode)']
        module_calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                        and ast.unparse(node) == 'PyDLL(None)']
        if len(calls) != 1 or len(module_calls) != 1 or self.module is not None:
            raise RuntimeError('one reviewed initial ctypes binding required')
        self.module, self.initializer = code, init_code
        self.module_sites = _call_offsets(code, module_calls[0])
        self.initializer_sites = _call_offsets(init_code, calls[0])

    def _eligible(self, event, arguments, caller):
        if (event != 'ctypes.dlopen' or arguments != (None,) or self.observations
                or self.guard.MODE != 'offline-pixhawk'
                or caller.f_code is not self.initializer or caller.f_lasti not in self.initializer_sites):
            return False
        namespace = self.guard.METADATA.exact_binding(self.guard.METADATA.namespaces, self.module)
        active = self.guard.METADATA.exact_binding(self.guard.METADATA.active_modules, self.module)
        module_frame = caller.f_back
        ctypes = sys.modules.get('ctypes')
        native = sys.modules.get('_ctypes')
        if (namespace is None or namespace is not active or ctypes is None or vars(ctypes) is not namespace
                or module_frame is None or module_frame.f_code is not self.module
                or module_frame.f_globals is not namespace or module_frame.f_lasti not in self.module_sites
                or caller.f_globals is not namespace or namespace.get('__file__') != CTYPES
                or native is None or namespace.get('_dlopen') is not native.dlopen
                or namespace.get('DEFAULT_MODE') != native.RTLD_LOCAL or 'pythonapi' in namespace):
            return False
        cdll, pydll = namespace.get('CDLL'), namespace.get('PyDLL')
        owner = caller.f_locals.get('self')
        if (not isinstance(cdll, type) or not isinstance(pydll, type)
                or pydll.__mro__ != (pydll, cdll, object) or type(owner) is not pydll
                or cdll.__init__.__code__ is not self.initializer or cdll.__init__.__globals__ is not namespace
                or caller.f_locals.get('name') is not None or caller.f_locals.get('handle') is not None
                or caller.f_locals.get('mode') != native.RTLD_LOCAL
                or caller.f_locals.get('use_errno') is not False
                or caller.f_locals.get('use_last_error') is not False
                or caller.f_locals.get('winmode') is not None or owner._name is not None
                or '_handle' in vars(owner)):
            return False
        frame = module_frame.f_back
        numpy_frame = None
        for unused in range(64):
            if frame is None:
                break
            if frame.f_code is self.numpy_module:
                numpy_frame = frame
                break
            frame = frame.f_back
        numpy_namespace = self.guard.METADATA.exact_binding(
            self.guard.METADATA.active_modules, self.numpy_module)
        if (numpy_frame is None or numpy_namespace is None
                or numpy_frame.f_globals is not numpy_namespace
                or numpy_frame.f_lasti not in self.numpy_sites
                or numpy_namespace.get('__file__') != NUMPY_INTERNAL or 'ctypes' in numpy_namespace):
            return False
        return True

    def permit(self, event, arguments, caller):
        if not self._eligible(event, arguments, caller):
            return False
        def copied_frame(frame, **changes):
            fields = {name: getattr(frame, name) for name in
                      ('f_code', 'f_lasti', 'f_globals', 'f_locals', 'f_back')}
            fields.update(changes)
            return types.SimpleNamespace(**fields)
        probes = (
            ('equal-code-not-identity', (None,), copied_frame(caller, f_code=caller.f_code.replace())),
            ('wrong-namespace', (None,), copied_frame(caller, f_globals=dict(caller.f_globals))),
            ('wrong-call-offset', (None,), copied_frame(caller, f_lasti=-1)),
            ('wrong-library-argument', ('unadmitted-library',), caller),
            ('module-code-not-identity', (None,), copied_frame(caller, f_back=copied_frame(
                caller.f_back, f_code=caller.f_back.f_code.replace()))),
        )
        for name, arguments, frame in probes:
            if self._eligible(event, arguments, frame):
                raise RuntimeError('ctypes classifier negative control failed')
            self.negative_controls.append({'name': name, 'denied_by_classifier': True, 'native_execution': False})
        self.observations.append({'classifier_only': True})
        try:
            if self._eligible(event, (None,), caller):
                raise RuntimeError('ctypes initialization count bound failed')
        finally:
            self.observations.pop()
        self.negative_controls.append({'name': 'initialization-replay', 'denied_by_classifier': True,
                                       'native_execution': False})
        module_frame = caller.f_back
        numpy_frame = module_frame
        while numpy_frame.f_code is not self.numpy_module:
            numpy_frame = numpy_frame.f_back
        self.observations.append({
            'event': event, 'argument': None, 'count': 1,
            'ctypes_source_sha256': HASHES[CTYPES], 'numpy_source_sha256': HASHES[NUMPY_INTERNAL],
            'initializer_offset': caller.f_lasti, 'module_offset': module_frame.f_lasti,
            'numpy_import_offset': numpy_frame.f_lasti, 'scope': 'current-process-handle-initialization-only',
        })
        return True


