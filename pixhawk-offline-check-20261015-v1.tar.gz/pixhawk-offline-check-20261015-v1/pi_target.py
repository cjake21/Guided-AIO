"""Bind an existing Pi environment and guard the unchanged installed checker."""

import argparse
import builtins
import datetime
import hashlib
import importlib._bootstrap as bootstrap
import importlib.machinery as machinery
import importlib.util
import json
import os
from pathlib import Path
import selectors
import signal
import site
import stat
import struct
import subprocess
import sys
import sysconfig
import time
import types
import zipimport


SOURCE_COMMIT = "280fb4a8dc11efa35c190c27ebb147e5a2db689b"
SOURCE_PINS = {
    "tools/check_installed.py": "5bb387d247baade6b5b7080a532b89d811248ead66246897723cbfd6a6bd5efc",
    "requirements/development-constraints.txt": "789464956679c6286725d2713150da6f93cf484fed4ba8d651426bab4cbd6929",
    "config/station.example.json": "56a5a1a43a21b717ed093d0d75d9cf6b0b689db115d1822619af2154e6b10494",
}
TARGET = dict(implementation="CPython", python="3.11.2", system="Linux", machine="aarch64",
              pointer_bits=64, libc="glibc", glibc="2.36",
              soabi="cpython-311-aarch64-linux-gnu", py_debug=0)
ENV = dict(PATH="/usr/bin:/bin", LANG="C", LC_ALL="C", TZ="UTC",
           PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", STOMP_SKIP_HOSTNAME_SCAN="1",
           OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
HERE = Path(__file__).resolve().parent
STARTUP_ROOT = Path('/usr/lib/python3.11')
STARTUP_BASE = Path('/usr')
STARTUP_SOURCE = Path('/etc/python3.11/sitecustomize.py')
STARTUP_SOURCE_SIZE = 155
STARTUP_SOURCE_MTIME = 1775613480000000000
STARTUP_OWNER = (0, 0)
STARTUP_CACHE = '__pycache__/sitecustomize.cpython-311.pyc'
STARTUP_CACHE_TAG = 'cpython-311'
STARTUP_LINK = dict(target=str(STARTUP_SOURCE), resolved=str(STARTUP_SOURCE), mode=0o644,
    sha256='43d81125d92376b1a69d53a71126a041cc9a18d8080e92dea0a2ae23be138b1e')
STARTUP_PINS = {
    STARTUP_CACHE: dict(bytes=334, mode=0o644,
        sha256='c55af644025f1502bf838c6bd75a57dacadc719811d7282db36368560162e637'),
    'site.py': dict(bytes=23728, mode=0o644,
        sha256='2779ae9ccd216f70e554fe47dbd1089ff53c7188093baeddcaba0f7c2127ba08'),
    'importlib/_bootstrap.py': dict(bytes=48276, mode=0o644,
        sha256='a06d09f359d9880b2289f0d60958b33a0ddd0767042dcf978c13d684da8a051e'),
    'importlib/_bootstrap_external.py': dict(bytes=68856, mode=0o644,
        sha256='5b7f704fd3198cb474fea0e74cb21df2d159ceb6bde78aad5db3eb5efa883ccf'),
}
STARTUP_BINARY = dict(bytes=6616880, mode=0o755,
    sha256='ef8ea6cdde1ed5696b130d90a07026a3088e0c767166a3a627233da845a9fae9')
STARTUP_DIRECTORIES = tuple(map(Path, ('/', '/usr', '/usr/lib', '/usr/lib/python3.11',
    '/usr/lib/python3.11/__pycache__', '/usr/lib/python3.11/importlib', '/etc', '/etc/python3.11')))
FILE_LOADERS = ((machinery.ExtensionFileLoader, machinery.EXTENSION_SUFFIXES),
                (machinery.SourceFileLoader, machinery.SOURCE_SUFFIXES),
                (machinery.SourcelessFileLoader, machinery.BYTECODE_SUFFIXES))
FILE_HOOK = machinery.FileFinder.path_hook(*FILE_LOADERS)


def importer_state():
    functions = (builtins.__import__, bootstrap._find_and_load, bootstrap._find_and_load_unlocked,
                 bootstrap._load_unlocked, machinery.BuiltinImporter.find_spec.__func__,
                 machinery.FrozenImporter.find_spec.__func__, machinery.PathFinder.find_spec.__func__,
                 machinery.PathFinder._get_spec.__func__, machinery.PathFinder._path_importer_cache.__func__,
                 machinery.PathFinder._path_hooks, machinery.FileFinder.__init__,
                 machinery.FileFinder.find_spec, machinery.FileFinder._fill_cache,
                 machinery.FileFinder._get_spec, machinery.FileFinder.path_hook.__func__,
                 machinery.SourceFileLoader.get_data, machinery.SourceFileLoader.get_code,
                 machinery.SourceFileLoader.exec_module, site.main, site.venv, site.addpackage,
                 site.addsitedir, site.addsitepackages, site.getsitepackages,
                 site.execsitecustomize, site.execusercustomize)
    return tuple((function, getattr(function, '__code__', None)) for function in functions)


IMPORTER_STATE = importer_state()


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def ordinary(path):
    path = Path(os.path.abspath(path))
    for item in (path, *path.parents):
        require(not item.is_symlink(), "symlink path: " + str(item))
    return path


def read(path):
    path = ordinary(path)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= 512 * 1024 * 1024,
                "not a bounded ordinary input: " + str(path))
        data = stream.read(512 * 1024 * 1024 + 1)
        after = os.fstat(stream.fileno())
        fields = lambda info: (info.st_dev, info.st_ino, info.st_mode, info.st_size,
                               info.st_mtime_ns, info.st_ctime_ns)
        require(len(data) == before.st_size and fields(before) == fields(after), "input changed")
    return data


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def identity(path):
    path = ordinary(path)
    data = read(path)
    info = path.stat()
    require(not info.st_mode & 0o022, "group/world-writable input: " + str(path))
    return dict(path=str(path), bytes=len(data), mode=stat.S_IMODE(info.st_mode),
                sha256=hashlib.sha256(data).hexdigest())


def write(path, value):
    path = ordinary(path)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def load_json(path, expected):
    data = read(path)
    require(hashlib.sha256(data).hexdigest() == expected, "record digest mismatch")
    return parse_json(data)


def parse_json(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=unique)


def load_code(path, name):
    spec = importlib.util.spec_from_loader(name, loader=None, origin=str(path))
    module = importlib.util.module_from_spec(spec)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(read(path), str(path), "exec", dont_inherit=True), module.__dict__)
    return module


def snapshot(root, *, environment=False):
    root = ordinary(root)
    require(root.is_dir(), "missing tree: " + str(root))
    files, directories, links = {}, {}, {}
    for current, names, members in os.walk(root, followlinks=False):
        current = Path(current)
        if not environment:
            names[:] = [name for name in names if name not in ("site-packages", "dist-packages")]
        directories[str(current.relative_to(root))] = stat.S_IMODE(current.stat().st_mode)
        for name in sorted(names + members):
            path = current / name
            rel = str(path.relative_to(root))
            info = path.lstat()
            if stat.S_ISLNK(info.st_mode):
                if environment:
                    require(rel == "lib64" and os.readlink(path) == "lib", "unexpected environment symlink")
                    links[rel] = "lib"
                else:
                    target = path.resolve(strict=True)
                    require(target.is_file(), "stdlib directory symlink needs separate review")
                    require(not target.stat().st_mode & 0o022, "writable stdlib link target")
                    links[rel] = dict(target=os.readlink(path), resolved=str(target), sha256=sha(target),
                                      mode=stat.S_IMODE(target.stat().st_mode))
            elif stat.S_ISREG(info.st_mode):
                files[rel] = dict(bytes=info.st_size, mode=stat.S_IMODE(info.st_mode), sha256=sha(path))
            else:
                require(stat.S_ISDIR(info.st_mode), "special tree member")
            require(stat.S_ISLNK(info.st_mode) or not info.st_mode & 0o022,
                    "group/world-writable tree member: " + str(path))
    require(not root.stat().st_mode & 0o022, "unsafe tree root permissions")
    return dict(root=str(root), files=files, directories=directories, links=links)


def check_snapshot(value, *, environment=False):
    require(snapshot(value["root"], environment=environment) == value, "bound tree changed")


def support_pins():
    return {name: identity(HERE / name) for name in ("pi_target.py", "pi_guard.py")}


def target_facts():
    libc_value = os.confstr("CS_GNU_LIBC_VERSION")
    require(isinstance(libc_value, str) and len(libc_value.split()) == 2, "unavailable glibc observation")
    libc = libc_value.split()
    observed = dict(implementation="CPython" if sys.implementation.name == "cpython"
                    else sys.implementation.name,
                    python=".".join(map(str, sys.version_info[:3])), system=os.uname().sysname,
                    machine=os.uname().machine, pointer_bits=struct.calcsize("P") * 8,
                    libc=libc[0], glibc=libc[1], soabi=sysconfig.get_config_var("SOABI"),
                    py_debug=sysconfig.get_config_var("Py_DEBUG"))
    require(observed == TARGET, "target runtime mismatch: " + json.dumps(observed, sort_keys=True))
    return observed


def pre_site_policy(stdlib):
    expected = [str(stdlib.parent / "python311.zip"), str(stdlib), str(stdlib / "lib-dynload")]
    require(sys.path == expected, "unexpected isolated target interpreter search path")
    archive = Path(expected[0])
    require(not os.path.lexists(archive), "interpreter zip archive needs separate review")
    require(not os.path.lexists(Path(sys.base_prefix) / "pyvenv.cfg"),
            "base interpreter configuration needs separate review")


def collect():
    observed = target_facts()
    executable = Path(sys.executable).resolve(strict=True)
    stdlib = Path(sysconfig.get_path("stdlib")).resolve()
    pre_site_policy(stdlib)
    require(site.ENABLE_USER_SITE is None and sys.prefix == sys.base_prefix,
            "site was initialized before binding")
    tree = snapshot(stdlib)
    require(live_startup_policy(tree) is True, 'reviewed target startup hook is required')
    return dict(schema=2, target=observed,
                source_commit=SOURCE_COMMIT, support=support_pins(), executable=str(executable),
                executable_identity=identity(executable), pre_site_path=list(sys.path), stdlib=tree,
                native_status="trusted CPython/OS/stdlib only; installed native extensions forbidden")


def check_facts(facts, app=None):
    require(facts["schema"] == 2 and facts["source_commit"] == SOURCE_COMMIT,
            "facts schema/source mismatch")
    require(facts["support"] == support_pins(), "support changed")
    require(identity(facts["executable"]) == facts["executable_identity"], "interpreter changed")
    require(sha(Path(sys.executable).resolve(strict=True)) == facts["executable_identity"]["sha256"],
            "running interpreter differs from bound interpreter")
    require(target_facts() == facts["target"], "target observations changed")
    check_snapshot(facts["stdlib"])
    require(live_startup_policy(facts["stdlib"], app) is True,
            'reviewed target startup hook is required')
    pre_site_policy(Path(facts["stdlib"]["root"]))
    require(sys.path == facts["pre_site_path"], "pre-site interpreter path changed")


def group_alive(group):
    try:
        os.killpg(group, 0)
        return True
    except ProcessLookupError:
        return False


def supervision_passed(result):
    return (result.get("exit") == 0 and result.get("quiescent") is True
            and not any(result.get(key) for key in
                        ("timeout", "output_limit", "exception", "residual_descendants", "cleanup_errors")))


def supervise(command, records, *, cwd, environment, timeout=120, cap=1024 * 1024):
    records = ordinary(records)
    records.mkdir(mode=0o700)
    result = dict(command=command, timeout_seconds=timeout, stream_limit_bytes=cap,
                  status="failed", cleanup_errors=[], cwd=str(cwd), environment=environment,
                  start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(records / "attempt.json", result)
    process = None
    selector = selectors.DefaultSelector()
    streams = {}
    try:
        process = subprocess.Popen(command, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   start_new_session=True, close_fds=True)
        result["owned_group"] = process.pid
        for name, pipe in (("stdout", process.stdout), ("stderr", process.stderr)):
            streams[name] = (records / name).open("xb")
            selector.register(pipe, selectors.EVENT_READ, name)
            result[name + "_bytes"] = 0
        deadline = time.monotonic() + timeout
        terminating = False
        while selector.get_map() or process.poll() is None:
            now = time.monotonic()
            if now >= deadline:
                result["timeout"] = True
                break
            for key, unused in selector.select(min(0.1, deadline - now)):
                data = os.read(key.fileobj.fileno(), 65536)
                if not data:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                name = key.data
                previous = result[name + "_bytes"]
                result[name + "_bytes"] += len(data)
                streams[name].write(data[:max(0, cap - previous)])
                if result[name + "_bytes"] > cap:
                    result["output_limit"] = True
                    terminating = True
            if terminating:
                break
        result["exit"] = process.poll()
    except BaseException as error:
        result["exception"] = type(error).__name__
    finally:
        if process is not None:
            try:
                if group_alive(process.pid):
                    if process.poll() is not None:
                        result["residual_descendants"] = True
                    os.killpg(process.pid, signal.SIGKILL)
                result["final_exit"] = process.wait(timeout=5)
                until = time.monotonic() + 5
                while group_alive(process.pid) and time.monotonic() < until:
                    time.sleep(0.01)
                result["quiescent"] = not group_alive(process.pid)
            except BaseException as error:
                result["cleanup_errors"].append(type(error).__name__)
            for pipe in (process.stdout, process.stderr):
                if pipe is not None and not pipe.closed:
                    pipe.close()
        selector.close()
        for name, stream in streams.items():
            stream.flush()
            os.fsync(stream.fileno())
            stream.close()
            result[name + "_sha256"] = sha(records / name)
        result["status"] = "pass" if supervision_passed(result) else "failed"
        result["end_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(records / "result.json", result)
    return result


def startup_policy(app):
    require(not os.path.lexists(app / 'bin/pyvenv.cfg'), 'interpreter-adjacent configuration present')
    for name in ('lib/python3/dist-packages', 'local/lib/python3.11/dist-packages',
                 'lib/python3.11/dist-packages'):
        require(not os.path.lexists(app / name), 'additional application site directory: ' + name)
    config = read(app / "pyvenv.cfg").decode()
    settings = [line.strip() for line in config.splitlines()
                if line.strip().startswith("include-system-site-packages")]
    require(settings == ["include-system-site-packages = false"], "system site packages enabled/ambiguous")
    package_site = app / "lib/python3.11/site-packages"
    require(package_site.is_dir(), "application site missing")
    require(not any(path.name.endswith(".pth") or path.name in ("sitecustomize", "usercustomize")
                    or path.name.startswith(("sitecustomize.", "usercustomize."))
                    for path in package_site.rglob("*")), "startup hook present")
    return package_site


def initialize_site(app, pre_site_path, package_sites, startup_tree=None):
    before = dict(prefix=sys.prefix, user_site=site.ENABLE_USER_SITE, path=list(sys.path))
    expected = pre_site_path + [str(path) for path in package_sites]
    reviewed_hook = startup_tree is not None
    if reviewed_hook:
        require(live_startup_policy(startup_tree, app) is True, 'reviewed target startup hook is required')
        require(sys.path == pre_site_path and site.ENABLE_USER_SITE is None,
                'reviewed hook requires uninitialized isolated site')
        require(package_sites == [startup_policy(app)], 'prospective site paths changed')
        require('sitecustomize' not in sys.modules and 'usercustomize' not in sys.modules,
                'startup hook already loaded')
        standard_import_policy(expected)
        verify_hook_spec(machinery.PathFinder.find_spec('sitecustomize', expected))
    site.main()
    observed = dict(before=before, prefix=sys.prefix, user_site=site.ENABLE_USER_SITE, path=list(sys.path))
    require(sys.prefix == str(app) and site.ENABLE_USER_SITE is False
            and sys.path == expected, "guarded site layout mismatch: " + json.dumps(observed, sort_keys=True))
    if reviewed_hook:
        require(live_startup_policy(startup_tree, app) is True, 'reviewed target startup hook is required')
        require(package_sites == [startup_policy(app)], 'post-site paths changed')
        standard_import_policy(expected)
        module = sys.modules.get('sitecustomize')
        require(type(module) is types.ModuleType, 'reviewed hook was not imported')
        spec = module.__dict__.get('__spec__')
        verify_hook_spec(spec)
        require(module.__dict__.get('__loader__') is spec.loader
                and module.__dict__.get('__file__') == str(STARTUP_ROOT / 'sitecustomize.py')
                and module.__dict__.get('__cached__') == str(STARTUP_ROOT / STARTUP_CACHE)
                and 'apport_python_hook' not in module.__dict__
                and 'usercustomize' not in sys.modules, 'reviewed hook outcome changed')
    return observed


def reject_base_startup(tree):
    hooks = {name for name in set(tree['files']) | set(tree['links']) | set(tree['directories'])
             if Path(name).name in ('sitecustomize', 'usercustomize')
             or Path(name).name.startswith(('sitecustomize.', 'usercustomize.'))}
    if not hooks:
        return False
    require(tree['root'] == str(STARTUP_ROOT)
            and hooks == {'sitecustomize.py', STARTUP_CACHE}, 'base startup hook needs separate review')
    require(tree['links'].get('sitecustomize.py') == STARTUP_LINK,
            'reviewed startup source link changed')
    require('sitecustomize.py' not in tree['files'] and 'sitecustomize.py' not in tree['directories']
            and STARTUP_CACHE not in tree['links'] and STARTUP_CACHE not in tree['directories'],
            'reviewed startup member type changed')
    for name, expected in STARTUP_PINS.items():
        require(tree['files'].get(name) == expected, 'reviewed startup bytes or mode changed: ' + name)
    require(all(tree['directories'].get(name) == 0o755 for name in ('.', '__pycache__', 'importlib')),
            'reviewed startup directory mode changed')
    return True


def startup_file_policy(path, expected, *, owner=True):
    observed = identity(path)
    require({key: observed[key] for key in ('bytes', 'mode', 'sha256')} == expected,
            'live startup file changed: ' + str(path))
    info = path.lstat()
    require(not owner or (info.st_uid, info.st_gid) == STARTUP_OWNER,
            'live startup ownership changed: ' + str(path))
    return info


def live_startup_policy(tree, app=None):
    if not reject_base_startup(tree):
        return False
    check_snapshot(tree)
    require(sys.base_prefix == str(STARTUP_BASE) and sys.base_exec_prefix == str(STARTUP_BASE)
            and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
            and sys.flags.optimize == 0 and sys.implementation.cache_tag == STARTUP_CACHE_TAG,
            'reviewed startup interpreter context changed')
    executable = Path(sys.executable)
    allowed = {STARTUP_BASE / 'bin/python3.11'}
    if app is not None:
        allowed.add(app / 'bin/python')
    require(executable in allowed, 'reviewed startup executable path changed')
    startup_file_policy(executable, STARTUP_BINARY, owner=executable == STARTUP_BASE / 'bin/python3.11')
    for path in STARTUP_DIRECTORIES:
        info = ordinary(path).lstat()
        require(stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o755
                and (info.st_uid, info.st_gid) == STARTUP_OWNER, 'reviewed startup ancestor changed')
    source = dict(bytes=STARTUP_SOURCE_SIZE, mode=STARTUP_LINK['mode'], sha256=STARTUP_LINK['sha256'])
    info = startup_file_policy(STARTUP_SOURCE, source)
    require(info.st_mtime_ns == STARTUP_SOURCE_MTIME, 'reviewed source timestamp changed')
    link = STARTUP_ROOT / 'sitecustomize.py'
    info = link.lstat()
    require(stat.S_ISLNK(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o777
            and (info.st_uid, info.st_gid) == STARTUP_OWNER
            and info.st_mtime_ns == STARTUP_SOURCE_MTIME
            and os.readlink(link) == STARTUP_LINK['target']
            and str(link.resolve(strict=True)) == STARTUP_LINK['resolved'], 'live startup source link changed')
    for name, expected in STARTUP_PINS.items():
        startup_file_policy(STARTUP_ROOT / name, expected)
    return True


def standard_import_policy(paths):
    expected = (machinery.BuiltinImporter, machinery.FrozenImporter, machinery.PathFinder)
    require(len(sys.meta_path) == len(expected)
            and all(actual is wanted for actual, wanted in zip(sys.meta_path, expected))
            and all(actual[0] is wanted[0] and actual[1] is wanted[1]
                    for actual, wanted in zip(importer_state(), IMPORTER_STATE)),
            'standard startup import machinery changed')
    require(len(sys.path_hooks) == 2 and sys.path_hooks[0] is zipimport.zipimporter,
            'standard startup path hooks changed')
    hook = sys.path_hooks[1]
    require(type(hook) is types.FunctionType and hook.__code__ is FILE_HOOK.__code__
            and hook.__globals__ is FILE_HOOK.__globals__ and hook.__closure__ is not None
            and tuple(cell.cell_contents for cell in hook.__closure__)
            == tuple(cell.cell_contents for cell in FILE_HOOK.__closure__),
            'standard startup file finder changed')
    loaders = [(suffix, loader) for loader, suffixes in FILE_LOADERS for suffix in suffixes]
    for name in ('apport_python_hook', 'usercustomize'):
        require(name not in sys.modules and machinery.BuiltinImporter.find_spec(name) is None
                and machinery.FrozenImporter.find_spec(name) is None,
                'optional startup module already available: ' + name)
        for path in paths:
            cached = sys.path_importer_cache.get(path)
            require(cached is None or (type(cached) is machinery.FileFinder and cached.path == path
                    and cached._loaders == loaders and set(cached.__dict__) == {
                        'path', '_loaders', '_path_mtime', '_path_cache', '_relaxed_path_cache'}),
                    'nonstandard cached startup finder')
            try:
                info = Path(path).lstat()
            except FileNotFoundError:
                continue
            require(stat.S_ISDIR(info.st_mode) and ordinary(path).is_dir(),
                    'startup search archive/file present')
            require(machinery.FileFinder(path, *FILE_LOADERS).find_spec(name) is None,
                    'optional startup module discoverable: ' + name)
    require(machinery.BuiltinImporter.find_spec('sitecustomize') is None
            and machinery.FrozenImporter.find_spec('sitecustomize') is None,
            'builtin or frozen startup hook present')


def verify_hook_spec(spec):
    require(type(spec) is machinery.ModuleSpec and spec.name == 'sitecustomize'
            and type(spec.loader) is machinery.SourceFileLoader
            and spec.loader.__dict__ == dict(name='sitecustomize', path=str(STARTUP_ROOT / 'sitecustomize.py'))
            and spec.origin == str(STARTUP_ROOT / 'sitecustomize.py')
            and spec.cached == str(STARTUP_ROOT / STARTUP_CACHE)
            and spec.submodule_search_locations is None, 'reviewed startup loader selection changed')


def check_origins(files, native):
    for module in tuple(sys.modules.values()):
        filename = getattr(module, "__file__", None)
        if filename and not filename.startswith("<"):
            resolved = str(Path(filename).resolve())
            require(resolved in files, "loaded module escaped frozen read inputs: " + resolved)
            require(not resolved.endswith(".so") or resolved in native, "installed native module loaded")


def reject_application_imports(app):
    for module in tuple(sys.modules.values()):
        filename = getattr(module, "__file__", None)
        if filename and not filename.startswith("<"):
            require(app not in Path(filename).resolve().parents,
                    "installed code loaded before application check")


def validate_cache_receipts(receipt, binding):
    require(type(receipt) is dict and set(receipt) ==
            {'schema', 'policy', 'sources', 'observations', 'total'}
            and receipt['schema'] == 'importer-cache-absence.v1'
            and receipt['policy'] == 'ENOENT without cache-byte access', 'invalid cache receipt')
    files = set()
    for tree in (binding['facts']['stdlib'], binding['environment']):
        files.update(str(Path(tree['root']) / name) for name in tree['files'])
    files.update(row['resolved'] for row in binding['facts']['stdlib']['links'].values())
    files.update(row['path'] for row in binding['source_inputs'].values())
    files.update(row['path'] for row in binding['facts']['support'].values())
    sources = {path for path in files if path.endswith('.py')}
    rows = receipt['observations']
    require(type(receipt['sources']) is int and 0 <= receipt['sources'] <= len(sources)
            and type(rows) is list and len(rows) <= receipt['sources']
            and type(receipt['total']) is int, 'invalid cache receipt limits')
    caches = []
    for row in rows:
        require(type(row) is dict and set(row) == {'source', 'cache', 'attempts'}
                and type(row['source']) is str and row['source'] in sources
                and type(row['cache']) is str
                and row['cache'] == importlib.util.cache_from_source(row['source'])
                and row['cache'] not in files and type(row['attempts']) is int
                and 1 <= row['attempts'] <= 2**31 - 1, 'unbound cache receipt')
        caches.append(row['cache'])
    require(caches == sorted(set(caches))
            and receipt['total'] == sum(row['attempts'] for row in rows), 'cache receipt accounting')


def install_observation(log, log_sha, exit_file, exit_sha, app):
    log_input, exit_input = identity(log), identity(exit_file)
    require(log_input["sha256"] == log_sha and exit_input["sha256"] == exit_sha,
            "operator provenance digest mismatch")
    require(read(exit_file) in (b"0", b"0\n"), "operator-reported installer exit is not exact zero")
    lines = read(log).decode("utf-8").splitlines()
    require(lines and "No broken requirements found." in lines, "dependency-check observation missing")
    observation = parse_json(lines[-1])
    require(observation.get("status") == "offline installation and dependency check passed"
            and observation.get("selection") == "manager"
            and observation.get("application") == str(app)
            and observation.get("application_import_checks") == "pending separate target effect-control admission",
            "operator installation observation mismatch")
    require(identity(log) == log_input and identity(exit_file) == exit_input,
            "operator provenance changed while reading")
    return dict(kind="supplied-operator-provenance", log=log_input, exit_file=exit_input,
                reported_exit=0, reported_final=observation,
                scope="recorded installer observation only; current binding and checker are authoritative")


def source_inputs(source):
    inputs = {name: identity(source / name) for name in SOURCE_PINS}
    for name, expected in SOURCE_PINS.items():
        require(inputs[name]["sha256"] == expected, "fixed source input changed: " + name)
    return inputs


def bind_existing(args):
    facts = collect()
    app = ordinary(args.application)
    provenance = install_observation(args.install_log, args.install_log_sha,
                                     args.install_exit, args.install_exit_sha, app)
    startup_policy(app)
    require(sha(app / "bin/python") == facts["executable_identity"]["sha256"], "application interpreter differs")
    source = ordinary(args.source)
    binding = dict(schema=2, facts=facts, source=str(source), source_inputs=source_inputs(source),
                source_pins=SOURCE_PINS, source_scope="three fixed checker inputs, not full checkout attestation",
                operator_provenance=provenance, environment=snapshot(app, environment=True))
    validate_binding(binding)
    return binding


def validate_binding(binding):
    require(binding["schema"] == 2 and binding["source_pins"] == SOURCE_PINS, "binding scope changed")
    app = Path(binding["environment"]["root"])
    check_facts(binding["facts"], app)
    require(source_inputs(Path(binding["source"])) == binding["source_inputs"], "bound source inputs changed")
    check_snapshot(binding["environment"], environment=True)
    package_site = startup_policy(app)
    provenance = binding["operator_provenance"]
    require(install_observation(provenance["log"]["path"], provenance["log"]["sha256"],
                               provenance["exit_file"]["path"], provenance["exit_file"]["sha256"], app)
            == provenance, "bound operator provenance changed")
    if reject_base_startup(binding["facts"]["stdlib"]):
        require('sitecustomize' not in sys.modules, 'startup hook loaded before binding')
        paths = binding['facts']['pre_site_path'] + [str(package_site)]
        standard_import_policy(paths)
        verify_hook_spec(machinery.PathFinder.find_spec('sitecustomize', paths))


def child(args):
    binding = load_json(args.binding, args.binding_sha)
    validate_binding(binding)
    facts = binding["facts"]
    app = Path(binding["environment"]["root"])
    require(Path(sys.executable) == app / "bin/python", "not the bound app interpreter")
    require(dict(os.environ) == ENV, "child environment changed")
    reject_application_imports(app)
    if args.mode == "check":
        admission = load_json(args.admission, args.admission_sha)
        require(admission["status"] == "pass" and admission["mode"] == "admit"
                and admission["binding_sha256"] == args.binding_sha, "admission mismatch")
    files, directories, native = set(), set(), set()
    for tree in (facts["stdlib"], binding["environment"]):
        root = Path(tree["root"])
        files.update(str(root / name) for name in tree["files"])
        directories.update(str(root / name) for name in tree["directories"])
    files.update(item["resolved"] for item in facts["stdlib"]["links"].values())
    stdlib = Path(facts["stdlib"]["root"])
    native.update(str(stdlib / name) for name in facts["stdlib"]["files"]
                  if name.startswith("lib-dynload/") and name.endswith(".so"))
    native.update(item["resolved"] for name, item in facts["stdlib"]["links"].items()
                  if name.startswith("lib-dynload/") and name.endswith(".so"))
    files.update(str(Path(binding["source"]) / name) for name in SOURCE_PINS)
    files.update(str(HERE / name) for name in facts["support"])
    # site may inspect an absent base configuration, but may not load base packages.
    files.add(str(Path(sys.base_prefix) / "pyvenv.cfg"))
    guard_module = load_code(HERE / "pi_guard.py", "pi_guard")
    guard = guard_module.CheckGuard(files, directories, native)
    guard.activate()
    negatives = guard.probes()
    result = dict(status="pass", mode=args.mode, negative_controls=negatives,
                  binding_sha256=args.binding_sha, protection="Python API/audit; trusted native runtime",
                  application_imports=False, native_application_loading=False)
    package_site = startup_policy(app)
    result["site"] = initialize_site(app, facts["pre_site_path"], [package_site], facts['stdlib'])
    check_origins(files, native)
    reject_application_imports(app)
    if args.mode == "check":
        checker = load_code(Path(binding["source"]) / "tools/check_installed.py", "fixed_installed_check")
        result["checker"] = checker.main(["--manager"])
        result["application_imports"] = True
        check_origins(files, native)
    guard.finish()
    result['cache_absence'] = guard.cache_receipts()
    validate_cache_receipts(result['cache_absence'], binding)
    print(json.dumps({"child_result": result}, sort_keys=True), flush=True)


def guarded(args):
    binding = load_json(args.binding, args.binding_sha)
    validate_binding(binding)
    require(args.command != "admit" or args.accept_trusted_native,
            "review actual target runtime and Python/native limitations before admission")
    argv = [str(Path(binding["environment"]["root"]) / "bin/python"), "-I", "-B", "-S",
            str(HERE / "pi_target.py"), "_child", "--mode", args.command,
            "--binding", str(ordinary(args.binding)), "--binding-sha", args.binding_sha]
    if args.command == "check":
        admission = load_json(args.admission, args.admission_sha)
        require(admission["status"] == "pass" and admission["mode"] == "admit"
                and admission["binding_sha256"] == args.binding_sha, "matching admission required")
        argv += ["--admission", str(ordinary(args.admission)), "--admission-sha", args.admission_sha]
    observed = supervise(argv, args.records, cwd=HERE, environment=ENV)
    result = dict(status="failed", mode=args.command, binding_sha256=args.binding_sha, supervision=observed)
    try:
        try:
            validate_binding(binding)
        except (RuntimeError, OSError, ValueError, KeyError, TypeError) as error:
            result["binding_after"] = "failed"
            result["binding_after_error"] = str(error)
            raise
        result["binding_after"] = "pass"
        require(observed["status"] == "pass", "guard child failed; inspect retained records")
        require(not read(Path(args.records) / "stderr"), "guard child emitted stderr or cleanup error")
        messages = [json.loads(line) for line in read(Path(args.records) / "stdout").splitlines()]
        require(not any(item.get("denial_overflow") for item in messages), "denial overflow")
        denied = [item["denied_effect"] for item in messages if "denied_effect" in item]
        completions = [item["child_result"] for item in messages if "child_result" in item]
        require(len(completions) == 1 and completions[0]["status"] == "pass"
                and completions[0]["mode"] == args.command
                and completions[0]["binding_sha256"] == args.binding_sha, "missing child completion")
        require(len(denied) == completions[0]["negative_controls"]
                and all(item["phase"] == "negative" for item in denied), "runtime/late denial")
        validate_cache_receipts(completions[0]['cache_absence'], binding)
        result.update(status="pass", child=completions[0])
    finally:
        write(Path(args.records) / "admission.json" if args.command == "admit"
              else Path(args.records) / "check.json", result)
    return result


def main():
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
            "use python3.11 -I -B -S")
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    bind_parser = sub.add_parser("bind-existing")
    for name in ("application", "source", "install-log", "install-exit", "output"):
        bind_parser.add_argument("--" + name, type=Path, required=True)
    for name in ("install-log-sha", "install-exit-sha"):
        bind_parser.add_argument("--" + name, required=True)
    for name in ("admit", "check", "_child"):
        command = sub.add_parser(name)
        command.add_argument("--binding", type=Path, required=True)
        command.add_argument("--binding-sha", required=True)
        if name != "_child":
            command.add_argument("--records", type=Path, required=True)
        if name == "admit":
            command.add_argument("--accept-trusted-native", action="store_true")
        if name in ("check", "_child"):
            command.add_argument("--admission", type=Path)
            command.add_argument("--admission-sha")
        if name == "_child":
            command.add_argument("--mode", choices=("admit", "check"), required=True)
    args = parser.parse_args()
    if args.command == "bind-existing":
        write(args.output, bind_existing(args))
    elif args.command == "_child":
        child(args)
    else:
        guarded(args)


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as error:
        print("STOP: " + str(error), file=sys.stderr)
        raise SystemExit(1)
