"""Run the fixed installed check and retain one bounded, operator-owned attempt."""

import argparse
import contextlib
import datetime
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import stat
import sys
import tarfile
import tempfile
import time
from types import SimpleNamespace

HERE = Path(os.path.abspath(__file__)).parent
TEST_ROOT = Path('/home/admin/satgs-pi-test')
ENV = dict(PATH='/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC',
           PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', STOMP_SKIP_HOSTNAME_SCAN='1',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
SUPPORT = {
    'pi_target.py': 'dd905f46e6b5a1b5a0e5a7f7aadc28272fc0910e465fe6dd4f57c4391edae80b',
    'pi_guard.py': '7283e3f9db6f3a38e3e0208f86b60723c39e1a28969eab518e4c8044319cc4ab',
}
REFERENCE_PINS = {
    'tools/check_installed.py': '5bb387d247baade6b5b7080a532b89d811248ead66246897723cbfd6a6bd5efc',
    'requirements/development-constraints.txt': '789464956679c6286725d2713150da6f93cf484fed4ba8d651426bab4cbd6929',
    'config/station.example.json': '56a5a1a43a21b717ed093d0d75d9cf6b0b689db115d1822619af2154e6b10494',
    'NOTICES.md': 'd8eb0b5b7df768975c555ba6e8b3569acfc3d363c3a8cec8cb8409ec3951d462',
}
RESOURCE = 'cbff15682b2f28ca4ffd0ec087729f316f92819b19a1da9d2f114c6d5f613666'
MODULES = frozenset(('satgs', 'satgs._package_layout', 'satgs.deployment',
    'satgs.runtime_configuration', 'meteor_api', 'meteor_api.messenger', 'stomp',
    'ptu_control', 'ptu_control.pointing', 'ptu_control.tracking', 'pixhawk',
    'satgs.jobs_msg_pb2', 'meteor_api.protobufs.Meteor_pb2', 'ptu_control.ptu_msg_pb2',
    'pixhawk.pixhawk_pb2', 'google.protobuf.timestamp_pb2', 'serialptu', 'serialptu.proto_impl'))
PHASES = ('inputs', 'binding', 'admission', 'check')
MAX_FILE = 32 * 1024 * 1024
MAX_EVIDENCE = 64 * 1024 * 1024
ALLOWED_ROOT = {'binding.json', 'input-identities.json', 'phase-summary.json'}
ALLOWED_RECORDS = {'attempt.json', 'result.json', 'stdout', 'stderr', 'admission.json', 'check.json'}


def require(value, message):
    if not value:
        raise ValueError(message)


def ordinary(path):
    path = Path(os.path.abspath(path))
    for part in (path, *path.parents):
        require(not part.is_symlink(), 'symlinked input: ' + str(part))
    return path


def read(path, limit=MAX_FILE):
    path = ordinary(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, 'invalid bounded file: ' + str(path))
        data = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
        current = path.lstat()
        fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mode, s.st_mtime_ns, s.st_ctime_ns)
        require(len(data) == before.st_size and fields(before) == fields(after) == fields(current), 'input changed')
    return data


def digest(path):
    return hashlib.sha256(read(path)).hexdigest()


def load_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON field')
            result[key] = value
        return result
    return json.loads(read(path), object_pairs_hook=pairs)


def write_bytes(path, data):
    path = ordinary(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def write_json(path, value):
    write_bytes(path, (json.dumps(value, sort_keys=True, indent=2) + '\n').encode())


def identity(path):
    data = read(path)
    require(not Path(path).stat().st_mode & 0o022, 'group/world writable input: ' + str(path))
    return dict(path=str(ordinary(path)), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def verify_package():
    expected = {'run_pi_checks.sh', 'run_pi_checks.py', 'export-provenance.json',
                'pi_target.py', 'pi_guard.py', 'README.md'}
    expected |= {'reference/' + name for name in REFERENCE_PINS}
    found = {}
    for line in read(HERE / 'SHA256SUMS', 16384).decode('ascii').splitlines():
        checksum, name = line.split('  ')
        require(name in expected and name not in found and len(checksum) == 64,
                'unexpected support checksum entry')
        found[name] = identity(HERE / name)
        require(found[name]['sha256'] == checksum, 'support checksum mismatch: ' + name)
    require(set(found) == expected, 'support checksum membership mismatch')
    return found


def module_at(path, name, expected=None):
    data = read(path)
    require(expected is None or hashlib.sha256(data).hexdigest() == expected, 'module changed before loading')
    spec = importlib.util.spec_from_loader(name, loader=None, origin=str(path))
    module = importlib.util.module_from_spec(spec)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(data, str(path), 'exec', dont_inherit=True), module.__dict__)
    return module


def load_support(path):
    for name, expected in SUPPORT.items():
        require(identity(path / name)['sha256'] == expected, 'reviewed support mismatch: ' + name)
    return module_at(path / 'pi_target.py', 'reviewed_pi_target', SUPPORT['pi_target.py'])


def verify_reference(target):
    root = ordinary(HERE / 'reference')
    provenance = load_json(HERE / 'export-provenance.json')
    require(provenance.get('schema') == 1
            and provenance.get('source_commit') == '280fb4a8dc11efa35c190c27ebb147e5a2db689b'
            and provenance.get('source_tree') == 'b416271713af5d055e26a2f988482a25e6c36f5b'
            and provenance.get('established_by') == 'Codex-side fixed-commit blob export'
            and provenance.get('target_git_verification') is False,
            'invalid export provenance')
    require(set(provenance['files']) == set(REFERENCE_PINS), 'reference membership mismatch')
    for name, expected in REFERENCE_PINS.items():
        current = identity(root / name)
        require(current['sha256'] == expected
                and provenance['files'][name] == dict(sha256=expected, bytes=current['bytes'], mode='0644'),
                'bundled reference mismatch: ' + name)
    return dict(export_provenance=provenance, inputs=target.source_inputs(root))


def verify_checker(checker, binding):
    for name, value in dict(status='pass', scope='installed-package-resource-and-protobuf-check',
            manager_packages=True, distributions=31, protobuf_cases=5,
            canonical_resource_sha256=RESOURCE, unconfigured_example_rejected=True,
            owner_constructed=False, navigation_qualified=False, hardware_qualified=False).items():
        require(type(checker.get(name)) is type(value) and checker[name] == value,
                'checker result mismatch: ' + name)
    require(set(checker['origins']) == MODULES, 'checker origin membership mismatch')
    files = binding['environment']['files']
    for module, item in checker['origins'].items():
        rel = item['relative_path']
        require(isinstance(rel, str) and rel and not Path(rel).is_absolute()
                and '..' not in Path(rel).parts and str(Path(rel)) == rel, 'invalid module path: ' + module)
        key = 'lib/python3.11/site-packages/' + rel
        require(key in files and item['sha256'] == files[key]['sha256'], 'module not bound: ' + module)
    key = 'lib/python3.11/site-packages/satgs/data/deployment_profiles.json'
    require(files[key]['sha256'] == RESOURCE, 'resource is not bound')
    return dict(checker)


def validate_result(target, mode, records, binding, binding_sha, returned):
    result_path = records / ('admission.json' if mode == 'admit' else 'check.json')
    value = load_json(result_path)
    require(value == returned, 'returned and retained results disagree')
    require(value['status'] == 'pass' and value['mode'] == mode
            and value['binding_sha256'] == binding_sha and value['binding_after'] == 'pass',
            'phase result or binding-after failed')
    supervision = load_json(records / 'result.json')
    require(supervision == value['supervision'], 'nested supervision mismatch')
    require(supervision.get('status') == 'pass' and target.supervision_passed(supervision)
            and supervision.get('exit') == 0 and supervision.get('final_exit') == 0
            and supervision.get('quiescent') is True and supervision.get('cleanup_errors') == [],
            'nested child exit or cleanup failed')
    initial = load_json(records / 'attempt.json')
    for key, item in initial.items():
        if key not in ('status', 'cleanup_errors'):
            require(supervision.get(key) == item, 'nested command envelope changed: ' + key)
    require(supervision['environment'] == ENV and supervision['timeout_seconds'] == 120
            and supervision['stream_limit_bytes'] == 1024 * 1024, 'child execution controls changed')
    expected_argv = [str(Path(binding['environment']['root']) / 'bin/python'), '-I', '-B', '-S',
                     str(target.HERE / 'pi_target.py'), '_child', '--mode', mode,
                     '--binding', str(records.parent / 'binding.json'), '--binding-sha', binding_sha]
    if mode == 'check':
        admission_path = records.parent / 'admission/admission.json'
        expected_argv += ['--admission', str(admission_path), '--admission-sha', digest(admission_path)]
    require(supervision['command'] == expected_argv and supervision['cwd'] == str(target.HERE),
            'unexpected child command or cwd')
    for stream in ('stdout', 'stderr'):
        raw = read(records / stream, 1024 * 1024)
        require(len(raw) == supervision[stream + '_bytes']
                and hashlib.sha256(raw).hexdigest() == supervision[stream + '_sha256'],
                'child stream identity mismatch')
    require(not read(records / 'stderr'), 'child stderr is not empty')
    messages = [target.parse_json(line) for line in read(records / 'stdout').splitlines()]
    require(all(isinstance(item, dict) for item in messages), 'invalid child message')
    require(not any(item.get('denial_overflow') for item in messages), 'denial overflow')
    denials = [item['denied_effect'] for item in messages if 'denied_effect' in item]
    completions = [item['child_result'] for item in messages if 'child_result' in item]
    child = value['child']
    require(completions == [child] and child['status'] == 'pass' and child['mode'] == mode
            and child['binding_sha256'] == binding_sha and child['negative_controls'] == 41
            and len(denials) == 41 and all(item['phase'] == 'negative' for item in denials),
            'missing completion or runtime/late denial')
    require(sum(item.get('kind') == 'live-api' for item in denials) == 38
            and sum(item.get('kind') == 'audit-dispatch' for item in denials) == 3,
            'negative-control kinds changed')
    target.validate_cache_receipts(child['cache_absence'], binding)
    remaining = [item for item in messages if 'denied_effect' not in item and 'child_result' not in item]
    require(remaining == ([child.get('checker')] if mode == 'check' else []),
            'unexpected or conflicting child output')
    require(child['application_imports'] is (mode == 'check')
            and child['native_application_loading'] is False, 'application/native admission mismatch')
    site = child['site']
    require(site['prefix'] == binding['environment']['root'] and site['user_site'] is False
            and site['path'] == binding['facts']['pre_site_path'] +
                [str(Path(binding['environment']['root']) / 'lib/python3.11/site-packages')],
            'guarded site state mismatch')
    require(site['before']['user_site'] is None and site['before']['path'] == binding['facts']['pre_site_path'],
            'site initialized before guard')
    target.validate_binding(binding)
    if mode == 'check':
        return verify_checker(child['checker'], binding)
    require('checker' not in child, 'admission unexpectedly ran checker')
    return None


class RunInterrupted(KeyboardInterrupt):
    pass


class Interrupts:
    def __init__(self):
        self.received = []
        self.finalizing = False

    def handler(self, number, frame):
        self.received.append(number)
        if len(self.received) == 1 and not self.finalizing:
            raise RunInterrupted('operator interruption')


class BoundedText:
    def __init__(self, stream):
        self.stream = stream
        self.count = 0

    def write(self, value):
        data = value.encode('utf-8', 'replace')
        remaining = max(0, 1024 * 1024 - self.count)
        self.stream.write(data[:remaining])
        self.count += len(data)
        require(self.count <= 1024 * 1024, 'phase output limit')
        return len(value)

    def flush(self):
        self.stream.flush()


def error_text(error):
    return ''.join(c if c.isprintable() else ' ' for c in str(error))[:2000]


def package_attempt(attempt):
    files, total = {}, 0
    for path in sorted(attempt.rglob('*')):
        ordinary(path)
        rel = path.relative_to(attempt)
        if path.is_dir():
            require(len(rel.parts) == 1 and (rel.name.startswith('phase-') or rel.name in ('admission', 'check')),
                    'unexpected evidence directory')
            continue
        permitted = (len(rel.parts) == 1 and rel.name in ALLOWED_ROOT) or (
            len(rel.parts) == 2 and ((rel.parts[0] in {'phase-' + n for n in PHASES}
                and rel.name in {'call.json', 'stdout', 'stderr'}) or
                (rel.parts[0] in ('admission', 'check') and rel.name in ALLOWED_RECORDS)))
        require(permitted, 'unexpected evidence member: ' + str(rel))
        data = read(path)
        total += len(data)
        require(total <= MAX_EVIDENCE and len(files) < 64, 'evidence limit exceeded')
        files[str(rel)] = data
    checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n'
                        for name, data in files.items()).encode()
    write_bytes(attempt / 'EVIDENCE-SHA256SUMS', checksums)
    files['EVIDENCE-SHA256SUMS'] = checksums
    partial = attempt / 'evidence.partial.tar.gz'
    with partial.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as archive:
            for name, data in files.items():
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), 0o600, 0
                archive.addfile(member, io.BytesIO(data))
        stream.flush()
        os.fsync(stream.fileno())
    with tarfile.open(partial, 'r:gz') as archive:
        require(archive.getnames() == list(files), 'archive membership mismatch')
        for member in archive.getmembers():
            require(member.isfile() and archive.extractfile(member).read() == files[member.name],
                    'archive content mismatch')
    final = attempt / 'evidence.tar.gz'
    os.link(partial, final)
    partial.unlink()
    sha = digest(final)
    write_bytes(attempt / 'evidence.tar.gz.sha256', (sha + '  evidence.tar.gz\n').encode())
    return dict(status='PASS', path=str(final), sha256=sha, files=len(files), uncompressed_bytes=total,
                excludes='final report.txt and summary.json describe packaging after archive verification')


def report_text(summary):
    lines = ['Installed-application check: ' + summary['status'],
             'Selected application: ' + summary['application'], 'Bundled checker references: ' + summary['source'],
             'Codex-side export provenance: 280fb4a8dc11efa35c190c27ebb147e5a2db689b; no Pi Git verification',
             'Support: ' + summary['support'], 'Wall-clock synchronization: UNCONFIRMED',
             'Elapsed seconds (monotonic): %.3f' % summary['duration_seconds']]
    for name, value in summary['phases'].items():
        lines.append('%s: %s; child exit=%s; %s' %
                     (name, value['status'], value.get('child_exit', 'NOT RUN'), value.get('error', '')))
    lines += ['Primary: ' + json.dumps(summary['primary'], sort_keys=True),
              'Cleanup: ' + json.dumps(summary['cleanup'], sort_keys=True),
              'Capture errors: ' + json.dumps(summary['capture_errors'], sort_keys=True),
              'Packaging: ' + json.dumps(summary['packaging'], sort_keys=True)]
    if summary.get('verified_checker') is not None:
        c = summary['verified_checker']
        lines.append('Verified checker: %s distributions; %s origins; %s protobuf cases; resource %s' %
                     (c['distributions'], len(c['origins']), c['protobuf_cases'], c['canonical_resource_sha256']))
    lines += ['Only selected installed imports/resources/protobuf are checked; no owner is constructed.',
              'Scientific libraries and pymavlink are not imported by this checker.',
              'Navigation, physical state and hardware are NOT QUALIFIED. No manager or service is launched.',
              'Python API/audit restrictions trust bound CPython/stdlib native internals; not syscall isolation.',
              'Bound importer cache absence is recorded separately; it grants no cache-byte access.',
              'A failed/incomplete attempt must not be bypassed by reinstalling, chmod, hook removal or unguarded checks.',
              'Attach this report.txt and the verified evidence.tar.gz when packaging passed.',
              'Complete recording requires completion.json matching report/summary and launcher exit 0 for PASS.',
              'No claim of complete capture applies to SIGKILL, power loss or failed writes.']
    return '\n'.join(lines) + '\n'


def finalize_records(attempt, summary, interrupts=None):
    recorded_signals = len(summary.get('signals', []))
    def observed_interrupt():
        if interrupts is not None and len(interrupts.received) > recorded_signals:
            summary['signals'] = list(interrupts.received)
            summary['verified_checker'] = None
            if summary['primary'] is None:
                summary['primary'] = dict(phase='finalization', type='RunInterrupted', message='operator interruption')
            raise RunInterrupted('operator interruption during final recording')
    try:
        observed_interrupt()
        report = report_text(summary).encode()
        write_bytes(attempt / 'report.pending', report)
        observed_interrupt()
        summary['recording'] = dict(status='PASS', report_sha256=hashlib.sha256(report).hexdigest())
        write_json(attempt / 'summary.pending', summary)
        observed_interrupt()
        os.link(attempt / 'summary.pending', attempt / 'summary.json')
        os.link(attempt / 'report.pending', attempt / 'report.txt')
        observed_interrupt()
        write_json(attempt / 'completion.json', dict(report_sha256=digest(attempt / 'report.txt'),
                    summary_sha256=digest(attempt / 'summary.json'), status=summary['status']))
        observed_interrupt()
        return True
    except BaseException as error:
        summary['status'] = 'FAIL'
        summary['recording'] = dict(status='FAIL', error=error_text(error), type=type(error).__name__)
        # These are only this fresh attempt's provisional final records, never phase logs.
        try:
            if (attempt / 'completion.json').exists():
                os.link(attempt / 'completion.json', attempt / 'completion.incomplete')
                (attempt / 'completion.json').unlink()
            write_json(attempt / 'recording-failure.json', summary['recording'])
            write_json(attempt / 'summary.failed', summary)
            os.replace(attempt / 'summary.failed', attempt / 'summary.json')
            write_bytes(attempt / 'report.failed', report_text(summary).encode())
            os.replace(attempt / 'report.failed', attempt / 'report.txt')
        except BaseException:
            pass
        print('FAILED to finish report: ' + error_text(error), file=sys.stderr, flush=True)
        return False


def run(args):
    started = time.monotonic()
    root = ordinary(TEST_ROOT)
    require(root.is_dir(), 'test root missing')
    attempt = Path(tempfile.mkdtemp(prefix='installed-check-run-', dir=root))
    app = root / 'satgs-app-manager'
    summary = dict(schema=1, status='FAIL', attempt=str(attempt), application=str(app),
                   source=str(HERE / 'reference'), support=str(HERE),
                   launcher_argv=list(sys.orig_argv), script_argv=list(sys.argv), environment=ENV,
                   wall_clock_synchronized='unconfirmed',
                   start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   phases={name: dict(status='NOT RUN') for name in PHASES},
                   primary=None, cleanup={}, capture_errors=[], packaging=dict(status='NOT RUN'), verified_checker=None)
    interrupts = Interrupts()
    handlers = {s: signal.signal(s, interrupts.handler) for s in (signal.SIGINT, signal.SIGTERM)}
    target = None
    active = 'inputs'

    def phase(name, action, arguments=None):
        nonlocal active
        active = name
        print(name + ': running', flush=True)
        where = attempt / ('phase-' + name)
        where.mkdir(mode=0o700)
        record = dict(status='FAIL', execution='in-process reviewed support API', os_exit=None,
                      api={'inputs': 'support/reference/provenance checks', 'binding': 'pi_target.bind_existing',
                           'admission': 'pi_target.guarded(admit)', 'check': 'pi_target.guarded(check)'}[name],
                      arguments={k: str(v) if isinstance(v, Path) else v for k, v in (arguments or {}).items()},
                      start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        summary['phases'][name] = record
        begin = time.monotonic()
        action_error = None
        try:
            with (where / 'stdout').open('xb') as out, (where / 'stderr').open('xb') as err:
                with contextlib.redirect_stdout(BoundedText(out)), contextlib.redirect_stderr(BoundedText(err)):
                    value = action()
            require(not interrupts.received, 'operator interruption observed')
            record['status'] = 'PASS'
            return value
        except BaseException as error:
            action_error = error
            record.update(error=error_text(error), exception_type=type(error).__name__)
            raise
        finally:
            record['duration_seconds'] = time.monotonic() - begin
            try:
                write_json(where / 'call.json', record)
            except BaseException as error:
                summary['capture_errors'].append(dict(phase=name, error=error_text(error), type=type(error).__name__))
                if action_error is None:
                    record.update(status='FAIL', error='phase record write failed', exception_type=type(error).__name__)
                    raise

    try:
        def inputs():
            nonlocal target
            require(args.accept_trusted_native, 'explicit --accept-trusted-native is required')
            require(dict(os.environ) == ENV, 'use run_pi_checks.sh for the fixed clean launch environment')
            package = verify_package()
            target = load_support(Path(summary['support']))
            source = verify_reference(target)
            log, exit_file = root / 'install-manager-attempt-1/output.log', root / 'install-manager-attempt-1/exit.txt'
            provenance = target.install_observation(log, digest(log), exit_file, digest(exit_file), app)
            require(set(provenance['reported_final']) == {'application', 'application_import_checks',
                    'installer', 'selection', 'status', 'target'}, 'unexpected installer observation fields')
            result = dict(package=package, source=source, support={n: identity(Path(summary['support']) / n)
                          for n in SUPPORT}, installer_log=identity(log), installer_exit=identity(exit_file))
            write_json(attempt / 'input-identities.json', result)
            return log, exit_file
        log, exit_file = phase('inputs', inputs, dict(source=summary['source'], support=summary['support']))
        bind_args = SimpleNamespace(application=app, source=Path(summary['source']),
                install_log=log, install_log_sha=digest(log), install_exit=exit_file,
                install_exit_sha=digest(exit_file), output=attempt / 'binding.json')

        def bind():
            binding = target.bind_existing(bind_args)
            target.write(bind_args.output, binding)
            require(load_json(bind_args.output) == binding, 'retained binding mismatch')
            summary['target_facts'] = binding['facts']['target']
            return binding
        binding = phase('binding', bind, vars(bind_args))
        binding_sha = digest(bind_args.output)
        for name, mode in (('admission', 'admit'), ('check', 'check')):
            command_args = SimpleNamespace(command=mode, binding=bind_args.output, binding_sha=binding_sha,
                    records=attempt / name, accept_trusted_native=True)
            if mode == 'check':
                command_args.admission = attempt / 'admission/admission.json'
                command_args.admission_sha = digest(command_args.admission)

            def guarded():
                result = target.guarded(command_args)
                require(digest(bind_args.output) == binding_sha, 'binding record changed')
                checked = validate_result(target, mode, command_args.records, binding, binding_sha, result)
                require(verify_package() == load_json(attempt / 'input-identities.json')['package'],
                        'launcher support changed during run')
                require(verify_reference(target) == load_json(attempt / 'input-identities.json')['source'],
                        'bundled references changed during run')
                summary['phases'][name]['child_exit'] = result['supervision']['exit']
                summary['cleanup'][name] = dict(quiescent=result['supervision']['quiescent'],
                                               errors=result['supervision']['cleanup_errors'])
                return checked
            checker = phase(name, guarded, vars(command_args))
        summary['verified_checker'] = checker
        summary['status'] = 'PASS'
    except BaseException as error:
        summary['primary'] = dict(phase=active, type=type(error).__name__, message=error_text(error))
    finally:
        interrupts.finalizing = True
        for name in ('admission', 'check'):
            path = attempt / name / 'result.json'
            if path.exists():
                try:
                    nested = load_json(path)
                    summary['phases'][name]['child_exit'] = nested.get('final_exit', nested.get('exit'))
                    summary['cleanup'][name] = dict(quiescent=nested.get('quiescent'),
                            errors=nested.get('cleanup_errors'), timeout=nested.get('timeout', False),
                            exception=nested.get('exception'), residual=nested.get('residual_descendants', False))
                    stderr = read(attempt / name / 'stderr', 1024 * 1024).decode('utf-8', 'replace')
                    if stderr:
                        summary['phases'][name]['child_stderr_tail'] = stderr[-2000:]
                        summary['phases'][name]['error'] = summary['phases'][name].get('error', '') + '; child stderr: ' + error_text(stderr[-1000:])
                except BaseException as error:
                    summary['cleanup'][name] = dict(record_error=error_text(error))
            elif summary['phases'][name]['status'] != 'NOT RUN':
                summary['cleanup'][name] = dict(status='UNKNOWN', reason='nested result missing')
        summary['signals'] = list(interrupts.received)
        if interrupts.received:
            summary['status'] = 'FAIL'
            summary['verified_checker'] = None
            if summary['primary'] is None:
                summary['primary'] = dict(phase=active, type='RunInterrupted', message='operator interruption')
        summary['duration_seconds'] = time.monotonic() - started
        summary['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            write_json(attempt / 'phase-summary.json', summary)
            summary['packaging'] = package_attempt(attempt)
        except BaseException as error:
            summary['packaging'] = dict(status='FAIL', error=error_text(error), type=type(error).__name__)
            summary['status'] = 'FAIL'
        try:
            summary['duration_seconds'] = time.monotonic() - started
            summary['signals'] = list(interrupts.received)
            if interrupts.received:
                summary['status'] = 'FAIL'
                summary['verified_checker'] = None
                if summary['primary'] is None:
                    summary['primary'] = dict(phase='finalization', type='RunInterrupted', message='operator interruption')
            finalize_records(attempt, summary, interrupts)
        except BaseException as error:
            summary['status'] = 'FAIL'
            print('FAILED to finish report: ' + error_text(error), file=sys.stderr, flush=True)
        for number, handler in handlers.items():
            signal.signal(number, handler)
    print(summary['status'] + ': ' + str(attempt / 'report.txt'), flush=True)
    if summary['packaging']['status'] == 'PASS':
        print('Evidence: ' + summary['packaging']['path'], flush=True)
    else:
        print('Evidence archive incomplete; retain attempt: ' + str(attempt), flush=True)
    return 0 if summary['status'] == 'PASS' else 1


def main(argv=None):
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode, 'use run_pi_checks.sh')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accept-trusted-native', action='store_true')
    return run(parser.parse_args(argv))


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as error:
        print('STOP before report allocation: ' + error_text(error), file=sys.stderr)
        raise SystemExit(1)
