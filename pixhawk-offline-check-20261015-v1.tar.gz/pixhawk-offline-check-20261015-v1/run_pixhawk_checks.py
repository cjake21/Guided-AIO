"""Record one protected offline Pixhawk handler attempt on the fixed Pi environment."""

import argparse
import contextlib
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import sys
import tempfile
import time


HERE = Path(os.path.abspath(__file__)).parent
TEST_ROOT = Path('/home/admin/satgs-pi-test')
APPLICATION = TEST_ROOT / 'satgs-app-manager'
ENV = dict(PATH='/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC',
           PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', STOMP_SKIP_HOSTNAME_SCAN='1',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
RECORDING_SHA256 = 'e9b2930d6b9aea75b91ff831685246231a614c9c0f2fd8b700fa643b1c48ff0f'
PHASES = ('inputs', 'binding', 'admission', 'check')
PACKAGE_FILES = frozenset({
    'run_pixhawk_checks.py', 'run_pixhawk_checks.sh', 'README.md', 'recording.py',
    'behavior_target.py', 'behavior_guard.py', 'ctypes_initialization.py',
    'pixhawk_cases.py', 'pi_target.py', 'pi_guard.py', 'expected-target.json',
    'export-provenance.json', 'reference/tools/check_installed.py',
    'reference/requirements/development-constraints.txt',
    'reference/config/station.example.json', 'reference/NOTICES.md',
})


def require(value, message):
    if not value:
        raise ValueError(message)


def load_recording():
    path = HERE / 'recording.py'
    for item in (path, *path.parents):
        require(not item.is_symlink(), 'symlinked recorder path')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(descriptor, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= 128 * 1024
                and not before.st_mode & 0o022, 'invalid recorder input')
        data = stream.read(128 * 1024 + 1)
        after = os.fstat(stream.fileno())
        fields = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mode,
                               item.st_mtime_ns, item.st_ctime_ns)
        require(len(data) == before.st_size and fields(before) == fields(after) == fields(path.lstat()),
                'recorder input changed')
    require(hashlib.sha256(data).hexdigest() == RECORDING_SHA256, 'exact recorder copy changed')
    spec = importlib.util.spec_from_loader('pixhawk_recording', loader=None, origin=str(path))
    module = importlib.util.module_from_spec(spec)
    module.__file__ = str(path)
    sys.modules[spec.name] = module
    exec(compile(data, str(path), 'exec', dont_inherit=True), module.__dict__)
    module.report_text = report_text
    return module


def verify_package(recording):
    manifest_path = HERE / 'SHA256SUMS'
    manifest_identity = recording.identity(manifest_path)
    found = {}
    for line in recording.read(manifest_path, 16384).decode('ascii').splitlines():
        parts = line.split('  ')
        require(len(parts) == 2, 'invalid support checksum line')
        checksum, name = parts
        require(name in PACKAGE_FILES and name not in found and len(checksum) == 64
                and all(character in '0123456789abcdef' for character in checksum),
                'unexpected support checksum entry')
        found[name] = recording.identity(HERE / name)
        require(found[name]['sha256'] == checksum, 'support checksum mismatch: ' + name)
    require(set(found) == PACKAGE_FILES, 'support checksum membership mismatch')
    expected_directories = {str(parent) for name in PACKAGE_FILES
                            for parent in Path(name).parents if str(parent) != '.'}
    actual_files = set()
    for path in HERE.rglob('*'):
        recording.ordinary(path)
        relative = str(path.relative_to(HERE))
        if path.is_dir():
            require(relative in expected_directories, 'unexpected support directory: ' + relative)
        else:
            require(stat.S_ISREG(path.lstat().st_mode), 'nonregular support member')
            actual_files.add(relative)
    require(actual_files == PACKAGE_FILES | {'SHA256SUMS'}, 'actual support membership mismatch')
    require(recording.identity(manifest_path) == manifest_identity, 'support manifest changed')
    require(found['recording.py']['sha256'] == RECORDING_SHA256, 'recorder checksum mismatch')
    return dict(files=found, manifest=manifest_identity)


def verify_bound_support(binding, package):
    require(binding['environment']['root'] == str(APPLICATION), 'bound application selection changed')
    support = binding['behavior']['support']
    require(set(support) == PACKAGE_FILES, 'bound support membership mismatch')
    for name, item in package['files'].items():
        require(support[name]['path'] == str(HERE / name)
                and support[name]['sha256'] == item['sha256']
                and support[name]['bytes'] == item['bytes'], 'support is not bound: ' + name)


def validate_phase(recording, target, mode, records, binding, binding_path,
                   binding_sha, returned, admission=None, admission_sha=None):
    path = records / ('admission.json' if mode == 'admit' else 'check.json')
    value = recording.load_json(path)
    require(value == returned, 'returned and retained phase results disagree')
    require(value['status'] == 'pass' and value['mode'] == mode
            and value['binding_sha256'] == binding_sha and value['binding_after'] == 'pass',
            'phase result or binding-after failed')
    supervision = recording.load_json(records / 'result.json')
    require(supervision == value['supervision'], 'nested supervision mismatch')
    require(supervision.get('status') == 'pass' and supervision.get('exit') == 0
            and supervision.get('final_exit') == 0 and supervision.get('quiescent') is True
            and supervision.get('cleanup_errors') == []
            and not any(supervision.get(key) for key in
                        ('timeout', 'output_limit', 'exception', 'residual_descendants')),
            'nested child exit or cleanup failed')
    initial = recording.load_json(records / 'attempt.json')
    for key, item in initial.items():
        if key not in ('status', 'cleanup_errors'):
            require(supervision.get(key) == item, 'nested command envelope changed: ' + key)
    require(supervision['environment'] == ENV and supervision['timeout_seconds'] == 60
            and supervision['stream_limit_bytes'] == 1024 * 1024, 'child execution controls changed')
    expected_command = [str(APPLICATION / 'bin/python'), '-I', '-B', '-S',
                        str(HERE / 'behavior_target.py'), '_child', '--mode', mode,
                        '--binding', str(binding_path), '--binding-sha', binding_sha]
    if mode == 'offline':
        expected_command += ['--admission', str(admission), '--admission-sha', admission_sha]
    require(supervision['command'] == expected_command and supervision['cwd'] == str(HERE),
            'unexpected child command or cwd')
    streams = {}
    for name in ('stdout', 'stderr'):
        data = recording.read(records / name, 1024 * 1024)
        require(len(data) == supervision[name + '_bytes']
                and hashlib.sha256(data).hexdigest() == supervision[name + '_sha256'],
                'child stream identity mismatch')
        streams[name] = data
    require(not streams['stderr'], 'successful child stderr is not empty')
    messages = [target.target.parse_json(line) for line in streams['stdout'].splitlines()]
    require(all(type(item) is dict for item in messages), 'invalid child output')
    require(not any(item.get('denial_overflow') for item in messages), 'child denial overflow')
    denials = [item['denied_effect'] for item in messages if set(item) == {'denied_effect'}]
    completions = [item['child_result'] for item in messages if set(item) == {'child_result'}]
    child = value['child']
    require(len(denials) == 44 and all(item['phase'] == 'negative' for item in denials)
            and completions == [child] and len(messages) == len(denials) + len(completions),
            'missing completion, unexpected output or runtime denial')
    require(sum(item['kind'] == 'live-api' for item in denials) == 40
            and sum(item['kind'] == 'audit-dispatch' for item in denials) == 4,
            'negative control classification mismatch')
    require(child['status'] == 'pass' and child['mode'] == mode
            and child['binding_sha256'] == binding_sha and child['negative_controls'] == 44
            and child['application_imports'] is True and child['native_application_loading'] is True,
            'child admission or import scope mismatch')
    selected_native = {str(APPLICATION / name)
                       for name in binding['behavior']['profile']['native_extensions']}
    require(len(selected_native) == 4 and set(child['selected_native']) == selected_native,
            'selected native extension set mismatch')
    observed_native = set()
    for item in child['origins'].values():
        relative = str(Path(item['path']).relative_to(APPLICATION))
        require(str(APPLICATION / relative) == item['path'] and '..' not in Path(relative).parts
                and binding['environment']['files'][relative]['sha256'] == item['sha256'],
                'loaded application origin is not bound')
        if item['path'].endswith('.so'):
            observed_native.add(item['path'])
    require(observed_native == selected_native, 'loaded native extension set mismatch')
    target.target.validate_cache_receipts(child['cache_absence'], target.cache_binding(binding))
    target.validate_child(child, binding, mode)
    target.validate_binding(binding)
    if mode == 'admit':
        require('behavior' not in child, 'admission unexpectedly ran handler cases')
        return None
    behavior = child['behavior']
    for key, expected in dict(status='PASS', scenario_count=16, passed=16, failed=0,
                              mavlink_write_attempts=0).items():
        require(type(behavior.get(key)) is type(expected) and behavior[key] == expected,
                'behavior result mismatch: ' + key)
    require(len(behavior['cases']) == 16 and all(item['status'] == 'PASS' for item in behavior['cases']),
            'behavior case membership or status mismatch')
    return behavior


def report_text(summary):
    lines = ['Pixhawk offline handler check: ' + summary['status'],
             'Selected application: ' + summary['application'],
             'Support: ' + summary['support'],
             'Attempt: ' + summary['attempt'],
             'Wall-clock synchronization: UNCONFIRMED',
             'Elapsed seconds (monotonic): %.3f' % summary['duration_seconds']]
    for name, value in summary['phases'].items():
        lines.append('%s: %s; child exit=%s; %s' %
                     (name, value['status'], value.get('child_exit', 'NOT RUN'), value.get('error', '')))
    for name in ('primary', 'cleanup', 'capture_errors', 'packaging'):
        lines.append(name.replace('_', ' ').capitalize() + ': ' + json.dumps(summary[name], sort_keys=True))
    behavior = summary.get('verified_behavior')
    if behavior is not None:
        lines.append('Verified offline scenarios: %s passed / %s; MAVLink write attempts: %s' %
                     (behavior['passed'], behavior['scenario_count'], behavior['mavlink_write_attempts']))
    lines += ['The offline check is designed to exercise installed manager handling, generated MAVLink/protobuf and strict callbacks with in-memory boundaries.',
              'Fixed parser dialect and complete frames only; no mavutil auto-negotiation or fragmented-stream qualification.',
              'No application manager/subscriber constructor, service, broker, device or live route is launched.',
              'Callback acceptance and scenario PASS do not establish sensor presence, source authentication, freshness or navigation validity.',
              'Host results do not qualify this target. This attempt reports its own bound target result only.',
              'Trusted native opt-in covers reviewed bound native imports, not syscall isolation or arbitrary FFI.',
              'The old installed checker is not rerun; bundled references remain binding/provenance inputs only.',
              'A future live test needs separate exact Cube interface approval; serial opening can use O_RDWR, termios, RTS/DTR and input flush.',
              'No TX is authorized here, and an intended no-TX live test would not remove those opening effects.',
              'Do not bypass failed controls by reinstalling, chmod, removing hooks or running unguarded checks.',
              'Attach report.txt and verified evidence.tar.gz when packaging passed.',
              'Complete recording requires completion.json matching report/summary and launcher exit 0 for PASS.',
              'No complete capture guarantee applies to SIGKILL, power loss or failed writes.']
    return '\n'.join(lines) + '\n'


def run(args, recording):
    started = time.monotonic()
    root = recording.ordinary(TEST_ROOT)
    require(root.is_dir(), 'existing test root missing')
    attempt = Path(tempfile.mkdtemp(prefix='pixhawk-handler-run-', dir=root))
    summary = dict(schema=1, status='FAIL', attempt=str(attempt), application=str(APPLICATION),
                   source=str(HERE / 'reference'), support=str(HERE),
                   launcher_argv=list(sys.orig_argv), script_argv=list(sys.argv), environment=ENV,
                   wall_clock_synchronized='unconfirmed',
                   start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   phases={name: dict(status='NOT RUN') for name in PHASES},
                   primary=None, cleanup={}, capture_errors=[], packaging=dict(status='NOT RUN'),
                   verified_behavior=None, verified_checker=None)
    interrupts = recording.Interrupts()
    handlers = {number: signal.signal(number, interrupts.handler)
                for number in (signal.SIGINT, signal.SIGTERM)}
    target = None
    package = None
    active = 'inputs'

    def phase(name, action, arguments=None):
        nonlocal active
        active = name
        print(name + ': running', flush=True)
        where = attempt / ('phase-' + name)
        where.mkdir(mode=0o700)
        record = dict(status='FAIL', execution='in-process reviewed support API', os_exit=None,
                      api={'inputs': 'exact support manifest and file membership',
                           'binding': 'behavior_target.prepare_binding',
                           'admission': 'behavior_target.run_phase(admit)',
                           'check': 'behavior_target.run_phase(offline)'}[name],
                      arguments={key: str(value) if isinstance(value, Path) else value
                                 for key, value in (arguments or {}).items()},
                      start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        summary['phases'][name] = record
        begin = time.monotonic()
        action_error = None
        try:
            with (where / 'stdout').open('xb') as out, (where / 'stderr').open('xb') as err:
                with contextlib.redirect_stdout(recording.BoundedText(out)), \
                     contextlib.redirect_stderr(recording.BoundedText(err)):
                    value = action()
            require(not interrupts.received, 'operator interruption observed')
            record['status'] = 'PASS'
            return value
        except BaseException as error:
            action_error = error
            record.update(error=recording.error_text(error), exception_type=type(error).__name__)
            raise
        finally:
            record['duration_seconds'] = time.monotonic() - begin
            try:
                recording.write_json(where / 'call.json', record)
            except BaseException as error:
                summary['capture_errors'].append(dict(phase=name, error=recording.error_text(error),
                                                       type=type(error).__name__))
                if action_error is None:
                    record.update(status='FAIL', error='phase record write failed',
                                  exception_type=type(error).__name__)
                    raise

    try:
        def inputs():
            nonlocal target, package
            require(args.accept_trusted_native, 'explicit --accept-trusted-native is required')
            require(dict(os.environ) == ENV, 'use run_pixhawk_checks.sh for the fixed clean environment')
            package = verify_package(recording)
            recording.write_json(attempt / 'input-identities.json', package)
            target = recording.module_at(HERE / 'behavior_target.py', 'pixhawk_behavior_target',
                                         package['files']['behavior_target.py']['sha256'])
            require(set(target.INPUTS) == PACKAGE_FILES, 'target helper input membership differs')

        phase('inputs', inputs, dict(support=HERE))

        def bind():
            result = target.prepare_binding(attempt)
            require(type(result) is dict and set(result) == {'binding', 'binding_sha'},
                    'unexpected binding API result')
            binding_path = recording.ordinary(result['binding'])
            require(binding_path == attempt / 'binding.json', 'binding output escaped attempt')
            require(recording.digest(binding_path) == result['binding_sha'], 'retained binding hash mismatch')
            binding = recording.load_json(binding_path)
            verify_bound_support(binding, package)
            target.validate_binding(binding)
            require(verify_package(recording) == package, 'support changed during binding')
            summary['target_facts'] = binding['facts']['target']
            return binding, binding_path, result['binding_sha']

        binding, binding_path, binding_sha = phase('binding', bind, dict(application=APPLICATION))
        for phase_name, mode in (('admission', 'admit'), ('check', 'offline')):
            records = attempt / phase_name
            admission = attempt / 'admission/admission.json' if mode == 'offline' else None
            admission_sha = recording.digest(admission) if admission is not None else None

            def guarded():
                target.validate_binding(binding)
                result = target.run_phase(mode, binding_path, binding_sha, records,
                                          admission=admission, admission_sha=admission_sha)
                require(recording.digest(binding_path) == binding_sha, 'binding record changed')
                checked = validate_phase(recording, target, mode, records, binding, binding_path,
                                         binding_sha, result, admission, admission_sha)
                require(verify_package(recording) == package, 'support changed during guarded phase')
                verify_bound_support(binding, package)
                summary['phases'][phase_name]['child_exit'] = result['supervision']['final_exit']
                summary['cleanup'][phase_name] = dict(quiescent=result['supervision']['quiescent'],
                                                      errors=result['supervision']['cleanup_errors'])
                return checked

            behavior = phase(phase_name, guarded, dict(mode=mode, binding=binding_path,
                             binding_sha=binding_sha, records=records, admission=admission,
                             admission_sha=admission_sha))
        summary['verified_behavior'] = behavior
        summary['status'] = 'PASS'
    except BaseException as error:
        summary['primary'] = dict(phase=active, type=type(error).__name__, message=recording.error_text(error))
    finally:
        interrupts.finalizing = True
        for name in ('admission', 'check'):
            path = attempt / name / 'result.json'
            if path.exists():
                try:
                    nested = recording.load_json(path)
                    summary['phases'][name]['child_exit'] = nested.get('final_exit', nested.get('exit'))
                    summary['cleanup'][name] = dict(quiescent=nested.get('quiescent'),
                            errors=nested.get('cleanup_errors'), timeout=nested.get('timeout', False),
                            exception=nested.get('exception'), residual=nested.get('residual_descendants', False))
                    stderr = recording.read(attempt / name / 'stderr', 1024 * 1024).decode('utf-8', 'replace')
                    if stderr:
                        summary['phases'][name]['child_stderr_tail'] = stderr[-2000:]
                        summary['phases'][name]['error'] = summary['phases'][name].get('error', '') + \
                            '; child stderr: ' + recording.error_text(stderr[-1000:])
                except BaseException as error:
                    summary['cleanup'][name] = dict(record_error=recording.error_text(error))
            elif summary['phases'][name]['status'] != 'NOT RUN':
                summary['cleanup'][name] = dict(status='UNKNOWN', reason='nested result missing')
        summary['signals'] = list(interrupts.received)
        if interrupts.received:
            summary['status'] = 'FAIL'
            summary['verified_behavior'] = None
            if summary['primary'] is None:
                summary['primary'] = dict(phase=active, type='RunInterrupted', message='operator interruption')
        summary['duration_seconds'] = time.monotonic() - started
        summary['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            recording.write_json(attempt / 'phase-summary.json', summary)
            summary['packaging'] = recording.package_attempt(attempt)
        except BaseException as error:
            summary['packaging'] = dict(status='FAIL', error=recording.error_text(error), type=type(error).__name__)
            summary['status'] = 'FAIL'
        try:
            summary['duration_seconds'] = time.monotonic() - started
            summary['signals'] = list(interrupts.received)
            if interrupts.received:
                summary['status'] = 'FAIL'
                summary['verified_behavior'] = None
                if summary['primary'] is None:
                    summary['primary'] = dict(phase='finalization', type='RunInterrupted', message='operator interruption')
            recording.finalize_records(attempt, summary, interrupts)
        except BaseException as error:
            summary['status'] = 'FAIL'
            print('FAILED to finish report: ' + recording.error_text(error), file=sys.stderr, flush=True)
        for number, handler in handlers.items():
            signal.signal(number, handler)
    print(summary['status'] + ': ' + str(attempt / 'report.txt'), flush=True)
    if summary['packaging']['status'] == 'PASS':
        print('Evidence: ' + summary['packaging']['path'], flush=True)
    else:
        print('Evidence archive incomplete; retain attempt: ' + str(attempt), flush=True)
    return 0 if summary['status'] == 'PASS' else 1


def main(argv=None):
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
            'use run_pixhawk_checks.sh')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accept-trusted-native', action='store_true')
    return run(parser.parse_args(argv), load_recording())


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as error:
        print('STOP before report allocation: ' + str(error)[:2000], file=sys.stderr)
        raise SystemExit(1)
