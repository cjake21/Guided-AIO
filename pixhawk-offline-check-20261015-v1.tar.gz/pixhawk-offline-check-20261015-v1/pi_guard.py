"""Read-only Python effect controls for the fixed installed checker, not a sandbox."""

import errno
import fcntl
import importlib._bootstrap as bootstrap
import importlib._bootstrap_external as external
import io
import json
import os
from pathlib import Path
import posix
import socket
import stat
import subprocess
import sys
import threading
import types


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


class CheckGuard:
    def __init__(self, files, directories, native):
        self.files = frozenset(files)
        self.directories = frozenset(directories)
        self.native = frozenset(native)
        self.phase = "negative"
        self.denials = []
        self.overflow = False
        self.probe_kind = "live-api"
        self.context = threading.local()
        self.real_open = os.open
        self.blocked = []
        self.real_lstat = os.lstat
        self.loader_type = external.SourceFileLoader
        self.importer_functions = (
            external.FileLoader.get_data, external.SourceLoader.get_code,
            external._LoaderBasics.exec_module, bootstrap._load_unlocked,
        )
        self.importer_codes = tuple(function.__code__ for function in self.importer_functions)
        self.cache_function = external.cache_from_source
        self.open_code = external._io.open_code
        self.cache_sources = {}
        self.cache_observations = {}
        for source in sorted(self.files):
            if not source.endswith('.py'):
                continue
            chain = self.directory_identity(str(Path(source).parent))
            info = self.real_lstat(source)
            if chain is None or not stat.S_ISREG(info.st_mode):
                continue
            cache = self.cache_function(source)
            if cache not in self.files:
                cache_chain = self.directory_identity(str(Path(cache).parent), missing=True)
                if cache_chain is not None:
                    self.cache_sources[cache] = (source, self.file_identity(info), chain, cache_chain)

    @staticmethod
    def file_identity(info):
        return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
                info.st_mtime_ns, info.st_ctime_ns)

    def directory_identity(self, path, missing=False):
        result = []
        for item in reversed((Path(path), *Path(path).parents)):
            try:
                info = self.real_lstat(item)
            except FileNotFoundError:
                if missing:
                    result.append((str(item), None))
                    return tuple(result)
                return None
            except OSError:
                return None
            if not stat.S_ISDIR(info.st_mode):
                return None
            result.append((str(item), (info.st_dev, info.st_ino, info.st_mode)))
        return tuple(result)

    def absent_import_cache(self, path, frame):
        row = self.cache_sources.get(path)
        if row is None or not sys.dont_write_bytecode:
            return False
        current = (external.FileLoader.get_data, external.SourceLoader.get_code,
                   external._LoaderBasics.exec_module, bootstrap._load_unlocked)
        if (external.SourceFileLoader is not self.loader_type
                or external.cache_from_source is not self.cache_function
                or external._io.open_code is not self.open_code):
            return False
        frames = []
        for number, function in enumerate(self.importer_functions):
            if (current[number] is not function or function.__code__ is not self.importer_codes[number]
                    or frame is None or frame.f_code is not self.importer_codes[number]
                    or frame.f_globals is not function.__globals__):
                return False
            frames.append(frame)
            frame = frame.f_back
        source, identity, source_chain, cache_chain = row
        data, code, execution, loading = (item.f_locals for item in frames)
        loader = data.get('self')
        module = execution.get('module')
        if type(loader) is not self.loader_type or type(module) is not types.ModuleType:
            return False
        spec = module.__dict__.get('__spec__')
        if (type(spec) is not bootstrap.ModuleSpec or loading.get('spec') is not spec
                or loading.get('module') is not module or spec.loader is not loader
                or spec.origin != source or spec._initializing is not True
                or module.__dict__.get('__loader__') is not loader
                or sys.modules.get(spec.name) is not module
                or loader.__dict__ != dict(name=spec.name, path=source)
                or data.get('path') != path or code.get('self') is not loader
                or execution.get('self') is not loader or code.get('fullname') != spec.name
                or code.get('source_path') != source or code.get('bytecode_path') != path):
            return False
        try:
            if (self.directory_identity(str(Path(source).parent)) != source_chain
                    or self.file_identity(self.real_lstat(source)) != identity
                    or self.directory_identity(str(Path(path).parent), missing=True) != cache_chain):
                return False
        except OSError:
            return False
        try:
            self.real_lstat(path)
        except FileNotFoundError:
            count = self.cache_observations.get(path, 0)
            if count >= 2**31 - 1:
                return False
            self.cache_observations[path] = count + 1
            return True
        except OSError:
            return False
        return False

    def cache_receipts(self):
        observations = [dict(source=self.cache_sources[path][0], cache=path, attempts=count)
                        for path, count in sorted(self.cache_observations.items())]
        return dict(schema='importer-cache-absence.v1', policy='ENOENT without cache-byte access',
                    sources=len(self.cache_sources), observations=observations,
                    total=sum(row['attempts'] for row in observations))

    def path(self, value, directory_fd=None):
        if isinstance(value, int):
            value = os.readlink("/proc/self/fd/" + str(value))
        path = Path(os.fsdecode(value))
        if not path.is_absolute() and directory_fd not in (None, -1):
            path = Path(os.readlink("/proc/self/fd/" + str(directory_fd))) / path
        return str(path.resolve())

    def deny(self, event):
        record = {"event": event, "phase": self.phase,
                  "kind": self.probe_kind if self.phase == "negative" else "runtime"}
        if len(self.denials) < 128:
            self.denials.append(record)
            print(json.dumps({"denied_effect": record}), flush=True)
        else:
            self.overflow = True
            print('{"denial_overflow": true}', flush=True)
        raise PermissionError("fixed installed-check effect policy")

    def audit(self, event, args):
        if event.startswith(("socket.", "sqlite3.", "ctypes.")) or event in (
            "subprocess.Popen", "os.system", "os.exec", "os.posix_spawn", "os.fork",
            "os.forkpty", "pty.spawn", "os.chdir", "os.mkdir", "os.remove", "os.rmdir",
            "os.rename", "os.link", "os.symlink", "os.chmod", "os.chown", "os.utime",
            "os.truncate", "os.setxattr", "os.removexattr", "os.mknod", "os.mkfifo",
            "os.kill", "os.killpg",
        ):
            self.deny(event)
        if event == "open":
            pending = getattr(self.context, "opening", None)
            directory_fd = pending[1] if pending and pending[0] == args[0] else None
            writing = args[2] & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
            raw = args[0]
            if isinstance(raw, (str, bytes)) and os.fsdecode(raw).endswith('.pyc') and raw not in self.files:
                if (type(raw) is str and directory_fd is None and not writing and args[1] == 'r'
                        and args[2] == os.O_CLOEXEC
                        and self.absent_import_cache(raw, sys._getframe(1))):
                    # The audited open never resumes, including after a concurrent file appearance.
                    raise FileNotFoundError(errno.ENOENT, 'bound importer cache absent', raw)
                self.deny('open')
            path = self.path(raw, directory_fd)
            if writing or path not in self.files | self.directories:
                self.deny("open")
        if event in ("os.listdir", "os.scandir") and self.path(args[0]) not in self.directories:
            self.deny(event)
        if event == "import" and len(args) > 1 and args[1] is not None:
            path = self.path(args[1])
            if path not in self.files or (path.endswith(".so") and path not in self.native):
                self.deny("import")

    def tracked_open(self, path, flags, mode=0o777, *, dir_fd=None):
        prior = getattr(self.context, "opening", None)
        self.context.opening = (path, dir_fd)
        try:
            return self.real_open(path, flags, mode, dir_fd=dir_fd)
        finally:
            self.context.opening = prior

    def activate(self):
        os.open = posix.open = self.tracked_open
        for module, names in (
            (os, ("mknod", "mkfifo", "openpty", "forkpty", "fork", "system", "posix_spawn",
                  "posix_spawnp", "execv", "execve", "chown", "fchown", "lchown", "setxattr",
                  "removexattr", "setsid", "setpgid", "kill", "killpg", "ftruncate", "fchmod")),
            (fcntl, ("ioctl", "flock", "lockf")),
        ):
            for name in names:
                if not hasattr(module, name):
                    continue
                def blocked(*args, _name=module.__name__ + "." + name, **kwargs):
                    self.deny("api." + _name)
                setattr(module, name, blocked)
                if module is os and hasattr(posix, name):
                    setattr(posix, name, blocked)
                self.blocked.append(blocked)
        sys.addaudithook(self.audit)

    def probes(self):
        forbidden = "/__satgs_guard_must_not_create__"
        probes = [
            lambda: socket.socket(),
            lambda: socket.getaddrinfo(b"example.invalid", 80),
            lambda: subprocess.run(["/usr/bin/true"], check=True),
            lambda: open("/dev/ttyACM0", "rb"),
            lambda: io.open("/dev/ttyACM0", "rb"),
            lambda: Path("/dev/ttyACM0").open("rb"),
            lambda: os.open("/dev/ttyACM0", os.O_RDONLY),
            lambda: open("/etc/passwd", "rb"),
            lambda: open(forbidden, "xb"),
            lambda: os.truncate(forbidden, 0),
            lambda: os.rename(forbidden, forbidden + "2"),
            lambda: os.symlink("/etc", forbidden),
            lambda: os.listdir("/etc"),
        ] + self.blocked
        dispatch = [lambda: sys.audit("ctypes.dlopen", None),
                    lambda: sys.audit("import", "probe", "/tmp/not-loaded.so", None, None, None),
                    lambda: sys.audit("sqlite3.connect", ":memory:")]
        for number, probe in enumerate(probes + dispatch):
            self.probe_kind = "live-api" if number < len(probes) else "audit-dispatch"
            before = len(self.denials)
            try:
                probe()
            except PermissionError:
                require(len(self.denials) == before + 1, "probe missing its denial")
            else:
                raise RuntimeError("effect probe admitted")
        directory = sorted(self.directories)[0]
        self.probe_kind = "live-api"
        descriptor = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
        try:
            before = len(self.denials)
            try:
                os.open("../../__satgs_guard_must_not_create__", os.O_CREAT | os.O_WRONLY,
                        dir_fd=descriptor)
            except PermissionError:
                require(len(self.denials) == before + 1, "dir_fd probe missing its denial")
            else:
                raise RuntimeError("dir_fd write admitted")
        finally:
            os.close(descriptor)
        self.phase = "runtime"
        return len(self.denials)

    def finish(self):
        require(not self.overflow and all(item["phase"] == "negative" for item in self.denials),
                "runtime effect denied, including a caught exception")
        return len(self.denials)
