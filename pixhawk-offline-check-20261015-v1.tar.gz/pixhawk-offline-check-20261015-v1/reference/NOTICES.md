# Component notices and internal-delivery scope

Original component ownership remains intact. This integration snapshot does not assign a blanket license, change Government rights, or grant external redistribution rights. Internal preparation was approved by Cole; exact content and any outstanding source-owner requirement must be resolved at the separate first-push gate.

Preserve `components/meteor-api/LICENSE`, all Meteor source/package headers and `files_to_ignore_datarights.txt`. The license/header text contains MITRE copyright and U.S. Government noncommercial computer software rights notices. The tooling exclusion list is not a redistribution grant.

Preserve the Government/MITRE notice in `components/serialptu/serialptu/ptu.py`. No standalone license was present in the accepted ground_station, sat_tracker, pixhawk or serialptu inventories; this delivery does not invent one. Retained author and project metadata identify original maintainers, not approval by them of this integration snapshot.

Preserve `components/stomp.py/LICENSE` and its Apache-2.0/upstream references. Legitimate upstream project links in retained documentation are not delivery mirrors or fallbacks. No third-party wheel, environment or native binary is transferred in this source snapshot. Later artifact acquisition and installation must retain the selected artifacts' own notices and provenance.
