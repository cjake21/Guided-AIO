"""Check selected installed package origins and resources without constructing owners."""
import argparse
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manager', action='store_true')
    args = parser.parse_args(argv)
    require(sys.prefix != sys.base_prefix, 'a separate application environment is required')
    require(os.environ.get('STOMP_SKIP_HOSTNAME_SCAN') == '1', 'set hostname policy before interpreter startup')
    site = Path(sys.prefix) / 'lib' / ('python' + sys.version.split()[0].rsplit('.', 1)[0]) / 'site-packages'
    require(site.is_dir(), 'expected application site directory missing')
    origin = Path(__file__).resolve().parents[1]
    constraints = {}
    for line in (origin / 'requirements/development-constraints.txt').read_text().splitlines():
        name, version = line.split('==')
        constraints[name] = version
    manager_only = {'serialptu', 'pyserial', 'pymavlink', 'lxml', 'fastcrc'}
    expected = set(constraints) if args.manager else set(constraints) - manager_only
    canonical = lambda value: value.lower().replace('_', '-').replace('.', '-')
    distributions = list(importlib.metadata.distributions(path=[str(site)]))
    actual = {canonical(item.metadata['Name']): item for item in distributions}
    require(len(actual) == len(distributions) and set(actual) == expected, 'installed distribution set mismatch')
    require(all(item.version == constraints[name] and Path(item.locate_file('')).resolve() == site
                for name, item in actual.items()), 'installed version or origin mismatch')
    modules = (
        'satgs', 'satgs._package_layout', 'satgs.deployment', 'satgs.runtime_configuration',
        'meteor_api', 'meteor_api.messenger', 'stomp', 'ptu_control', 'ptu_control.pointing',
        'ptu_control.tracking', 'pixhawk', 'satgs.jobs_msg_pb2',
        'meteor_api.protobufs.Meteor_pb2', 'ptu_control.ptu_msg_pb2', 'pixhawk.pixhawk_pb2',
        'google.protobuf.timestamp_pb2',
    ) + (('serialptu', 'serialptu.proto_impl') if args.manager else ())
    imported = {name: importlib.import_module(name) for name in modules}
    origins = {}
    for name, module in imported.items():
        path = Path(module.__file__).resolve()
        require(site in path.parents and path.is_file(), 'module escaped installed environment')
        origins[name] = {'relative_path': str(path.relative_to(site)),
                         'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    layout = imported['satgs._package_layout']
    deployment = imported['satgs.deployment']
    require(layout.INSTALLED is True, 'source layout imported instead of installed layout')
    resource = site / 'satgs/data/deployment_profiles.json'
    require(deployment.DEFAULT_MANIFEST_PATH == resource, 'default manifest is not installed resource')
    resource_hash = hashlib.sha256(resource.read_bytes()).hexdigest()
    require(resource_hash == 'cbff15682b2f28ca4ffd0ec087729f316f92819b19a1da9d2f114c6d5f613666',
            'canonical manifest identity changed')
    deployment.load_manifest()
    cases = (
        (imported['satgs.jobs_msg_pb2'].JobRequest, {'sat_id': 1}, '0801'),
        (imported['meteor_api.protobufs.Meteor_pb2'].PdapParamsMsg, {'min_pulse_size': 1}, '1801'),
        (imported['ptu_control.ptu_msg_pb2'].PingCmd, {'ping': True}, '0801'),
        (imported['pixhawk.pixhawk_pb2'].PingCmd, {'ping': True}, '0801'),
        (imported['google.protobuf.timestamp_pb2'].Timestamp, {'seconds': 1}, '0801'),
    )
    for message_type, fields, encoded in cases:
        message = message_type(**fields)
        require(message.SerializeToString().hex() == encoded, 'protobuf literal wire mismatch')
        parsed = message_type()
        parsed.ParseFromString(bytes.fromhex(encoded))
        require(all(getattr(parsed, key) == value for key, value in fields.items()), 'protobuf parse mismatch')
    configuration = imported['satgs.runtime_configuration']
    example = json.loads((origin / 'config/station.example.json').read_bytes())
    try:
        configuration._station_settings(example, None, None)
    except configuration.RuntimeConfigurationError:
        pass
    else:
        raise RuntimeError('unconfigured example unexpectedly admitted')
    result = {'status': 'pass', 'scope': 'installed-package-resource-and-protobuf-check',
              'manager_packages': args.manager, 'distributions': len(actual), 'origins': origins,
              'protobuf_cases': len(cases), 'canonical_resource_sha256': resource_hash,
              'unconfigured_example_rejected': True, 'owner_constructed': False,
              'navigation_qualified': False, 'hardware_qualified': False}
    print(json.dumps(result, sort_keys=True))
    return result


if __name__ == '__main__':
    main()
