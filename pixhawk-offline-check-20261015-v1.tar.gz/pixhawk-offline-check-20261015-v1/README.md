# Offline Pixhawk handler check

This support package performs one protected offline attempt against the existing
`/home/admin/satgs-pi-test/satgs-app-manager` installation. It does not install,
repair or modify that environment, rerun the previous installed checker, open a
broker/device, start a manager/service or provide a live route.

Use only the reviewed complete package, with its final `SHA256SUMS`, on the
separately admitted target. Host validation is not Pi qualification. The fixed
target profile, application/stdlib fingerprints, four allowed native extensions
and their bound dependencies must match. Do not edit the profile or bypass a
failure to make a run proceed.

## One command

From the extracted support directory, with the existing test root and application
already present, run:

```sh
./run_pixhawk_checks.sh --accept-trusted-native
```

Do not activate a virtual environment or invoke the Python file directly. The shell
clears the environment and starts `/usr/bin/python3.11 -I -B -S`. Explicit native
opt-in is required. There is no app-path, serial-port, broker or live-mode option.
The native allowance is source/profile bound; Python API/audit restrictions are
not syscall isolation and do not authorize arbitrary FFI.

Normal imports include installed pymavlink 2.4.49, NumPy 2.2.6, PyYAML 6.0.3,
fastcrc 0.3.4 and pyserial 3.5. Four exact installed extensions and their trusted
native dependencies are in scope. The separate diagnostic environment's
pymavlink 2.4.50 is not used or changed. One genuine NumPy-triggered
`ctypes.PyDLL(None)` initialization is allowed; later library/symbol access is
denied. Optional pymavlink HOME extensions must remain absent. An existing file,
symlink or hook directory fails closed and must not be removed to bypass review.

The launcher creates a fresh `pixhawk-handler-run-*` directory under the existing
test root. It checks manifest hashes including itself, rejects symlinks and extra
or missing files, and binds all packaged support inputs. Four recorded phases run:

1. `inputs`: complete package identity and membership.
2. `binding`: unchanged target collection/existing-install binding plus the
   accepted target behavior profile and exact application/stdlib fingerprints.
3. `admission`: guarded imports and negative controls, without handler scenarios.
4. `check`: guarded offline handler scenarios using the same bound installation.

Both guarded child phases use 60-second supervision and bounded 1 MiB streams.
The `check` phase retains its result as `check/check.json` although its child mode
is `offline`. Admission results are hash-bound into that phase. The fixture uses
manager ID 17 only as a nonoperational test identity.

## What the cases establish

Sixteen scenarios exercise the actual installed manager loop, real generated
MAVLink encode/decode, dataclass/protobuf conversion and strict data callback.
Receive/publication remain in memory. Manager and subscriber constructors are
bypassed; no subscription, worker or logging file is created by the fixture.
Nine callback-negative inputs cover malformed/wrong-ID/type/size/time/nonfinite
data and wrong identifiers. Expected legacy warnings and exceptions are recorded;
unexpected failures remain failures even when product code catches them.

Each scenario keeps one fixed decoder and supplies complete frames. Actual wire
version is recorded separately from decoder dialect. MAVLink 1 missing-yaw behavior
is distinct from MAVLink 1 frames decoded by a MAVLink 2 parser with zero-padded
extension fields. The cases do not qualify mavutil auto-negotiation, fragmented
streams or serial/broker lifecycle.

These are software characterizations, not sensor or navigation approval. Mixed
source identities, ignored source times, arrival-order position replacement,
missing-component defaults, finite invalid/sentinel values, protobuf rounding
and whole-second aggregate timestamps remain existing behavior. Strict callback
acceptance does not establish component presence, valid fix/heading, freshness,
source authentication, calibrated geometry or physical readiness. No location
update or navigation policy is implemented here.

## Retained result

After an allocated attempt, success and failure paths automatically attempt to
write `report.txt`, `summary.json`, `completion.json` and verified `evidence.tar.gz`
with checksum files. The launcher prints their paths and exits zero only for PASS.
Keep the full attempt, including failed attempts. Attach the report and verified
archive; include the actual launcher exit status when handing results back.

The archive contains bounded phase/child records and raw streams. Final report
and summary are outside the archive because they describe archive verification;
`completion.json` binds their hashes. Missing completion, nonzero launcher exit,
packaging failure or incomplete cleanup means the attempt is not a completed PASS.
Failure before allocation, such as a missing test root or invalid recorder copy,
can only print a stop message. SIGKILL, power loss and failed writes cannot promise
complete recording. Do not manually reconstruct or overwrite a failed attempt.

`recording.py` is an exact copy of the previous approved reporting/supervision
launcher's source (SHA-256
`e9b2930d6b9aea75b91ff831685246231a614c9c0f2fd8b700fa643b1c48ff0f`).
The new launcher reuses its bounded capture, packaging and finalization helpers
with a Pixhawk-specific report function. It never calls that module's old checker
entry point. Bundled legacy references are unchanged provenance/binding inputs,
not an instruction to rerun the previous installed check.

## Future live work is excluded

A live test would need separate approval bound to the exact Cube USB interface
00 identity. No device scan, SLCAN route, serial command or live command is included.
No TX is authorized here. Even an intended no-TX serial test can open with
`O_RDWR`, change baud/termios and RTS/DTR, and automatically flush input before
reading. Those opening effects require review and cannot be described as harmless
receive-only isolation. Do not invent or activate a live route from this package.
