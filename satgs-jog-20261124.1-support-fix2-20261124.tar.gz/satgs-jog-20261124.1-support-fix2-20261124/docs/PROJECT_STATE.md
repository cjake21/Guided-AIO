# SATGS development state

Updated November 24, 2026. Primary workflow: `msel-project-engineer`, registered at
`/home/cjacobson/.agents/skills/msel-skill/msel-project-engineer/SKILL.md`.
Project routing is in the repository's `AGENTS.md`.

## November 24: launcher recovery after the first checker follow-up

New evidence at `/workspace/development-delivery/jog-6-fail/` has 17 phases PASS,
including all 42 native widget methods with zero skips/errors/denials. The sole
FAIL is source-workflow: our new binding test remapped its own `/home/admin`
scratch path, causing FileNotFoundError. That fixture is corrected to remap exact
historical app roots only. The conditional `checks && select` did not select jog6.
Cole then tried direct selection and received the same generic missing-file error.

A source-real reproducer with a missing current dispatcher and a deleted stale
selected jog5 fails in prepare's unconditional old-app validation. Explicit select
now prepares against the requested app while retaining decoded workspace/selection
until the existing select/idle lease. An exact published same-path jog6 dispatcher
is recognized and backed up before upgrade. Normal preparation/bootstrap semantics
stay unchanged, and missing-file errors report the path. No application, station,
database, runtime wheel or PTU-control change is required. All 100 focused source/launcher fixtures pass; actual guarded source-workflow
passes 23 tests with zero failures/errors/runtime denials and cleanup PASS. Source
validation passes. Independent probes reproduce and confirm recovery, published
same-path dispatcher upgrade, busy-station refusal and unchanged station. Final
review and support-fix2 packaging/publication are in progress.

## November 24: jog6 checks after disk cleanup

New evidence at `/workspace/development-delivery/jog-5-block/` is a jog6 run.
Its selected interpreter launched successfully, but acceptance binding raised
FileNotFoundError for `/home/admin/satgs-jog-20261118-app-manager/bin/python`.
All 18 phases were NOT RUN and overall status was BLOCKED. No new PTU or native
layout failure is recorded. Cole confirms deleting all previous jog directories
to recover disk space; older retained-installation claims below are dated history.

The correction makes missing historical launcher/metadata files optional while
retaining checks on files present and the current candidate. Full launcher alias
registration stays compatible; absent versions cannot be selected. Runtime wheels,
app version `0.0.1+jog.20261124.1`, selected alias `jog6` and station are unchanged.
All 97 focused source/launcher/checker fixtures pass, including actual binding
with every historical installation absent, retained-file checks and missing-current
module rejection. Installed jog6 launcher follow-up passes all four phases
(controls, static, installed, launcher), with four actual CLI calls, cleanup PASS
and unchanged inputs. Source validation passes. An initial manual test invocation
omitted required `-S`; the corrected no-site invocation and actual runner both pass.
Independent review reports no blocking findings; its additional fixture removes
all 11 historical apps, selects and launches jog6 CLI successfully with station
bytes/mode unchanged. The exact extracted follow-up also passes all four installed
launcher phases with cleanup PASS, four CLI calls and the 97-test fixture inventory.
The 2,500,266-byte support bundle reuses unchanged jog6 wheels and is published on
`artifacts/releases` at `b03e018350a8a0d9b531c51153e116e2f552d2b9`, a normal child
of the original jog6 artifact commit. Its new archive, checksum and versioned README
are the only added artifact files. The archive retains its preparation snapshot;
these notes record completed validation/publication. Local records are at
`/workspace/development/satgs-maintenance/jog6-checker-fix-20261124`.
The Pi procedure checks the already installed jog6 and skips setup.
See [the follow-up instructions](JOG6_CHECKER_UPDATE_20261124.md).

## November 24: jog5 physical-control failure and jog6 correction

Continue branch `feature/operator-handbook-ptu`, starting from published source
`b7b023e7719184e61e2b7a1d78762aef48b6075c`. Cole reports jog5 software checks
passed, but no physical movement and arrows turning gray. Supplied exports are
`/workspace/development-delivery/jog-5-fail/fail-jog5.json` and `fail-jog-5.json`.
They contain 16 unique current jog5 results: two Connect OK, two jog busy, seven
Stop OK, four Status OK and one Disconnect OK. The other 106 attempts are older
station history. Jog5 is operator-installed/selected, superseding the November 20
entry below; accepted jog4 and station data remain retained.

Connect completes in about 60 ms. Every current readback has status `008000`, which
original PTCR20 source identifies as Up soft limit. The local owner incorrectly
latched every axis flag as a whole-device fault, returned busy before either JOG
write, and the shared worker then disabled all arrows permanently. Repeated valid
polls or waiting cannot clear that latch. This is not a new Connect deadline.

Jog6 is published on `artifacts/releases` at
`c874e712d9d88736a7bc027b34d67ab27d98a3cc`, a normal child of retained jog5
`7b0f9bcffa6a51b2a3a471ed04c74d3cd34e4c9c`. It adds only the new archive,
checksum and versioned README. This normal descendant source/docs update uses
`feature/operator-handbook-ptu`. Publication receipt:
`/workspace/development/satgs-maintenance/jog6-release-20261124/publication-1/result.json`.
No Pi selection or hardware operation is performed by publication.

Jog6 `jog-20261124.1` pairs satgs, ptu_control and serialptu at
`0.0.1+jog.20261124.1`, alias `jog6`, separate target application
`/home/admin/satgs-jog-20261124-app-manager`. Its local manual path classifies
soft limits by direction. With `008000`, Up is disabled and Left/Right/Down remain
available after valid fresh stationary feedback. The authoritative owner checks
that direction again before writing. The existing PTU label displays the limit;
GUI and CLI share the same behavior. Numeric endpoint/no-go rules are unchanged,
and no soft-limit override, error reset, homing or firmware change is sent.

Reaching a soft limit ends a hold through actual Stop plus fresh stationary status
without poisoning the session. Motor/hard-limit faults, uncertain writes, missing
replies and failed Stop feedback remain latched. Independent review found a normal
Stop-ACK-only fault could previously be lost when following Status cleared it;
the corrected manual driver checks that ACK too. All prior interrupted-reply
correlation checks remain.

The identical captured-status reproducer against installed jog5 fails busy with
submission none and zero JOG packets; corrected canonical owners pass with one
fully written JOG packet. Focused modules ran 262 tests: 246 passed and 16 native
methods skipped without display. The actual native keyboard/repeat/focus/Stop
regression passes with the captured limit and 700x460 bounds. Independent review
passed 52 focused tests plus 10 final boundaries and its exact Stop-fault reproducer,
with no remaining blocking finding. Guide 6 and release/launcher 92 checks passed.

All six wheels built offline and normal separate 31-package host installation
passed. All 17 installed headless phases passed with cleanup PASS, zero runtime
denials and unchanged inputs. Native checks ran 42 methods: 41 passed, one exact
17 px Pi-font test NOT RUN on this host. No native failure, error or runtime denial;
native status remains BLOCKED for that font limitation. The updated 008000 keyboard
regression passed. No tests or result expectations were weakened.

Build/installed-candidate results are retained in
`/workspace/development/satgs-maintenance/jog6-release-20261124`, including
`captured-status-{red,green}.log`, `focused-owner-tests.log`, `REVIEW.md`,
`host-setup-1`, `host-check-1` and `host-check-2`. The normal package uses
`package-1/satgs-jog-20261124.1.tar.gz`, with its packaging result beside it.
Jog6 target and physical results remain pending Cole. No live station, device
or service was changed.
See [the focused limit update](PTU_LIMIT_UPDATE_20261124.md). Older sections below
are dated history and do not supersede this entry.

## November 20 source, application and delivery history

Continue `/workspace/development/SATGS-Modular-Suite`, branch
`feature/operator-handbook-ptu`, base `c1c335b44d8a59641deef878304b4a975eab443e`.
All inherited work and accepted installations remain intact. Published jog4
`jog-20261119.1` remains Cole's selected working application. The jog5
release is `jog-20261119.2`, with satgs, ptu_control and serialptu paired at
`0.0.1+jog.20261119.2`. It adds the interrupted-JOG/Stop correction and PTU layout
fix, retaining the existing installer, bootstrap and comprehensive task playbooks.
There is no workspace/database migration.

Cole resumed publication November 20 after Bitbucket access returned.
Jog5 is published on `artifacts/releases` at `7b0f9bcffa6a51b2a3a471ed04c74d3cd34e4c9c`, a normal child
of jog4 `ab49ea9ba5783a7d620444ce81162dc44f419b07`. Only its archive, checksum
and versioned README were added. Source and comprehensive docs are included in
this normal descendant update on `feature/operator-handbook-ptu`; the previously
advertised source tip `ed77ba159463bf9b8a9017ff30a1ecb023dcd61f` is an ancestor.
The final publication receipt is
`/workspace/development/satgs-maintenance/jog5-release-20261119/publication-1/result.json`.
The archive retains its reviewed November 19 prepublication snapshot; local/on-hold
notes inside it are historical. Jog5 is not selected on the Pi or hardware-tested.

Cole confirmed jog4 physical GUI arrow control on November 19. After the
software check returned FAIL, he explicitly selected jog4 and launched the GUI.
The selected application is `/home/admin/satgs-jog-20261119-app-manager`; station
remains `/home/admin/satgs/station`. He reports waiting about five seconds for
Connect before using arrow controls to move the physical PTU.

The new transfer is `/workspace/development-delivery/ptu-jog4`. Its Pi acceptance
has all 17 non-native phases PASS, cleanup PASS, and native-widgets FAIL solely
for three small-window bounds assertions in the taller-text-controls scenario.
The exact 17-pixel Pi-font test passed. No native errors or runtime denials were
reported. The failure must remain recorded; it does not contradict physical
motion. The previous jog3 unanswered-query records remain historical evidence.

The latest operation export contains three successful jog4 Connects, 21 successful
holds across all four directions and 21 successful Stop/readbacks. An earlier
jog4 Connect exhausted five seconds with ten unanswered probes. One later hold
has a separate Stop-feedback defect: cancellation interrupted a jog ACK after
byte `06`; the complete Stop packet was then written, but queued input triggered
stale-response before Stop feedback was read. Stop failed state blocked subsequent
Status/Disconnect; passive cleanup completed and a fresh Connect succeeded.
Do not relabel that operation a successful Stop or change its retained result.

Jog4 `jog-20261119.1` is now published on `artifacts/releases` at
`ab49ea9ba5783a7d620444ce81162dc44f419b07`, one descendant of retained jog3
`4542c0d27820e5a13a8a8bfdb64c51026c7657cc`. Cole explicitly approved this
publication. It adds only the archive, checksum and versioned README. An
independent Git fetch verified all three remote files against package-2.
Local receipt:
`/workspace/development/satgs-maintenance/jog4-release-20261119/publication-1/result.json`.
At jog4 publication the product source branch remained uncommitted WIP; that
artifact publication did not advance it. The November 20 source update includes
that preserved work. The archive's prepublication state note is historical.

Host checks and implementation review passed within their recorded scope.
Physical GUI movement is now operator-confirmed on jog4. This is not complete
physical qualification of numeric positioning, CLI motion or Stop behavior.
Both the small-window layout defect and the interrupted-jog/Stop feedback race
are corrected in the separately identified local jog5 candidate. Target checks
remain Cole's next hardware task after delivery; preserve his working jog4.
No device, broker, Pi, operational service or daily selection was changed by
Codex. All prior releases remain available.

See [the Connect update](CONNECT_UPDATE_20261119.md) for the actual exchange,
correction, review, validation and next operator actions. Earlier sections below
retain the development history and are superseded by this current entry where
they describe jog3 as uninstalled or records as unavailable.

## Local follow-up after Cole's jog4 test

The jog5 PTU layout correction compacts the duplicated setup text,
keeps the device-soft-limit versus numeric endpoint/no-go distinction visible,
and removes PTU-only vertical gaps. No control, callback or motion behavior is
changed. The existing regression now requires at least the measured Pi label
height 23 px, entry height 25 px and button height 46 px, retaining baseline+4.
The published jog4 GUI fails the stronger host regression; the corrected GUI
passes it across the existing sizes/scenarios. Tab/Escape and disabled-motion/
Enter invariants also pass. Exact Pi-font correction remains untested on this
host's fixed 13 px font. Logs:
`/tmp/satgs-jog4-layout-20261119-1/layout-measured-{red,green}/native-owner/child`.
Canonical source/test and existing acceptance mirrors agree.

The local jog5 candidate includes this correction and has not changed the Pi.
Keep the confirmed jog4 installation intact.

The Stop correction now treats a fully written manual JOG cancelled on release
as a pending exchange. It writes Stop immediately, completes and validates the
known interrupted reply, requires a separate Stop ACK, and requires fresh
stationary status before another hold. Known input queued beyond the old reply
is rejected rather than promoted to a Stop ACK. Real device faults, incomplete
or malformed replies, uncertain writes and existing invalidation remain blocked.
Saved results retain the interrupted reply separately from the Stop response.
GUI and CLI use this same local owner path; no controls are force-enabled.

Independent review found the extra queued-ACK correlation gap above; it was
corrected and its separate reproducer now rejects the unknown reply while
preserving unread bytes and latches. The reviewer then passed 91 focused driver
and shared-session tests with no remaining blocking findings.

The five affected driver/owner/shared-interface modules ran 250 tests: 234 passed,
16 native methods skipped without a display. One stale owner fixture initially
suppressed its old JOG ACK but expected Stop success; it now supplies separate
old/Stop replies. Negative missing-reply tests remain. Guide tests passed (6),
release/launcher tests passed (92), and source/shell/whitespace checks passed.

All six wheels built offline. The normal installer created a separate 31-package
host application, with the three changed owners at `0.0.1+jog.20261119.2`.
All 17 installed headless phases passed with cleanup PASS and unchanged inputs.
Installed native checks ran 42 tests: 41 passed, one exact 17 px font test was
NOTRUN on the fixed 13 px Tk9 host. There were no native failures, errors or
runtime denials; native acceptance remains BLOCKED for the unavailable font.
The stronger measured-height layout and native PTU controls passed. These are
host fixture results, not jog5 Pi or physical Stop qualification.

Records are under `/workspace/development/satgs-maintenance/jog5-release-20261119`:
`focused-owner-tests-2.log`, `REVIEW.md`, `host-setup-1`, `host-check-1` and
`host-check-2`. The local archive uses
`package-1/satgs-jog-20261119.2.tar.gz`, with its packaging result beside it.
The compiled handbook preview is `handbook/user-guide.html`. Publication resumed
November 20 as recorded above; source and artifact history remain separate.

## Implemented continuation

- Shared `Workspace.install_software` uses the saved catalog selection and an
  explicit offline wheel directory to install into a new environment. Setup's
  **Install software** button and CLI `install-software` call that operation.
- Installation resolves dependencies, checks them with pip, verifies selected
  distribution metadata, and retains separate started/result receipts and an
  environment log. Report/export includes the receipts and labels whether their
  configuration revision is current. It never changes station configuration,
  selects an application, starts services or imports equipment modules.
- Missing Full M-SEL owners, reuse in a new environment, occupied destinations,
  stale/busy stations and URL dependencies have explicit outcomes. Failed
  candidates remain available for diagnosis. `software_complete` is distinct
  from `profile_complete`; native, system, hardware and service requirements remain
  unresolved. Existing successful candidates and receipts remain intact.
- Fresh-account launcher preparation supports explicit `--bootstrap jog3` after
  acceptance without an older runtime or existing station. Repeated bootstrap
  preserves an existing selection. Normal GUI launch with no default station
  opens Home for explicit station creation. Optional `--initialize-station NEW_PATH`
  calls the installed product initializer and records that chosen station as the
  daily workspace; existing selections and occupied station paths are refused.
  Existing-account upgrades retain their
  selection and preserve the prior jog3 dispatcher.
- Client/manager requirement pins now match the existing jog3 constraints.
  Changed ground-station source/tests/docs were mirrored under the existing
  release-support reference directory.

## Validation actually run

Host software evidence only. No broker, hardware, new network dependency or Pi
qualification was used. Test wheels in behavioral tests are fixtures; the separate
installed smoke uses real owner/dependency wheels.

The affected product checks passed, 61 tests:

```sh
/workspace/development/satgs-maintenance/jog3-release-20261118-rLIZxN1o/host-setup-1/application/bin/python -I -B -c 'import sys,unittest; sys.path[:0]=["components/ground_station/src","components/ground_station/tests"]; unittest.main(module=None, argv=["unittest","test_operator_install","test_operator_core","test_operator_cli","test_operator_presentation","test_operator_gui.HeadlessOperatorPresenterTests"], verbosity=1)'
```

The affected launcher/support checks passed, 92 tests:

```sh
python3 -I -B -S -c 'import sys,unittest; sys.path.insert(0,"tests"); unittest.main(module=None, argv=["unittest","test_daily_launchers","test_launcher_checks","test_source_workflow"], verbosity=1)'
```

The source check, shell syntax check and `git diff --check` passed. Earlier attempts
exposed stale dispatcher-path assertions, one introduced test indentation error,
and a source-workflow invocation missing required `-S`. Those were corrected;
the tests were rerun with the results above. A focused second reader reviewed the
supplied installer logic, without filesystem/test access. Its three failure-path
findings were fixed. This is not an independent whole-repository acceptance.
The final guide-content check also passed, six tests:

```sh
/workspace/development/satgs-maintenance/jog3-release-20261118-rLIZxN1o/host-setup-1/application/bin/python -I -B -c 'import sys,unittest; sys.path[:0]=["components/ground_station/src","components/ground_station/tests"]; unittest.main(module=None, argv=["unittest","test_operator_guide_content"], verbosity=1)'
python3 -I -B -S tools/check_source.py
bash -n setup_update.sh launchers/setup_daily.sh
git diff --check
```

Real offline installation evidence:
`/tmp/satgs-profile-install-20261118-d3kbd5s1/summary.json`, with build log,
install result, installed CLI stdout/stderr and Full missing-input result beside
it. The changed operator wheel was built offline using the existing pinned build
interpreter. A new environment installed the Guided Arrow selection with the
retained 31-distribution host closure. Installed CLI status/help/docs passed;
installed Full M-SEL installation correctly rejected missing owners before
creating another candidate. Station bytes were preserved during installation.
The smoke uses CPython 3.11 on x86-64. New GUI rendering, ARM64/Pi behavior and
physical operation were not tested. Temporary evidence is not a release.

The final rebuild and fresh environment are recorded as `final_*` results in
that summary, with `final-build.log`, `final-install-result.json`, installed
status/help/docs/report output and `final-full-missing-inputs.json`. Real
fresh-account bootstrap also passed using the installed product initializer,
no old runtime and the generated daily CLI wrapper. It reopened the selected
station; repeated plain bootstrap preserved the selection. Its result is in
`fresh-bootstrap-status.json`. New install receipts use
`satgs-software-install.v1`; Report checks their station/attempt identities and
exports only the supported result fields.

## Next actions and product scope

1. Cole downloads jog5 and runs its normal setup/check/select sequence on the Pi,
   preserving the accepted jog4 application and station. Validate release/Stop,
   repeated holds, numeric movement and shared CLI operation under supervision.
2. Supply Full M-SEL's absent `satgs-post-processing`, `cyberpowerpdu`, `dsi`,
   `signal_hound_control`, `bbdevice` and transitive/platform wheels. Establish
   compatible native/vendor inputs, especially Signal Hound on ARM64. Actual Full
   software installation and the complete fresh-account demonstration remain open.
3. Cole performs the normal jog5 acceptance/select procedure after delivery and
   supervised PTU readback, arrows/keys, numeric target, release/Stop, CLI and saved
   session observations. Carry forward his confirmed jog4 physical GUI control;
   do not repeat baud discovery or historical bring-up.

Keep one modular Full M-SEL/Guided Arrow/Custom product with shared GUI/CLI owners.
The December 1, 2026 demonstration still requires fresh internal Bitbucket
installation, actual Full M-SEL software/configuration and physical PTU results.
The long-term telemetry, location, planning/tracking, services, RF/processing,
results and maintenance goal remains intact. Profile Save is not installation;
this software-install slice is not a claim that the complete demo has passed.

## Comprehensive handbook update

Cole requested install-to-operation examples for TLE-only, PTU-only and Full
M-SEL instances. The existing 13-chapter handbook now contains a task chooser,
the ten-owner distribution map, complete TLE/PTU Custom JSON changes files,
GUI and CLI install/configuration steps, a TLE catalog procedure, a Full walk-
through, every native tab's fields/actions, and output/receipt locations. Nearby
legacy comparison, component references and release-availability text were
reconciled. Application code was not changed for this documentation task.

The text distinguishes existing legacy TLE commands, published jog3 and the
unpublished installer/bootstrap work. It does not claim per-package GUI download,
native TLE editing, force-refresh-all or complete Full package/service delivery.
The active checkout has no SATGS Read the Docs hosting configuration; the update
uses the existing Markdown/offline HTML/text handbook path. Nothing was uploaded
or published to a documentation service or Bitbucket.

Preview: `/tmp/satgs-handbook-preview-20261118-yimr0ty0/guide/user-guide.html`.
The adjacent preview ZIP contains HTML/text/assets, Markdown sources and a
README identifying the development scope. Guide checks: six passed; all 47
shell blocks passed `bash -n`. Existing tests caught that the first tutorial CSV
must match the packaged historical fixture; the new example was aligned with
that real four-column fixture, preserving the assertion.

Scenario evidence: `/tmp/satgs-handbook-examples-20261118-pfv8x4rp/summary.json`.
Using explicitly supplied retained host wheels, actual TLE-only and PTU-only
installs passed and omitted the unwanted owners. Installed TLE console help,
native TLE-only planning and passive local PTU configuration passed. Mocked HTTP
at the request boundary exercised actual add/duplicate/delete, stale-versus-fresh
refresh and all-catalog pass-finder/run-sheet behavior. Manual TLE content passed
strict native parsing and historical planning without a fetch. The driver is
`/tmp/satgs_handbook_examples_check.py`; it creates disposable directories and
uses no live network or hardware. Host x86-64 evidence is not Pi/ARM64 evidence.

Three legacy code defects were reproduced and documented, not fixed in this
docs-only task: deleting the final row leaves only a `norad_id` header; a null
date reaches an incompatible string datetime path; replacing a refreshed row
drops `txids`. Keep complete headers, valid UTC dates and catalog/association
backups as described in the guide. Track focused owner fixes after the immediate
PTU/release work. Cole's planned November 19 jog3 target check remains unchanged.

## Component playbooks and separate suite gap inventory

Cole expanded the documentation request to cover the original ground_station,
serialptu, sat_tracker, Pixhawk and meteor-api Messenger owners, with use cases
as the entry point. The handbook chooser now links each task to package selection,
installation/configuration, actions and expected outputs. The core owner sections
and original-to-current task mapping were rewritten around those procedures.

TLE fetch/store, manual entry/replacement, deletion, age-based whole-catalog
refresh and native local planning remain concrete worked paths. Native GUI/CLI
PTU control uses the four-owner Custom selection and existing shared session.
Full M-SEL retains the complete ten-owner setup and every-tab walkthrough.
Advanced references add standalone serialptu installation with an executable
packet inspection example, tracking-request preparation and lifecycle ownership,
Pixhawk role installation/sensor fields/telemetry/CLI option reference, and the
existing Messenger package/settings/bounded API sequence. Messenger already
exists at `components/meteor-api/src/meteor_api/messenger.py`; no duplicate was
created.

Development inventories were moved out of the packaged operator chapters into
[SUITE_GAPS.md](SUITE_GAPS.md). It records missing Full artifacts/platform inputs,
download/service provisioning, TLE owner defects, live tracking/GPS integration,
component documentation and actual target acceptance work. Ordinary prerequisites,
returned-state interpretation and operational error handling remain in the guide.
The guide still states its version and the endpoint of each supported procedure.
The local gap file is excluded from the compiled guide and preview ZIP.

No application code, Git refs, installed selection, services, devices or Pi
state changed during this documentation update. No publication was performed.
All 13 existing handbook Markdown mirrors were synchronized.

Validation of the final text:

- Six existing handbook tests passed, including complete component coverage,
  command/widget spelling, deterministic compilation, links and historical TLE.
- All 51 shell blocks passed `bash -n`; three Python blocks parsed, and three
  JSON blocks parsed. The maintained source check and `git diff --check` passed.
- Real new standalone host environments installed serialptu, pixhawk[manager]
  and meteor_api from the retained compatible offline wheelhouse. Each passed
  `pip check`; none installed satgs/ptu_control. The installed serialptu example
  exactly matched its documented output. Pixhawk manager/subscriber help and
  installed Messenger API signature checks passed without starting their owners.
- Evidence: `/tmp/satgs-component-playbooks-20261118-zwe8451k/summary.json`.
  Temporary driver: `/tmp/satgs_playbook_verify.py`. These are host CPython 3.11
  x86-64 checks, with no network, broker, live GPS or hardware operation.
- The earlier installed TLE-only/PTU-only and mocked HTTP/catalog/planning results
  remain historical evidence for unchanged recipes; they were not rerun.
- A second reader reviewed supplied task scope and example contracts without
  filesystem access. Its clarity suggestions were applied; this is not an
  independent execution or full-suite review.

Updated preview:
`/tmp/satgs-playbook-preview-20261118-czflzy67/guide/user-guide.html`.
Download package:
`/tmp/satgs-playbook-preview-20261118-czflzy67/SATGS-Operator-Playbooks-Preview-20261118.zip`.
The ZIP contains the 13 Markdown chapters, images, offline HTML/text/CSS, preview
README and validation record; it has 23 members and excludes the local gap file.

Next implementation remains the new identified release/target installation and
complete Full inputs described above. Cole still operates the Pi for the planned
jog3 check. Full product and December 1 demonstration goals are unchanged.

## November 19 QPT130 Connect investigation: awaiting actual attempt records

Cole now reports jog3 selected and its changed PTU controls visible. Save local
QPT130 succeeds; Connect returns `deadline`, physical state `unobserved`, and
arrows remain disabled. This supersedes the preceding reported bench selection.
It is not target acceptance or a physical readback PASS.

Read the separate source-backed follow-up at
`/workspace/.codex-transfer/context/satgs-jog3-connect-followup-20261119-q6f9HkB2/NEXT_CHAT_INSTRUCTIONS.txt`.
It explicitly says the current failed Connect started/result records were not
supplied. Neither the follow-up folder nor the recent failure transfer folders
identified those records. Requested the matching existing JSON pair or its local
transfer path; no new hardware run or broad collection was requested.

Traced the live shared path through BenchSession, LocalBenchClient, shared bench
operations, selected-device acquisition and serialptu. Confirmed a source timing
regression candidate: local Connect caps cold verification/open/claim and its
single status query at the saved exchange budget, normally one second. Original
serialptu opened during construction and then allowed a separate five-second
connection window with repeated 0.5-second status attempts. Selected settings
and initial bytes match: `02 31 00 00 00 00 00 31 03`.

Hardware-free reproducer: `/tmp/satgs_connect_reproduce.py`, run with the retained
jog3 host CPython 3.11 application interpreter. It uses the real LocalBenchClient,
driver, encoder/parser and receipt generation, replacing only serial/device and
clock boundaries. Immediate feedback returned `ok`; a controlled 0.8-second open
plus 0.4-second response returned `deadline` after approximately 1.025 virtual
seconds, with a fully written nine-byte status request and no received bytes.
A lost first query also returned deadline with one write. This establishes the
source regression candidate, not the physical unit's actual failure mechanism.

Two independent read-only source readers confirmed timing/packet and limit-policy
facts. Original Connect does not set limits, reset motor faults or override soft
limits. Current axis-status latching occurs only after decoded feedback, so it
cannot by itself explain an unobserved deadline. The separate overbroad directional
soft-limit latch remains a follow-up, not an inferred cause of this attempt.

Do not implement caller retries around ordinary observe_bounded: timeout already
invalidates that owner. A justified establishment correction must distinguish
initial nonmoving probes from MOVE/JOG/STOP, retain partial/late replies and every
attempt, and preserve cancellation, ownership, fault and failed-Stop state. Shared
Connect receipt-count/category validation also needs coherent treatment if more
than one initial probe is introduced.

No product code, release identity, environment/selection, daily station, sealed
handoff or Git ref changed in this investigation. No device, broker, Pi or network
was accessed. No normal update was built or published. Next: inspect the actual
failed JSON exchanges/open outcome, write the concrete narrow change plan, then
implement, run focused affected checks, obtain review of that diff and prepare
the normal separately identified application update.
