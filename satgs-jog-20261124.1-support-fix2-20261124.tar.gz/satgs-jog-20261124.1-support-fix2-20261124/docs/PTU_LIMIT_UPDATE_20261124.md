# Jog5 limit-state failure and jog6 correction

Cole reports jog5 installed software checks passed but physical arrow control
failed. The two exports in `/workspace/development-delivery/jog-5-fail` contain
16 current jog5 results, distinct from 106 inherited older results. Both Connects
succeed in 60–62 ms and all seven requested Stops receive replies. Both jog holds
return `busy`, submission `none`, and no serial JOG exchange. Waiting one minute
cannot change the resulting shared failed-hold latch.

Every current readback reports `008000`: no pan flag, Up soft limit in the tilt
byte, no movement/execution flag. This meaning comes from the retained
`PTCR20._parse_status_bits` and `get_status_definitions` implementation. The local
owner treated every nonzero axis byte as a whole-unit fault. Its first rejected
jog then made the shared session disable every arrow.

The existing PTCR20 owner now classifies directional soft limits separately from
motor/hard-limit faults. With this status, only Up is blocked; Down and horizontal
jogs retain their existing device soft limits. Per-direction reasons travel with
validated observations into the shared session and existing GUI. The CLI uses the
same admission. Clearing the device flag restores that direction on fresh feedback.
No encoder, second controller, broker, limit override or reset command was added.
Numeric target envelope and no-go checks remain unchanged.

A hold reaching a soft limit requests Stop, validates its distinct response and
fresh stationary readback, records why the hold ended, then permits another valid
direction. Existing fault/uncertain-write/failed-Stop latches remain. Independent
review also found a normal Stop reply's motor fault could be missed if the next
Status cleared it. The manual driver now validates that Stop ACK before success.

Validation uses the real encoder, parser, owner and shared session, replacing only
the serial boundary. The captured 008000 baseline on installed jog5 fails busy with
zero JOG packets; corrected owners return OK after one complete JOG write. The
262 affected tests pass with 16 native methods reserved for display. The actual Tk
keyboard/repeat/focus/Stop regression passes with the captured flag at 700x460.
Independent 52-test and final 10-test focused runs pass, with no blocking findings.
Guide 6 and release/launcher 92 checks pass. Build and installed results are recorded
in PROJECT_STATE.md; these host checks do not establish physical movement.

Jog6 is release `jog-20261124.1`, paired application/PTU/serial versions
`0.0.1+jog.20261124.1`, installed separately at
`/home/admin/satgs-jog-20261124-app-manager`. After delivery, extract in a new
directory and use the normal setup/check/select workflow:

```sh
. ./setup_update.sh --accept-trusted-native
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog6
```

Launch `satgs-operator-gui`, Connect and inspect the limit label. With Up soft limit
still reported, try a supervised short Left/Right or Down hold and release/Stop.
Up becomes available when fresh device feedback clears its flag. Cole performs
all physical tests. Retain jog4, jog5 and the station; rollback while idle uses
`. ./launchers/setup_daily.sh --select jog5` or the retained working `jog4`.

The final offline build and separate 31-package host install passed. All 17 installed
headless phases passed with clean cleanup and unchanged inputs. Installed native
checks passed 41 of 42 methods; the exact 17 px Pi-font case is unavailable on this
host, leaving native acceptance BLOCKED for that one case. The updated captured-
limit keyboard test passed. Source/host results do not prove physical movement.

Published November 24 on `artifacts/releases` at
`c874e712d9d88736a7bc027b34d67ab27d98a3cc`, preserving the jog5 parent and all earlier releases.
Source, tests and documentation use the maintained `feature/operator-handbook-ptu`
branch. The archive preserves its tested preparation snapshot; publication does
not change the selected Pi application or station.
