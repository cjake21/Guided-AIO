# Launch and check the installed jog6 after removing older releases

Cole's jog6 run returned BLOCKED before any of its 18 phases ran. The checker
required `/home/admin/satgs-jog-20261118-app-manager/bin/python`, even though it
was checking `/home/admin/satgs-jog-20261124-app-manager`. Cole removed previous
jog directories to reclaim disk space. That is the cause of this result.

The follow-up changes acceptance support and daily launcher preparation. It uses the same jog6 runtime
wheels, application version and `jog6` alias. Missing historical installs no longer
block acceptance. Files still present retain their input checks, and selected
application checks remain required. This does not establish a physical PTU result.

Use `satgs-jog-20261124.1-support-fix2-20261124.tar.gz` for the corrected
checker and launcher recovery. Extract it into a new directory. Close SATGS GUI
and CLI sessions, then open Bash in the extracted directory on the Pi desktop.
The existing jog6 application stays at `/home/admin/satgs-jog-20261124-app-manager`.
Skip `setup_update.sh`; no application or dependencies need reinstalling.

Select the installed jog6 and open it:

```sh
. ./launchers/setup_daily.sh --select jog6 && satgs-operator-gui
```

Explicit selection prepares missing managed launchers and upgrades the previously
published jog6 dispatcher when present. It validates the requested application
instead of requiring the deleted old selection's application. It preserves the
saved workspace and changes selection only under the existing idle station lease.
Close the GUI and CLI before changing selection. Backups remain under
`~/.local/share/satgs-launchers/backups/`. Missing-file errors name the failed path.

Run consolidated checks from the same extracted directory:

```sh
./run_pi_operator_checks.sh --accept-trusted-native
```

Checks print report/evidence paths automatically. Keep previous failed reports as
history. The first support-only follow-up's new regression test incorrectly
rewrote its own Pi scratch path under `/home/admin`. The supplied jog6 export
has 17 phases PASS, including all 42 native widget methods, and that one source
fixture ERROR. The `checks && select` chain therefore skipped real selection.
The fixture now rewrites only exact historical application roots, leaving its
scratch and current application untouched. The previous bundle remains historical.

The daily station remains `/home/admin/satgs/station`. In the PTU tab, use the saved
local QPT130 connection and Connect. At status `008000`, Up should be unavailable
while Left, Right and Down remain available after fresh stationary feedback. Cole
performs the physical movement test. A software check result alone does not prove
movement. Earlier aliases can only launch or roll back to applications still
installed; this update does not recreate deleted versions.

All 100 focused source/launcher fixtures pass. The actual guarded source-workflow
child passes all 23 tests with no errors, failures or runtime denials and clean
completion. Source validation passes. Independent launcher recovery/upgrade and
station-preservation probes pass. Final packaged transfer checks and publication
are in progress. Existing jog6
runtime wheels, PTU behavior, station format and alias are unchanged. Cole performs
the Pi and physical movement checks.
