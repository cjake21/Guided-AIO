# QPT130 Connect update, November 19

Candidate `jog-20261119.1`, alias `jog4`, pairs satgs, ptu_control and serialptu
at `0.0.1+jog.20261119.1`. It preserves all older applications and station data.

## Evidence and correction

Cole supplied the actual failed Connect report. Jog3 attempt
`74d4b451112f42f5baf6f378d37ff543` opened the selected adapter in approximately
27 ms, wrote all nine bytes `02 31 00 00 00 00 00 31 03`, and received no bytes
during the remaining approximately 0.98 seconds. Repeated attempts have the
same shape. This establishes an unanswered query, not an open failure, corrupt
reply or decoded soft-limit flag. Separate policy_mismatch records wrote nothing.

The original driver allowed five seconds for connection establishment and used
0.5-second status attempts. The shared local owner had instead bounded cold open
and one query by the saved one-second ordinary exchange timeout. Local Connect
now has a five-second overall budget, including acquisition, and repeats only
fully written initial status queries with no reply bytes, at most ten probes.
After a reply following repeated probes it validates subsequent frames and waits
for 0.5 seconds without new bytes, within the same overall budget. Every probe
and all received bytes remain in existing Results/report records. PTCR20 has no
transaction ID, so the record labels initial response correlation as unsequenced.
Later unexpected input still fails the ordinary stale-input check.

Partial replies/writes, unknown write counts, malformed frames, cancellation,
failed Stop and invalidated contexts remain terminal. Connect sends no movement,
reset, homing or limit-programming command. Ordinary command budgets and saved
settings are unchanged. Feedback retains conservative age from request start;
a slow successful Connect makes polling due promptly. The PTU tab also moves its
existing Choose button into the connection row to recover vertical space.

This is a source-supported startup correction. Only Cole's hardware test can
show whether it resolves this unit's silent response.

## Validation and review

The real driver/encoder/parser with controlled serial boundaries reproduces the
old failure for a 0.8-second open plus a 0.4-second reply, and for a lost first
reply. The corrected implementation succeeds in both scenarios. Delayed replies
to two startup probes are consumed before a following Status succeeds.

Focused driver/owner/shared CLI/interface modules: 223 passed; 16 native methods
were skipped without a display and are covered separately on an owned display.
Installer, guide and core tests: 31 passed. Release/launcher tests: 92 passed.
All six wheels built offline; a separate 31-distribution host installation passed
creation, install, dependency and metadata checks. Source and whitespace checks
passed. These are host results, not Pi or physical acceptance.

The installed host candidate also passed all 17 consolidated headless phases,
with no failures, skips or runtime denials and clean supervision. Installed native
capture ran 42 methods: 41 passed, one exact-font test was explicitly unavailable;
there were no failures, errors or runtime denials and cleanup was clean. The native
lane is BLOCKED for that missing font case, not a complete native acceptance PASS.
Records are retained in
`/workspace/development/satgs-maintenance/jog4-release-20261119/host-check-1`
and `host-check-2`. The six-owner build is
`/workspace/development/satgs-maintenance/jog4-release-20261119-build-1`.

Independent implementation review initially found pending startup replies and
slow-Connect polling issues. Both were corrected and the review approved the
implementation. That reviewer authored driver regressions but did not implement
the correction. The release/launcher reader found a missing jog3 rollback choice;
it was corrected and the focused release tests passed.

The actual Connect button passes a lost-first-reply test: arrows remain disabled
while waiting, then become available after valid feedback; no motion is emitted.
The original GUI reproduces the three reported layout overflows under the text-
spacing stress. The corrected GUI passes. The exact 17-pixel Pi-font check is
explicitly unavailable on the retained host's fixed 13-pixel Tk9 font runtime.

## Publication

Published with Cole's explicit approval on November 19, 2026, at artifact commit
`ab49ea9ba5783a7d620444ce81162dc44f419b07`, branch `artifacts/releases`.
Only the reviewed archive, checksum and versioned README were added. Independently
fetched remote files match package-2. Source branches and all prior releases remain
unchanged. Download through the
[fixed-commit archive page](https://git.codev.mitre.org/users/cjacobson/repos/satgs-modular-suite/browse/satgs-jog-20261119.1.tar.gz?at=ab49ea9ba5783a7d620444ce81162dc44f419b07).

## Cole's Pi and physical result

On November 19 Cole confirmed physical QPT130 movement through jog4 GUI arrow
controls after waiting about five seconds for Connect. The consolidated check
had returned FAIL, so he explicitly selected jog4 and launched the GUI. Record
jog4 as the current operator-selected working installation; preserve it.

The transfer `/workspace/development-delivery/ptu-jog4` explains that FAIL: 17
non-native phases and cleanup passed. Native widgets ran 42 methods with no errors,
skips or runtime denials. Only the layout method failed, with three bounds
assertions under taller-text-controls at 700x460: Down extends 11 px below its tab,
and Enable broker steps/Disarm extend 25 px. The separate exact Pi-font test passes.
This is a remaining layout defect, not a physical-control failure.

The latest operation export records three successful Connects, 21 successful
holds in all four directions, and 21 successful Stop/readbacks. It also preserves
one initial five-second Connect deadline and one interrupted-jog/Stop feedback
failure. In the latter, driver exchange 33 writes the full jog packet, receives
`06`, and is cancelled on release. Exchange 34 writes the complete Stop packet,
then raises stale-response on queued input before reading a Stop response. The
queued tail bytes are not present in that record. Later passive cleanup and a
fresh Connect succeed. This is a separate source-backed follow-up; do not hide
it or treat the Stop write alone as confirmed physical stopping. Numeric motion,
CLI physical control and complete Stop qualification have not been confirmed by
Cole's statement.

## Operator update

Download and extract the reviewed archive in a new directory. Close SATGS after
ending any active session. Keep the previous application and offline dependencies.
From the extracted directory:

```sh
. ./setup_update.sh --accept-trusted-native
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog4
```

Setup stages `/home/admin/satgs-jog-20261119-app-manager`. Selection occurs only
after successful checks and an idle station. Open SATGS, go to PTU, leave the
Configuration JSON field empty to use the existing saved connection, then Connect.
Allow five seconds. Verify returned position before trying a supervised short jog
and Stop. If Connect still fails, its existing Results > Report now contains the
complete initial phase. Do not force-enable controls or install ActiveMQ for local
serial. Cole performs all hardware tests.

Rollback while idle: `. ./launchers/setup_daily.sh --select jog3`.
No current station settings, results or accepted installations are overwritten.
The installer and task playbooks are included; complete Full M-SEL owner/native
provisioning remains tracked separately in SUITE_GAPS.md for the December 1 goal.

## Local jog5 continuation

Cole requested the fix and documentation delivery, then held publication because
Bitbucket is down. Jog5 uses release `jog-20261119.2`; it remains local and has not
changed the accepted jog4 application or station.

The interrupted-JOG correction sends Stop before waiting for the old reply tail.
It validates that old reply, requires a separate Stop ACK and fresh stationary
status, then permits another hold through the shared GUI/CLI session. Results
retain the old JOG prefix/completed reply separately from the Stop response.
Unknown bytes already queued beyond the known old reply, missing replies, device
faults and uncertain writes retain the blocked outcome.

Independent review found and reproduced the extra queued-ACK boundary. The fix
now rejects it after writing Stop, leaving the unknown bytes unread. The final
independent driver/session run passed 91 tests with no blocking findings. The
local build, package and installed-check results are recorded in PROJECT_STATE.md
and `/workspace/development/satgs-maintenance/jog5-release-20261119`. Cole performs
the future Pi and physical tests.

Jog5 host validation is complete: all six wheels built offline, normal separate
31-package installation passed, and all 17 installed headless phases passed with
clean cleanup. Installed native checks passed 41 tests; one exact Pi-font test
was NOTRUN on this host, leaving native status BLOCKED. No jog5 Pi or physical
result is inferred. The local package and compiled handbook remain beside the
validation records. Source/docs and artifact publication remain on hold.

## Publication resumed November 20

Cole requested another push after internal Bitbucket service returned. Jog5
`jog-20261119.2` is now published on `artifacts/releases` at
`7b0f9bcffa6a51b2a3a471ed04c74d3cd34e4c9c`, a normal child of the retained jog4 release. The artifact
commit adds only the archive, checksum and versioned README. Source and docs
are maintained separately on `feature/operator-handbook-ptu`. The archive's
November 19 local/on-hold notes are its preparation history. This publication
does not change Cole's Pi, selected jog4 or station. Use the jog5 README/setup
commands for the next target check; the earlier operator update above is jog4
history.
