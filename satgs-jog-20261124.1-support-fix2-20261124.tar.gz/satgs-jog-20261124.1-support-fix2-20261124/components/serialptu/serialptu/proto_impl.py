# from . import protocol
from serialptu import protocol
from serialptu.errors import CorruptedMessageError

class PTCR20(protocol.Quickset):
    """
       PTCR20 specific details:
        - Do not set ptu_id and do not tack ptu_id value onto message, as PTCR20 has no concept of identity
        - get_soft_limit command value is 0x71
        - set_soft_limit command value is 0x81
        - limit_response for both get/set_soft_limit in PTCR20 is the same structure
    """

    def __init__(self):
        super(PTCR20, self).__init__(ptu_id=None, jog_aux_bytes=2, move_aux_bytes=2)
        # Override the base class _commands['get_soft_limit'] to 0x71
        self._commands['get_soft_limit'] = 0x71

    def create_dict_copy(self):
        return self._commands

    @staticmethod
    def manual_jog_status(raw):
        if type(raw) is not bytes or len(raw) != 3:
            raise CorruptedMessageError("strict-status")
        blocked = {}
        for axis, mask, direction, reason in (
                (0, 0x80, "right", "Clockwise soft limit reached."),
                (0, 0x40, "left", "Counter-clockwise soft limit reached."),
                (1, 0x80, "up", "Up soft limit reached."),
                (1, 0x40, "down", "Down soft limit reached.")):
            if raw[axis] & mask:
                blocked[direction] = reason
        return bool((raw[0] | raw[1]) & 0x3f), blocked

    def jog(self, pan_velocity, tilt_velocity,
            override_soft_limits=False, stop = None, reset_errors=False):

        return self._build_jog(pan_velocity, tilt_velocity,
                               override_soft_limits=override_soft_limits,
                               stop=stop,
                               reset_errors=reset_errors)

    def get_soft_limit(self, axis):
        self._check_axis(axis)

        # Returns the specified axis soft limit value
        return self._build_message(bytes([self._commands['get_soft_limit']]) +
                                   bytes([self._axis[axis]]))

    def set_soft_limit(self, axis):
        self._check_axis(axis)

        # This sets the current position as axis soft limit
        return self._build_message(bytes([self._commands['set_soft_limit']]) +
                                   bytes([self._axis[axis]]))

    def get_min_speed(self):
        return self._build_message(bytes([self._commands['get_min_speeds']]))

    def set_min_speed(self, pan_velocity, tilt_velocity):
        return self._build_message(bytes([self._commands['set_min_speeds'], pan_velocity, tilt_velocity]))

    def get_max_speed(self):
        return self._build_message(bytes([self._commands['get_max_speeds']]))

    def set_max_speed(self, pan_velocity, tilt_velocity):
        return self._build_message(bytes([self._commands['set_max_speeds'], pan_velocity, tilt_velocity]))

    def parse_status_message(self, message):
        # Status response is normally 8bytes long
        if len(message) < 8:
            raise CorruptedMessageError("Status response too short")

        parsed = {
            'message_type' : 'status_response',
            'command'      : self._command_lookup[message[0]],
            'pan'          : self._unpack_int_16(message[1:3]) / self._degree_factor,
            'tilt'         : self._unpack_int_16(message[3:5]) / self._degree_factor,
            'status_bytes' : bytes(message[5:8]),
            'status'       : self._parse_status_bits(message[5:8])
        }

        # print(parsed)
        return parsed

    def parse_move_message(self, message):
        # Move response is normally 8bytes long
        if len(message) < 8:
            raise CorruptedMessageError("Move response too short")

        parsed = {
            'message_type' : 'move_response',
            'command'      : self._command_lookup[message[0]],
            'pan'          : self._unpack_int_16(message[1:3]) / self._degree_factor,
            'tilt'         : self._unpack_int_16(message[3:5]) / self._degree_factor,
            'status_bytes' : bytes(message[5:8]),
            'status'       : self._parse_status_bits(message[5:8])
        }

        # print(parsed)
        return parsed

    def parse_limit_message(self, message):
        # Limit reponse is normally 4bytes long
        new_commands_dict = self.create_dict_copy()
        received_command = {command : name for name, command in new_commands_dict.items()}
        if len(message) < 4:
            raise CorruptedMessageError("Get/Set Limit response too short")

        parsed = {
            'message_type' : 'limit_response',
            'command'      : received_command[message[0]],
            'axis'         : self._axis_lookup[message[1]],
            'limit'        : self._unpack_int_16(message[2:4]) / self._degree_factor
        }

        # print(parsed)
        return parsed

    def parse_speed_limit_message(self, message):
        # Speed limit response is normally 3bytes long
        if len(message) < 3:
           raise CorruptedMessageError("Get/Set Min/Max speed limit response too short")

        parsed = {
            'message_type'     : 'speed_limit_response',
            'command'          : self._command_lookup[message[0]],
            'pan_speed_limit'  : message[1],
            'tilt_speed_limit' : message[2]
        }

        # print(parsed)
        return parsed

    def get_status_definitions(self):
        return [
            ("General", [
                #("ENC", "Encoder Installed (Ignores pan soft/hard limits if true)", "status"),
                ("HRES", "High resolution capable", "status"),
                ("EXEC", "Executing remote command", "status"),
                ("OSLR", "Controller is in soft limit override", "status"),
                ("CWM", "PTU is moving clockwise", "status"),
                ("CCWM", "PTU is moving counter-clockwise", "status"),
                ("UPM", "PTU is moving up", "status"),
                ("DWNM", "PTU is moving down", "status")
            ]),
            ("Pan Status", [
                ("CWSL", "Clockwise soft limit hit", "error"),
                ("CCWSL", "Counter-clockwise soft limit hit", "error"),
                ("CWHL", "Clockwise hard limit hit", "error"),
                ("CCWHL", "Counter-clockwise hard limit hit", "error"),
                ("TO", "Motor Timeout Error", "error"),
                ("DE", "Directional Error", "error"),
                ("OL", "Current Overload", "error")
            ]),
            ("Tilt Status", [
                ("USL", "Up soft limit hit", "error"),
                ("DSL", "Down soft limit hit", "error"),
                ("UHL", "Up hard limit hit", "error"),
                ("DHL", "Down hard limit hit", "error"),
                ("TO", "Motor Timeout Error", "error"),
                ("DE", "Directional Error", "error"),
                ("OL", "Current Overload", "error")
            ])
        ]

    def _parse_status_bits(self, bitfields):
        pan = bitfields[0]
        tilt = bitfields[1]
        gen = bitfields[2]

        return [
            ("General", [
                #("ENC", bool(gen & 0x80)),
                ("HRES", bool(gen & 0x80)),
                ("EXEC", bool(gen & 0x40)),
                ("OSLR", bool(gen & 0x10)),
                ("CWM",  bool(gen & 0x08)),
                ("CCWM", bool(gen & 0x04)),
                ("UPM",  bool(gen & 0x02)),
                ("DWNM", bool(gen & 0x01))
            ]),
            ("Pan Status", [
                ("CWSL",  bool(pan & 0x80)),
                ("CCWSL", bool(pan & 0x40)),
                ("CWHL",  bool(pan & 0x20)),
                ("CCWHL", bool(pan & 0x10)),
                ("TO",    bool(pan & 0x08)),
                ("DE",    bool(pan & 0x04)),
                ("OL",    bool(pan & 0x02))
            ]),
            ("Tilt Status", [
                ("USL", bool(tilt & 0x80)),
                ("DSL", bool(tilt & 0x40)),
                ("UHL", bool(tilt & 0x20)),
                ("DHL", bool(tilt & 0x10)),
                ("TO",  bool(tilt & 0x08)),
                ("DE",  bool(tilt & 0x04)),
                ("OL",  bool(tilt & 0x02))
            ])
        ]


class PTCR96(protocol.Quickset):
    _coordinate_width = 3

    def __init__(self):
        super(PTCR96, self).__init__(ptu_id=0x0, jog_aux_bytes=4, move_aux_bytes=4, degree_factor=100)

    def jog(self, pan_velocity, tilt_velocity,
            override_soft_limits=False, stop=None, reset_errors=False):

        extra_cmd_mask = 0
        if pan_velocity > 0:
            extra_cmd_mask = extra_cmd_mask | 0x80
        if tilt_velocity > 0:
            extra_cmd_mask = extra_cmd_mask | 0x40

        return self._build_jog(pan_velocity, tilt_velocity,
                               dir_bit=False,
                               max_speed=255, extra_cmd_mask=extra_cmd_mask,
                               override_soft_limits=override_soft_limits,
                               stop=stop,
                               reset_errors=reset_errors)

    def get_soft_limit(self, axis):
        self._check_axis(axis)

        # Setting the 0x80 bit indicates we want to get_soft_limit, returns the specificied axis soft limit value
        return self._build_message(bytes([self._commands["get_soft_limit"], self._axis[axis] | 0x80]))

    def set_soft_limit(self, axis):
        self._check_axis(axis)

        # This sets current position as the axis soft limit
        return self._build_message(bytes([self._commands["set_soft_limit"], self._axis[axis]]))

    def get_firmware(self):
        pass
        #return self._build_message(bytes([self._commands["get_soft_limit"], self._axis[axis] | 0x80]))

    def get_pt_ramp_params(self):
        return self._build_message(bytes[self._commands["get_pt_ramp_params"], 0x80 ])

    def parse_status_message(self, message):
        # Status response is normally 10bytes long (zoom, focus, cam parameters not implemented)
        if len(message) < 10:
            return CorruptedMessageError("Status response too short")

        parsed = {
            'message_type' : 'status_response',
            'command'      : self._command_lookup[message[0]],
            'pan'          : self._unpack_int_24(message[1:4]) / self._degree_factor,
            'tilt'         : self._unpack_int_24(message[4:7]) / self._degree_factor,
            'status_bytes' : bytes(message[7:10]),
            'status'       : self._parse_status_bits(message[7:10])
        }

        # print(parsed)
        return parsed

    def parse_limit_message(self, message):
        # Limit response is normally 5bytes long
        if len(message) < 5:
            raise CorruptedMessageError("Get/Set Limit response too short")

        parsed = {
            'message_type' : 'limit_response',
            'command'      : self._command_lookup[message[0]],
            'axis'         : self._axis_lookup[message[1]],
            'limit'        : self._unpack_int_24(message[2:5]) / self._degree_factor
        }

        # print(parsed)
        return parsed

    def parse_move_message(self, message):
        # Move reponse is normally 10bytes long (zoom, focus response not implmented)
        if len(message) < 10:
            raise CorruptedMessageError("Move response too short")

        parsed = {
            'message_type' : 'move_response',
            'command'      : self._command_lookup[message[0]],
            'pan'          : self._unpack_int_24(message[1:4]) / self._degree_factor,
            'tilt'         : self._unpack_int_24(message[4:7]) / self._degree_factor,
            'status_bytes' : bytes(message[7:10]),
            'status'       : self._parse_status_bits(message[7:10])
        }

        # print(parsed)
        return parsed

    def _parse_ramp_params_message(self, message):
        if len(message) < 10:
            raise CorruptedMessageError("Move response too short")

        parsed = {
            'message_type' : 'move_response',
            'command'      : self._command_lookup[message[0]],
            'pan'          : self._unpack_int_24(message[1:4]) / self._degree_factor,
            'tilt'         : self._unpack_int_24(message[4:7]) / self._degree_factor,
            'status'       : self._parse_status_bits(message[7:10])
        }

        return parsed

    def _coord_only_message(self, command, pan, tilt):
        data = (bytes([command]) +
                self._pack_int_24(pan * self._degree_factor) +
                self._pack_int_24(tilt * self._degree_factor) +
                bytes(self._move_aux_bytes))

        return self._build_message(data)

    def get_status_definitions(self):
        return [
            ("General", [
                ("EXEC", "Executing remote command", "status"),
                ("OSLR", "Controller is in soft limit override", "status"),
                ("CWM", "PTU is moving clockwise", "status"),
                ("CCWM", "PTU is moving counter-clockwise", "status"),
                ("UPM", "PTU is moving up", "status"),
                ("DWNM", "PTU is moving down", "status"),
                ("CON", "Continuous rotation", "status")
            ]),
            ("Pan Status", [
                ("CWSL", "Clockwise soft limit hit", "error"),
                ("CCWSL", "Counter-clockwise soft limit hit", "error"),
                ("CWHL", "Clockwise hard limit hit", "error"),
                ("CCWHL", "Counter-clockwise hard limit hit", "error"),
                ("TO", "Motor Timeout Error", "error"),
                ("DE", "Direction Error", "error")
            ]),
            ("Tilt Status", [
                ("USL", "Up soft limit hit", "error"),
                ("DSL", "Down soft limit hit", "error"),
                ("UHL", "Up hard limit hit", "error"),
                ("DHL", "Down hard limit hit", "error"),
                ("TO", "Motor Timeout Error", "error"),
                ("DE", "Direction Error", "error")
            ])
        ]

    def _parse_status_bits(self, bitfields):
        pan = bitfields[0]
        tilt = bitfields[1]
        gen = bitfields[2]

        return [
            ("General", [
                ("EXEC", bool(gen & 0x40)),
                ("OSLR", bool(gen & 0x10)),
                ("CWM",  bool(gen & 0x08)),
                ("CCWM", bool(gen & 0x04)),
                ("UPM",  bool(gen & 0x02)),
                ("DWNM", bool(gen & 0x01)),
                ("CON", bool(gen & 0x80))
            ]),
            ("Pan Status", [
                ("CWSL",  bool(pan & 0x80)),
                ("CCWSL", bool(pan & 0x40)),
                ("CWHL",  bool(pan & 0x20)),
                ("CCWHL", bool(pan & 0x10)),
                ("TO",    bool(pan & 0x08)),
                ("DE",    bool(pan & 0x04))
            ]),
            ("Tilt Status", [
                ("USL", bool(tilt & 0x80)),
                ("DSL", bool(tilt & 0x40)),
                ("UHL", bool(tilt & 0x20)),
                ("DHL", bool(tilt & 0x10)),
                ("TO",  bool(tilt & 0x08)),
                ("DE",  bool(tilt & 0x04))
            ])
        ]

