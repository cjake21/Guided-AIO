"""Hardware-free contracts using the real PTCR20/PTCR96 encoders."""
from dataclasses import FrozenInstanceError, replace
from contextlib import contextmanager
import errno
import threading
import time
import unittest
from unittest.mock import Mock, patch

from serial import SerialException
from serialptu.acquisition import AcquisitionError, SerialDeviceIdentity, SerialSettings, _DeviceSnapshot
from serialptu.errors import CorruptedMessageError
from serialptu.proto_impl import PTCR20, PTCR96
from serialptu.ptu import PTU, PointingError


def acknowledgement(proto, command=0x33, pan=0, tilt=0, status=bytes(3)):
    pack = proto._pack_int_16 if type(proto) is PTCR20 else proto._pack_int_24
    packet = proto._build_message(bytes([command]) + pack(pan) + pack(tilt) + status)
    return b"\x06" + packet[1:]


class RecordingSerial:
    def __init__(self, proto):
        self.proto = proto
        self.port = None
        self.baudrate = 57600
        self.bytesize = 8
        self.parity = "N"
        self.stopbits = 1
        self.xonxoff = self.rtscts = self.dsrdtr = False
        self.timeout = 0
        self.write_timeout = None
        self.opened = False
        self.opens = self.closes = 0
        self.writes = []
        self.response = bytearray()
        self.result = None
        self.on_write = None
        self.on_open = None
        self.close_failure = False
        self.auto_ack = True

    def isOpen(self):
        return self.opened

    @property
    def in_waiting(self):
        return len(self.response)

    def open(self):
        self.opens += 1
        self.opened = True
        if self.on_open:
            self.on_open()

    def close(self):
        self.closes += 1
        if self.close_failure:
            raise OSError("injected")
        self.opened = False

    def write(self, data):
        self.writes.append(data)
        if self.on_write:
            self.on_write()
        if isinstance(self.result, BaseException):
            raise self.result
        if self.auto_ack:
            command = self.proto._decode_strict_packet(data, 2)[0]
            self.response.extend(acknowledgement(self.proto, command))
        return len(data) if self.result is None else self.result

    def read(self, count):
        result = bytes(self.response[:count])
        del self.response[:count]
        return result


class PreparedPointingTests(unittest.TestCase):
    def make(self, proto=None, opened=True, logger=None):
        proto = PTCR20() if proto is None else proto
        native = RecordingSerial(proto)
        with patch("serialptu.ptu.serial.Serial", return_value=native):
            driver = PTU(proto, "recording-only", pointing=True, logger=logger)
        cancel = threading.Event()
        deadline = time.monotonic() + 2
        handle = driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
        if opened:
            driver.open_bounded(deadline=deadline, cancel=cancel)

        def release():
            native.close_failure = False
            driver.close(deadline=time.monotonic() + 1)
        self.addCleanup(release)
        return driver, native, handle, deadline, cancel

    def prepare(self, driver, handle, deadline, cancel, pan=12.34, tilt=-56.78):
        return driver.prepare_move_to(handle, pan, tilt, deadline=deadline, cancel=cancel)

    def submit(self, driver, handle, prepared, deadline, cancel):
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            return driver.submit_prepared_move(handle, prepared, deadline=deadline, cancel=cancel)

    def test_literal_legacy_encoder_bytes_are_unchanged(self):
        self.assertEqual(PTCR20().move_to(0, 0), bytes.fromhex("02 33 00 00 00 00 00 00 33 03"))
        self.assertEqual(PTCR96().move_to(0, 0),
                         bytes.fromhex("02 00 33 00 00 00 00 00 00 00 00 00 00 33 03"))

    def test_manual_status_classifier_distinguishes_directional_soft_limits_from_faults(self):
        for raw, directions in ((b'\x00\x00\x00', ()), (b'\x80\x00\x00', ('right',)),
                                (b'\x40\x00\x00', ('left',)), (b'\x00\x80\x00', ('up',)),
                                (b'\x00\x40\x00', ('down',)),
                                (b'\xc0\xc0\x00', ('right', 'left', 'up', 'down'))):
            with self.subTest(raw=raw):
                fatal, blocked = PTCR20.manual_jog_status(raw)
                self.assertFalse(fatal)
                self.assertEqual(set(blocked), set(directions))
                self.assertTrue(all(type(reason) is str and reason for reason in blocked.values()))
        for axis in (0, 1):
            for bit in (1, 2, 4, 8, 16, 32):
                raw = bytearray(3)
                raw[axis] = bit
                with self.subTest(axis=axis, bit=bit):
                    self.assertTrue(PTCR20.manual_jog_status(bytes(raw))[0])
        for raw in (None, bytearray(3), b'', b'\x00\x80', bytes(4), '008000'):
            with self.subTest(raw=raw), self.assertRaises(CorruptedMessageError):
                PTCR20.manual_jog_status(raw)

    def test_stateless_jog_reuses_legacy_encoding_without_status_motion(self):
        proto = PTCR20()
        for velocities, decoded, literal in (
                ((1, 0), (127, 0, 127), "02 31 00 ff 00 00 00 ce 03"),
                ((-1, 0), (-127, 0, 127), "02 31 00 fe 00 00 00 cf 03"),
                ((0, 1), (0, 127, 127), "02 31 00 00 ff 00 00 ce 03"),
                ((0, -1), (0, -127, 127), "02 31 00 00 fe 00 00 cf 03"),
                ((.5, 0), (64, 0, 127), "02 31 00 81 00 00 00 b0 03")):
            with self.subTest(velocities=velocities):
                packet = proto.jog_packet(*velocities)
                self.assertEqual(packet, bytes.fromhex(literal))
                self.assertEqual(packet, PTCR20().jog(*velocities, override_soft_limits=False))
                self.assertEqual(proto.decode_jog_packet(packet), decoded)
                self.assertEqual((proto._last_jog_pan, proto._last_jog_tilt, proto._last_jog_override),
                                 (0, 0, False))
                proto.validate_nonmoving_status_packet(proto.get_status())
        legacy = PTCR20()
        packet = legacy.jog(1, 0, override_soft_limits=True)
        self.assertEqual(legacy.get_status(), packet)
        self.assertEqual(PTCR96().jog(1, 0), bytes.fromhex("02 00 31 80 ff 00 00 00 00 00 4e 03"))

    def test_stateless_jog_rejects_unsafe_flags_axes_and_malformed_packets(self):
        proto = PTCR20()
        for velocities in ((0, 0), (1, 1), (True, 0), (2, 0), (float('nan'), 0), (0, float('inf'))):
            with self.subTest(velocities=velocities), self.assertRaises(CorruptedMessageError):
                proto.jog_packet(*velocities)
        for payload in (bytes([0x31, 4, 255, 0, 0, 0]), bytes([0x31, 1, 255, 0, 0, 0]),
                        bytes([0x31, 2, 0, 0, 0, 0]), bytes([0x31, 0, 255, 255, 0, 0]),
                        bytes([0x31, 0, 1, 0, 0, 0]), bytes([0x31, 0, 255, 0, 1, 0])):
            with self.subTest(payload=payload), self.assertRaises(CorruptedMessageError):
                proto.decode_jog_packet(proto._build_message(payload))
        with self.assertRaises(CorruptedMessageError):
            PTCR96().jog_packet(1, 0)
        self.assertEqual((proto._last_jog_pan, proto._last_jog_tilt, proto._last_jog_override), (0, 0, False))

    def test_actual_encoder_truncation_and_signed_integer_decode(self):
        for proto, expected in ((PTCR20(), (-700, -567, 10)),
                                (PTCR96(), (-7004, -5678, 100))):
            with self.subTest(protocol=type(proto).__name__):
                driver, native, handle, deadline, cancel = self.make(proto)
                prepared = self.prepare(driver, handle, deadline, cancel, -70.04, -56.78)
                self.assertEqual((prepared.pan_units, prepared.tilt_units,
                                  prepared.units_per_degree), expected)
                self.assertEqual(native.writes, [])

    def test_canonical_escape_roundtrip_and_malformed_packets(self):
        for proto in (PTCR20(), PTCR96()):
            packet = proto.move_to(0.2, 0.3)
            self.assertEqual(proto.decode_move_to_packet(packet),
                             (int(0.2 * proto._degree_factor), int(0.3 * proto._degree_factor),
                              int(proto._degree_factor)))
            malformed = [bytearray(packet), packet[:-1], packet + b"\x00",
                         b"\x02\x33\x1b\x03", b"\x02\x33\x1b\x80\x03",
                         b"\x02\x33\x02\x03", packet[:-2] + b"\xff\x03"]
            for value in malformed:
                with self.assertRaises(CorruptedMessageError):
                    proto.decode_move_to_packet(value)

    def test_packet_decoder_rejects_wrong_kind_address_aux_and_length(self):
        for proto in (PTCR20(), PTCR96()):
            width = proto._coordinate_width
            for data in (b"\x34" + bytes(width * 2 + proto._move_aux_bytes),
                         b"\x33" + bytes(width * 2) + b"\x01" + bytes(proto._move_aux_bytes - 1),
                         b"\x33" + bytes(width * 2 + proto._move_aux_bytes + 1)):
                with self.assertRaises(CorruptedMessageError):
                    proto.decode_move_to_packet(proto._build_message(data))
        proto = PTCR96()
        packet = proto.move_to(0, 0)
        with self.assertRaises(CorruptedMessageError):
            proto.decode_move_to_packet(packet[:1] + b"\x01" + packet[2:-2] + b"\x32\x03")

    def test_strict_constructor_is_inert_and_legacy_constructor_default_is_unchanged(self):
        for strict, expected in ((True, 0), (False, 1)):
            native = RecordingSerial(PTCR20())
            logger = Mock()
            with patch("serialptu.ptu.serial.Serial", return_value=native):
                driver = PTU(native.proto, "recording-only", pointing=strict, logger=logger)
            self.assertEqual(native.opens, expected)
            self.assertIsNone(driver._keepalive)
            if strict:
                logger.assert_not_called()
                self.assertEqual(logger.method_calls, [])
                with self.assertRaises(PointingError):
                    driver.open_bounded(deadline=time.monotonic() + 1, cancel=threading.Event())
                self.assertEqual(native.opens, 0)
                driver.close(deadline=time.monotonic() + 1)
            else:
                driver.close()

    def test_bind_then_open_starts_no_keepalive_and_does_not_claim_position(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        self.assertEqual(native.opens, 0)
        driver.open_bounded(deadline=deadline, cancel=cancel)
        self.assertEqual(native.opens, 1)
        self.assertIsNone(driver._keepalive)
        self.assertEqual(native.writes, [])
        self.assertEqual(handle.binding, bytes(32))
        with self.assertRaises(PointingError):
            PTU.KeepAlive(driver)

    def test_failed_or_late_open_invalidates_but_retains_passive_cleanup(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        native.on_open = cancel.set
        with self.assertRaises(PointingError):
            driver.open_bounded(deadline=deadline, cancel=cancel)
        self.assertTrue(native.opened)
        cancel.clear()
        with self.assertRaises(PointingError):
            self.prepare(driver, handle, deadline, cancel)
        driver.close(deadline=deadline)
        self.assertFalse(native.opened)

    def test_prepared_record_and_handle_are_immutable(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        for record, field in ((handle, "binding"), (prepared, "packet"),
                              (prepared, "pan_units"), (prepared, "generation")):
            with self.assertRaises(AttributeError):
                setattr(record, field, None)
            with self.assertRaises(AttributeError):
                delattr(record, field)
        self.assertIs(type(prepared.packet), bytes)

    def test_prepared_submission_encodes_once_and_writes_exact_same_bytes_once(self):
        for proto in (PTCR20(), PTCR96()):
            driver, native, handle, deadline, cancel = self.make(proto)
            proto.move_to = Mock(wraps=proto.move_to)
            prepared = self.prepare(driver, handle, deadline, cancel)
            result = self.submit(driver, handle, prepared, deadline, cancel)
            proto.move_to.assert_called_once_with(12.34, -56.78)
            self.assertEqual(native.writes, [prepared.packet])
            self.assertIs(native.writes[0], prepared.packet)
            self.assertTrue(result[0])
            self.assertEqual(result[1]["message_type"], "move_response")
            self.assertGreater(native.write_timeout, 0)
            self.assertLessEqual(native.write_timeout, 2)

    def test_submit_requires_guard_and_exact_original_controls(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        with self.assertRaises(PointingError):
            driver.submit_prepared_move(handle, prepared, deadline=deadline, cancel=cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            for other_deadline, other_cancel in ((deadline + 1, cancel), (deadline, threading.Event())):
                with self.assertRaises(PointingError):
                    driver.submit_prepared_move(handle, prepared,
                                                deadline=other_deadline, cancel=other_cancel)
        self.assertEqual(native.writes, [])

    def test_foreign_handle_and_prepared_record_are_rejected(self):
        driver, native, handle, deadline, cancel = self.make()
        other, other_native, other_handle, other_deadline, other_cancel = self.make()
        prepared = self.prepare(other, other_handle, other_deadline, other_cancel)
        with self.assertRaises(PointingError):
            self.prepare(driver, other_handle, deadline, cancel)
        with self.assertRaises(PointingError):
            self.submit(driver, handle, prepared, deadline, cancel)
        self.assertEqual(native.writes, [])
        self.assertEqual(other_native.writes, [])

    def test_explicit_invalidation_rejects_existing_and_future_preparations(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
        with self.assertRaises(PointingError):
            self.submit(driver, handle, prepared, deadline, cancel)
        with self.assertRaises(PointingError):
            self.prepare(driver, handle, deadline, cancel)
        with self.assertRaises(PointingError):
            driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
        self.assertEqual(native.writes, [])

    def test_context_changes_invalidate_pending_preparations(self):
        for change in ("protocol", "baudrate", "timeout", "jog", "scale"):
            driver, native, handle, deadline, cancel = self.make()
            prepared = self.prepare(driver, handle, deadline, cancel)
            if change == "protocol":
                driver._protocol = PTCR20()
            elif change == "jog":
                driver.protocol._last_jog_pan = 0.5
            elif change == "scale":
                driver.protocol._degree_factor = 100
            else:
                setattr(native, change, 1)
            with self.assertRaises(PointingError):
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertTrue(driver._pointing_blocked)
            self.assertEqual(native.writes, [])

    def test_all_legacy_routes_deny_before_stateful_encoders(self):
        driver, native, handle, deadline, cancel = self.make()
        driver.protocol.jog = Mock(side_effect=AssertionError("encoder must not run"))
        driver.protocol.reset = Mock(side_effect=AssertionError("reset must not run"))
        calls = [(driver.get_status, ()), (driver.jog, (1, 1)), (driver.move_to_zero, ()),
                 (driver.move_to, (1, 1)), (driver.move_delta, (1, 1)), (driver.move_home, ()),
                 (driver.get_soft_limit, ("CW",)), (driver.set_soft_limit, ("CW",)),
                 (driver.get_max_speed, ()), (driver.get_min_speed, ()),
                 (driver.set_max_speed, (1, 1)), (driver.set_min_speed, (1, 1)),
                 (driver.reset_motor_timeout, ()), (driver.open, ()),
                 (driver._send_message, (b"unvalidated",)), (driver._receive_message, ()),
                 (driver.set_status_rate, (1,)), (driver.connect_status_listener, (lambda: None,)),
                 (driver.disconnect_status_listener, (lambda: None,))]
        for function, args in calls:
            with self.assertRaises(PointingError) as failure:
                function(*args)
            self.assertEqual(failure.exception.primary, "legacy-disabled")
        driver.protocol.jog.assert_not_called()
        driver.protocol.reset.assert_not_called()
        self.assertEqual(native.writes, [])

    def test_only_validated_zero_jog_status_is_submitted(self):
        for proto in (PTCR20(), PTCR96()):
            driver, native, handle, deadline, cancel = self.make(proto)
            result = driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
            self.assertEqual(result[1]["message_type"], "status_response")
            self.assertEqual(len(native.writes), 1)
            proto.validate_nonmoving_status_packet(native.writes[0])
            proto._last_jog_tilt = 1
            with self.assertRaises(PointingError):
                driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
            self.assertEqual(len(native.writes), 1)

    def test_control_admission_and_coordinate_domain_have_no_effect(self):
        driver, native, handle, deadline, cancel = self.make()

        class HostileEvent(threading.Event):
            def is_set(self):
                raise AssertionError("must not dispatch")

        for invalid_deadline, invalid_cancel in ((True, cancel), (float("nan"), cancel),
                                                (float("inf"), cancel), (10 ** 1000, cancel),
                                                (deadline, HostileEvent()), (deadline, object())):
            with self.assertRaises(PointingError):
                self.prepare(driver, handle, invalid_deadline, invalid_cancel)
        for pan, tilt in ((True, 0), (float("nan"), 0), (0, float("inf")),
                          (999.99, 0), (361, 0), (0, 181), (10 ** 1000, 0)):
            with self.assertRaises(PointingError):
                self.prepare(driver, handle, deadline, cancel, pan, tilt)
        self.assertEqual(native.writes, [])

    def test_cancel_and_deadline_at_guard_recheck_prevent_write(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            cancel.set()
            with self.assertRaises(PointingError) as failure:
                driver.submit_prepared_move(handle, prepared, deadline=deadline, cancel=cancel)
            self.assertEqual(failure.exception.primary, "cancelled")
        cancel.clear()
        with patch("serialptu.ptu.time.monotonic", return_value=deadline):
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertEqual(failure.exception.primary, "deadline")
        self.assertEqual(native.writes, [])

    def test_lock_wait_uses_original_deadline_and_cancellation(self):
        driver, native, handle, deadline, cancel = self.make()
        entered = threading.Event()
        release = threading.Event()

        def holder():
            with driver._lock:
                entered.set()
                release.wait(1)

        thread = threading.Thread(target=holder)
        thread.start()
        try:
            self.assertTrue(entered.wait(0.5))
            with self.assertRaises(PointingError) as failure:
                self.prepare(driver, handle, time.monotonic() + 0.02, cancel)
            self.assertEqual(failure.exception.primary, "deadline")
            cancel.set()
            with self.assertRaises(PointingError) as failure:
                self.prepare(driver, handle, deadline, cancel)
            self.assertEqual(failure.exception.primary, "cancelled")
        finally:
            release.set()
            thread.join(0.5)
            self.assertFalse(thread.is_alive())
        self.assertEqual(native.writes, [])

    def test_short_unknown_and_failed_writes_are_not_retried(self):
        for count, disposition in ((0, "none"), (1, "partial"), (True, "unknown"),
                                   (-1, "unknown"), (OSError("injected"), "unknown")):
            driver, native, handle, deadline, cancel = self.make()
            prepared = self.prepare(driver, handle, deadline, cancel)
            native.result = count
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertEqual(failure.exception.submission, disposition)
            self.assertEqual(len(native.writes), 1)
            with self.assertRaises(PointingError):
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertEqual(len(native.writes), 1)

    def test_cancel_after_full_native_write_is_complete_submission_not_success(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        native.on_write = cancel.set
        with self.assertRaises(PointingError) as failure:
            self.submit(driver, handle, prepared, deadline, cancel)
        self.assertEqual(failure.exception.primary, "cancelled")
        self.assertEqual(failure.exception.submission, "complete")
        self.assertEqual(failure.exception.written, len(prepared.packet))
        self.assertEqual(len(native.writes), 1)

    def test_deadline_after_full_native_write_is_not_success(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        clock = [deadline - 1]
        native.on_write = lambda: clock.__setitem__(0, deadline)
        with patch("serialptu.ptu.time.monotonic", side_effect=lambda: clock[0]):
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, deadline, cancel)
        self.assertEqual(failure.exception.primary, "deadline")
        self.assertEqual(failure.exception.submission, "complete")
        self.assertTrue(driver._pointing_blocked)

    def test_missing_or_wrong_response_never_resends(self):
        for response in (b"", acknowledgement(PTCR20(), 0x31), b"\x06\x33\x03"):
            driver, native, handle, deadline, cancel = self.make()
            prepared = self.prepare(driver, handle, deadline, cancel)
            native.auto_ack = False
            native.response.extend(response)
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, time.monotonic() + 0.03, cancel)
            self.assertEqual(failure.exception.submission, "complete")
            self.assertEqual(len(native.writes), 1)

    def test_expired_close_releases_passively_but_does_not_claim_timely_success(self):
        driver, native, handle, deadline, cancel = self.make()
        driver.protocol.reset = Mock(side_effect=AssertionError("no compensating motion"))
        with self.assertRaises(PointingError) as failure:
            driver.close(deadline=time.monotonic() - 1)
        self.assertEqual(failure.exception.primary, "close-deadline")
        self.assertFalse(native.opened)
        self.assertTrue(driver._pointing_closed)
        driver.close(deadline=deadline)
        self.assertEqual(native.closes, 1)
        self.assertEqual(native.writes, [])
        driver.protocol.reset.assert_not_called()

    def test_close_failure_retains_release_debt_and_blocks_commands(self):
        driver, native, handle, deadline, cancel = self.make()
        native.close_failure = True
        with self.assertRaises(PointingError) as failure:
            driver.close(deadline=deadline)
        self.assertEqual(failure.exception.primary, "close-io")
        self.assertTrue(native.opened)
        self.assertFalse(driver._pointing_closed)
        self.assertTrue(driver._pointing_blocked)
        native.close_failure = False
        driver.close(deadline=deadline)
        self.assertFalse(native.opened)


    def test_public_context_is_read_only_and_checks_the_seal(self):
        for proto, expected in ((PTCR20(), ("PTCR20", 10, None)),
                                (PTCR96(), ("PTCR96", 100, 0))):
            native = RecordingSerial(proto)
            with patch("serialptu.ptu.serial.Serial", return_value=native):
                driver = PTU(proto, "recording-only", pointing=True)
            self.assertEqual(driver.pointing_context, expected)
            with self.assertRaises(AttributeError):
                driver.pointing_context = expected
            deadline = time.monotonic() + 1
            driver.bind_pointing(bytes(32), deadline=deadline, cancel=threading.Event())
            self.assertEqual(driver.pointing_context, expected)
            native.baudrate += 1
            with self.assertRaises(PointingError):
                _ = driver.pointing_context
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
            self.assertEqual(native.opens, 0)
            driver.close(deadline=deadline)

    def test_close_lock_timeout_retains_release_debt_and_blocks_future_writes(self):
        driver, native, handle, deadline, cancel = self.make()
        entered = threading.Event()
        release = threading.Event()

        def holder():
            with driver._lock:
                entered.set()
                release.wait(1)

        thread = threading.Thread(target=holder)
        thread.start()
        try:
            self.assertTrue(entered.wait(0.5))
            with self.assertRaises(PointingError) as failure:
                driver.close(deadline=time.monotonic() - 1)
            self.assertEqual(failure.exception.primary, "close-deadline")
            self.assertTrue(native.opened)
            self.assertFalse(driver._pointing_closed)
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
        finally:
            release.set()
            thread.join(0.5)
            self.assertFalse(thread.is_alive())
        driver.close(deadline=deadline)
        self.assertFalse(native.opened)


    def test_invalidation_completion_shares_the_prewrite_lock_and_survives_restore(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        before_write = threading.Event()
        permit_write = threading.Event()
        invalidation_waiting = threading.Event()
        invalidation_completed = threading.Event()
        failures = []
        order = []
        original_lock = driver._lock
        original_write = native.write
        invalidator_identity = []

        class ObservedLock:
            def acquire(self, *args, **kwargs):
                if invalidator_identity and threading.get_ident() == invalidator_identity[0]:
                    invalidation_waiting.set()
                return original_lock.acquire(*args, **kwargs)

            def release(self):
                return original_lock.release()

        def paused_write(packet):
            before_write.set()
            if not permit_write.wait(1):
                raise AssertionError('prewrite barrier was not released')
            order.append('write')
            return original_write(packet)

        def sender():
            try:
                self.submit(driver, handle, prepared, deadline, cancel)
            except BaseException as error:
                failures.append(('sender', error))

        def invalidator():
            invalidator_identity.append(threading.get_ident())
            try:
                driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
                order.append('invalidation')
                invalidation_completed.set()
                native.baudrate += 1
                native.baudrate -= 1
            except BaseException as error:
                failures.append(('invalidator', error))

        driver._lock = ObservedLock()
        native.write = paused_write
        send_thread = threading.Thread(target=sender)
        invalidate_thread = threading.Thread(target=invalidator)
        send_thread.start()
        try:
            self.assertTrue(before_write.wait(0.5))
            invalidate_thread.start()
            self.assertTrue(invalidation_waiting.wait(0.5))
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
            self.assertFalse(invalidation_completed.is_set())
            self.assertEqual(driver._pointing_generation, prepared.generation)
            self.assertEqual(native.writes, [])
        finally:
            permit_write.set()
            send_thread.join(0.5)
            if invalidate_thread.ident is not None:
                invalidate_thread.join(0.5)
            self.assertFalse(send_thread.is_alive())
            self.assertFalse(invalidate_thread.is_alive())
        self.assertEqual(order, ['write', 'invalidation'])
        self.assertTrue(invalidation_completed.is_set())
        self.assertEqual(len(failures), 1)
        self.assertEqual(failures[0][0], 'sender')
        self.assertIs(type(failures[0][1]), PointingError)
        self.assertEqual(failures[0][1].submission, 'complete')
        self.assertNotEqual(driver._pointing_generation, prepared.generation)
        self.assertEqual(native.writes, [prepared.packet])
        with self.assertRaises(PointingError):
            self.submit(driver, handle, prepared, deadline, cancel)
        with self.assertRaises(PointingError):
            self.prepare(driver, handle, deadline, cancel)
        self.assertEqual(native.writes, [prepared.packet])

    def test_timed_out_invalidation_requests_stop_without_claiming_completion(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        entered = threading.Event()
        release = threading.Event()

        def holder():
            with driver._lock:
                entered.set()
                release.wait(1)

        thread = threading.Thread(target=holder)
        thread.start()
        try:
            self.assertTrue(entered.wait(0.5))
            with self.assertRaises(PointingError) as failure:
                driver.invalidate_pointing(handle, deadline=time.monotonic() + 0.02, cancel=cancel)
            self.assertEqual(failure.exception.primary, 'deadline')
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
            self.assertEqual(driver._pointing_generation, prepared.generation)
        finally:
            release.set()
            thread.join(0.5)
            self.assertFalse(thread.is_alive())
        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
        self.assertTrue(driver._pointing_blocked)
        self.assertNotEqual(driver._pointing_generation, prepared.generation)
        self.assertEqual(native.writes, [])


    def test_public_availability_is_nonreserving_and_false_for_every_nonfresh_state(self):
        for state in ('fresh', 'bound', 'requested', 'invalidated', 'closed', 'invalid-profile', 'legacy'):
            with self.subTest(state=state):
                proto = PTCR20()
                native = RecordingSerial(proto)
                strict = state != 'legacy'
                with patch('serialptu.ptu.serial.Serial', return_value=native):
                    driver = PTU(proto, 'recording-only', pointing=strict, logger=Mock())
                deadline = time.monotonic() + 1
                cancel = threading.Event()
                if state in ('bound', 'invalidated'):
                    handle = driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
                    if state == 'invalidated':
                        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
                elif state == 'requested':
                    driver._pointing_stop_requested = True
                elif state == 'closed':
                    driver.close(deadline=deadline)
                elif state == 'invalid-profile':
                    proto._degree_factor = 999
                before = (native.opens, native.closes, driver._pointing_handle,
                          driver._pointing_stop_requested, driver._pointing_generation)
                self.assertIs(driver.pointing_available, state == 'fresh')
                self.assertIs(driver.pointing_available, state == 'fresh')
                with self.assertRaises(AttributeError):
                    driver.pointing_available = True
                self.assertEqual(before, (native.opens, native.closes, driver._pointing_handle,
                                          driver._pointing_stop_requested, driver._pointing_generation))
                self.assertEqual(native.writes, [])
                if strict:
                    driver.close(deadline=deadline)
                else:
                    driver.close()


class SelectedBenchDriverTests(unittest.TestCase):
    def make(self, capability='readback', opened=True, bound=True):
        proto = PTCR20()
        native = RecordingSerial(proto)
        settings = SerialSettings('/dev/serial/by-id/usb-recording-only', 9600, 8, 'N', 1,
                                  False, False, False, True, True)
        identity = SerialDeviceIdentity('067b', '23a3', 'recording-only', '00', 'pl2303')
        with patch('serialptu.ptu.serial.Serial', return_value=native) as factory:
            driver = PTU(proto, settings.port, baud=9600, pointing=True, serial_settings=settings,
                         device_identity=identity, serial_capability=capability)
        factory.assert_called_once_with(baudrate=9600, timeout=0, exclusive=True)
        self.assertEqual((native.opens, native.writes), (0, []))
        deadline, cancel = time.monotonic() + 2, threading.Event()
        handle = None
        if bound:
            bind = driver.bind_readback if capability == 'readback' else driver.bind_manual
            handle = bind(bytes(32), deadline=deadline, cancel=cancel)
        if opened:
            self.open(driver, deadline, cancel)

        def release():
            native.close_failure = False
            driver.close(deadline=time.monotonic() + 1)

        self.addCleanup(release)
        return driver, native, handle, deadline, cancel

    def open(self, driver, deadline, cancel):
        snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
        with patch('serialptu.ptu.verify_selected_device', return_value=snapshot) as verify, \
                patch('serialptu.ptu.claim_selected_device') as claim:
            driver.open_bounded(deadline=deadline, cancel=cancel)
        verify.assert_called_once_with(driver.readback_context.serial_settings,
                                       driver.readback_context.device_identity)
        claim.assert_called_once()

    @contextmanager
    def establishment_clock(self, cancel):
        now = [time.monotonic()]

        def wait(seconds):
            now[0] += seconds
            return cancel.is_set()

        with patch('serialptu.ptu.time.monotonic', side_effect=lambda: now[0]), \
                patch.object(cancel, 'wait', side_effect=wait):
            yield now

    def interrupted_manual_jog(self, prefix_length=1, response=None):
        driver, native, handle, deadline, cancel = self.make('manual')
        response = acknowledgement(driver.protocol, 0x31, 123, 456) if response is None else response
        native.auto_ack = False
        original_read = native.read
        consumed = []

        def write():
            native.response.extend(response)
            if prefix_length == 0:
                cancel.set()

        def read(count):
            value = original_read(count)
            consumed.extend(value)
            if len(consumed) == prefix_length:
                cancel.set()
            return value

        native.on_write, native.read = write, read
        packet = driver.prepare_jog(handle, 0, 1, deadline=deadline, cancel=cancel)
        with self.assertRaisesRegex(PointingError, '^cancelled$'):
            with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
                driver.submit_prepared_jog(handle, packet, deadline=deadline, cancel=cancel)
        native.on_write, native.read, native.auto_ack = None, original_read, True
        self.assertEqual(driver.last_exchange.response, response[:prefix_length])
        return driver, native, handle, deadline, threading.Event(), response

    def test_stop_reconciles_cancelled_jog_prefix_before_separate_ack_and_fresh_status(self):
        for prefix_length in (0, 1, 4, 11):
            with self.subTest(prefix_length=prefix_length):
                driver, native, handle, deadline, cancel, old_response = self.interrupted_manual_jog(prefix_length)
                previous = driver.last_exchange
                self.assertTrue(driver.jog_stop_pending)
                self.assertFalse(driver.jog_stop_reconciled)
                self.assertFalse(driver._pointing_blocked)
                with self.assertRaises(PointingError):
                    driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)
                with self.assertRaises(PointingError):
                    driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
                stopped = acknowledgement(driver.protocol, 0x31, 321, -45)
                native.auto_ack = False
                native.on_write = lambda: native.response.extend(stopped)
                original_read = native.read

                def read(count):
                    self.assertEqual(len(native.writes), 2)
                    return original_read(count)

                native.read = read
                result = driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                receipt = driver.last_exchange
                self.assertEqual((result[1]['pan'], result[1]['tilt']), (32.1, -4.5))
                self.assertEqual(receipt.interrupted_sequence, previous.sequence)
                self.assertEqual(receipt.interrupted_response_prefix, old_response[:prefix_length])
                self.assertEqual(receipt.interrupted_response, old_response)
                self.assertEqual(receipt.response, stopped)
                self.assertEqual((receipt.operation, receipt.category, receipt.submission, receipt.written),
                                 ('stop', 'ok', 'complete', 10))
                self.assertEqual(native.writes, [bytes.fromhex('02310000ff0000ce03'),
                                                  bytes.fromhex('02311b82000000003303')])
                self.assertEqual(previous.response, old_response[:prefix_length])
                self.assertTrue(driver.jog_stop_pending)
                self.assertTrue(driver.jog_stop_reconciled)
                with self.assertRaises(PointingError):
                    driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)
                native.read, native.on_write, native.auto_ack = original_read, None, True
                driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertFalse(driver.jog_stop_pending)
                self.assertFalse(driver.jog_stop_reconciled)
                self.assertFalse(driver._pointing_blocked)
                packet = driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)
                with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
                    driver.submit_prepared_jog(handle, packet, deadline=deadline, cancel=cancel)
                self.assertEqual(len(native.writes), 4)

    def test_stop_is_written_before_waiting_for_a_late_interrupted_jog_tail(self):
        driver, native, handle, unused_deadline, cancel, old_response = self.interrupted_manual_jog()
        native.response.clear()
        native.auto_ack = False
        stopped = acknowledgement(driver.protocol, 0x31, 124, 457)
        original_read = native.read
        with self.establishment_clock(cancel) as now:
            started = now[0]
            scheduled = [(started + .2, old_response[1:]), (started + .4, stopped)]

            def read(count):
                self.assertEqual(len(native.writes), 2)
                if scheduled and now[0] >= scheduled[0][0]:
                    native.response.extend(scheduled.pop(0)[1])
                return original_read(count)

            native.read = read
            result = driver.stop_bounded(handle, deadline=started + 1, cancel=cancel)
            self.assertGreaterEqual(now[0] - started, .4)
        self.assertEqual((result[1]['pan'], result[1]['tilt']), (12.4, 45.7))
        self.assertEqual(driver.last_exchange.interrupted_response, old_response)
        self.assertEqual(driver.last_exchange.response, stopped)
        self.assertTrue(driver.jog_stop_reconciled)

    def test_stop_cannot_promote_a_single_old_or_stop_reply_to_confirmation(self):
        for missing in ('jog', 'stop'):
            with self.subTest(missing=missing):
                driver, native, handle, unused_deadline, cancel, old_response = self.interrupted_manual_jog(0)
                if missing == 'jog':
                    native.response.clear()
                else:
                    native.auto_ack = False
                with self.establishment_clock(cancel) as now:
                    with self.assertRaisesRegex(PointingError, '^deadline$'):
                        driver.stop_bounded(handle, deadline=now[0] + .3, cancel=cancel)
                self.assertEqual(len(native.writes), 2)
                self.assertEqual(driver.last_exchange.response, b'')
                self.assertTrue(driver.last_exchange.interrupted_response)
                self.assertEqual(driver.last_exchange.submission, 'complete')
                self.assertFalse(driver.jog_stop_reconciled)
                self.assertTrue(driver._pointing_blocked)

    def test_stop_reconciliation_retains_malformed_old_and_stop_replies(self):
        for malformed in ('jog', 'stop'):
            with self.subTest(malformed=malformed):
                driver, native, handle, deadline, cancel, old_response = self.interrupted_manual_jog()
                corrupt = b'\x06\x31\x00\x03'
                if malformed == 'jog':
                    native.response[:] = corrupt[1:]
                else:
                    native.auto_ack = False
                    native.on_write = lambda: native.response.extend(corrupt)
                with self.assertRaisesRegex(PointingError, '^strict-checksum$'):
                    driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertEqual(len(native.writes), 2)
                self.assertEqual(driver.last_exchange.interrupted_response,
                                 corrupt if malformed == 'jog' else old_response)
                self.assertEqual(driver.last_exchange.response, b'' if malformed == 'jog' else corrupt)
                self.assertTrue(driver._pointing_blocked)
                self.assertFalse(driver.jog_stop_reconciled)

    def test_stop_never_accepts_extra_prewrite_bytes_after_the_interrupted_reply(self):
        for prefix_length in (4, 11):
            with self.subTest(prefix_length=prefix_length):
                driver, native, handle, deadline, cancel, old_response = self.interrupted_manual_jog(prefix_length)
                unknown = acknowledgement(driver.protocol, 0x31, 222, 333)
                native.response.extend(unknown)
                native.auto_ack = False
                with self.assertRaisesRegex(PointingError, '^stale-response$'):
                    driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertEqual(len(native.writes), 2)
                self.assertEqual(driver.last_exchange.interrupted_response, old_response)
                self.assertEqual(driver.last_exchange.response, b'')
                self.assertEqual(bytes(native.response), unknown)
                self.assertEqual(driver.last_exchange.submission, 'complete')
                self.assertFalse(driver.jog_stop_reconciled)
                self.assertTrue(driver._pointing_blocked)
                with self.assertRaises(PointingError):
                    driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)

    def test_stop_reconciliation_cancellation_retains_each_received_byte(self):
        for stage in ('jog', 'stop'):
            with self.subTest(stage=stage):
                driver, native, handle, deadline, cancel, old_response = self.interrupted_manual_jog()
                original_read = native.read
                received = []
                cancel_at = 1 if stage == 'jog' else len(old_response)

                def read(count):
                    value = original_read(count)
                    received.extend(value)
                    if len(received) == cancel_at:
                        cancel.set()
                    return value

                native.read = read
                with self.assertRaisesRegex(PointingError, '^cancelled$'):
                    driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertEqual(len(native.writes), 2)
                self.assertEqual(driver.last_exchange.interrupted_response,
                                 old_response[:2] if stage == 'jog' else old_response)
                self.assertEqual(driver.last_exchange.response, b'' if stage == 'jog' else b'\x06')
                self.assertTrue(driver._pointing_blocked)
                self.assertFalse(driver.jog_stop_reconciled)

    def test_stop_reconciliation_preserves_device_faults_and_requires_stationary_fresh_status(self):
        for fault_stage in ('jog', 'stop', 'status-axis', 'status-motion'):
            with self.subTest(fault_stage=fault_stage):
                fault = acknowledgement(PTCR20(), 0x31, status=b'\x08\x00\x00')
                driver, native, handle, deadline, cancel, old_response = self.interrupted_manual_jog(
                    response=fault if fault_stage == 'jog' else None)
                if fault_stage == 'stop':
                    native.auto_ack = False
                    native.on_write = lambda: native.response.extend(fault)
                if fault_stage in ('jog', 'stop'):
                    with self.assertRaisesRegex(PointingError, '^strict-status$'):
                        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                else:
                    driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                    raw = b'\x04\x00\x00' if fault_stage == 'status-axis' else b'\x00\x00\x02'
                    response = acknowledgement(driver.protocol, 0x31, status=raw)
                    native.auto_ack = False
                    native.on_write = lambda: native.response.extend(response)
                    with self.assertRaisesRegex(PointingError, '^strict-status$'):
                        driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertTrue(driver._pointing_blocked)
                self.assertTrue(driver.jog_stop_pending)
                with self.assertRaises(PointingError):
                    driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)

    def test_manual_soft_limits_allow_interrupted_jog_stop_and_stationary_recovery(self):
        response = acknowledgement(PTCR20(), 0x31, status=b'\xc0\xc0\x00')
        driver, native, handle, deadline, cancel, old_response = self.interrupted_manual_jog(response=response)
        native.auto_ack = False
        native.on_write = lambda: native.response.extend(response)
        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(driver.last_exchange.interrupted_response, response)
        self.assertEqual(driver.last_exchange.response, response)
        self.assertTrue(driver.jog_stop_reconciled)
        result = driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(result[1]['status_bytes'], b'\xc0\xc0\x00')
        self.assertFalse(driver.jog_stop_pending)
        self.assertFalse(driver._pointing_blocked)

    def test_normal_manual_stop_rejects_true_axis_faults_but_accepts_soft_limits(self):
        for raw, fatal in ((b'\xc0\xc0\x00', False), (b'\x08\x00\x00', True),
                           (b'\x00\x20\x00', True), (b'\x01\x00\x00', True)):
            with self.subTest(raw=raw):
                driver, native, handle, deadline, cancel = self.make('manual')
                response = acknowledgement(driver.protocol, 0x31, status=raw)
                native.auto_ack = False
                native.on_write = lambda: native.response.extend(response)
                if fatal:
                    with self.assertRaisesRegex(PointingError, '^strict-status$'):
                        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                else:
                    self.assertEqual(driver.stop_bounded(handle, deadline=deadline, cancel=cancel)[1]['status_bytes'], raw)
                self.assertEqual(driver.last_exchange.response, response)
                self.assertEqual(driver._pointing_blocked, fatal)
                native.on_write, native.auto_ack = None, True
                driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertEqual(driver._pointing_blocked, fatal)
                if fatal:
                    with self.assertRaises(PointingError):
                        driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)

    def test_stop_keeps_unknown_incomplete_overflow_and_short_write_outcomes_blocked(self):
        for mode, category in (('unknown', 'stale-response'), ('incomplete', 'deadline'),
                               ('overflow', 'response'), ('short-write', 'short-write')):
            with self.subTest(mode=mode):
                if mode == 'unknown':
                    driver, native, handle, unused_deadline, cancel = self.make('manual')
                    native.response.extend(acknowledgement(driver.protocol, 0x31))
                else:
                    driver, native, handle, unused_deadline, cancel, old_response = self.interrupted_manual_jog()
                    if mode == 'incomplete':
                        native.response.clear()
                    elif mode == 'overflow':
                        native.response[:] = bytes(65)
                    else:
                        native.result = 2
                native.auto_ack = False
                before = bytes(native.response)
                with self.establishment_clock(cancel) as now:
                    with self.assertRaisesRegex(PointingError, '^' + category + '$'):
                        driver.stop_bounded(handle, deadline=now[0] + .2, cancel=cancel)
                self.assertEqual(len(native.writes), 1 if mode == 'unknown' else 2)
                self.assertEqual(driver.last_exchange.response, b'')
                self.assertEqual(driver.last_exchange.response_truncated, mode == 'overflow')
                if mode == 'unknown':
                    self.assertIsNone(driver.last_exchange.interrupted_sequence)
                    self.assertEqual(bytes(native.response), before)
                elif mode == 'overflow':
                    self.assertEqual(driver.last_exchange.interrupted_response, b'\x06' + bytes(63))
                else:
                    self.assertEqual(driver.last_exchange.interrupted_response, b'\x06')
                    if mode == 'short-write':
                        self.assertEqual(bytes(native.response), before)
                self.assertTrue(driver._pointing_blocked)
                self.assertFalse(driver.jog_stop_reconciled)

    def test_reconciled_stop_cannot_clear_a_separate_invalidation(self):
        driver, native, handle, deadline, cancel, old_response = self.interrupted_manual_jog()
        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertTrue(driver.jog_stop_reconciled)
        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
        generation = driver._pointing_generation
        driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertTrue(driver._pointing_blocked)
        self.assertTrue(driver._pointing_stop_requested)
        self.assertTrue(driver.jog_stop_pending)
        self.assertEqual(driver._pointing_generation, generation)
        with self.assertRaises(PointingError):
            driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)

    def test_establishment_allows_cold_open_and_delayed_initial_feedback(self):
        driver, native, handle, unused_deadline, cancel = self.make('manual', opened=False)
        native.auto_ack = False
        response = acknowledgement(driver.protocol, 0x31, -123, 456)
        original_read = native.read
        sent_at = []
        with self.establishment_clock(cancel) as now:
            started = now[0]
            native.on_open = lambda: now.__setitem__(0, now[0] + .8)
            native.on_write = lambda: sent_at.append(now[0])

            def read(count):
                if now[0] >= sent_at[0] + .4 and not native.response:
                    native.response.extend(response)
                return original_read(count)

            native.read = read
            self.open(driver, started + 5, cancel)
            result = driver.establish_bounded(handle, deadline=started + 5, cancel=cancel)
            self.assertGreater(now[0] - started, 1)
            self.assertLess(now[0] - started, 1.3)
        self.assertEqual((result[1]['pan'], result[1]['tilt']), (-12.3, 45.6))
        self.assertEqual(native.writes, [bytes.fromhex('02 31 00 00 00 00 00 31 03')])
        self.assertEqual(driver.establishment_exchanges, (driver.last_exchange,))
        self.assertEqual(driver.last_exchange.response, response)
        self.assertEqual(driver.last_exchange.category, 'ok')
        self.assertFalse(driver._pointing_blocked)
        driver.close(deadline=time.monotonic() + 1)
        self.assertEqual((native.opens, native.closes, len(native.writes)), (1, 1, 1))

    def test_establishment_retries_lost_probe_and_retains_late_unsequenced_feedback(self):
        for arrival in ('second-probe', 'late-first-probe'):
            with self.subTest(arrival=arrival):
                driver, native, handle, unused_deadline, cancel = self.make()
                native.auto_ack = False
                response = acknowledgement(driver.protocol, 0x31, 789, -123)
                original_read = native.read
                delivered = []
                with self.establishment_clock(cancel) as now:
                    started = now[0]

                    def read(count):
                        ready = (len(native.writes) == 2 if arrival == 'second-probe'
                                 else now[0] >= started + .75)
                        if ready and not delivered:
                            delivered.append(True)
                            native.response.extend(response)
                        return original_read(count)

                    native.read = read
                    result = driver.establish_bounded(handle, deadline=started + 5, cancel=cancel)
                self.assertEqual((result[1]['pan'], result[1]['tilt']), (78.9, -12.3))
                self.assertEqual(len(native.writes), 2)
                first, final = driver.establishment_exchanges
                self.assertEqual((first.sequence, first.category, first.response), (1, 'deadline', b''))
                self.assertEqual((final.sequence, final.category, final.response), (2, 'ok', response))
                for receipt in (first, final):
                    self.assertEqual((receipt.request, receipt.submission, receipt.written),
                                     (native.writes[0], 'complete', 9))
                    self.assertFalse(receipt.response_truncated)
                self.assertEqual(native.writes[0], native.writes[1])
                self.assertLessEqual(first.finished_monotonic, final.started_monotonic)
                self.assertIs(driver.last_exchange, final)
                self.assertFalse(driver._pointing_blocked)

    def test_establishment_settles_late_replies_before_normal_status(self):
        driver, native, handle, unused_deadline, cancel = self.make('manual')
        native.auto_ack = False
        first = acknowledgement(driver.protocol, 0x31, 100, 200)
        second = acknowledgement(driver.protocol, 0x31, 110, 210)
        original_read = native.read
        scheduled = []
        with self.establishment_clock(cancel) as now:
            started = now[0]
            native.on_write = lambda: scheduled.append((now[0] + .6, first if len(native.writes) == 1 else second))

            def read(count):
                while scheduled and now[0] >= scheduled[0][0]:
                    native.response.extend(scheduled.pop(0)[1])
                return original_read(count)

            native.read = read
            result = driver.establish_bounded(handle, deadline=started + 5, cancel=cancel)
            self.assertGreaterEqual(now[0] - started, 1.59)
            self.assertLess(now[0] - started, 1.65)
            self.assertEqual((result[1]['pan'], result[1]['tilt']), (11, 21))
            self.assertEqual(len(native.writes), 2)
            self.assertEqual(driver.establishment_exchanges[-1].response, first + second)
            self.assertEqual((scheduled, bytes(native.response)), ([], b''))
            native.on_write, native.auto_ack = None, True
            result = driver.observe_bounded(handle, deadline=now[0] + 1, cancel=cancel)
        self.assertEqual((result[1]['pan'], result[1]['tilt']), (0, 0))
        self.assertEqual(driver.last_exchange.category, 'ok')
        self.assertEqual(len(native.writes), 3)
        self.assertFalse(driver._pointing_blocked)

    def test_establishment_partial_or_malformed_tail_never_admits_earlier_valid_feedback(self):
        for tail, category in ((b'\x06\x31', 'deadline'),
                               (b'\x06\x31\x00\x03', 'strict-checksum')):
            with self.subTest(category=category):
                driver, native, handle, unused_deadline, cancel = self.make()
                native.auto_ack = False
                response = acknowledgement(driver.protocol, 0x31, 100, 200)
                original_read = native.read
                with self.establishment_clock(cancel) as now:
                    started = now[0]
                    fragments = [(started + .6, response), (started + .85, tail)]

                    def read(count):
                        if fragments and now[0] >= fragments[0][0]:
                            native.response.extend(fragments.pop(0)[1])
                        return original_read(count)

                    native.read = read
                    with self.assertRaisesRegex(PointingError, '^' + category + '$'):
                        driver.establish_bounded(handle, deadline=started + 5, cancel=cancel)
                self.assertEqual(len(native.writes), 2)
                self.assertEqual(len(driver.establishment_exchanges), 2)
                self.assertEqual(driver.last_exchange.response, response + tail)
                self.assertEqual(driver.last_exchange.category, category)
                self.assertTrue(driver._pointing_blocked)

    def test_establishment_settling_honors_deadline_and_cancellation(self):
        for category in ('deadline', 'cancelled'):
            with self.subTest(category=category):
                driver, native, handle, unused_deadline, cancel = self.make()
                native.auto_ack = False
                response = acknowledgement(driver.protocol, 0x31)
                original_read = native.read
                delivered = []
                with self.establishment_clock(cancel) as now:
                    started = now[0]

                    def read(count):
                        if now[0] >= started + .6 and not delivered:
                            native.response.extend(response)
                            delivered.append(True)
                        return original_read(count)

                    native.read = read
                    if category == 'cancelled':
                        def wait(seconds):
                            now[0] += seconds
                            if now[0] >= started + .8:
                                cancel.set()
                            return cancel.is_set()

                        cancel.wait.side_effect = wait
                    with self.assertRaisesRegex(PointingError, '^' + category + '$'):
                        driver.establish_bounded(handle, deadline=started + 1, cancel=cancel)
                    self.assertLessEqual(now[0] - started, 1 + 1e-6)
                self.assertEqual(len(native.writes), 2)
                self.assertEqual(driver.last_exchange.response, response)
                self.assertEqual(driver.last_exchange.category, category)
                self.assertTrue(driver._pointing_blocked)

    def test_establishment_rechecks_controls_after_the_quiet_boundary(self):
        for category in ('deadline', 'cancelled'):
            with self.subTest(category=category):
                driver, native, handle, unused_deadline, cancel = self.make()
                native.auto_ack = False
                response = acknowledgement(driver.protocol, 0x31)
                native.on_write = lambda: native.response.extend(response if len(native.writes) == 2 else b'')
                with self.establishment_clock(cancel) as now:
                    started = now[0]

                    def queued(serial):
                        if now[0] >= started + .9:
                            if category == 'cancelled':
                                cancel.set()
                            else:
                                now[0] = started + 2.1
                        return len(serial.response)

                    with patch.object(RecordingSerial, 'in_waiting', property(queued)):
                        with self.assertRaisesRegex(PointingError, '^' + category + '$'):
                            driver.establish_bounded(handle, deadline=started + 2, cancel=cancel)
                self.assertEqual(len(native.writes), 2)
                self.assertEqual(driver.last_exchange.response, response)
                self.assertEqual(driver.last_exchange.category, category)
                self.assertTrue(driver._pointing_blocked)

    def test_establishment_bounds_cumulative_feedback_and_preserves_overflow_evidence(self):
        driver, native, handle, unused_deadline, cancel = self.make()
        native.auto_ack = False
        response = acknowledgement(driver.protocol, 0x31) * 7
        native.on_write = lambda: native.response.extend(response if len(native.writes) == 2 else b'')
        with self.establishment_clock(cancel) as now:
            with self.assertRaisesRegex(PointingError, '^response$'):
                driver.establish_bounded(handle, deadline=now[0] + 5, cancel=cancel)
        self.assertEqual(len(native.writes), 2)
        self.assertEqual(len(driver.establishment_exchanges), 2)
        self.assertEqual(driver.last_exchange.response, response[:64])
        self.assertTrue(driver.last_exchange.response_truncated)
        self.assertEqual(driver.last_exchange.category, 'response')
        self.assertTrue(driver._pointing_blocked)

    def test_establishment_partial_frame_stops_probes_until_complete_or_overall_deadline(self):
        for complete in (True, False):
            with self.subTest(complete=complete):
                driver, native, handle, unused_deadline, cancel = self.make()
                native.auto_ack = False
                response = acknowledgement(driver.protocol, 0x31, -100, 200)
                original_read = native.read
                with self.establishment_clock(cancel) as now:
                    started = now[0]
                    fragments = [(started + .4, response[:3])]
                    if complete:
                        fragments.append((started + .85, response[3:]))

                    def read(count):
                        if fragments and now[0] >= fragments[0][0]:
                            native.response.extend(fragments.pop(0)[1])
                        return original_read(count)

                    native.read = read
                    if complete:
                        result = driver.establish_bounded(handle, deadline=started + 5, cancel=cancel)
                        self.assertEqual((result[1]['pan'], result[1]['tilt']), (-10, 20))
                        self.assertGreaterEqual(now[0] - started, .85)
                    else:
                        with self.assertRaisesRegex(PointingError, '^deadline$'):
                            driver.establish_bounded(handle, deadline=started + 5, cancel=cancel)
                        self.assertAlmostEqual(now[0] - started, 5)
                self.assertEqual(len(native.writes), 1)
                self.assertEqual(driver.establishment_exchanges, (driver.last_exchange,))
                self.assertEqual(driver.last_exchange.response, response if complete else response[:3])
                self.assertEqual(driver.last_exchange.category, 'ok' if complete else 'deadline')
                self.assertEqual(driver._pointing_blocked, not complete)

    def test_establishment_reads_feedback_arriving_at_the_resend_boundary(self):
        driver, native, handle, unused_deadline, cancel = self.make()
        native.auto_ack = False
        response = acknowledgement(driver.protocol, 0x31, 123, -456)
        delivered = []
        with self.establishment_clock(cancel) as now:
            started = now[0]

            def queued(serial):
                if now[0] >= started + .5 and not delivered:
                    delivered.append(True)
                    serial.response.extend(response)
                return len(serial.response)

            with patch.object(RecordingSerial, 'in_waiting', property(queued)):
                result = driver.establish_bounded(handle, deadline=started + 5, cancel=cancel)
        self.assertEqual((result[1]['pan'], result[1]['tilt']), (12.3, -45.6))
        self.assertEqual(len(native.writes), 1)
        self.assertEqual(driver.establishment_exchanges, (driver.last_exchange,))
        self.assertEqual((driver.last_exchange.response, driver.last_exchange.category), (response, 'ok'))

    def test_establishment_empty_feedback_stops_at_five_seconds_with_ten_receipts(self):
        driver, native, handle, unused_deadline, cancel = self.make()
        native.auto_ack = False
        with self.establishment_clock(cancel) as now:
            started = now[0]
            with self.assertRaisesRegex(PointingError, '^deadline$') as caught:
                driver.establish_bounded(handle, deadline=started + 20, cancel=cancel)
            self.assertAlmostEqual(now[0] - started, 5)
        self.assertEqual(caught.exception.submission, 'complete')
        self.assertEqual(len(native.writes), 10)
        self.assertEqual(tuple(receipt.sequence for receipt in driver.establishment_exchanges), tuple(range(1, 11)))
        for receipt in driver.establishment_exchanges:
            self.assertEqual((receipt.operation, receipt.category, receipt.submission, receipt.written),
                             ('status', 'deadline', 'complete', 9))
            self.assertEqual((receipt.request, receipt.response), (native.writes[0], b''))
            self.assertFalse(receipt.response_truncated)
        self.assertTrue(driver._pointing_blocked)

    def test_establishment_honors_shorter_deadline_and_cancellation_before_another_probe(self):
        for outcome in ('deadline', 'cancelled'):
            with self.subTest(outcome=outcome):
                driver, native, handle, unused_deadline, cancel = self.make()
                native.auto_ack = False
                with self.establishment_clock(cancel) as now:
                    started = now[0]
                    if outcome == 'cancelled':
                        def wait(seconds):
                            now[0] += seconds
                            if now[0] >= started + .49:
                                cancel.set()
                            return cancel.is_set()

                        cancel.wait.side_effect = wait
                    with self.assertRaisesRegex(PointingError, '^' + outcome + '$'):
                        driver.establish_bounded(handle, deadline=started + .7, cancel=cancel)
                    self.assertLessEqual(now[0] - started, .7 + 1e-6)
                self.assertEqual(len(native.writes), 2 if outcome == 'deadline' else 1)
                self.assertEqual(len(driver.establishment_exchanges), len(native.writes))
                self.assertEqual(driver.last_exchange.category, outcome)
                self.assertEqual(driver.last_exchange.response, b'')
                self.assertTrue(driver._pointing_blocked)

    def test_establishment_terminal_responses_and_uncertain_writes_never_retry(self):
        cases = (('short-write', 2, b'', 'partial'),
                 ('serial-io', OSError('fixture'), b'', 'unknown'),
                 ('strict-nak', None, b'\x15', 'complete'),
                 ('strict-checksum', None, b'\x06\x31\x00\x03', 'complete'),
                 ('stale-response', None, b'\x06', 'none'))
        for category, write_result, supplied, submission in cases:
            with self.subTest(category=category):
                driver, native, handle, deadline, cancel = self.make('manual')
                native.auto_ack, native.result = False, write_result
                if category == 'strict-nak':
                    supplied += acknowledgement(driver.protocol, 0x31)[1:]
                if category == 'stale-response':
                    native.response.extend(supplied)
                else:
                    native.on_write = lambda supplied=supplied: native.response.extend(supplied)
                with self.assertRaisesRegex(PointingError, '^' + category + '$'):
                    driver.establish_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertEqual(len(native.writes), 0 if category == 'stale-response' else 1)
                self.assertEqual(driver.establishment_exchanges, (driver.last_exchange,))
                self.assertEqual((driver.last_exchange.category, driver.last_exchange.submission),
                                 (category, submission))
                self.assertEqual(driver.last_exchange.response, b'' if category == 'stale-response' else supplied)
                self.assertTrue(driver._pointing_blocked)
                with self.assertRaises(PointingError):
                    driver.establish_bounded(handle, deadline=deadline, cancel=cancel)
                with self.assertRaises(PointingError):
                    driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)
                self.assertEqual(len(driver.establishment_exchanges), 1)
                if category == 'stale-response':
                    self.assertEqual(bytes(native.response), supplied)

    def test_establishment_cannot_clear_an_existing_exchange_or_stop_latch(self):
        for previous in ('observed', 'failed-stop', 'invalidated'):
            with self.subTest(previous=previous):
                driver, native, handle, deadline, cancel = self.make('manual')
                if previous == 'observed':
                    driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
                elif previous == 'failed-stop':
                    native.auto_ack, native.result = False, 2
                    with self.assertRaisesRegex(PointingError, '^short-write$'):
                        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                else:
                    driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
                before = (driver._pointing_blocked, driver._pointing_stop_requested,
                          driver._pointing_generation, driver.last_exchange, tuple(native.writes))
                with self.assertRaises(PointingError):
                    driver.establish_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertEqual((driver._pointing_blocked, driver._pointing_stop_requested,
                                  driver._pointing_generation, driver.last_exchange, tuple(native.writes)), before)
                self.assertEqual(driver.establishment_exchanges, ())

    def test_explicit_lines_and_context_are_staged_before_open_without_commands(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        context = driver.readback_context
        self.assertEqual((context.protocol, context.units_per_degree, context.protocol_address),
                         ('PTCR20', 10, None))
        self.assertEqual((native.baudrate, native.bytesize, native.parity, native.stopbits), (9600, 8, 'N', 1))
        self.assertEqual((native.xonxoff, native.rtscts, native.dsrdtr), (False, False, False))
        self.assertEqual((native.rts, native.dtr, native.exclusive), (True, True, True))
        self.assertIsNone(driver.last_exchange)
        self.open(driver, deadline, cancel)
        self.assertEqual(native.port, '/dev/ttyUSB0')
        self.assertEqual(driver.readback_context, context)
        self.assertEqual(native.writes, [])
        self.assertIsNone(driver._keepalive)
        with self.assertRaises(FrozenInstanceError):
            context.protocol = 'PTCR96'
        with self.assertRaises(AttributeError):
            driver.serial_capability = 'manual'

    def test_both_bench_capabilities_reject_tracking_bind_before_open(self):
        for capability in ('readback', 'manual'):
            driver, native, handle, deadline, cancel = self.make(capability, opened=False, bound=False)
            with self.subTest(capability=capability), self.assertRaisesRegex(PointingError, '^readback-only$'):
                driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
            self.assertEqual((native.opens, native.writes, driver._pointing_handle), (0, [], None))

    def test_readback_and_manual_binding_cannot_upgrade_each_other(self):
        for capability in ('readback', 'manual'):
            driver, native, handle, deadline, cancel = self.make(capability, opened=False, bound=False)
            wrong = driver.bind_manual if capability == 'readback' else driver.bind_readback
            with self.subTest(capability=capability), self.assertRaises(PointingError):
                wrong(bytes(32), deadline=deadline, cancel=cancel)
            self.assertEqual((native.opens, native.writes, driver._pointing_handle), (0, [], None))

    def test_readback_rejects_preparation_submission_stop_and_legacy_before_encoder_mutation(self):
        driver, native, handle, deadline, cancel = self.make()
        with patch.object(driver.protocol, 'move_to') as move, \
                patch.object(driver.protocol, 'stop_packet') as stop, \
                patch.object(driver.protocol, 'jog') as jog, \
                patch.object(driver.protocol, 'jog_packet') as strict_jog:
            attempts = (lambda: driver.prepare_move_to(handle, 1, -1, deadline=deadline, cancel=cancel),
                        lambda: driver.submit_prepared_move(handle, None, deadline=deadline, cancel=cancel),
                        lambda: driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel),
                        lambda: driver.submit_prepared_jog(handle, None, deadline=deadline, cancel=cancel),
                        lambda: driver.stop_bounded(handle, deadline=deadline, cancel=cancel),
                        lambda: driver.move_to(1, -1), lambda: driver.jog(1, 0),
                        driver.reset_motor_timeout, driver.move_to_zero, driver.open)
            for attempt in attempts:
                with self.assertRaises(PointingError):
                    attempt()
            move.assert_not_called()
            stop.assert_not_called()
            jog.assert_not_called()
            strict_jog.assert_not_called()
        self.assertEqual(native.writes, [])

    def test_manual_reuses_prepared_encoder_guard_and_zero_jog_stop(self):
        driver, native, handle, deadline, cancel = self.make('manual')
        packet = driver.prepare_move_to(handle, 12.34, -56.78, deadline=deadline, cancel=cancel)
        self.assertEqual((packet.pan_units, packet.tilt_units), (123, -567))
        with self.assertRaisesRegex(PointingError, '^guard-required$'):
            driver.submit_prepared_move(handle, packet, deadline=deadline, cancel=cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            driver.submit_prepared_move(handle, packet, deadline=deadline, cancel=cancel)
        self.assertEqual(native.writes, [packet.packet])
        self.assertEqual(driver.last_exchange.operation, 'move')
        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(native.writes[1], bytes.fromhex('02 31 1b 82 00 00 00 00 33 03'))
        self.assertEqual(driver.last_exchange.operation, 'stop')
        driver.close(deadline=deadline)
        self.assertEqual(len(native.writes), 2)

    def test_manual_jog_requires_same_guard_and_retains_exact_receipt(self):
        driver, native, handle, deadline, cancel = self.make('manual')
        with patch.object(driver.protocol, 'jog_packet', wraps=driver.protocol.jog_packet) as encode:
            prepared = driver.prepare_jog(handle, .5, 0, deadline=deadline, cancel=cancel)
            self.assertEqual((prepared.pan_velocity, prepared.tilt_velocity, prepared.velocity_scale), (64, 0, 127))
            with self.assertRaises(FrozenInstanceError):
                prepared.pan_velocity = 127
            with self.assertRaisesRegex(PointingError, '^guard-required$'):
                driver.submit_prepared_jog(handle, prepared, deadline=deadline, cancel=cancel)
            with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
                with self.assertRaises(PointingError):
                    driver.submit_prepared_jog(handle, prepared, deadline=deadline, cancel=threading.Event())
                result = driver.submit_prepared_jog(handle, prepared, deadline=deadline, cancel=cancel)
            self.assertEqual(encode.call_count, 1)
        self.assertEqual(native.writes, [prepared.packet])
        self.assertEqual(result[1]['message_type'], 'status_response')
        receipt = driver.last_exchange
        self.assertEqual((receipt.operation, receipt.category, receipt.submission), ('jog', 'ok', 'complete'))
        self.assertEqual((receipt.request, receipt.written), (prepared.packet, len(prepared.packet)))
        self.assertEqual(driver.pointing_context, ('PTCR20', 10, None))
        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
        driver.protocol.validate_stop_packet(native.writes[-1])
        driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        driver.protocol.validate_nonmoving_status_packet(native.writes[-1])

    def test_jog_foreign_modified_and_invalidated_preparations_never_write(self):
        driver, native, handle, deadline, cancel = self.make('manual')
        other, other_native, other_handle, unused_deadline, unused_cancel = self.make('manual')
        prepared = driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)
        with other.pointing_guard(other_handle, deadline=deadline, cancel=cancel):
            with self.assertRaisesRegex(PointingError, '^prepared$'):
                other.submit_prepared_jog(other_handle, prepared, deadline=deadline, cancel=cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            with self.assertRaisesRegex(PointingError, '^prepared$'):
                driver.submit_prepared_jog(handle, replace(prepared, pan_velocity=1), deadline=deadline, cancel=cancel)
        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
        with self.assertRaises(PointingError):
            driver.prepare_jog(handle, -1, 0, deadline=deadline, cancel=cancel)
        self.assertEqual((native.writes, other_native.writes), ([], []))

    def test_jog_uncertain_write_is_not_retried_and_stop_keeps_same_owner(self):
        for result, submission in ((0, 'none'), (2, 'partial'), (OSError('fixture'), 'unknown')):
            with self.subTest(submission=submission):
                driver, native, handle, deadline, cancel = self.make('manual')
                prepared = driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)
                native.result, native.auto_ack = result, False
                with self.assertRaises(PointingError) as caught:
                    with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
                        driver.submit_prepared_jog(handle, prepared, deadline=deadline, cancel=cancel)
                self.assertEqual(caught.exception.submission, submission)
                self.assertEqual((driver.last_exchange.operation, driver.last_exchange.submission), ('jog', submission))
                self.assertEqual(native.writes, [prepared.packet])
                native.result, native.auto_ack = None, True
                driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
                self.assertEqual(native.opens, 1)
                self.assertEqual(driver.last_exchange.operation, 'stop')

    def test_jog_cancelled_before_native_write_keeps_receipt_and_can_resume_after_stop(self):
        driver, native, handle, deadline, cancel = self.make('manual')
        prepared = driver.prepare_jog(handle, 1, 0, deadline=deadline, cancel=cancel)

        def cancel_before_write(serial):
            cancel.set()
            return len(serial.response)

        with patch.object(RecordingSerial, 'in_waiting', property(cancel_before_write)):
            with self.assertRaisesRegex(PointingError, '^cancelled$') as caught:
                with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
                    driver.submit_prepared_jog(handle, prepared, deadline=deadline, cancel=cancel)
        self.assertEqual(caught.exception.submission, 'none')
        self.assertEqual((driver.last_exchange.operation, driver.last_exchange.category,
                          driver.last_exchange.submission, driver.last_exchange.written),
                         ('jog', 'cancelled', 'none', None))
        self.assertEqual(native.writes, [])
        fresh_cancel = threading.Event()
        driver.stop_bounded(handle, deadline=deadline, cancel=fresh_cancel)
        prepared = driver.prepare_jog(handle, -1, 0, deadline=deadline, cancel=fresh_cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=fresh_cancel):
            driver.submit_prepared_jog(handle, prepared, deadline=deadline, cancel=fresh_cancel)
        self.assertEqual(driver.last_exchange.category, 'ok')
        self.assertEqual(native.opens, 1)
        self.assertTrue(cancel.is_set())

    def test_jog_cancellation_after_full_write_does_not_poison_stop_controls(self):
        driver, native, handle, deadline, cancel = self.make('manual')
        prepared = driver.prepare_jog(handle, 0, -1, deadline=deadline, cancel=cancel)
        native.on_write, native.auto_ack = cancel.set, False
        with self.assertRaisesRegex(PointingError, '^cancelled$') as caught:
            with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
                driver.submit_prepared_jog(handle, prepared, deadline=deadline, cancel=cancel)
        self.assertEqual(caught.exception.submission, 'complete')
        self.assertEqual(driver.last_exchange.operation, 'jog')
        native.response.extend(acknowledgement(driver.protocol, 0x31))
        native.on_write, native.auto_ack = None, True
        driver.stop_bounded(handle, deadline=deadline, cancel=threading.Event())
        self.assertTrue(cancel.is_set())
        self.assertEqual(driver.last_exchange.operation, 'stop')

    def test_identity_mismatch_refuses_open_and_preserves_passive_cleanup(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        with patch('serialptu.ptu.verify_selected_device', side_effect=AcquisitionError('device-identity')):
            with self.assertRaisesRegex(PointingError, '^device-identity$'):
                driver.open_bounded(deadline=deadline, cancel=cancel)
        self.assertEqual((native.opens, native.writes), (0, []))
        driver.close(deadline=deadline)

    def test_busy_native_owner_is_reported_without_retry_or_write(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
        with patch('serialptu.ptu.verify_selected_device', return_value=snapshot), \
                patch.object(native, 'open', side_effect=SerialException(errno.EAGAIN, 'fixture')) as opening:
            with self.assertRaisesRegex(PointingError, '^device-busy$'):
                driver.open_bounded(deadline=deadline, cancel=cancel)
        opening.assert_called_once_with()
        self.assertEqual(native.writes, [])

    def test_legacy_constructor_requests_same_cooperating_exclusion_and_releases_passively(self):
        native = RecordingSerial(PTCR20())
        with patch('serialptu.ptu.serial.Serial', return_value=native) as factory:
            driver = PTU(native.proto, 'recording-only', baud=9600, logger=Mock())
        factory.assert_called_once_with(baudrate=9600, timeout=0, exclusive=True)
        self.assertEqual(native.opens, 1)
        self.assertEqual(native.writes, [])
        driver.close()
        self.assertEqual(native.closes, 1)
        self.assertEqual(native.writes, [])

    def test_failed_post_open_identity_retains_owned_release_without_query(self):
        for capability in ('readback', 'manual'):
            for failure in ('device-identity', 'device-ownership'):
                driver, native, handle, deadline, cancel = self.make(capability, opened=False)
                snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
                with patch('serialptu.ptu.verify_selected_device', return_value=snapshot), \
                        patch('serialptu.ptu.claim_selected_device', side_effect=AcquisitionError(failure)):
                    with self.assertRaises(PointingError):
                        driver.open_bounded(deadline=deadline, cancel=cancel)
                self.assertTrue(native.opened)
                attempts = (lambda: driver.get_status_bounded(handle, deadline=deadline, cancel=cancel),
                            lambda: driver.observe_bounded(handle, deadline=deadline, cancel=cancel),
                            lambda: driver.stop_bounded(handle, deadline=deadline, cancel=cancel),
                            lambda: driver.prepare_move_to(handle, 1, -1, deadline=deadline, cancel=cancel),
                            lambda: driver.submit_prepared_move(handle, None, deadline=deadline, cancel=cancel))
                for attempt in attempts:
                    with self.subTest(capability=capability, failure=failure), self.assertRaises(PointingError):
                        attempt()
                self.assertEqual(native.writes, [])
                driver.close(deadline=deadline)
                self.assertFalse(native.opened)

    def test_control_line_and_native_mode_drift_reject_before_query(self):
        for name, value in (('rts', False), ('dtr', False), ('exclusive', False),
                            ('inter_byte_timeout', .1), ('rs485_mode', object()), ('rtscts', True)):
            driver, native, handle, deadline, cancel = self.make()
            setattr(native, name, value)
            with self.subTest(name=name), self.assertRaises(PointingError):
                driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
            self.assertEqual(native.writes, [])

    def test_status_receipt_retains_exact_bytes_and_monotonic_receipt_not_arrival(self):
        driver, native, handle, deadline, cancel = self.make()
        result = driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
        receipt = driver.last_exchange
        self.assertEqual(native.writes, [bytes.fromhex('02 31 00 00 00 00 00 31 03')])
        self.assertEqual(receipt.request, native.writes[0])
        self.assertEqual(receipt.response, acknowledgement(driver.protocol, 0x31))
        self.assertEqual((receipt.sequence, receipt.operation, receipt.category, receipt.submission),
                         (1, 'status', 'ok', 'complete'))
        self.assertEqual(receipt.written, len(receipt.request))
        self.assertLessEqual(receipt.started_monotonic, receipt.finished_monotonic)
        self.assertFalse(receipt.response_truncated)
        self.assertEqual(result[1]['message_type'], 'status_response')
        with self.assertRaises(FrozenInstanceError):
            receipt.category = 'changed'
        driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(driver.last_exchange.sequence, 2)
        self.assertEqual(receipt.sequence, 1)

    def test_stale_feedback_refusal_has_a_new_receipt_without_write_or_consumption(self):
        driver, native, handle, deadline, cancel = self.make()
        stale = acknowledgement(driver.protocol, 0x31, 123, 456)
        native.response.extend(stale)
        with self.assertRaisesRegex(PointingError, '^stale-response$'):
            driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
        receipt = driver.last_exchange
        self.assertEqual((receipt.category, receipt.submission, receipt.response), ('stale-response', 'none', b''))
        self.assertEqual(bytes(native.response), stale)
        self.assertEqual(native.writes, [])

    def test_partial_write_and_bad_protocol_responses_keep_failure_evidence(self):
        for mode in ('short', 'checksum', 'nak', 'oversize'):
            driver, native, handle, deadline, cancel = self.make()
            native.auto_ack = False
            response = b''
            if mode == 'short':
                native.result = 2
            else:
                response = (b'\x06\x31\x00\x03' if mode == 'checksum' else
                            b'\x15' + acknowledgement(driver.protocol, 0x31)[1:] if mode == 'nak' else b'\x00' * 65)
                native.on_write = lambda response=response: native.response.extend(response)
            with self.subTest(mode=mode), self.assertRaises(PointingError):
                driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
            receipt = driver.last_exchange
            self.assertEqual(len(native.writes), 1)
            self.assertEqual(receipt.category, {'short': 'short-write', 'checksum': 'strict-checksum',
                                               'nak': 'strict-nak', 'oversize': 'response'}[mode])
            self.assertEqual(receipt.response, response[:64])
            self.assertEqual(receipt.response_truncated, mode == 'oversize')
            self.assertEqual(receipt.submission, 'partial' if mode == 'short' else 'complete')

    def test_partial_or_missing_response_timeout_keeps_received_bytes_without_retry(self):
        for response in (b'', b'\x06\x31'):
            driver, native, handle, deadline, cancel = self.make()
            native.auto_ack = False
            native.on_write = lambda response=response: native.response.extend(response)
            original_read = native.read
            now = [time.monotonic()]

            def read(count):
                result = original_read(count)
                if not result:
                    now[0] += 2
                return result

            native.read = read
            with patch('serialptu.ptu.time.monotonic', side_effect=lambda: now[0]):
                with self.assertRaisesRegex(PointingError, '^deadline$'):
                    driver.observe_bounded(handle, deadline=now[0] + 1, cancel=cancel)
            self.assertEqual(driver.last_exchange.response, response)
            self.assertEqual(driver.last_exchange.category, 'deadline')
            self.assertEqual(driver.last_exchange.submission, 'complete')
            self.assertEqual(len(native.writes), 1)

    def test_delayed_partial_response_is_decoded_without_resend(self):
        driver, native, handle, deadline, cancel = self.make()
        native.auto_ack = False
        expected = acknowledgement(driver.protocol, 0x31, -123, 456)
        reads = [0]
        original_read = native.read

        def read(count):
            reads[0] += 1
            if reads[0] == 2:
                native.response.extend(expected[:3])
            elif reads[0] == 6:
                native.response.extend(expected[3:])
            return original_read(count)

        native.read = read
        result = driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual((result[1]['pan'], result[1]['tilt']), (-12.3, 45.6))
        self.assertEqual(driver.last_exchange.response, expected)
        self.assertEqual(driver.last_exchange.category, 'ok')
        self.assertEqual(len(native.writes), 1)

    def test_cancellation_after_native_read_keeps_the_received_byte(self):
        driver, native, handle, deadline, cancel = self.make()
        original_read = native.read

        def read(count):
            value = original_read(count)
            cancel.set()
            return value

        native.read = read
        with self.assertRaisesRegex(PointingError, '^cancelled$'):
            driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(driver.last_exchange.response, b'\x06')
        self.assertEqual(driver.last_exchange.submission, 'complete')

    def test_receipt_sequence_never_wraps_or_reuses_previous_receipt(self):
        driver, native, handle, deadline, cancel = self.make()
        driver._exchange_sequence = 2**64 - 2
        driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        receipt = driver.last_exchange
        self.assertEqual(receipt.sequence, 2**64 - 1)
        with self.assertRaisesRegex(PointingError, '^exchange-sequence$'):
            driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertIs(driver.last_exchange, receipt)
        self.assertEqual(len(native.writes), 1)


if __name__ == "__main__":
    unittest.main()
