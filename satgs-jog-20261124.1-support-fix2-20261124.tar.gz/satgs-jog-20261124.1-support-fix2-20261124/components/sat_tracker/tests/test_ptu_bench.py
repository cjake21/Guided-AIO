"""Real bench owners, protobuf and serial codecs at controlled external boundaries."""
import copy
import errno
import tempfile
import threading
import time
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from serial import SerialException
from ptu_control import bench
from ptu_control import ptu_msg_pb2 as pb
from ptu_control.constants import Topics
from ptu_control.pointing import PointingError, PointingPolicy
from ptu_control.ptu_client import PtuClient, PtuError
from ptu_control.ptu_manager import PtuManager
from ptu_control.bench_local import LocalBenchClient
from serialptu.proto_impl import PTCR20
from serialptu.ptu import PTU
from serialptu.acquisition import SerialSettings, SerialDeviceIdentity, _DeviceSnapshot
from test_ptu_manager_pointing import FollowingSerial, MessageBus, rectangle, settings


def bench_settings(mode="rehearsal"):
    value = settings()
    value["bench_context"] = dict(mode=mode, equipment_label="controlled fixture unit",
        serial_port="recording-only", baud=57600, pan_min=-100, pan_max=100,
        tilt_min=-90, tilt_max=0, max_change_degrees=100,
        observation_max_age_seconds=1, exchange_timeout_seconds=.1)
    return value


def readback_settings():
    return {"readback_context": {
        "schema": "ptu-readback-context.v1", "session_id": "61" * 32,
        "equipment_label": "controlled fixture unit", "model": "QPT130", "protocol": "PTCR20",
        "protocol_address": None,
        "serial_settings": {"port": "/dev/serial/by-id/usb-recording-only", "baudrate": 9600,
            "bytesize": 8, "parity": "N", "stopbits": 1, "xonxoff": False, "rtscts": False,
            "dsrdtr": False, "rts": True, "dtr": True},
        "device_identity": {"vendor_id": "067b", "product_id": "23a3", "serial_number": "recording-only",
            "interface_number": "00", "driver": "pl2303"},
        "observation_max_age_seconds": 1, "exchange_timeout_seconds": .1}}


def manual_settings():
    value = readback_settings().pop("readback_context")
    value.update(schema="ptu-manual-context.v1", frame="mechanical-pan-tilt-degrees.v1",
                 session_id="62" * 32, pan_min=-100, pan_max=100, tilt_min=-90, tilt_max=0,
                 max_change_degrees=5, no_go_rectangle=None)
    return {"manual_context": value}


def controlled_bench_driver(stack, configuration):
    value = configuration.get("manual_context", configuration.get("readback_context"))
    proto = PTCR20()
    native = FollowingSerial(proto)
    serial = SerialSettings(**value["serial_settings"])
    identity = SerialDeviceIdentity(**value["device_identity"])
    with patch("serialptu.ptu.serial.Serial", return_value=native):
        driver = PTU(proto, serial.port, baud=serial.baudrate, pointing=True,
            serial_settings=serial, device_identity=identity,
            serial_capability="manual" if "manual_context" in configuration else "readback")
    snapshot = _DeviceSnapshot("/dev/ttyUSB0", 7, 13, 188 * 256)
    stack.enter_context(patch("serialptu.ptu.verify_selected_device", return_value=snapshot))
    stack.enter_context(patch("serialptu.ptu.claim_selected_device"))
    return driver, native


class BenchTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.bus = MessageBus()
        self.bus.install(self.stack)
        self.configuration = bench_settings()
        self.cancel = threading.Event()
        self.deadline = time.monotonic() + 5
        self.directory = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.owners = []
        self.clients = []
        self.addCleanup(self.release)

    def release(self):
        for client in self.clients:
            client.close(deadline=time.monotonic() + 1)
        for manager, native, driver in self.owners:
            native.auto_ack = True
            native.close_failure = False
            manager.close(deadline=time.monotonic() + 1)
        self.assertEqual(self.bus.registrations, [])

    def manager(self, configuration=None, admitted=True, zone=None):
        configuration = self.configuration if configuration is None else configuration
        proto = PTCR20()
        native = FollowingSerial(proto)
        with patch("serialptu.ptu.serial.Serial", return_value=native):
            driver = PTU(proto, "recording-only", pointing=True)
        with patch.object(bench, "_controlled_rehearsal_boundary", return_value=admitted):
            try:
                manager = PtuManager.open_bench(messenger=self.bus.messenger, settings=configuration,
                    ptu_id=2, driver=driver, elevation_mask=0, no_go_data=zone,
                    run_deadline=self.deadline, cancel=self.cancel)
            except Exception:
                driver.close(deadline=self.deadline)
                raise
        self.owners.append((manager, native, driver))
        return manager, native, driver

    def client(self, configuration=None, zone=None):
        client = PtuClient.open_bench(messenger=self.bus.messenger,
            settings=self.configuration if configuration is None else configuration, ptu_id=2,
            elevation_mask=0, log_dir=self.directory, no_go_data=zone,
            deadline=self.deadline, cancel=self.cancel)
        self.clients.append(client)
        return client

    def controls(self):
        return dict(deadline=self.deadline, cancel=self.cancel)

    def connected(self, **options):
        manager, native, driver = self.manager(**options)
        client = self.client(options.get("configuration"), options.get("zone"))
        manager.activate(**self.controls())
        self.assertEqual(client.connect(**self.controls()).category, "ok")
        return manager, native, driver, client

    def test_unpatched_rehearsal_factory_rejects_without_open_or_write(self):
        with self.assertRaises(PointingError) as caught:
            self.manager(admitted=False)
        self.assertEqual(caught.exception.primary, "unsupported")
        self.assertEqual(self.bus.messages, [])

    def test_unpatched_operational_factory_rejects_before_serial_open(self):
        with self.assertRaises(PointingError) as caught:
            self.manager(configuration=bench_settings("operational"), admitted=False)
        self.assertEqual(caught.exception.primary, "unsupported")
        self.assertEqual(self.bus.messages, [])

    def test_factories_are_inert_and_connect_status_never_move(self):
        manager, native, driver = self.manager()
        client = self.client()
        self.assertEqual((native.opens, native.writes), (0, []))
        manager.activate(**self.controls())
        result = client.connect(**self.controls())
        status = client.status(**self.controls())
        self.assertEqual(result.category, "ok")
        self.assertEqual(status.position_reference, "protocol-reported-unqualified")
        self.assertEqual(status.physical_state, "unobserved")
        self.assertTrue(status.has_observation)
        self.assertEqual(native.motion(), [])
        for packet in native.writes:
            driver.protocol.validate_nonmoving_status_packet(packet)

    def test_preview_move_same_prepared_packet_no_arrival_claim_or_duplicate(self):
        manager, native, driver, client = self.connected()
        preview = client.preview(10, 0, **self.controls())
        self.assertEqual(preview.category, "ok")
        self.assertEqual(native.motion(), [])
        prepared = manager._bench_previews[client._prime_sender_id][3]
        result = client.move(preview.preview_sequence, **self.controls())
        self.assertEqual(result.category, "ok")
        self.assertEqual(result.submission, "complete")
        self.assertEqual(result.physical_state, "indeterminate")
        self.assertTrue(result.possible_motion)
        self.assertEqual(native.motion(), [prepared.packet])
        duplicate = client.move(preview.preview_sequence, **self.controls())
        self.assertEqual(duplicate.category, "context_changed")
        self.assertEqual(len(native.motion()), 1)

    def test_raw_position_reference_bits_are_preserved_not_inferred(self):
        manager, native, driver, client = self.connected()
        original = native.write

        def destination_reply(packet):
            result = original(packet)
            raw = driver.protocol._decode_strict_packet(bytes(native.response), 6)
            changed = driver.protocol._build_message(raw[:-1] + bytes([raw[-1] | 0x20]))
            native.response[:] = b"\x06" + changed[1:]
            return result

        native.write = destination_reply
        result = client.status(**self.controls())
        self.assertEqual(result.status_bytes, "000020")
        self.assertEqual(result.position_reference, "protocol-reported-unqualified")

    def test_known_buffered_stale_feedback_is_not_used_as_current_status(self):
        from test_prepared_pointing import acknowledgement
        manager, native, driver, client = self.connected()
        native.response.extend(acknowledgement(driver.protocol, 0x31, 999, 0))
        before = len(native.writes)
        result = client.status(**self.controls())
        self.assertEqual(result.category, "serial_failure")
        self.assertFalse(result.has_observation)
        self.assertEqual(len(native.writes), before)

    def test_stale_or_changed_start_and_two_axis_targets_cannot_move(self):
        manager, native, driver, client = self.connected()
        self.assertEqual(client.preview(10, -10, **self.controls()).category, "endpoint_rejected")
        preview = client.preview(10, 0, **self.controls())
        native.pan_units = 1
        result = client.move(preview.preview_sequence, **self.controls())
        self.assertEqual(result.category, "context_changed")
        self.assertEqual(native.motion(), [])
        preview = client.preview(10, 0, **self.controls())
        stored = manager._bench_previews[client._prime_sender_id]
        observation = stored[4]
        manager._bench_previews[client._prime_sender_id] = stored[:4] + (
            observation[:4] + (observation[4] - 2,) + observation[5:],)
        self.assertEqual(client.move(preview.preview_sequence, **self.controls()).category, "context_changed")
        self.assertEqual(native.motion(), [])

    def test_actual_final_encoder_no_go_quantization_is_preserved(self):
        manager, native, driver, client = self.connected(zone=rectangle())
        native.pan_units, native.tilt_units = -800, -700
        result = client.preview(-70.04, -70, **self.controls())
        self.assertEqual(result.category, "endpoint_rejected")
        self.assertEqual(native.motion(), [])

    def test_another_client_can_stop_and_invalidate_pending_preview(self):
        manager, native, driver, client = self.connected()
        other = self.client()
        other.connect(**self.controls())
        preview = client.preview(10, 0, **self.controls())
        result = other.stop(**self.controls())
        self.assertEqual(result.category, "ok")
        stops = [packet for packet in native.writes
                 if driver.protocol._decode_strict_packet(packet, 2)[1] == 2]
        self.assertEqual(len(stops), 1)
        driver.protocol.validate_stop_packet(stops[0])
        self.assertEqual(client.move(preview.preview_sequence, **self.controls()).category, "context_changed")

    def test_stop_after_uncertain_move_uses_same_open_owner_without_retry(self):
        manager, native, driver, client = self.connected()
        preview = client.preview(10, 0, **self.controls())
        native.before_write = lambda command: setattr(native, "auto_ack", command != 0x33)
        result = client.move(preview.preview_sequence, **self.controls())
        self.assertNotEqual(result.category, "ok")
        self.assertEqual(result.physical_state, "indeterminate")
        native.before_write = None
        native.auto_ack = True
        stopped = client.stop(**self.controls())
        self.assertEqual(stopped.category, "ok")
        self.assertEqual(stopped.physical_state, "indeterminate")
        self.assertEqual(len(native.motion()), 1)
        self.assertEqual(native.opens, 1)

    def test_stop_pending_gates_a_concurrent_move_before_its_next_exchange(self):
        manager, native, driver, client = self.connected()
        other = self.client()
        other.connect(**self.controls())
        preview = client.preview(10, 0, **self.controls())
        results, errors = {}, []

        def invoke(name, operation):
            try:
                results[name] = operation()
            except Exception as error:
                errors.append(error)

        manager._operation.acquire()
        stopping = threading.Thread(target=invoke, args=("stop", lambda: other.stop(**self.controls())))
        moving = threading.Thread(target=invoke, args=("move", lambda: client.move(preview.preview_sequence, **self.controls())))
        try:
            stopping.start()
            self.assertTrue(manager._bench_stop_pending.wait(.5))
            moving.start()
        finally:
            manager._operation.release()
        stopping.join(1)
        moving.join(1)
        self.assertFalse(stopping.is_alive())
        self.assertFalse(moving.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(results["stop"].category, "ok")
        self.assertIn(results["move"].category, ("busy", "context_changed"))
        self.assertEqual(native.motion(), [])

    def test_failed_stop_latches_across_status_reconnect_and_later_stop(self):
        manager, native, driver, client = self.connected()
        native.auto_ack = False
        failed = client.stop(**self.controls())
        self.assertNotEqual(failed.category, "ok")
        self.assertEqual(failed.state, "stop_failed")
        self.assertEqual(failed.physical_state, "indeterminate")
        native.auto_ack = True
        self.assertEqual(client.status(**self.controls()).state, "stop_failed")
        self.assertEqual(client.stop(**self.controls()).state, "stop_failed")
        self.assertEqual(client.preview(10, 0, **self.controls()).category, "busy")
        other = self.client()
        self.assertEqual(other.connect(**self.controls()).state, "stop_failed")
        self.assertEqual(other.preview(10, 0, **self.controls()).category, "busy")
        self.assertEqual(native.motion(), [])

    def test_operational_mode_cannot_send_move_stop_or_inherited_motion(self):
        config = bench_settings("operational")
        manager, native, driver, client = self.connected(configuration=config)
        preview = client.preview(10, 0, **self.controls())
        before = len(native.writes)
        self.assertEqual(client.move(preview.preview_sequence, **self.controls()).category, "unsupported")
        self.assertEqual(client.stop(**self.controls()).category, "unsupported")
        self.assertEqual(len(native.writes), before)
        with self.assertRaises(PointingError):
            manager.move_to_az_el(10, 90, binding=manager.policy.binding, **self.controls())
        self.assertEqual(native.motion(), [])

    def test_disconnect_and_close_are_passive_and_old_requests_do_not_replay(self):
        manager, native, driver, client = self.connected()
        old = next(body for topic, body in self.bus.messages if topic == Topics.BENCH_COMMAND + "_2")
        client.preview(10, 0, **self.controls())
        before = len(native.writes)
        client.disconnect(**self.controls())
        rejected = manager.rejected
        self.bus.deliver(Topics.BENCH_COMMAND + "_2", old)
        self.assertEqual(manager.rejected, rejected + 1)
        self.assertIsNone(manager._bench_regular_slot)
        self.assertEqual(client.status(**self.controls()).category, "disconnected")
        client.close(deadline=self.deadline)
        self.assertEqual(len(native.writes), before)
        self.assertTrue(native.opened)
        self.assertEqual(native.motion(), [])

    def test_wrong_wire_binding_broadcast_and_other_id_have_no_effect(self):
        manager, native, driver, client = self.connected()
        command = pb.BenchCommand(operation=pb.BenchCommand.MOVE, binding=b"x" * 32,
                                   sender=client._prime_sender_id, sequence=99, preview_sequence=1)
        before = len(native.writes)
        for topic in (Topics.BENCH_COMMAND + "_0", Topics.BENCH_COMMAND + "_3", Topics.BENCH_COMMAND + "_2"):
            self.bus.deliver(topic, command.SerializeToString())
        self.assertEqual(len(native.writes), before)

    def test_optional_station_location_binds_exact_observer_context(self):
        original = settings()
        old = PointingPolicy.from_settings(original, 2, 0, None)
        current = copy.deepcopy(original)
        current["station_location"] = dict(source="manual", station_id="fixture-station", revision=2,
            latitude_deg=42, longitude_deg=-71, altitude_m=100,
            altitude_reference="synthetic-fixture-reference", coordinate_units="degrees-metres")
        bound = PointingPolicy.from_settings(current, 2, 0, None)
        self.assertNotEqual(old.binding, bound.binding)
        self.assertEqual(bound.station_location[3:6], (42, -71, 100))
        current["ground_station_lat"] = 41
        with self.assertRaises(PointingError) as caught:
            PointingPolicy.from_settings(current, 2, 0, None)
        self.assertEqual(caught.exception.primary, "policy_mismatch")

    def test_cancelled_local_request_never_leaks_command_lock(self):
        manager, native, driver, client = self.connected()
        cancelled = threading.Event()
        cancelled.set()
        with self.assertRaises(PtuError):
            client.status(deadline=self.deadline, cancel=cancelled)
        self.assertFalse(client._operation.locked())
        self.assertEqual(client.status(**self.controls()).category, "ok")


class SelectedBenchTests(unittest.TestCase):
    setUp = BenchTests.setUp
    release = BenchTests.release
    controls = BenchTests.controls

    def manager(self, configuration):
        driver, native = controlled_bench_driver(self.stack, configuration)
        native.tilt_units = -100
        try:
            manager = PtuManager.open_bench(messenger=self.bus.messenger, settings=configuration,
                ptu_id=2, driver=driver, run_deadline=self.deadline, cancel=self.cancel)
        except BaseException:
            driver.close(deadline=self.deadline)
            raise
        self.owners.append((manager, native, driver))
        return manager, native, driver

    def client(self, configuration):
        client = PtuClient.open_bench(messenger=self.bus.messenger, settings=configuration,
            ptu_id=2, log_dir=self.directory, deadline=self.deadline, cancel=self.cancel)
        self.clients.append(client)
        return client

    def connected(self, configuration):
        manager, native, driver = self.manager(configuration)
        client = self.client(configuration)
        manager.activate(**self.controls())
        self.assertEqual(client.connect(**self.controls()).category, "ok")
        return manager, native, driver, client

    def test_query_context_needs_no_pointing_navigation_or_tle_values(self):
        configuration = readback_settings()
        context = bench.ReadbackContext.from_settings(configuration, 2)
        self.assertEqual(context.mode, "query-only")
        self.assertFalse(context.motion_allowed)
        self.assertEqual((context.protocol, context.protocol_address, context.baud), ("PTCR20", None, 9600))
        with self.assertRaises(TypeError):
            context.serial_settings["baudrate"] = 57600
        for key, value in (("protocol_address", 2), ("session_id", "bad"), ("exchange_timeout_seconds", True)):
            broken = copy.deepcopy(configuration)
            broken["readback_context"][key] = value
            with self.assertRaises(PointingError):
                bench.ReadbackContext.from_settings(broken, 2)

    def test_broker_manual_soft_flag_keeps_existing_axis_fault_policy(self):
        configuration = manual_settings()
        manager, native, driver = self.manager(configuration)
        native.status_bytes = b'\x00\x80\x00'
        client = self.client(configuration)
        manager.activate(**self.controls())
        record = client.connect(**self.controls()).as_record()
        self.assertEqual(record['category'], 'ok')
        self.assertEqual(record['status_bytes'], '008000')
        self.assertNotIn('jog_blocked_directions', record)
        self.assertTrue(manager._invalid)
        self.assertEqual(client.preview(0, -10, **self.controls()).category, 'busy')

    def test_manual_limits_frame_and_explicit_no_go_are_binding_inputs(self):
        original = manual_settings()
        context = bench.ManualContext.from_settings(original, 2)
        changed = copy.deepcopy(original)
        changed["manual_context"]["max_change_degrees"] = 2
        self.assertNotEqual(context.binding, bench.ManualContext.from_settings(changed, 2).binding)
        self.assertNotEqual(context.binding, bench.ReadbackContext.from_settings(readback_settings(), 2).binding)
        for key in ("frame", "pan_min", "max_change_degrees", "no_go_rectangle"):
            broken = copy.deepcopy(original)
            del broken["manual_context"][key]
            with self.assertRaises(PointingError):
                bench.ManualContext.from_settings(broken, 2)
        for rectangle in ({}, {"pan_min": 0}, {"pan_min": 1, "pan_max": 0, "tilt_min": -1, "tilt_max": 0}):
            broken = copy.deepcopy(original)
            broken["manual_context"]["no_go_rectangle"] = rectangle
            with self.assertRaises(PointingError):
                bench.ManualContext.from_settings(broken, 2)

    def test_selected_factories_and_activation_never_transmit_or_enable_tracking(self):
        configuration = readback_settings()
        manager, native, driver = self.manager(configuration)
        client = self.client(configuration)
        self.assertEqual(native.writes, [])
        self.assertFalse(native.opened)
        self.assertIsNone(manager.policy)
        self.assertIsNone(client._policy)
        manager.activate(**self.controls())
        self.assertEqual(native.writes, [])
        self.assertEqual([topic for topic, unused, unused_id in self.bus.registrations], [Topics.BENCH_COMMAND + "_2"])
        result = client.connect(**self.controls()).as_record()
        self.assertEqual((result["pan"], result["tilt"], result["units_per_degree"]), (0, -10, 10))
        self.assertEqual(result["position_reference"], "protocol-reported-unqualified")
        self.assertEqual(result["capabilities"], ["connect", "status", "disconnect"])
        self.assertNotIn("pan_min", result)
        self.assertEqual(len(result["exchanges"]), 1)
        receipt = result["exchanges"][0]
        self.assertEqual(bytes.fromhex(receipt["request"]), native.writes[-1])
        self.assertEqual(receipt["request"], "023100000000003103")
        self.assertTrue(receipt["response"])
        self.assertGreaterEqual(receipt["finished_monotonic"], receipt["started_monotonic"])
        self.assertEqual(native.motion(), [])

    def test_query_forbidden_commands_reject_before_queue_or_physical_state_changes(self):
        manager, native, driver, client = self.connected(readback_settings())
        before = len(native.writes), len(self.bus.messages)
        for operation in (lambda: client.preview(1, -10, **self.controls()),
                          lambda: client.move(1, **self.controls()), lambda: client.stop(**self.controls()),
                          lambda: client.check_connection(**self.controls()),
                          lambda: client.load_tle("unused", **self.controls()),
                          lambda: client.prime(1, -10, **self.controls()),
                          lambda: client.ptu_move_to(1, -10, **self.controls())):
            with self.assertRaises(PtuError):
                operation()
        for operation in (pb.BenchCommand.PREVIEW, pb.BenchCommand.MOVE, pb.BenchCommand.STOP):
            message = pb.BenchCommand(operation=operation, binding=manager._bench.binding,
                sender=client._prime_sender_id, sequence=100 + operation)
            manager._bench_cb(message.SerializeToString(), "bench")
        self.assertEqual((len(native.writes), len(self.bus.messages)), before)
        self.assertEqual(manager._bench_stop_count, 0)
        self.assertFalse(manager._bench_stop_pending.is_set())
        self.assertFalse(manager._bench_possible_motion)
        with self.assertRaises(PointingError):
            manager.move_to_az_el(1, 80, binding=manager._bench.binding, **self.controls())

    def assert_selected_controller_claim(self, configuration):
        manager, native, driver, first = self.connected(configuration)
        second = self.client(configuration)
        if manager._bench.motion_allowed:
            self.assertEqual(first.preview(1, -10, **self.controls()).category, "ok")
        before, previews = len(native.writes), dict(manager._bench_previews)
        self.assertEqual(second.connect(**self.controls()).category, "busy")
        self.assertEqual(len(native.writes), before)
        self.assertNotIn(second._prime_sender_id, manager._bench_senders)
        self.assertEqual(manager._bench_connected, {first._prime_sender_id})
        foreign = pb.BenchCommand(operation=pb.BenchCommand.STOP, binding=manager._bench.binding,
            sender=second._prime_sender_id, sequence=99)
        manager._bench_cb(foreign.SerializeToString(), "bench")
        self.assertEqual((manager._bench_stop_count, manager._bench_priority_slot), (0, None))
        self.assertFalse(manager._bench_stop_pending.is_set())
        self.assertFalse(manager._bench_stop_failed or manager._invalid or manager._bench_possible_motion)
        self.assertEqual(manager._bench_previews, previews)
        self.assertEqual(len(native.writes), before)
        self.assertEqual(first.status(**self.controls()).category, "ok")
        self.assertEqual(first.disconnect(**self.controls()).category, "ok")
        self.assertEqual(second.connect(**self.controls()).category, "ok")
        self.assertEqual(manager._bench_connected, {second._prime_sender_id})
        before = len(native.writes)
        foreign.sender = first._prime_sender_id
        manager._bench_cb(foreign.SerializeToString(), "bench")
        self.assertEqual(len(native.writes), before)
        self.assertEqual((manager._bench_stop_count, manager._bench_priority_slot), (0, None))
        self.assertFalse(manager._bench_stop_pending.is_set())
        self.assertFalse(manager._bench_stop_failed or manager._invalid or manager._bench_possible_motion)
        second.close(deadline=self.deadline)
        self.assertEqual(first.connect(**self.controls()).category, "busy")
        self.assertEqual(len(native.writes), before)
        self.assertEqual(manager._bench_connected, {second._prime_sender_id})
        self.assertEqual(native.motion(), [])

    def test_query_controller_claim_requires_explicit_disconnect_for_handoff(self):
        self.assert_selected_controller_claim(readback_settings())

    def test_manual_controller_claim_requires_explicit_disconnect_for_handoff(self):
        self.assert_selected_controller_claim(manual_settings())

    def assert_failed_connect_does_not_claim(self, configuration):
        manager, native, driver = self.manager(configuration)
        first, second = self.client(configuration), self.client(configuration)
        manager.activate(**self.controls())
        native.auto_ack = False
        try:
            self.assertEqual(first.connect(**self.controls()).category, "deadline")
        finally:
            native.auto_ack = True
        self.assertEqual(manager._bench_connected, set())
        self.assertEqual(second.connect(**self.controls()).category, "ok")
        self.assertEqual(manager._bench_connected, {second._prime_sender_id})
        self.assertEqual(native.motion(), [])

    def test_query_failed_connect_does_not_claim_controller(self):
        self.assert_failed_connect_does_not_claim(readback_settings())

    def test_manual_failed_connect_does_not_claim_controller(self):
        self.assert_failed_connect_does_not_claim(manual_settings())

    def test_stop_queued_during_disconnect_cannot_poison_later_controller(self):
        configuration = manual_settings()
        configuration["manual_context"]["exchange_timeout_seconds"] = 1
        manager, native, driver, first = self.connected(configuration)
        second = self.client(configuration)
        self.assertEqual(first.preview(1, -10, **self.controls()).category, "ok")
        results, errors = [], []
        entered, release = threading.Event(), threading.Event()

        class DelayedDisconnectPop(dict):
            def pop(self, key, default=None):
                value = super().pop(key, default)
                if key == first._prime_sender_id:
                    entered.set()
                    if not release.wait(1):
                        raise AssertionError("controlled disconnect scheduling timeout")
                return value

        manager._bench_previews = DelayedDisconnectPop(manager._bench_previews)

        def disconnect():
            try:
                results.append(first.disconnect(**self.controls()))
            except BaseException as error:
                errors.append(error)

        caller = threading.Thread(target=disconnect, name="selected-disconnect-race")
        before = len(native.writes)
        caller.start()
        try:
            self.assertTrue(entered.wait(1))
            pending = pb.BenchCommand(operation=pb.BenchCommand.STOP, binding=manager._bench.binding,
                sender=first._prime_sender_id, sequence=first._bench_sequence + 1)
            manager._bench_cb(pending.SerializeToString(), "bench")
            self.assertTrue(manager._bench_stop_pending.is_set())
        finally:
            release.set()
            caller.join(2)
        self.assertFalse(caller.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual([result.category for result in results], ["ok"])
        deadline = time.monotonic() + 1
        outcomes = []
        while time.monotonic() < deadline:
            outcomes = [pb.BenchOutcome.FromString(body) for topic, body in self.bus.messages
                        if topic == Topics.BENCH_OUTCOME + "_2"]
            outcomes = [result for result in outcomes if result.operation == pb.BenchCommand.STOP]
            if outcomes and not manager._bench_stop_pending.is_set():
                break
            threading.Event().wait(.001)
        self.assertEqual([(result.category, len(result.exchanges)) for result in outcomes], [("disconnected", 0)])
        self.assertFalse(manager._bench_stop_pending.is_set())
        self.assertEqual((manager._bench_stop_count, manager._bench_priority_slot), (0, None))
        self.assertFalse(manager._bench_stop_failed or manager._invalid or manager._bench_possible_motion)
        self.assertEqual(manager._bench_previews, {})
        self.assertEqual(len(native.writes), before)
        self.assertEqual(second.connect(**self.controls()).category, "ok")
        self.assertEqual(second.status(**self.controls()).category, "ok")

    def test_manual_numeric_move_and_stop_keep_all_wire_receipts_without_arrival_claim(self):
        manager, native, driver, client = self.connected(manual_settings())
        preview = client.preview(1, -10, **self.controls())
        self.assertEqual(preview.category, "ok")
        moved = client.move(preview.preview_sequence, **self.controls()).as_record()
        self.assertEqual(moved["category"], "ok")
        self.assertEqual([receipt["operation"] for receipt in moved["exchanges"]], ["status", "move"])
        self.assertEqual(moved["physical_state"], "indeterminate")
        self.assertEqual(client.status(**self.controls()).pan, 1)
        stopped = client.stop(**self.controls()).as_record()
        self.assertEqual(stopped["category"], "ok")
        self.assertEqual([receipt["operation"] for receipt in stopped["exchanges"]], ["stop", "status"])
        driver.protocol.validate_stop_packet(bytes.fromhex(stopped["exchanges"][0]["request"]))
        before = len(native.writes)
        self.assertEqual(client.disconnect(**self.controls()).category, "ok")
        self.assertEqual(len(native.writes), before)
        self.assertEqual(len(native.motion()), 1)

    def test_manual_final_encoder_rejects_truncated_negative_endpoint_at_inclusive_no_go(self):
        configuration = manual_settings()
        configuration["manual_context"].update(pan_min=-100, pan_max=0, max_change_degrees=20,
            no_go_rectangle=dict(pan_min=-70, pan_max=-30, tilt_min=-90, tilt_max=0))
        manager, native, driver, client = self.connected(configuration)
        native.pan_units, native.tilt_units = -800, -700
        manager._bench.check_target(-70.04, -70, (-80, -70))
        packet = driver.prepare_move_to(manager._handle, -70.04, -70, **self.controls())
        self.assertEqual((packet.pan_units, packet.tilt_units, packet.units_per_degree), (-700, -700, 10))
        result = client.preview(-70.04, -70, **self.controls())
        self.assertEqual(result.category, "endpoint_rejected")
        self.assertEqual(native.motion(), [])
        self.assertEqual(client.preview(-79, -71, **self.controls()).category, "endpoint_rejected")

    def test_manual_minimum_steps_preserve_exact_nonzero_positive_and_negative_tenths(self):
        configuration = manual_settings()
        configuration["manual_context"]["max_change_degrees"] = .1
        manager, native, driver, client = self.connected(configuration)
        for start, targets in ((3, (.4, .3)), (-3, (-.4, -.3))):
            native.pan_units = start
            for target in targets:
                with self.subTest(start=start, target=target):
                    preview = client.preview(target, -10, **self.controls())
                    self.assertEqual(preview.category, "ok")
                    self.assertEqual(client.move(preview.preview_sequence, **self.controls()).category, "ok")
                    self.assertEqual(client.status(**self.controls()).pan, target)
        self.assertEqual(len(native.motion()), 4)

    def test_manual_encoded_step_cannot_overshoot_declared_decimal_change(self):
        configuration = manual_settings()
        configuration["manual_context"]["max_change_degrees"] = .15
        manager, native, driver, client = self.connected(configuration)
        native.pan_units = 11
        manager._bench.check_target(.95, -10, (1.1, -10))
        packet = driver.prepare_move_to(manager._handle, .95, -10, **self.controls())
        self.assertEqual((packet.pan_units, packet.tilt_units, packet.units_per_degree), (9, -100, 10))
        self.assertEqual(client.preview(.95, -10, **self.controls()).category, "endpoint_rejected")
        self.assertEqual(native.motion(), [])

    def test_stop_ack_is_retained_when_followup_status_times_out(self):
        manager, native, driver, client = self.connected(manual_settings())
        original = native.write
        stopped = False

        def write(packet):
            nonlocal stopped
            decoded = driver.protocol._decode_strict_packet(packet, 2)
            if decoded[0] == 0x31 and decoded[1] == 2:
                stopped = True
            elif stopped:
                native.auto_ack = False
            return original(packet)

        native.write = write
        result = client.stop(**self.controls()).as_record()
        self.assertEqual(result["category"], "deadline")
        self.assertEqual(result["submission"], "complete")
        self.assertEqual(result["state"], "stop_failed")
        self.assertEqual([receipt["operation"] for receipt in result["exchanges"]], ["stop", "status"])
        self.assertEqual(result["exchanges"][0]["category"], "ok")
        self.assertEqual(result["exchanges"][1]["category"], "deadline")
        self.assertEqual(native.motion(), [])

    def test_replayed_missing_or_malformed_receipts_cannot_become_fresh_readback(self):
        manager, native, driver, client = self.connected(readback_settings())
        original = next(body for topic, body in reversed(self.bus.messages) if topic == Topics.BENCH_OUTCOME + "_2")
        for change in ("replay", "missing", "nonfinite", "wrong-operation", "unknown-category",
                       "unknown-outcome-field", "unknown-receipt-field", "missing-written"):
            message = pb.BenchOutcome.FromString(original)
            message.sequence += 1
            message.operation = pb.BenchCommand.STATUS
            pending = [pb.BenchCommand.STATUS, threading.Event(), None]
            client._bench_pending[message.sequence] = pending
            if change == "missing":
                message.ClearField("exchanges")
            elif change == "nonfinite":
                message.exchanges[0].sequence += 1
                message.exchanges[0].finished_monotonic = float("nan")
            elif change == "wrong-operation":
                message.exchanges[0].sequence += 1
                message.exchanges[0].operation = "move"
            elif change == "unknown-category":
                message.exchanges[0].sequence += 1
                message.exchanges[0].category = "made-up"
            elif change == "unknown-outcome-field":
                message.exchanges[0].sequence += 1
                message.MergeFromString(b"\xa0\x06\x01")
            elif change == "unknown-receipt-field":
                message.exchanges[0].sequence += 1
                message.exchanges[0].MergeFromString(b"\xa0\x06\x01")
            elif change == "missing-written":
                message.exchanges[0].sequence += 1
                message.exchanges[0].ClearField("written")
            client._receive_bench(message.SerializeToString(), "")
            self.assertIsNone(pending[2])
            self.assertFalse(pending[1].is_set())
            client._bench_pending.pop(message.sequence)

    def test_owner_rejects_manual_profile_for_readback_and_keeps_policy_unmodified(self):
        driver, native = controlled_bench_driver(self.stack, manual_settings())
        self.addCleanup(lambda: driver.close(deadline=time.monotonic() + 1))
        with self.assertRaises(PointingError) as caught:
            PtuManager.open_bench(messenger=self.bus.messenger, settings=readback_settings(), ptu_id=2,
                driver=driver, run_deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(caught.exception.primary, "policy_mismatch")
        self.assertFalse(native.opened)
        self.assertEqual(native.writes, [])


class LocalBenchTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.cancel = threading.Event()
        self.deadline = time.monotonic() + 5
        self.clients = []
        self.addCleanup(self.release)
        snapshot = _DeviceSnapshot("/dev/ttyUSB0", 7, 13, 188 * 256)
        self.stack.enter_context(patch("serialptu.ptu.verify_selected_device", return_value=snapshot))
        self.stack.enter_context(patch("serialptu.ptu.claim_selected_device"))

    def release(self):
        for client, native in self.clients:
            native.close_failure = False
            client.close(deadline=time.monotonic() + 1)

    def controls(self, cancel=None):
        return dict(deadline=self.deadline, cancel=self.cancel if cancel is None else cancel)

    def client(self, configuration=None):
        configuration = manual_settings() if configuration is None else copy.deepcopy(configuration)
        configuration["bench_transport"] = "local-serial"
        native = FollowingSerial(PTCR20())
        native.tilt_units = -100
        with patch("serialptu.ptu.serial.Serial", return_value=native):
            client = LocalBenchClient.open(settings=configuration, ptu_id=2, **self.controls())
        self.clients.append((client, native))
        return client, native

    def connected(self, configuration=None):
        client, native = self.client(configuration)
        self.assertEqual(client.connect(**self.controls()).category, "ok")
        return client, native

    def selected_ownership(self, *natives):
        claimed = {}

        def claim(native, settings, identity, snapshot):
            self.assertEqual(native.port, snapshot.target)
            self.assertNotIn(snapshot.target, claimed)
            claimed[snapshot.target] = native

        self.stack.enter_context(patch("serialptu.ptu.claim_selected_device", side_effect=claim))
        for native in natives:
            original_close = native.close

            def opening(native=native):
                if native.port in claimed:
                    raise SerialException(errno.EBUSY, "controlled ownership")

            def closing(native=native, original=original_close):
                original()
                if claimed.get(native.port) is native:
                    del claimed[native.port]

            native.on_open = opening
            native.close = closing
        return claimed

    def test_local_jog_is_explicit_continuous_velocity_with_decoded_feedback(self):
        configuration = manual_settings()
        configuration["manual_context"].update(max_change_degrees=.1,
            no_go_rectangle=dict(pan_min=-1, pan_max=1, tilt_min=-20, tilt_max=0))
        client, native = self.connected(configuration)
        for reported, velocity in ((0, 1), (20, 1), (1200, 1)):
            native.pan_units = reported
            record = client.jog(velocity, 0, **self.controls()).as_record()
            self.assertEqual(record["category"], "ok")
            self.assertEqual(record["operation"], "jog")
            self.assertEqual(record["motion_contract"], "device-soft-limits-jog.v1")
            self.assertFalse(record["software_endpoint_limits_enforced"])
            self.assertFalse(record["no_go_enforced"])
            self.assertFalse(record["soft_limit_override"])
            self.assertNotIn("max_change_degrees", record)
            self.assertEqual(record["pan"], reported / 10)
            self.assertEqual(record["physical_state"], "indeterminate")
            self.assertEqual((record["encoded_pan_velocity"], record["encoded_tilt_velocity"],
                              record["velocity_scale"]), (127, 0, 127))
            self.assertEqual([item["operation"] for item in record["exchanges"]], ["jog"])
            self.assertEqual(record["exchanges"][0]["request"], "023100ff000000ce03")
        self.assertEqual(len(native.writes), 4)
        self.assertTrue(client._bench_jog_active)
        self.assertEqual(client.stop(**self.controls()).category, "ok")
        self.assertFalse(client._bench_jog_active)
        self.assertEqual(client.status(**self.controls()).category, "ok")
        self.assertEqual(native.motion(), [])

    def test_up_soft_limit_preserves_readback_and_only_blocks_upward_jog(self):
        client, native = self.client()
        native.pan_units, native.tilt_units = 5, 123
        native.status_bytes = b'\x00\x80\x00'
        record = client.connect(**self.controls()).as_record()
        self.assertEqual((record['category'], record['pan'], record['tilt'], record['status_bytes']),
                         ('ok', .5, 12.3, '008000'))
        self.assertEqual(set(record['jog_blocked_directions']), {'up'})
        self.assertFalse(client._invalid)
        count = len(native.writes)
        blocked = client.jog(0, 1, **self.controls()).as_record()
        self.assertEqual((blocked['category'], blocked['submission']), ('limit_reached', 'none'))
        self.assertEqual(len(native.writes), count)
        for velocity in ((-1, 0), (1, 0), (0, -1)):
            record = client.jog(*velocity, **self.controls()).as_record()
            self.assertEqual(record['category'], 'ok')
            self.assertEqual(set(record['jog_blocked_directions']), {'up'})
            self.assertEqual(client.stop(**self.controls()).category, 'ok')
        native.status_bytes = bytes(3)
        clear = client.status(**self.controls()).as_record()
        self.assertEqual(clear['jog_blocked_directions'], {})
        self.assertEqual(client.jog(0, 1, **self.controls()).category, 'ok')
        self.assertFalse(client._invalid)

    def test_each_soft_limit_blocks_its_direction_and_preserves_escape(self):
        for raw, direction, blocked_velocity, escape_velocity in (
                (b'\x80\x00\x00', 'right', (1, 0), (-1, 0)),
                (b'\x40\x00\x00', 'left', (-1, 0), (1, 0)),
                (b'\x00\x80\x00', 'up', (0, 1), (0, -1)),
                (b'\x00\x40\x00', 'down', (0, -1), (0, 1))):
            with self.subTest(direction=direction):
                client, native = self.client()
                native.status_bytes = raw
                record = client.connect(**self.controls()).as_record()
                self.assertEqual(set(record['jog_blocked_directions']), {direction})
                self.assertTrue(record['jog_stationary'])
                self.assertNotIn('manual_fault_reason', record)
                count = len(native.writes)
                blocked = client.jog(*blocked_velocity, **self.controls()).as_record()
                self.assertEqual((blocked['category'], blocked['submission']), ('limit_reached', 'none'))
                self.assertEqual(len(native.writes), count)
                escaped = client.jog(*escape_velocity, **self.controls()).as_record()
                self.assertEqual(escaped['category'], 'ok')
                self.assertEqual(client.stop(**self.controls()).category, 'ok')
                self.assertFalse(client._invalid)

    def test_all_soft_flags_block_all_directions_without_latching_a_fault(self):
        client, native = self.client()
        native.status_bytes = b'\xc0\xc0\x00'
        record = client.connect(**self.controls()).as_record()
        self.assertEqual(set(record['jog_blocked_directions']), {'left', 'right', 'up', 'down'})
        count = len(native.writes)
        for velocity in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            result = client.jog(*velocity, **self.controls()).as_record()
            self.assertEqual((result['category'], result['submission']), ('limit_reached', 'none'))
        self.assertEqual(len(native.writes), count)
        self.assertFalse(client._invalid)
        self.assertEqual(client.stop(**self.controls()).category, 'ok')

    def test_jog_ack_reaching_soft_limit_retains_feedback_then_allows_moving_away(self):
        client, native = self.connected()
        native.pan_units, native.tilt_units = 5, 123
        native.before_write = lambda command: setattr(native, 'status_bytes', b'\x00\x80\x00')
        count = len(native.writes)
        record = client.jog(0, 1, **self.controls()).as_record()
        self.assertEqual((record['category'], record['submission']), ('limit_reached', 'complete'))
        self.assertEqual((record['pan'], record['tilt'], record['status_bytes']), (.5, 12.3, '008000'))
        self.assertTrue(record['has_observation'])
        self.assertEqual(record['exchanges'][0]['category'], 'ok')
        self.assertEqual(len(native.writes), count + 1)
        self.assertFalse(client._invalid)
        stop = client.stop(**self.controls()).as_record()
        self.assertEqual(stop['category'], 'ok')
        self.assertTrue(stop['jog_stationary'])
        self.assertNotIn('manual_fault_reason', stop)
        native.before_write = lambda command: setattr(native, 'status_bytes', bytes(3))
        escaped = client.jog(0, -1, **self.controls()).as_record()
        self.assertEqual(escaped['category'], 'ok')
        self.assertEqual(escaped['jog_blocked_directions'], {})
        self.assertFalse(client._invalid)

    def test_jog_blocks_numeric_and_nonmoving_poll_commands_until_explicit_stop(self):
        client, native = self.connected()
        preview = client.preview(1, -10, **self.controls())
        self.assertEqual(client.jog(0, -1, **self.controls()).category, "ok")
        self.assertEqual(client._bench_previews, {})
        count = len(native.writes)
        for operation in (lambda: client.status(**self.controls()), lambda: client.connect(**self.controls()),
                          lambda: client.preview(1, -10, **self.controls()),
                          lambda: client.move(preview.preview_sequence, **self.controls()),
                          lambda: client.disconnect(**self.controls())):
            self.assertEqual(operation().category, "busy")
        self.assertEqual(len(native.writes), count)
        self.assertEqual(client.stop(**self.controls()).category, "ok")
        self.assertEqual(client.preview(1, -10, **self.controls()).category, "ok")

    def test_query_only_and_invalid_jog_are_rejected_before_serial_activation(self):
        client, native = self.client(readback_settings())
        with self.assertRaises(PtuError) as caught:
            client.jog(1, 0, **self.controls())
        self.assertEqual(caught.exception.primary, "unsupported")
        self.assertEqual((native.opens, native.writes), (0, []))
        client, native = self.client()
        for velocities in ((0, 0), (1, 1), (True, 0), (1.01, 0), (0, float("nan")), (0, float("inf"))):
            with self.subTest(velocities=velocities), self.assertRaises(PointingError):
                client.jog(*velocities, **self.controls())
        self.assertEqual((native.opens, native.writes), (0, []))

    def test_stale_observation_does_not_authorize_a_jog_refresh(self):
        client, native = self.connected()
        observation = list(client._bench_observation)
        observation[4] -= 2
        client._bench_observation = tuple(observation)
        count = len(native.writes)
        record = client.jog(-1, 0, **self.controls()).as_record()
        self.assertEqual(record["category"], "context_changed")
        self.assertEqual(record["submission"], "none")
        self.assertEqual(record["exchanges"], [])
        self.assertEqual(len(native.writes), count)

    def test_uncertain_first_jog_retains_motion_and_same_owner_stop_authority(self):
        for result, submission in ((0, "none"), (2, "partial"), (OSError("fixture"), "unknown")):
            with self.subTest(submission=submission):
                client, native = self.connected()
                native.result, native.auto_ack = result, False
                record = client.jog(-1, 0, **self.controls()).as_record()
                self.assertNotEqual(record["category"], "ok")
                self.assertEqual(record["submission"], submission)
                self.assertEqual(record["exchanges"][0]["operation"], "jog")
                self.assertTrue(record["possible_motion"])
                self.assertTrue(record["jog_active"])
                self.assertFalse(record["has_observation"])
                count = len(native.writes)
                self.assertEqual(client.jog(-1, 0, **self.controls()).category, "busy")
                self.assertEqual(len(native.writes), count)
                native.result, native.auto_ack = None, True
                self.assertEqual(client.stop(**self.controls()).category, "ok")
                self.assertFalse(client._bench_jog_active)
                self.assertEqual(native.opens, 1)
                self.assertEqual(client.jog(-1, 0, **self.controls()).category, "busy")

    def test_jog_preflight_cancel_has_no_submission_and_preserves_lock_ownership(self):
        client, native = self.connected()
        held_cancel = threading.Event()
        held_cancel.set()
        count = len(native.writes)
        with self.assertRaises(PtuError) as caught:
            client.jog(1, 0, **self.controls(held_cancel))
        self.assertEqual((caught.exception.primary, caught.exception.submission), ("cancelled", "none"))
        self.assertFalse(client._regular_request.locked())
        held_cancel.clear()
        reached, failures = threading.Event(), []
        original_lock = client._lock

        def enter_lock(*args):
            reached.set()
            return original_lock(*args)

        def jog():
            try:
                client.jog(1, 0, **self.controls(held_cancel))
            except Exception as error:
                failures.append(error)

        client._regular_request.acquire()
        try:
            with patch.object(client, "_lock", side_effect=enter_lock):
                worker = threading.Thread(target=jog, name="controlled-jog-preflight")
                worker.start()
                self.assertTrue(reached.wait(1))
                held_cancel.set()
                worker.join(1)
                self.assertFalse(worker.is_alive())
            self.assertTrue(client._regular_request.locked())
        finally:
            held_cancel.set()
            client._regular_request.release()
            worker.join(1)
        self.assertEqual(len(failures), 1)
        self.assertEqual((failures[0].primary, failures[0].submission), ("cancelled", "none"))
        self.assertEqual(len(native.writes), count)
        self.assertFalse(client._invalid)
        self.assertEqual(client.stop(**self.controls()).category, "ok")
        self.assertEqual(client.jog(1, 0, **self.controls()).category, "ok")

    def test_jog_cancelled_before_native_write_preserves_owner_for_a_new_hold_after_stop(self):
        client, native = self.connected()
        held_cancel = threading.Event()
        count = len(native.writes)

        def cancel_before_write(serial):
            held_cancel.set()
            return len(serial.response)

        with patch.object(type(native), "in_waiting", property(cancel_before_write)):
            record = client.jog(1, 0, **self.controls(held_cancel)).as_record()
        self.assertEqual((record["category"], record["submission"]), ("cancelled", "none"))
        self.assertEqual(len(native.writes), count)
        self.assertEqual(len(record["exchanges"]), 1)
        self.assertEqual(record["exchanges"][0]["category"], "cancelled")
        self.assertTrue(record["jog_active"])
        self.assertFalse(client._invalid)
        self.assertEqual(client.stop(**self.controls()).category, "ok")
        self.assertEqual(client.jog(-1, 0, **self.controls()).category, "ok")
        self.assertEqual(native.opens, 1)
        self.assertTrue(held_cancel.is_set())

    def test_jog_cancelled_after_write_accepts_independent_stop_event(self):
        client, native = self.connected()
        held_cancel = threading.Event()
        native.before_write = lambda command: held_cancel.set()
        record = client.jog(0, 1, **self.controls(held_cancel)).as_record()
        self.assertEqual((record["category"], record["submission"]), ("cancelled", "complete"))
        self.assertTrue(record["jog_active"])
        native.before_write, native.auto_ack = None, True
        self.assertEqual(client.stop(**self.controls()).category, "ok")
        self.assertTrue(held_cancel.is_set())

    def test_jog_device_fault_retains_actual_feedback_and_blocks_more_motion(self):
        client, native = self.connected()
        original = native.write

        def fault(packet):
            count = original(packet)
            data = bytes([0x31]) + native.proto._pack_int_16(123) + native.proto._pack_int_16(-100) + bytes([0x08, 0, 0])
            native.response = bytearray(b"\x06" + native.proto._build_message(data)[1:])
            return count

        native.write = fault
        record = client.jog(1, 0, **self.controls()).as_record()
        self.assertEqual((record["category"], record["submission"]), ("context_changed", "complete"))
        self.assertEqual(record["pan"], 12.3)
        self.assertEqual(record["status_bytes"], "080000")
        self.assertTrue(record["has_observation"])
        self.assertTrue(record['manual_fault_reason'])
        self.assertTrue(client._invalid)
        native.write = original
        stop = client.stop(**self.controls()).as_record()
        self.assertEqual(stop['category'], 'ok')
        self.assertEqual(stop['status_bytes'], '000000')
        self.assertTrue(stop['manual_fault_reason'])
        self.assertEqual(client.jog(-1, 0, **self.controls()).category, "busy")

    def test_soft_limit_escape_never_clears_a_failed_stop_or_stop_ack_fault(self):
        client, native = self.client()
        native.status_bytes = b'\x00\x80\x00'
        self.assertEqual(client.connect(**self.controls()).category, 'ok')
        original = native.write

        def stop_fault(packet):
            decoded = native.proto._decode_strict_packet(packet, 2)
            native.status_bytes = b'\x08\x00\x00' if decoded[:2] == b'\x31\x02' else bytes(3)
            return original(packet)

        native.write = stop_fault
        stop = client.stop(**self.controls()).as_record()
        self.assertEqual(stop['category'], 'serial_failure')
        self.assertEqual(stop['exchanges'][0]['category'], 'strict-status')
        self.assertTrue(client._bench_stop_failed)
        native.write, native.status_bytes = original, bytes(3)
        cleared = client.status(**self.controls()).as_record()
        self.assertEqual(cleared['status_bytes'], '000000')
        self.assertTrue(cleared['manual_fault_reason'])
        count = len(native.writes)
        self.assertEqual(client.jog(0, -1, **self.controls()).category, 'busy')
        self.assertEqual(len(native.writes), count)

    def test_failed_stop_while_jog_waits_prevents_its_next_write(self):
        configuration = manual_settings()
        configuration["manual_context"]["exchange_timeout_seconds"] = 1
        client, native = self.connected(configuration)
        outcomes = {}
        jog = threading.Thread(target=lambda: outcomes.update(jog=client.jog(1, 0, **self.controls())))
        stop = threading.Thread(target=lambda: outcomes.update(stop=client.stop(
            deadline=time.monotonic() + .03, cancel=self.cancel)))
        count = len(native.writes)
        client._operation.acquire()
        try:
            jog.start()
            stop.start()
            stop.join(1)
            self.assertFalse(stop.is_alive())
        finally:
            client._operation.release()
            jog.join(1)
        self.assertFalse(jog.is_alive())
        self.assertEqual(outcomes["stop"].category, "deadline")
        self.assertEqual(outcomes["jog"].category, "busy")
        self.assertEqual(outcomes["jog"].as_record()["exchanges"], [])
        self.assertEqual(len(native.writes), count)

    def test_jog_owner_close_remains_passive_and_never_starts_keepalive(self):
        client, native = self.connected()
        self.assertEqual(client.jog(1, 0, **self.controls()).category, "ok")
        count = len(native.writes)
        self.assertIsNone(client._driver._keepalive)
        client.close(deadline=self.deadline)
        self.assertEqual(len(native.writes), count)

    def test_local_factory_is_inert_and_never_constructs_transport_or_manager(self):
        with patch("meteor_api.messenger.Messenger.__init__", side_effect=AssertionError("messenger")), \
                patch.object(PtuManager, "open_bench", side_effect=AssertionError("manager")):
            client, native = self.client(readback_settings())
            self.assertEqual(native.opens, 0)
            self.assertEqual(native.writes, [])
            self.assertIsNone(client._driver._keepalive)
            record = client.connect(**self.controls()).as_record()
            self.assertEqual(record["category"], "ok")
            self.assertEqual((record["pan"], record["tilt"]), (0, -10))
            self.assertEqual(record["position_reference"], "protocol-reported-unqualified")
            self.assertEqual(record["exchanges"][0]["request"], "023100000000003103")
            self.assertEqual(native.motion(), [])

    def test_local_transport_is_explicit_bound_and_rejects_mixed_broker_inputs(self):
        configuration = manual_settings()
        original = bench.ManualContext.from_settings(configuration, 2)
        with patch("serialptu.ptu.serial.Serial") as serial:
            with self.assertRaises(PtuError):
                LocalBenchClient.open(settings=configuration, ptu_id=2, **self.controls())
            serial.assert_not_called()
        configuration["bench_transport"] = "local-serial"
        self.assertNotEqual(original.binding, bench.ManualContext.from_settings(configuration, 2).binding)
        for key in ("amq_hostname", "amq_transport", "amq_use_ssl", "amq_password"):
            with self.subTest(key=key), patch("serialptu.ptu.serial.Serial") as serial:
                broken = dict(configuration, **{key: "recording-only"})
                with self.assertRaises((PointingError, PtuError)):
                    LocalBenchClient.open(settings=broken, ptu_id=2, **self.controls())
                serial.assert_not_called()

    def test_query_only_rejects_motion_before_activation_and_passively_disconnects(self):
        client, native = self.client(readback_settings())
        for operation in (lambda: client.preview(1, -10, **self.controls()),
                          lambda: client.move(1, **self.controls()),
                          lambda: client.stop(**self.controls())):
            with self.assertRaises(PtuError) as caught:
                operation()
            self.assertEqual(caught.exception.primary, "unsupported")
        self.assertEqual((native.opens, native.writes), (0, []))
        self.assertEqual(client.connect(**self.controls()).category, "ok")
        count = len(native.writes)
        self.assertEqual(client.disconnect(**self.controls()).category, "ok")
        client.close(deadline=self.deadline)
        self.assertEqual(len(native.writes), count)

    def test_numeric_move_reuses_the_same_checked_packet_and_preview_only_once(self):
        client, native = self.connected()
        preview = client.preview(1.23, -10, **self.controls())
        self.assertEqual(preview.category, "ok")
        prepared = client._bench_previews[client._sender][3]
        moved = client.move(preview.preview_sequence, **self.controls()).as_record()
        self.assertEqual(moved["category"], "ok")
        self.assertEqual(native.motion(), [prepared.packet])
        self.assertEqual([item["operation"] for item in moved["exchanges"]], ["status", "move"])
        self.assertEqual(moved["physical_state"], "indeterminate")
        self.assertEqual(client.status(**self.controls()).pan, 1.2)
        self.assertEqual(client.move(preview.preview_sequence, **self.controls()).category, "context_changed")
        self.assertEqual(len(native.motion()), 1)

    def test_final_packet_no_go_and_decimal_change_checks_match_managed_owner(self):
        configuration = manual_settings()
        configuration["manual_context"].update(pan_min=-100, pan_max=0, max_change_degrees=20,
            no_go_rectangle=dict(pan_min=-70, pan_max=-30, tilt_min=-90, tilt_max=0))
        client, native = self.connected(configuration)
        native.pan_units, native.tilt_units = -800, -700
        client._bench.check_target(-70.04, -70, (-80, -70))
        self.assertEqual(client.preview(-70.04, -70, **self.controls()).category, "endpoint_rejected")
        self.assertEqual(client.preview(-79, -71, **self.controls()).category, "endpoint_rejected")
        self.assertEqual(native.motion(), [])
        configuration = manual_settings()
        configuration["manual_context"]["max_change_degrees"] = .15
        client, native = self.connected(configuration)
        native.pan_units = 11
        self.assertEqual(client.preview(.95, -10, **self.controls()).category, "endpoint_rejected")
        self.assertEqual(native.motion(), [])

    def test_stale_preview_and_changed_position_never_submit_motion(self):
        client, native = self.connected()
        preview = client.preview(1, -10, **self.controls())
        native.pan_units = 1
        self.assertEqual(client.move(preview.preview_sequence, **self.controls()).category, "context_changed")
        preview = client.preview(1, -10, **self.controls())
        stored = client._bench_previews[client._sender]
        observation = list(stored[4])
        observation[4] -= 2
        client._bench_previews[client._sender] = (*stored[:4], tuple(observation))
        before = len(native.writes)
        self.assertEqual(client.move(preview.preview_sequence, **self.controls()).category, "context_changed")
        self.assertEqual(len(native.writes), before)
        self.assertEqual(native.motion(), [])

    def test_zero_partial_unknown_and_complete_failed_moves_are_never_retried(self):
        for result, submission in ((0, "none"), (2, "partial"), (OSError("fixture"), "unknown"),
                                   (None, "complete")):
            with self.subTest(submission=submission):
                client, native = self.connected()
                preview = client.preview(1, -10, **self.controls())

                def failure(command):
                    if command == 0x33:
                        native.result = result
                        native.auto_ack = False

                native.before_write = failure
                record = client.move(preview.preview_sequence, **self.controls()).as_record()
                self.assertNotEqual(record["category"], "ok")
                self.assertEqual(record["submission"], submission)
                self.assertEqual(record["exchanges"][-1]["submission"], submission)
                self.assertEqual(len(native.motion()), 1)
                native.before_write, native.result, native.auto_ack = None, None, True
                self.assertEqual(client.stop(**self.controls()).category, "ok")
                self.assertEqual(native.opens, 1)
                self.assertEqual(len(native.motion()), 1)

    def test_cancelled_move_does_not_cancel_later_status_or_stop(self):
        client, native = self.connected()
        movement_cancel = threading.Event()
        preview = client.preview(1, -10, **self.controls(movement_cancel))

        def cancel_move(command):
            if command == 0x33:
                movement_cancel.set()
                native.auto_ack = False

        native.before_write = cancel_move
        moved = client.move(preview.preview_sequence, **self.controls(movement_cancel))
        self.assertEqual((moved.category, moved.submission), ("cancelled", "complete"))
        native.before_write, native.auto_ack = None, True
        self.assertTrue(movement_cancel.is_set())
        self.assertEqual(client.status(**self.controls()).category, "ok")
        self.assertEqual(client.stop(**self.controls()).category, "ok")
        self.assertEqual(native.opens, 1)

    def test_stop_pending_blocks_move_after_status_without_mixing_receipts(self):
        configuration = manual_settings()
        configuration["manual_context"]["exchange_timeout_seconds"] = 1
        client, native = self.connected(configuration)
        preview = client.preview(1, -10, **self.controls())
        entered, release = threading.Event(), threading.Event()
        outcomes = {}

        def pause_status(command):
            native.before_write = None
            entered.set()
            if not release.wait(.5):
                raise AssertionError("fixture release")

        native.before_write = pause_status
        move = threading.Thread(target=lambda: outcomes.update(move=client.move(
            preview.preview_sequence, **self.controls())))
        stop = threading.Thread(target=lambda: outcomes.update(stop=client.stop(**self.controls())))
        move.start()
        try:
            self.assertTrue(entered.wait(.5))
            stop.start()
            self.assertTrue(client._bench_stop_pending.wait(.5))
        finally:
            release.set()
            move.join(1)
            if stop.ident is not None:
                stop.join(1)
        self.assertFalse(move.is_alive())
        self.assertFalse(stop.is_alive())
        self.assertEqual(outcomes["move"].category, "busy")
        self.assertEqual(outcomes["stop"].category, "ok")
        self.assertEqual([item["operation"] for item in outcomes["move"].as_record()["exchanges"]], ["status"])
        self.assertEqual([item["operation"] for item in outcomes["stop"].as_record()["exchanges"]], ["stop", "status"])
        self.assertEqual(native.motion(), [])

    def test_stop_followup_deadline_retains_ack_and_latches_failure(self):
        client, native = self.connected()
        original = native.write
        stopped = False

        def write(packet):
            nonlocal stopped
            decoded = client._driver.protocol._decode_strict_packet(packet, 2)
            if decoded[0] == 0x31 and decoded[1] == 2:
                stopped = True
            elif stopped:
                native.auto_ack = False
            return original(packet)

        native.write = write
        record = client.stop(**self.controls()).as_record()
        self.assertEqual((record["category"], record["submission"], record["state"]),
                         ("deadline", "complete", "stop_failed"))
        self.assertEqual([item["category"] for item in record["exchanges"]], ["ok", "deadline"])
        native.write, native.auto_ack = original, True
        self.assertEqual(client.status(**self.controls()).state, "stop_failed")
        self.assertEqual(client.stop(**self.controls()).state, "stop_failed")
        self.assertEqual(client.preview(1, -10, **self.controls()).category, "busy")

    def test_stop_lock_timeout_stays_latched_before_held_move_can_submit(self):
        configuration = manual_settings()
        configuration["manual_context"]["exchange_timeout_seconds"] = 1
        client, native = self.connected(configuration)
        preview = client.preview(1, -10, **self.controls())
        entered, release = threading.Event(), threading.Event()
        outcomes = {}

        def pause_status(command):
            native.before_write = None
            entered.set()
            if not release.wait(.5):
                raise AssertionError("fixture release")

        native.before_write = pause_status
        move = threading.Thread(target=lambda: outcomes.update(move=client.move(
            preview.preview_sequence, **self.controls())))
        move.start()
        try:
            self.assertTrue(entered.wait(.5))
            stopped = client.stop(deadline=time.monotonic() + .03, cancel=self.cancel)
            self.assertEqual(stopped.category, "deadline")
            self.assertEqual(stopped.state, "stop_failed")
            self.assertEqual(stopped.as_record()["exchanges"], [])
            self.assertFalse(client._bench_stop_pending.is_set())
        finally:
            release.set()
            move.join(1)
        self.assertFalse(move.is_alive())
        self.assertEqual(outcomes["move"].category, "busy")
        self.assertEqual([item["operation"] for item in outcomes["move"].as_record()["exchanges"]], ["status"])
        self.assertEqual(native.motion(), [])

    def test_passive_cleanup_failure_retains_owner_and_can_be_retried(self):
        client, native = self.connected()
        count = len(native.writes)
        native.close_failure = True
        with self.assertRaises(PointingError) as caught:
            client.close(deadline=self.deadline)
        self.assertEqual(caught.exception.primary, "cleanup_incomplete")
        self.assertFalse(client._closed)
        with self.assertRaises(PtuError) as caught:
            client.status(**self.controls())
        self.assertEqual(caught.exception.primary, "closed")
        native.close_failure = False
        self.assertTrue(client.close(deadline=self.deadline))
        self.assertEqual(len(native.writes), count)
        self.assertFalse(native.opened)

    def test_cleanup_lock_deadline_still_gates_driver_and_retains_retry(self):
        client, native = self.connected()
        entered, release = threading.Event(), threading.Event()
        count = len(native.writes)

        def hold_operation():
            with client._operation:
                entered.set()
                release.wait(.5)

        holder = threading.Thread(target=hold_operation)
        holder.start()
        try:
            self.assertTrue(entered.wait(.5))
            with self.assertRaises(PointingError) as caught:
                client.close(deadline=time.monotonic() + .03)
            self.assertEqual(caught.exception.primary, "cleanup_incomplete")
            self.assertTrue(client._closing.is_set())
            self.assertTrue(client._driver._pointing_closing)
            self.assertFalse(client._closed)
        finally:
            release.set()
            holder.join(1)
        self.assertFalse(holder.is_alive())
        self.assertTrue(client.close(deadline=self.deadline))
        self.assertFalse(native.opened)
        self.assertEqual(len(native.writes), count)

    def test_buffered_response_never_becomes_fresh_local_readback(self):
        client, native = self.connected(readback_settings())
        native.response.extend(b"\x06\x31\x03")
        count = len(native.writes)
        record = client.status(**self.controls()).as_record()
        self.assertEqual(record["category"], "serial_failure")
        self.assertFalse(record["has_observation"])
        self.assertEqual(record["exchanges"][0]["category"], "stale-response")
        self.assertEqual(len(native.writes), count)

    def test_selected_alias_busy_error_does_not_reopen_or_close_existing_owner(self):
        first, first_native = self.client()
        configuration = manual_settings()
        configuration["manual_context"]["serial_settings"]["port"] = "/dev/serial/by-id/usb-recording-alias"
        second, second_native = self.client(configuration)
        claimed = self.selected_ownership(first_native, second_native)
        self.assertEqual(first.connect(**self.controls()).category, "ok")
        record = second.connect(**self.controls()).as_record()
        self.assertEqual(record["category"], "busy")
        self.assertEqual(second_native.writes, [])
        second.close(deadline=self.deadline)
        self.assertIs(claimed["/dev/ttyUSB0"], first_native)
        self.assertTrue(first_native.opened)
        self.assertEqual(first.status(**self.controls()).category, "ok")
        self.assertEqual((first_native.opens, second_native.opens), (1, 1))

    def test_broker_and_local_modes_cannot_acquire_each_others_selected_device(self):
        for first_route in ("broker", "local"):
            with self.subTest(first_route=first_route), ExitStack() as stack:
                bus = MessageBus()
                bus.install(stack)
                configuration = manual_settings()
                driver, broker_native = controlled_bench_driver(stack, configuration)
                manager = PtuManager.open_bench(messenger=bus.messenger, settings=configuration,
                    ptu_id=2, driver=driver, run_deadline=self.deadline, cancel=self.cancel)
                stack.callback(lambda: manager.close(deadline=time.monotonic() + 1))
                local, local_native = self.client(configuration)
                claimed = self.selected_ownership(broker_native, local_native)
                if first_route == "broker":
                    manager.activate(**self.controls())
                    self.assertEqual(local.connect(**self.controls()).category, "busy")
                    self.assertEqual(local_native.writes, [])
                    local.close(deadline=self.deadline)
                    self.assertIs(claimed["/dev/ttyUSB0"], broker_native)
                else:
                    self.assertEqual(local.connect(**self.controls()).category, "ok")
                    with self.assertRaises(PointingError) as caught:
                        manager.activate(**self.controls())
                    self.assertEqual(caught.exception.primary, "busy")
                    self.assertEqual(broker_native.writes, [])
                    manager.close(deadline=self.deadline)
                    self.assertIs(claimed["/dev/ttyUSB0"], local_native)
                    local.close(deadline=self.deadline)
