from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

from satgs._operator_contract import OperatorError
from satgs.operator_activity import StationLease
from satgs.operator_cli import main
from satgs.operator_core import initialize_workspace
from satgs.operator_gui import OperatorPresenter
from satgs.operator_install import DISTRIBUTIONS


def wheel(directory, name, requires=()):
    normalized = name.replace("-", "_")
    info = normalized + "-1.0.dist-info"
    contents = {
        info + "/METADATA": "Metadata-Version: 2.1\nName: " + name + "\nVersion: 1.0\n"
            "Provides-Extra: manager\n" + "".join("Requires-Dist: " + value + "\n" for value in requires) + "\n",
        info + "/WHEEL": "Wheel-Version: 1.0\nGenerator: test\nRoot-Is-Purelib: true\nTag: py3-none-any\n",
    }
    contents[info + "/RECORD"] = "".join(path + ",,\n" for path in (*contents, info + "/RECORD"))
    with ZipFile(directory / (normalized + "-1.0-py3-none-any.whl"), "w") as archive:
        for path, value in contents.items():
            archive.writestr(path, value)


class OperatorInstallTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="satgs-install-test-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.workspace = initialize_workspace(self.root / "station")
        self.wheels = self.root / "wheels"
        self.wheels.mkdir()
        self.environment = self.root / "new environment"
        self.save("guided_arrow")

    def save(self, profile, changes=None):
        preview = self.workspace.preview_components(profile, changes=changes)
        self.workspace.apply(preview["preview_id"])

    def inputs(self, failure=None):
        for name in ("meteor-api", "satgs", "ptu-control", "serialptu", "pixhawk"):
            wheel(self.wheels, name, requires=failure if name == "satgs" and failure else ())

    def test_offline_cli_install_omits_unselected_owner_and_preserves_station_and_old_environment(self):
        self.inputs()
        self.save("custom", {"pixhawk": "omit", "pointing.pixhawk": "omit", "pointing.dual_gps": "omit"})
        old = self.root / "previous environment"
        old.mkdir()
        (old / "retained").write_text("previous selection")
        station = self.workspace.station_path.read_bytes()
        output = io.StringIO()
        with redirect_stdout(output):
            code = main(["--workspace", str(self.workspace.root), "--format", "json", "install-software",
                         "--wheelhouse", str(self.wheels), "--environment", str(self.environment)])
        self.assertEqual(code, 0, output.getvalue())
        result = json.loads(output.getvalue())["result"]
        self.assertTrue(result["software_complete"])
        self.assertFalse(result["profile_complete"])
        self.assertFalse(result["application_selected"])
        self.assertFalse(result["services_started"])
        self.assertEqual(result["packages"], {DISTRIBUTIONS[row["component"]]: "1.0"
                         for row in result["selection"]["selections"]
                         if row["component"] in DISTRIBUTIONS and row["mode"] != "omit"})
        self.assertNotIn("pixhawk", result["packages"])
        self.assertEqual(self.workspace.station_path.read_bytes(), station)
        self.assertEqual((old / "retained").read_text(), "previous selection")
        receipt = Path(result["receipt_file"])
        self.assertEqual(json.loads(receipt.read_text())["result"], "installed")
        saved = json.loads(receipt.read_text())
        saved["unrelated_private_field"] = "private canary"
        receipt.write_text(json.dumps(saved))
        self.assertTrue(any(row["result"] == "installed" for row in self.workspace.report()["installations"]))
        self.assertNotIn("private canary", json.dumps(self.workspace.report()))
        log = Path(result["log_file"]).read_text()
        self.assertIn("--no-index", log)
        self.assertIn("--only-binary=:all:", log)
        self.assertNotIn("--no-deps", log)
        with self.assertRaisesRegex(OperatorError, "new path"):
            self.workspace.install_software(self.wheels, self.environment)

    def test_full_missing_owners_and_direct_url_dependency_reject_before_environment_creation(self):
        self.inputs()
        self.save("full_msel")
        with self.assertRaises(OperatorError) as failure:
            self.workspace.install_software(self.wheels, self.environment)
        for name in ("satgs-post-processing", "cyberpowerpdu", "dsi", "signal-hound-control", "bbdevice"):
            self.assertIn(name, str(failure.exception))
        self.assertFalse(self.environment.exists())
        self.assertEqual(list(self.workspace.root.glob("install-*.json")), [])
        self.save("guided_arrow")
        wheel(self.wheels, "satgs", requires=("unexpected @ https://example.invalid/package.whl",))
        with self.assertRaisesRegex(OperatorError, "direct URL"):
            self.workspace.install_software(self.wheels, self.environment)
        self.assertFalse(self.environment.exists())

    def test_failed_resolution_is_retained_and_presenter_reports_failure(self):
        self.inputs(failure=("unavailable-dependency==9",))
        presenter = OperatorPresenter(self.workspace)
        presenter.dispatch("refresh")
        before = self.workspace.station_path.read_bytes()
        outcome = presenter.dispatch("install_software", wheelhouse=self.wheels, environment=self.environment)
        self.assertFalse(outcome["ok"], outcome)
        result = outcome["result"]
        self.assertEqual(result["result"], "failed")
        self.assertFalse(result["software_complete"])
        self.assertTrue(Path(result["receipt_file"]).is_file())
        self.assertTrue(Path(result["log_file"]).is_file())
        self.assertEqual(self.workspace.station_path.read_bytes(), before)
        self.assertEqual(len(self.workspace.report()["installations"]), 2)

    def test_busy_stale_reuse_and_station_destination_refuse_before_install(self):
        self.inputs()
        with StationLease(self.workspace.root), self.assertRaises(OperatorError):
            self.workspace.install_software(self.wheels, self.environment)
        with self.assertRaisesRegex(OperatorError, "Station changed"):
            self.workspace.install_software(self.wheels, self.environment, expected_revision="0" * 64)
        with self.assertRaisesRegex(OperatorError, "outside the station"):
            self.workspace.install_software(self.wheels, self.workspace.root / "environment")
        self.save("custom", {"meteor-api": "reuse"})
        with self.assertRaisesRegex(OperatorError, "cannot reuse"):
            self.workspace.install_software(self.wheels, self.environment)
        self.assertFalse(self.environment.exists())

    def test_destination_creation_failure_keeps_a_failed_result_receipt(self):
        self.inputs()
        with patch("satgs.operator_install.Path.mkdir", side_effect=PermissionError("fixture denied")):
            result = self.workspace.install_software(self.wheels, self.environment)
        self.assertEqual(result["result"], "failed")
        self.assertEqual(result["exit_code"], 4)
        self.assertFalse(result["software_complete"])
        self.assertTrue(Path(result["receipt_file"]).is_file())
