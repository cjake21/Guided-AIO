# 10. Original M-SEL to current SATGS

The integrated product retains the original component responsibilities. Use
this map to find a familiar task, then follow its linked playbook. Routine
operation uses an installed release; these component names do not ask you to
check out or switch an original repository branch.

## Start with the task you already know

| Original owner or task | Current destination | Procedure |
| --- | --- | --- |
| ground_station setup and station coordinates | Setup, Location and shared CLI operations | [Install](installation.md), then [configure a site](station-location.md) |
| Satellite CSV and CelesTrak TLE maintenance | ground_station's `add_tle`, `del_tle`, `pass_finder`; manual CSV editing | [TLE catalog playbook](operator-tutorial.md#maintain-a-tle-catalog) |
| Direct PTU arrow/angle operation | Existing PTU tab and shared CLI session through sat_tracker and serialptu | [PTU-only playbook](operator-tutorial.md#install-and-use-a-local-ptu-instance) |
| Low-level serial commands | Original serialptu protocol owner | [Inspect encoded commands](operator-tutorial.md#inspect-a-ptu-command-packet-without-connecting-hardware) |
| Higher-level whole-pass tracking | sat_tracker PTU client/manager, shared pass runner and reviewed run records | [Prepare a tracking request](operator-tutorial.md#prepare-and-review-a-tracking-request) |
| Cube/GPS observations | Pixhawk manager/subscriber | [GPS owner configuration](operator-tutorial.md#configure-the-pixhawk-gps-owner) |
| Messenger.py integration | `meteor_api.messenger.Messenger` | [Shared message owner](operator-tutorial.md#use-the-shared-messenger-owner) |
| RF, power, recording and analysis | Their retained Full M-SEL owners | [Full owner map](installation.md#the-ten-full-m-sel-software-owners) and [component handbook](component-handbook.md) |

## Installation, selection and location

Use Full M-SEL to select the complete ten-owner package set, Guided Arrow for
the portable foundation, or Custom for a task such as TLE-only or local PTU-only.
The [worked selections](configurations.md#choose-packages-for-a-specific-job)
give the exact rows. Save the selection, install its software into a new
environment, then configure the services and devices assigned to that instance.

Original planning YAML uses `ground_station_lat`, `ground_station_lon` and
`ground_station_altm`. Native Location stores latitude/longitude in degrees,
altitude in metres and an explicit altitude reference in the selected station.
Supply the matching configuration to the tool you are using. Saving native
Location does not edit a separate YAML file. Use another workspace for another
site, or preview/save relocation; older plans then require revalidation.

## Prediction and TLE inputs

| Task | Retained command or current action | Inputs and result |
| --- | --- | --- |
| Fetch a new satellite | `add_tle NORAD_ID --satfile CATALOG` | Downloads elements for an absent ID and writes the CSV |
| Delete a satellite | `del_tle NORAD_ID --satfile CATALOG` | Removes the entire row; keep a catalog backup |
| Check catalog age and calculate passes | `pass_finder -config YAML --satfile CATALOG --duration DAYS --elmask DEGREES` | Refreshes stale selected rows, then predicts from the current time |
| Calculate from an explicit local file | Results > Calculate, or `satgs-operator plan` | Saves a native plan for one NORAD ID, site, UTC start, span and mask |
| Export a legacy run sheet | Add `--to_csv` to `pass_finder` | Writes `passes_utc_...csv` in YAML `run_sheet_dir` |
| Export a station report | Results > Export..., or `satgs-operator export` | Writes a new JSON snapshot |

`pass_finder` uses `--sids` to select existing catalog IDs and checks all rows
when it is omitted. Its freshness threshold is 0.5 days. `add_tle` leaves an
existing ID unchanged. Native Calculate reads the selected CSV without fetching
or rewriting it. Follow the [complete examples](operator-tutorial.md#maintain-a-tle-catalog)
for exact commands, formats and verification.

A native JSON report and a legacy schedule CSV have different consumers. Keep
catalogs, run sheets, native plans and run recordings under their own names.

## Direct and queued operations

The distributed queue remains owned by ground_station. On a configured full
station, its command names are `add_pass`, `add_schedule`, `request_gs_queue`,
`remove_pass` and `clear_gs_queue`. They operate on broker jobs. A native plan or
reviewed request is a local record, not a queue submission.

Native Run prepares a request from a saved plan and explicit deployment/runtime
inputs. Review run records those inputs; Start run separately requests execution.
Use the [run procedure](operator-tutorial.md#review-a-run-request) and retain the
returned request ID for status, cancellation and results. Removing a queued job,
cancelling a local request and commanding physical Stop have different effects.

The pass runner owns observation, prime/track/completion and cleanup. Keep its
raw artifacts alongside the native request/progress/result files when reviewing
a run. The software result describes command submission and owner outcomes;
inspect returned equipment state for the corresponding physical result.

## Pixhawk, PTU and results

Pixhawk's positive sensor ID selects an application source. Its host USB port
connects the Cube; receiver UARTs connect the GPS units to that Cube. Neither is
the PTU application's manager ID or the PTU serial wire address. Use the exact
[sensor mapping and field reference](operator-tutorial.md#configure-the-pixhawk-gps-owner).

For manual QPT130 work, use the [PTU tab](ptu-operation.md). Its local controls
retain familiar left/right and up/down directions, held jog and returned status.
Numeric moves use Preview then Move. Keep the shared session as the serial
owner and close it before another application uses that port. The PTU chapter
compares the original serialptu GUI's gestures and soft-limit behavior.

Results > Report and Export... inspect the native station history. Original
RF captures, telemetry CSVs, truth logs and post-processing outputs remain with
their producing owners. [Results](results.md) explains which files are saved,
how to reopen them and what to retain when moving or backing up a station.

Source revisions, original pins and current implementation symbols are listed
in the [technical appendix](maintainer-reference.md).
