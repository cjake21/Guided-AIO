# 1. Purpose and architecture

SATGS is the main application for the modular M-SEL / Guided Arrow ground
station. Choose the work you need, install its owners, configure your instance,
then follow that task's playbook. The native window and `satgs-operator` CLI
share the same station settings and results.

**Guide version:** local candidate `jog-20261124.1`, November 24, 2026. It includes the
selected-software installer, bounded local QPT130 Connect and directional device
soft-limit feedback. Pi and physical acceptance of jog6 are pending. Open the matching
installed guide through Help > User Guide or `satgs-operator docs`.

## Find the instructions for your job

Start with [Installation](installation.md#get-the-software-for-your-instance).
Each task below gives the package choice, inputs, actions and expected output.

| I want to... | Install or select | Playbook |
| --- | --- | --- |
| Fetch and store a current TLE from CelesTrak | TLE-only Custom: ground_station and meteor-api | [Fetch a TLE](operator-tutorial.md#fetch-and-store-one-current-tle-from-celestrak) |
| Enter known TLEs or remove a catalog entry | Same TLE-only selection | [Manual entry](operator-tutorial.md#manually-enter-or-replace-elements-you-already-have) and [delete](operator-tutorial.md#delete-a-satellite-with-the-existing-command) |
| Check the whole satellite catalog and refresh old elements | Same TLE-only selection | [Refresh with pass_finder](operator-tutorial.md#check-all-stored-satellites-and-refresh-stale-elements) |
| Calculate when a satellite is visible | Same TLE-only selection, with a saved site | [Calculate a native plan](operator-tutorial.md#calculate-a-native-plan-from-the-file) |
| Move the PTU with arrows or numeric angles | PTU-only Custom: ground_station, meteor-api, sat_tracker, serialptu | [Local PTU control](operator-tutorial.md#install-and-use-a-local-ptu-instance) |
| Build and inspect a serial command in my own software | serialptu library | [Packet inspection](operator-tutorial.md#inspect-a-ptu-command-packet-without-connecting-hardware) |
| Prepare and review a satellite tracking request | Station/pass owners including sat_tracker | [Tracking request](operator-tutorial.md#prepare-and-review-a-tracking-request) |
| Configure the GPS subsystem and understand its observations | pixhawk subscriber or manager role | [Pixhawk configuration](operator-tutorial.md#configure-the-pixhawk-gps-owner) |
| Use the shared message library in an integration | meteor-api and its paired transport | [Messenger configuration](operator-tutorial.md#use-the-shared-messenger-owner) |
| Prepare the entire M-SEL station | Full M-SEL: all ten software owners | [Full installation](operator-tutorial.md#prepare-a-full-m-sel-instance) and [every GUI tab](daily-operation.md#walk-through-every-tab) |

For TLE maintenance, use the named console commands or a CSV editor, then open
the resulting file on Results. For manual PTU work, use the existing PTU tab or
its shared CLI session. The component references are for integrations and
separately configured distributed services.

## Choose your starting point

- First installation: [choose packages](configurations.md#choose-packages-for-a-specific-job),
  [install them](installation.md), then open your task's playbook above.
- Existing installation: use the [daily quickstart](daily-operation.md#daily-quickstart).
- Original M-SEL user: find the corresponding owner and command in
  [Original M-SEL to current SATGS](legacy-comparison.md).
- Practice session: follow [Practice without hardware](operator-tutorial.md#practice-without-hardware)
  in a separate workspace using the supplied historical inputs.
- Configuration or command detail: use the [component handbook](component-handbook.md),
  [CLI reference](operator-cli-reference.md) and [technical appendix](maintainer-reference.md).

## The five core component owners

The original component repositories remain the owners of their responsibilities
inside the integrated software. They are not separate applications to install
for every job, and selecting a use case does not require switching Git branches.

| Owner | Installed package | Responsibility | Typical use |
| --- | --- | --- | --- |
| ground_station | satgs | Main native GUI/CLI, station settings, TLE tools, pass planning and orchestration | Catalog maintenance, station setup, plans and reports |
| serialptu | serialptu | Serial command construction, response parsing and encoded PTU targets | Low-level integrations; driver beneath local PTU control |
| sat_tracker | ptu_control | PTU sessions, client/manager and higher-level pass tracking | Manual control and the pointing lifecycle of a pass |
| Pixhawk | pixhawk | Cube/MAVLink navigation observations and subscriber logging | GPS/attitude subsystem |
| meteor-api | meteor_api | Messenger publish/subscribe between application owners | Distributed PTU, navigation, queue and other services |

The Messenger implementation is `meteor_api/messenger.py`, imported as
`from meteor_api.messenger import Messenger`. The ActiveMQ server is a separate
service. Explicit local serial PTU control and local orbit calculation run
without that server.

Full M-SEL also includes RF, power, recording, native receiver and processing
owners. Their [distribution map](installation.md#the-ten-full-m-sel-software-owners)
and [component sections](component-handbook.md) explain what to select.

## Understand installation, configuration and observation

Installation places selected software into an environment. Setup > Preview and
Review > Save record configuration. Setup > Install software performs the
separate software installation. A station workspace keeps settings, plans,
receipts and operation results; the daily launcher selects the application used
to open it. Keep these paths distinct when maintaining several instances.

A saved manual location records coordinates supplied by the operator. A GPS
position is a measurement received from a receiver. Saving coordinates does
not demonstrate GPS reception or align the antenna. Likewise, a requested PTU
target and its returned position are separate values.

Use the source, timestamp, fix, health, freshness and operation outcome shown
for the task. A received message confirms receipt; the operation's result and
the equipment's returned state establish what happened. [Results](results.md)
explains how to reopen and retain that evidence.
