# 6. Set the station location and understand navigation

Set a manual position when you know the stationary planning site's coordinates.
The orbit calculator uses this saved site for subsequent plans. A location save
does not rotate the antenna, calibrate a PTU, survey the site or determine north.

## Enter coordinates with the correct units

On Location enter latitude, longitude, altitude and Altitude reference.
Latitude and longitude are decimal degrees: north/east positive and south/west
negative. Latitude must be from -90 through 90; longitude from -180 through 180.
Altitude is metres, not feet. All numbers must be finite. The shared location
value does not add a separate numerical altitude bound.

Choose `mean_sea_level` only when that is the intended declared reference.
`unspecified` records that the reference has not been established. The choice
does not convert a datum or apply a geoid correction. Runtime manual binding
requires its supported declared reference and exact saved revision in addition
to owner admission; an unspecified-reference numerical plan is not admitted
execution input.

The [practice tutorial](operator-tutorial.md#cancel-a-location-preview) supplies
complete commands using synthetic 34 degrees north, -118 degrees east and
100 metres. Do not copy those values into a real station.

## Preview save and reload

Click Preview to open Review. Inspect previous and proposed values and affected
plans. Cancel (Esc) leaves the saved coordinates unchanged and retains a
cancellation artifact. To save instead, Preview again and click Save. A cancelled
preview cannot later be applied.

CLI uses the same operation:

```text
location-preview --latitude-deg NUMBER --longitude-deg NUMBER
                 --altitude-m NUMBER
                 --altitude-reference unspecified|mean_sea_level
apply --preview RETURNED_PREVIEW_ID --confirm
```

This is grammar, not a runnable site definition. Use the tutorial's complete
sequence to obtain the actual returned identity. JSON holds it under
`result.preview_id`; human output intentionally omits internal identifiers.

After Save, Home > Reload or `reload` reads the saved station. Close and reopen
that workspace to confirm persistence. Another GUI/CLI save can make a preview
stale. Reload and review a new one; there is no force-save option. Repeating a
completed apply returns its existing receipt without another generation change.

A save can change `station.json` before a later receipt/durability step fails.
The result then reports partial failure. Reload first. If that operation remains
current, repeating apply can recover its receipt without changing the site
twice. Keep partial artifacts rather than assuming an error means nothing saved.

A managed run or PTU session holds the station activity lease. Location Save is
refused while that lease is held; it cannot change an active run's frozen site.
Wait for the owned activity and cleanup to finish, then review a fresh preview.
An accepted change applies to subsequent planning, not the run already admitted.

## Relocate or use another site

For a new permanent site, Preview and Save the changed coordinates, then calculate
a new plan. Old plans retain their original inputs and are marked
`revalidation_required: true`; they do not silently move to the new site.
The [relocation exercise](operator-tutorial.md#compare-planning-inputs-after-relocation)
changes only longitude and compares the recorded planning inputs.

For occasional planning at another locale, use another workspace and open it
through Home > Open station.... The native application has no legacy `--at`
locale alias. A separate workspace avoids repeatedly changing the daily site's
saved position and keeps its plans/results together.

## Read measured observations separately

Location shows manual, measured/replay and effective position separately.
The GPS panel reports source/fix/time/freshness when observation evidence exists.
Use GPS is disabled in this workflow; save the planning site using the manual
fields above.

A reported 3D fix is not enough to choose the planning site. A message can be
received while system health is critical or heading remains unqualified.
`fresh_replay` describes a fixed synthetic fixture, not a current clock reading.
Incomplete aggregates do not acquire manufactured coordinates or a fabricated
final unpublished observation.

Manual configuration remains usable when GPS is unavailable. Do not initialize
a station or overwrite a known position just to replace an unknown observation.
Inspect source identities and private navigation records with the responsible
owner when a measured source is needed.

## Qualify heading and alignment separately

Site latitude/longitude determine where the station is. Antenna heading and
calibration determine how its pointing frame relates to the sky. Dual-GPS
heading also depends on receiver identities/fixes, antenna baseline, mounting,
source references and the navigation stack. Cube USB is the host transport;
GPS UART wiring/configuration is another responsibility.

No location choice establishes mechanical limits, safe trajectory clearance,
physical Stop or arrival. Those remain part of the allocated unit's separate
pointing/navigation commissioning procedure. Continue with [PTU operation](ptu-operation.md)
for software session behavior and [Plans and runs](operator-tutorial.md) for
site-bound planning.
