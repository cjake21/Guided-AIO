# 5. Start and use the GUI or CLI

## Daily quickstart

On your normal local or remote desktop, open the application menu and choose
SATGS. The terminal equivalent is:

```sh
satgs-operator-gui
```

No virtual-environment activation or versioned application path is needed.
Inspect the selected station before changing it:

```sh
satgs-operator status
satgs-operator docs
```

The daily wrappers use the saved release and workspace. The usual daily station
is `/home/admin/satgs/station`. A missing station is an error, not an instruction
to initialize or replace it. Leave a working accepted selection alone until a
reviewed update is ready. [Updates](updates-troubleshooting.md) explains separate
installation, acceptance and explicit selection.

The preceding guide release is the retained rollback choice. This handbook uses
its own `handbook` selection after acceptance. Selection changes which installed
application the wrappers use. It does not open a window, choose a hardware unit,
select a profile or select live/replay observations.

## Use a desktop, remote desktop or SSH

A remote desktop attached to your normal graphical login can use the menu and
window like a local desktop. An SSH-only session should use the CLI and:

```sh
satgs-operator docs --text
```

Do not force `DISPLAY=:0` or borrow another desktop session's permissions. A
forwarded or inherited display variable does not establish a usable desktop.
The documentation dispatcher uses terminal fallback in SSH/headless sessions.

Sourced setup updates PATH in that terminal only. Shell profiles and global PATH
are unchanged. If a new terminal cannot find the commands, use the installed
wrappers directly:

```sh
~/.local/bin/satgs-operator status
~/.local/bin/satgs-operator-gui
```

## Choose the station workspace

A workspace is the private directory containing saved station settings and
artifacts. Home > Open station... opens an existing workspace in this window.
Home > New station... creates a new one; it refuses an existing directory rather
than resetting it. Use a separate workspace for another site or practice task.

An explicit path changes only the current invocation:

```sh
satgs-operator --workspace "$satgs_practice_station" status
satgs-operator-gui --workspace "$satgs_practice_station"
```

The variable is created by the [practice tutorial](operator-tutorial.md).
Keep quotes around paths containing spaces. Opening another workspace does not
retarget the saved daily launcher selection. Direct developer package entry
points have different defaults, described in the [CLI reference](operator-cli-reference.md).

## Find the right page

| Page | Use it for | Saved or observed result |
| --- | --- | --- |
| Home | Inspect the station, open/create a workspace and Reload (Ctrl+R) | Saved settings and separately reported status dimensions |
| Setup | Choose Profile, QPT130 model and Custom modes/providers; Preview | Proposed component intent, not installation |
| Location | Enter decimal-degree site coordinates and altitude/reference; Preview | A proposed manual planning position |
| Review | Inspect previous/proposed values, then Save or Cancel (Esc) | A receipt or cancellation artifact |
| Results | Enter local TLE/start/NORAD/span/elevation; Calculate, Report, Export... | Retained plans and a new report file |
| Run | Provide explicit input files; Review run, Start run, Cancel run | Reviewed request and separate progress/result artifacts |
| PTU | Save the explicit transport/setup, Connect, inspect returned position, use local held jog or Preview/Move, Stop and Disconnect | Session outcomes and returned observations, with physical results confirmed by the operator |

Help > User Guide opens this installed release's offline guide without discarding
drafts or changing the selected tab. The same content is available through
`satgs-operator docs`, `satgs-operator --read-docs` and `docs --text`. Docs work
before station initialization and with missing or invalid station configuration.
A viewer-dispatch success means the local viewer was invoked, not that a human
saw a rendered window. Unavailable/failed viewers fall back to readable text.

## Interpret status before acting

| Display | Meaning and useful next step |
| --- | --- |
| Selection: No data / `unconfigured` | No saved canonical selection. Choose and review intent on Setup when needed. |
| No location set. | Enter a deliberate manual position on Location before planning. |
| `unknown` | No admitted evidence establishes that dimension. Check its assigned source or validation record. |
| `selected_local` | Component intent is saved; installation and readiness remain separate. |
| `unqualified` heading/calibration | Coordinates and message receipt do not establish antenna alignment. Use the separate qualification procedure. |
| `critical` with `transport_pass` | Health and transport can disagree. Inspect both rather than treating received messages as health. |
| `fresh_replay` | A fixed synthetic observation, not a current live timestamp. |

Generation counts saved configuration changes, not messages or installations.
New stations start at generation 1. JSON status retains identities, source times
and diagnostics that everyday human output omits. After another GUI/CLI saves,
Reload before editing. If a preview conflicts, reload and create a fresh preview;
there is no force-save override.

Continue with [Station location](station-location.md) or the
[hardware-free practice workflow](operator-tutorial.md).

## Walk through every tab

Use this order after installing a Full, Guided or Custom instance. The same
window serves each selection. A tab is a view of shared operations; use the
pages relevant to your job. Opening a tab does not connect equipment.

### Home: choose the station and inspect state

Use **New station...** to create a new workspace beneath an existing parent.
An existing directory is refused. Use **Open station...** to resume the directory
containing your saved `station.json`. Use **Reload (Ctrl+R)** after another CLI or
GUI saves. Keep the chosen station path with your results so you can reopen the
same history later.

Read the station name, saved profile/location, independent status dimensions and
last saved operation. Unknown installation, fix, transport or heading is not
changed to ready by opening the application. The new installer records candidate
installation receipts separately; Home's installation dimension can remain
unknown. Inspect Results > Report for the actual candidate installation outcome.
The Home station is separate from the daily launcher's saved application path.

CLI equivalents are `init`, `status` and `reload`, with an explicit
`--workspace` for a separate instance. Opening an example station in the window
does not change the daily default selection for the next launch.

### Setup: select software and responsibilities

Choose **Profile** `full_msel`, `guided_arrow` or `custom`, and the supported
**PTU model**. This Pelican case accepts QPT130. Preview the profile to see its
component rows. For Custom, use **Selection mode** and **Provider** for each
row, following [the task selection table](configurations.md#choose-packages-for-a-specific-job).
Use `install` for software to place in a new environment and `omit` for an
unneeded owner. `external` assigns only a supported external responsibility;
it does not create a connector. A new isolated environment cannot borrow a
`reuse` package from the old app.

Click **Preview**, inspect Review, and **Save**. Return to Setup and enter
**Offline wheel directory** and **New environment directory**, such as
`/home/admin/satgs-install-inputs/wheels` and a new
`/home/admin/satgs-full-app`. Click **Install software**. See
[Installation](installation.md) for obtaining the release-matched inputs.

Results shows the installation outcome. A missing wheel list or retained failed
environment is not a successful installation. Success does not start services
or change the daily selection. The CLI operations are `components-preview`,
confirmed `apply`, and the newer `install-software`.

### Location: save the planning site

Enter decimal-degree **Latitude**, **Longitude**, **Altitude (metres)** and the
**Altitude reference**. North/east are positive; west longitude is negative.
For the historical tutorial only, enter `34.0`, `-118.0`, `100.0` and
`mean_sea_level`. Use your actual site/reference for current planning.

Click Preview and Save on Review. Future plans use the new saved location; old
plans require revalidation, and an active run retains its frozen inputs. The
measured/replay panel shows observations separately. For this workflow use manual
entry; **Use GPS** is disabled. Saving the site does not program the Cube or
calibrate antenna north.
This tab changes native station settings, not a separate legacy pass-finder
YAML. CLI: `location-preview`, then confirmed `apply`.

### Review: inspect and confirm one change

Review displays previous/proposed values for the identified component or location
preview. Check the profile, package modes/providers, hardware instance identities,
coordinates/units and diagnostics. **Save** confirms that preview. **Cancel
(Esc)** discards its application and leaves saved settings unchanged.

If the station changes elsewhere, reload and preview again; do not reuse an old
ID or force the save. Review's Save is neither software installation nor a motion
command. CLI: `apply --preview RETURNED_ID --confirm` or
`cancel --preview RETURNED_ID`.

### Results: calculate, inspect and export

For a pass calculation, enter **Start (UTC ISO 8601)** with an explicit offset,
**NORAD ID** found in your local CSV, **Span (days)**, **Minimum elevation (deg)**
and **Local TLE CSV**. For the historical worked file enter
`2025-05-16T03:00:00Z`, `25338`, `1`, `20` and its absolute path. Valid spans are
one hour through seven days; elevation is 0 through 90 degrees. For today's
planning, supply current suitable elements and the intended current start.

Click **Calculate**. A plan and its inputs are saved in `plan-<id>.json` beneath
the station. A result with no opportunities is possible for valid inputs.
Calculate reads the CSV without refreshing it and never sends tracking commands.
Maintain the file through the TLE recipe first.

**Report** reads saved configuration, plan summaries, installation records,
PTU attempts and their actual outcomes. **Export...** writes a new JSON snapshot
to the **New report file** path. Choose an existing parent and unused filename,
for example `/home/admin/satgs-exports/first-ptu-session.json` after creating that
export directory. Export does not collect RF captures, copy the entire workspace
or upload to storage. CLI: `plan`, `report`, `export --output NEW_FILE`.

### Run: bind a plan to supported runtime owners

Choose a saved **Plan**. Supply actual, separately prepared **Configuration
JSON**, **Runtime bindings JSON**, **Owner settings** and **Local TLE CSV** files.
The configuration must match the saved selection, the bindings must identify
the intended owners, and the TLE must match the planned input. These files are
not all created by Setup Save and cannot be replaced with guessed example paths.

Enter **Duration (seconds)** as a positive duration inside the opportunity and
**Opportunity (1-based)**, such as `1` for the first returned opportunity. Choose
**Execution mode** deliberately. **Review run** freezes those inputs; inspect
the request before **Start run**. **Cancel run** requests local cancellation.
A cancellation request is not confirmation of remote cancellation or physical
Stop. A `rehearsal` choice does not bypass owner requirements.

This page's review endpoint is a saved request. Execution requires an accepted
runtime binding and a separately confirmed Start. Use the PTU tab for explicit
local manual control. Full RF queue, receiver and processing operations use their
configured component owners. CLI equivalents are `run-preview`, `run-start`,
`run-status` and `run-cancel`.

### PTU: operate the explicitly selected manual connection

Use **Save local QPT130** for the reviewed local default or imported reviewed
local setup. Saving does not connect. **Connect** acquires exclusive ownership
and reads actual angles. Inspect **Reported pan/tilt** and **Status** before
motion. **Target pan/tilt** are separate requested values in mechanical degrees.

Local directional arrows are held jog; release requests Stop. Give **Keys** focus
for keyboard arrows. A numeric move requires a permitted target, **Preview**,
then **Move**. For example, if the returned position is 100 degrees pan and
20 degrees tilt, and 101/20 is physically cleared and within your configured
numeric policy, enter pan `101` and tilt `20`, preview, then deliberately move.
Those numbers illustrate the fields; they are not a commissioning target.

**Stop** sends the supported Stop operation and records its outcome. Inspect
returned evidence and the actual unit before **Disconnect** releases ownership.
Continuous jog and numeric endpoint checks have different contracts, described
in [PTU operation](ptu-operation.md). The broker route remains explicit; its
**Broker step (degrees)**, **Enable broker steps** and **Disarm** controls do not
select local serial automatically.

CLI: `bench-configure --transport local-serial`, then `bench` with its session
commands. Use one writer at a time. Results are retained beneath the selected
station. Software checks, command acknowledgements and physical observations
remain distinct. Inspect each operation's returned outcome.
