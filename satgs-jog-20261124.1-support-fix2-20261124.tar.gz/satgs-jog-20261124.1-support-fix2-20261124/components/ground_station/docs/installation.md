# 4. Install and prepare the selected deployment

An already accepted daily application normally needs no reinstall. Inspect it
with `satgs-operator status` and read its installed guide first. Install an
update into a separate candidate environment, check it, then explicitly select
it. Keep the current application, station, dependencies and failed attempts.

## Get the software for your instance

Obtain the versioned release archive and its target-platform offline wheel
directory from the internal Bitbucket release page. Extract them into a new
directory on the machine where this instance will run. On the Pi use its ARM64,
CPython 3.11 inputs. Keep the existing application installed while preparing
another instance.

Next choose the packages in Setup, save the selection, then use **Install
software** to install that choice from the local wheel directory. Downloading
happens before opening this form; the GUI and CLI use the same local inputs.

Choose the versioned archive and its adjacent README on `artifacts/releases`.
Use that release's setup instructions for the initial operator application.
The [guide version notice](operator-guide.md) identifies which installer this
preview describes. A source pull synchronizes source; install the resulting
release to update the Pi application.

Use the complete, release-matched wheel directory for the owners you choose.
Dependency resolution installs each selected owner's required Python libraries.
A fresh environment gives each task its own installed package set.

| Task | Local owner packages to select | Packages/services you can leave out |
| --- | --- | --- |
| TLE fetch/store/delete/manual catalog and local pass calculations | ground_station (`satgs`) and meteor-api, plus their dependencies | PTU, serial driver, Pixhawk, RF/PDU/recording/processing owners and ActiveMQ server |
| Existing native local PTU tab and CLI | ground_station, meteor-api, sat_tracker with its manager extra, serialptu | Pixhawk/pymavlink, RF/PDU/recording/processing owners and ActiveMQ server |
| Full M-SEL | All ten owners below, with matching dependencies | Only responsibilities explicitly omitted or externally assigned by a supported configuration; a reduced selection is Custom |

### The ten Full M-SEL software owners

| Setup package row | Installed distribution | Purpose |
| --- | --- | --- |
| ground_station | satgs, with Full plotting/front-end library extras | Native GUI/CLI, station configuration, TLE/pass calculations and orchestration |
| meteor-api | meteor_api, with the selected stomp.py dependency | Python messaging used by the owners; does not install an ActiveMQ server |
| sat_tracker | ptu_control with manager dependencies | Shared PTU control and tracking owner |
| serialptu | serialptu and its serial dependencies | QPT protocol and local serial driver |
| pixhawk | pixhawk with manager dependencies | Cube/GNSS/attitude observation owner |
| msel_post_processing | satgs-post-processing | Capture parsing, quick-look reports and retained processing/storage tools |
| cyberpowerpdu | cyberpowerpdu | PDU/HPA power-control owner |
| dsi_instruments | dsi | RF front-end and loopback owner |
| signal_hound | signal_hound_control | Signal Hound IQ/spectrum recording owner |
| signal_hound_native_wrapper | bbdevice, with compatible vendor/native library | Receiver API wrapper and native runtime |

The GUI displays catalog package names; pip metadata and console commands can
use the distribution names in the middle column. The `satgs[full]` extra alone
does not install these ten owners. Java/ActiveMQ, clock synchronization, Tk/Tcl,
device permissions and vendor libraries remain separate host responsibilities.

### Set up paths for a worked example

The following commands assume the updated operator application is installed and
available as `satgs-operator`. Run them in Bash. They create a new example parent
and a new station, separate from the daily station:

```sh
satgs_example_root=$(mktemp -d "$HOME/satgs-examples.XXXXXXXX") || exit 1
satgs_task_station="$satgs_example_root/task-station"
satgs-operator --workspace "$satgs_task_station" init
printf 'Example parent: %s\nStation: %s\n' "$satgs_example_root" "$satgs_task_station"
```

Save `tle-only.json` or `ptu-only.json` from
[Task package selections](configurations.md#choose-packages-for-a-specific-job)
under that parent. Use a new task station for each recipe. GUI equivalents are
Home > New station... beneath an existing parent, then Home > Open station...
when resuming. Record the actual absolute paths shown on your machine.

For example, after extracting the supplied wheel directory:

```sh
satgs_task_wheels="$HOME/satgs-install-inputs/wheels"
satgs_task_app="$HOME/satgs-tle-app"
```

For a PTU or Full example, choose a different new environment name such as
`satgs-ptu-app` or `satgs-full-app`. These variables do not download anything or
create the wheel directory. An existing environment path will be refused.

## Prerequisites and assigned responsibilities

The native release pairs satgs and ptu_control at `0.0.1+jog.20261124.1` with
serialptu `0.0.1+jog.20261124.1`. It retains the paired Meteor/lower
loopback versions. Other reviewed runtime dependencies are reused. Explicit
local-serial bench control does not require ActiveMQ or a manager service.
The established target route uses the existing CPython 3.11 environment and its
offline dependency inputs. Native GUI work needs usable Tk/Tcl and a normal
desktop session; CLI docs and local station operations do not need a display.

Before preparing an installation, assign the runtime account, candidate and
evidence directories, preserved station workspace and intended software roles.
For services, also assign the responsible administrator and real resource
identities. Do not turn a PTU label, USB example or sample broker address into
an operational binding.

| Resource | Responsible role | Information required before operational use |
| --- | --- | --- |
| Application and offline dependency inputs | Release maintainer/operator | Exact release content, compatible interpreter/platform, separate candidate paths |
| ActiveMQ and time | Host/service administrator | Broker release, Java runtime, address/identity/trust, private authentication, time source |
| PTU manager and physical unit | Pointing/equipment owner | Stable instance, application ID, model/protocol/baud/wire address, policy and position/Stop contracts |
| Pixhawk and dual GPS | Navigation owner | Sensor/PTU IDs, host connection, receiver connections, source/fix/time/reference/heading qualification |
| RF, power and recording | RF/equipment owners | Instruments, outlet mapping, receiver/native support, frequency/power constraints and output capacity |
| Processing and optional storage | Data/service owner | Parser compatibility, input/output directories, retention and private service access |

## Install the native release offline

Obtain the versioned PTU update through its existing internal browser/download
route. Extract it into its own new directory and open a Bash terminal there.
Do not extract over an older delivery or copy files into accepted site-packages.
The release's root README is the exact handoff for that package.

The setup entry point is:

```sh
. ./setup_update.sh --accept-trusted-native
```

The trusted-native flag acknowledges the reviewed CPython/stdlib/native boundary;
the Python API/audit controls are not syscall isolation. Setup reuses retained
offline dependencies and stages a separate candidate. It does not select it,
reset a station, connect equipment or start operational services.

After setup succeeds, run the consolidated acceptance from the same extraction.
Select only after its report passes and there is no conflicting activity:

```sh
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog6
```

For a fresh account, the updated setup stops after staging when no saved daily
selection exists. Check and explicitly create/select a new station beneath your
existing home directory:

```sh
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --bootstrap jog6 --initialize-station "$HOME/satgs-station"
```

The new station path must not already exist. This uses the installed application's
normal initializer, saves that path in the daily selection, and opens no GUI.
Then open **SATGS** from the menu. Bootstrap without `--initialize-station`
prepares only the initial application selection; Home can create/open a station
for that invocation. Repeating plain bootstrap preserves an existing selection.
Explicit initialization is refused when a daily selection already exists. Any
partially created station is retained if preparation fails.

## Install the saved software selection

In **Setup**, choose Full M-SEL, Guided Arrow or a supported Custom selection,
click **Preview**, then **Save** on Review. Return to Setup. Enter the directory
containing the release's complete, compatible offline wheels and a new environment
directory. Click **Install software**. The saved selection determines the packages;
unsaved changes must be saved first. The window remains responsive during installation.

The equivalent CLI operation is:

```sh
satgs-operator install-software --wheelhouse /absolute/path/to/release-wheels --environment /absolute/path/to/new-application
```

Using the worked-example variables after Preview and Save:

```sh
satgs-operator --workspace "$satgs_task_station" install-software --wheelhouse "$satgs_task_wheels" --environment "$satgs_task_app"
```

In the GUI, open that task station, then enter absolute paths in **Offline wheel
directory** and **New environment directory**. For example, a Pi user might
enter `/home/admin/satgs-install-inputs/wheels` and `/home/admin/satgs-tle-app`.
Those are example locations, not directories provided by every archive. Type
expanded paths in the GUI; it does not expand shell variables such as `$HOME`
or a leading `~`. Click **Install software** and read the Results outcome.

Success includes `result: installed` and `software_complete: true`, with the
installed package versions. To check or open that newly created environment
while keeping the daily application selection intact:

```sh
"$satgs_task_app/bin/satgs-operator" --workspace "$satgs_task_station" status
"$satgs_task_app/bin/satgs-operator-gui" --workspace "$satgs_task_station"
```

Use the installed environment's entry points for the remainder of that example.
The installer does not register arbitrary new paths as daily release aliases.
Normal published Pi updates use their release's checked setup/select procedure
to change the daily launcher. Closing the example window does not change that
saved daily selection.

The operation creates a separate Python environment, installs selected software
with dependency resolution using only the supplied wheels, runs `pip check`, and
reads the selected distribution versions from that environment. Python's `venv`
and bundled `ensurepip` must be available. Matching native Tk/Tcl and vendor/OS
libraries remain platform prerequisites. Installation does not import equipment
modules, connect devices, start services or change the daily application selection.

Results and Report/export retain separate `install-<id>-started.json` and
`install-<id>-result.json` records in the station. The new environment contains
`satgs-install.log`. A failure preserves that environment and its log; use a new
path after correcting inputs. Existing environments are refused. Configuration
Save receipts and installation receipts remain distinct. Repeating installation
cannot overwrite the previous environment. A `reuse` software selection must be
changed to `install` for a new isolated environment; it cannot borrow another
environment's packages.

Full M-SEL selects all ten catalog packages. Guided Arrow selects its five
owners. Custom installs only the owners marked `install`; the installer includes
the local manager extras for selected PTU and Pixhawk owners.

A successful receipt means the requested software installed and its Python
dependencies checked. Read `software_complete` for that result. Read the separate
`profile_complete` and `unresolved` fields for the station's remaining assigned
system, service and hardware responsibilities. Configure those resources through
their owner procedures before running tasks that use them.

## Retain and select the native candidate

The staged native application is `/home/admin/satgs-jog-20261124-app-manager`.
The preceding `/home/admin/satgs-ptu-20261117-app-manager` is retained for rollback.
The saved station remains `/home/admin/satgs/station` unless the operator has
deliberately selected another workspace. Setup/acceptance print their separate
report and attempt paths. Keep `report.txt`, `summary.json`, `completion.json`,
`evidence.tar.gz` and failed/partial environments. Failure is a reason to retain
the current selection, not to delete the new attempt and try over its files.

Verify the selected commands from a different normal working directory:

```sh
satgs-operator docs --text
satgs-operator status
```

On the desktop, open SATGS from the menu and inspect the saved station. A setup
message about a menu item does not establish that the menu was clicked. Changed
host tests, Pi checks and equipment commissioning stay separately reported.

## Software roles and package selection

This table explains the maintained dependency selections. It is not an instruction
to run pip inside an accepted application. The reviewed setup builds/installs
the appropriate wheels together; a source pull alone does not install them.

| Role | Exact selected package or extra | Separate prerequisites |
| --- | --- | --- |
| Shared operator/planning application | `satgs==0.0.1+jog.20261124.1` | Python 3.10+, actual scientific dependencies; Tk only for the window |
| Pointing clients | `satgs[pointing]==0.0.1+jog.20261124.1` | Paired PTU client and `pixhawk==0.0.1`, assigned external owners if used |
| Local PTU owner prerequisites | `ptu_control[manager]==0.0.1+jog.20261124.1` | Retained `serialptu==0.0.1+jog.20261124.1`, SciPy; local bench needs no broker or running manager |
| Local Pixhawk manager | `pixhawk[manager]==0.0.1` | pyserial, pymavlink, NumPy and assigned observation source |
| Shared messaging | `meteor_api==2.2.0+bench.20261117.1` and `stomp.py==8.1.0+bench.20261117.1` | Independent ActiveMQ server and explicit reviewed transport settings |
| Optional Meteor ZeroMQ | `meteor_api[zmq]==2.2.0+bench.20261117.1` | NumPy/pyzmq for its actual METEOR paths |
| Plotting/front-end libraries | `satgs[plotting]`, `satgs[frontend]`, or `satgs[full]` at the same satgs version | Their libraries, plus separately provisioned RF owners/equipment |
| Optional Box integration | `satgs[box]` at the same satgs version | Internal package access, private credentials and assigned Box destination |

The `gui` extra is empty because Tk is a system/native prerequisite rather than
a pip-provisioned GUI framework. The build generates the reviewed protobuf
modules before packaging. Runtime installations use those generated modules and
do not need a compiler. A developer needs the maintained build instructions,
not an arbitrary system protoc chosen from an old compatibility table.

## Prepare messaging and time

Local planning needs neither server. A manager/queue deployment does. The
service administrator first records its assigned ActiveMQ release, compatible
Java, service account, listener and storage location. The historical source
runbook describes ActiveMQ Classic and `activemq.service`; it is not proof of a
newly qualified server installation for every target OS.

Configure verified TLS identity/trust and private broker authentication through
the service owner's approved route. Keep public certificate trust distinct
from certificate private keys. Application settings separately identify the
dial address, TLS server name, STOMP host where required and credentials.
Do not disable TLS verification or paste production values into this guide.

The separately selected mechanical bench also supports explicit plaintext STOMP
on `127.0.0.1:61613`, matching the original local recipe's protocol. Use
`satgs-operator bench-configure --transport loopback-plaintext-bench --output "$HOME/satgs/bench.json"`
to create matching private JSON/XML. It never
changes an operational TLS configuration, starts a server or installs Java.
This exception is not available to satellite pointing. See [PTU operation](ptu-operation.md).

After the administrator's separately authorized provisioning/start procedure,
these are useful service/time inspections on that assigned host:

```sh
systemctl status activemq.service --no-pager
chronyc sources
timedatectl
```

Confirm the selected source and actual synchronization, then the application's
transport/owner result. Keep the service endpoint and time source with the
station configuration. See the [Messenger settings reference](operator-tutorial.md#use-the-shared-messenger-owner)
for the application-side connection fields.

## Prepare a PTU owner

Decide whether the serial owner runs locally or is independently supplied.
Only a local owner needs the local manager/driver role. Allocate the exact
physical QPT130 and record the stable hardware instance, positive application
manager ID and separate serial wire identity. Confirm the model/protocol, baud,
adapter, permissions, calibration/no-go policy, reported-position semantics and
required Stop contract with the equipment owner.

The retained `ptu.service` shows the owning manager program, not a runnable recipe
for this unit. Its historical username, serial path and arguments must not be
copied as commissioning values. Use a reviewed bench setup document and owner
binding instead. Selected QPT130/PTCR20 manual and query-only sessions are admitted
through an explicitly saved local-serial connection or a validated temporary
configuration. The separate broker route requires its isolated broker using
either verified TLS or the explicit loopback-only plaintext bench selection.
Keep manual control and scheduled tracking as separate operations.

The supported software check uses the controlled owner path in consolidated
acceptance, then verifies the actual session outcomes and displayed provenance.
Do not start the original direct-serial GUI concurrently. See [PTU operation](ptu-operation.md)
for deliberate connect, readback, local press-and-hold jog, numeric moves,
retained broker steps and cleanup.

## Prepare navigation observations

Assign the Pixhawk application ID and PTU mapping, then the host-side Cube USB
connection. Separately record the two receiver UART connections and navigation
stack. A local `pixhawk[manager]` installation does not configure firmware,
receiver links, moving-baseline heading or antenna alignment.

The retained manager parser uses `--pix-id` and `--port`; its old README contains
a different ID flag. Treat the historical service file as a template only.
Before live use, the navigation owner supplies source identity, fix/health,
timestamp/freshness, coordinate/altitude references and heading/alignment evidence.
Use the [Pixhawk reference](operator-tutorial.md#configure-the-pixhawk-gps-owner)
for package roles, exact sensor mapping and telemetry fields. Enter the planning
site manually on Location.

## Prepare RF power and recording

A complete Full M-SEL deployment needs the actual dsi_instruments, cyberpowerpdu
and signal_hound owners, plus the native wrapper/vendor runtime and equipment.
Install the complete Full selection and prepare its native/runtime inputs for
the assigned receiver model.

The RF/equipment owner assigns instrument ports/names, PDU identity and outlet
mapping, receiver model/serial/native compatibility, approved operating limits
and output capacity. Adapt the corresponding service units to the runtime
account and reviewed configuration. Do not use broad recursive/world-writable
permissions from historical examples.

Inspect configuration and reported state under the equipment runbook before an
RF task. Turning on an HPA, switching routes or starting a recording is an
operational action, not an installer smoke test. Retain the resulting equipment status and capture configuration with the run.

## Prepare legacy processing and storage

Post-processing consumes legacy pass directories, not the native report JSON.
The data owner installs the compatible msel_post_processing package and parser,
plotting/report dependencies with the full station. It assigns input/output
locations, capacity, retention and backup. Retain raw captures and failures so
analysis can be repeated.

Box is optional and historically disabled by default. It requires separately
available internal `box-api-sync` tooling, private authentication, an assigned
destination and deliberate `box_connectivity` configuration. The retained queue's
automatic Box path is narrower than a general upload service. Native Export
does not use it. Optional email also needs protected owner-supplied SMTP settings.

Read [Results](results.md) for native saved files and the
[migration comparison](legacy-comparison.md) for the original output workflows.

## Source access and complete Full M-SEL installations

Maintainers obtain the maintained integration source through the internal
repository route described in [Updates](updates-troubleshooting.md). Preserve component ownership and notices. A Full source installation uses the
complete ten-owner tree and the compatible dependencies for those owners.

In that complete, prepared ground_station owner checkout the retained commands
for inspection and guarded legacy installation are:

```sh
./build.sh --non-interactive --profile full_msel --dry-run
./build.sh --non-interactive --profile full_msel
```

Run the second only under the separately approved full deployment procedure,
after its prerequisites and intended environment are reviewed. For Guided Arrow,
only the static dry-run route is supplied:

```sh
./build.sh --non-interactive --profile guided_arrow --dry-run
```

Use Setup > Install software or `install-software` for the selected offline
software workflow described in this chapter. Use the assigned service procedures
for host provisioning and activation.
