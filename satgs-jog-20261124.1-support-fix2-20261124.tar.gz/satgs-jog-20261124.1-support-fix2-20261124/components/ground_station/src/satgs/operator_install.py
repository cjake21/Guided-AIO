"""Offline software installation for a saved operator selection."""

from email.parser import BytesParser
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from uuid import uuid4
from zipfile import BadZipFile, ZipFile

from satgs._operator_contract import OperatorError
from satgs.deployment_plan import parse_configuration, validate_selection_contract
from satgs.operator_activity import ActivityError, MARKER, StationLease


DISTRIBUTIONS = {
    "meteor-api": "meteor-api", "ground_station": "satgs",
    "msel_post_processing": "satgs-post-processing", "cyberpowerpdu": "cyberpowerpdu",
    "dsi_instruments": "dsi", "pixhawk": "pixhawk", "sat_tracker": "ptu-control",
    "serialptu": "serialptu", "signal_hound": "signal-hound-control",
    "signal_hound_native_wrapper": "bbdevice",
}


def _normalized(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def _directory(value):
    path = Path(os.path.abspath(value))
    for parent in (*reversed(path.parents), path):
        if parent.is_symlink() or not parent.is_dir():
            raise OperatorError("Use an existing directory without symbolic-link parents.")
    return path


def _wheel_names(directory):
    names = set()
    try:
        wheels = sorted(directory.glob("*.whl"))
        if not wheels:
            raise OperatorError("The selected wheel directory contains no wheels.", "install_inputs", 3)
        for path in wheels:
            if path.is_symlink() or not path.is_file():
                raise OperatorError("Wheel inputs must be ordinary files.", "install_inputs", 3)
            with ZipFile(path) as archive:
                records = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
                if len(records) != 1 or archive.getinfo(records[0]).file_size > 1024 * 1024:
                    raise OperatorError("A wheel has invalid package metadata.", "install_inputs", 3)
                metadata = BytesParser().parsebytes(archive.read(records[0]))
            name = metadata.get("Name")
            if not name or not metadata.get("Version"):
                raise OperatorError("A wheel is missing its package identity.", "install_inputs", 3)
            if any("@" in requirement or "://" in requirement
                   for requirement in metadata.get_all("Requires-Dist", [])):
                raise OperatorError("Offline installation rejects direct URL dependencies in wheel metadata.",
                                    "install_inputs", 3)
            names.add(_normalized(name))
    except (OSError, BadZipFile, KeyError, UnicodeError):
        raise OperatorError("Cannot read the selected wheel metadata.", "install_inputs", 3) from None
    return names


def install_software(workspace, wheelhouse, environment, *, expected_revision=None):
    from satgs.operator_core import _activity, _bytes, _catalog, _digest, _write_new

    try:
        with StationLease(workspace.root):
            raw, settings = workspace._read()
            revision = _digest(raw)
            if expected_revision is not None and revision != expected_revision:
                raise OperatorError("Station changed; reload before installing.", "stale_revision", 3)
            selection = settings["operator"].get("selection")
            if selection is None:
                raise OperatorError("Preview and Save a component selection before installing.")
            catalog = _catalog()
            configuration = parse_configuration(selection, catalog)
            if validate_selection_contract(configuration, catalog):
                raise OperatorError("The saved component selection is incomplete or inconsistent.")
            software = [row for row in selection["selections"] if row["component"] in DISTRIBUTIONS
                        and row["mode"] != "omit"]
            reused = [row["component"] for row in software if row["mode"] != "install"]
            if reused:
                raise OperatorError("A new environment cannot reuse packages from another environment. "
                                    "Choose install for: " + ", ".join(reused), "install_inputs", 3)
            if not software:
                raise OperatorError("The saved selection has no software to install.")
            wheels = _directory(wheelhouse)
            destination = Path(os.path.abspath(environment))
            _directory(destination.parent)
            if destination.is_relative_to(workspace.root) or destination.is_relative_to(wheels):
                raise OperatorError("Choose an environment outside the station and wheel directories.")
            if destination.exists() or destination.is_symlink():
                raise OperatorError("The environment must be a new path; existing files were preserved.")
            available = _wheel_names(wheels)
            selected = {row["component"]: DISTRIBUTIONS[row["component"]] for row in software}
            missing = [component + " (" + name + ")" for component, name in selected.items() if name not in available]
            if missing:
                raise OperatorError("Missing selected software wheels: " + ", ".join(missing), "install_inputs", 3)
            requirements = sorted(set(selected.values()))
            requirements = [name + "[manager]" if name in ("ptu-control", "pixhawk") else
                            "satgs[full]" if name == "satgs" and selection.get("preset") == "full_msel" else name
                            for name in requirements]
            attempt = uuid4().hex
            receipt = {
                "schema": "satgs-software-install.v1",
                "operation": "install_software", "attempt_id": attempt,
                "workspace_id": settings[MARKER]["id"], "station_revision": revision,
                "selection": selection, "environment": str(destination), "wheelhouse": str(wheels),
                "configuration_saved": False, "application_selected": False, "services_started": False,
                "hardware_opened": False, "software_complete": False, "profile_complete": False,
                "verification": "distribution_metadata_and_pip_check", "native_runtime_verified": False,
                "unresolved": [row for row in selection["selections"]
                               if row["component"] not in DISTRIBUTIONS and row["mode"] != "omit"],
                "result": "started", "partial": True, "exit_code": 4,
            }
            _write_new(workspace.root / f"install-{attempt}-started.json", _bytes(receipt))
            log_path = destination / "satgs-install.log"
            receipt["log_file"] = str(log_path)
            environment_vars = {key: os.environ[key] for key in ("HOME", "LANG", "LC_ALL", "TMPDIR")
                                if key in os.environ}
            environment_vars.update(PATH=os.defpath, PIP_CONFIG_FILE=os.devnull)
            python = destination / "bin/python"
            packages = {}
            try:
                destination.mkdir(mode=0o700)
                with log_path.open("x", encoding="utf-8") as log:
                    def run(command):
                        log.write(json.dumps(command) + "\n")
                        log.flush()
                        result = subprocess.run(command, env=environment_vars, cwd=destination,
                                                stdout=log, stderr=subprocess.STDOUT, check=False, timeout=600)
                        if result.returncode:
                            raise OperatorError("Installation failed. Inspect the retained install log.", "install_failed", 4)

                    run([sys.executable, "-I", "-B", "-m", "venv", "--copies", str(destination)])
                    pip = [str(python), "-I", "-B", "-m", "pip", "--isolated",
                           "--disable-pip-version-check", "--no-input", "--no-cache-dir"]
                    run([*pip, "install", "--no-index", "--only-binary=:all:", "--find-links", str(wheels),
                         *requirements])
                    run([*pip, "check"])
                    script = ("import importlib.metadata as m,json,sys; "
                              "print(json.dumps({'python':sys.version,'packages':"
                              "{name:m.version(name) for name in sys.argv[1:]}}))")
                    try:
                        verified = subprocess.run([str(python), "-I", "-B", "-c", script, *sorted(selected.values())],
                                                  env=environment_vars, cwd=destination, capture_output=True,
                                                  text=True, check=False, timeout=60)
                    except subprocess.TimeoutExpired as error:
                        log.write(str(error.stdout or "") + str(error.stderr or "") + "\nVerification timed out.\n")
                        raise
                    log.write(verified.stdout + verified.stderr)
                    verified.check_returncode()
                    identity = json.loads(verified.stdout)
                    packages = identity["packages"]
                    receipt["python"] = identity["python"]
                    if workspace._read()[0] != raw:
                        raise OperatorError("Station changed during installation; the result is not current.", "stale_revision", 3)
                    receipt.update(result="installed", software_complete=True, partial=False, exit_code=0)
                    if (destination / "bin/satgs-operator").is_file():
                        receipt["status_command"] = [str(destination / "bin/satgs-operator"),
                                                     "--workspace", str(workspace.root), "status"]
            except (OSError, subprocess.SubprocessError, ValueError, KeyError, OperatorError) as error:
                receipt.update(result="failed", exit_code=getattr(error, "exit_code", 4),
                               error={"code": getattr(error, "code", "install_failed"),
                               "message": str(error) if isinstance(error, OperatorError) else
                               "Installation could not complete. Inspect the retained install log."})
            receipt["packages"] = packages
            receipt["receipt_file"] = str(workspace.root / f"install-{attempt}-result.json")
            _write_new(Path(receipt["receipt_file"]), _bytes(receipt))
            return receipt
    except ActivityError as error:
        raise _activity(error) from None
