"""Human views of operator documents, separate from stored and exported data."""

from copy import deepcopy
import json
from pathlib import PurePath
import re


LEGACY_STATION_NAME = "Synthetic operator practice station"

DISPLAY_PRIVATE_FIELDS = frozenset({
    "workspace", "workspace_id", "station_revision", "expected_revision", "revision",
    "schema", "schema_version", "installed_identity", "installation_path", "executable",
    "python_path", "source_revision", "contract_revision", "source_path", "support_path",
    "candidate_release_id", "inventory_id", "release_id", "build_manifest", "manifest",
    "git_branch", "git_commit", "branch", "commit", "provenance", "provenance_root",
    "planning_identity", "preview_id", "review_attempt", "request_id", "plan_id",
    "station_id", "attempt_id",
    "root", "path", "directory", "configuration_path", "evidence_path", "binding",
    "source_identity", "support_identity", "build", "contracts", "context_id", "time_basis",
})


def display_message(value):
    text = str(value)
    if re.search(r"(?<![A-Za-z0-9])[0-9a-fA-F]{40,64}(?![A-Za-z0-9])", text) or re.search(
            r"(?:^|\s)(?:/[^\s]+|file:/[^\s]+)", text):
        return "Cannot complete the operation. Check the selected input."
    return text


def display_document(value):
    """Keep operator state separate from internal document and installation identities."""
    def visible(item, field=None):
        if isinstance(item, dict):
            return {key: visible(nested, key) for key, nested in item.items()
                    if key not in DISPLAY_PRIVATE_FIELDS and
                    not any(part in str(key).lower() for part in ("sha256", "checksum", "digest")) and
                    not (key != "station_name" and isinstance(nested, str) and
                         re.fullmatch(r"[0-9a-fA-F]{40,64}", nested))}
        if isinstance(item, list):
            return [visible(nested, field) for nested in item]
        if isinstance(item, str) and field != "station_name":
            if item.startswith("/") or item.startswith("file:/"):
                return PurePath(item.removeprefix("file:")).name
            return display_message(item)
        return deepcopy(item)
    return visible(presentation_document(value))


def display_document_text(value):
    return json.dumps(display_document(value), indent=2, sort_keys=True,
                      ensure_ascii=True, allow_nan=False)


def station_name(value):
    return value if isinstance(value, str) and value not in ("", LEGACY_STATION_NAME) else "Station"


def _fields(value, names):
    return {name: deepcopy(value[name]) for name in names if name in value}


def gps_document(value):
    return _fields(value, (
        "available", "provenance", "live_hardware_observed", "source_id", "observation_time", "time_basis",
        "coordinates", "latitude_unit", "longitude_unit", "altitude_unit",
        "horizontal_reference", "altitude_reference", "fix", "freshness",
        "valid_for_station_selection",
    ))


def _plan_document(value):
    return _fields(value, (
        "plan_id", "station_revision", "location", "altitude_reference", "start_utc",
        "span_days", "elevation_mask_deg", "norad_id", "tle_sha256", "source",
        "tle_reference_time", "refresh_performed", "opportunities", "execution_enabled",
    ))


def _operation_document(value):
    return _fields(value, (
        "operation", "preview_id", "kind", "workspace_id", "result", "changed",
        "configuration_saved", "station_revision", "active_run_changed",
        "planning_revalidation_required", "owner_state", "receipt_recorded", "partial",
        "output",
    ))


def _deployment_document(value):
    document = _fields(value, (
        "operation", "apply_supported", "complete", "blocked", "configuration",
        "candidate_release_id", "inventory_id", "derived_requirements",
    ))
    document["outcomes"] = [_fields(item, (
        "component", "mode", "provider", "instance_ids", "derived", "reasons", "presence", "runtime_state", "outcome",
    )) for item in value.get("outcomes", [])]
    return document


def _station_document(value):
    document = _fields(value, (
        "workspace", "workspace_id", "station_revision", "generation", "case",
        "selection", "effective_location", "status", "observations", "owner_state",
        "capabilities", "last_operation",
    ))
    document["station_name"] = station_name(value.get("station_name"))
    if document.get("effective_location") is None:
        document["effective_location"] = "No location set."
    document["measured_gps"] = gps_document(value.get("measured_gps", {}))
    document["gps_selection"] = _fields(value.get("gps_selection", {}), ("enabled",))
    document["plans"] = [_fields(plan, ("plan_id", "station_revision", "revalidation_required"))
                         for plan in value.get("plans", [])]
    if value.get("deployment_plan") is not None:
        document["deployment_plan"] = _deployment_document(value["deployment_plan"])
    if "operation_results" in value:
        document["operation_results"] = [_operation_document(item) for item in value["operation_results"]]
    if "installations" in value:
        document["installations"] = deepcopy(value["installations"])
    return document


def presentation_document(value):
    if not isinstance(value, dict):
        return deepcopy(value)
    if "station_name" in value and "status" in value:
        return _station_document(value)
    if "result" in value and ("action" in value or set(value) == {"status", "result"}):
        document = deepcopy(value)
        document["result"] = presentation_document(value["result"])
        return document
    if "preview_id" in value and "proposed" in value:
        document = _fields(value, (
            "schema_version", "workspace_id", "kind", "expected_revision", "previous",
            "proposed", "affected_plans", "changed", "review_attempt", "preview_id",
        ))
        document["affected_plans"] = [
            _fields(plan, ("plan_id", "station_revision", "revalidation_required"))
            for plan in value.get("affected_plans", [])
        ]
        if value.get("kind") == "components":
            document["proposed"] = _fields(value["proposed"], ("configuration", "ptu_model"))
            document["proposed"]["plan"] = _deployment_document(value["proposed"]["plan"])
        return document
    if "opportunities" in value and "station_revision" in value:
        return _plan_document(value)
    if value.get("operation") in ("apply", "cancel", "export_report"):
        return _operation_document(value)
    if "profiles" in value and "components" in value:
        return _fields(value, ("apply_supported", "profiles", "components"))
    return deepcopy(value)


def human_text(value):
    document = display_document(value)
    lines = []
    if isinstance(document, dict) and "error" in document:
        error = document["error"]
        lines.extend((f"Error: {error['message']}", f"Code: {error['code']}"))
        if "result" not in document:
            if not set(document) - {"error", "status", "ok", "action"}:
                return "\n".join(lines)
            document = {key: nested for key, nested in document.items() if key != "error"}
        else:
            document = document["result"]
    elif isinstance(document, dict) and "result" in document and (
            "action" in document or set(document) == {"status", "result"}):
        if document.get("status") == "FAIL":
            lines.append("Operation incomplete.")
        document = document["result"]

    def append(item, depth=0):
        padding = "  " * depth
        if isinstance(item, dict):
            for key, nested in item.items():
                label = key.replace("_", " ").capitalize()
                if isinstance(nested, (dict, list)) and nested:
                    lines.append(f"{padding}{label}:")
                    append(nested, depth + 1)
                else:
                    lines.append(f"{padding}{label}: {scalar(nested)}")
        elif isinstance(item, list):
            for index, nested in enumerate(item, 1):
                lines.append(f"{padding}{index}.")
                append(nested, depth + 1)
        else:
            lines.append(f"{padding}{scalar(item)}")

    def scalar(item):
        if item is None or item == "":
            return "No data"
        if isinstance(item, bool):
            return "Yes" if item else "No"
        if item in ([], {}):
            return "None"
        return str(item)

    append(document)
    return "\n".join(lines)


def document_text(value):
    return json.dumps(presentation_document(value), indent=2, sort_keys=True,
                      ensure_ascii=True, allow_nan=False)
