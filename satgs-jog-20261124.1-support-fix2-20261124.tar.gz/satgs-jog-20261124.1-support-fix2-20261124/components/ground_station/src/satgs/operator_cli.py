"""Headless adapter for the shared offline operator workflow."""

import argparse
import json
import sys

from satgs._operator_contract import ALTITUDE_REFERENCES, OperatorError
from satgs.operator_presentation import human_text


class OperatorParser(argparse.ArgumentParser):
    def error(self, message):
        raise OperatorError('Unsupported operator arguments; use --help.')


def parser():
    root = OperatorParser(prog='satgs-operator', allow_abbrev=False,
        description='SATGS station configuration and results.')
    root.add_argument('--workspace', default='./satgs-workspace', metavar='PATH')
    root.add_argument('--format', choices=('human', 'json'), default='human')
    root.add_argument('--read-docs', action='store_true', help='Open the bundled user guide (alias of docs).')
    commands = root.add_subparsers(dest='command')
    docs = commands.add_parser('docs', help='Read the bundled offline user guide.', allow_abbrev=False)
    docs.add_argument('--text', action='store_true', help='Print the guide without a display or viewer.')
    init = commands.add_parser('init', help='Create a new workspace.', allow_abbrev=False)
    init.add_argument('--case', choices=('pelican-qpt130',), default='pelican-qpt130')
    for name, description in (
        ('status', 'Show station status.'),
        ('reload', 'Read the current saved selection again.'),
        ('catalog', 'Show profiles and components.'),
        ('report', 'Show the current report.'),
    ):
        commands.add_parser(name, help=description, allow_abbrev=False)
    location = commands.add_parser('location-preview', help='Preview explicit manual coordinates.', allow_abbrev=False)
    location.add_argument('--latitude-deg', type=float, required=True)
    location.add_argument('--longitude-deg', type=float, required=True)
    location.add_argument('--altitude-m', type=float, required=True)
    location.add_argument('--altitude-reference', choices=ALTITUDE_REFERENCES, required=True)
    location.add_argument('--expected-revision')
    components = commands.add_parser('components-preview', help='Preview canonical or Custom selection.', allow_abbrev=False)
    components.add_argument('--profile', choices=('guided_arrow', 'full_msel', 'custom'), required=True)
    components.add_argument('--changes', metavar='JSON_PATH', help='Custom selection changes')
    components.add_argument('--ptu-model', default='QPT130')
    components.add_argument('--expected-revision')
    install = commands.add_parser('install-software', help='Install the saved software selection offline into a new environment.',
                                  allow_abbrev=False)
    install.add_argument('--wheelhouse', required=True, metavar='DIRECTORY')
    install.add_argument('--environment', required=True, metavar='NEW_DIRECTORY')
    install.add_argument('--expected-revision')
    apply = commands.add_parser('apply', help='Confirm and save the identified preview.', allow_abbrev=False)
    apply.add_argument('--preview', required=True)
    apply.add_argument('--confirm', action='store_true')
    cancel = commands.add_parser('cancel', help='Cancel a preview without changing station configuration.', allow_abbrev=False)
    cancel.add_argument('--preview', required=True)
    plan = commands.add_parser('plan', help='Compute local numerical pass opportunities.', allow_abbrev=False)
    plan.add_argument('--start', default='2025-05-16T03:00:00Z', help='UTC time; default is the bundled historical replay.')
    plan.add_argument('--norad-id', type=int, default=25338)
    plan.add_argument('--span-days', type=float, default=1)
    plan.add_argument('--elevation-deg', type=float, default=20)
    plan.add_argument('--tle-file', metavar='LOCAL_CSV')
    run_preview = commands.add_parser('run-preview', help='Review a frozen runtime request.', allow_abbrev=False)
    run_preview.add_argument('--plan-id', required=True)
    for field in ('deployment-config', 'runtime-bindings', 'station-config', 'tle-file'):
        run_preview.add_argument('--' + field, required=True)
    run_preview.add_argument('--duration', required=True, type=float)
    run_preview.add_argument('--opportunity', type=int, default=1)
    run_preview.add_argument('--mode', choices=('operational', 'rehearsal'), default='operational')
    for name in ('run-start', 'run-status', 'run-cancel'):
        command = commands.add_parser(name, allow_abbrev=False)
        command.add_argument('--run-id', required=True)
        if name == 'run-start':
            command.add_argument('--confirm', action='store_true')
    export = commands.add_parser('export', help='Export a redacted report to a new private file.', allow_abbrev=False)
    export.add_argument('--output', required=True)
    replay = commands.add_parser('replay', help='Select a status scenario.', allow_abbrev=False)
    replay.add_argument('--state', required=True,
        choices=('unknown', 'disconnected', 'silent', 'no_fix', 'reported_3d', 'stale', 'mismatched', 'incomplete', 'critical'))
    bench = commands.add_parser('bench', help='Explicit PTU command session.', allow_abbrev=False)
    bench.add_argument('--configuration', help='Override the saved local PTU selection for this session.')
    configuration = commands.add_parser('bench-configure', allow_abbrev=False,
        help='Create a new explicit mechanical configuration without opening anything.')
    configuration.add_argument('--output', metavar='NEW_JSON', help='Export a new JSON, or omit for saved local setup.')
    configuration.add_argument('--import-configuration', metavar='JSON', help='Save an existing local configuration in the workspace.')
    configuration.add_argument('--transport', choices=('local-serial', 'loopback-plaintext-bench'),
                               default='loopback-plaintext-bench')
    configuration.add_argument('--manager-id', type=int, default=1)
    configuration.add_argument('--exchange-timeout', type=float, default=1)
    configuration.add_argument('--feedback-max-age', type=float, default=5)
    configuration.add_argument('--manual-max-change-deg', type=float)
    zone = configuration.add_mutually_exclusive_group()
    zone.add_argument('--no-go-rectangle', type=float, nargs=4, metavar=('PAN_MIN', 'PAN_MAX', 'TILT_MIN', 'TILT_MAX'))
    zone.add_argument('--no-go-unconfigured', action='store_true')
    return root


def dispatch(arguments):
    if arguments.command == 'docs':
        from satgs.operator_docs import dispatch_docs
        return dispatch_docs(text=getattr(arguments, 'text', False))
    if arguments.command == 'bench-configure':
        from satgs.operator_bench import configure_local_serial_bench, configure_loopback_bench, save_local_bench
        if arguments.output is None:
            if (arguments.transport != 'local-serial' or arguments.manual_max_change_deg is not None
                    or arguments.no_go_rectangle is not None or arguments.no_go_unconfigured
                    or arguments.manager_id != 1 or arguments.exchange_timeout != 1 or arguments.feedback_max_age != 5):
                raise OperatorError('Saved setup uses the selected local QPT130. Use --output for an explicit custom configuration.')
            from satgs.operator_core import Workspace
            return save_local_bench(Workspace(arguments.workspace), arguments.import_configuration)
        if arguments.import_configuration is not None:
            raise OperatorError('Use --import-configuration without --output to save the existing local selection.')
        options = dict(manager_id=arguments.manager_id, exchange_timeout=arguments.exchange_timeout,
                       feedback_max_age=arguments.feedback_max_age,
                       max_change_degrees=arguments.manual_max_change_deg)
        if arguments.no_go_unconfigured:
            options['no_go_rectangle'] = None
        elif arguments.no_go_rectangle is not None:
            options['no_go_rectangle'] = dict(zip(('pan_min', 'pan_max', 'tilt_min', 'tilt_max'),
                                                  arguments.no_go_rectangle))
        configure = configure_local_serial_bench if arguments.transport == 'local-serial' else configure_loopback_bench
        return configure(arguments.output, **options)
    from satgs.deployment_cli import CliInputError
    try:
        return _dispatch_station(arguments)
    except CliInputError as error:
        raise OperatorError(str(error)) from None


def _dispatch_station(arguments):
    from satgs.deployment_cli import read_json_document
    from satgs.operator_core import Workspace, initialize_workspace

    if arguments.command == 'init':
        return initialize_workspace(arguments.workspace, case=arguments.case).inspect()
    workspace = Workspace(arguments.workspace)
    if arguments.command == 'bench':
        from satgs.operator_bench import interactive_bench
        return interactive_bench(workspace, arguments.configuration, input_stream=sys.stdin, output_stream=sys.stdout)
    if arguments.command in ('status', 'reload'):
        return workspace.inspect()
    if arguments.command == 'catalog':
        return workspace.catalog()
    if arguments.command == 'location-preview':
        return workspace.preview_location(latitude_deg=arguments.latitude_deg,
            longitude_deg=arguments.longitude_deg, altitude_m=arguments.altitude_m,
            altitude_reference=arguments.altitude_reference, expected_revision=arguments.expected_revision)
    if arguments.command == 'components-preview':
        changes = read_json_document(arguments.changes)[1] if arguments.changes else None
        return workspace.preview_components(arguments.profile, changes=changes,
            ptu_model=arguments.ptu_model, expected_revision=arguments.expected_revision)
    if arguments.command == 'apply':
        if not arguments.confirm:
            raise OperatorError('Apply requires --confirm after reviewing the identified preview.')
        return workspace.apply(arguments.preview)
    if arguments.command == 'install-software':
        return workspace.install_software(arguments.wheelhouse, arguments.environment,
                                          expected_revision=arguments.expected_revision)
    if arguments.command == 'cancel':
        return workspace.cancel(arguments.preview)
    if arguments.command == 'plan':
        from satgs.operator_planning import plan_workspace
        return plan_workspace(workspace, start_time=arguments.start, norad_id=arguments.norad_id,
            span_days=arguments.span_days, elevation_deg=arguments.elevation_deg, tle_file=arguments.tle_file)
    if arguments.command == 'report':
        return workspace.report()
    if arguments.command == 'run-preview':
        return workspace.preview_run(plan_id=arguments.plan_id, deployment_config=arguments.deployment_config,
            runtime_bindings=arguments.runtime_bindings, station_config=arguments.station_config,
            tle_file=arguments.tle_file, duration=arguments.duration, opportunity=arguments.opportunity, mode=arguments.mode)
    if arguments.command == 'run-start':
        return workspace.execute_run(arguments.run_id, confirm=arguments.confirm,
            progress=lambda value: print('Run: ' + value.get('state', 'unknown'), file=sys.stderr))
    if arguments.command == 'run-status':
        return workspace.run_status(arguments.run_id)
    if arguments.command == 'run-cancel':
        return workspace.cancel_run(arguments.run_id)
    if arguments.command == 'export':
        return workspace.export_report(arguments.output)
    if arguments.command == 'replay':
        return workspace.replay(arguments.state)
    raise OperatorError('Unsupported operator command.')


def _print_output(output, json_output):
    print(json.dumps(output, sort_keys=True, ensure_ascii=True, allow_nan=False)
          if json_output else human_text(output))


def main(argv=None):
    supplied = list(sys.argv[1:] if argv is None else argv)
    json_output = any(argument == '--format=json' or
                      (argument == '--format' and supplied[index + 1:index + 2] == ['json'])
                      for index, argument in enumerate(supplied))
    try:
        arguments = parser().parse_args(supplied)
        json_output = arguments.format == 'json'
        if arguments.read_docs:
            if arguments.command is not None:
                raise OperatorError('Unsupported operator arguments; use --help.')
            arguments.command = 'docs'
        elif arguments.command is None:
            raise OperatorError('Unsupported operator arguments; use --help.')
        result = dispatch(arguments)
        if arguments.command == 'docs':
            if json_output:
                _print_output({'status': 'PASS', 'result': result}, True)
            elif result['mode'] == 'text':
                if result['message']:
                    print(result['message'], file=sys.stderr)
                print(result['text'], end='' if result['text'].endswith('\n') else '\n')
            else:
                print(result['message'])
            return 0
        partial = type(result) is dict and result.get('partial') is True
        exit_code = result.get('exit_code', 0) if type(result) is dict else 0
        output = {'status': 'FAIL' if partial or exit_code not in (0, 8) else
                  'INDETERMINATE' if exit_code == 8 else 'PASS', 'result': result}
        _print_output(output, json_output)
        return 4 if partial else exit_code
    except OperatorError as error:
        code = getattr(error, 'exit_code', 2)
        _print_output({'status': 'FAIL', 'error': {'code': getattr(error, 'code', 'invalid'),
            'message': str(error)}}, json_output)
        return code
    except KeyboardInterrupt:
        _print_output({'status': 'FAIL', 'error': {'code': 'cancelled', 'message': 'Local operation interrupted.'}}, json_output)
        return 130
    except Exception:
        _print_output({'status': 'FAIL', 'error': {'code': 'operation_failed',
            'message': 'Operator operation could not complete; inspect retained workspace artifacts.'}}, json_output)
        return 4


if __name__ == '__main__':
    raise SystemExit(main())
