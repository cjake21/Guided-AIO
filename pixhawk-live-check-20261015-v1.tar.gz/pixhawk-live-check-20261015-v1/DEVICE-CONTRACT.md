# Bounded live receive contract

This support is for a separately authorized operator-run attempt, not Codex
hardware execution. The launcher automatically binds its complete inventory and
the existing application, then runs device-free admission before opening the
selected interface. The accepted offline package and application are unchanged.

## Fixed device and operator preconditions

The operator supplied `/dev/ttyACM0`, USB interface `00`, 115200 baud and USB serial
`3E003A001251333232393436`. Admission resolves only
`/sys/class/tty/ttyACM0/device` and its bounded ancestors. It reads the matching
interface number, USB serial, observed numeric vendor/product IDs and tty device
number. It rejects ambiguous ancestry, a different serial/interface, a nonordinary
device node, or pre/post-open changes. It does not scan devices or choose a fallback.

Both explicit acknowledgements are required:

- All other readers of this Cube interface have been stopped by the operator, and
  the interface is reserved for this one bounded attempt.
- TTY open/close effects are accepted. These can affect USB control traffic and
  DTR/RTS even without an explicit configuration call.

The source opens once with `O_RDONLY`, `O_NOCTTY`, `O_NONBLOCK`, `O_CLOEXEC` and
`O_NOFOLLOW`. It issues only `TIOCEXCL` to restrict later nonprivileged opens, then
uses `tcgetattr` to require the existing 115200, local 8-bit, raw/no-echo/no-flow
configuration. It never changes baud, terminal flags, DTR/RTS or input buffers.
Failure closes the descriptor without takeover, repair, retry or reconnect.

`TIOCEXCL` does not evict an existing reader or prevent privileged bypass. Operator
exclusive-use confirmation is a precondition, not kernel-proven historical
ownership. No process scan or automatic process/service stop is included.

The descriptor cannot perform payload writes. The parser's send/write route is
also rejected and recorded. This is not proof of zero physical USB transmission:
terminal settings can be inspected only after opening, and unsafe inherited
echo/flow behavior cannot be ruled out retroactively during that short interval.
Unsafe settings abort before a receive read. The final report must retain this
limitation, including the observed `HUPCL` state.

## Guard integration

Load the hash-bound `live_device.py` and construct `DeviceGate` before activating
the protected import guard. The new guard may delegate an `open` event to
`gate.permit_open(args, caller)` only with the real immediate audit caller frame.
The classifier requires the exact gate method code, globals, gate instance and
active exact path/flags. All other events retain the accepted guard behavior.
Do not replace the guard with a broad device, `/sys`, ioctl or file-write allowance.

The captured ioctl function is used only at the single exact `TIOCEXCL` callsite.
No generic ioctl/FFI service is exposed. These are source-bound Python controls
with trusted installed native dependencies, not syscall isolation against hostile
code running inside the process.

## Actual application path and bounds

`make_connection` invokes the installed `mavutil.mavfile` parser and its normal
receive/autodetection logic, with a bounded source and denied write method.
`mavlink_connection`, `mavserial` and the manager constructor are never called.
The normal constructor would send four stream requests. The normal serial route
also opens read/write at 1200 baud before changing baud and can assert DTR/RTS and
flush input. Those operations are excluded here.

`run_live` bypasses operational constructors, invokes installed
`PixhawkManager.run`, uses its `FusedMsg.to_pb` publication, and passes serialized
bytes into the actual strict callback. It reuses the accepted fixture's subscriber
setup and nonoperational manager ID 17. No broker, service, worker or CSV logging
is involved. Live receipt timestamps are not replaced by fixture time.

The defaults are 60 seconds, 4 MiB input, 4096 decoded messages, 256 publications,
128 detailed decoded samples and 32 warning/error records. Every read checks the
deadline, including reads inside the parser loop. Reaching a cap is reported.
Finite stop/failure is raised from receive; sticky failures survive the manager's
bare publication exception handler. The descriptor closes in `finally`.

Missing messages produce `INCONCLUSIVE`, never an automatic stream request.
`OBSERVED` means the selected message types and at least one callback acceptance
were observed, not that navigation data are valid, fresh, calibrated or usable.
Report wire version separately from decoder version. The existing application's
mixed-source assembly, arrival-order overwrite, component defaults, ignored
source times, float32 conversion and incomplete-final-aggregate behavior remain.

## Offline tests

`test_live_support.run_tests(modules)` accepts already-admitted installed modules.
It must not be invoked through an unguarded application import path. Tests supply
only in-memory bytes, clocks and fake device primitives. Cases cover fragmented
frames, mixed wire versions, bad CRC, garbage deadlines, no data, disconnect,
write/generated-send denial, caps, swallowed publication failure, identity/node
changes, terminal rejection, exclusive-open failure and cleanup. The corrected
protected host run passed 21 such tests, including audit recursion/dispatch,
mid-read context drift and truthful close failure. Real driver/TTY behavior,
target import admission and live handling remain to be demonstrated on the Pi.
