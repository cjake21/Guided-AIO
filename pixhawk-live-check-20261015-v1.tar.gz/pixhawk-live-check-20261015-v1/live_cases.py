"""Actual installed manager/conversion/callback bridge, without constructors."""

from dataclasses import asdict
import hashlib
import logging

from live_transport import LiveStop, safe_value


def run_live(manager, subscriber, protobuf, conversion, topics, cases, connection):
    session = connection.session
    owner = object.__new__(manager.PixhawkManager)
    owner.simulate_hw = False
    owner.pix_id = cases.MANAGER_ID
    owner._datamsg = None
    owner.connection = connection
    client = cases._subscriber_owner(subscriber)
    publications = []

    class Publisher:
        def publish(self, topic, message):
            session.check()
            if session.publications >= session.limits.publications:
                session.stop('publication-limit')
            if topic != topics.DATA_MSG + '_' + str(cases.MANAGER_ID):
                session.fail('publication-topic')
            try:
                payload = message.SerializeToString()
                if type(payload) is not bytes or len(payload) > 4096:
                    session.fail('publication-body')
                decoded = protobuf.fused_msg()
                decoded.ParseFromString(payload)
                rejected_before = client._rejected
                client._receive_data(payload, '')
                accepted = client._rejected == rejected_before and cases.MANAGER_ID in client.pix_status
                if client._state.locked() or client._fault is not None:
                    session.fail('callback-state')
                session.publications += 1
                publications.append(dict(
                    index=session.publications, topic=topic,
                    payload_length=len(payload), payload_sha256=hashlib.sha256(payload).hexdigest(),
                    fields={field.name: safe_value(getattr(decoded, field.name))
                            for field in decoded.DESCRIPTOR.fields},
                    callback_accepted=accepted, callback_rejections=client._rejected,
                    callback_row=cases._json_value(asdict(conversion(client.pix_status[cases.MANAGER_ID])))
                    if accepted else None))
            except Exception as error:
                session.fail('publication-' + type(error).__name__)

    class Capture(logging.Handler):
        def emit(self, record):
            if record.levelno < logging.WARNING and not record.exc_info:
                return
            if len(session.log_records) >= session.limits.logs:
                session.fail('log-bound')
            session.log_records.append(dict(level=record.levelname, message=record.getMessage()[:240],
                exception=record.exc_info[0].__name__ if record.exc_info else None))
            if record.exc_info:
                session.fail('manager-caught-' + record.exc_info[0].__name__)

    owner.messenger = Publisher()
    root = logging.getLogger()
    old = root.handlers, root.level, root.disabled
    capture = Capture()
    root.handlers, root.disabled = [capture], False
    root.setLevel(logging.WARNING)
    try:
        try:
            owner.run()
        except LiveStop:
            pass
        else:
            session.fail('manager-returned-without-boundary')
    finally:
        try:
            connection.close()
        finally:
            root.handlers, level, root.disabled = old
            root.setLevel(level)
            capture.close()

    missing = sorted({'ATTITUDE', 'GPS_RAW_INT', 'GPS2_RAW', 'GLOBAL_POSITION_INT'} - set(session.message_types))
    accepted = sum(row['callback_accepted'] for row in publications)
    status = 'FAIL' if session.faults or session.write_attempts or not connection.closed else 'OBSERVED'
    if status == 'OBSERVED' and (not accepted or missing):
        status = 'INCONCLUSIVE'
    return dict(
        status=status, stop_reason=session.stop_reason, faults=list(session.faults),
        input_bytes=session.input_bytes, decoded_messages=session.messages,
        message_counts=dict(session.message_types), wire_versions=dict(session.wire_versions),
        sources=[dict(system=key[0], component=key[1], messages=value)
                 for key, value in sorted(session.sources.items())],
        missing_message_types=missing, decoded_samples=session.samples,
        omitted_decoded_samples=max(0, session.messages - len(session.samples)),
        publications=publications, callback_accepted=accepted,
        final_unpublished=cases._json_value(asdict(owner._datamsg)) if owner._datamsg is not None else None,
        logs=session.log_records, write_attempts=session.write_attempts, source_closed=connection.closed,
        operational_constructors_called=False, manager_identity='fixture-only-17',
        transport='single admitted input source; in-memory publication only',
        navigation='NOT QUALIFIED', physical_state='NOT OBSERVED', time_synchronization='UNCONFIRMED')
