#!/bin/sh
exec /usr/bin/env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C TZ=UTC PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 STOMP_SKIP_HOSTNAME_SCAN=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /usr/bin/python3.11 -I -B -S "$(/usr/bin/dirname -- "$0")/run_live_checks.py" "$@"
