"""Offline controls. Application modules must be supplied by an admitted caller."""

import io
import os
from pathlib import PurePosixPath
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import live_device
from live_guard import LiveGuard
from live_cases import run_live
from live_transport import Limits, LiveViolation, Session, make_connection


class Clock:
    def __init__(self):
        self.value = 0.0

    def __call__(self):
        return self.value


class BytesSource:
    def __init__(self, payload, clock, chunk=3, step=.001):
        self.payload, self.clock, self.chunk, self.step = payload, clock, chunk, step
        self.closed = False

    def read(self, count):
        self.clock.value += self.step
        data = self.payload[:min(count, self.chunk)]
        self.payload = self.payload[len(data):]
        return data

    def close(self):
        self.closed = True


def run_tests(modules):
    mavutil, v20, v10 = (modules[name] for name in ('mavutil', 'v20', 'v10'))

    def frame(kind, dialect=v20, **changes):
        defaults = {
            'attitude': dict(time_boot_ms=100, roll=.1, pitch=.2, yaw=.3,
                             rollspeed=0., pitchspeed=0., yawspeed=0.),
            'gps_raw_int': dict(time_usec=1000, fix_type=3, lat=421234567, lon=-712345678,
                                alt=12000, eph=100, epv=100, vel=0, cog=0, satellites_visible=10),
            'gps2_raw': dict(time_usec=1000, fix_type=3, lat=421234567, lon=-712345678,
                             alt=12000, eph=100, epv=100, vel=0, cog=0, satellites_visible=10,
                             dgps_numch=0, dgps_age=0),
            'global_position_int': dict(time_boot_ms=100, lat=421234567, lon=-712345678,
                                        alt=12000, relative_alt=0, vx=0, vy=0, vz=0, hdg=0),
        }
        values = dict(defaults[kind], **changes)
        if dialect is v20 and kind in ('gps_raw_int', 'gps2_raw'):
            values['yaw'] = 36000
        encoder = dialect.MAVLink(None, srcSystem=42, srcComponent=1)
        return bytes(getattr(dialect, 'MAVLink_' + kind + '_message')(**values).pack(encoder))

    def connection(payload=b'', limits=None, chunk=3, step=.001):
        clock = Clock()
        session = Session(limits or Limits(seconds=.2), clock)
        source = BytesSource(payload, clock, chunk, step)
        return make_connection(mavutil, source, session), source

    def bridge(conn):
        return run_live(modules['manager'], modules['subscriber'], modules['protobuf'],
                        modules['conversion'], modules['topics'], modules['cases'], conn)

    def terminal():
        t = live_device.termios
        return [0, 0, t.CS8 | t.CLOCAL | t.CREAD, 0, t.B115200, t.B115200, [0] * 32]

    class ReceiveTests(unittest.TestCase):
        def test_actual_manager_fragmented_pipeline(self):
            payload = b''.join(frame(kind) for kind in
                               ('attitude', 'gps_raw_int', 'gps2_raw', 'global_position_int', 'attitude'))
            conn, source = connection(payload)
            result = bridge(conn)
            self.assertEqual(result['status'], 'OBSERVED')
            self.assertEqual(result['callback_accepted'], 1)
            self.assertEqual(result['missing_message_types'], [])
            self.assertEqual(result['write_attempts'], 0)
            self.assertEqual(result['publications'][0]['fields']['gpsYaw'], 36000)
            self.assertTrue(source.closed)

        def test_mixed_wire_versions_use_installed_parser(self):
            conn, source = connection(frame('attitude') + frame('attitude', dialect=v10))
            result = bridge(conn)
            self.assertEqual(result['wire_versions'], {'2.0': 1, '1.0': 1})
            self.assertEqual(result['callback_accepted'], 1)
            self.assertTrue(source.closed)

        def test_sustained_garbage_deadline(self):
            conn, source = connection(b'x' * 10000, Limits(seconds=.01), chunk=512, step=.002)
            result = bridge(conn)
            self.assertEqual(result['stop_reason'], 'duration-limit')
            self.assertLess(result['input_bytes'], 10000)
            self.assertEqual(result['status'], 'INCONCLUSIVE')
            self.assertTrue(source.closed)

        def test_no_data_is_not_success(self):
            conn, source = connection()
            result = bridge(conn)
            self.assertEqual(result['status'], 'INCONCLUSIVE')
            self.assertEqual(result['decoded_messages'], 0)
            self.assertTrue(source.closed)

        def test_crc_bad_data_then_recovery(self):
            damaged = frame('attitude')
            damaged = damaged[:-1] + bytes([damaged[-1] ^ 1])
            conn, source = connection(damaged + frame('attitude') + frame('attitude'))
            result = bridge(conn)
            self.assertGreater(result['message_counts'].get('BAD_DATA', 0), 0)
            self.assertEqual(result['callback_accepted'], 1)
            self.assertTrue(source.closed)

        def test_write_denial_is_sticky(self):
            conn, source = connection()
            with self.assertRaises(LiveViolation):
                conn.write(b'forbidden')
            with self.assertRaises(LiveViolation):
                conn.recv_msg()
            result = bridge(conn)
            self.assertEqual(result['status'], 'FAIL')
            self.assertEqual(result['write_attempts'], 1)
            self.assertTrue(source.closed)

        def test_generated_send_is_denied(self):
            conn, source = connection()
            with self.assertRaises(LiveViolation):
                conn.mav.heartbeat_send(2, 3, 0, 0, 3)
            self.assertEqual(conn.session.write_attempts, 1)
            conn.close()

        def test_publication_cap_survives_bare_except(self):
            conn, source = connection(frame('attitude') * 4, Limits(seconds=.2, publications=1))
            result = bridge(conn)
            self.assertEqual(result['stop_reason'], 'publication-limit')
            self.assertEqual(len(result['publications']), 1)
            self.assertTrue(source.closed)

        def test_publication_failure_survives_bare_except(self):
            conn, source = connection(frame('attitude') * 2)
            def broken_conversion(message):
                raise ValueError('controlled conversion failure')
            result = run_live(modules['manager'], modules['subscriber'], modules['protobuf'],
                              broken_conversion, modules['topics'], modules['cases'], conn)
            self.assertEqual(result['status'], 'FAIL')
            self.assertIn('publication-ValueError', result['faults'])
            self.assertTrue(source.closed)

        def test_disconnect_is_terminal(self):
            conn, source = connection()
            def disconnected(count):
                raise OSError('controlled disconnect')
            source.read = disconnected
            result = bridge(conn)
            self.assertEqual(result['status'], 'FAIL')
            self.assertIn('receive-OSError', result['faults'])
            self.assertTrue(source.closed)

        def test_byte_bound(self):
            conn, source = connection(b'x' * 100, Limits(seconds=.2, input_bytes=7))
            result = bridge(conn)
            self.assertEqual(result['input_bytes'], 7)
            self.assertEqual(result['stop_reason'], 'input-byte-limit')

        def test_message_bound(self):
            conn, source = connection(frame('attitude') * 3, Limits(seconds=.2, messages=1))
            result = bridge(conn)
            self.assertEqual(result['decoded_messages'], 1)
            self.assertEqual(result['stop_reason'], 'message-limit')

    class DeviceTests(unittest.TestCase):
        def test_audit_stack_event_does_not_request_another_stack(self):
            guard = object.__new__(LiveGuard)
            guard.device_enabled = False
            guard.device_gate = None
            self.assertIsNone(guard.audit('sys._getframe', (None,)))

        def test_enabled_dispatch_is_only_an_open_classifier(self):
            calls = []
            def classify(args, caller):
                calls.append((args, caller.f_code))
                return True
            guard = object.__new__(LiveGuard)
            guard.device_enabled = True
            guard.device_gate = SimpleNamespace(permit_open=classify)
            arguments = ('controlled-only-no-open', None, os.O_RDONLY)
            self.assertIsNone(guard.audit('open', arguments))
            self.assertEqual(calls, [(arguments, self.test_enabled_dispatch_is_only_an_open_classifier.__func__.__code__)])
            self.assertIsNone(guard.audit('sys._getframe', (None,)))
            self.assertEqual(len(calls), 1)

        def test_mid_read_context_changes_prevent_read(self):
            reads = []
            closed = []
            identity = {'controlled': 1}
            current = dict(identity)
            attributes = terminal()
            gate = SimpleNamespace(collect_identity=lambda: current,
                _real_read=lambda fd, size: reads.append((fd, size)) or b'x',
                _real_close=closed.append)
            source = live_device._ReceiveSource(gate, 19, {'identity': identity})
            fake_termios = SimpleNamespace(**dict(vars(live_device.termios),
                tcgetattr=lambda fd: attributes))
            with patch.object(live_device, 'termios', fake_termios), patch.object(
                    live_device, 'select', SimpleNamespace(select=lambda *args: ([19], [], []))):
                self.assertEqual(source.read(1), b'x')
                current = {'controlled': 2}
                with self.assertRaises(live_device.NotAdmitted):
                    source.read(1)
                current = dict(identity)
                attributes[3] |= live_device.termios.ECHO
                with self.assertRaises(live_device.NotAdmitted):
                    source.read(1)
                self.assertEqual(reads, [(19, 1)])
                source.close()
            self.assertEqual(closed, [19])
            self.assertTrue(source.closed)

        def test_failed_close_is_not_reported_as_closed(self):
            attempts = []
            def failed_close(fd):
                attempts.append(fd)
                raise OSError('controlled close failure')
            source = live_device._ReceiveSource(SimpleNamespace(_real_close=failed_close), 19, {})
            with self.assertRaises(OSError):
                source.close()
            self.assertFalse(source.closed)
            self.assertEqual(attempts, [19])

        def test_operator_acknowledgements_required(self):
            gate = live_device.DeviceGate()
            with self.assertRaises(live_device.NotAdmitted):
                gate.open_receive_source(live_device.Acknowledgements())
            self.assertFalse(gate._used)

        def test_terminal_rejects_echo_flow_and_wrong_baud(self):
            for index, value in ((0, live_device.termios.IXON), (0, live_device.termios.IXOFF),
                                 (3, live_device.termios.ECHO), (3, live_device.termios.ICANON),
                                 (4, live_device.termios.B9600)):
                attributes = terminal()
                attributes[index] = value
                with self.assertRaises(live_device.NotAdmitted):
                    live_device.check_terminal(attributes)

        def test_terminal_accepts_without_mutation(self):
            attributes = terminal()
            before = repr(attributes)
            result = live_device.check_terminal(attributes)
            self.assertEqual(repr(attributes), before)
            self.assertFalse(result['configuration_changed'])

        def test_unrelated_open_not_permitted(self):
            gate = live_device.DeviceGate()
            self.assertFalse(gate.permit_open(('/dev/ttyACM0', None, os.O_RDONLY), None))
            with self.assertRaises(live_device.NotAdmitted):
                gate._open('/dev/ttyACM0', os.O_RDONLY)

        def test_fake_device_lifecycle_and_identity_failures(self):
            usb = PurePosixPath('/sys/devices/test/usb1/1-1')
            interface = usb / '1-1:1.0'
            tty = interface / 'tty/ttyACM0'
            values = {str(interface / 'bInterfaceNumber'): b'00\n',
                      str(usb / 'serial'): (live_device.SERIAL + '\n').encode(),
                      str(usb / 'idVendor'): b'2dae\n', str(usb / 'idProduct'): b'1016\n',
                      str(tty / 'dev'): b'166:0\n'}

            class FakePath(PurePosixPath):
                def resolve(self, strict=False):
                    if str(self) == live_device.TTY_SYSFS:
                        return FakePath(tty)
                    if str(self) == live_device.TTY_SYSFS + '/device':
                        return FakePath(interface)
                    raise AssertionError('unexpected resolution')

            for failure in (None, 'serial', 'interface', 'node-swap', 'exclusive', 'echo'):
                opened, closed, ioctls, reads = [], [], [], []
                node = SimpleNamespace(st_dev=1, st_ino=2, st_rdev=os.makedev(166, 0),
                                       st_mode=stat.S_IFCHR | 0o660, st_ctime_ns=3)
                rows = dict(values)
                if failure == 'serial':
                    rows[str(usb / 'serial')] = b'other\n'
                if failure == 'interface':
                    rows[str(interface / 'bInterfaceNumber')] = b'02\n'
                def fake_lstat(path):
                    if str(path) == live_device.DEVICE:
                        return node
                    if str(path) in rows:
                        return SimpleNamespace(st_mode=stat.S_IFREG | 0o444)
                    raise FileNotFoundError(str(path))
                def fake_open(path, flags):
                    caller = sys._getframe(1)
                    self.assertTrue(gate.permit_open((path, None, flags), caller))
                    self.assertFalse(gate.permit_open((path + '.other', None, flags), caller))
                    self.assertFalse(gate.permit_open((path, None, flags | os.O_RDWR), caller))
                    cloned = SimpleNamespace(f_code=caller.f_code.replace(), f_globals=caller.f_globals,
                                             f_locals=caller.f_locals)
                    self.assertFalse(gate.permit_open((path, None, flags), cloned))
                    copied = SimpleNamespace(f_code=caller.f_code, f_globals=dict(caller.f_globals),
                                             f_locals=caller.f_locals)
                    self.assertFalse(gate.permit_open((path, None, flags), copied))
                    opened.append((str(path), flags))
                    return len(opened) + 10
                def fake_read(descriptor, count):
                    path = opened[descriptor - 11][0]
                    reads.append(path)
                    return rows[path]
                def fake_fstat(descriptor):
                    return node if failure != 'node-swap' else SimpleNamespace(
                        **dict(vars(node), st_ino=999))
                def fake_ioctl(descriptor, request):
                    ioctls.append(request)
                    if failure == 'exclusive':
                        raise OSError('controlled busy')
                fake_os = SimpleNamespace(**dict(vars(os), open=fake_open, read=fake_read,
                    close=closed.append, lstat=fake_lstat, fstat=fake_fstat))
                attributes = terminal()
                if failure == 'echo':
                    attributes[3] |= live_device.termios.ECHO
                fake_termios = SimpleNamespace(**dict(vars(live_device.termios),
                                                     tcgetattr=lambda descriptor: attributes))
                with patch.object(live_device, 'os', fake_os), patch.object(live_device, 'Path', FakePath), \
                     patch.object(live_device, 'fcntl', SimpleNamespace(ioctl=fake_ioctl)), \
                     patch.object(live_device, 'termios', fake_termios):
                    gate = live_device.DeviceGate()
                    if failure is None:
                        source = gate.open_receive_source(live_device.Acknowledgements(True, True))
                        self.assertTrue(source.evidence['opened_read_only'])
                        source.close()
                        with self.assertRaises(live_device.NotAdmitted):
                            gate.open_receive_source(live_device.Acknowledgements(True, True))
                    else:
                        with self.assertRaises((live_device.NotAdmitted, OSError)):
                            gate.open_receive_source(live_device.Acknowledgements(True, True))
                tty_opens = [row for row in opened if row[0] == live_device.DEVICE]
                self.assertEqual(len(tty_opens), 0 if failure in ('serial', 'interface') else 1)
                self.assertTrue(all(flags & os.O_ACCMODE == os.O_RDONLY for _, flags in opened))
                self.assertNotIn(live_device.DEVICE, reads)
                self.assertEqual(len(closed), len(opened))
                self.assertTrue(all(request == live_device.termios.TIOCEXCL for request in ioctls))

    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(case)
                               for case in (ReceiveTests, DeviceTests))
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    return dict(status='PASS' if result.wasSuccessful() else 'FAIL', tests=result.testsRun,
                failures=len(result.failures), errors=len(result.errors), output=stream.getvalue())
