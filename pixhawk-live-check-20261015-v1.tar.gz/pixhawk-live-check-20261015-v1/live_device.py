"""Exact Cube interface admission. No serial configuration or payload writes."""

from dataclasses import dataclass
import fcntl
import os
from pathlib import Path
import select
import stat
import sys
import termios


DEVICE = '/dev/ttyACM0'
TTY_SYSFS = '/sys/class/tty/ttyACM0'
SERIAL = '3E003A001251333232393436'
INTERFACE = '00'
BAUD = 115200


class NotAdmitted(RuntimeError):
    pass


def require(condition, reason):
    if not condition:
        raise NotAdmitted(reason)


@dataclass(frozen=True)
class Acknowledgements:
    exclusive_cube_confirmed: bool = False
    open_close_effects_accepted: bool = False


def check_terminal(attributes):
    require(type(attributes) is list and len(attributes) == 7, 'unrecognized terminal attributes')
    iflag, oflag, cflag, lflag, ispeed, ospeed, controls = attributes
    forbidden_input = sum(getattr(termios, name, 0) for name in
                          ('IXON', 'IXOFF', 'IXANY', 'ISTRIP', 'INLCR', 'IGNCR', 'ICRNL',
                           'PARMRK', 'BRKINT', 'INPCK'))
    forbidden_local = sum(getattr(termios, name, 0) for name in
                          ('ICANON', 'ISIG', 'IEXTEN', 'ECHO', 'ECHOE', 'ECHOK', 'ECHONL',
                           'ECHOCTL', 'ECHOPRT', 'ECHOKE'))
    require(not iflag & forbidden_input and not lflag & forbidden_local,
            'terminal is not already raw/no-echo/no-software-flow; no configuration attempted')
    require(not oflag & termios.OPOST, 'terminal output processing enabled')
    require(not cflag & (getattr(termios, 'CRTSCTS', 0) | termios.PARENB | termios.CSTOPB),
            'terminal hardware flow/parity/stop configuration differs')
    require(cflag & termios.CSIZE == termios.CS8 and cflag & termios.CREAD
            and cflag & termios.CLOCAL, 'terminal must already use local 8-bit receive mode')
    require(ispeed == termios.B115200 and ospeed == termios.B115200,
            'terminal is not already configured at 115200 baud')
    return dict(baud=BAUD, raw_no_echo_no_flow=True, configuration_changed=False,
                hangup_on_close=bool(cflag & termios.HUPCL))


class DeviceGate:
    """Construct before guard activation; attach permit_open to the live guard only."""
    def __init__(self):
        self._real_open, self._real_read, self._real_close = os.open, os.read, os.close
        self._real_ioctl = fcntl.ioctl
        self._opening = None
        self._allowed_reads = set()
        self._used = False
        self.receipts = []

    def permit_open(self, args, caller):
        return bool(self._opening is not None and caller is not None
                    and caller.f_code is DeviceGate._open.__code__
                    and caller.f_globals is globals() and caller.f_locals.get('self') is self
                    and args[0] == self._opening[0] and args[1] is None
                    and args[2] == self._opening[1])

    def _open(self, path, flags):
        caller = sys._getframe(1)
        is_identity = (caller.f_code is DeviceGate._read_ascii.__code__
                       and caller.f_globals is globals() and caller.f_locals.get('self') is self
                       and path in self._allowed_reads
                       and flags == os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
        is_device = (caller.f_code is DeviceGate.open_receive_source.__code__
                     and caller.f_globals is globals() and caller.f_locals.get('self') is self
                     and path == DEVICE and flags == os.O_RDONLY | os.O_NOCTTY | os.O_NONBLOCK
                     | os.O_CLOEXEC | os.O_NOFOLLOW and self._used)
        require(is_identity or is_device, 'unadmitted gate open')
        require(self._opening is None, 'nested gate open')
        self._opening = path, flags
        try:
            return self._real_open(path, flags)
        finally:
            self._opening = None

    def _read_ascii(self, path):
        path = str(path)
        require(path in self._allowed_reads and stat.S_ISREG(os.lstat(path).st_mode),
                'nonregular or unbound USB identity field')
        descriptor = self._open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
        try:
            data = self._real_read(descriptor, 257)
            require(len(data) <= 256, 'USB identity field exceeds bound')
            return data.decode('ascii').strip()
        finally:
            self._real_close(descriptor)

    def collect_identity(self):
        node = os.lstat(DEVICE)
        require(stat.S_ISCHR(node.st_mode), 'exact device is not an ordinary character node')
        tty = Path(TTY_SYSFS).resolve(strict=True)
        ancestry = (Path(TTY_SYSFS) / 'device').resolve(strict=True)
        require(str(tty).startswith('/sys/devices/') and str(ancestry).startswith('/sys/devices/'),
                'unexpected tty sysfs ancestry')
        interface = None
        for item in (ancestry, *tuple(ancestry.parents)[:8]):
            if not str(item).startswith('/sys/devices/'):
                break
            try:
                info = os.lstat(item / 'bInterfaceNumber')
            except FileNotFoundError:
                continue
            require(stat.S_ISREG(info.st_mode), 'nonregular USB interface field')
            require(interface is None, 'ambiguous USB interface ancestry')
            interface = item
        require(interface is not None and (tty == interface or interface in tty.parents),
                'tty is not beneath one USB interface')
        usb = interface.parent
        paths = {interface / 'bInterfaceNumber', usb / 'serial', usb / 'idVendor',
                 usb / 'idProduct', tty / 'dev'}
        self._allowed_reads = {str(path) for path in paths}
        try:
            number = self._read_ascii(interface / 'bInterfaceNumber')
            serial = self._read_ascii(usb / 'serial')
            vendor = self._read_ascii(usb / 'idVendor')
            product = self._read_ascii(usb / 'idProduct')
            dev = self._read_ascii(tty / 'dev')
        finally:
            self._allowed_reads.clear()
        require(number == INTERFACE and serial == SERIAL, 'Cube serial/interface identity mismatch')
        require(len(vendor) == len(product) == 4
                and all(char in '0123456789abcdefABCDEF' for char in vendor + product),
                'invalid observed USB identifiers')
        require(dev == str(os.major(node.st_rdev)) + ':' + str(os.minor(node.st_rdev)),
                'tty sysfs/device number mismatch')
        return dict(device=DEVICE, serial=serial, interface=number,
                    vendor_id_observed=vendor, product_id_observed=product,
                    tty_sysfs=str(tty), interface_sysfs=str(interface), usb_sysfs=str(usb),
                    device_number=dev, node_identity=[node.st_dev, node.st_ino, node.st_rdev,
                                                    node.st_mode, node.st_ctime_ns])

    def open_receive_source(self, acknowledgements):
        require(type(acknowledgements) is Acknowledgements
                and acknowledgements.exclusive_cube_confirmed is True
                and acknowledgements.open_close_effects_accepted is True,
                'operator exclusive-use and open/close-effect acknowledgements required')
        require(not self._used, 'one device-open attempt only; no retry or reconnect')
        identity = self.collect_identity()
        self._used = True
        descriptor = self._open(DEVICE, os.O_RDONLY | os.O_NOCTTY | os.O_NONBLOCK
                                | os.O_CLOEXEC | os.O_NOFOLLOW)
        try:
            info = os.fstat(descriptor)
            require(stat.S_ISCHR(info.st_mode)
                    and [info.st_dev, info.st_ino, info.st_rdev, info.st_mode, info.st_ctime_ns]
                    == identity['node_identity'], 'opened device identity changed')
            self._real_ioctl(descriptor, termios.TIOCEXCL)
            terminal = check_terminal(termios.tcgetattr(descriptor))
            require(self.collect_identity() == identity, 'device identity changed during admission')
            receipt = dict(identity=identity, terminal=terminal, opened_read_only=True,
                           exclusive_open_control='TIOCEXCL; operator established no prior reader',
                           no_prior_reader='operator acknowledgement, not kernel-proven',
                           open_close_effects_accepted=True)
            self.receipts.append(receipt)
            return _ReceiveSource(self, descriptor, receipt)
        except BaseException:
            self._real_close(descriptor)
            raise


class _ReceiveSource:
    def __init__(self, gate, descriptor, evidence):
        self._gate, self._descriptor = gate, descriptor
        self.evidence = evidence
        self.closed = False

    def read(self, count):
        require(not self.closed and type(count) is int and 1 <= count <= 512,
                'invalid receive access')
        require(self._gate.collect_identity() == self.evidence['identity'], 'device identity changed')
        check_terminal(termios.tcgetattr(self._descriptor))
        ready, _, _ = select.select([self._descriptor], [], [], 0)
        if not ready:
            return b''
        try:
            data = self._gate._real_read(self._descriptor, count)
        except BlockingIOError:
            return b''
        require(data != b'', 'device disconnected')
        return data

    def close(self):
        if not self.closed:
            self._gate._real_close(self._descriptor)
            self.closed = True
