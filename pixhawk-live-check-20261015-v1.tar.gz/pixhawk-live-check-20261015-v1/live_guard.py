"""One source-bound exact-device exception to the unchanged import/effect guard."""

import sys

from behavior_guard import BehaviorGuard


class LiveGuard(BehaviorGuard):
    def __init__(self, *args, device_gate=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.device_gate = device_gate
        self.device_enabled = False

    def audit(self, event, args):
        caller = sys._getframe(1) if event in ('exec', 'ctypes.dlopen', 'open') else None
        if (event == 'open' and self.device_enabled and self.device_gate is not None
                and self.device_gate.permit_open(args, caller)):
            return
        return super().audit(event, args, _caller=caller)

    def absent_import_cache(self, path, frame):
        if (frame is not None and frame.f_code is BehaviorGuard.audit.__code__
                and frame.f_globals is BehaviorGuard.audit.__globals__
                and frame.f_locals.get('self') is self):
            frame = frame.f_back
        if (frame is not None and frame.f_code is LiveGuard.audit.__code__
                and frame.f_globals is globals() and frame.f_locals.get('self') is self):
            frame = frame.f_back
        from pi_guard import CheckGuard
        return CheckGuard.absent_import_cache(self, path, frame)
