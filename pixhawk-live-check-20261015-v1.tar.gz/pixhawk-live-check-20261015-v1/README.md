# Bounded Cube receive support

Prepared for a separately authorized, operator-run receive-only attempt. Local
protected tests exercised the installed host handler and fake device primitives;
they do not establish target admission or authorize Codex hardware execution.

The final reviewed package uses the existing
`/home/admin/satgs-pi-test/satgs-app-manager` environment. It does not install or
repair dependencies, run a manager constructor, start a service or contact a
broker. The accepted offline result is preserved and not rerun as a new Pi
qualification exercise. Device-free controls within this new attempt verify the
new package's guarded setup before its separately acknowledged receive phase.

## Operator command after package admission

From the final extracted support directory:

```sh
./run_live_checks.sh --accept-trusted-native --exclusive-cube-confirmed --accept-open-close-effects
```

The command requires the existing test root, admitted application and exact Cube
serial `3E003A001251333232393436`, interface `00`, `/dev/ttyACM0`, already using
115200 baud and raw/no-echo/no-flow terminal settings. No port, identity, baud or
configuration override is accepted. Missing or different inputs fail closed.
Cole reported `ID_VENDOR=CubePilot`. Numeric vendor/product identifiers are
observed from the matched sysfs parent, not guessed from that descriptive name.

Before acknowledging exclusive use, the operator must have stopped other readers
of this interface and reserved it for this attempt. The program does not inspect
all processes, stop a service or take over an existing reader. `TIOCEXCL` restricts
later nonprivileged opens, not previously opened descriptors or privileged actors.

Read [DEVICE-CONTRACT.md](DEVICE-CONTRACT.md) before accepting opening effects.
Only `O_RDONLY` payload access is opened. There are no termios setters, serial
writes, stream requests, heartbeat sends, explicit DTR/RTS operations, input
flushes or reconnects. TTY open/close and USB control traffic can still have
effects. An absolute physical no-transmission claim is not made.

## Automated sequence and retained evidence

The environment is cleared and `/usr/bin/python3.11 -I -B -S` launches one fresh
`pixhawk-live-run-*` directory. Package identity and the unchanged installed
software binding are checked. Device-free admission then runs the 16 accepted
handler cases and 21 controlled live-support tests under the native/import/effect
guard. Only a successful bound admission permits the live child to enable the
exact-device gate.

Live reception is bounded to 60 seconds, 4 MiB input, 4096 decoded messages and
256 publications. The outer live-child deadline is 90 seconds to allow guarded
startup and cleanup. Detailed samples and warnings are bounded. Data follow the
installed mavutil parser, actual manager loop, dataclass/protobuf conversion and
strict callback. Publication stays in memory. Manager ID 17 is a fixture identity.

The program closes the source and records the stop reason, parsed source IDs,
source/arrival timestamps, wire and decoder versions, actual application fields,
callback results, missing types, denial counts and cleanup. Missing telemetry or
callback acceptance does not cause transmission; the attempt is inconclusive or
failed. A successful collection is not navigation, fix, heading, freshness or
sensor approval. No station location is selected or changed.

Success and allocated failure paths reuse the accepted recorder to retain
`report.txt`, `summary.json`, `completion.json`, phase records and a verified
`evidence.tar.gz` with checksums. Preserve the entire attempt. Attach the report,
verified evidence archive and actual outer launcher exit status. Exit zero means
the recorded collection, cleanup and packaging passed, not operational readiness.
SIGKILL, power loss or failed writes can prevent complete recording.

## Source provenance and offline review

The source base is the accepted
`pi-pixhawk-behavior-20261015-r01XHug5/support` package. `recording.py`, `pi_target.py`,
`pi_guard.py`, `ctypes_initialization.py`, `pixhawk_cases.py`, `expected-target.json`
and bundled reference inputs are unchanged copies. The target and launcher are
adapted for the new phases/inventory. The copied behavior guard accepts the exact
caller frame forwarded by the narrow live guard; its existing restrictions and
negative controls remain in force. The old export provenance describes the
unchanged reference/source base, not the identity of this new package.

The separate `tests/run_host.py` reuses the accepted host supervisor and existing
host environment. It supplies controlled byte/device primitives under a guard
with no live device capability. Host checks do not qualify the Pi or authorize
hardware execution. The final `SHA256SUMS` belongs to this new support inventory.

The first host attempt failed before application import because the new audit
wrapper recursively observed its own stack event. The correction restricts stack
inspection to the three inherited events that need a caller. The separately
recorded corrected host run passed all 16 handler cases, 21 support controls and
44 intended protection probes, with no runtime denials and clean child cleanup.
Those are CPython 3.11.16/x86-64 observations, not a new Pi result.
