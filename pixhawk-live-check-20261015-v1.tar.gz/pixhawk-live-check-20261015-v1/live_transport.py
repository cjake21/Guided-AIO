"""Bounded installed-mavutil receive adapter with no transmitting transport."""

from collections import Counter
from dataclasses import dataclass
import hashlib
import math
import time


class LiveStop(BaseException):
    pass


class LiveViolation(LiveStop):
    pass


@dataclass(frozen=True)
class Limits:
    seconds: float = 60.0
    input_bytes: int = 4 * 1024 * 1024
    messages: int = 4096
    publications: int = 256
    samples: int = 128
    logs: int = 32

    def __post_init__(self):
        if type(self.seconds) not in (int, float) or not math.isfinite(self.seconds) or not 0 < self.seconds <= 60:
            raise ValueError('invalid receive duration')
        for name, maximum in (('input_bytes', 4194304), ('messages', 4096),
                              ('publications', 256), ('samples', 128), ('logs', 32)):
            value = getattr(self, name)
            if type(value) is not int or not 1 <= value <= maximum:
                raise ValueError('invalid collection bound: ' + name)


def safe_value(value):
    if isinstance(value, float) and not math.isfinite(value):
        return {'nonfinite': 'nan' if math.isnan(value) else ('+inf' if value > 0 else '-inf')}
    if isinstance(value, bytes):
        return {'length': len(value), 'prefix_hex': value[:32].hex()}
    if isinstance(value, str):
        return value[:160]
    if isinstance(value, (list, tuple)):
        return [safe_value(item) for item in value[:32]]
    if value is None or type(value) in (int, float, bool):
        return value
    return type(value).__name__


class Session:
    def __init__(self, limits=Limits(), clock=time.monotonic):
        self.limits, self.clock = limits, clock
        self.started = clock()
        self.deadline = self.started + limits.seconds
        self.input_bytes = self.messages = self.publications = self.write_attempts = 0
        self.faults = []
        self.stop_reason = None
        self.message_types = Counter()
        self.wire_versions = Counter()
        self.sources = Counter()
        self.samples = []
        self.log_records = []

    def fail(self, reason):
        if len(self.faults) < 16:
            self.faults.append(reason)
        self.stop_reason = 'violation'
        raise LiveViolation(reason)

    def check(self):
        if self.faults:
            raise LiveViolation(self.faults[0])
        if self.stop_reason:
            raise LiveStop(self.stop_reason)
        if self.clock() >= self.deadline:
            self.stop('duration-limit')

    def stop(self, reason):
        self.stop_reason = reason
        raise LiveStop(reason)

    def record_message(self, message, decoder):
        self.messages += 1
        kind = message.get_type()
        self.message_types[kind] += 1
        source = (message.get_srcSystem(), message.get_srcComponent())
        self.sources[source] += 1
        raw = bytes(message.get_msgbuf())
        wire = {0xfe: '1.0', 0xfd: '2.0'}.get(raw[0], 'unrecognized') if raw else 'empty'
        self.wire_versions[wire] += 1
        if len(self.samples) < self.limits.samples:
            fields = message.get_fieldnames()
            self.samples.append(dict(
                index=self.messages, arrival_monotonic=self.clock(), message_type=kind,
                source_system=source[0], source_component=source[1], sequence=message.get_seq(),
                wire_protocol=wire, decoder_protocol=decoder,
                wire_length=len(raw), wire_sha256=hashlib.sha256(raw).hexdigest(),
                source_timestamps={name: safe_value(getattr(message, name))
                                   for name in ('time_boot_ms', 'time_usec') if hasattr(message, name)},
                decoded_fields={name: safe_value(getattr(message, name)) for name in fields[:32]}))


def make_connection(mavutil, source, session):
    """The supplied source owns one admitted descriptor, or controlled test bytes."""
    class ReceiveConnection(mavutil.mavfile):
        def __init__(self):
            self._source, self.session = source, session
            self.closed = False
            super().__init__(None, 'bound-receive-source', input=False)

        def recv(self, n=None):
            session.check()
            if session.input_bytes >= session.limits.input_bytes:
                session.stop('input-byte-limit')
            if type(n) is not int or not 1 <= n <= 4096:
                session.fail('invalid-parser-read-size')
            count = min(n, 512, session.limits.input_bytes - session.input_bytes)
            try:
                data = source.read(count)
            except Exception as error:
                session.fail('receive-' + type(error).__name__)
            if type(data) is not bytes or len(data) > count:
                session.fail('receive-source-contract')
            session.input_bytes += len(data)
            session.check()
            return data

        def recv_msg(self):
            session.check()
            if session.messages >= session.limits.messages:
                session.stop('message-limit')
            if self.logfile is not None or self.logfile_raw is not None or self.message_hooks or self.idle_hooks:
                session.fail('unadmitted-parser-hook')
            try:
                message = super().recv_msg()
            except Exception as error:
                session.fail('parser-' + type(error).__name__)
            if message is not None:
                session.record_message(message, self.WIRE_PROTOCOL_VERSION)
            return message

        def write(self, payload):
            session.write_attempts += 1
            session.fail('transmit-attempt')

        def close(self):
            if not self.closed:
                source.close()
                self.closed = True

    return ReceiveConnection()
