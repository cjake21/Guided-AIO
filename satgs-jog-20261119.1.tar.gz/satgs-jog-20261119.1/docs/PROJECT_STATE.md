# SATGS development state

Updated November 19, 2026. Primary workflow: `msel-project-engineer`, registered at
`/home/cjacobson/.agents/skills/msel-skill/msel-project-engineer/SKILL.md`.
Project routing is in the repository's `AGENTS.md`.

## Current source, application and delivery

Continue `/workspace/development/SATGS-Modular-Suite`, branch
`feature/operator-handbook-ptu`, base `c1c335b44d8a59641deef878304b4a975eab443e`.
All inherited work and accepted installations remain intact. Current candidate
`jog-20261119.1` pairs satgs, ptu_control and serialptu at
`0.0.1+jog.20261119.1`, selection alias `jog4`. It includes the existing installer,
bootstrap and task-playbook work plus the bounded local Connect correction.
There is no workspace/database migration.

Cole has selected jog3 on the Pi, application
`/home/admin/satgs-jog-20261118-v3-app-manager`, station
`/home/admin/satgs/station`. Save local QPT130 succeeds. Actual supplied Connect
records show full nine-byte writes and zero reply bytes in one second, including
attempt `74d4b451112f42f5baf6f378d37ff543`. The two policy_mismatch records have
no exchanges and are separate failures. Do not bypass their context check.

The published release remains `jog-20261118.3`, artifact commit
`4542c0d27820e5a13a8a8bfdb64c51026c7657cc`. Jog4 is built, reviewed and installed-tested locally;
publication, Pi installation, exact Pi font rendering and physical Connect/jog/
numeric/Stop tests are not implied by host checks. No device, broker, Pi,
operational service, daily selection or Git ref was changed here.

See [the Connect update](CONNECT_UPDATE_20261119.md) for the actual exchange,
correction, review, validation and next operator actions. Earlier sections below
retain the development history and are superseded by this current entry where
they describe jog3 as uninstalled or records as unavailable.

## Implemented continuation

- Shared `Workspace.install_software` uses the saved catalog selection and an
  explicit offline wheel directory to install into a new environment. Setup's
  **Install software** button and CLI `install-software` call that operation.
- Installation resolves dependencies, checks them with pip, verifies selected
  distribution metadata, and retains separate started/result receipts and an
  environment log. Report/export includes the receipts and labels whether their
  configuration revision is current. It never changes station configuration,
  selects an application, starts services or imports equipment modules.
- Missing Full M-SEL owners, reuse in a new environment, occupied destinations,
  stale/busy stations and URL dependencies have explicit outcomes. Failed
  candidates remain available for diagnosis. `software_complete` is distinct
  from `profile_complete`; native, system, hardware and service requirements remain
  unresolved. Existing successful candidates and receipts remain intact.
- Fresh-account launcher preparation supports explicit `--bootstrap jog3` after
  acceptance without an older runtime or existing station. Repeated bootstrap
  preserves an existing selection. Normal GUI launch with no default station
  opens Home for explicit station creation. Optional `--initialize-station NEW_PATH`
  calls the installed product initializer and records that chosen station as the
  daily workspace; existing selections and occupied station paths are refused.
  Existing-account upgrades retain their
  selection and preserve the prior jog3 dispatcher.
- Client/manager requirement pins now match the existing jog3 constraints.
  Changed ground-station source/tests/docs were mirrored under the existing
  release-support reference directory.

## Validation actually run

Host software evidence only. No broker, hardware, new network dependency or Pi
qualification was used. Test wheels in behavioral tests are fixtures; the separate
installed smoke uses real owner/dependency wheels.

The affected product checks passed, 61 tests:

```sh
/workspace/development/satgs-maintenance/jog3-release-20261118-rLIZxN1o/host-setup-1/application/bin/python -I -B -c 'import sys,unittest; sys.path[:0]=["components/ground_station/src","components/ground_station/tests"]; unittest.main(module=None, argv=["unittest","test_operator_install","test_operator_core","test_operator_cli","test_operator_presentation","test_operator_gui.HeadlessOperatorPresenterTests"], verbosity=1)'
```

The affected launcher/support checks passed, 92 tests:

```sh
python3 -I -B -S -c 'import sys,unittest; sys.path.insert(0,"tests"); unittest.main(module=None, argv=["unittest","test_daily_launchers","test_launcher_checks","test_source_workflow"], verbosity=1)'
```

The source check, shell syntax check and `git diff --check` passed. Earlier attempts
exposed stale dispatcher-path assertions, one introduced test indentation error,
and a source-workflow invocation missing required `-S`. Those were corrected;
the tests were rerun with the results above. A focused second reader reviewed the
supplied installer logic, without filesystem/test access. Its three failure-path
findings were fixed. This is not an independent whole-repository acceptance.
The final guide-content check also passed, six tests:

```sh
/workspace/development/satgs-maintenance/jog3-release-20261118-rLIZxN1o/host-setup-1/application/bin/python -I -B -c 'import sys,unittest; sys.path[:0]=["components/ground_station/src","components/ground_station/tests"]; unittest.main(module=None, argv=["unittest","test_operator_guide_content"], verbosity=1)'
python3 -I -B -S tools/check_source.py
bash -n setup_update.sh launchers/setup_daily.sh
git diff --check
```

Real offline installation evidence:
`/tmp/satgs-profile-install-20261118-d3kbd5s1/summary.json`, with build log,
install result, installed CLI stdout/stderr and Full missing-input result beside
it. The changed operator wheel was built offline using the existing pinned build
interpreter. A new environment installed the Guided Arrow selection with the
retained 31-distribution host closure. Installed CLI status/help/docs passed;
installed Full M-SEL installation correctly rejected missing owners before
creating another candidate. Station bytes were preserved during installation.
The smoke uses CPython 3.11 on x86-64. New GUI rendering, ARM64/Pi behavior and
physical operation were not tested. Temporary evidence is not a release.

The final rebuild and fresh environment are recorded as `final_*` results in
that summary, with `final-build.log`, `final-install-result.json`, installed
status/help/docs/report output and `final-full-missing-inputs.json`. Real
fresh-account bootstrap also passed using the installed product initializer,
no old runtime and the generated daily CLI wrapper. It reopened the selected
station; repeated plain bootstrap preserved the selection. Its result is in
`fresh-bootstrap-status.json`. New install receipts use
`satgs-software-install.v1`; Report checks their station/attempt identities and
exports only the supported result fields.

## Next actions and product scope

1. Review/build the next separately identified update from this preserved source.
   Validate the new Setup layout and the fresh-account bootstrap on the target;
   do not ship the smoke wheel under the published jog3 identity.
2. Supply Full M-SEL's absent `satgs-post-processing`, `cyberpowerpdu`, `dsi`,
   `signal_hound_control`, `bbdevice` and transitive/platform wheels. Establish
   compatible native/vendor inputs, especially Signal Hound on ARM64. Actual Full
   software installation and the complete fresh-account demonstration remain open.
3. Cole performs the existing published jog3 acceptance/select procedure and
   supervised PTU readback, arrows/keys, numeric target, release/Stop, CLI and saved
   session observations. No repeated baud discovery or historical bring-up.

Keep one modular Full M-SEL/Guided Arrow/Custom product with shared GUI/CLI owners.
The December 1, 2026 demonstration still requires fresh internal Bitbucket
installation, actual Full M-SEL software/configuration and physical PTU results.
The long-term telemetry, location, planning/tracking, services, RF/processing,
results and maintenance goal remains intact. Profile Save is not installation;
this software-install slice is not a claim that the complete demo has passed.

## Comprehensive handbook update

Cole requested install-to-operation examples for TLE-only, PTU-only and Full
M-SEL instances. The existing 13-chapter handbook now contains a task chooser,
the ten-owner distribution map, complete TLE/PTU Custom JSON changes files,
GUI and CLI install/configuration steps, a TLE catalog procedure, a Full walk-
through, every native tab's fields/actions, and output/receipt locations. Nearby
legacy comparison, component references and release-availability text were
reconciled. Application code was not changed for this documentation task.

The text distinguishes existing legacy TLE commands, published jog3 and the
unpublished installer/bootstrap work. It does not claim per-package GUI download,
native TLE editing, force-refresh-all or complete Full package/service delivery.
The active checkout has no SATGS Read the Docs hosting configuration; the update
uses the existing Markdown/offline HTML/text handbook path. Nothing was uploaded
or published to a documentation service or Bitbucket.

Preview: `/tmp/satgs-handbook-preview-20261118-yimr0ty0/guide/user-guide.html`.
The adjacent preview ZIP contains HTML/text/assets, Markdown sources and a
README identifying the development scope. Guide checks: six passed; all 47
shell blocks passed `bash -n`. Existing tests caught that the first tutorial CSV
must match the packaged historical fixture; the new example was aligned with
that real four-column fixture, preserving the assertion.

Scenario evidence: `/tmp/satgs-handbook-examples-20261118-pfv8x4rp/summary.json`.
Using explicitly supplied retained host wheels, actual TLE-only and PTU-only
installs passed and omitted the unwanted owners. Installed TLE console help,
native TLE-only planning and passive local PTU configuration passed. Mocked HTTP
at the request boundary exercised actual add/duplicate/delete, stale-versus-fresh
refresh and all-catalog pass-finder/run-sheet behavior. Manual TLE content passed
strict native parsing and historical planning without a fetch. The driver is
`/tmp/satgs_handbook_examples_check.py`; it creates disposable directories and
uses no live network or hardware. Host x86-64 evidence is not Pi/ARM64 evidence.

Three legacy code defects were reproduced and documented, not fixed in this
docs-only task: deleting the final row leaves only a `norad_id` header; a null
date reaches an incompatible string datetime path; replacing a refreshed row
drops `txids`. Keep complete headers, valid UTC dates and catalog/association
backups as described in the guide. Track focused owner fixes after the immediate
PTU/release work. Cole's planned November 19 jog3 target check remains unchanged.

## Component playbooks and separate suite gap inventory

Cole expanded the documentation request to cover the original ground_station,
serialptu, sat_tracker, Pixhawk and meteor-api Messenger owners, with use cases
as the entry point. The handbook chooser now links each task to package selection,
installation/configuration, actions and expected outputs. The core owner sections
and original-to-current task mapping were rewritten around those procedures.

TLE fetch/store, manual entry/replacement, deletion, age-based whole-catalog
refresh and native local planning remain concrete worked paths. Native GUI/CLI
PTU control uses the four-owner Custom selection and existing shared session.
Full M-SEL retains the complete ten-owner setup and every-tab walkthrough.
Advanced references add standalone serialptu installation with an executable
packet inspection example, tracking-request preparation and lifecycle ownership,
Pixhawk role installation/sensor fields/telemetry/CLI option reference, and the
existing Messenger package/settings/bounded API sequence. Messenger already
exists at `components/meteor-api/src/meteor_api/messenger.py`; no duplicate was
created.

Development inventories were moved out of the packaged operator chapters into
[SUITE_GAPS.md](SUITE_GAPS.md). It records missing Full artifacts/platform inputs,
download/service provisioning, TLE owner defects, live tracking/GPS integration,
component documentation and actual target acceptance work. Ordinary prerequisites,
returned-state interpretation and operational error handling remain in the guide.
The guide still states its version and the endpoint of each supported procedure.
The local gap file is excluded from the compiled guide and preview ZIP.

No application code, Git refs, installed selection, services, devices or Pi
state changed during this documentation update. No publication was performed.
All 13 existing handbook Markdown mirrors were synchronized.

Validation of the final text:

- Six existing handbook tests passed, including complete component coverage,
  command/widget spelling, deterministic compilation, links and historical TLE.
- All 51 shell blocks passed `bash -n`; three Python blocks parsed, and three
  JSON blocks parsed. The maintained source check and `git diff --check` passed.
- Real new standalone host environments installed serialptu, pixhawk[manager]
  and meteor_api from the retained compatible offline wheelhouse. Each passed
  `pip check`; none installed satgs/ptu_control. The installed serialptu example
  exactly matched its documented output. Pixhawk manager/subscriber help and
  installed Messenger API signature checks passed without starting their owners.
- Evidence: `/tmp/satgs-component-playbooks-20261118-zwe8451k/summary.json`.
  Temporary driver: `/tmp/satgs_playbook_verify.py`. These are host CPython 3.11
  x86-64 checks, with no network, broker, live GPS or hardware operation.
- The earlier installed TLE-only/PTU-only and mocked HTTP/catalog/planning results
  remain historical evidence for unchanged recipes; they were not rerun.
- A second reader reviewed supplied task scope and example contracts without
  filesystem access. Its clarity suggestions were applied; this is not an
  independent execution or full-suite review.

Updated preview:
`/tmp/satgs-playbook-preview-20261118-czflzy67/guide/user-guide.html`.
Download package:
`/tmp/satgs-playbook-preview-20261118-czflzy67/SATGS-Operator-Playbooks-Preview-20261118.zip`.
The ZIP contains the 13 Markdown chapters, images, offline HTML/text/CSS, preview
README and validation record; it has 23 members and excludes the local gap file.

Next implementation remains the new identified release/target installation and
complete Full inputs described above. Cole still operates the Pi for the planned
jog3 check. Full product and December 1 demonstration goals are unchanged.

## November 19 QPT130 Connect investigation: awaiting actual attempt records

Cole now reports jog3 selected and its changed PTU controls visible. Save local
QPT130 succeeds; Connect returns `deadline`, physical state `unobserved`, and
arrows remain disabled. This supersedes the preceding reported bench selection.
It is not target acceptance or a physical readback PASS.

Read the separate source-backed follow-up at
`/workspace/.codex-transfer/context/satgs-jog3-connect-followup-20261119-q6f9HkB2/NEXT_CHAT_INSTRUCTIONS.txt`.
It explicitly says the current failed Connect started/result records were not
supplied. Neither the follow-up folder nor the recent failure transfer folders
identified those records. Requested the matching existing JSON pair or its local
transfer path; no new hardware run or broad collection was requested.

Traced the live shared path through BenchSession, LocalBenchClient, shared bench
operations, selected-device acquisition and serialptu. Confirmed a source timing
regression candidate: local Connect caps cold verification/open/claim and its
single status query at the saved exchange budget, normally one second. Original
serialptu opened during construction and then allowed a separate five-second
connection window with repeated 0.5-second status attempts. Selected settings
and initial bytes match: `02 31 00 00 00 00 00 31 03`.

Hardware-free reproducer: `/tmp/satgs_connect_reproduce.py`, run with the retained
jog3 host CPython 3.11 application interpreter. It uses the real LocalBenchClient,
driver, encoder/parser and receipt generation, replacing only serial/device and
clock boundaries. Immediate feedback returned `ok`; a controlled 0.8-second open
plus 0.4-second response returned `deadline` after approximately 1.025 virtual
seconds, with a fully written nine-byte status request and no received bytes.
A lost first query also returned deadline with one write. This establishes the
source regression candidate, not the physical unit's actual failure mechanism.

Two independent read-only source readers confirmed timing/packet and limit-policy
facts. Original Connect does not set limits, reset motor faults or override soft
limits. Current axis-status latching occurs only after decoded feedback, so it
cannot by itself explain an unobserved deadline. The separate overbroad directional
soft-limit latch remains a follow-up, not an inferred cause of this attempt.

Do not implement caller retries around ordinary observe_bounded: timeout already
invalidates that owner. A justified establishment correction must distinguish
initial nonmoving probes from MOVE/JOG/STOP, retain partial/late replies and every
attempt, and preserve cancellation, ownership, fault and failed-Stop state. Shared
Connect receipt-count/category validation also needs coherent treatment if more
than one initial probe is introduced.

No product code, release identity, environment/selection, daily station, sealed
handoff or Git ref changed in this investigation. No device, broker, Pi or network
was accessed. No normal update was built or published. Next: inspect the actual
failed JSON exchanges/open outcome, write the concrete narrow change plan, then
implement, run focused affected checks, obtain review of that diff and prepare
the normal separately identified application update.
