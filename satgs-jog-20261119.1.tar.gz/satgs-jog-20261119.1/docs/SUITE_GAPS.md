# Local suite completion notes

Updated November 19, 2026. Development notes for the complete M-SEL / SATGS /
Guided Arrow product. Keep this file outside the packaged operator handbook.
Record missing software, integration, acceptance and documentation here, rather
than inserting a development backlog into operator playbooks.

## Delivery and fresh installation

- Cole selected jog3 on the Pi. Save local QPT130 succeeds; repeated Connect
  attempts wrote the complete initial status query and received no bytes in one
  second. The jog4 candidate restores bounded initial establishment and includes
  the selected-software installer, bootstrap and task playbooks. Publication,
  Pi installation and physical confirmation are separate outstanding steps.
- The installer consumes compatible offline wheels. There is no GUI or CLI
  package downloader or reduced task-specific download bundle. Task selection
  reduces a new environment's installed owners, not bytes already downloaded.
- Deliver the complete selected owner/dependency wheelhouse for CPython 3.11 on
  the Pi's ARM64 platform. Five replacement wheels alone are not that closure.
- Full M-SEL still needs real deliverable owners and dependencies for
  `satgs-post-processing`, `cyberpowerpdu`, `dsi`, `signal_hound_control`, and
  `bbdevice`, including Signal Hound vendor/native support and ARM64 validation.
  Neither the current six-owner source integration nor `satgs[full]` is the
  complete ten-owner suite.
- Installation writes separate started/result receipts and validates Python
  packages. It does not provision host services, native runtimes, device access
  or select the candidate as the daily app. `profile_complete` remains false;
  complete the relevant real provisioning/verification before changing it.
- December 1 demonstration goal remains fresh Bitbucket download, actual Full
  software installation/configuration, normal GUI launch, QPT130 arrows/targets,
  returned position, Stop, CLI parity and retained results. Preserve the broader
  modular product goal after the demonstration.

## ground_station: main application and TLE catalog

- Keep the existing native GUI and shared CLI. No second application or separate
  TLE/PTU implementation. Native TLE fetch/add/edit/delete controls do not exist;
  current catalog maintenance uses the retained commands and CSV editing.
- There is no tiny independent TLE distribution. TLE tools belong to `satgs`
  and bring its scientific/serialization/HTTP dependencies plus meteor-api.
- `add_tle` leaves an existing NORAD ID unchanged. `pass_finder` refreshes records
  older than `DEFAULTS.tle_validity = 0.5` days, not every satellite each time.
  There is no force-refresh-all flag or refresh-only operation.
- Reproduced edge cases to fix with focused regression tests: deleting the final
  row can leave only the `norad_id` header; the undated refresh path passes an
  incompatible reference-time type; refreshed rows lose `txids` associations
  and acquire an `epoch` column. Some legacy fetch errors log without a nonzero
  CLI exit. Preserve user files and improve error propagation.
- Native plans read local CSV without mutation or network. Queue schedule CSV,
  native plan/report JSON and the TLE catalog have different formats and roles.
- Native queue submission/import/removal/clear, live RF controls, database-history
  browsing, database installation/migrations and generic Box upload are separate
  gaps. Retained owner commands are not GUI equivalents.

## serialptu: low-level protocol and serial ownership

- Preserve this owner for PTCR20/PTCR96 command encoding, response parsing and
  final encoded-target checks. Native local control uses it through sat_tracker.
- Do not create another direct-serial GUI or bypass the shared session. Keep one
  writer, actual returned position and the supported Stop operation.
- Current held jog retains device soft limits but does not enforce numeric
  software endpoint/no-go constraints during continuous travel. Numeric moves
  retain those endpoint checks. Document a future policy change only after it
  exists and is tested.
- Wider model/protocol/high-resolution/serial-address combinations need their
  allocated-unit acceptance procedures. The current portable case is QPT130 /
  PTCR20 / 9600, with the recorded Prolific by-id adapter. No repeat baud hunt.

## sat_tracker: higher-level commands and complete passes

- `PtuClient.open_pointing`, the manager and scheduled tracking lifecycle exist.
  Native reviewed requests and retained outcomes exist. Ordinary live runtime
  owner admission remains closed; a controlled host run is not physical tracking.
- Complete the supported runtime/owner binding and commissioning path for
  load-TLE, prime, scheduled track, completion, cleanup and physical outcome.
  Supply real example input files and an operator pass playbook after that path
  works. Never substitute historical practice TLEs or guessed owner identities.
- Keep explicit local manual serial control independent of ActiveMQ. Preserve
  the distributed broker route without silent transport switching.
- The deployment planner still describes distributed PTU broker dependencies
  for the local-only Custom selection. Reconcile the planning model with the
  explicit manual transport rather than installing an unnecessary server.
- Guided Arrow's retained queue requires local recording/processing operations
  while its profile assigns those capabilities externally. Complete that
  deployment contract before treating the canonical queue as operational.

## Pixhawk: GPS subsystem

- Manager and subscriber source are present. `pixhawk[manager]` adds pyserial,
  pymavlink and NumPy. A subscriber-only install does not own the USB connection.
- The manager parser uses `--pix-id`, not the old README's `--ptu-id`. Distinguish
  its positive sensor ID, mapped PTU ID, host serial path and receiver UARTs.
- Native `Use GPS` remains disabled. Finish live measured-source selection,
  identity, valid fix, freshness, health, position/altitude references and
  station persistence. Synthetic replay and manually saved location do not
  establish live GPS reception.
- Supply the actual Cube/receiver connection, firmware, dual-GPS moving-baseline
  heading, north/alignment and acceptance documentation for the allocated unit.
  Check the source's inconsistent GPS-yaw unit comments against the MAVLink
  conversion before publishing heading calculations. Do not invent thresholds.
- Verify current distributed manager/subscriber entry points with the paired
  Messenger/lower transport and proper shutdown. They retain legacy constructor
  call sites; source presence alone does not prove an end-to-end deployed path.

## meteor-api: Messenger.py request

- Messenger already exists at
  `components/meteor-api/src/meteor_api/messenger.py`; its import is
  `from meteor_api.messenger import Messenger`. Preserve it as the single shared
  owner. Do not add a duplicate capitalized `Messenger.py` or copy it into SATGS.
- The paired distribution is `meteor_api==2.2.0+bench.20261117.1`, with amended
  `stomp.py==8.1.0+bench.20261117.1`. Preserve both when packaging owners.
- Bounded TLS acquisition, subscribe/publish/cancel/close and the separate
  loopback bench route are implemented. Validate each retained legacy consumer
  against the intended acquisition/lifecycle contract during its integration.
- Complete a site-specific ActiveMQ/Java/service provisioning procedure with
  actual endpoint, trust, account and lifecycle settings. Package presence is
  not server provisioning. Keep credentials and private keys out of examples.

## Remaining complete-suite owners and documentation

- Retain the complete ten-owner Full catalog, including RF front end, PDU/HPA,
  recording, native wrapper and post-processing. Bring in real source/artifacts
  and device-specific procedures rather than empty directories or invented tools.
- Provide supported model/native/platform procedures for Signal Hound, RF
  routing/limits, PDU outlet mapping, capture capacity, post-processing inputs,
  optional Box/email configuration and failure recovery.
- Verify the complete fresh/profile installation on the Pi and record which
  evidence is host-only, Pi software, live telemetry or physical motion.
- Publish operator playbooks only for their actual supported endpoint. Expand
  GPS reception, complete pass tracking and full service setup when the missing
  integration and example configurations above are complete.

## Evidence retained from the current work

The installed host examples for TLE-only/PTU-only selections, real offline pip
resolution, TLE command boundaries, manual CSV planning and passive local bench
configuration are recorded in `docs/PROJECT_STATE.md`. They used no live device
or broker. The documentation preview is unpublished. Do not turn those results
into a Pi installation, live CelesTrak, GPS or physical tracking claim.
