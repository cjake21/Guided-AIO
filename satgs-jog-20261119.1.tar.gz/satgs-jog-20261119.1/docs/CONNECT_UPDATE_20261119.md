# QPT130 Connect update, November 19

Candidate `jog-20261119.1`, alias `jog4`, pairs satgs, ptu_control and serialptu
at `0.0.1+jog.20261119.1`. It preserves all older applications and station data.

## Evidence and correction

Cole supplied the actual failed Connect report. Jog3 attempt
`74d4b451112f42f5baf6f378d37ff543` opened the selected adapter in approximately
27 ms, wrote all nine bytes `02 31 00 00 00 00 00 31 03`, and received no bytes
during the remaining approximately 0.98 seconds. Repeated attempts have the
same shape. This establishes an unanswered query, not an open failure, corrupt
reply or decoded soft-limit flag. Separate policy_mismatch records wrote nothing.

The original driver allowed five seconds for connection establishment and used
0.5-second status attempts. The shared local owner had instead bounded cold open
and one query by the saved one-second ordinary exchange timeout. Local Connect
now has a five-second overall budget, including acquisition, and repeats only
fully written initial status queries with no reply bytes, at most ten probes.
After a reply following repeated probes it validates subsequent frames and waits
for 0.5 seconds without new bytes, within the same overall budget. Every probe
and all received bytes remain in existing Results/report records. PTCR20 has no
transaction ID, so the record labels initial response correlation as unsequenced.
Later unexpected input still fails the ordinary stale-input check.

Partial replies/writes, unknown write counts, malformed frames, cancellation,
failed Stop and invalidated contexts remain terminal. Connect sends no movement,
reset, homing or limit-programming command. Ordinary command budgets and saved
settings are unchanged. Feedback retains conservative age from request start;
a slow successful Connect makes polling due promptly. The PTU tab also moves its
existing Choose button into the connection row to recover vertical space.

This is a source-supported startup correction. Only Cole's hardware test can
show whether it resolves this unit's silent response.

## Validation and review

The real driver/encoder/parser with controlled serial boundaries reproduces the
old failure for a 0.8-second open plus a 0.4-second reply, and for a lost first
reply. The corrected implementation succeeds in both scenarios. Delayed replies
to two startup probes are consumed before a following Status succeeds.

Focused driver/owner/shared CLI/interface modules: 223 passed; 16 native methods
were skipped without a display and are covered separately on an owned display.
Installer, guide and core tests: 31 passed. Release/launcher tests: 92 passed.
All six wheels built offline; a separate 31-distribution host installation passed
creation, install, dependency and metadata checks. Source and whitespace checks
passed. These are host results, not Pi or physical acceptance.

The installed host candidate also passed all 17 consolidated headless phases,
with no failures, skips or runtime denials and clean supervision. Installed native
capture ran 42 methods: 41 passed, one exact-font test was explicitly unavailable;
there were no failures, errors or runtime denials and cleanup was clean. The native
lane is BLOCKED for that missing font case, not a complete native acceptance PASS.
Records are retained in
`/workspace/development/satgs-maintenance/jog4-release-20261119/host-check-1`
and `host-check-2`. The six-owner build is
`/workspace/development/satgs-maintenance/jog4-release-20261119-build-1`.

Independent implementation review initially found pending startup replies and
slow-Connect polling issues. Both were corrected and the review approved the
implementation. That reviewer authored driver regressions but did not implement
the correction. The release/launcher reader found a missing jog3 rollback choice;
it was corrected and the focused release tests passed.

The actual Connect button passes a lost-first-reply test: arrows remain disabled
while waiting, then become available after valid feedback; no motion is emitted.
The original GUI reproduces the three reported layout overflows under the text-
spacing stress. The corrected GUI passes. The exact 17-pixel Pi-font check is
explicitly unavailable on the retained host's fixed 13-pixel Tk9 font runtime.

## Operator update after publication

Download and extract the reviewed archive in a new directory. Close SATGS after
ending any active session. Keep the previous application and offline dependencies.
From the extracted directory:

```sh
. ./setup_update.sh --accept-trusted-native
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog4
```

Setup stages `/home/admin/satgs-jog-20261119-app-manager`. Selection occurs only
after successful checks and an idle station. Open SATGS, go to PTU, leave the
Configuration JSON field empty to use the existing saved connection, then Connect.
Allow five seconds. Verify returned position before trying a supervised short jog
and Stop. If Connect still fails, its existing Results > Report now contains the
complete initial phase. Do not force-enable controls or install ActiveMQ for local
serial. Cole performs all hardware tests.

Rollback while idle: `. ./launchers/setup_daily.sh --select jog3`.
No current station settings, results or accepted installations are overwritten.
The installer and task playbooks are included; complete Full M-SEL owner/native
provisioning remains tracked separately in SUITE_GAPS.md for the December 1 goal.
