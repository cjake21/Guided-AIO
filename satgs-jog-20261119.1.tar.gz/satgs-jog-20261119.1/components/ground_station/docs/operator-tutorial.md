# 8. Plan and perform supported runs

Calculate an opportunity before preparing a run. An opportunity describes a
satellite's visibility for a particular site, orbit input, time span and elevation
mask. It is not a queue submission or proof that equipment can execute it.

Results uses Start (UTC ISO 8601), NORAD ID, Span (days), Minimum elevation (deg)
and Local TLE CSV. UTC time needs an explicit offset. Span is one hour through
seven days, elevation 0 through 90 degrees, and at most 256 opportunities are
retained. A circumpolar opportunity can omit rise/set times. Empty results mean
no opportunity was found for these inputs.

Use current approved local orbit data for current operational planning. Native
planning validates the selected identity/CSV/TLE/checksums but does not fetch or
refresh it. The default and the exercise below are explicitly historical NOAA 15
data, not a demonstration of current orbit freshness.

## Maintain a TLE catalog

Choose this path when you want orbital data and pass calculations without
installing PTU, GPS or RF owners. For a new reduced environment, complete the
[TLE-only Custom selection](configurations.md#tle-only-custom-changes-file) and
[software installation](installation.md#install-the-saved-software-selection)
first. The example variables below refer to that new station, its application
environment and its private example parent. The existing TLE tools are console
commands owned by `satgs`; they are not `satgs-operator` subcommands.

If an accepted operator environment is already installed, its TLE console tools
can be used without waiting for the new selective installer. Set `satgs_task_app`
to that actual installed directory, keep a separate example parent/CSV, and skip
creating another environment. After installing and selecting jog4, its example path
is `/home/admin/satgs-jog-20261119-app-manager`. Merely downloading it does not
create that environment. This uses the packages already present; it is not a
claim that the old download was a minimal TLE-only bundle.

Here, "database" means a CSV satellite catalog on disk. No SQL database or
database-server account is needed. It is separate from `station.json`, native
plan JSON, run sheets and the distributed job queue. Use the console commands or a CSV editor for maintenance, then choose the
resulting CSV on Results to calculate a local plan.

### Create a new catalog or select an existing one

For a new catalog in the new example parent:

```sh
satgs_tle_db="$satgs_example_root/sat_db.csv"
printf '%s\n' 'norad_id,name,tle,date,txids' > "$satgs_tle_db"
```

Run that creation line once for a new file. For existing data, set `satgs_tle_db`
to its actual absolute path and skip creation. Close any CSV editor while a CLI
command is writing the file, and do not run two writers at once. The legacy tools
rewrite the CSV and do not provide the native station's revision/locking contract.
Keep a copy before changing an existing catalog.

### Fetch and store one current TLE from CelesTrak

The example NORAD catalog number is `25544`. Replace it with the object you want.
This command needs network access from the operator's machine to CelesTrak:

```sh
env STOMP_SKIP_HOSTNAME_SCAN=1 "$satgs_task_app/bin/add_tle" 25544 --satfile "$satgs_tle_db"
cat "$satgs_tle_db"
```

`STOMP_SKIP_HOSTNAME_SCAN=1` skips an unused legacy transport hostname scan; this
TLE operation does not construct a broker client. The application requests the
configured CelesTrak GP endpoint with `CATNR=25544` and `FORMAT=TLE`, then writes
the returned name and two element lines into the CSV. `date` records the fetch
time in UTC. The orbital epoch embedded in line 1 is a different value and is
not made current by changing `date`.

The file should now contain a `25544` row with a quoted TLE field and a UTC date.
Provider availability determines whether a particular ID has data. Inspect the
row and logged outcome: these legacy commands can report a fetch error without
a nonzero shell exit. An HTML/error response is not a usable TLE.

If that ID is already present, `add_tle` logs "Satellite already in dB" and leaves
it unchanged. Repeating add is not a refresh command. Use the age-based refresh
procedure below, or deliberately replace the row through manual entry when you
have newer valid elements.

### Manually enter or replace elements you already have

Make a backup, open the CSV in a text or CSV editor, and add or replace the entire
row for the NORAD ID. Keep one row per ID. A duplicate is not a second version of
that satellite; native planning rejects an ambiguous selected ID.

The required columns are `norad_id,name,tle,date`; the legacy catalog also uses
`txids`. Preserve that column if present. For TLE-only work it can be empty.
The `tle` cell contains `NAME,line 1,line 2` as one quoted CSV field. Preserve
every space, sign and checksum digit in the two 69-character element lines.
The row name must equal the name inside that cell, and both element lines must
contain the same NORAD number as the row.

This complete one-row file is the bundled historical NOAA 15 practice example
using the four required planning columns. It is valid input for the historical
calculation below, not current orbital data. When editing an existing five-column
legacy catalog instead, keep its `txids` column and its corresponding field on
every row; an empty field is represented by a final comma on this sample row.

```csv
norad_id,name,tle,date
25338,NOAA 15,"NOAA 15,1 25338U 98030A   25135.84934273  .00000229  00000+0  11192-3 0  9996,2 25338  98.5367 161.5741 0011424  74.5549 285.6893 14.26965248404873",2025-05-16 02:51:09 UTC
```

Save it as a separate `manual-tle.csv` under the example parent. For your own
elements, replace the ID, both occurrences of the name, both element lines and
the actual acquisition/reference date. The date format is exactly
`YYYY-MM-DD HH:MM:SS UTC`, including the space before `UTC`. Do not stamp an old
TLE with today's date to make it appear fresh. Native planning checks row shape,
identity, line length, checksum and date format; parsing successfully does not
establish that the orbit is suitable for today's tracking job.

To remove a manually entered satellite, delete that entire CSV row while keeping
the header and all unrelated rows. Save the file, then verify that the ID is
absent and the full header remains.

### Delete a satellite with the existing command

For an existing catalog row:

```sh
cp -n "$satgs_tle_db" "$satgs_tle_db.before-delete.csv"
env STOMP_SKIP_HOSTNAME_SCAN=1 "$satgs_task_app/bin/del_tle" 25544 --satfile "$satgs_tle_db"
cat "$satgs_tle_db"
```

The row should be absent and other satellites should remain. An unknown ID logs
that it is not in the database. The command removes the row; it does not merely
clear its two element lines. Deletion does not cancel scheduled work or erase
previous plans/results.

After deletion, verify that the header still contains
`norad_id,name,tle,date,txids` for a five-column catalog. Keep that full header
when the catalog becomes empty; restore it in the editor before the next add
if necessary. Preserve all unrelated rows.

### Check all stored satellites and refresh stale elements

`pass_finder` reads the chosen CSV, checks TLE age, fetches replacements where
needed, saves updates back to that same CSV, and then calculates passes. With no
`--sids`, it checks every catalog row. Its current freshness threshold is
`DEFAULTS.tle_validity = 0.5` days, or 12 hours. A row inside that age window is
kept; "check all" does not mean "fetch every satellite on every invocation".
Use manual replacement when you already have newer elements for a fresh row.

It also needs a planning location, even if refreshing was your main purpose.
Save this as `pass-finder.yaml` under the example parent, replacing the synthetic
site with your intended planning location and the output directory with an
actual absolute path:

```yaml
ground_station_name: Example planning site
ground_station_lat: 34.0
ground_station_lon: -118.0
ground_station_altm: 100.0
run_sheet_dir: /home/admin/satgs-example-run-sheets
```

Latitude/longitude are decimal degrees, north/east positive; altitude is metres.
This legacy YAML is separate from the native task station's `station.json`.
Saving coordinates on Location does not update this YAML. For native planning,
use Location; for this legacy command, explicitly supply its YAML.

```sh
cp -n "$satgs_tle_db" "$satgs_tle_db.before-refresh.csv"
env STOMP_SKIP_HOSTNAME_SCAN=1 "$satgs_task_app/bin/pass_finder" --satfile "$satgs_tle_db" -config "$satgs_example_root/pass-finder.yaml" --duration 1 --elmask 20 --to_csv
```

The command uses the host's current UTC time for its prediction start. Duration
is days and elevation mask is degrees. It writes a run sheet such as
`passes_utc_<time-and-id>.csv` beneath `run_sheet_dir` and prints its path.
Without `--to_csv`, it prints a summary instead. `--sids 25544 25338` restricts
the checked/calculated set to those existing IDs. Do not name absent IDs.
GNSS passes are excluded from predictions by default; add `--gnss` if wanted.
`--local` displays the source's configured US/Eastern time rather than UTC.

Keep valid UTC dates on catalog rows. For an RF catalog, refresh a working copy
and retain its transmitter associations. Compare the resulting IDs, elements,
dates and metadata with your backup before replacing the operational file.
Inspect fetch errors and verify the actual catalog contents after the command.

### Calculate a native plan from the file

For the manually entered historical sample, save `34.0`, `-118.0`, `100.0`,
`mean_sea_level` on Location through Preview and Review > Save. These are practice
coordinates. On Results enter the following:

| Field | Historical practice value |
| --- | --- |
| Start (UTC ISO 8601) | `2025-05-16T03:00:00Z` |
| NORAD ID | `25338` |
| Span (days) | `1` |
| Minimum elevation (deg) | `20` |
| Local TLE CSV | The absolute path to your `manual-tle.csv` |

Click Calculate. A `plan-<id>.json` is saved automatically in the native task
workspace. The equivalent command from the installed task environment is:

```sh
"$satgs_task_app/bin/satgs-operator" --workspace "$satgs_task_station" plan --start 2025-05-16T03:00:00Z --norad-id 25338 --span-days 1 --elevation-deg 20 --tle-file "$satgs_example_root/manual-tle.csv"
```

For a current fetched object, use its ID, the fetched catalog path and an explicit
current start time. Leave the source file untouched while calculating. Native
planning neither downloads nor refreshes TLEs, and Calculate never starts PTU
tracking. Use Results > Report or Export... to inspect/share the saved result.

## Install and use a local PTU instance

Use a new example station and the
[local PTU-only Custom file](configurations.md#local-ptu-only-custom-changes-file).
Select the four owners shown there, preview/save them, and install into a new
environment such as `/home/admin/satgs-ptu-app`. Use that environment's
`satgs-operator-gui --workspace ABSOLUTE_STATION_PATH` entry point as described
in Installation. The current release bootstrap may already contain extra owners;
this separate environment demonstrates the smaller selected software set.

This example is explicit local serial control. It needs no broker, GPS fix,
station coordinates, TLE, pass plan or RF package. Software installation does not
establish physical travel clearance or enable safe operation of a different PTU.
The existing Pelican configuration is QPT130, PTCR20, 9600 baud, with the Prolific
by-id adapter ending `EBCUb14C705-if00-port0`. Use its full stable device path
from the PTU chapter. Another station must provide its own supported binding.

1. On PTU, keep the configuration file field empty for the saved local default, or select your existing reviewed local configuration. Click Save local QPT130 once. No connection or movement occurs.
2. Confirm the equipment setup and clear area under the supervised procedure, then click Connect. Inspect Reported pan/tilt and Status. Connect reads returned angles; it does not home or move.
3. Hold a local directional arrow for a deliberate supervised jog; release requests Stop. Give Keys focus for keyboard arrows. Editing arrows in number/text fields retain their normal behavior. Focus/tab changes end a hold.
4. For a numeric move, enter permitted mechanical Target pan/tilt values in degrees. Keep the other axis at its latest returned angle. Click Preview, inspect the target, then Move. A requested target is distinct from the reported angles.
5. Click Stop, inspect the outcome and returned evidence, then Disconnect. Disconnect releases ownership and is not proof of physical stopping.
6. Use Results > Report and Export... to retain the session record. Reopen the same station to inspect it later.

Continuous jog retains device soft limits but does not enforce the numeric
software endpoint/no-go policy during travel. Numeric moves retain requested and
encoded-target checks. Use [the PTU chapter](ptu-operation.md) for the actual
configuration, hold/focus behavior, failure recovery and supervised first-use
procedure.

The equivalent CLI uses the same saved local setup and exclusive owner:

```sh
"$satgs_task_app/bin/satgs-operator" --workspace "$satgs_task_station" bench-configure --transport local-serial
"$satgs_task_app/bin/satgs-operator" --workspace "$satgs_task_station" bench
```

Inside the session, start with `connect`, then `status`. Numeric grammar is
`preview PAN TILT`, then `move`; continuous grammar is
`jog left|right|up|down SECONDS`. Replace those words with one permitted target,
direction and supervised duration; they are not literal commands to paste.
Finish with `stop`, `status`, `disconnect`, `quit`. Do not run GUI and CLI writers
concurrently. Session results are saved automatically in that task station.

## Prepare a Full M-SEL instance

Choose this path for the complete station. Use the Full M-SEL release input set
for your target platform and keep the existing application available while
preparing the new instance.

1. Obtain the versioned application and complete target-platform package set from the internal release route. Check that all ten owners in Installation are supplied, including `satgs-post-processing`, `cyberpowerpdu`, `dsi`, `signal_hound_control` and `bbdevice`. Assign compatible Signal Hound vendor/native support, Tk/Tcl and separate broker/time/service responsibilities.
2. Stage and check the native application using that release's setup procedure. On a fresh account, use the release's explicit bootstrap/initialize procedure. Open the normal GUI and the intended new Full station.
3. On Setup choose Profile `full_msel`. The current Pelican case's PTU model is QPT130. Click Preview; on Review inspect the ten packages, capabilities, host roles and deployment diagnostics. Click Save to record that selection.
4. Return to Setup. Enter the complete absolute Offline wheel directory and a new environment path such as `/home/admin/satgs-full-app`. Click Install software. Read the installation outcome in Results and retain its receipt and log.
5. Inspect the install outcome and installed versions. `software_complete: true` means the selected Python software installed and passed its checks. `profile_complete: false` and unresolved responsibilities still require actual platform, service, device and native-runtime configuration. No service or hardware is started by this action.
6. Open that new environment with the explicit entry point from Installation, keeping the daily app available for rollback. Follow the tab walkthrough below and the separate owner procedures for services/equipment. Use a published release's checked selection procedure when making it the daily app.

For the CLI choice and install on a new Full task station:

```sh
satgs_full_choice=$(satgs-operator --workspace "$satgs_task_station" --format json components-preview --profile full_msel) || exit 1
printf '%s\n' "$satgs_full_choice"
satgs_full_choice_id=$(printf '%s' "$satgs_full_choice" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
satgs-operator --workspace "$satgs_task_station" apply --preview "$satgs_full_choice_id" --confirm
satgs-operator --workspace "$satgs_task_station" install-software --wheelhouse "$satgs_task_wheels" --environment "$satgs_task_app"
```

Review the printed preview before Apply. This uses the same saved selection and
installer as the GUI. Configure the assigned broker, device permissions, receiver, PDU mapping and
storage destinations through their owner procedures. Native tabs cover shared
operator tasks; Full RF queue, receiver and post-processing workflows retain
their component owners and configuration. Read [every tab](daily-operation.md#walk-through-every-tab)
and the [component handbook](component-handbook.md) for those boundaries.

## Use the original component owners

Use these references when integrating a component into another program or
maintaining a distributed station. Routine manual PTU operation uses the
[PTU-only playbook](operator-tutorial.md#install-and-use-a-local-ptu-instance).
The library examples below use a separate environment so they preserve the
normal SATGS application.

### Inspect a PTU command packet without connecting hardware

Choose this task if you need serialptu's low-level command construction rather
than the whole station application. Use the release wheel directory from
Installation and a new environment:

```sh
satgs_serial_root=$(mktemp -d "$HOME/satgs-serial-example.XXXXXXXX") || exit 1
satgs_serial_app="$satgs_serial_root/application"
python3.11 -m venv "$satgs_serial_app"
"$satgs_serial_app/bin/python" -m pip install --no-index --find-links "$satgs_task_wheels" "serialptu==0.0.1+jog.20261118.3"
"$satgs_serial_app/bin/python" -m pip check
```

This installs serialptu and its pyserial/NumPy/SciPy dependencies. It is a
library installation; choose the PTU-only Custom selection instead when you
want the native window and CLI.

Save the following as `inspect_packet.py` inside the new example parent:

```python
from serialptu.proto_impl import PTCR20

protocol = PTCR20()
packet = protocol.move_to(10.0, 5.0)
print(packet.hex(" "))
print(protocol.decode_move_to_packet(packet))
print(protocol.validate_nonmoving_status_packet(protocol.get_status()).hex(" "))
print(protocol.validate_stop_packet(protocol.stop_packet()).hex(" "))
```

Run it with the library environment:

```sh
"$satgs_serial_app/bin/python" "$satgs_serial_root/inspect_packet.py"
```

Expected output:

```text
02 33 64 00 32 00 00 00 65 03
(100, 50, 10)
02 31 00 00 00 00 00 31 03
02 31 1b 82 00 00 00 00 33 03
```

The decoded target is 100/50 counts at 10 counts per degree: 10 degrees pan,
5 degrees tilt. The remaining lines are a nonmoving status packet and a Stop
packet. This program constructs and validates bytes in memory. It opens no port
and sends no command. Use a fresh protocol instance for independent sessions
because protocol objects retain state.

PTCR20 has no serial wire ID. PTCR96 has its own address and encoding contract.
For actual control, the shared sat_tracker session binds the selected protocol,
owns the serial connection, checks the encoded target and reads responses. Do
not send these example bytes to a device alongside that session.

### Prepare and review a tracking request

Choose this task when moving from a single manual PTU command to a satellite
pass. The endpoint of this procedure is an input-bound request for review.
ground_station plans the opportunity and runs the pass lifecycle; sat_tracker
owns higher-level PTU commands; serialptu owns their serial encoding.

Use Full M-SEL or a deployment-specific selection containing ground_station,
meteor-api, sat_tracker, serialptu and the actual navigation/service owners used
by that deployment. Install through Setup as described earlier. For an
integration that needs only the Python PTU client, its distribution is
`ptu_control==0.0.1+jog.20261118.3`; the local manager role is
`ptu_control[manager]==0.0.1+jog.20261118.3`. Required dependencies are resolved
with the package. This is the same owner used by the existing PTU tab.

1. Save the actual planning site on Location.
2. Maintain the local TLE catalog, then Calculate on Results with the intended NORAD ID, UTC start, span and elevation mask.
3. Open Run and select the returned Plan. Choose the desired Opportunity (1-based) and a Duration (seconds) that fits inside it.
4. Select the deployment's Configuration JSON, Runtime bindings JSON, Owner settings and the same Local TLE CSV used by the plan. These files identify the configured services and equipment.
5. Choose the intended Execution mode and click Review run. Inspect the plan, site, time window, TLE and owner identities in the saved request.
6. Keep the returned request ID. Use it to inspect status and, for a started supported run, progress, cancellation and final results.

The equivalent CLI review form is shown below. Uppercase words stand for the
actual paths and IDs returned or supplied for this deployment:

```text
satgs-operator --workspace STATION run-preview --plan-id PLAN_ID
    --deployment-config CONFIGURATION_JSON --runtime-bindings BINDINGS_JSON
    --station-config OWNER_SETTINGS_JSON --tle-file LOCAL_TLE_CSV
    --duration SECONDS --opportunity 1 --mode operational
satgs-operator --workspace STATION run-status --run-id REQUEST_ID
```

Reviewing or saving a scheduled tracking request does not start tracking. Start
must accept the request before a supported tracking run begins. Use the
[run review procedure](operator-tutorial.md#review-a-run-request) for execution
scope and [Results](results.md) to interpret its records.

For integration work, the existing pointing client lifecycle is
`PtuClient.open_pointing`, `enable_scheduled_tracking`, `load_tle`, `prime`,
`track`, `complete_tracking`, then `close`. Commands take explicit deadlines
and cancellation controls. The shared pass runner owns that ordering and cleanup;
a GUI tab should call the shared operations rather than reproduce it.

### Configure the Pixhawk GPS owner

Choose the installation role from where this instance receives observations:

| Role | Package selection | Connection owned here |
| --- | --- | --- |
| Subscriber in another application | `pixhawk==0.0.1` | Messenger subscriptions to the assigned sensor |
| Local Cube/MAVLink manager | `pixhawk[manager]==0.0.1` | Host serial connection, plus Messenger publishing |
| Native station with navigation | Select pixhawk and its observation capabilities in the intended profile | Navigation owner configured for that station |

For a standalone component environment, create a new parent and select the
package for your role. This example installs the local manager dependencies:

```sh
satgs_gps_root=$(mktemp -d "$HOME/satgs-gps-example.XXXXXXXX") || exit 1
satgs_gps_app="$satgs_gps_root/application"
python3.11 -m venv "$satgs_gps_app"
"$satgs_gps_app/bin/python" -m pip install --no-index --find-links "$satgs_task_wheels" "pixhawk[manager]==0.0.1"
"$satgs_gps_app/bin/python" -m pip check
```

For subscriber-only use, select `"pixhawk==0.0.1"` in that install command.
The manager extra adds pyserial, pymavlink and NumPy. The shared meteor-api
dependency supplies messaging; the broker service is configured separately.

The sensor mapping in owner settings uses these fields:

```yaml
pixhawk_sensors:
  - id: 1
    ptu_id: 1
```

This is a mapping fragment, not a complete broker configuration. Replace both
positive application IDs with the assigned sensor and PTU IDs. The bounded
pointing subscriber selects one matching sensor row. The retained distributed
echo tool accepts a sensor ID, with `0` meaning all configured sensors.

The following options describe an already configured distributed deployment.
Installing the package prepares the software; reception also requires the
assigned Cube connection, running publisher and configured Messenger service.

| Entry point | Option | Value |
| --- | --- | --- |
| `python -m pixhawk.pixhawk_manager` | `--pix-id` | Positive application sensor ID, for example `1` |
| Same manager | `--port` | Allocated host serial path |
| Same manager | `--baud` | Connection baud, default `115200` |
| Same manager | `-config` | Absolute private station YAML path |
| `echo_pixhawk SENSOR_ID` | `-config` | Same station's private YAML; observes the configured publisher through Messenger |
| Same echo subscriber | `--filename` | New output CSV base in an existing directory |

Use the installed component environment's Python/console entry point in its
service definition. The manager's flag is `--pix-id`. Its port is the host
connection to the Cube; USB `/dev/ttyACM0` at 115200 is an example, while the
actual allocated connection and baud come from the navigation setup. The GPS
receivers' UART connections to the Cube are separate. Start the deployed service
through its owner procedure, with that configuration's Messenger endpoint.

The manager requests ATTITUDE, GPS_RAW_INT, GPS2_RAW and GLOBAL_POSITION_INT at
1 Hz and publishes fused observations. Interpret the output fields separately:

| Field | Meaning |
| --- | --- |
| `pix_id`, `pc_time` | Application sensor identity and host observation time in UTC |
| `lat`, `lon` | Latitude and longitude converted to decimal degrees |
| `alt` | Altitude converted from millimetres to metres; retain its source reference |
| `roll`, `pitch`, `yaw` | Attitude fields in radians |
| `gpsStatus`, `gps2Status` | Receiver fix-type values |
| `gpsVis`, `gps2Vis` | Receiver satellite counts |
| `hdg` | Heading in hundredths of a degree from the source message |

Keep GPS yaw fields with their source/units when reviewing raw data. A received
message, a valid position fix and qualified dual-GPS antenna heading are separate
observations. Inspect the assigned sensor and timestamp as well as the numbers.

An echo log base such as `navigation.csv` produces per-sensor files such as
`navigation_1.csv` under the selected existing output directory. The bounded
pointing subscriber's run artifact is `pixhawk_log_1.csv` for sensor 1. Use new
output paths to preserve prior logs. Native Location shows manual and
measured/replay state separately; enter the planning site through its manual
Preview/Save workflow. Saving coordinates does not demonstrate GPS reception.

### Use the shared Messenger owner

Choose this task when writing a component that publishes commands or subscribes
to observations. The implementation requested as Messenger.py is already the
shared `meteor_api/messenger.py` module:

```python
from meteor_api.messenger import Messenger, MessengerError
```

It is installed automatically with the main station/PTU/GPS owners. To install
only the message library and its required dependencies for an integration:

```sh
satgs_messaging_root=$(mktemp -d "$HOME/satgs-messaging-example.XXXXXXXX") || exit 1
satgs_messaging_app="$satgs_messaging_root/application"
python3.11 -m venv "$satgs_messaging_app"
"$satgs_messaging_app/bin/python" -m pip install --no-index --find-links "$satgs_task_wheels" "meteor_api==2.2.0+bench.20261117.1"
"$satgs_messaging_app/bin/python" -m pip check
```

This selects the paired `stomp.py==8.1.0+bench.20261117.1` dependency. Use the
release's copies together. ActiveMQ/Java is a separately configured service.

For bounded TLS acquisition, the component supplies a private settings mapping:

| Setting | What to provide |
| --- | --- |
| `amq_dial_address` | Assigned canonical numeric IP address, for example the documentation-only address `192.0.2.7` |
| `amq_port` | Integer port of the assigned TLS STOMP listener |
| `amq_tls_server_name` | Server identity to verify against its certificate |
| `amq_ca_pem` | Public CA certificate PEM text supplied by the service owner |
| `amq_username`, `amq_password` | Credentials supplied privately for this component |
| `amq_use_ssl` | Boolean `true` |
| `amq_stomp_host` | Optional broker virtual-host header |

Example addresses are not a configured station. Keep private settings outside
source and exported reports. This bounded path requires
`STOMP_SKIP_HOSTNAME_SCAN=1` in the component's launching process. It skips the
legacy hostname scan; dial address and verified TLS certificate identity remain
explicit inputs.

The bounded API sequence below is integration code for an available configured
broker. The caller supplies `settings` using the mapping above, an assigned
`topic`, and `on_message`, a callback accepting body and identifier:

```python
import threading
from time import monotonic
from meteor_api.messenger import Messenger

cancel = threading.Event()
prepared = Messenger.prepare_transport(settings, cancel)
messenger = Messenger.open_bounded(
    settings, monotonic() + 5, cancel, prepared=prepared
)
try:
    messenger.subscribe(
        topic, on_message, "example",
        deadline=monotonic() + 5, cancel=cancel
    )
    messenger.publish(
        topic, b"example payload",
        deadline=monotonic() + 5, cancel=cancel
    )
    messenger.cancelSubscribe(
        topic, on_message, "example",
        deadline=monotonic() + 5, cancel=cancel
    )
finally:
    messenger.close(deadline=monotonic() + 5)
```

The callback runs when a matching observation arrives; publishing alone does
not establish that another component acted. Real station topics use their
owner's expected payload, commonly a serialized protobuf. Use the same callback,
topic and identifier when cancelling a subscription. Give every operation an
absolute monotonic deadline and close the owner during cleanup. Messenger
provides transport; the receiving owner validates and performs its operation.

## Practice without hardware

This tutorial extends the earlier operator practice workflow with the current
window labels and daily launchers. It uses a new private directory, synthetic
site coordinates and a historical NOAA 15 TLE. It never uses the daily station
as a disposable fixture. None of the steps below starts a service or opens a
device.

## Inspect the existing station first

From any normal working directory:

```sh
satgs-operator status
satgs-operator --format json status
```

Home > Reload (Ctrl+R) is the matching native action. These commands inspect the
already selected workspace. They do not initialize or repair it. If the daily
selection or workspace is unavailable, retain the diagnostic and read
`satgs-operator docs --text`; do not issue `init` against the daily path.

## Create a private practice workspace

Use Bash and the daily `satgs-operator` command already selected by reviewed
setup. The following creates a unique parent directory under `/tmp`; it changes
only the task-specific variables shown. Keep the printed path for reopening.

```sh
satgs_practice_root=$(mktemp -d /tmp/satgs-guide-practice.XXXXXXXX) || exit 1
satgs_practice_station="$satgs_practice_root/practice station"
printf 'Practice directory: %s\n' "$satgs_practice_root"
satgs-operator --workspace "$satgs_practice_station" init
satgs-operator --workspace "$satgs_practice_station" status
satgs-operator-gui --workspace "$satgs_practice_station" &
```

The new station starts at generation 1 with no selection and no location.
Unknown observations and unqualified calibration/heading are expected. The
space in `practice station` is deliberate; retain the quotes around its path.
The final `&` leaves the graphical window running while this terminal accepts
the paired CLI examples. Close that window normally when the exercise is done.
The daily selection still points to the original saved workspace. The explicit
`--workspace` changes this invocation only. Keep this terminal open for the
remaining examples, or set the two task-specific variables to the exact printed
paths in another terminal.

The examples below use `34.0` degrees north, `-118.0` degrees east and `100.0`
metres, later changing longitude to `-117.0`. These are synthetic practice values
chosen for a repeatable calculation, not a surveyed site or Cole's location.
Mean-sea-level reference is explicitly declared for the exercise; no conversion
is performed.

## Select Guided Arrow and retain returned identities

In Setup choose `guided_arrow` and QPT130, then Preview. Review shows the previous
and proposed selection. Click Save, then Reload to see the saved intent. To
perform the same change through the CLI instead, use this sequence once:

```sh
satgs_component_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json components-preview --profile guided_arrow) || exit 1
satgs_component_id=$(printf '%s' "$satgs_component_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_component_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_component_id" --confirm
satgs-operator --workspace "$satgs_practice_station" reload
```

Review the printed JSON before the apply line. `preview_id` is the actual value
returned by your operation, not a fixed token to copy from this guide. Human
output intentionally omits internal IDs, so use `--format json` before the
command when a later command needs an identity. Stop if preview or JSON parsing
fails. The GUI and CLI alternatives are the same workflow; do not mistake doing
both for a necessary second save.

## Cancel a location preview

In Location enter latitude `34`, longitude `-118`, altitude `100`, and
`mean_sea_level`. Click Preview, inspect Review, then Cancel (Esc). Home > Reload
must still show no effective location. Equivalent CLI:

```sh
satgs_location_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json location-preview --latitude-deg 34 --longitude-deg -118 --altitude-m 100 --altitude-reference mean_sea_level) || exit 1
satgs_location_id=$(printf '%s' "$satgs_location_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_location_preview"
satgs-operator --workspace "$satgs_practice_station" cancel --preview "$satgs_location_id"
satgs-operator --workspace "$satgs_practice_station" status
```

Cancelling preserves saved coordinates and generation. It retains a cancellation
artifact, so it is not a promise of zero filesystem writes. Repeating cancel is
idempotent. Applying that cancelled preview must return conflict, exit 3.

## Save and reopen the manual position

Preview the values again. The previous cancelled identity is not reusable.
Review the new proposal, then Save. Through the CLI:

```sh
satgs_location_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json location-preview --latitude-deg 34 --longitude-deg -118 --altitude-m 100 --altitude-reference mean_sea_level) || exit 1
satgs_location_id=$(printf '%s' "$satgs_location_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_location_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_location_id" --confirm
satgs-operator --workspace "$satgs_practice_station" reload
```

After the one component save and this location save, generation is 3 if you have
made no other changes. Status reports manual latitude `34.0`, longitude `-118.0`,
altitude `100.0` and declared reference `mean_sea_level` in JSON. The everyday
view may omit technical identity fields. GPS stays unavailable, installation
unknown and heading/calibration unqualified.

Close the window normally and run the same quoted GUI command from the first
section again, or use Home > Open station... and choose this practice directory.
Reload must retain the manual selection. Opening another workspace in a window
does not retarget the saved daily launcher selection.

## Plan from an explicitly local historical TLE

Create a local CSV with the same explicit historical data used by the bundled
example. The shell redirects only into your new private practice directory. It
does not require the application's Python interpreter, discover an old
installation or fetch a TLE:

```sh
satgs_practice_tle="$satgs_practice_root/NOAA 15 historical.csv"
printf '%s\n' 'norad_id,name,tle,date' '25338,NOAA 15,"NOAA 15,1 25338U 98030A   25135.84934273  .00000229  00000+0  11192-3 0  9996,2 25338  98.5367 161.5741 0011424  74.5549 285.6893 14.26965248404873",2025-05-16 02:51:09 UTC' > "$satgs_practice_tle"
satgs-operator --workspace "$satgs_practice_station" --format json plan --start 2025-05-16T03:00:00Z --norad-id 25338 --span-days 1 --elevation-deg 20 --tle-file "$satgs_practice_tle"
```

The resulting file has this header and one quoted TLE record. If entering it in
a text editor instead, preserve both lines and save it at the exact
`satgs_practice_tle` path. Do not replace a real station's satellite catalog.

```csv
norad_id,name,tle,date
25338,NOAA 15,"NOAA 15,1 25338U 98030A   25135.84934273  .00000229  00000+0  11192-3 0  9996,2 25338  98.5367 161.5741 0011424  74.5549 285.6893 14.26965248404873",2025-05-16 02:51:09 UTC
```

Then run the `plan` line. In the GUI, set Results fields to the same start,
NORAD ID `25338`, span `1`, elevation `20` and full local CSV path, then Calculate.
The expected result has `source: operator_selected_local_tle`,
`refresh_performed: false`, `execution_enabled: false`, and opportunities from
the real orbit calculation. The exact plan ID depends on your workspace identity
and revision. No fixed ID in a document can replace it. Keep the historical date
visible: this exercise does not demonstrate current orbit freshness.

## Compare planning inputs after relocation

In Location change longitude from `-118` to `-117`, leaving latitude `34`,
altitude `100` and reference unchanged. Preview and Save. CLI equivalent:

```sh
satgs_relocation_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json location-preview --latitude-deg 34 --longitude-deg -117 --altitude-m 100 --altitude-reference mean_sea_level) || exit 1
satgs_relocation_id=$(printf '%s' "$satgs_relocation_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_relocation_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_relocation_id" --confirm
satgs-operator --workspace "$satgs_practice_station" --format json status
satgs-operator --workspace "$satgs_practice_station" --format json plan --start 2025-05-16T03:00:00Z --norad-id 25338 --span-days 1 --elevation-deg 20 --tle-file "$satgs_practice_tle"
```

The earlier plan is marked `revalidation_required: true`. The new plan has a
different station revision and longitude. TLE bytes and calculation time/span/
mask are unchanged. Compare those inputs before comparing opportunity times.
This is a relocation of the planning site, not an antenna alignment command.

## Inspect independent observation states

The optional synthetic status exercise is explicit and local:

```sh
satgs-operator --workspace "$satgs_practice_station" replay --state critical
satgs-operator --workspace "$satgs_practice_station" --format json status
```

Home > Reload shows `critical` system health alongside `transport_pass` and
unqualified heading. JSON identifies `synthetic_replay`, fixed fixture time and
`live_hardware_observed: false`. The saved manual position does not change.
`replay --state unknown` restores unknown replay dimensions; it does not undo the
component or location saves.

## Rehearsal and execution scope

The Run form freezes and reviews an input-bound request. For this guide's
practice station, ordinary owner admission remains closed. Use the supplied
controlled acceptance for software rehearsal; a saved request is the endpoint
of the manual review exercise. Keep practice coordinates separate from equipment
bindings.

The release's consolidated acceptance uses disposable stations and controlled
owner/transport boundaries for the changed software checks. It does not initialize
the daily station. Its report identifies which runtime, PTU, GUI and preservation
scenarios actually ran and where their artifacts were retained. This is software
evidence, not a production broker/serial run or physical qualification. The
retained earlier daily-support rehearsal targets its older runtime application;
do not attribute its PASS to this release.

For a started controlled run, Run > Cancel run and `run-cancel --run-id` request
local cancellation. Before starting, `run-status`/`run-cancel` return not_started.
Keep software completion, command submission, manager outcome and physical state
separate. Use the independent [local PTU playbook](operator-tutorial.md#install-and-use-a-local-ptu-instance)
for deliberate manual control.

## Review a run request

After Calculate, choose the desired Plan on Run. Supply Configuration JSON,
Runtime bindings JSON, Owner settings, the matching Local TLE CSV, Duration
(seconds), Opportunity (1-based) and Execution mode. These are exact reviewed
inputs supplied by the deployment/owner, not files the form invents. Duration
must fit the chosen opportunity. Review run freezes them with the saved manual
position/reference and station revision.

Inspect the reviewed request. Start run is a separate confirmation. Changing
station settings or any bound input requires a new request. The CLI grammar in
the [reference](operator-cli-reference.md#runtime-request-review-and-execution)
uses the actual saved plan and returned request identity; no fixed example ID
can replace either. Select the intended execution mode explicitly.

For an admitted controlled run, keep the returned request identity, read its
progress and final result, then use Results > Report and Export... for a station
snapshot. Retain the separate `run-request-...`, `run-...-progress.json` and
`run-...-result.json` files as described in [Results](results.md). Export does
not bundle them. The controlled acceptance's failed/partial scenarios exercise
these distinctions without opening equipment.

## Cancel or recover without losing the result

Run > Cancel run requests local cancellation of a started run. In a synchronous
CLI run, use another terminal with the same workspace and actual request ID for
run-status/run-cancel. An unfinished disk record is not proof of a live process.
Repeated execution of a finished request returns its retained result rather than
silently repeating motion.

On failure, keep request/progress/result and runner logs. Read primary failure,
manager/submission outcome, software completion, physical state and save/cleanup
details together. Physical indeterminate (exit 8) is not success; local
cancellation (exit 130) is not remote Stop. Do not retry uncertain motion merely
because a result save failed. Use the owner recovery procedure.

## Inspect and export results

```sh
satgs-operator --workspace "$satgs_practice_station" report
satgs-operator --workspace "$satgs_practice_station" --format json report
satgs-operator --workspace "$satgs_practice_station" export --output "$satgs_practice_root/practice report.json"
```

Results > Report and Export... are the equivalent GUI actions. Inspect the
position/reference, retained plans, replay provenance and operation results in
the JSON. Export must create a private new file. Repeating the exact export
returns exit 4 and leaves the existing bytes intact. Choose another filename if
you need another snapshot. Keep the practice directory and report; no deletion
or cleanup is part of this tutorial.

## Deliberate negative checks

These checks belong only to this new practice workspace. Invalid latitude `nan`
must return exit 2 without changing saved coordinates. Applying a valid preview
without `--confirm` must return exit 2. Applying a cancelled or stale preview
must return exit 3. A preview made before the relocation becomes stale. Do not
weaken these restrictions to make a script proceed.

The complete argument grammar and outcome meanings are in the
[CLI reference](operator-cli-reference.md). The
[original-workflow comparison](legacy-comparison.md) explains why a local
planning exercise does not replace queued RF tracking or legacy result storage.
