#!/bin/bash

if [ -z "${BASH_VERSION:-}" ]; then
    printf '%s\n' 'Use a Bash terminal: . ./setup_update.sh --accept-trusted-native' >&2
    return 2 2>/dev/null || exit 2
fi
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    printf '%s\n' 'Use: . ./setup_update.sh --accept-trusted-native' >&2
    exit 2
fi
if [ "$#" -ne 1 ] || [ "$1" != '--accept-trusted-native' ]; then
    printf '%s\n' 'Use: . ./setup_update.sh --accept-trusted-native' >&2
    return 2
fi
if declare -F satgs_handbook_setup >/dev/null; then
    printf '%s\n' 'Existing setup function was preserved; setup not run.' >&2
    return 2
fi

satgs_handbook_setup() {
    local satgs_handbook_dir satgs_handbook_status
    satgs_handbook_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || return
    printf '%s\n' 'Setup uses the reviewed CPython/stdlib/native-runtime trust boundary, not syscall isolation.'
    /usr/bin/python3.11 -I -B -S "$satgs_handbook_dir/support/release_update.py" stage --accept-trusted-native
    satgs_handbook_status=$?
    if [ "$satgs_handbook_status" -ne 0 ]; then
        printf '%s\n' 'Setup failed; launcher preparation and selection were not run. Retain the printed reports and candidate.' >&2
        return "$satgs_handbook_status"
    fi
    if [ ! -e "$HOME/.config/satgs/operator.json" ] && [ ! -L "$HOME/.config/satgs/operator.json" ]; then
        printf '%s\n' 'Fresh account: the candidate is staged; no application or station was selected.' \
            'Next: ./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --bootstrap jog4 --initialize-station "$HOME/satgs-station"' \
            'This explicitly creates a new station at that path. Then open SATGS from the menu.'
        return 0
    fi
    . "$satgs_handbook_dir/launchers/setup_daily.sh"
    satgs_handbook_status=$?
    if [ "$satgs_handbook_status" -ne 0 ]; then
        printf '%s\n' 'Launcher preparation failed; the previous selection was retained. Keep the setup reports.' >&2
        return "$satgs_handbook_status"
    fi
    printf '%s\n' 'PTU candidate staged; the existing daily selection was retained. No GUI was opened.' \
        'Next: ./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog4'
}

if satgs_handbook_setup "$@"; then
    unset -f satgs_handbook_setup
    return 0
else
    unset -f satgs_handbook_setup
    return 1
fi
