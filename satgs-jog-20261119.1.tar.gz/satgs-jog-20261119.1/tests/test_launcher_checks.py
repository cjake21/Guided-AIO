import ast
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'support/launcher_checks.py'
checks = types.ModuleType('tested_launcher_checks')
checks.__file__ = str(SOURCE)
exec(compile(SOURCE.read_bytes(), str(SOURCE), 'exec', dont_inherit=True), vars(checks))
TARGET_SOURCE = ROOT / 'support/pi_target.py'
supervisor = types.ModuleType('tested_launcher_supervision')
supervisor.__file__ = str(TARGET_SOURCE)
exec(compile(TARGET_SOURCE.read_bytes(), str(TARGET_SOURCE), 'exec', dont_inherit=True), vars(supervisor))


def output(count=96, ending='OK'):
    return '\n----------------------------------------------------------------------\nRan %d tests in 0.1s\n\n%s\n' % (count, ending)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


class LauncherGateTests(unittest.TestCase):
    def test_current_jog_binding_preserves_distinct_previous_bench_identity(self):
        binding = {name + '_application': '/fixture/' + name
                   for name in ('runtime', 'ui', 'guide', 'handbook', 'ptu', 'bench', 'jog', 'jog2', 'jog3')}
        binding['application'] = '/fixture/jog4'
        identities = checks._identities(binding)
        self.assertEqual(set(identities), {'runtime', 'ui', 'guide', 'handbook', 'ptu', 'bench', 'jog', 'jog2', 'jog3', 'jog4'})
        self.assertEqual(identities['bench'], dict(application='/fixture/bench', candidate_version='0.0.1+bench.20261118.1'))
        self.assertEqual(identities['jog'], dict(application='/fixture/jog', candidate_version='0.0.1+jog.20261118.1'))
        self.assertEqual(identities['jog2'], dict(application='/fixture/jog2', candidate_version='0.0.1+jog.20261118.2'))
        self.assertEqual(identities['jog3'], dict(application='/fixture/jog3', candidate_version='0.0.1+jog.20261118.3'))
        self.assertEqual(identities['jog4'], dict(application='/fixture/jog4', candidate_version='0.0.1+jog.20261119.1'))
        self.assertEqual(checks._managed(Path('/fixture/home'))[0],
                         Path('/fixture/home/.local/share/satgs-launchers/profile-install-20261118/daily.py'))
        tree = ast.parse((ROOT / 'support/docs_checks.py').read_bytes())
        examples = next(node for node in tree.body
                        if isinstance(node, ast.FunctionDef) and node.name == 'run_examples')
        dispatchers = [node.value for node in ast.walk(examples) if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'dispatcher'
                               for target in node.targets)]
        self.assertEqual(len(dispatchers), 1)
        self.assertEqual(ast.dump(dispatchers[0]),
                         ast.dump(ast.parse('launcher_checks._managed(home)[0]', mode='eval').body))

    def test_complete_reviewed_suite_accepted(self):
        self.assertIsNone(checks._fixture_failure(output(), True))

    def test_wrong_missing_or_ambiguous_count_rejected(self):
        for text in [output(count) for count in (0, 61, 66, 73, 74, 75, 79, 85, 86, 87, 91, 93)] + [
                '', 'OK\n', output() + output(), output().replace('96 tests', 'unknown tests')]:
            with self.subTest(text=text):
                reason = checks._fixture_failure(text, True)
                self.assertIn('expected 96; observed', reason)

    def test_skipped_failed_or_incomplete_completion_rejected(self):
        for ending in ('OK (skipped=1)', 'OK (expected failures=1)', 'FAILED (failures=1)',
                       'FAILED (errors=1)', 'FAILED (unexpected successes=1)', '', 'NOT OK'):
            with self.subTest(ending=ending):
                self.assertIn('skipped, incomplete or unsuccessful',
                              checks._fixture_failure(output(ending=ending), True))

    def test_unsuccessful_supervision_rejected(self):
        good = dict(exit=0, quiescent=True)
        self.assertIsNone(checks._fixture_failure(output(), supervisor.supervision_passed(good)))
        for change in (dict(exit=1), dict(quiescent=False), dict(timeout=True),
                       dict(output_limit=True), dict(exception='fixture failure'),
                       dict(residual_descendants=[123]), dict(cleanup_errors=['fixture failure'])):
            with self.subTest(change=change):
                self.assertEqual(checks._fixture_failure(
                    output(), supervisor.supervision_passed(dict(good, **change))),
                    'Launcher stdlib fixture tests failed.')

    def test_inventory_matches_source_and_unittest_discovery(self):
        actual = {}
        for path in sorted((ROOT / 'tests').glob('test_*.py')):
            tree = ast.parse(path.read_bytes(), filename=str(path))
            names = [(node.name, method.name) for node in tree.body if isinstance(node, ast.ClassDef)
                     for method in node.body if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef))
                     and method.name.startswith('test_')]
            self.assertEqual(len(names), len(set(names)))
            actual[path.name] = len(names)
        self.assertEqual(actual, checks.FIXTURE_COUNTS)
        self.assertEqual(sum(actual.values()), 96)
        pending = [unittest.TestLoader().discover(str(ROOT / 'tests'), pattern='test_*.py')]
        discovered, identities = {}, []
        while pending:
            item = pending.pop()
            if isinstance(item, unittest.TestSuite):
                pending.extend(item)
            else:
                name = type(item).__module__ + '.py'
                discovered[name] = discovered.get(name, 0) + 1
                identities.append(item.id())
        self.assertEqual(len(identities), len(set(identities)))
        self.assertEqual(discovered, checks.FIXTURE_COUNTS)

    def run_fixture(self, text, supervised=True):
        temporary = tempfile.TemporaryDirectory(prefix='satgs-launcher-gate-')
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        scratch, attempt = root / 'scratch', root / 'attempt'
        scratch.mkdir()
        attempt.mkdir()
        binding = dict(interpreter='/fixture/python', launcher_source=str(ROOT / 'launchers'))
        calls = []

        def supervise(command, destination, **kwargs):
            calls.append((command, destination, kwargs))
            destination.mkdir()
            if destination.name == 'unit':
                (destination / 'stderr').write_text(text)
            else:
                count = 3 if destination.name == 'preparation' else 1
                row = dict(status='PASS', runtime_denials=[], negative_controls=42,
                           launcher_checks=dict(actual_installed_cli_calls=[{} for _ in range(count)]))
                (destination / 'stdout').write_text('OPERATOR_LANE_RESULT ' + json.dumps(row) + '\n')
            return dict(exit=0 if supervised else 1, quiescent=True)

        def prepare(*args):
            (scratch / 'launcher-preparation.json').write_text('{}\n')
            return dict(generated={})

        target = types.SimpleNamespace(ENV={}, supervise=supervise,
                                       supervision_passed=supervisor.supervision_passed)
        recording = types.SimpleNamespace(read=lambda path: path.read_bytes(), require=require)
        with mock.patch.object(checks, 'prepare', side_effect=prepare) as preparation:
            result = checks.run(binding, scratch, attempt, target, recording)
        return result, calls, preparation

    def test_run_rejects_old_inventory_before_effects(self):
        result, calls, preparation = self.run_fixture(output(66))
        self.assertEqual(result['status'], 'FAIL')
        self.assertEqual(result['child_exit'], 0)
        self.assertIn('expected 96; observed 66', result['reason'])
        self.assertEqual(result['result']['actual_cli_calls'], 0)
        self.assertEqual(len(calls), 1)
        preparation.assert_not_called()

    def test_run_rejects_unsuccessful_child_before_effects(self):
        result, calls, preparation = self.run_fixture(output(), supervised=False)
        self.assertEqual(result['status'], 'FAIL')
        self.assertEqual(result['child_exit'], 1)
        self.assertEqual(len(calls), 1)
        preparation.assert_not_called()

    def test_run_accepts_complete_suite_and_checks_both_guarded_cli_results(self):
        result, calls, preparation = self.run_fixture(output())
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['result']['unit_tests'], 96)
        self.assertEqual(result['result']['unit_fixture_counts'], checks.FIXTURE_COUNTS)
        self.assertEqual(result['result']['actual_cli_calls'], 4)
        self.assertEqual(len(result['additional_supervision']), 2)
        self.assertEqual([row[1].name for row in calls], ['unit', 'preparation', 'other-cwd'])
        self.assertNotEqual(calls[1][2]['cwd'], calls[2][2]['cwd'])
        self.assertNotIn('--launcher-followup', calls[1][0])
        self.assertIn('--launcher-followup', calls[2][0])
        preparation.assert_called_once()


if __name__ == '__main__':
    unittest.main()
