"""Native operator views over the shared managed-workspace operations.

Importing this module does not import Tk or open a display.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from pathlib import Path
import threading
import time
from typing import Any

from satgs._operator_contract import OperatorError
from satgs.operator_presentation import (
    display_document_text, display_message, gps_document, human_text, station_name,
)


def _number_input(value, parser=float):
    return parser(value) if type(value) is str else value


def display_unavailable(error):
    message = str(error).lower()
    return message == "no display name and no $display environment variable" or message.startswith((
        "couldn't connect to display ", "could not connect to display ", "cannot open display ",
    ))


class OperatorPresenter:
    """Thin input/output adapter, also usable without a display."""

    def __init__(self, workspace=None):
        self.workspace = workspace
        self.status: dict[str, Any] = {}
        self.catalog: dict[str, Any] = {}
        self.preview: dict[str, Any] | None = None
        self.result: dict[str, Any] | None = None
        self.revision: str | None = None
        self.run_preview = None
        self.runtime_result = None
        self._runtime_thread = None
        self._runtime_cancel = threading.Event()
        self._runtime_lock = threading.Lock()
        self._runtime_observation = None
        self._runtime_request_id = None
        self._bench_session = None
        self._bench_thread = None
        self._bench_stop_thread = None
        self._bench_close_thread = None
        self._bench_lock = threading.Lock()
        self._bench_records = []
        self._bench_preview_ready = False
        self._bench_preview_generation = 0
        self._bench_closing = False
        self._bench_cleanup_error = None
        self.bench_saved = None
        self.bench_saved_error = None

    def dispatch(self, action: str, **values) -> dict[str, Any]:
        from satgs.operator_core import OperatorError, Workspace, initialize_workspace

        try:
            if action in ("open_workspace", "create_scratch") and (self.runtime_active or self.bench_open):
                return self._failure(action, "active_work", "Wait for the active run to finish.")
            if action.startswith("bench_"):
                return self.start_bench(action[6:], **values)
            if action == "create_scratch":
                self.workspace = initialize_workspace(Path(values["root"]))
                self.preview = None
                self._clear_runtime()
                value = self._refresh()
            elif action == "open_workspace":
                workspace = Workspace(Path(values["root"]))
                status, catalog = workspace.inspect(), workspace.catalog()
                self.workspace, self.status, self.catalog = workspace, status, catalog
                self.revision, self.preview = status["station_revision"], None
                self._clear_runtime()
                self._load_bench_configuration()
                value = status
            elif self.workspace is None:
                return self._failure(action, "workspace_required", "Open or create a workspace.")
            elif action == "refresh":
                value = self._refresh()
            elif action == "preview_location":
                self.preview = None
                value = self.workspace.preview_location(
                    latitude_deg=_number_input(values["latitude_deg"]),
                    longitude_deg=_number_input(values["longitude_deg"]),
                    altitude_m=_number_input(values["altitude_m"]),
                    altitude_reference=values["altitude_reference"],
                    expected_revision=self.revision,
                )
                self.preview = value
            elif action == "preview_components":
                self.preview = None
                value = self.workspace.preview_components(
                    values["profile"], changes=values.get("changes"),
                    ptu_model=values.get("ptu_model", "QPT130"),
                    expected_revision=self.revision,
                )
                self.preview = value
            elif action in ("apply", "cancel"):
                if self.preview is None:
                    return self._failure(action, "preview_required", "Preview a change first.")
                preview_id = self.preview["preview_id"]
                value = getattr(self.workspace, action)(preview_id)
                self.preview = None
                return self._completed_with_reload(action, value)
            elif action == "report":
                value = self.workspace.report()
            elif action == "export_report":
                value = self.workspace.export_report(Path(values["output"]))
            elif action == "plan":
                from satgs.operator_planning import plan_workspace

                value = plan_workspace(
                    self.workspace, start_time=values["start_time"],
                    norad_id=_number_input(values.get("norad_id", 25338), int),
                    span_days=_number_input(values.get("span_days", 1)),
                    elevation_deg=_number_input(values.get("elevation_deg", 20)),
                    tle_file=values.get("tle_file") or None,
                )
                return self._completed_with_reload(action, value)
            elif action == "run_preview":
                self.run_preview = self.workspace.preview_run(**values)
                value = self.run_preview
            elif action == "run_start":
                if self.runtime_active or self.bench_open:
                    return self._failure(action, "active_work", "Wait for the active work to finish.")
                request_id = values.get("request_id")
                if values.get("confirm") is not True or self.run_preview is None or request_id != self.run_preview["request_id"]:
                    return self._failure(action, "preview_required", "Review the selected run before starting.")
                self._runtime_cancel = threading.Event()
                self._runtime_request_id = request_id
                workspace = self.workspace
                self._runtime_observation = {"request_id": request_id, "state": "starting", "finished": False}
                def update(record):
                    with self._runtime_lock:
                        self._runtime_observation = record
                def run():
                    try:
                        update(workspace.execute_run(request_id, confirm=True,
                            cancel=self._runtime_cancel, progress=update))
                    except OperatorError as error:
                        update({"request_id": request_id, "finished": True, "state": "failed",
                            "exit_code": error.exit_code, "error": {"code": error.code, "message": str(error)},
                            "physical_state": "unobserved"})
                    except Exception:
                        update({"request_id": request_id, "finished": True, "state": "failed", "exit_code": 5,
                            "physical_state": "indeterminate", "error": {"code": "execution-failure",
                            "message": "Run failed. Inspect its retained result."}})
                self._runtime_thread = threading.Thread(target=run, name="operator-runtime", daemon=False)
                self._runtime_thread.start()
                value = dict(self._runtime_observation)
            elif action == "run_status":
                with self._runtime_lock:
                    value = dict(self._runtime_observation) if self._runtime_observation and values.get("request_id") == self._runtime_request_id else None
                if value is not None:
                    value["liveness"] = "local_worker_active" if self.runtime_active else "local_worker_finished"
                if value is None:
                    value = self.workspace.run_status(values["request_id"])
            elif action == "run_cancel":
                identity = values.get("request_id", self._runtime_request_id)
                value = self.workspace.cancel_run(identity)
                if identity == self._runtime_request_id:
                    self._runtime_cancel.set()
            else:
                return self._failure(action, "unknown_action", "Unsupported action.")
            outcome = self._outcome(action, value)
            self.result = outcome
            if action == "run_start":
                self.runtime_result = outcome
        except OperatorError as exc:
            outcome = {"ok": False, "status": "FAIL", "action": action,
                       "error": {"code": exc.code, "message": str(exc)}}
            self.result = outcome
        except (ValueError, TypeError, OverflowError):
            return self._failure(action, "invalid_input", "Check the numbers, units and altitude reference.")
        except OSError:
            return self._failure(action, "storage_error", "Cannot complete the operation. Check the workspace and available storage.")
        return outcome

    @property
    def runtime_active(self):
        return self._runtime_thread is not None and self._runtime_thread.is_alive()

    def cancel_active(self):
        self._runtime_cancel.set()

    def poll_runtime(self):
        if self._runtime_request_id is None:
            return None
        foreground = self.result
        try:
            self.runtime_result = self.dispatch("run_status", request_id=self._runtime_request_id)
        finally:
            if foreground is not None:
                value = foreground.get("result")
                if (foreground["action"] not in ("run_start", "run_status", "run_cancel")
                        or type(value) is not dict or value.get("request_id") != self._runtime_request_id):
                    self.result = foreground
        return self.runtime_result

    @property
    def bench_active(self):
        workers = any(worker is not None and worker.is_alive() for worker in
                      (self._bench_thread, self._bench_stop_thread, self._bench_close_thread))
        session = self._bench_session
        return workers or session is not None and session.readback_snapshot()["jog"]["token"] is not None

    @property
    def bench_open(self):
        return self._bench_session is not None or self.bench_active

    def invalidate_bench_preview(self):
        with self._bench_lock:
            self._bench_preview_generation += 1
            self._bench_preview_ready = False

    def bench_snapshot(self):
        with self._bench_lock:
            session = self._bench_session
            return {"active": self.bench_active, "connected": self._bench_session is not None,
                    "preview_ready": self._bench_preview_ready, "closing": self._bench_closing,
                    "cleanup_error": self._bench_cleanup_error, "results": deepcopy(self._bench_records),
                    "readback": session.readback_snapshot() if session is not None else None}

    def disarm_bench_manual(self):
        session = self._bench_session
        if session is not None:
            session.disarm_manual()

    def poll_bench(self):
        session = self._bench_session
        self.collect_bench_results()
        if (session is not None and not self.bench_active and not self._bench_closing
                and not session._closed and self._bench_cleanup_error is None
                and not self.runtime_active and session.readback_snapshot()["poll_due"]):
            return self.start_bench("status", automatic=True)
        return None

    def collect_bench_results(self):
        session = self._bench_session
        if session is not None:
            for record in session.drain_jog_results():
                self._record_bench(record)

    def _record_bench(self, record):
        with self._bench_lock:
            identity = record.get("attempt_id")
            if identity is not None:
                for index, previous in enumerate(self._bench_records):
                    if previous.get("attempt_id") == identity:
                        self._bench_records[index] = record
                        return
            self._bench_records.append(record)
            self._bench_records = self._bench_records[-20:]

    def start_bench(self, operation, **values):
        from satgs.operator_core import OperatorError

        action = "bench_" + operation
        if operation not in ("connect", "status", "preview", "move", "stop", "disconnect", "manual", "step",
                             "setup_local", "jog_start", "jog_renew", "jog_end"):
            return self._failure(action, "unknown_action", "Unsupported PTU operation.")
        if self.workspace is None:
            return self._failure(action, "workspace_required", "Open or create a workspace.")
        session = self._bench_session
        if operation in ("jog_renew", "jog_end"):
            accepted = session is not None and getattr(session, "renew_jog" if operation == "jog_renew" else
                                                      "end_jog")(values.get("jog_token"))
            return self._outcome(action, {"accepted": accepted})
        if self._bench_closing or self.runtime_active:
            return self._failure(action, "active_work", "Wait for the active work to finish.")
        if operation == "setup_local":
            if self.bench_open:
                return self._failure(action, "active_work", "Disconnect the PTU before changing its saved connection.")
            from satgs.operator_bench import save_local_bench
            configuration = values.get("configuration_file")
            path = Path(configuration) if configuration is not None and str(configuration).strip() else None
            return self._completed_with_reload(action, save_local_bench(self.workspace, path))
        slot = "_bench_stop_thread" if operation == "stop" else "_bench_thread"
        worker = getattr(self, slot)
        stopping = self._bench_stop_thread
        if (worker is not None and worker.is_alive()
                or operation != "stop" and stopping is not None and stopping.is_alive()):
            return self._failure(action, "active_work", "A PTU operation is already active.")
        if operation == "connect" and session is not None:
            return self._failure(action, "conflict", "Disconnect the current PTU session first.")
        if operation != "connect" and session is None:
            return self._failure(action, "not_connected", "Connect the selected PTU first.")
        if session is not None and session.query_only and operation not in ("status", "disconnect"):
            return self._failure(action, "unsupported", "Query-only sessions allow Status and Disconnect.")
        if operation == "jog_start":
            self.invalidate_bench_preview()
            record = session.start_jog(values.get("direction"))
            if record.get("category") != "ok":
                return self._failure(action, record.get("category", "rejected"),
                                     record.get("message", "Local PTU hold was not accepted."))
            return {"ok": True, "status": "RUNNING", "action": action, "result": record}
        if session is not None and session.readback_snapshot()["jog"]["token"] is not None and operation not in (
                "stop", "disconnect"):
            return self._failure(action, "active_work", "Release the PTU direction control and wait for Stop.")
        if operation == "move" and not self._bench_preview_ready:
            return self._failure(action, "preview_required", "Preview the target before Move.")
        if operation in ("preview", "move", "stop", "disconnect", "step", "manual"):
            self.invalidate_bench_preview()
        if operation in ("preview", "move", "stop", "disconnect"):
            self.disarm_bench_manual()
        generation = self._bench_preview_generation
        workspace = self.workspace
        configuration = values.get("configuration_file")
        if configuration is not None and not str(configuration).strip():
            configuration = None
        target = {key: _number_input(values[key]) for key in ("pan", "tilt")} if operation == "preview" else {}
        if operation == "manual":
            target = {"step_degrees": _number_input(values.get("step_degrees")),
                      "manual_generation": session.readback_snapshot()["manual_generation"]}
        elif operation == "step":
            target = {"direction": values.get("direction")}
        automatic = values.get("automatic") is True

        def run():
            current = session
            try:
                if operation == "connect":
                    from satgs.operator_bench import BenchSession
                    current = BenchSession(workspace, Path(configuration) if configuration is not None else None)
                    self._bench_session = current
                    if self._bench_closing:
                        current.cancel.set()
                        raise OperatorError("Local PTU connection cancelled.", "cancelled", 130)
                    record = current.connect()
                    self._load_bench_configuration()
                else:
                    record = current.perform(operation, persist=not automatic, **target)
                with self._bench_lock:
                    if operation == "preview" and generation == self._bench_preview_generation:
                        self._bench_preview_ready = record.get("category") == "ok" and not record.get("partial", False)
                if operation == "disconnect":
                    for item in current.drain_jog_results():
                        self._record_bench(item)
                    if current.released:
                        self._bench_session = None
                        self._bench_cleanup_error = None
                    else:
                        self._bench_cleanup_error = "PTU passive cleanup is incomplete. Inspect the retained session."
                elif operation == "connect" and record.get("category") != "ok":
                    current.close()
                    self._bench_session = None
                if not automatic:
                    self._record_bench(record)
            except OperatorError as error:
                if operation == "disconnect":
                    self._bench_cleanup_error = "PTU passive cleanup is incomplete. Inspect the retained session."
                if operation == "connect" and current is not None:
                    try:
                        current.close()
                        self._bench_session = None
                    except Exception:
                        self._bench_cleanup_error = "PTU passive cleanup is incomplete. Inspect the retained session."
                self._record_bench({"operation": operation, "category": error.code,
                    "message": str(error), "physical_state": "indeterminate"})
            except Exception:
                if operation == "disconnect":
                    self._bench_cleanup_error = "PTU passive cleanup is incomplete. Inspect the retained session."
                if operation == "connect" and current is not None:
                    try:
                        current.close()
                        self._bench_session = None
                    except Exception:
                        self._bench_cleanup_error = "PTU passive cleanup is incomplete. Inspect the retained session."
                self._record_bench({"operation": operation, "category": "exchange_failed",
                    "message": "PTU operation failed. Inspect its saved result.", "physical_state": "indeterminate"})

        worker = threading.Thread(target=run, name="operator-ptu-" + operation, daemon=False)
        setattr(self, slot, worker)
        worker.start()
        return {"ok": True, "status": "RUNNING", "action": action,
                "result": {"operation": operation, "state": "requested"}}

    def close_bench(self):
        if self._bench_closing or not self.bench_open:
            return
        self._bench_closing = True
        self.disarm_bench_manual()
        self.invalidate_bench_preview()
        session = self._bench_session
        if session is not None:
            session.cancel.set()
        workers = (self._bench_thread, self._bench_stop_thread)

        def close():
            try:
                deadline = time.monotonic() + (session._context["exchange_timeout_seconds"] if session else 30)
                for worker in workers:
                    if worker is not None:
                        worker.join(max(0, deadline - time.monotonic()))
                        if worker.is_alive():
                            raise RuntimeError("PTU operation has not released")
                current = self._bench_session
                if current is not None:
                    current.cancel.set()
                    current.close()
                    for record in current.drain_jog_results():
                        self._record_bench(record)
                self._bench_session = None
                self._bench_cleanup_error = None
            except Exception:
                self._bench_cleanup_error = "PTU passive cleanup is incomplete. Inspect the retained session."
            finally:
                self._bench_closing = False

        self._bench_close_thread = threading.Thread(target=close, name="operator-ptu-close", daemon=False)
        self._bench_close_thread.start()

    def _clear_runtime(self):
        self.run_preview = None
        self.runtime_result = None
        self._runtime_request_id = None
        with self._runtime_lock:
            self._runtime_observation = None

    def _refresh(self) -> dict[str, Any]:
        self.status = self.workspace.inspect()
        self.revision = self.status["station_revision"]
        self.catalog = self.workspace.catalog()
        self._load_bench_configuration()
        return self.status

    def _load_bench_configuration(self):
        from satgs.operator_bench import saved_bench_configuration
        try:
            self.bench_saved = saved_bench_configuration(self.workspace)
            self.bench_saved_error = None
        except (OperatorError, OSError, ImportError) as error:
            self.bench_saved = None
            self.bench_saved_error = display_message(str(error))

    def _failure(self, action: str, code: str, message: str) -> dict[str, Any]:
        outcome = {"ok": False, "status": "FAIL", "action": action,
                   "error": {"code": code, "message": message}}
        self.result = outcome
        return outcome

    @staticmethod
    def _outcome(action, value):
        partial = type(value) is dict and value.get("partial") is True
        code = value.get("exit_code", 0) if type(value) is dict else 0
        outcome = {"ok": not partial and code in (0, 8), "status": "FAIL" if partial or code not in (0, 8) else
                   "INDETERMINATE" if code == 8 else "PASS",
                   "action": action, "result": value}
        if code not in (0, 8):
            outcome["error"] = value.get("error", {"code": value.get("primary", "execution-failure"),
                "message": "Run did not complete. Inspect the saved result."})
        if partial:
            outcome["error"] = {"code": "partial_result", "message":
                "Operation incomplete. Check the recorded save and receipt results."}
        return outcome

    def _completed_with_reload(self, action, value):
        from satgs.operator_core import OperatorError

        outcome = self._outcome(action, value)
        try:
            self._refresh()
        except (OperatorError, OSError):
            outcome["inspection_error"] = "Status reload failed. The recorded operation result is unchanged."
            outcome.update(ok=False, status="FAIL")
            outcome.setdefault("error", {"code": "inspection_incomplete", "message": outcome["inspection_error"]})
        self.result = outcome
        return outcome


class OperatorWindow:
    """The Tk modules are supplied only after an explicit graphical launch."""

    def __init__(self, root, presenter: OperatorPresenter, *, tk, ttk, filedialog):
        self.root = root
        self.presenter = presenter
        self.tk, self.ttk, self.filedialog = tk, ttk, filedialog
        self.widgets: dict[str, Any] = {}
        self.component_controls: dict[str, tuple[Any, Any, Any]] = {}
        self._component_configuration = None
        self._location_revision = None
        self._location_loaded = None
        self._profile_loaded = None
        self._workspace_loaded = None
        self._task_thread = None
        self._task_result = None
        self._task_lock = threading.Lock()
        self._task_disabled = {}
        self._docs_thread = None
        self._docs_result = None
        self._docs_lock = threading.Lock()
        self._guide_window = None
        self._bench_pressed = set()
        self._bench_blocked_keys = set()
        self._bench_releases = {}
        self._bench_hold = None
        self._bench_hold_timer = None
        self._bench_displayed_attempt = None
        self.root.title("SATGS")
        self.root.minsize(700, 460)
        width = min(1040, max(700, root.winfo_screenwidth() - 60))
        height = min(800, max(460, root.winfo_screenheight() - 60))
        self.root.geometry(f"{width}x{height}")
        self.menu = tk.Menu(root, tearoff=False)
        self.help_menu = tk.Menu(self.menu, tearoff=False)
        self.help_menu.add_command(label="User Guide", underline=0, command=self._open_user_guide)
        self.menu.add_cascade(label="Help", underline=0, menu=self.help_menu)
        root.configure(menu=self.menu)
        self._style()
        self.shell = ttk.Frame(root, padding=12)
        self.shell.grid(sticky="nsew")
        root.rowconfigure(0, weight=1)
        root.columnconfigure(0, weight=1)
        self.shell.columnconfigure(0, weight=1)
        self.shell.rowconfigure(3, weight=1)
        self.station = tk.StringVar(value="Station")
        ttk.Label(self.shell, textvariable=self.station, style="Heading.TLabel").grid(row=1, column=0, sticky="w", pady=(0, 8))
        self.identity = tk.StringVar(value="")
        self.notebook = ttk.Notebook(self.shell, takefocus=True)
        self.notebook.grid(row=3, column=0, sticky="nsew")
        self.notebook.enable_traversal()
        self.pages = {}
        for name, underline in (("Home", 0), ("Setup", 0), ("Location", 0),
                                ("Review", 1), ("Results", 5), ("Run", 0), ("PTU", 0)):
            page = ttk.Frame(self.notebook, padding=12)
            page.columnconfigure(0, weight=1)
            self.notebook.add(page, text=name, underline=underline)
            self.pages[name] = page
        self._build_home()
        self._build_setup()
        self._build_location()
        self._build_review()
        self._build_results()
        self._build_bench()
        self.notebook.bind("<<NotebookTabChanged>>", self._bench_focus_changed, add="+")
        self.root.bind("<FocusOut>", self._bench_focus_changed, add="+")
        self.root.bind("<Unmap>", self._bench_unmapped, add="+")
        self.root.bind("<ButtonRelease-1>", self._bench_pointer_released_elsewhere, add="+")
        for key in ("Left", "Right", "Up", "Down", "space", "Return"):
            self.root.bind("<KeyRelease-" + key + ">", self._bench_key_released_elsewhere, add="+")
        self.message = tk.StringVar(value="")
        footer = ttk.Frame(self.shell)
        footer.grid(row=4, column=0, sticky="ew", pady=(12, 0))
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, textvariable=self.message, wraplength=820).grid(row=0, column=0, sticky="ew")
        self._button(footer, "bench_stop", "Stop", lambda: self._bench_action("stop"), row=0, column=1, padx=(12, 0))
        self.root.bind("<Control-r>", lambda event: self.perform("refresh"))
        self.root.bind("<Escape>", self._escape)
        self.root.bind("<Configure>", self._resize_labels, add="+")
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self._closing = False
        self._window_closed = False
        self._timers = {}
        if presenter.workspace is not None:
            self.perform("refresh", show_result=False)
        else:
            self._render()

    def _style(self):
        style = self.ttk.Style(self.root)
        style.configure("Heading.TLabel", font="TkHeadingFont")
        style.configure("TButton", padding=(8, 5))
        self._surface = style.lookup("TFrame", "background") or self.root.cget("background")

    def _heading(self, parent, text, row=0):
        self.ttk.Label(parent, text=text, style="Heading.TLabel", wraplength=680).grid(row=row, column=0, sticky="w", pady=(0, 8))

    def _resize_labels(self, event):
        if event.widget != self.root:
            return
        width = max(280, self.root.winfo_width() - 80)
        pending = [self.shell]
        while pending:
            widget = pending.pop()
            pending.extend(widget.winfo_children())
            if widget.winfo_class() == "TLabel":
                wraplength = widget.cget("wraplength")
                if wraplength not in ("", None) and widget.winfo_pixels(wraplength) > 0:
                    widget.configure(wraplength=width)

    def _button(self, parent, name, text, command, **grid):
        button = self.ttk.Button(parent, text=text, command=command, takefocus=True)
        button.grid(**grid)
        self.widgets[name] = button
        return button

    def _text(self, parent, name, *, height=10, row=0):
        frame = self.ttk.Frame(parent)
        frame.grid(row=row, column=0, sticky="nsew", pady=(4, 8))
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        text = self.tk.Text(frame, wrap="word", height=height, state="disabled", takefocus=True,
                            relief="solid", borderwidth=1, font="TkDefaultFont", padx=8, pady=8)
        scroll = self.ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.widgets[name] = text
        return text

    def _set_text(self, name, value, *, structured=False):
        widget = self.widgets[name]
        rendered = display_message(value) if isinstance(value, str) else human_text(value)
        if widget.get("1.0", "end-1c") == rendered:
            return
        yview, xview = widget.yview(), widget.xview()
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", rendered)
        widget.configure(state="disabled")
        if yview:
            widget.yview_moveto(yview[0])
        if xview:
            widget.xview_moveto(xview[0])

    def _build_home(self):
        page = self.pages["Home"]
        self._heading(page, "Status")
        actions = self.ttk.Frame(page)
        actions.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        self._button(actions, "open_workspace", "Open station...", self._open_workspace, row=0, column=0, padx=(0, 8))
        self._button(actions, "create_scratch", "New station...", self._create_scratch, row=0, column=1, padx=(0, 8))
        self._button(actions, "refresh", "Reload (Ctrl+R)", lambda: self.perform("refresh"), row=0, column=2)
        tree = self.ttk.Treeview(page, columns=("dimension", "evidence"), show="headings", height=11, takefocus=True)
        tree.heading("dimension", text="Status")
        tree.heading("evidence", text="Value")
        tree.column("dimension", width=180, stretch=False)
        tree.column("evidence", width=650)
        tree.grid(row=2, column=0, sticky="nsew", pady=(0, 10))
        scroll = self.ttk.Scrollbar(page, orient="vertical", command=tree.yview)
        scroll.grid(row=2, column=1, sticky="ns", pady=(0, 10))
        tree.configure(yscrollcommand=scroll.set)
        self.widgets["status_dimensions"] = tree
        self._text(page, "status_detail", height=9, row=3)
        page.rowconfigure(2, weight=2)
        page.rowconfigure(3, weight=1)

    def _build_setup(self):
        page = self.pages["Setup"]
        self._heading(page, "Configuration")
        form = self.ttk.Frame(page)
        form.grid(row=1, column=0, sticky="ew")
        self.profile = self.tk.StringVar(value="guided_arrow")
        self.ptu_model = self.tk.StringVar(value="QPT130")
        self.ttk.Label(form, text="Profile").grid(row=0, column=0, sticky="w", padx=(0, 8))
        profile = self.ttk.Combobox(form, textvariable=self.profile, state="readonly",
                                    values=("full_msel", "guided_arrow", "custom"), takefocus=True, width=22)
        profile.grid(row=0, column=1, sticky="w", padx=(0, 24))
        self.widgets["profile"] = profile
        self.ttk.Label(form, text="PTU model").grid(row=0, column=2, sticky="w", padx=(0, 8))
        model = self.ttk.Combobox(form, textvariable=self.ptu_model, state="readonly", values=("QPT130",), takefocus=True, width=12)
        model.grid(row=0, column=3, sticky="w")
        self.widgets["ptu_model"] = model
        container = self.ttk.Frame(page)
        container.grid(row=3, column=0, sticky="nsew")
        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)
        self.component_canvas = self.tk.Canvas(container, highlightthickness=0, background=self._surface, takefocus=False)
        scroll = self.ttk.Scrollbar(container, orient="vertical", command=self.component_canvas.yview)
        self.component_canvas.configure(yscrollcommand=scroll.set)
        self.component_canvas.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.component_frame = self.ttk.Frame(self.component_canvas)
        self.component_window = self.component_canvas.create_window((0, 0), window=self.component_frame, anchor="nw")
        self.component_frame.bind("<Configure>", lambda event: self.component_canvas.configure(scrollregion=self.component_canvas.bbox("all")))
        self.component_canvas.bind("<Configure>", lambda event: self.component_canvas.itemconfigure(self.component_window, width=event.width))
        self._button(page, "preview_components", "Preview", self._preview_components,
                     row=4, column=0, sticky="w", pady=(12, 0))
        page.rowconfigure(3, weight=1)

    def _build_location(self):
        from satgs.operator_core import ALTITUDE_REFERENCES

        page = self.pages["Location"]
        self._heading(page, "Location")
        form = self.ttk.Frame(page)
        form.grid(row=1, column=0, sticky="ew")
        self.location_vars = {}
        for row, (key, label) in enumerate((("latitude_deg", "Latitude (decimal degrees, north +)"),
                                             ("longitude_deg", "Longitude (decimal degrees, east +)"),
                                             ("altitude_m", "Altitude (metres)"))):
            self.ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", padx=(0, 20), pady=5)
            variable = self.tk.StringVar()
            entry = self.ttk.Entry(form, textvariable=variable, width=25, takefocus=True)
            entry.grid(row=row, column=1, sticky="w", pady=5)
            self.location_vars[key] = variable
            self.widgets[key] = entry
        self.altitude_reference = self.tk.StringVar(value="unspecified")
        self.ttk.Label(form, text="Altitude reference").grid(row=3, column=0, sticky="w", padx=(0, 20), pady=5)
        reference = self.ttk.Combobox(form, textvariable=self.altitude_reference, state="readonly",
                                      values=ALTITUDE_REFERENCES, width=23, takefocus=True)
        reference.grid(row=3, column=1, sticky="w", pady=5)
        self.widgets["altitude_reference"] = reference
        self._button(page, "preview_location", "Preview", self._preview_location,
                     row=2, column=0, sticky="w", pady=(8, 0))
        gps = self.ttk.LabelFrame(page, text="GPS", padding=10)
        gps.grid(row=3, column=0, sticky="nsew", pady=(16, 0))
        gps.columnconfigure(0, weight=1)
        gps.rowconfigure(1, weight=1)
        self._button(gps, "use_gps", "Use GPS", lambda: None,
                     row=0, column=0, sticky="w")
        self.widgets["use_gps"].state(["disabled"])
        self._text(gps, "gps_detail", height=9, row=1)
        page.rowconfigure(3, weight=1)

    def _build_review(self):
        page = self.pages["Review"]
        self._heading(page, "Review")
        self._text(page, "review_detail", height=18, row=2)
        page.rowconfigure(2, weight=1)
        actions = self.ttk.Frame(page)
        actions.grid(row=3, column=0, sticky="w")
        self._button(actions, "apply", "Save", lambda: self.perform("apply"), row=0, column=0, padx=(0, 10))
        self._button(actions, "cancel", "Cancel (Esc)", lambda: self.perform("cancel"), row=0, column=1)

    def _build_results(self):
        page = self.pages["Results"]
        self._heading(page, "Results")
        form = self.ttk.Frame(page)
        form.grid(row=1, column=0, sticky="ew")
        self.plan_vars = {}
        fields = (("start_time", "Start (UTC ISO 8601)", "2025-05-16T03:00:00Z"), ("norad_id", "NORAD ID", "25338"),
                  ("span_days", "Span (days)", "1"), ("elevation_deg", "Minimum elevation (deg)", "20"),
                  ("tle_file", "Local TLE CSV", ""))
        for row, (key, label, default) in enumerate(fields):
            self.ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", padx=(0, 16), pady=3)
            variable = self.tk.StringVar(value=default)
            self.plan_vars[key] = variable
            entry = self.ttk.Entry(form, textvariable=variable, width=32, takefocus=True)
            entry.grid(row=row, column=1, sticky="w", pady=3)
            self.widgets[key] = entry
        actions = self.ttk.Frame(page)
        actions.grid(row=2, column=0, sticky="w", pady=10)
        self._button(actions, "plan", "Calculate", self._plan, row=0, column=0, padx=(0, 8))
        self._button(actions, "report", "Report", lambda: self._start_task("report"), row=0, column=1, padx=(0, 8))
        self._button(actions, "export_report", "Export...", self._export_report, row=0, column=2)
        runtime = self.ttk.Frame(self.pages["Run"])
        runtime.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        self.runtime_vars = {}
        self._plan_choices = {}
        self.plan_choice = self.tk.StringVar()
        for row, (name, label) in enumerate((("plan_id", "Plan"), ("deployment_config", "Configuration JSON"),
                ("runtime_bindings", "Runtime bindings JSON"), ("station_config", "Owner settings"),
                ("tle_file", "Local TLE CSV"), ("duration", "Duration (seconds)"),
                ("opportunity", "Opportunity (1-based)"))):
            self.ttk.Label(runtime, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12))
            variable = self.tk.StringVar(value="1" if name == "opportunity" else "")
            self.runtime_vars[name] = variable
            variable.trace_add("write", self._runtime_input_changed)
            if name == "plan_id":
                entry = self.ttk.Combobox(runtime, textvariable=self.plan_choice, state="readonly", takefocus=True)
                entry.bind("<<ComboboxSelected>>", self._select_plan)
            else:
                entry = self.ttk.Entry(runtime, textvariable=variable, width=40, takefocus=True)
            entry.grid(row=row, column=1, sticky="ew")
            self.widgets["runtime_" + name] = entry
        runtime.columnconfigure(1, weight=1)
        self.runtime_mode = self.tk.StringVar(value="operational")
        self.runtime_mode.trace_add("write", self._runtime_input_changed)
        self.ttk.Label(runtime, text="Execution mode").grid(row=7, column=0, sticky="w")
        self.ttk.Combobox(runtime, textvariable=self.runtime_mode, values=("operational", "rehearsal"),
                          state="readonly", takefocus=True).grid(row=7, column=1, sticky="w")
        buttons = self.ttk.Frame(runtime)
        buttons.grid(row=8, column=0, columnspan=2, sticky="w", pady=6)
        self._button(buttons, "run_preview", "Review run", self._run_preview, row=0, column=0)
        self._button(buttons, "run_start", "Start run", self._run_start, row=0, column=1)
        self._button(buttons, "run_cancel", "Cancel run", lambda: self.perform("run_cancel"), row=0, column=2)
        self._text(self.pages["Run"], "run_detail", height=12, row=2)
        self.pages["Run"].rowconfigure(2, weight=1)
        output = self.ttk.Frame(page)
        output.grid(row=3, column=0, sticky="ew", pady=(0, 8))
        output.columnconfigure(1, weight=1)
        self.ttk.Label(output, text="New report file").grid(row=0, column=0, padx=(0, 12))
        self.report_output = self.tk.StringVar()
        entry = self.ttk.Entry(output, textvariable=self.report_output, takefocus=True)
        entry.grid(row=0, column=1, sticky="ew")
        self.widgets["report_output"] = entry
        self._button(output, "choose_report", "Choose...", self._choose_report, row=0, column=2, padx=(8, 0))
        self._text(page, "result_detail", height=15, row=4)
        page.rowconfigure(4, weight=1)

    def _build_bench(self):
        page = self.pages["PTU"]
        page.configure(padding=(12, 6))
        form = self.ttk.Frame(page)
        form.grid(row=0, column=0, sticky="ew")
        form.columnconfigure(1, weight=1)
        self.bench_configuration = self.tk.StringVar()
        self._button(form, "bench_setup_local", "Save local QPT130",
                     lambda: self._bench_action("setup_local"), row=0, column=0, sticky="w")
        self.bench_saved = self.tk.StringVar(value="No saved local connection.")
        self.ttk.Label(form, textvariable=self.bench_saved, wraplength=690).grid(
            row=1, column=0, columnspan=3, sticky="w", pady=(2, 0))
        self.ttk.Label(form, text="Advanced JSON override").grid(row=2, column=0, sticky="w", padx=(0, 12))
        entry = self.ttk.Entry(form, textvariable=self.bench_configuration, width=40, takefocus=True)
        entry.grid(row=2, column=1, sticky="ew")
        self.widgets["bench_configuration"] = entry
        self._button(form, "bench_choose_configuration", "Choose...", self._choose_bench_configuration,
                     row=2, column=2, padx=(8, 0))
        self.ttk.Label(form, text="Save once, then Connect. JSON overrides are session-only unless saved. "
                       "Local hold uses device soft limits; endpoint/no-go checks apply only to numeric Move.",
                       wraplength=900).grid(row=3, column=0, columnspan=3, sticky="w", pady=(2, 0))
        connections = self.ttk.Frame(form)
        connections.grid(row=0, column=1, columnspan=2, sticky="w", padx=(12, 0))
        for column, (operation, label) in enumerate((("connect", "Connect"), ("status", "Status"),
                                                    ("disconnect", "Disconnect"))):
            self._button(connections, "bench_" + operation, label,
                         lambda operation=operation: self._bench_action(operation), row=0, column=column, padx=(0, 8))
        self.bench_position = self.tk.StringVar(value="Position: not observed")
        self.ttk.Label(page, textvariable=self.bench_position, wraplength=900).grid(row=1, column=0, sticky="w", pady=(2, 0))
        target = self.ttk.Frame(page)
        target.grid(row=2, column=0, sticky="w")
        self.bench_target = {}
        for row, (key, label) in enumerate((("pan", "Target pan (degrees)"), ("tilt", "Target tilt (degrees)"))):
            self.ttk.Label(target, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=1)
            variable = self.tk.StringVar()
            self.bench_target[key] = variable
            entry = self.ttk.Entry(target, textvariable=variable, width=14, takefocus=True)
            entry.grid(row=row, column=1, sticky="w", pady=1)
            variable.trace_add("write", self._bench_target_changed)
            self.widgets["bench_" + key] = entry
        pad = self.ttk.LabelFrame(target, text="Directions: hold locally / broker steps", padding=6)
        pad.grid(row=0, column=2, rowspan=4, padx=(20, 0), sticky="n")
        self._bench_pad_widgets = []
        for direction, label, row, column in (("left", "← Left", 1, 0),
                ("right", "Right →", 1, 2), ("up", "↑ Up", 0, 1),
                ("down", "↓ Down", 2, 1)):
            button = self._button(pad, "bench_" + direction, label,
                lambda direction=direction: self._bench_direction_command(direction), row=row, column=column)
            button.bind("<ButtonPress-1>", lambda event, direction=direction:
                        self._bench_pointer_press(event, direction))
            button.bind("<ButtonRelease-1>", lambda event, direction=direction:
                        self._bench_pointer_release(direction))
            button.bind("<Leave>", lambda event, direction=direction:
                        self._bench_pointer_release(direction))
            for key in ("space", "Return"):
                button.bind("<KeyPress-" + key + ">", lambda event, direction=direction:
                            self._bench_key_press(event, direction))
                button.bind("<KeyRelease-" + key + ">", self._bench_key_release)
            self._bench_pad_widgets.append(button)
        focus = self._button(pad, "bench_pad_focus", "Keys",
            lambda: self.widgets["bench_pad_focus"].focus_set(), row=1, column=1)
        self._bench_pad_widgets.append(focus)
        for widget in self._bench_pad_widgets:
            for key in ("Left", "Right", "Up", "Down"):
                widget.bind("<KeyPress-" + key + ">", self._bench_key_press)
                widget.bind("<KeyRelease-" + key + ">", self._bench_key_release)
        numeric_actions = self.ttk.Frame(target)
        numeric_actions.grid(row=2, column=0, columnspan=2, sticky="w", pady=2)
        self._button(numeric_actions, "bench_preview", "Preview", lambda: self._bench_action("preview"), row=0, column=0, padx=(0, 8))
        self._button(numeric_actions, "bench_move", "Move", lambda: self._bench_action("move"), row=0, column=1)
        actions = self.ttk.Frame(target)
        actions.grid(row=3, column=0, columnspan=2, sticky="w")
        self.ttk.Label(actions, text="Broker step (degrees)").grid(row=0, column=0, padx=(0, 6))
        self.bench_step = self.tk.StringVar()
        step = self.ttk.Entry(actions, textvariable=self.bench_step, width=9, takefocus=True)
        step.grid(row=0, column=1)
        self.widgets["bench_step"] = step
        self.bench_step.trace_add("write", self._bench_manual_changed)
        self._button(actions, "bench_manual", "Enable broker steps", lambda: self._bench_action("manual"),
                     row=1, column=0, sticky="w", pady=(2, 0))
        self._button(actions, "bench_disarm", "Disarm", self._bench_manual_changed,
                     row=1, column=1, sticky="w", padx=(6, 0), pady=(2, 0))
        self._text(page, "bench_detail", height=8, row=3)
        page.rowconfigure(3, weight=1)

    def _choose_bench_configuration(self):
        selected = self.filedialog.askopenfilename(parent=self.root, title="PTU configuration",
                                                  filetypes=(("JSON configuration", "*.json"),))
        if selected:
            self.bench_configuration.set(selected)

    def _bench_target_changed(self, *unused):
        self.presenter.invalidate_bench_preview()
        if "bench_move" in self.widgets:
            self.widgets["bench_move"].state(["disabled"])

    def _bench_manual_changed(self, *unused):
        self._bench_release_hold()
        self.presenter.disarm_bench_manual()
        if self._bench_local():
            self._bench_blocked_keys.update(key for key in self._bench_pressed if not key.startswith("mouse:"))
        self._bench_pressed.clear()
        for identifier in self._bench_releases.values():
            self.root.after_cancel(identifier)
        self._bench_releases.clear()
        if "bench_manual" in self.widgets and hasattr(self, "_closing"):
            self._render_bench()

    def _bench_focus_owned(self):
        return (str(self.notebook.select()) == str(self.pages["PTU"])
                and self.root.focus_get() in self._bench_pad_widgets
                and self.root.grab_current() is None)

    def _bench_focus_changed(self, event=None):
        def check():
            if not self._window_closed and not self._bench_focus_owned():
                self._bench_manual_changed()
        if hasattr(self, "_window_closed") and not self._window_closed:
            self.root.after_idle(check)

    def _bench_unmapped(self, event):
        if event.widget == self.root:
            self._bench_manual_changed()

    def _bench_key_press(self, event, direction=None):
        if not self._bench_focus_owned():
            return None
        key = event.keysym
        pending = self._bench_releases.pop(key, None)
        if pending is not None:
            self.root.after_cancel(pending)
        if key in self._bench_blocked_keys:
            return "break"
        if key not in self._bench_pressed:
            self._bench_pressed.add(key)
            if self._bench_local():
                self._bench_begin_hold(key, direction or key.lower())
            else:
                self._bench_action("step", direction=direction or key.lower())
        return "break"

    def _bench_key_release(self, event):
        key = event.keysym
        if key not in self._bench_releases:
            hold = self._bench_hold
            def release():
                self._bench_releases.pop(key, None)
                self._bench_pressed.discard(key)
                self._bench_blocked_keys.discard(key)
                if hold is not None and hold["key"] == key:
                    self._bench_release_hold(hold)
            self._bench_releases[key] = self.root.after_idle(release)
        return "break"

    def _bench_key_released_elsewhere(self, event):
        if event.keysym in self._bench_blocked_keys or event.keysym in self._bench_pressed:
            return self._bench_key_release(event)
        return None

    def _bench_local(self):
        readback = self.presenter.bench_snapshot()["readback"]
        return readback is not None and readback["transport"] == "local-serial"

    def _bench_direction_command(self, direction):
        if not self._bench_local():
            return self._bench_action("step", direction=direction)

    def _bench_pointer_press(self, event, direction):
        if event.widget.instate(["disabled"]):
            return "break"
        event.widget.focus_set()
        if self._bench_local():
            key = "mouse:" + direction
            self._bench_pressed.add(key)
            self._bench_begin_hold(key, direction)
            return "break"
        return None

    def _bench_pointer_release(self, direction):
        key = "mouse:" + direction
        self._bench_pressed.discard(key)
        hold = self._bench_hold
        if hold is not None and hold["key"] == key:
            self._bench_release_hold(hold)
        return "break" if self._bench_local() else None

    def _bench_pointer_released_elsewhere(self, event):
        hold = self._bench_hold
        if hold is not None and hold["key"].startswith("mouse:"):
            self._bench_pressed.discard(hold["key"])
            self._bench_release_hold(hold)

    def _bench_begin_hold(self, key, direction):
        if self._bench_hold is not None:
            if self._bench_hold["key"] != key:
                self._bench_release_hold()
            return
        if not self._bench_focus_owned():
            return
        outcome = self._bench_action("jog_start", direction=direction)
        if outcome["ok"]:
            hold = {"key": key, "direction": direction, "token": outcome["result"]["jog_token"]}
            self._bench_hold = hold
            self.widgets["bench_" + direction].state(["pressed"])
            self._bench_hold_timer = self.root.after(100, lambda: self._bench_renew_hold(hold))

    def _bench_renew_hold(self, hold):
        if self._bench_hold is not hold:
            return
        self._bench_hold_timer = None
        if self._closing or not self._bench_focus_owned() or hold["key"] not in self._bench_pressed:
            self._bench_release_hold(hold)
            return
        outcome = self.presenter.dispatch("bench_jog_renew", jog_token=hold["token"])
        if not outcome["ok"] or not outcome["result"]["accepted"]:
            self._bench_release_hold(hold)
            return
        self._bench_hold_timer = self.root.after(100, lambda: self._bench_renew_hold(hold))

    def _bench_release_hold(self, hold=None, *, request_stop=True):
        current = self._bench_hold
        if current is None or hold is not None and hold is not current:
            return
        self._bench_hold = None
        self.widgets["bench_" + current["direction"]].state(["!pressed"])
        if self._bench_hold_timer is not None:
            self.root.after_cancel(self._bench_hold_timer)
            self._bench_hold_timer = None
        if request_stop:
            self.presenter.dispatch("bench_jog_end", jog_token=current["token"])

    def _bench_action(self, operation, **values):
        if self._task_thread is not None and operation != "stop":
            return {"ok": False, "status": "FAIL", "action": "bench_" + operation,
                    "error": {"code": "active_work", "message": "Wait for the current operation."}}
        if operation in ("stop", "disconnect", "preview", "move", "setup_local"):
            self._bench_release_hold(request_stop=operation != "stop")
        if operation in ("connect", "setup_local"):
            values["configuration_file"] = self.bench_configuration.get()
        if operation == "preview":
            values.update({key: variable.get() for key, variable in self.bench_target.items()})
        elif operation == "manual":
            values["step_degrees"] = self.bench_step.get()
            self.widgets["bench_pad_focus"].focus_set()
        outcome = self.presenter.dispatch("bench_" + operation, **values)
        if not outcome["ok"]:
            self.message.set(display_message(outcome["error"]["message"]))
        else:
            if operation == "setup_local":
                self.bench_configuration.set("")
                self.message.set("Local PTU selection saved. Connect remains explicit.")
            else:
                self.message.set("PTU " + operation + " requested.")
        self._render_bench()
        if self.presenter.bench_open:
            self._schedule(self._poll_bench)
        return outcome

    def _render_bench(self):
        snapshot = self.presenter.bench_snapshot()
        normal = self.presenter._bench_thread
        busy = normal is not None and normal.is_alive()
        stopping = self.presenter._bench_stop_thread
        stop_busy = stopping is not None and stopping.is_alive()
        connected = snapshot["connected"]
        readback = snapshot["readback"]
        local = readback is not None and readback["transport"] == "local-serial"
        jog = readback["jog"] if readback is not None else None
        jogging = jog is not None and jog["token"] is not None
        motion_allowed = readback is not None and not readback["motion_blocked"]
        manual = motion_allowed and readback["manual_enabled"] and readback["freshness"] == "fresh"
        directional = readback["jog_allowed"] if local else manual
        enabled = not snapshot["closing"] and not self._closing
        for name, available in (("connect", not connected and not busy), ("disconnect", connected and not busy and not stop_busy),
                ("status", connected and not busy and not stop_busy and not jogging),
                ("preview", connected and motion_allowed and not busy and not stop_busy and not jogging),
                ("move", connected and motion_allowed and snapshot["preview_ready"] and not busy and not stop_busy and not jogging),
                ("manual", connected and not local and motion_allowed and readback["freshness"] == "fresh" and not busy and not stop_busy),
                ("disarm", connected),
                *((direction, connected and (directional or jogging and jog["direction"] == direction)
                   and not busy and not stop_busy)
                  for direction in ("left", "right", "up", "down")),
                ("stop", connected and readback is not None and readback["stop_allowed"] and not stop_busy)):
            allowed = enabled and available and (name == "stop" or self._task_thread is None)
            self.widgets["bench_" + name].state(["!disabled"] if allowed else ["disabled"])
        for name in ("bench_configuration", "bench_choose_configuration", "bench_setup_local"):
            self.widgets[name].state(["disabled"] if connected or busy or not enabled else ["!disabled"])
        self.widgets["bench_step"].state(["disabled"] if local or not enabled else ["!disabled"])
        saved = self.presenter.bench_saved
        if self.presenter.bench_saved_error:
            self.bench_saved.set("Saved connection unavailable: " + self.presenter.bench_saved_error)
        elif saved is not None:
            station = saved["station"]
            context = station.get("manual_context", station.get("readback_context"))
            self.bench_saved.set("Saved local " + context["model"] + ": " + context["serial_settings"]["port"])
            if "manual_context" in station and context["no_go_rectangle"] is None:
                self.bench_saved.set(self.bench_saved.get() + " | Numeric no-go: unconfigured")
        else:
            self.bench_saved.set("No saved local connection. Save local QPT130 or choose a session-only file.")
        records = snapshot["results"]
        observed = readback["observation"] if readback is not None else None
        if observed is not None and readback["freshness"] != "disconnected":
            mode = "Controlled rehearsal" if readback["mode"] == "rehearsal" else "Protocol reported"
            manual_text = ("Local hold: " + jog["state"] + (" | " + jog["error"] if jog["error"] else "")) if local else (
                f"Manual steps enabled: {readback['step_degrees']:g}°" if readback["manual_enabled"] else "Manual steps disabled")
            self.bench_position.set(f"{mode}: pan {observed['pan']:g}°, tilt {observed['tilt']:g}° | "
                f"{readback['freshness']} | {observed['observed_at']} | {manual_text}" +
                (" | " + readback["motion_blocked"] if readback["motion_blocked"] else "") +
                (" | Readback: " + readback["error"] if readback["error"] else ""))
        else:
            self.bench_position.set("Reported position: not observed" +
                (" | " + readback["freshness"] if readback is not None else ""))
        self._set_text("bench_detail", records[-5:] if records else "No PTU operation requested.", structured=True)
        if snapshot["cleanup_error"]:
            self.message.set(snapshot["cleanup_error"])

    def _poll_bench(self):
        if self._window_closed:
            return
        self.presenter.collect_bench_results()
        self._render_bench()
        if self._closing:
            self._poll_close()
        elif not self.presenter.bench_active:
            records = self.presenter.bench_snapshot()["results"]
            if records and self._task_thread is None and records[-1].get("attempt_id") != self._bench_displayed_attempt:
                record = records[-1]
                self._bench_displayed_attempt = record.get("attempt_id")
                if record.get("category") != "ok" or record.get("partial"):
                    self.message.set(display_message(record.get("message", "PTU operation returned " + str(record.get("category", "unknown")) + ".")))
                else:
                    messages = {"connect": "PTU session connected.", "status": "Position readback received.",
                        "preview": "Target preview.", "move": "Move submitted. Physical state: indeterminate.",
                        "jog": "Hold command submitted. Physical state: indeterminate.",
                        "stop": "Stop command submitted. Physical state: indeterminate.", "disconnect": "PTU session disconnected."}
                    self.message.set(messages.get(record.get("operation"), "PTU result received."))
            if self._task_thread is None:
                self.presenter.poll_bench()
        if self.presenter.bench_open and not self._closing:
            self._schedule(self._poll_bench)

    def perform(self, action, *, show_result=True, **values):
        if self._closing or self._task_thread is not None and action != "run_cancel":
            return {"ok": False, "status": "FAIL", "action": action,
                    "error": {"code": "active_work", "message": "Wait for the current operation."}}
        outcome = self.presenter.dispatch(action, **values)
        if self._task_thread is not None:
            self.message.set("Local cancellation requested." if outcome["ok"] else
                             display_message(outcome["error"]["message"]))
            return outcome
        return self._show_outcome(action, outcome, values, show_result=show_result)

    def _show_outcome(self, action, outcome, values, *, show_result=True):
        self.presenter.result = outcome
        draft = values.get("changes") if action == "preview_components" and values.get("profile") == "custom" and not outcome["ok"] else None
        self._render(component_draft=draft)
        if outcome["ok"] and action.startswith("preview_"):
            self.notebook.select(self.pages["Review"])
            self.widgets["apply"].focus_set()
        elif show_result and action not in ("refresh", "open_workspace", "create_scratch", "cancel"):
            self.notebook.select(self.pages["Results"])
            self.widgets["result_detail"].focus_set()
        return outcome

    def _start_task(self, action, **values):
        if self._task_thread is not None or self._closing:
            return {"ok": False, "status": "FAIL", "action": action,
                    "error": {"code": "active_work", "message": "Wait for the current operation."}}
        snapshot = deepcopy(values)
        self._task_result = None
        self._task_disabled = {}
        for name, widget in self.widgets.items():
            if widget.winfo_class() == "TButton" and name not in ("run_cancel", "bench_stop"):
                self._task_disabled[name] = widget.instate(["disabled"])
                widget.state(["disabled"])
        self.message.set({"plan": "Calculating...", "report": "Loading report...",
                          "export_report": "Exporting..."}[action])

        def run():
            try:
                outcome = self.presenter.dispatch(action, **snapshot)
            except Exception:
                outcome = self.presenter._failure(action, "operation_failed",
                                                   "Cannot complete the operation. Try again after checking the inputs.")
            with self._task_lock:
                self._task_result = outcome

        self._task_thread = threading.Thread(target=run, name="operator-" + action, daemon=False)
        try:
            self._task_thread.start()
        except RuntimeError:
            self._task_thread = None
            self._restore_task_controls()
            return self._show_outcome(action, self.presenter._failure(action, "operation_failed",
                                      "Cannot start the operation. Try again."), snapshot)
        self._task_action, self._task_values = action, snapshot
        self._schedule(self._poll_task)
        return {"ok": True, "status": "RUNNING", "action": action, "result": {"state": "requested"}}

    def _restore_task_controls(self):
        for name, disabled in self._task_disabled.items():
            self.widgets[name].state(["disabled"] if disabled else ["!disabled"])
        self._task_disabled = {}

    def _poll_task(self):
        if self._window_closed or self._task_thread is None:
            return
        if self._task_thread.is_alive():
            self._schedule(self._poll_task)
            return
        self._task_thread.join()
        self._task_thread = None
        with self._task_lock:
            outcome, self._task_result = self._task_result, None
        self._restore_task_controls()
        if self._closing:
            self._poll_close()
        else:
            self._show_outcome(self._task_action, outcome, self._task_values)

    def _preview_location(self):
        return self.perform("preview_location", **{key: value.get() for key, value in self.location_vars.items()},
                            altitude_reference=self.altitude_reference.get())

    def _preview_components(self):
        changes = None
        if self.profile.get() == "custom" and self._component_configuration is not None:
            changes = deepcopy(self._component_configuration)
            changes.update(id="operator-custom", preset=None)
            for selection in changes["selections"]:
                mode, provider, _ = self.component_controls[selection["component"]]
                selection.update(mode=mode.get(), provider=provider.get())
        return self.perform("preview_components", profile=self.profile.get(), changes=changes,
                            ptu_model=self.ptu_model.get())

    def _plan(self):
        return self._start_task("plan", **{key: value.get() for key, value in self.plan_vars.items()})

    def _select_plan(self, event=None):
        self.runtime_vars["plan_id"].set(self._plan_choices.get(self.plan_choice.get(), ""))

    def _run_preview(self):
        self.presenter.run_preview = None
        values = {key: value.get() for key, value in self.runtime_vars.items()}
        values["mode"] = self.runtime_mode.get()
        try:
            values["duration"] = float(values["duration"])
            values["opportunity"] = int(values["opportunity"])
        except ValueError:
            return self.perform("run_preview", **values)
        return self.perform("run_preview", **values)

    def _runtime_input_changed(self, *unused):
        self.presenter.run_preview = None
        if "run_start" in self.widgets:
            self.widgets["run_start"].state(["disabled"])

    def _run_start(self):
        preview = self.presenter.run_preview
        result = self.perform("run_start", request_id=preview["request_id"] if preview else None, confirm=True)
        if result["ok"]:
            self._schedule(self._poll_run)
        return result

    def _poll_run(self):
        if self._window_closed:
            return
        if self._task_thread is not None:
            self._schedule(self._poll_run)
            return
        self.presenter.poll_runtime()
        self._render()
        if self.presenter.runtime_active:
            self._schedule(self._poll_run)
        elif self._closing:
            self._poll_close()

    def _open_user_guide(self):
        if self._docs_thread is not None or self._closing:
            return
        self._docs_result = None
        self.help_menu.entryconfigure("User Guide", state="disabled")

        def run():
            try:
                from satgs.operator_docs import dispatch_docs
                result = dispatch_docs()
            except OperatorError as error:
                result = {"mode": "error", "message": str(error), "text": ""}
            except Exception:
                result = {"mode": "error", "message": "The user guide could not be opened.", "text": ""}
            with self._docs_lock:
                self._docs_result = result

        self._docs_thread = threading.Thread(target=run, name="operator-docs", daemon=False)
        try:
            self._docs_thread.start()
        except RuntimeError:
            self._docs_thread = None
            self.help_menu.entryconfigure("User Guide", state="normal")
            self._show_user_guide({"message": "The user guide could not be started.", "text": ""})
            return
        self._schedule(self._poll_docs)

    def _poll_docs(self):
        if self._window_closed or self._docs_thread is None:
            return
        if self._docs_thread.is_alive():
            self._schedule(self._poll_docs)
            return
        self._docs_thread.join()
        self._docs_thread = None
        self.help_menu.entryconfigure("User Guide", state="normal")
        with self._docs_lock:
            result = self._docs_result
        if self._closing:
            self._poll_close()
        elif result is not None and result["mode"] != "viewer_dispatched":
            self._show_user_guide(result)

    def _show_user_guide(self, result):
        if self._guide_window is not None and self._guide_window.winfo_exists():
            self._guide_window.lift()
            return
        window = self.tk.Toplevel(self.root)
        self._guide_window = window
        window.title("SATGS User Guide")
        window.transient(self.root)
        window.geometry("800x600")
        window.minsize(480, 320)
        window.rowconfigure(0, weight=1)
        window.columnconfigure(0, weight=1)
        frame = self.ttk.Frame(window, padding=12)
        frame.grid(sticky="nsew")
        frame.rowconfigure(1, weight=1)
        frame.columnconfigure(0, weight=1)
        self.ttk.Label(frame, text=result["message"], wraplength=700).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        guide = self.tk.Text(frame, wrap="word", font="TkDefaultFont", takefocus=True,
                             padx=8, pady=8)
        guide.insert("1.0", result["text"])
        guide.configure(state="disabled")
        scrollbar = self.ttk.Scrollbar(frame, orient="vertical", command=guide.yview)
        guide.configure(yscrollcommand=scrollbar.set)
        guide.grid(row=1, column=0, sticky="nsew")
        scrollbar.grid(row=1, column=1, sticky="ns")
        self._guide_text = guide
        guide.focus_set()

    def _close(self):
        self._closing = True
        self._bench_manual_changed()
        self.presenter.cancel_active()
        self.presenter.close_bench()
        self._poll_close()

    def _schedule(self, callback):
        if callback in self._timers or self._window_closed:
            return
        def invoke():
            self._timers.pop(callback, None)
            if not self._window_closed:
                callback()
        self._timers[callback] = self.root.after(50, invoke)

    def _poll_close(self):
        if self._window_closed:
            return
        if (self._task_thread is not None or self._docs_thread is not None
                or self.presenter.runtime_active or self.presenter.bench_active):
            self.message.set("Closing...")
            self._schedule(self._poll_close)
        elif self.presenter.bench_snapshot()["cleanup_error"]:
            self._closing = False
            self.message.set(self.presenter.bench_snapshot()["cleanup_error"])
        else:
            for identifier in tuple(self._timers.values()):
                self.root.after_cancel(identifier)
            self._timers.clear()
            self._window_closed = True
            self.root.destroy()

    def _open_workspace(self):
        selected = self.filedialog.askdirectory(parent=self.root, title="Open station", mustexist=True)
        if selected:
            self.perform("open_workspace", root=selected)

    def _create_scratch(self):
        selected = self.filedialog.asksaveasfilename(parent=self.root, title="New station", confirmoverwrite=True)
        if selected:
            self.perform("create_scratch", root=selected)

    def _export_report(self):
        if not self.report_output.get():
            self._choose_report()
        if self.report_output.get():
            return self._start_task("export_report", output=self.report_output.get())
        return None

    def _choose_report(self):
        selected = self.filedialog.asksaveasfilename(parent=self.root, title="Export report", defaultextension=".json",
                                                    filetypes=(("JSON report", "*.json"),), confirmoverwrite=True)
        if selected:
            self.report_output.set(selected)

    def _escape(self, event):
        if self.presenter.preview is not None:
            self.perform("cancel")
            return "break"
        return None

    def _render(self, *, component_draft=None):
        status = self.presenter.status
        workspace = getattr(self.presenter.workspace, "root", None)
        workspace_changed = workspace != self._workspace_loaded
        if workspace_changed:
            self.bench_configuration.set("")
        self.station.set(station_name(status.get("station_name")))
        tree = self.widgets["status_dimensions"]
        dimensions = status.get("status", {})
        for key, label in (("configuration", "Configuration selection"), ("installation", "Installation"),
                           ("connection", "Connection"), ("message_receipt", "Message receipt"),
                           ("fix", "Fix / validity"), ("freshness", "Freshness"),
                           ("system_health", "System health"), ("calibration", "Calibration / heading"),
                           ("heading", "Heading qualification"), ("transport_check", "Transport check"),
                           ("operation_result", "Operation result")):
            value = status.get("last_operation") if key == "operation_result" else dimensions.get(key)
            if value is None:
                value = "Not checked"
            values = (label, display_document_text(value) if not isinstance(value, str) else display_message(value))
            if tree.exists(key):
                if tuple(tree.item(key, "values")) != values:
                    tree.item(key, values=values)
            else:
                tree.insert("", "end", iid=key, values=values)
        selection = status.get("selection")
        summary = {"station_name": station_name(status.get("station_name")),
                   "profile": (selection.get("preset") or "custom") if selection else "unconfigured",
                   "location": status.get("effective_location") or "No location set.",
                   "last_operation": status.get("last_operation")}
        self._set_text("status_detail", summary if status else "No workspace selected.")
        self._set_text("gps_detail", {"measured_gps": gps_document(status.get("measured_gps", {})),
                                     "selection_enabled": status.get("gps_selection", {}).get("enabled", False)} if status else "No data.")
        review = self.presenter.preview or "No pending preview."
        if component_draft is not None:
            review = {"status": "Not saved", "proposed": component_draft,
                      "error": self.presenter.result["error"], "confirmation_enabled": False}
        self._set_text("review_detail", review, structured=True)
        for name in ("apply", "cancel"):
            self.widgets[name].state(["!disabled"] if self.presenter.preview is not None else ["disabled"])
        self.widgets["run_start"].state(["!disabled"] if self.presenter.run_preview is not None and not self.presenter.runtime_active and not self.presenter.bench_open else ["disabled"])
        self.widgets["run_cancel"].state(["!disabled"] if self.presenter.runtime_active else ["disabled"])
        self._set_text("run_detail", self.presenter.runtime_result or "No run observation.")
        choices = {"Plan " + str(index) + (" (stale)" if plan["revalidation_required"] else ""):
                   plan["plan_id"] for index, plan in enumerate(status.get("plans", []), 1)}
        if choices != self._plan_choices:
            self._plan_choices = choices
            self.widgets["runtime_plan_id"].configure(values=tuple(choices))
        selected = self.runtime_vars["plan_id"].get()
        self.plan_choice.set(next((label for label, identity in choices.items() if identity == selected), ""))
        if self.presenter.result is not None:
            outcome = self.presenter.result
            action = outcome["action"]
            if action in ("run_start", "run_status", "run_cancel"):
                result = outcome.get("result", {})
                state, code = result.get("state"), result.get("exit_code")
                if not outcome["ok"] and code != 130:
                    message = outcome["error"]["message"]
                elif action == "run_cancel":
                    message = "Local cancellation requested. Physical state is not confirmed."
                elif code == 130:
                    message = "Local work cancelled. Physical state is not confirmed."
                elif code == 8:
                    message = "Software work complete. Physical state: indeterminate."
                elif action == "run_start" or state == "starting":
                    message = "Run starting."
                elif result.get("finished"):
                    message = "Software work complete."
                else:
                    message = "Run active: " + str(state or "awaiting progress") + "."
                self.message.set(display_message(message))
            elif not outcome["ok"]:
                self.message.set("Operation failed: " + display_message(outcome["error"]["message"]))
            else:
                messages = {"create_scratch": "Workspace created.", "open_workspace": "Workspace opened.",
                            "refresh": "Status reloaded.", "preview_location": "Location preview.",
                            "preview_components": "Configuration preview.", "cancel": "Preview cancelled.",
                            "report": "Report loaded.", "export_report": "Report exported.",
                            "plan": "Calculation complete."}
                if action == "apply":
                    result = outcome["result"]
                    message = "No changes." if result.get("result") == "unchanged" else (
                        "Location saved." if result.get("kind") == "location" else "Configuration saved.")
                else:
                    message = messages.get(action, "Operation complete.")
                self.message.set(message)
            self._set_text("result_detail", outcome)
        configuration = status.get("selection")
        edited = self._component_edited()
        if component_draft is not None:
            configuration = component_draft
        elif self.presenter.preview is not None and self.presenter.preview.get("kind") == "components":
            configuration = self.presenter.preview["proposed"]["configuration"]
        if (component_draft is not None or workspace_changed or not edited) and (
                configuration != self._component_configuration or not self.component_frame.winfo_children()):
            self._populate_components(configuration)
        saved_profile = (status.get("selection") or {}).get("preset") or "custom"
        if status.get("selection") is None:
            saved_profile = "guided_arrow"
        if workspace_changed or self._profile_loaded is None or self.profile.get() == self._profile_loaded:
            self.profile.set(saved_profile)
        self._profile_loaded = saved_profile
        if self._location_revision != self.presenter.revision:
            location = status.get("effective_location") or {}
            current = self._location_values()
            saved = tuple(str(location[key]) if key in location else "" for key in self.location_vars) + (
                location.get("altitude_reference", "unspecified"),)
            if workspace_changed or self._location_loaded is None or current == self._location_loaded:
                for variable, value in zip((*self.location_vars.values(), self.altitude_reference), saved):
                    variable.set(value)
            self._location_loaded = saved
            self._location_revision = self.presenter.revision
        self._workspace_loaded = workspace
        self._render_bench()

    def _location_values(self):
        return tuple(variable.get() for variable in self.location_vars.values()) + (self.altitude_reference.get(),)

    def _component_edited(self):
        if self._component_configuration is None:
            return False
        return any(identity in self.component_controls and
                   (self.component_controls[identity][0].get() != item["mode"] or
                    self.component_controls[identity][1].get() != item["provider"])
                   for item in self._component_configuration.get("selections", [])
                   for identity in (item["component"],))

    def _populate_components(self, configuration):
        self._component_configuration = deepcopy(configuration)
        previous_scroll = self.component_canvas.yview()
        for widget in self.component_frame.winfo_children():
            widget.destroy()
        self.component_controls.clear()
        if configuration is None:
            self.ttk.Label(self.component_frame, text="Select a configuration.",
                           wraplength=880).grid(sticky="w")
            return
        self.ttk.Label(self.component_frame, text="Custom component").grid(row=0, column=0, sticky="w", padx=4)
        self.ttk.Label(self.component_frame, text="Selection mode").grid(row=0, column=1, sticky="w", padx=4)
        self.ttk.Label(self.component_frame, text="Provider").grid(row=0, column=2, sticky="w", padx=4)
        catalog = {item["id"]: item for item in self.presenter.catalog.get("components", [])}
        for row, selection in enumerate(configuration.get("selections", []), 1):
            identity = selection["component"]
            component = catalog[identity]
            providers = component.get("providers", []) + component.get("external_providers", [])
            mode = self.tk.StringVar(value=selection["mode"])
            provider = self.tk.StringVar(value=selection["provider"])
            self.ttk.Label(self.component_frame, text=identity).grid(row=row, column=0, sticky="w", padx=4, pady=4)
            mode_widget = self.ttk.Combobox(self.component_frame, textvariable=mode, state="readonly",
                                            values=("install", "reuse", "external", "omit"), width=12, takefocus=True)
            mode_widget.grid(row=row, column=1, sticky="w", padx=4, pady=4)
            provider_widget = self.ttk.Combobox(self.component_frame, textvariable=provider, state="readonly",
                                                values=tuple(providers), width=30, takefocus=True)
            provider_widget.grid(row=row, column=2, sticky="w", padx=4, pady=4)
            self.component_controls[identity] = (mode, provider, mode_widget)
            for widget in (mode_widget, provider_widget):
                widget.bind("<FocusIn>", lambda event: self._scroll_to_component(event.widget))
        if previous_scroll:
            self.component_canvas.yview_moveto(previous_scroll[0])

    def _scroll_to_component(self, widget):
        self.component_canvas.update_idletasks()
        height = self.component_frame.winfo_height()
        if height > self.component_canvas.winfo_height():
            top = self.component_canvas.canvasy(0)
            bottom = top + self.component_canvas.winfo_height()
            y, end = widget.winfo_y(), widget.winfo_y() + widget.winfo_height()
            if y < top:
                self.component_canvas.yview_moveto(max(0, y - 4) / height)
            elif end > bottom:
                self.component_canvas.yview_moveto(max(0, end - self.component_canvas.winfo_height() + 4) / height)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="SATGS")
    parser.add_argument("--workspace", type=Path, help="Existing managed workspace to inspect")
    parser.add_argument("--demo", type=Path, help="Create a new workspace at this path")
    args = parser.parse_args(argv)
    if args.workspace is not None and args.demo is not None:
        parser.error("select --workspace or --demo, not both")
    try:
        import tkinter as tk
        from tkinter import filedialog, ttk
    except ImportError:
        print("Native GUI unavailable: install the reviewed optional Python Tk runtime. Headless satgs-operator remains available.")
        return 3
    try:
        root = tk.Tk()
    except tk.TclError as error:
        print("Native GUI unavailable: cannot connect to the display." if display_unavailable(error) else
              "Native GUI startup failed: Tk initialization could not complete.")
        return 3
    presenter = OperatorPresenter()
    try:
        window = OperatorWindow(root, presenter, tk=tk, ttk=ttk, filedialog=filedialog)
        if args.workspace is not None:
            window.perform("open_workspace", root=args.workspace, show_result=False)
        if args.demo is not None:
            window.perform("create_scratch", root=args.demo)
        root.mainloop()
    finally:
        presenter.cancel_active()
        presenter.close_bench()
        try:
            root.destroy()
        except tk.TclError:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
