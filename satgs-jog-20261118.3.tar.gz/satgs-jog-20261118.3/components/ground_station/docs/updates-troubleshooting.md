# 11. Updates rollback and troubleshooting

Keep the accepted application usable while preparing an update. Station data,
installed code, source checkout and acceptance records are different things.
A repository pull synchronizes source; it does not replace installed wheels,
activate managers, migrate data or select the next daily application.

## Use a reviewed release

The PTU release pairs satgs and ptu_control at `0.0.1+jog.20261118.3`, with
serialptu `0.0.1+jog.20261118.3` and retained paired Meteor/lower loopback support.
Local serial and broker operation are explicit separate choices. Obtain its versioned internal download or exact
maintained source/release through the authorized route. Today's Pi offline
route does not require Git authentication or copying a developer's private key.

From the new extraction, follow [Installation](installation.md#install-the-native-release-offline):
setup a separate candidate, run consolidated acceptance, inspect its report,
then explicitly select `jog3` only when compatible and idle. The retained
`bench` installation is the prior selection for rollback. Failed candidates,
old environments and their evidence are kept, not overwritten.

The release handoff is one setup/update command and one consolidated acceptance
command. Follow the root README for the actual release content and command
arguments. Do not install with an editable runtime checkout or run `git pull`
inside an active installed environment. There is no auto-update on GUI launch
or cron-driven application activation.

From the extracted reviewed release directory, inspect and stage it with:

```sh
python3.11 -I -B -S support/release_update.py status
. ./setup_update.sh --accept-trusted-native
```

Status reports the release, existing daily selection and required replacement
wheels. Staging builds a separate installation and retains the current selection.
Inspect the setup result, then run the consolidated check:

```sh
./run_pi_operator_checks.sh --accept-trusted-native
```

Select only after its actual report passes and managed station activity is idle:

```sh
. ./launchers/setup_daily.sh --select jog3
```

Selection does not open a window. Click SATGS or run `satgs-operator-gui`
afterward when you want the GUI. The CLI uses the same selected environment and
workspace. Neither opening interface starts a service or PTU operation.

## Maintained source workflow

The integration repository keeps ground_station, sat_tracker, serialptu,
pixhawk, meteor-api and the amended lower transport as distinct owners. Use an
inactive source workspace for development and the repository's documented
exact-ref acquisition/build workflow. Preserve legal notices and owner provenance.
Coordinate reviewed shared fixes upstream with the maintainers rather than
editing unmanaged copies in several checkouts.

The current candidate's maintained source is included in its versioned artifact;
artifact publication does not advance remote source refs. The source-status
command below applies only to an actual Git checkout of a separately published
source identity. These are the local checks and offline build entry points:

```sh
python3.11 -I -B -S tools/source_status.py --ref refs/heads/feature/operator-handbook-ptu
python3.11 -I -B -S tools/check_source.py
python3.11 -I -B -S tools/build_release.py --build-python /absolute/satgs-build-env/bin/python --output-root /absolute/new-satgs-build
```

The two absolute paths must identify a separately provisioned build environment
with the locked tools and a new output directory. They are not Pi daily-use
paths. The source check does not fetch or modify anything. Fetching or merging
source requires the explicit repository workflow and authorization; building
does not install or select its output. Preserve a failed build directory.

Source checks and builds must use complete source and generated resources,
not a hidden fallback to a previous delivery/evidence directory. Optional client
and manager dependencies stay separate. A source update must retain compatible
station settings/results and must explain any incompatibility before activation.
This release introduces no database or workspace schema migration.

The source line, review route, immutable release references and retained artifact
downloads are recorded by the root contributor/release instructions. Do not
substitute a moving upstream branch for an explicit release. Branch cleanup,
default-branch changes and tag moves require their own exact administrative
approval and are not prerequisites for using this handbook.

## Return to the preceding compatible selection

If acceptance fails, leave the existing selection unchanged. If a selected
jog release must be rolled back, use this update's reviewed daily
selection machinery to select the preceding bench application:

```sh
. ./launchers/setup_daily.sh --select bench
```

Use the launchers distributed with the reviewed update, not a guessed older
script. Selection must be idle and compatible. Reopen the ordinary wrapper,
then inspect status and the installed guide. Do not delete the PTU candidate,
move virtual environments or reset the workspace during rollback.

Rollback changes the selected application. It does not undo prior physical
effects, erase operation history, roll back independent services or claim atomic
code/data rollback. Preserve original/failed records if recovery is uncertain.

## Troubleshoot the layer that failed

| Symptom | Check and next action |
| --- | --- |
| Command not found in a new terminal | Use the installed `~/.local/bin` wrapper. Sourced PATH applies only to its terminal. Do not invent aliases into versioned environments. |
| Launcher reports unsuitable selection/path | Retain its diagnostic and selection file. Do not initialize the daily station or bypass application identity checks. |
| GUI does not open over SSH | Use `docs --text` and CLI. Open the window in your normal desktop/remote desktop session, without forcing another display. |
| Menu item missing or placed unexpectedly | Verify ordinary menu installation/desktop metadata using the maintainer appendix. A printed setup message is not a menu-click check. |
| Docs falls back to text | Text is the supported headless/viewer-failure route. Missing packaged resources instead report `docs_unavailable`; repair a separate candidate. |
| Unknown installation/health/fix/heading | These are distinct evidence dimensions. Inspect the assigned source; do not turn unknown into healthy with profile Save or replay. |
| Custom Save disabled | Review canonical provider/hardware-instance diagnostics. Full's optional hardware has no stable instances; supply reviewed intent or start from Guided's instances. |
| Preview stale/conflicting | Reload, inspect the changed station, then create a new preview. Do not force or reuse a cancelled preview. |
| Save reports partial receipt failure | Reload real saved state before retrying. Keep the preview/receipt/partial artifacts. |
| No pass opportunities | Check site, NORAD, local TLE, UTC span and elevation mask. This is not evidence of PTU/receiver failure. |
| Planning dependency/TLE error | Retain the diagnostic and source file. Repair the inactive package/input; no automatic TLE refresh occurs here. |
| Run not_started or owner admission rejected | Review the actual request/inputs and release admission. Rehearsal mode is not a bypass or successful execution. |
| PTU unknown/stale/busy or required Stop failed | Do not repeat motion. Inspect correlated owner evidence and follow the PTU recovery contract. Disconnect does not prove Stop. |
| Export fails on an existing filename | Choose a new file in an existing private directory. Existing bytes are deliberately preserved. |
| Missing RF/database/Box result | Native Export does not perform recording, database writes or uploads. Check the separate configured legacy/service workflow. |
| Setup or acceptance fails | Retain printed attempt/report/archive paths and failed candidate. Keep the prior selection; do not clean and overwrite evidence. |

For support, provide the selected release, task, exact bounded diagnostic and
relevant redacted report/attempt files. Keep credentials, private keys and
unrelated station data out of the handoff. [Results](results.md) explains which
files preserve a run and which report is only a snapshot.
