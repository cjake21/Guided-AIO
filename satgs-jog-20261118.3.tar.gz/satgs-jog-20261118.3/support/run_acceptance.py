"""One fixed offline candidate acceptance attempt, reusing admitted supervision/finalization."""

import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import signal
import stat
import sys
import sysconfig
import tarfile
import tempfile
import time
import tomllib
import types

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LANES = ('controls', 'static', 'installed', 'docs', 'guide-content', 'presenter', 'core-cli', 'planning',
         'regression', 'runtime-integration', 'bench', 'owner-regression',
         'messenger-regression', 'lower-regression', 'source-workflow',
         'docs-examples', 'native-widgets', 'launcher')
LAUNCHER_FOLLOWUP = ('controls', 'static', 'installed', 'launcher')
SCREENSHOTS = frozenset(('setup.png', 'location.png', 'results.png', 'run.png', 'ptu.png'))
WARNINGS = []


def route(args):
    if getattr(args, 'jog_development', False) and not getattr(args, 'headless_development', False):
        raise ValueError('Focused jog checks require the bound host headless route.')
    if getattr(args, 'headless_development', False):
        if any(getattr(args, name, False) for name in ('launcher_followup', 'controls_only',
                'startup_diagnostic', 'capture_widgets_only', 'installed_preflight', 'owned_host_display_fixture')):
            raise ValueError('Host headless complement cannot be combined with another route.')
        if getattr(args, 'jog_development', False):
            return ('controls', 'static', 'installed', 'core-cli', 'bench', 'owner-regression',
                    'lower-regression', 'source-workflow', 'launcher'), 'host-jog-development'
        return tuple(lane for lane in LANES if lane != 'native-widgets'), 'host-headless-complement'
    if getattr(args, 'installed_preflight', False):
        if any(getattr(args, name, False) for name in
               ('launcher_followup', 'controls_only', 'startup_diagnostic', 'capture_widgets_only')):
            raise ValueError('Installed preflight cannot be combined with another route.')
        return ('controls', 'static', 'installed'), 'installed-origin-preflight'
    if getattr(args, 'capture_widgets_only', False):
        if (not getattr(args, 'owned_host_display_fixture', False)
                or getattr(args, 'owned_host_native_scratch', None) is None
                or any(getattr(args, name, False) for name in
                       ('launcher_followup', 'controls_only', 'startup_diagnostic'))):
            raise ValueError('Intermediate capture requires only the owned host widget route.')
        return ('controls', 'static', 'installed', 'native-widgets'), 'intermediate-host-widget-capture'
    if getattr(args, 'launcher_followup', False):
        if (getattr(args, 'controls_only', False) or getattr(args, 'startup_diagnostic', False)
                or getattr(args, 'owned_host_display_fixture', False)
                or getattr(args, 'owned_host_native_scratch', None) is not None):
            raise ValueError('Launcher follow-up cannot be combined with another check mode.')
        return LAUNCHER_FOLLOWUP, 'launcher-followup-functional-checks'
    if getattr(args, 'controls_only', False):
        return ('controls',), 'controls-only'
    return LANES, 'handbook-and-bounded-ptu-functional-checks'


def private_authority(path):
    return provenance.private_authority(path)


def sha(path):
    if private_authority(path):
        raise RuntimeError('required public input overlaps private desktop authentication; no bytes read')
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path, name, expected=None):
    raw = path.read_bytes()
    if expected is not None and hashlib.sha256(raw).hexdigest() != expected:
        WARNINGS.append(dict(path=str(path), reason='recorded support digest differs', blocking=False))
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec', dont_inherit=True), vars(module))
    return module


provenance = load(HERE / 'provenance.py', 'operator_provenance')


def inventory(roots, stdlib=None, excluded=()):
    files, directories, native = {}, set(), set()
    for root in roots:
        if not root.is_dir():
            raise FileNotFoundError('required candidate input directory unavailable: ' + str(root))
        directories.add(str(root.resolve()))
        for path in root.rglob('*'):
            if str(path) in excluded:
                continue
            if root == stdlib and any(name in path.relative_to(root).parts for name in ('site-packages', 'dist-packages')):
                continue
            if '.git' in path.relative_to(root).parts or '__pycache__' in path.parts or path.suffix == '.pyc':
                continue
            if private_authority(path):
                continue
            if path.is_symlink():
                resolved = path.resolve(strict=True)
                if resolved.is_dir():
                    continue
            else:
                resolved = path
            if resolved.is_file():
                if stat.S_ISREG(resolved.stat().st_mode):
                    files[str(resolved)] = sha(resolved)
                    if resolved.suffix == '.so':
                        native.add(str(resolved))
            elif resolved.is_dir():
                directories.add(str(resolved))
    return files, directories, native


class UnsupportedRuntime(RuntimeError):
    pass


def public_utc_input(target):
    source = Path('/usr/share/zoneinfo/UTC')
    try:
        resolved = source.resolve(strict=True)
        if resolved not in (source, Path('/usr/share/zoneinfo/Etc/UTC')):
            raise UnsupportedRuntime('Public UTC resolved outside the two reviewed resource paths')
        rows = []
        for item in sorted(set((source, *source.parents, resolved, *resolved.parents)), key=str):
            info = item.lstat()
            link = os.readlink(item) if stat.S_ISLNK(info.st_mode) else None
            if link is not None:
                if item != source or link not in ('Etc/UTC', '/usr/share/zoneinfo/Etc/UTC'):
                    raise UnsupportedRuntime('Unreviewed public UTC symlink chain')
            elif item != resolved and not stat.S_ISDIR(info.st_mode):
                raise UnsupportedRuntime('Nonordinary public UTC ancestor')
            rows.append(dict(path=str(item), device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
                             uid=info.st_uid, gid=info.st_gid, bytes=info.st_size,
                             mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns, link=link))
        if not stat.S_ISREG(resolved.lstat().st_mode) or resolved.stat().st_size > 65536:
            raise UnsupportedRuntime('Public UTC resource must be a bounded ordinary TZif file')
        payload = resolved.read_bytes()
        target.utc_source_policy(payload)
        return dict(source=str(source), resolved=str(resolved), sha256=sha(resolved), bytes=len(payload), identities=rows,
                    role='public UTC timezone data only, not clock synchronization or installed tzdata byte equivalence')
    except OSError as error:
        raise UnsupportedRuntime('Public UTC resource identity unavailable: ' + type(error).__name__) from None


def pi_science_absence():
    path = Path('/opt/_internal/cpython-3.11.10/lib/python3.11/site-packages/scipy_openblas32/lib')
    rows = []
    for item in reversed((path, *path.parents)):
        try:
            info = item.lstat()
        except FileNotFoundError:
            rows.append(dict(path=str(item), identity=None))
            break
        if not stat.S_ISDIR(info.st_mode):
            raise UnsupportedRuntime('Pi SciPy native RPATH has a nonordinary ancestor')
        rows.append(dict(path=str(item), identity=[info.st_dev, info.st_ino, info.st_mode]))
    else:
        raise UnsupportedRuntime('Pi SciPy native RPATH provider exists; separate dependency review required')
    return dict(path=str(path), ancestors=rows, policy='exact known native RPATH remains absent')


def declared_runtime(application, recording):
    settings = recording.read(application / 'pyvenv.cfg').decode('utf-8').splitlines()
    homes = [line.partition('=')[2].strip() for line in settings if line.partition('=')[0].strip() == 'home']
    if len(homes) != 1 or not Path(homes[0]).is_absolute():
        raise UnsupportedRuntime('application must declare exactly one absolute interpreter home')
    runtime = Path(homes[0]).parent.resolve()
    return runtime


def application_runtime(application, recording, target):
    runtime = declared_runtime(application, recording)
    if (sys.implementation.name != 'cpython' or Path(sys.base_prefix).resolve() != runtime
            or sys.version_info[:2] != (3, 11)):
        raise UnsupportedRuntime('selected interpreter and declared CPython3.11 base disagree')
    if platform.machine() == 'aarch64' and sys.version_info[:3] == (3, 11, 2):
        if runtime != Path('/usr'):
            raise UnsupportedRuntime('supported Pi runtime uses the /usr base layout')
        target.target_facts()
        tree = target.snapshot(runtime / 'lib/python3.11')
        if target.live_startup_policy(tree, application) is not True:
            raise UnsupportedRuntime('Exact retained Pi startup hook/cache profile required')
        pi_science_absence()
        return runtime, 'compatible-pi-cpython3112-semantic-startup', tree
    if (platform.machine() != 'x86_64' or sys.version_info[:3] != (3, 11, 16)
            or sysconfig.get_config_var('SOABI') != 'cpython-311-x86_64-linux-gnu'):
        raise UnsupportedRuntime('supported profiles are CPython3.11.2/aarch64 and 3.11.16/x86-64')
    stdlib = runtime / 'lib/python3.11'
    if any(path.name.startswith(('sitecustomize', 'usercustomize')) for path in stdlib.rglob('*')):
        raise UnsupportedRuntime('Host gate forbids base startup hooks; target reviewed hook/cache needs its separate retained policy.')
    return runtime, 'compatible-host-cpython31116-no-startup-hooks', None


def candidate_inputs(source, application, runtime, excluded=()):
    activity = ROOT / 'components/ground_station/src/satgs/operator_activity.py'
    if (not all(stat.S_ISDIR(parent.lstat().st_mode) for parent in activity.parents)
            or not stat.S_ISREG(activity.lstat().st_mode)):
        raise RuntimeError('Workflow activity source requires an ordinary file and directory ancestry.')
    files, directories, native = inventory((runtime / 'lib/python3.11', application, source, HERE,
                                             ROOT / 'launchers', ROOT / 'tests', ROOT / 'tools',
                                             ROOT / 'requirements'),
        runtime / 'lib/python3.11', excluded=excluded)
    files[str(ROOT / 'release.json')] = sha(ROOT / 'release.json')
    files[str(activity)] = sha(activity)
    return files, directories, native


def bind(source, application, runtime, environments, profile, startup_tree, target):
    site = application / 'lib/python3.11/site-packages'
    numpy_metadata = target.numpy_metadata_snapshot(site)
    files, directories, native = candidate_inputs(source, application, runtime,
                                                  excluded=(numpy_metadata['path'],))
    runtime_application = (Path('/workspace/development/satgs-runtime-qpt130-20261110-host-setup-attempt-6/application')
                           if profile == 'compatible-host-cpython31116-no-startup-hooks'
                           else Path('/home/admin/satgs-runtime-20261110-app-manager'))
    retained_entries = [runtime_application / 'bin' / name for name in ('python', 'satgs-operator', 'satgs-operator-gui')]
    retained_entries.append(runtime_application / 'lib/python3.11/site-packages/satgs-0.0.1+runtime.20261110.1.dist-info/METADATA')
    ui_application = (Path('/workspace/development/satgs-native-ui-20261111-host-setup-attempt-3/application')
                      if profile == 'compatible-host-cpython31116-no-startup-hooks'
                      else Path('/home/admin/satgs-native-ui-20261111-app-manager'))
    retained_entries.extend(ui_application / 'bin' / name for name in ('python', 'satgs-operator', 'satgs-operator-gui'))
    retained_entries.append(ui_application / 'lib/python3.11/site-packages/satgs-0.0.1+ui.20261111.1.dist-info/METADATA')
    guide_application = (Path('/workspace/development/satgs-user-guide-20261112-host-setup-attempt-1/application')
                         if profile == 'compatible-host-cpython31116-no-startup-hooks'
                         else Path('/home/admin/satgs-user-guide-20261112-app-manager'))
    retained_entries.extend(guide_application / 'bin' / name
                            for name in ('python', 'satgs-operator', 'satgs-operator-gui'))
    retained_entries.append(guide_application / 'lib/python3.11/site-packages/satgs-0.0.1+guide.20261112.1.dist-info/METADATA')
    handbook_application = (Path('/workspace/development/satgs-maintenance/host-setup-4/application')
                            if profile == 'compatible-host-cpython31116-no-startup-hooks'
                            else Path('/home/admin/satgs-handbook-20261112-app-manager'))
    retained_entries.extend(handbook_application / 'bin' / name
                            for name in ('python', 'satgs-operator', 'satgs-operator-gui'))
    retained_entries.append(handbook_application / 'lib/python3.11/site-packages/satgs-0.0.1+handbook.20261112.1.dist-info/METADATA')
    ptu_application = (Path('/workspace/development/satgs-maintenance/qpt-readback-20261117/host-setup-4/application')
                       if profile == 'compatible-host-cpython31116-no-startup-hooks'
                       else Path('/home/admin/satgs-ptu-20261117-app-manager'))
    retained_entries.extend(ptu_application / 'bin' / name
                            for name in ('python', 'satgs-operator', 'satgs-operator-gui'))
    retained_entries.append(ptu_application / 'lib/python3.11/site-packages/satgs-0.0.1+ptu.20261117.1.dist-info/METADATA')
    bench_application = (Path('/workspace/development/satgs-maintenance/bench-local-serial-20261118-oQodX2ph/host-setup-2/application')
                         if profile == 'compatible-host-cpython31116-no-startup-hooks'
                         else Path('/home/admin/satgs-bench-20261118-app-manager'))
    retained_entries.extend(bench_application / 'bin' / name
                            for name in ('python', 'satgs-operator', 'satgs-operator-gui'))
    retained_entries.append(bench_application / 'lib/python3.11/site-packages/satgs-0.0.1+bench.20261118.1.dist-info/METADATA')
    jog_application = (Path('/workspace/development/satgs-maintenance/bench-jog-20261118-ky03GHW5/host-setup-2/application')
                       if profile == 'compatible-host-cpython31116-no-startup-hooks'
                       else Path('/home/admin/satgs-jog-20261118-app-manager'))
    retained_entries.extend(jog_application / 'bin' / name
                            for name in ('python', 'satgs-operator', 'satgs-operator-gui'))
    retained_entries.append(jog_application / 'lib/python3.11/site-packages/satgs-0.0.1+jog.20261118.1.dist-info/METADATA')
    jog2_application = (Path('/workspace/development/satgs-maintenance/bench-jog-correction-20261118-8Ji7ffg8/host-setup-4/application')
                        if profile == 'compatible-host-cpython31116-no-startup-hooks'
                        else Path('/home/admin/satgs-jog-20261118-v2-app-manager'))
    retained_entries.extend(jog2_application / 'bin' / name
                            for name in ('python', 'satgs-operator', 'satgs-operator-gui'))
    retained_entries.append(jog2_application / 'lib/python3.11/site-packages/satgs-0.0.1+jog.20261118.2.dist-info/METADATA')
    for path in retained_entries:
        if not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError('Retained launcher identity is not an ordinary file.')
        files[str(path)] = sha(path)
        directories.update(str(parent) for parent in path.parents)
    if startup_tree is not None:
        for relative, row in startup_tree['files'].items():
            if relative.endswith('.pyc'):
                continue
            path = str(Path(startup_tree['root']) / relative)
            files[path] = row['sha256']
            if path.endswith('.so'):
                native.add(path)
        for relative, row in startup_tree['links'].items():
            files[row['resolved']] = row['sha256']
            files[str(Path(startup_tree['root']) / relative)] = row['sha256']
        directories.update(str(Path(startup_tree['root']) / relative) for relative in startup_tree['directories'])
    utc = public_utc_input(target)
    files[utc['resolved']] = utc['sha256']
    project = tomllib.loads((source / 'pyproject.toml').read_text())['project']
    release = load(HERE / 'release_update.py', 'operator_acceptance_release').release_manifest()
    if project['version'] != release['application_version']:
        raise RuntimeError('Acceptance application version differs from the selected release.')
    expected = {}
    for line in (HERE / 'reference/requirements/development-constraints.txt').read_text().splitlines():
        name, version = line.split('==')
        name = name.lower().replace('_', '-').replace('.', '-')
        expected[name] = release['packages'][name] if name in release['replacement_wheels'] else version
    allowed_native = set()
    prefixes = ('numpy/', 'pandas/', 'scipy/', 'ephem/', 'yaml/', 'google/')
    for path in native:
        if str(runtime / 'lib/python3.11/lib-dynload') + '/' in path:
            allowed_native.add(path)
        elif path.startswith(str(site) + '/') and path[len(str(site)) + 1:].startswith(prefixes):
            allowed_native.add(path)
    mapping = {}
    for path in sorted((source / 'src/satgs').rglob('*.py')):
        relative = path.relative_to(source / 'src')
        installed = site / relative
        installed_expected = hashlib.sha256(b'INSTALLED = True\n').hexdigest() if str(relative) == 'satgs/_package_layout.py' else sha(path)
        if installed.is_symlink() or not installed.is_file():
            raise RuntimeError('required installed G module is missing or nonordinary: ' + str(relative))
        if sha(installed) != installed_expected:
            raise RuntimeError('Installed candidate differs from selected G source: ' + str(relative))
        mapping[str(relative)] = dict(source=str(path), installed=str(installed), installed_sha256=installed_expected,
                                      source_sha256=sha(path),
                                      exemption='exact generated installed layout marker' if str(relative) == 'satgs/_package_layout.py' else None)
    owner_mapping = {}
    for component, relative_root in (('sat_tracker', 'src/ptu_control'), ('serialptu', 'serialptu'),
                                     ('meteor-api', 'src/meteor_api'), ('stomp.py', 'stomp')):
        canonical = ROOT / 'components' / component
        reference = HERE / 'reference/components' / component
        for subtree in (relative_root, 'tests'):
            original = {str(path.relative_to(canonical)): sha(path)
                        for path in sorted((canonical / subtree).rglob('*.py'))}
            copied = {str(path.relative_to(reference)): sha(path)
                      for path in sorted((reference / subtree).rglob('*.py'))}
            if original != copied:
                raise RuntimeError('Owner validation reference differs: ' + component + '/' + subtree)
            for relative, digest in original.items():
                if subtree == 'tests':
                    continue
                installed_relative = Path(relative).relative_to('src') if relative.startswith('src/') else Path(relative)
                installed = site / installed_relative
                if installed.is_symlink() or not installed.is_file() or sha(installed) != digest:
                    raise RuntimeError('Installed owner differs from candidate: ' + component + '/' + relative)
                owner_mapping[component + '/' + relative] = dict(source_sha256=digest, installed=str(installed))
    return dict(schema='operator-candidate-acceptance.v2', source=str(source), application=str(application),
                runtime=str(runtime), runtime_profile=profile, startup_tree=startup_tree,
                interpreter=str(application / 'bin/python'),
                scipy_rpath_absence=pi_science_absence() if startup_tree is not None else None,
                numpy_optional_metadata=numpy_metadata,
                inputs=files, directories=sorted(directories), native=sorted(allowed_native),
                input_identities={name: provenance.identity(name) for name in files},
                tests=str(source / 'tests'), expected_distributions=expected,
                component_tests=[str(HERE / 'reference/components' / name / 'tests') for name in
                                 ('meteor-api', 'sat_tracker', 'serialptu', 'pixhawk', 'stomp.py')],
                source_installed_mapping=mapping,
                owner_installed_mapping=owner_mapping,
                public_utc=utc,
                resource_sha256=sha(source / 'config/deployment_profiles.json'),
                tle_sha256=sha(source / 'src/satgs/data/operator_tle.csv'),
                example=str(HERE / 'reference/config/station.example.json'), environments=environments,
                launcher_source=str(ROOT / 'launchers'), workflow_tests=str(ROOT / 'tests'),
                runtime_application=str(runtime_application),
                ui_application=str(ui_application),
                guide_application=str(guide_application),
                handbook_application=str(handbook_application),
                ptu_application=str(ptu_application),
                bench_application=str(bench_application),
                jog_application=str(jog_application),
                jog2_application=str(jog2_application),
                hardware_enabled=False, network_enabled=False, services_enabled=False)


def unchanged(binding, target):
    if target.numpy_metadata_snapshot(Path(binding['application']) / 'lib/python3.11/site-packages') != binding['numpy_optional_metadata']:
        raise RuntimeError('selected NumPy optional metadata changed')
    if binding['startup_tree'] is not None:
        target.require(target.live_startup_policy(binding['startup_tree'], Path(binding['application'])) is True,
                       'retained Pi startup snapshot changed')
    current_utc = public_utc_input(target)['identities']
    recorded_utc = binding['public_utc']['identities']
    if (len(current_utc) != len(recorded_utc)
            or not all(target.utc_identity_matches(before, after) for before, after in zip(recorded_utc, current_utc))):
        raise RuntimeError('public UTC input source or ancestor identity changed')
    if binding['scipy_rpath_absence'] is not None and pi_science_absence() != binding['scipy_rpath_absence']:
        raise RuntimeError('Pi scientific native RPATH absence changed')
    WARNINGS.extend(provenance.current(binding))


def package_attempt(recording, attempt):
    allowed_root = {'binding.json', 'input-identities.json', 'phase-summary.json', 'inner-summary.json', 'inner-started.json',
                    'operator-context.json', 'provenance.json'}
    allowed_lane = {'attempt.json', 'result.json', 'stdout', 'stderr'}
    files, total = {}, 0
    for path in sorted(attempt.rglob('*')):
        recording.ordinary(path)
        relative = path.relative_to(attempt)
        if path.is_dir():
            recording.require((len(relative.parts) == 1 and relative.name in (*LANES, 'runner')) or
                              (relative.parts == ('native-widgets', 'screenshots')) or
                              (len(relative.parts) == 2 and relative.parts[0] == 'launcher'
                               and relative.parts[1] in ('unit', 'preparation', 'other-cwd')) or
                              (len(relative.parts) == 2 and relative.parts[0] == 'native-widgets'
                               and relative.parts[1] in ('server', 'child')), 'unexpected evidence directory')
            continue
        permitted = (len(relative.parts) == 1 and relative.name in allowed_root) or (
            len(relative.parts) == 2 and relative.parts[0] in (*LANES, 'runner') and relative.name in allowed_lane) or (
            len(relative.parts) == 2 and relative.parts[0] == 'native-widgets' and relative.name == 'owner-result.json') or (
            len(relative.parts) == 3 and relative.parts[0] == 'native-widgets'
            and relative.parts[1] in ('server', 'child') and relative.name in allowed_lane) or (
            len(relative.parts) == 3 and relative.parts[:2] == ('native-widgets', 'screenshots')
            and relative.name in SCREENSHOTS) or (
            len(relative.parts) == 3 and relative.parts[0] == 'launcher'
            and relative.parts[1] in ('unit', 'preparation', 'other-cwd') and relative.name in allowed_lane)
        recording.require(permitted, 'unexpected evidence member')
        data = recording.read(path)
        total += len(data)
        recording.require(total <= recording.MAX_EVIDENCE and len(files) < 120, 'evidence limit exceeded')
        files[str(relative)] = data
    partial = attempt / 'evidence.partial.tar.gz'
    with partial.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as archive:
            for name, data in files.items():
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), 0o600, 0
                archive.addfile(member, io.BytesIO(data))
        stream.flush()
        os.fsync(stream.fileno())
    with tarfile.open(partial, 'r:gz') as archive:
        recording.require(archive.getnames() == list(files), 'archive membership mismatch')
        for member in archive.getmembers():
            recording.require(member.isfile() and archive.extractfile(member).read() == files[member.name],
                              'archive content mismatch')
    final = attempt / 'evidence.tar.gz'
    os.link(partial, final)
    partial.unlink()
    digest = recording.digest(final)
    return dict(status='PASS', path=str(final), sha256=digest, files=len(files), uncompressed_bytes=total,
                excludes='final report/summary/completion bind the verified archive after packaging')


def report_text(summary):
    followup = summary.get('scope') == 'launcher-followup-functional-checks'
    preflight = summary.get('scope') == 'installed-origin-preflight'
    capture = summary.get('scope') == 'intermediate-host-widget-capture'
    headless = summary.get('scope') == 'host-headless-complement'
    jog = summary.get('scope') == 'host-jog-development'
    label = ('Host focused jog development: ' if jog else 'Host headless complement: ' if headless else 'Installed-origin preflight: ' if preflight else 'Intermediate host widget capture: ' if capture
             else 'Operator launcher follow-up: ' if followup else 'Operator protection selftest: '
             if summary.get('scope') == 'controls-only' else 'Operator handbook and bounded PTU functional check: ')
    lines = [label + summary['status'],
             'Application: ' + summary['application'], 'Source: ' + summary['source'],
             'Offline: no hardware, broker/database/Box, service activation, RF or PTU commands.',
             ('Host-only controls/static/installed origins plus core CLI, bench, owner, lower, source/update and launcher regressions. Native widgets are separate; this is not Pi or full acceptance.'
              if jog else 'Host headless handbook and selected shared/owner/source/update regressions. Native-widget results must be supplied separately; this is not Pi acceptance.'
              if headless else 'Controls, static and installed origins/resources only. No handbook, PTU behavior, source/update or native acceptance.'
              if preflight else 'Intermediate native-widget capture only. Final handbook assets and consolidated acceptance are not established.'
              if capture else 'This run covers controls, static, installed origins/resources and launcher checks only; product/native suites are not rerun.'
              if followup else 'Installed handbook, actual native widgets, bounded PTU command/readback paths, source/update workflow and selected integration regressions; no live-device qualification.')]
    lines.append('Python network/device/child effects remain denied; selected CPython/stdlib/native internals are trusted, not syscall isolation.'
                 if followup else 'Local desktop capability is explicit; tests own only their windows, not the desktop server. Python network/device/child effects remain denied. Trusted CPython/Tcl/Tk/native bootstrap is not hostile-code or syscall isolation.')
    for lane, row in summary['phases'].items():
        lines.append('%s: %s; child exit=%s; %s' %
                     (lane, row['status'], row.get('child_exit', 'NOT RUN'), row.get('reason',
                        row.get('result', {}).get('error_message', ''))))
    lines.extend(['Primary: ' + json.dumps(summary['primary'], sort_keys=True),
                  'Cleanup: ' + json.dumps(summary.get('cleanup', {}), sort_keys=True)
                      + ' (process/scratch supervision; native protection/window cleanup is recorded in its lane receipt)',
                  'Packaging: ' + json.dumps(summary['packaging'], sort_keys=True),
                  'Observed acceptance-runner exit: ' + str(summary.get('launcher', {}).get('observed_runner_exit', 'NOT OBSERVED')),
                  'Provenance: ' + json.dumps(summary.get('provenance', {}), sort_keys=True),
                  'Selected desktop: ' + json.dumps(summary.get('native_selection', {}), sort_keys=True),
                  'Development display fixture: ' + ('explicit host-only Tk9 scaling setup; no desktop/HiDPI qualification'
                      if summary.get('native_selection', {}).get('owned_host_fixture') else 'not selected'),
                  'Duration seconds: %.3f' % summary['duration_seconds'],
                  'Prior bounded Pixhawk PASS is carried forward only for its unchanged matching baseline scope.',
                  ('Prior product/native results remain separate evidence; this launcher follow-up does not establish full UI or physical acceptance.'
                   if followup else 'Automated native coverage is only the actual reported widget lane, not operator smoke or physical qualification.'),
                  'Navigation, calibrated heading, absolute time and physical readiness remain unqualified.',
                  'Completion binds report/summary; the verified archive contains actual child records, not scratch fixtures.'])
    return '\n'.join(lines) + '\n'


def _desktop_binding(binding, descriptor):
    roots = [Path(name) for name in descriptor.get('resource_roots', ())]
    if roots:
        files, directories, native = inventory(roots)
        binding['inputs'].update(files)
        binding['directories'] = sorted(set(binding['directories']) | directories)
        binding['native'] = sorted(set(binding['native']) | native)
    for name in descriptor.get('resource_files', ()):
        path = Path(name)
        if not path.is_absolute() or not path.is_file() or path.is_symlink():
            raise UnsupportedRuntime('desktop resource must be an ordinary absolute file')
        binding['inputs'][name] = sha(path)
    binding['directories'] = sorted(set(binding['directories']) | set(descriptor.get('resource_directories', ())))
    for name in descriptor.get('metadata_read_paths', ()):
        path = Path(name)
        if path == Path('/proc/self/maps'):
            continue
        if name == (descriptor.get('authority') or {}).get('path') or private_authority(path):
            continue
        if path.is_file() and not path.is_symlink():
            binding['inputs'][name] = sha(path)
    binding['input_identities'] = {name: provenance.identity(name) for name in binding['inputs']}


def run_attempt(args):
    recording = load(HERE / 'recording.py', 'acceptance_recording')
    target = load(HERE / 'pi_target.py', 'pi_target')
    attempt = recording.ordinary(args.attempt)
    if not attempt.is_dir():
        raise FileNotFoundError('outer launcher must allocate a fresh attempt')
    recording.write_json(attempt / 'inner-started.json', dict(pid=os.getpid()))
    started = time.monotonic()
    selected_lanes, scope = route(args)
    summary = dict(schema='operator-consolidated-acceptance.v2', status='BLOCKED',
                   scope=scope,
                   application=str(args.application), source=str(args.source),
                   phases={lane: dict(status='NOT RUN') for lane in selected_lanes}, primary=None,
                   cleanup=dict(status='NOT RUN'), capture_errors=[], packaging=dict(status='NOT RUN'),
                   signals=[], native_selection={}, provenance={})
    interrupts = recording.Interrupts()
    previous = {number: signal.signal(number, interrupts.handler) for number in (signal.SIGINT, signal.SIGTERM)}
    binding = None
    native_context = descriptor = desktop = None
    try:
        runtime_root = declared_runtime(args.application, recording)
        if any(attempt == root or root in attempt.parents for root in (HERE, args.source, args.application, runtime_root)):
            raise RuntimeError('acceptance output must not overlap support/source/application/runtime')
        WARNINGS.extend(provenance.optional_checksums(HERE))
        environments = {lane: dict(target.ENV) for lane in LANES}
        runtime, profile, startup_tree = application_runtime(args.application, recording, target)
        target.require(runtime == runtime_root, 'runtime changed during admission')
        if getattr(args, 'headless_development', False) and profile != 'compatible-host-cpython31116-no-startup-hooks':
            raise UnsupportedRuntime('Headless complement is a host-development route, not reduced Pi acceptance.')
        native_reason = None
        try:
            if (args.controls_only or getattr(args, 'launcher_followup', False)
                    or getattr(args, 'installed_preflight', False) or getattr(args, 'headless_development', False)):
                raise UnsupportedRuntime('selected check route does not select a desktop')
            desktop = load(HERE / 'desktop_display.py', 'operator_desktop')
            owned_scratch = getattr(args, 'owned_host_native_scratch', None)
            if owned_scratch is not None:
                recording.require(args.owned_host_display_fixture, 'owned native scratch requires the host fixture')
                scratch_path = recording.ordinary(owned_scratch)
                recording.require(scratch_path.name == 'application'
                                  and scratch_path.parent.name.startswith('owned-desktop-')
                                  and scratch_path.parent.parent == attempt.parents[1]
                                  and os.environ.get('XAUTHORITY') == str(scratch_path.parent / 'authority'),
                                  'Native capture scratch differs from this output-owned display authority.')
                recording.require((scratch_path / 'framebuffer/Xvfb_screen0').is_file(), 'owned framebuffer is missing')
            else:
                native_context = tempfile.TemporaryDirectory(prefix='operator-native-', dir=attempt.parent)
                scratch_path = Path(native_context.name)
            descriptor = desktop.select_from_environment(args.application, scratch_path,
                owned_host_fixture=getattr(args, 'owned_host_display_fixture', False))
            descriptor['framebuffer_capture'] = owned_scratch is not None
            environments['native-widgets'] = desktop.child_environment(target.ENV, descriptor)
            summary['native_selection'] = descriptor
        except (OSError, RuntimeError, ValueError) as error:
            native_reason = recording.error_text(error)
            summary['native_selection'] = (dict(status='NOT RUN', reason=native_reason)
                if any(getattr(args, name, False) for name in
                       ('launcher_followup', 'installed_preflight', 'headless_development', 'controls_only')) else dict(status='BLOCKED', reason=native_reason,
                previous_r3='native was host-only and stripped DISPLAY; this does not show Tk unavailable'))
        binding = bind(args.source, args.application, runtime, environments, profile, startup_tree, target)
        binding['startup_diagnostic'] = getattr(args, 'startup_diagnostic', False)
        summary['startup_diagnostic'] = binding['startup_diagnostic']
        if descriptor is not None:
            descriptor['startup_diagnostic'] = binding['startup_diagnostic']
        binding['native_display'] = descriptor
        binding['network_policy'] = 'Python network/device/process effects denied; explicit selected local desktop only; native bootstrap trust is not syscall isolation'
        if descriptor is not None:
            _desktop_binding(binding, descriptor)
        target.startup_policy(args.application)
        recording.write_json(attempt / 'binding.json', binding)
        recording.write_json(attempt / 'input-identities.json', binding['inputs'])
        installed_ok = False
        for lane in selected_lanes:
            if binding['startup_diagnostic'] and lane != 'native-widgets':
                summary['phases'][lane] = dict(status='NOT RUN', reason='Startup diagnostic only; not acceptance.')
                continue
            if not binding['startup_diagnostic'] and lane not in ('controls', 'static', 'installed') and not installed_ok:
                summary['phases'][lane] = dict(status='NOT RUN',
                    reason='Dependent installed compatibility/origin/resource check did not pass.')
                continue
            if lane == 'native-widgets' and descriptor is None:
                summary['phases'][lane] = dict(status='BLOCKED', reason=native_reason)
                continue
            unchanged(binding, target)
            if lane == 'launcher':
                summary['phases'][lane] = dict(status='FAIL', reason='Launcher checks did not complete.')
                launcher = load(HERE / 'launcher_checks.py', 'launcher_checks_parent')
                with tempfile.TemporaryDirectory(prefix='operator-launcher-', dir=attempt.parent) as scratch:
                    summary['phases'][lane] = launcher.run(binding, scratch, attempt, target, recording)
                unchanged(binding, target)
                if summary['phases'][lane]['status'] != 'PASS' and summary['primary'] is None:
                    summary['primary'] = dict(phase=lane, type='LauncherFailure',
                        message=summary['phases'][lane].get('reason', 'Launcher checks did not pass.'))
                continue
            with tempfile.TemporaryDirectory(prefix='operator-lane-', dir=attempt.parent) as scratch:
                if lane == 'native-widgets':
                    scratch = descriptor.get('scratch', scratch)
                if lane == 'docs-examples':
                    launcher = load(HERE / 'launcher_checks.py', 'guide_launcher_preparation')
                    launcher.prepare(binding, scratch, recording)
                command = [binding['interpreter'], '-I', '-B', '-S', str(HERE / 'child.py'),
                           '--binding', str(attempt / 'binding.json'), '--lane', lane, '--scratch', str(scratch)]
                result = target.supervise(command, attempt / lane, cwd=HERE,
                                          environment=environments[lane], timeout=120,
                                          cap=8 * 1024 * 1024 if lane == 'native-widgets' else 1024 * 1024)
            unchanged(binding, target)
            output = (attempt / lane / 'stdout').read_text(errors='replace').splitlines()
            rows = [json.loads(line[len('OPERATOR_LANE_RESULT '):]) for line in output
                    if line.startswith('OPERATOR_LANE_RESULT ')]
            row = rows[0] if len(rows) == 1 else dict(status='FAIL',
                runner_error='MissingOrAmbiguousChildResult',
                error_message=(attempt / lane / 'stderr').read_text(errors='replace')[-2000:])
            if lane == 'native-widgets' and row.get('ui_screenshots', {}).get('owned_host') is True:
                captures = row['ui_screenshots']['checkpoints']
                recording.require(len(captures) == len(SCREENSHOTS) and {item['label'] + '.png' for item in captures} == SCREENSHOTS,
                                  'Owned UI screenshot checkpoints differ from the fixed set.')
                directory = attempt / 'native-widgets/screenshots'
                directory.mkdir(mode=0o700)
                for item in captures:
                    name = item['label'] + '.png'
                    recording.require(item['status'] == 'CAPTURED' and item['relative'] == 'screenshots/' + name,
                                      'Invalid owned UI screenshot receipt.')
                    data = target.read(Path(descriptor['scratch']) / 'screenshots' / name, limit=8 * 1024 * 1024)
                    recording.require(len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
                                      and data.startswith(b'\x89PNG\r\n\x1a\n'), 'Owned UI PNG bytes differ.')
                    descriptor_fd = os.open(directory / name,
                        os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
                    with os.fdopen(descriptor_fd, 'wb') as stream:
                        stream.write(data)
                        stream.flush()
                        os.fsync(stream.fileno())
            supervised = target.supervision_passed(result)
            clean_blocked = result.get('exit') == result.get('final_exit') == 78 and target.supervision_passed(dict(result, exit=0))
            status = 'PASS' if supervised and row.get('status') == 'PASS' else 'BLOCKED' if clean_blocked and row.get('status') == 'BLOCKED' else 'FAIL'
            summary['phases'][lane] = dict(status=status, child_exit=result.get('exit'),
                                           supervision=result, result=row)
            WARNINGS.extend(row.get('provenance_warnings', ()))
            if status == 'FAIL' and summary['primary'] is None:
                summary['primary'] = dict(phase=lane, type=row.get('runner_error', 'FunctionalFailure'),
                    message=row.get('error_message', 'Failed assertions, protection or child supervision; see retained raw output.'))
            if lane == 'installed':
                installed_ok = status == 'PASS'
            if lane == 'controls' and status != 'PASS':
                break
        statuses = {row['status'] for row in summary['phases'].values()}
        summary['status'] = 'FAIL' if 'FAIL' in statuses else 'BLOCKED' if statuses != {'PASS'} else 'PASS'
        if binding['startup_diagnostic']:
            summary['status'] = 'FAIL' if 'FAIL' in statuses else 'BLOCKED'
            if summary['primary'] is None:
                summary['primary'] = dict(type='StartupDiagnosticOnly',
                    message='Startup diagnostic only; review observed startup records; not acceptance.')
        if summary['status'] == 'BLOCKED' and summary['primary'] is None:
            lane, row = next((lane, row) for lane, row in summary['phases'].items() if row['status'] != 'PASS')
            summary['primary'] = dict(phase=lane, type='RequiredCoverageBlocked',
                message=row.get('reason', row.get('result', {}).get('error_message', 'required coverage was not executed')))
        if interrupts.received:
            summary['status'] = 'FAIL'
            summary['primary'] = dict(type='RunInterrupted', message='operator interruption')
        summary['cleanup'] = dict(status='PASS' if all(
            row.get('supervision', {}).get('quiescent', True)
            and not row.get('supervision', {}).get('cleanup_errors')
            and not row.get('supervision', {}).get('residual_descendants')
            for row in summary['phases'].values()) and all(
            observed.get('quiescent') is True and not observed.get('cleanup_errors')
            and not observed.get('residual_descendants')
            for row in summary['phases'].values() for observed in row.get('additional_supervision', ())) else 'FAIL')
        if summary['cleanup']['status'] != 'PASS':
            summary['status'] = 'FAIL'
    except BaseException as error:
        summary['status'] = 'BLOCKED' if binding is None and isinstance(error, (FileNotFoundError, UnsupportedRuntime)) else 'FAIL'
        summary['primary'] = dict(type=type(error).__name__, message=recording.error_text(error))
    finally:
        interrupts.finalizing = True
        summary['signals'] = list(interrupts.received)
        summary['duration_seconds'] = time.monotonic() - started
        if native_context is not None:
            try:
                native_context.cleanup()
            except BaseException as error:
                summary['status'] = 'FAIL'
                summary['cleanup'] = dict(status='FAIL', error=recording.error_text(error))
        summary['provenance'] = provenance.summary(WARNINGS)
        recording.write_json(attempt / 'phase-summary.json', summary['phases'])
        recording.write_json(attempt / 'inner-summary.json', summary)
        for number, handler in previous.items():
            signal.signal(number, handler)
    return 0 if summary['status'] == 'PASS' else 78 if summary['status'] == 'BLOCKED' else 1


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--source', type=Path, default=HERE / 'reference/ground_station')
    parser.add_argument('--application', type=Path, required=True)
    parser.add_argument('--attempt', type=Path, required=True)
    parser.add_argument('--owned-host-display-fixture', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--owned-host-native-scratch', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--capture-widgets-only', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--installed-preflight', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--headless-development', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--jog-development', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--startup-diagnostic', action='store_true')
    parser.add_argument('--controls-only', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--launcher-followup', action='store_true',
                        help='Check launcher wiring without repeating product/native suites.')
    args = parser.parse_args()
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise RuntimeError('use the isolated no-site operator launcher')
    route(args)
    args.application, args.source = args.application.resolve(), args.source.resolve()
    args.attempt = Path(os.path.abspath(args.attempt))
    return run_attempt(args)


if __name__ == '__main__':
    raise SystemExit(main())
