#!/bin/bash

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    printf '%s\n' 'Use: . ./launchers/setup_daily.sh [--select jog3|jog2|jog|bench|ptu|handbook|guide|ui|runtime]' >&2
    exit 2
fi
if declare -F satgs_ui_daily_setup >/dev/null; then
    printf '%s\n' 'Existing setup function was preserved; setup not run.' >&2
    return 2
fi

satgs_ui_daily_setup() {
    local satgs_launcher_dir satgs_setup_status
    satgs_launcher_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || return
    /usr/bin/python3 -I -B -S "$satgs_launcher_dir/daily.py" "$@"
    satgs_setup_status=$?
    if [ "$satgs_setup_status" -ne 0 ]; then
        return "$satgs_setup_status"
    fi
    case "$PATH" in
        "$HOME/.local/bin"|"$HOME/.local/bin":*) ;;
        *) export PATH="$HOME/.local/bin:$PATH" ;;
    esac
    if [ "$(type -t satgs-operator)" != file ] || [ "$(command -v satgs-operator)" != "$HOME/.local/bin/satgs-operator" ]; then
        printf '%s\n' 'A shell alias or function still overrides satgs-operator; it was preserved.' >&2
        return 1
    fi
    printf '%s\n' 'Ready in this terminal: satgs-operator status' \
        'GUI: choose SATGS in the desktop application menu.' \
        'Other terminals: check command lookup there; shell profiles were not changed.'
}

if satgs_ui_daily_setup "$@"; then
    unset -f satgs_ui_daily_setup
    return 0
else
    unset -f satgs_ui_daily_setup
    return 1
fi
