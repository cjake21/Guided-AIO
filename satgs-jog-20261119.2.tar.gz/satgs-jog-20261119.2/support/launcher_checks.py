"""Compositional launch checks retain the existing product effect protections."""

from contextlib import redirect_stdout
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import runpy
import os
import secrets
import stat
import sys


FIXTURE_COUNTS = {
    'test_daily_launchers.py': 61,
    'test_source_workflow.py': 22,
    'test_ui_capture.py': 4,
    'test_launcher_checks.py': 9,
}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _directory(path):
    info = Path(path).lstat()
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid()
            or stat.S_IMODE(info.st_mode) != 0o700):
        raise RuntimeError('Launcher fixture directory is not private and owned.')
    return [info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid]


def _identities(binding):
    return {
        'runtime': dict(application=binding['runtime_application'], candidate_version='0.0.1+runtime.20261110.1'),
        'ui': dict(application=binding['ui_application'], candidate_version='0.0.1+ui.20261111.1'),
        'guide': dict(application=binding['guide_application'], candidate_version='0.0.1+guide.20261112.1'),
        'handbook': dict(application=binding['handbook_application'], candidate_version='0.0.1+handbook.20261112.1'),
        'ptu': dict(application=binding['ptu_application'], candidate_version='0.0.1+ptu.20261117.1'),
        'bench': dict(application=binding['bench_application'], candidate_version='0.0.1+bench.20261118.1'),
        'jog': dict(application=binding['jog_application'], candidate_version='0.0.1+jog.20261118.1'),
        'jog2': dict(application=binding['jog2_application'], candidate_version='0.0.1+jog.20261118.2'),
        'jog3': dict(application=binding['jog3_application'], candidate_version='0.0.1+jog.20261118.3'),
        'jog4': dict(application=binding['jog4_application'], candidate_version='0.0.1+jog.20261119.1'),
        'jog5': dict(application=binding['application'], candidate_version='0.0.1+jog.20261119.2'),
    }


def _managed(home):
    return (home / '.local/share/satgs-launchers/jog-20261119-v2/daily.py',
            home / '.config/satgs/operator.json', home / '.local/bin/satgs-operator',
            home / '.local/bin/satgs-operator-gui',
            home / '.local/share/applications/satgs-runtime-20261110.desktop')


def prepare(binding, scratch, recording):
    scratch, home = Path(scratch), Path(scratch) / 'home'
    home.mkdir(mode=0o700)
    (home / 'satgs').mkdir(mode=0o700)
    products = ('satgs', 'ptu_control', 'serialptu', 'meteor_api', 'pixhawk')
    before = {name for name in sys.modules if name.split('.', 1)[0] in products}
    source = Path(binding['launcher_source']) / 'daily.py'
    recording.require(_sha(source) == binding['inputs'][str(source)], 'Bound launcher source changed.')
    module = _module(source, 'source_real_daily_launcher')
    identities = _identities(binding)
    prepared = module.prepare(home, identities=identities)
    station = home / 'satgs/station'
    station.mkdir(mode=0o700)
    settings = {
        'satgs_operator_workspace': dict(schema_version=1, id=secrets.token_hex(16), root=str(station)),
        'ground_station_name': 'Station', 'ground_station_configured': False,
        'ground_station_lat': None, 'ground_station_lon': None, 'ground_station_altm': None,
        'operator': dict(case='pelican-qpt130', generation=1, selection=None,
                         altitude_reference='unspecified', replay_state='unknown',
                         provenance='synthetic_scratch_not_operational', last_operation=None),
    }
    recording.write_json(station / 'station.json', settings)
    selected = module.select(home, 'jog5', identities=identities)
    recording.require(before == {name for name in sys.modules if name.split('.', 1)[0] in products}
                      and json.loads((station / 'station.json').read_text()) == settings,
                      'Passive launcher preparation imported owners or changed fixture station settings.')
    row = dict(status='PASS', prepare=prepared, selection=selected, home=str(home),
               directories={str(path): _directory(path) for path in (scratch, home, home / 'satgs')},
               identities=identities, source=dict(path=str(source), sha256=_sha(source)),
               station=dict(path=str(station / 'station.json'), sha256=_sha(station / 'station.json'),
                            role='Synthetic managed fixture using the current initializer shape; not product initialization.'),
               generated={str(path): _sha(path) for path in _managed(home)},
               scope='Source-real helper and exact passive StationLease in fresh owned scratch; no owner imports or acquisition.')
    recording.write_json(scratch / 'launcher-preparation.json', row)
    return row


def check(binding, scratch, *, followup=False):
    from satgs.operator_core import Workspace, initialize_workspace

    scratch = Path(scratch)
    home = scratch / 'home'
    preparation_path = scratch / 'launcher-preparation.json'
    if preparation_path.stat().st_size > 65536:
        raise RuntimeError('Launcher preparation receipt exceeds its bound.')
    preparation = json.loads(preparation_path.read_text())
    source = Path(binding['launcher_source']) / 'daily.py'
    directories = {str(path): _directory(path) for path in (scratch, home, home / 'satgs')}
    generated = {str(path): _sha(path) for path in _managed(home)}
    selected = dict(schema='satgs-daily-selection.v1', application=binding['application'],
                    workspace=str(home / 'satgs/station'), candidate_version='0.0.1+jog.20261119.2')
    if (preparation['home'] != str(home) or preparation['directories'] != directories
            or preparation['identities'] != _identities(binding) or preparation['generated'] != generated
            or preparation['source'] != dict(path=str(source), sha256=binding['inputs'][str(source)])
            or json.loads((home / '.config/satgs/operator.json').read_text()) != selected):
        raise RuntimeError('Source-real launcher preparation identity differs from the bound fixture.')
    manifest = scratch / 'launcher-fixture.json'
    if not followup:
        default = Workspace(home / 'satgs/station')
        if (preparation['station']['path'] != str(default.station_path)
                or preparation['station']['sha256'] != _sha(default.station_path)):
            raise RuntimeError('Prepared synthetic default station changed.')
        override = initialize_workspace(scratch / 'other-station')
        protected = (default.station_path, override.station_path, *_managed(home), preparation_path)
        fixture = dict(home=str(home), default=default.inspect(), override=override.inspect(),
                       protected={str(path): _sha(path) for path in protected},
                       cli=str(home / '.local/bin/satgs-operator'),
                       selected_application=binding['application'])
        manifest.write_text(json.dumps(fixture, sort_keys=True) + '\n')
    else:
        if manifest.stat().st_size > 65536:
            raise RuntimeError('Launcher fixture manifest exceeds its bound.')
        fixture = json.loads(manifest.read_text())
    protected = (home / 'satgs/station/station.json', scratch / 'other-station/station.json',
                 *_managed(home), preparation_path)
    if (fixture['home'] != str(home) or fixture['selected_application'] != binding['application']
            or set(fixture['protected']) != {str(path) for path in protected}
            or not all(_sha(path) == fixture['protected'][str(path)] for path in protected)):
        raise RuntimeError('Prepared launcher fixture changed.')
    dispatcher = _managed(home)[0]
    daily = _module(dispatcher, 'generated_daily_dispatcher')
    if daily.registered() != _identities(binding):
        raise RuntimeError('Generated dispatcher application profile differs from the bound fixture.')
    cases = [('other-cwd', ['--format', 'json', 'status'], fixture['default'])] if followup else [
        ('help', ['--help'], None),
        ('status', ['--format', 'json', 'status'], fixture['default']),
        ('override', ['--workspace', str(scratch / 'other-station'), '--format', 'json', 'status'], fixture['override']),
    ]
    records = []
    for name, arguments, expected in cases:
        interpreter, command, environment = daily.launch_plan('cli', arguments, home / '.config/satgs/operator.json')
        prefix = [str(Path(binding['application']) / 'bin/python'), '-I', '-B',
                  str(Path(binding['application']) / 'bin/satgs-operator')]
        if (interpreter != prefix[0] or command[:4] != prefix
                or environment.get('STOMP_SKIP_HOSTNAME_SCAN') != '1'
                or environment.get('PYTHONNOUSERSITE') != '1'):
            raise RuntimeError('Source-real dispatch plan leaves the bound application.')
        previous = sys.argv
        output = io.StringIO()
        code = 0
        try:
            sys.argv = command[3:]
            with redirect_stdout(output):
                try:
                    runpy.run_path(command[3], run_name='__main__')
                except SystemExit as error:
                    code = error.code
        finally:
            sys.argv = previous
        text = output.getvalue()
        if code not in (0, None):
            raise RuntimeError('Actual guarded CLI entry point failed: ' + name)
        if name == 'help':
            if 'usage:' not in text or 'satgs-operator' not in text:
                raise RuntimeError('Actual guarded CLI help is missing.')
        elif json.loads(text) != dict(status='PASS', result=expected):
            raise RuntimeError('Actual guarded CLI result differs from the selected fixture.')
        if not all(_sha(path) == fixture['protected'][str(path)] for path in protected):
            raise RuntimeError('Read-only CLI changed a station or shared selection.')
        if {str(path): _directory(path) for path in (scratch, home, home / 'satgs')} != directories:
            raise RuntimeError('Read-only CLI changed the prepared home identity.')
        records.append(dict(case=name, command=command, cwd=str(Path.cwd()), exit=0,
                            interpreter=interpreter, output=text))
    return dict(actual_installed_cli_calls=records, default_and_station_preserved=True,
                execution='Installed console source under existing guarded genuine site; no exec or subprocess permission.',
                os_launch_scope='Generated shell/dispatcher OS execution is fixture-only in the separate stdlib suite.',
                real_ordinary_shell_bootstrap='NOT VERIFIED', daily_station_touched=False)


def _lane_row(path):
    lines = path.read_text(errors='replace').splitlines()
    rows = [json.loads(line.removeprefix('OPERATOR_LANE_RESULT '))
            for line in lines if line.startswith('OPERATOR_LANE_RESULT ')]
    if len(rows) != 1:
        raise RuntimeError('Launcher child result is missing or ambiguous.')
    return rows[0]


def _fixture_failure(stderr, supervised):
    if not supervised:
        return 'Launcher stdlib fixture tests failed.'
    counts = re.findall(r'^Ran ([0-9]+) tests? in ', stderr, re.MULTILINE)
    expected = sum(FIXTURE_COUNTS.values())
    if len(counts) != 1 or int(counts[0]) != expected:
        observed = ', '.join(counts) if counts else 'missing'
        return 'Launcher fixture count differs: expected %d; observed %s.' % (expected, observed)
    if stderr.rstrip().splitlines()[-1] != 'OK':
        return 'Launcher fixture suite is skipped, incomplete or unsuccessful.'
    return None


def run(binding, scratch, attempt, target, recording):
    scratch, attempt = Path(scratch), Path(attempt)
    lane = attempt / 'launcher'
    lane.mkdir(mode=0o700)
    environment = dict(target.ENV)
    unit_command = [binding['interpreter'], '-I', '-B', '-S', '-m', 'unittest', 'discover',
                    '-s', str(Path(binding['launcher_source']).parent / 'tests'),
                    '-p', 'test_*.py', '-v']
    unit = target.supervise(unit_command, lane / 'unit', cwd=Path(binding['launcher_source']).parent,
                            environment=environment, timeout=120, cap=1024 * 1024)
    stderr = recording.read(lane / 'unit/stderr').decode()
    reason = _fixture_failure(stderr, target.supervision_passed(unit))
    if reason is not None:
        return dict(status='FAIL', child_exit=unit.get('exit'), reason=reason, supervision=unit,
                    result=dict(status='FAIL', error_message=reason, unit_supervision=unit,
                                actual_cli_calls=0, scope='Launcher fixture checks; guarded CLI was not run.'))
    preparation = prepare(binding, scratch, recording)
    preparation_bytes = recording.read(scratch / 'launcher-preparation.json')
    observations, rows = [], []
    for index, name in enumerate(('preparation', 'other-cwd')):
        cwd = scratch / ('cwd-one' if index == 0 else 'cwd-two')
        cwd.mkdir(mode=0o700)
        command = [binding['interpreter'], '-I', '-B', '-S', str(Path(__file__).parent / 'child.py'),
                   '--binding', str(attempt / 'binding.json'), '--lane', 'launcher', '--scratch', str(scratch)]
        if index:
            command.append('--launcher-followup')
        observed = target.supervise(command, lane / name, cwd=cwd, environment=environment,
                                    timeout=120, cap=1024 * 1024)
        observations.append(observed)
        recording.require(target.supervision_passed(observed), 'Guarded actual CLI checks failed: ' + name)
        recording.require(recording.read(scratch / 'launcher-preparation.json') == preparation_bytes
                          and all(_sha(path) == digest for path, digest in preparation['generated'].items()),
                          'Launcher preparation changed during actual CLI execution.')
        row = _lane_row(lane / name / 'stdout')
        recording.require(row['status'] == 'PASS' and row['runtime_denials'] == [] and row['negative_controls'] == 42,
                          'Actual CLI effect controls failed.')
        rows.append(row)
    rows[0].update(scope='Launcher fixture OS execution plus guarded real installed CLI composition',
                   unit_tests=sum(FIXTURE_COUNTS.values()),
                   unit_fixture_counts=dict(FIXTURE_COUNTS),
                   unit_scope='Reviewed support fixtures; no owner acquisition.',
                   stdlib_preparation=preparation,
                   actual_cli_calls=sum(
                       len(row['launcher_checks']['actual_installed_cli_calls']) for row in rows),
                   followup_result=rows[1], unit_supervision=unit)
    return dict(status='PASS', child_exit=observations[0]['exit'], supervision=observations[0],
                additional_supervision=[unit, observations[1]], result=rows[0])
