#!/usr/bin/python

###############################################################################
# Description:  Pan/Tilt control framework
#
# Developer(s): Collin Hockey <chockey@mitre.org>
###############################################################################
# NOTICE
#
# This software was produced for the U.S. Government
# under Contract No. F19628-99-C-0001, and is
# subject to the Rights in Noncommercial Computer Software
# and Noncommercial Computer Software Documentation Clause
# (DFARS) 252.227-7014 (JUN 1995)
#
# COPYRIGHT 2012 The MITRE Corporation
###############################################################################

import errno
import logging
import math
from contextlib import contextmanager
from dataclasses import dataclass
import serial
import threading
import time
from typing import Optional

from serialptu import errors
from serialptu import util
from serialptu.acquisition import (AcquisitionError, ReadbackContext, SerialDeviceIdentity,
                                   SerialSettings, claim_selected_device, verify_selected_device)



class PointingError(RuntimeError):
    """Fixed failure code and observed serial submission disposition."""

    def __init__(self, primary, submission="none", written=None):
        super().__init__(primary)
        self.primary = primary
        self.submission = submission
        self.written = written


class _PointingHandle:
    __slots__ = ("_stamp", "binding", "capability")

    def __init__(self, stamp, binding, capability="pointing"):
        object.__setattr__(self, "_stamp", stamp)
        object.__setattr__(self, "binding", binding)
        object.__setattr__(self, "capability", capability)

    def __setattr__(self, name, value):
        raise AttributeError("immutable-pointing-handle")

    def __delattr__(self, name):
        raise AttributeError("immutable-pointing-handle")


class _PreparedMove:
    __slots__ = ("_stamp", "_handle", "generation", "packet", "pan_units",
                 "tilt_units", "units_per_degree")

    def __init__(self, stamp, handle, generation, packet, coordinates):
        for name, value in (("_stamp", stamp), ("_handle", handle),
                            ("generation", generation), ("packet", packet),
                            ("pan_units", coordinates[0]), ("tilt_units", coordinates[1]),
                            ("units_per_degree", coordinates[2])):
            object.__setattr__(self, name, value)

    def __setattr__(self, name, value):
        raise AttributeError("immutable-prepared-move")

    def __delattr__(self, name):
        raise AttributeError("immutable-prepared-move")


@dataclass(frozen=True)
class _PreparedJog:
    _stamp: object
    _handle: object
    generation: int
    packet: bytes
    pan_velocity: int
    tilt_velocity: int
    velocity_scale: int


@dataclass(frozen=True)
class ExchangeReceipt:
    sequence: int
    operation: str
    request: bytes
    response: bytes
    response_truncated: bool
    started_monotonic: float
    finished_monotonic: float
    category: str
    submission: str
    written: Optional[int]
    interrupted_sequence: Optional[int] = None
    interrupted_response_prefix: bytes = b""
    interrupted_response: bytes = b""


class PTU:

    class KeepAlive(threading.Thread):
        """Internal keepalive thread.

        Periodically polls the PTU for status.
        """

        def __init__(self, ptu, rate=0.3):
            ptu._require_legacy()
            super(PTU.KeepAlive, self).__init__()
            self._ptu = ptu
            self._shutdown = threading.Event()
            self._last_status_time = -1
            self._rate_lock = threading.Lock()
            with self._rate_lock: self._rate = rate

            self.established = threading.Event()

        def run(self):
            while not self._shutdown.is_set():
                try:
                    if not self.established.is_set():
                        ret = self._ptu.get_status(timeout = .5, establishing = True)
                        if ret[0]:
                            self.established.set()
                            continue

                    else:
                        # Send a keep-alive message every second if no other message has
                        # been sent. If the keep-alives timeout enough times the unit has
                        # been disconnected.
                        with self._rate_lock: rate = self._rate

                        if time.time() - self._last_status_time > rate:
                            self._last_status_time = time.time()
                            ret = self._ptu.get_status(timeout = .5, establishing = True)
                            if ret[0]:
                                self._ptu._status_signal.fire(ret[1])

                    time.sleep(0.1)
                except errors.TimeoutError as e:
                    pass # Ignore these, we're keeping the connection alive, if it dies, we don't care
                except errors.CorruptedMessageError as e:
                    pass # Ignore these, we're keeping the connection alive, if it dies, we don't care?

        def set_rate(self, rate):
            """
            Set a rate for status queries, a minimum of 1/10 second.
            """
            with self._rate_lock: self._rate = rate

        def stop(self):
            self._shutdown.set()

    def __init__(self, protocol, port, baud=57600, timeout=0.5, retries = 1, logger=None, rate=0.3, *,
                 pointing=False, serial_settings=None, device_identity=None, serial_capability="readback"):
        """
        Set up a PTU to be used.

        protocol: One of "PTCR20" (Some QPT-130s), "PTCR96" (QPT-200), "PRC90" (QPT-50)
        port: The COM or tty port the PTU is attached to
        baud: Baud rate to use, most units support at least 57600, which is the default.
        timeout: Default timeout to use waiting for a response message. (This
                 can be overridden for specific calls if needed)
        retries: Number of times retrying a message before reporting failure
        logger: Logger to use. If left at None, a NullHandler will be used and
                no log messages will be output from the library.
        """
        if type(pointing) is not bool:
            raise PointingError("pointing-admission")
        if (type(serial_capability) is not str or serial_capability not in ("readback", "manual")
                or (serial_settings is None and serial_capability != "readback")):
            raise PointingError("serial-context")
        if serial_settings is not None or device_identity is not None:
            if (not pointing or type(serial_settings) is not SerialSettings
                    or type(device_identity) is not SerialDeviceIdentity
                    or serial_settings.port != port or serial_settings.baudrate != baud):
                raise PointingError("serial-context")
        self._serial_settings = serial_settings
        self._device_identity = device_identity
        self._serial_capability = serial_capability if serial_settings is not None else None
        self._device_snapshot = None
        self._exchange_sequence = 0
        self._last_exchange = None
        self._establishment_exchanges = ()
        self._interrupted_jog = None
        self._jog_stop_reconciled = False
        self._pointing = pointing
        self._pointing_stamp = object()
        self._pointing_handle = None
        self._pointing_profile = None
        self._pointing_protocol = None
        self._pointing_serial = None
        self._pointing_generation = 0
        self._pointing_blocked = False
        self._pointing_stop_requested = False
        self._pointing_closed = False
        self._pointing_closing = False
        self._pointing_context_invalid = False
        self._pointing_guard_thread = None
        self._pointing_guard_depth = 0
        self._pointing_guard_deadline = None
        self._pointing_guard_cancel = None
        self._protocol = protocol
        self._timeout = timeout
        self._logger = logger
        self._retries = retries
        self._status_signal = util.Signal()

        if not pointing and self._logger is None:
            self._logger = logging.getLogger('quickset.PTU')
            self._logger.addHandler(logging.NullHandler())

        self._lock = threading.RLock()

        self._serial = serial.Serial(baudrate=baud, timeout=0, exclusive=True)
        self._serial.port = port
        if serial_settings is not None:
            serial_settings.apply(self._serial)
        self._interface = util.BufferedSerial(self._serial, eop=self._protocol.get_end_of_packet(),
                                              open_on_init=not pointing)
        self._connected = False
        self._last_tx_time = -1
        self._keepalive = None
        self.rate = rate

        if not pointing:
            self._logger.info("PTU initialized (Port: {}; Baud: {}; Protocol: {})".format(
                port, baud, self._protocol.__class__.__name__))

    @property
    def protocol(self):
        """
        Get a reference to the protocol in use
        """
        return self._protocol

    def connect_status_listener(self, listener):
        """Connect an observer listening for PTU status updates.

        Status updates include the current position and any errors.

        listener: A callable object which takes one parameter. The information
                  will be a dictionary of PTU data.
        """
        self._require_legacy()
        self._status_signal.connect(listener)

    def disconnect_status_listener(self, listener):
        """Disconnect an observer listening for PTU updates"""
        self._require_legacy()
        self._status_signal.disconnect(listener)

    def set_status_rate(self, rate):
        """Set the rate at which we request status updates from the PTU"""
        self._require_legacy()
        if self._keepalive:
            self._keepalive.set_rate(rate)

    def get_status(self, timeout = None, establishing = False):
        """Get the current PTU status.

        If you don't need status right away, it may be better to use a status
        listener and register it through connect_status_listener rather than
        call this function repeatedly
        """
        self._require_legacy()
        with self._lock:
            if timeout is None: timeout = self._timeout

            message = self.protocol.get_status()
            #print(f"Returned message is: {message}, in hex: {message.hex()}")
            self._logger.debug("Sending status request")
            return self._send_message(message, timeout = timeout, establishing = establishing)

    def jog(self, pan_speed, tilt_speed, override_soft_limits = False, timeout = None):
        """Start panning or tilting at a set speed.

        pan_speed: A floating point number in the range (-1, 1), where -1 is
                   the max speed panning left, and 1 is the max speed panning
                   right.
        tilt_speed: Similar to pan_speed, but 1 is max speed tilting up, and -1
                    is max speed tilting down
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.jog(pan_speed, tilt_speed, override_soft_limits = override_soft_limits)
            self._logger.info("Sending Jog Command: (Pan: {}, Tilt {})".format(pan_speed, tilt_speed))

            return self._send_message(message, timeout = timeout)

    def move_to_zero(self, timeout=None):
        """Move to the zero position"""
        self._require_legacy()
        with self._lock:
            message = self.protocol.move_to_zero()
            self._logger.info("Sending Move to 0 command")

            return self._send_message(message, timeout)

    def move_to(self, pan_coord, tilt_coord, timeout=None):
        """Move to a set position from zero

        pan_coord: Coordinate to pan to, positive right.
        tilt_coord: Coordinate to tilt to, positive up.
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.move_to(pan_coord, tilt_coord)
            self._logger.debug("Sending Move To command: (Pan: {}, Tilt {})".format(pan_coord, tilt_coord))

            return self._send_message(message, timeout)

    def move_delta(self, pan, tilt, timeout=None):
        """Move some number of degrees from the current position

        pan: Degrees to pan, positive is to the right
        tilt: Degrees to tilt, positive is up
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.move_delta(pan, tilt)
            self._logger.info("Sending Move Delta command: (Pan: {}, Tilt {})".format(pan, tilt))

            return self._send_message(message, timeout)

    def move_home(self, timeout=None):
        """Move to the set home position"""
        self._require_legacy()
        with self._lock:
            message = self.protocol.move_home()
            self._logger.info("Sending Move Home command")

            return self._send_message(message, timeout)

    def get_soft_limit(self, axis, timeout=None):
        """Get the current soft limits for a particular axis

        axis: The Axis you want, should be one of CW, CCW, UP, or DOWN
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.get_soft_limit(axis)
            self._logger.info("Getting soft limits for axis {}".format(axis))

            return self._send_message(message, timeout)

    def set_soft_limit(self, axis, timeout=None):
        """Set the soft limits to the current position

        axis: The Axis you want, should be one of CW, CCW, UP, or DOWN
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.set_soft_limit(axis)
            self._logger.info("Setting soft limits for axis {}".format(axis))

            return self._send_message(message, timeout)

    def get_max_speed(self, timeout=None):
        """UNSTABLE: This function is under construction (TODO: ptcr96 implementation)

        Returns the max speed parameters for panning and tilting (1-255)
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.get_max_speed()
            self._logger.info(f"Getting maximum speed limit for pan and tilt")

            return self._send_message(message, timeout)

    def get_min_speed(self, timeout=None):
        """UNSTABLE: This function is under construction (TODO: ptcr96 implementation)

        Returns the min speed parameters for panning and tilting (0 = no movement, 255 = absolute top speed)
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.get_min_speed()
            self._logger.info(f"Getting minimum speed limit for pan and tilt")

            return self._send_message(message, timeout)

    def set_max_speed(self, pan_speed, tilt_speed, timeout=None):
        """UNSTABLE: This function is under construction (TODO: ptcr96 implmentation)

        Set the maximum speed setting for both pan and tilt.
        If max speed is set to less than min speed, the PTU will run no slower than the min speed.

        pan_speed: Integer value between 1-255
        tilt_speed: Integer value between 1-255
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.set_max_speed(pan_speed, tilt_speed)
            self._logger.info(f"Setting maximum speed limit - Pan: {pan_speed}, Tilt: {tilt_speed}")

            return self._send_message(message, timeout)

    def set_min_speed(self, pan_speed, tilt_speed, timeout=None):
        """UNSTABLE: This function is under construction (TODO: ptcr96 implementation)

        Set the minimum speed setting for both pan and tilt

        pan_speed: Integer value between 0-255 (0 = no movement, 255 = absolute top speed)
        tilt_speed: Integer value between 0-255 (0 = no movement, 255 = absolute top speed)
        """
        self._require_legacy()
        with self._lock:
            message = self.protocol.set_min_speed(pan_speed, tilt_speed)
            self._logger.info(f"Setting minimum speed limit - Pan: {pan_speed}, Tilt: {tilt_speed}")

            return self._send_message(message, timeout)

    def reset_motor_timeout(self):
        self._require_legacy()
        self._logger.warning("Clear faults in motor and retry...")
        message = self.protocol.reset_motor_timeout()
        return self._send_message(message)

    def open(self):
        """
        Open the serial port and establish a connection with the PTU.

        Raises ConnectionFailedError if we are not able to establish connection
        with the PTU. If this happens, the serial port will be closed.
        """
        self._require_legacy()
        self.protocol.reset()
        self._interface.open()
        self._keepalive = self.KeepAlive(self, rate=self.rate)
        self._keepalive.start()
        if not self._keepalive.established.wait(5):
            # print("Gave up on keepalive")
            self.close()
            # print("Finished closing...")
            raise errors.ConnectionFailedError()

    def close(self, *, deadline=None):
        """
        Close the serial port.
        """
        if self._pointing:
            return self._close_pointing(deadline)
        if self._keepalive and self._keepalive.is_alive():
            self._keepalive.stop()
            self._keepalive.join()
        self._interface.close()
        self.protocol.reset()

    def is_connected(self):
        return self._interface.isOpen()

    def _send_message(self, message, timeout=None, retries=None, response=True, establishing=False):
        """
        message: The message ready to send
        timeout: The receive timeout (in seconds).
        no_response: If true, don't expect a response.
        establishing: Send this message whether we think we're connected or not, and
                      don't close the connection if something times out.

        Returns the reponse received sans start/end markers
        """
        self._require_legacy()
        if timeout is None: timeout = self._timeout
        if retries is None: retries = self._retries

        if not self.is_connected():
            raise errors.NotConnectedError()

        while retries > 0:
            self._logger.debug("Writing: " + " ".join("{:02x}".format(c) for c in message))
            # print(f"Attempting to write this message: {message}, in hex: {message.hex()}")
            self._interface.write(message)
            self._last_tx_time = time.time()

            if response:
                response = self._receive_message(timeout)
                # print(f"Response is: {response}")
                return (response[0], self.protocol.parse_message(response[1]))

            retries = retries - 1

        return (False, None)

    def _receive_message(self, timeout=None):
        """
        timeout: The message timeout (in seconds).
        """
        self._require_legacy()
        packet = self._interface.read_packet(timeout)
        if packet is None:
            raise errors.TimeoutError("PTU Reponse timed out")

        message = self.protocol.check_message(packet)
        if message.message is None:
            raise errors.CorruptedMessageError(message.error)

        if not message.acked:
            self._logger.error("Request Nacked")

        self._logger.debug("Response Bytes: " + " ".join("{:02x}".format(c) for c in message.message))
        return (message.acked, message.message)



    @property
    def pointing_available(self):
        """Observe fresh strict ownership without reserving or activating it."""
        if (not self._pointing or self._pointing_handle is not None
                or self._pointing_stop_requested or self._pointing_blocked or self._pointing_closed):
            return False
        try:
            self._profile()
        except Exception:
            return False
        return True

    @property
    def pointing_context(self):
        """Actual supported protocol, integer units/degree and wire address."""
        if (not self._pointing or self._pointing_stop_requested
                or self._pointing_blocked or self._pointing_closed):
            raise PointingError("invalidated")
        try:
            profile = self._profile()
            if (self._pointing_handle is not None
                    and (self._protocol is not self._pointing_protocol
                         or self._serial is not self._pointing_serial
                         or profile != self._pointing_profile)):
                raise PointingError("context-changed")
        except BaseException:
            if self._pointing_handle is not None:
                self._pointing_stop_requested = True
                self._pointing_context_invalid = True
            raise
        actual = profile[0]
        return ("PTCR20" if actual[0] == 2 else "PTCR96", int(actual[3]), actual[4])

    @property
    def pointing_serial_context(self):
        self.pointing_context
        return self._profile()[1]

    @property
    def readback_context(self):
        if self._serial_settings is None or self._device_identity is None:
            raise PointingError("serial-context")
        protocol, scale, address = self.pointing_context
        return ReadbackContext(protocol, scale, address, self._serial_settings, self._device_identity)

    @property
    def last_exchange(self):
        return self._last_exchange

    @property
    def serial_capability(self):
        return self._serial_capability

    def _require_legacy(self):
        if self._pointing:
            raise PointingError("legacy-disabled")

    @staticmethod
    def _deadline(deadline):
        if type(deadline) not in (int, float):
            raise PointingError("deadline-admission")
        try:
            finite = math.isfinite(deadline)
        except OverflowError:
            finite = False
        if not finite:
            raise PointingError("deadline-admission")

    @classmethod
    def _controls(cls, deadline, cancel):
        cls._deadline(deadline)
        if type(cancel) is not threading.Event:
            raise PointingError("cancel-admission")
        if cancel.is_set():
            raise PointingError("cancelled")
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise PointingError("deadline")
        return remaining

    @contextmanager
    def _pointing_lock(self, deadline, cancel):
        while True:
            remaining = self._controls(deadline, cancel)
            if self._lock.acquire(timeout=min(0.01, remaining)):
                break
        try:
            self._controls(deadline, cancel)
            if (self._pointing_guard_depth
                    and (self._pointing_guard_deadline != deadline
                         or self._pointing_guard_cancel is not cancel)):
                raise PointingError("guard-controls")
            yield
        finally:
            self._lock.release()

    def _profile(self):
        from serialptu.proto_impl import PTCR20, PTCR96
        proto = self._protocol
        if type(proto) not in (PTCR20, PTCR96):
            raise PointingError("protocol")
        expected = (2, 2, 2, 10, None) if type(proto) is PTCR20 else (3, 4, 4, 100, 0)
        actual = (proto._coordinate_width, proto._jog_aux_bytes, proto._move_aux_bytes,
                  proto._degree_factor, proto._ptu_id)
        if (any(type(value) is not int for value in actual[:3])
                or type(actual[3]) not in (int, float)
                or (actual[4] is not None and type(actual[4]) is not int)
                or actual != expected):
            raise PointingError("protocol")
        if (type(proto._commands) is not dict or type(proto._special_chars) is not dict
                or any(type(proto._commands.get(name)) is not int
                       or proto._commands[name] != value
                       for name, value in (("jog", 0x31), ("move_to", 0x33)))
                or any(type(proto._special_chars.get(name)) is not int
                       or proto._special_chars[name] != value
                       for name, value in (("stx", 2), ("etx", 3), ("ack", 6),
                                           ("nak", 21), ("esc", 27)))):
            raise PointingError("protocol")
        if (type(proto._last_jog_pan) not in (int, float) or proto._last_jog_pan != 0
                or type(proto._last_jog_tilt) not in (int, float) or proto._last_jog_tilt != 0
                or proto._last_jog_override is not False):
            raise PointingError("status-motion")
        settings = tuple(getattr(self._serial, name) for name in
                         ("port", "baudrate", "bytesize", "parity", "stopbits",
                          "xonxoff", "rtscts", "dsrdtr"))
        if (any(type(value) not in (str, int, float, bool, type(None)) for value in settings)
                or type(self._serial.timeout) not in (int, float) or self._serial.timeout != 0):
            raise PointingError("serial-context")
        controls = tuple(getattr(self._serial, name, None) for name in
                         ("rts", "dtr", "exclusive", "inter_byte_timeout", "rs485_mode"))
        if self._serial_settings is not None:
            if (controls != (self._serial_settings.rts, self._serial_settings.dtr, True, None, None)
                    or settings != (self._device_snapshot.target if self._device_snapshot else self._serial_settings.port,
                        self._serial_settings.baudrate, self._serial_settings.bytesize,
                        self._serial_settings.parity, self._serial_settings.stopbits,
                        self._serial_settings.xonxoff, self._serial_settings.rtscts, self._serial_settings.dsrdtr)):
                raise PointingError("serial-context")
        return (actual, settings, controls, self._serial_settings, self._device_identity, self._serial_capability)

    def _block_pointing(self):
        self._pointing_stop_requested = True
        if not self._pointing_blocked:
            self._pointing_blocked = True
            self._pointing_generation += 1

    def _pointing_check(self, handle, deadline, cancel, require_open=True):
        self._controls(deadline, cancel)
        if (not self._pointing or type(handle) is not _PointingHandle
                or handle is not self._pointing_handle or handle._stamp is not self._pointing_stamp):
            raise PointingError("binding")
        if (self._pointing_stop_requested or self._pointing_blocked or self._pointing_closed
                or self.jog_stop_pending):
            raise PointingError("invalidated")
        try:
            if (self._protocol is not self._pointing_protocol
                    or self._serial is not self._pointing_serial
                    or self._profile() != self._pointing_profile):
                raise PointingError("context-changed")
        except BaseException:
            self._pointing_context_invalid = True
            self._block_pointing()
            raise
        self._controls(deadline, cancel)
        if require_open and not self._interface.isOpen():
            raise PointingError("not-open")
        self._controls(deadline, cancel)

    def bind_pointing(self, binding, *, deadline, cancel):
        if self._serial_settings is not None:
            raise PointingError("readback-only")
        return self._bind(binding, "pointing", deadline, cancel)

    def bind_readback(self, binding, *, deadline, cancel):
        self.readback_context
        if self._serial_capability != "readback":
            raise PointingError("readback-only")
        return self._bind(binding, "readback", deadline, cancel)

    def bind_manual(self, binding, *, deadline, cancel):
        self.readback_context
        if self._serial_capability != "manual":
            raise PointingError("readback-only")
        return self._bind(binding, "manual", deadline, cancel)

    def _bind(self, binding, capability, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            if (not self._pointing or self._pointing_handle is not None
                    or self._pointing_stop_requested or self._pointing_blocked or self._pointing_closed):
                raise PointingError("binding")
            if type(binding) is not bytes or len(binding) != 32:
                raise PointingError("binding-admission")
            profile = self._profile()
            self._controls(deadline, cancel)
            self._pointing_handle = _PointingHandle(self._pointing_stamp, binding, capability)
            self._pointing_profile = profile
            self._pointing_protocol = self._protocol
            self._pointing_serial = self._serial
            self._pointing_generation += 1
            return self._pointing_handle

    def open_bounded(self, *, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(self._pointing_handle, deadline, cancel, require_open=False)
            try:
                if self._serial_settings is not None and not self._interface.isOpen():
                    self._device_snapshot = verify_selected_device(self._serial_settings, self._device_identity)
                    self._controls(deadline, cancel)
                    self._serial.port = self._device_snapshot.target
                    self._pointing_profile = self._profile()
                self._interface.open()
                if self._device_snapshot is not None:
                    claim_selected_device(self._serial, self._serial_settings,
                                          self._device_identity, self._device_snapshot)
                self._pointing_check(self._pointing_handle, deadline, cancel)
            except AcquisitionError as error:
                self._pointing_context_invalid = True
                self._block_pointing()
                raise PointingError(str(error)) from None
            except serial.SerialException as error:
                self._pointing_context_invalid = True
                self._block_pointing()
                if error.errno in (errno.EAGAIN, errno.EWOULDBLOCK, errno.EBUSY):
                    raise PointingError("device-busy") from None
                raise PointingError("serial-io") from None
            except BaseException:
                self._pointing_context_invalid = True
                self._block_pointing()
                raise

    @contextmanager
    def pointing_guard(self, handle, *, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(handle, deadline, cancel)
            if self._pointing_guard_depth:
                if (self._pointing_guard_deadline != deadline
                        or self._pointing_guard_cancel is not cancel):
                    raise PointingError("guard-controls")
            else:
                self._pointing_guard_deadline = deadline
                self._pointing_guard_cancel = cancel
            self._pointing_guard_depth += 1
            self._pointing_guard_thread = threading.get_ident()
            try:
                yield
            finally:
                self._pointing_guard_depth -= 1
                if not self._pointing_guard_depth:
                    self._pointing_guard_thread = None
                    self._pointing_guard_deadline = None
                    self._pointing_guard_cancel = None

    def prepare_move_to(self, handle, pan, tilt, *, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(handle, deadline, cancel, require_open=False)
            self._require_motion(handle)
            if (type(pan) not in (int, float) or type(tilt) not in (int, float)
                    or not -360 <= pan <= 360 or not -180 <= tilt <= 180
                    or not math.isfinite(pan) or not math.isfinite(tilt)):
                raise PointingError("coordinate-admission")
            packet = self._protocol.move_to(pan, tilt)
            coordinates = self._protocol.decode_move_to_packet(packet)
            self._pointing_check(handle, deadline, cancel, require_open=False)
            return _PreparedMove(self._pointing_stamp, handle, self._pointing_generation,
                                 packet, coordinates)

    def submit_prepared_move(self, handle, prepared, *, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(handle, deadline, cancel)
            self._require_motion(handle)
            if (self._pointing_guard_thread != threading.get_ident()
                    or not self._pointing_guard_depth
                    or self._pointing_guard_deadline != deadline
                    or self._pointing_guard_cancel is not cancel):
                raise PointingError("guard-required")
            if (type(prepared) is not _PreparedMove or prepared._stamp is not self._pointing_stamp
                    or prepared._handle is not handle
                    or prepared.generation != self._pointing_generation):
                raise PointingError("prepared")
            coordinates = self._protocol.decode_move_to_packet(prepared.packet)
            if coordinates != (prepared.pan_units, prepared.tilt_units, prepared.units_per_degree):
                raise PointingError("prepared")
            return self._pointing_exchange(handle, prepared.packet, 0x33, deadline, cancel)

    def get_status_bounded(self, handle, *, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(handle, deadline, cancel)
            packet = self._protocol.get_status()
            self._protocol.validate_nonmoving_status_packet(packet)
            return self._pointing_exchange(handle, packet, 0x31, deadline, cancel)

    def prepare_jog(self, handle, pan_velocity, tilt_velocity, *, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(handle, deadline, cancel, require_open=False)
            if handle.capability != "manual" or self.pointing_context != ("PTCR20", 10, None):
                raise PointingError("readback-only")
            if (any(type(value) not in (int, float) or not -1 <= value <= 1
                    or not math.isfinite(value) for value in (pan_velocity, tilt_velocity))
                    or (pan_velocity != 0) + (tilt_velocity != 0) != 1):
                raise PointingError("coordinate-admission")
            packet = self._protocol.jog_packet(pan_velocity, tilt_velocity)
            velocities = self._protocol.decode_jog_packet(packet)
            self._pointing_check(handle, deadline, cancel, require_open=False)
            return _PreparedJog(self._pointing_stamp, handle, self._pointing_generation, packet, *velocities)

    def submit_prepared_jog(self, handle, prepared, *, deadline, cancel):
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(handle, deadline, cancel)
            if handle.capability != "manual":
                raise PointingError("readback-only")
            if (self._pointing_guard_thread != threading.get_ident()
                    or not self._pointing_guard_depth
                    or self._pointing_guard_deadline != deadline
                    or self._pointing_guard_cancel is not cancel):
                raise PointingError("guard-required")
            if (type(prepared) is not _PreparedJog or prepared._stamp is not self._pointing_stamp
                    or prepared._handle is not handle or prepared.generation != self._pointing_generation):
                raise PointingError("prepared")
            velocities = self._protocol.decode_jog_packet(prepared.packet)
            if velocities != (prepared.pan_velocity, prepared.tilt_velocity, prepared.velocity_scale):
                raise PointingError("prepared")
            return self._pointing_exchange(handle, prepared.packet, 0x31, deadline, cancel, jog_packet=True)

    def stop_bounded(self, handle, *, deadline, cancel):
        """Submit the source-supported zero-JOG stop, without claiming a physical stop."""
        with self._pointing_lock(deadline, cancel):
            self._stop_check(handle, deadline, cancel)
            self._require_motion(handle)
            packet = self._protocol.stop_packet()
            self._protocol.validate_stop_packet(packet)
            return self._pointing_exchange(handle, packet, 0x31, deadline, cancel,
                                           stop_authority=True, stop_packet=True)

    def observe_bounded(self, handle, *, deadline, cancel):
        """Allow a checked nonmoving observation after an uncertain exchange."""
        with self._pointing_lock(deadline, cancel):
            self._stop_check(handle, deadline, cancel)
            if self.jog_stop_pending and not self.jog_stop_reconciled:
                raise PointingError("invalidated")
            packet = self._protocol.get_status()
            self._protocol.validate_nonmoving_status_packet(packet)
            return self._pointing_exchange(handle, packet, 0x31, deadline, cancel, stop_authority=True)

    @property
    def jog_stop_pending(self):
        return self._interrupted_jog is not None

    @property
    def jog_stop_reconciled(self):
        return self._jog_stop_reconciled

    @property
    def establishment_exchanges(self):
        return self._establishment_exchanges

    def establish_bounded(self, handle, *, deadline, cancel):
        """Acquire initial feedback using only checked nonmoving status probes."""
        with self._pointing_lock(deadline, cancel):
            self._pointing_check(handle, deadline, cancel)
            if (self._serial_settings is None or handle.capability not in ("readback", "manual")
                    or self._exchange_sequence != 0):
                raise PointingError("binding")
            packet = self._protocol.get_status()
            self._protocol.validate_nonmoving_status_packet(packet)
            return self._pointing_exchange(handle, packet, 0x31,
                min(deadline, time.monotonic() + 5), cancel, establishment=True)

    @staticmethod
    def _require_motion(handle):
        if handle.capability not in ("pointing", "manual"):
            raise PointingError("readback-only")

    def _stop_check(self, handle, deadline, cancel):
        self._controls(deadline, cancel)
        if (not self._pointing or type(handle) is not _PointingHandle
                or handle is not self._pointing_handle or handle._stamp is not self._pointing_stamp
                or self._pointing_closed or self._pointing_closing or self._pointing_context_invalid):
            raise PointingError("binding")
        try:
            matches = (self._protocol is self._pointing_protocol and self._serial is self._pointing_serial
                       and self._profile() == self._pointing_profile)
        except BaseException:
            self._pointing_context_invalid = True
            self._block_pointing()
            raise
        if not matches:
            self._pointing_context_invalid = True
            self._block_pointing()
            raise PointingError("context-changed")
        if not self._interface.isOpen():
            raise PointingError("not-open")
        self._controls(deadline, cancel)

    def _pointing_exchange(self, handle, packet, command, deadline, cancel,
                           stop_authority=False, stop_packet=False, jog_packet=False, establishment=False):
        check = self._stop_check if stop_authority else self._pointing_check
        started = time.monotonic()
        if self._exchange_sequence == 2**64 - 1:
            self._block_pointing()
            raise PointingError("exchange-sequence")
        self._exchange_sequence += 1
        sequence = self._exchange_sequence
        response = bytearray()
        frame = bytearray()
        parsed = None
        last_feedback = None
        category = "ok"
        written = None
        submission = "none"
        interrupted = (self._interrupted_jog if stop_packet and not self._jog_stop_reconciled
                       and not self._pointing_blocked and not self._pointing_stop_requested else None)
        interrupted_response = bytearray(interrupted.response if interrupted is not None else b"")
        cancelled_jog = False

        def record_exchange():
            self._last_exchange = ExchangeReceipt(sequence,
                "stop" if stop_packet else "jog" if jog_packet else "status" if command == 0x31 else "move",
                bytes(packet[:64]), bytes(response[:64]), len(response) > 64 or len(interrupted_response) > 64,
                started, time.monotonic(), category, submission, written,
                interrupted_sequence=interrupted.sequence if interrupted is not None else None,
                interrupted_response_prefix=interrupted.response if interrupted is not None else b"",
                interrupted_response=bytes(interrupted_response[:64]))
            if establishment:
                self._establishment_exchanges += (self._last_exchange,)

        def write_request():
            nonlocal written, submission
            self._serial.write_timeout = self._controls(deadline, cancel)
            check(handle, deadline, cancel)
            submission = "unknown"
            written = self._interface.write_bytes_exact(packet)
            if type(written) is not int or not 0 <= written <= len(packet):
                written = None
                raise PointingError("write-count")
            submission = "complete" if written == len(packet) else ("partial" if written else "none")
            if written != len(packet):
                raise PointingError("short-write")

        def check_recovery_status(data, *, stationary=False):
            raw = data.get("status_bytes")
            if (type(raw) is not bytes or len(raw) != 3 or raw[0] or raw[1]
                    or stationary and raw[2] & 0x4f):
                raise PointingError("strict-status")

        def finish_interrupted_jog():
            while not interrupted_response or interrupted_response[-1] != 3:
                check(handle, deadline, cancel)
                chunk = self._serial.read(1)
                if type(chunk) is bytes:
                    interrupted_response.extend(chunk[:65 - len(interrupted_response)])
                check(handle, deadline, cancel)
                if type(chunk) is not bytes or len(chunk) > 1 or len(interrupted_response) > 64:
                    raise PointingError("response")
                if not chunk:
                    cancel.wait(min(0.01, self._controls(deadline, cancel)))
            data = self._protocol.decode_pointing_response(bytes(interrupted_response), 0x31)
            check_recovery_status(data)
            check(handle, deadline, cancel)

        try:
            check(handle, deadline, cancel)
            if handle.capability == "readback":
                if command != 0x31 or stop_packet or jog_packet:
                    raise PointingError("readback-only")
                self._protocol.validate_nonmoving_status_packet(packet)
            queued = 0
            if stop_authority or self._serial_settings is not None:
                queued = self._serial.in_waiting
                if type(queued) is not int or queued < 0:
                    raise PointingError("response")
                if queued and not stop_packet:
                    raise PointingError("stale-response")
            write_request()
            if interrupted is not None:
                # Stop is already written before waiting for the interrupted JOG reply.
                finish_interrupted_jog()
                if queued > len(interrupted_response) - len(interrupted.response):
                    raise PointingError("stale-response")
            elif queued:
                raise PointingError("stale-response")
            check(handle, deadline, cancel)
            while True:
                check(handle, deadline, cancel)
                chunk = self._serial.read(1)
                if type(chunk) is bytes:
                    response.extend(chunk[:65 - len(response)])
                check(handle, deadline, cancel)
                if type(chunk) is not bytes or len(chunk) > 1:
                    raise PointingError("response")
                if chunk:
                    if len(response) > 64:
                        raise PointingError("response")
                    frame.extend(chunk)
                    last_feedback = time.monotonic()
                    if chunk == b"\x03":
                        parsed = self._protocol.decode_pointing_response(bytes(frame), command)
                        frame.clear()
                        check(handle, deadline, cancel)
                        if interrupted is not None:
                            check_recovery_status(parsed)
                            self._jog_stop_reconciled = True
                        elif (self._jog_stop_reconciled and not stop_packet
                              and not self._pointing_blocked and not self._pointing_stop_requested):
                            check_recovery_status(parsed, stationary=True)
                            self._interrupted_jog = None
                            self._jog_stop_reconciled = False
                        if not establishment or not self._establishment_exchanges:
                            return (True, parsed)
                else:
                    if (parsed is not None and not frame and last_feedback is not None
                            and time.monotonic() - last_feedback >= .5):
                        queued = self._serial.in_waiting
                        if type(queued) is not int or queued < 0:
                            raise PointingError("response")
                        if queued:
                            continue
                        check(handle, deadline, cancel)
                        return (True, parsed)
                    if (establishment and not response and time.monotonic() - started >= .5
                            and len(self._establishment_exchanges) < 9):
                        queued = self._serial.in_waiting
                        if type(queued) is not int or queued < 0:
                            raise PointingError("response")
                        if queued:
                            continue
                        # A partial frame ends probing; empty probes alone may be repeated.
                        category = "deadline"
                        record_exchange()
                        self._exchange_sequence += 1
                        sequence = self._exchange_sequence
                        started = time.monotonic()
                        category, submission, written = "ok", "none", None
                        write_request()
                    cancel.wait(min(0.01, self._controls(deadline, cancel)))
        except BaseException as exc:
            primary = exc.primary if type(exc) is PointingError else "serial-io"
            if type(exc) is errors.CorruptedMessageError:
                primary = str(exc) if str(exc) in (
                    "strict-frame", "strict-escape", "strict-checksum", "strict-address",
                    "strict-status", "strict-stop", "strict-jog", "strict-response", "strict-nak") else "protocol-response"
            cancelled_jog = (jog_packet and primary == "cancelled" and submission == "complete"
                             and self._serial_settings is not None and handle.capability == "manual"
                             and not self._pointing_blocked and not self._pointing_stop_requested
                             and not self._pointing_context_invalid and len(response) <= 64)
            if not cancelled_jog and not (jog_packet and primary == "cancelled" and submission == "none"):
                self._block_pointing()
            category = primary
            raise PointingError(primary, submission, written) from None
        finally:
            record_exchange()
            if cancelled_jog:
                self._interrupted_jog = self._last_exchange
                self._jog_stop_reconciled = False
                self._pointing_generation += 1

    def invalidate_pointing(self, handle, *, deadline, cancel):
        self._controls(deadline, cancel)
        if (not self._pointing or type(handle) is not _PointingHandle
                or handle is not self._pointing_handle):
            raise PointingError("binding")
        self._pointing_stop_requested = True
        with self._pointing_lock(deadline, cancel):
            self._block_pointing()

    def _close_pointing(self, deadline):
        self._deadline(deadline)
        self._pointing_closing = True
        self._pointing_stop_requested = True
        acquired = self._lock.acquire(blocking=False)
        while not acquired:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise PointingError("close-deadline")
            acquired = self._lock.acquire(timeout=min(0.01, remaining))
        try:
            self._block_pointing()
            self._interface.close()
            if self._interface.isOpen():
                raise PointingError("close-incomplete")
            self._pointing_closed = True
            if time.monotonic() >= deadline:
                raise PointingError("close-deadline")
        except PointingError:
            raise
        except BaseException:
            raise PointingError("close-io") from None
        finally:
            self._lock.release()

