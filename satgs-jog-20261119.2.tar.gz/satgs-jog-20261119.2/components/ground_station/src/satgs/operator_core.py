"""Shared offline operator workflow over an explicit private scratch station."""

from copy import deepcopy
from contextlib import ExitStack
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import stat
from uuid import uuid4

from satgs._operator_contract import ALTITUDE_REFERENCES, OperatorError
from satgs.deployment import DeploymentError, load_manifest
from satgs.deployment_cli import CliInputError, MAX_INPUT_BYTES, read_regular_bytes
from satgs.deployment_plan import (
    InputError, build_catalog, expand_preset, parse_configuration, plan_configuration,
    validate_selection_contract,
)
from satgs.operator_activity import (
    ActivityError, MARKER, StationLease, open_workspace, validate_marker, workspace_path,
)
from satgs.runtime_configuration import RuntimeConfigurationError, _parse_station_yaml
from satgs.station_location import LocationError, location_from_settings, prepare_manual_location
from satgs.station_location_cli import _write_new_artifact


GPS_REQUIREMENTS = (
    "No admitted measured GPS source is connected to this offline workspace.",
    "Fix validity and source identity are not established for station selection.",
    "Observation time and the required freshness policy are not established.",
    "Horizontal and altitude coordinate references and conversion are not established.",
)
_IDENTITY = re.compile(r"[0-9a-f]{64}")
REPLAY_STATES = {
    "unknown": ("unknown", "unknown", "unknown", "unknown", "unknown", "unknown"),
    "disconnected": ("disconnected", "none", "unknown", "unknown", "unknown", "unknown"),
    "silent": ("connected", "none", "unknown", "unknown", "unknown", "unknown"),
    "no_fix": ("connected", "received", "no_fix", "fresh_replay", "unknown", "unknown"),
    "reported_3d": ("connected", "received", "reported_3d", "fresh_replay", "unknown", "unknown"),
    "stale": ("connected", "received", "reported_3d", "stale", "unknown", "unknown"),
    "mismatched": ("connected", "mismatched_source", "unknown", "unqualified", "unknown", "unknown"),
    "incomplete": ("connected", "incomplete", "unknown", "unqualified", "unknown", "unknown"),
    "critical": ("connected", "received", "reported_3d", "fresh_replay", "critical", "transport_pass"),
}


def _bytes(document):
    payload = (json.dumps(document, sort_keys=True, indent=2, ensure_ascii=True,
                          allow_nan=False) + "\n").encode("utf-8")
    if len(payload) > MAX_INPUT_BYTES:
        raise OperatorError("Operator document exceeds the supported byte limit.")
    return payload


def _digest(payload):
    return hashlib.sha256(payload).hexdigest()


def _bench_report_record(record):
    fields = {"schema", "attempt_id", "operation", "operation_code", "category", "state", "mode", "transport",
              "physical_state", "position_reference", "submission", "has_observation", "pan", "tilt",
              "status_bytes", "observed_at", "observation_sequence", "requested_pan", "requested_tilt",
              "encoded_pan_units", "encoded_tilt_units", "units_per_degree", "preview_sequence",
              "equipment_label", "frame", "pan_min", "pan_max", "tilt_min", "tilt_max",
              "max_change_degrees", "possible_motion", "binding", "manager_id", "ptu_id", "query_only",
              "sequence", "phase", "started_monotonic", "finished_monotonic", "elapsed_seconds",
              "wall_clock_quality", "cleanup_complete", "cleanup_error", "passive_cleanup_retry", "partial", "started_recorded",
              "result_recorded", "recorded", "recording_deferred", "manual_enabled", "step_degrees", "step_direction",
              "jog_token", "jog_direction", "jog_exchange_count", "jog_acknowledged_count", "jog_uncertain_count",
              "jog_end_reason", "stop_category", "stop_submission", "motion_contract", "no_go_enforced",
              "software_endpoint_limits_enforced", "device_soft_limits_retained", "requested_pan_velocity",
              "requested_tilt_velocity", "encoded_pan_velocity", "encoded_tilt_velocity", "velocity_scale",
              "connection_budget_seconds", "response_correlation", "message", "jog_reply_interrupted",
              "jog_reply_reconciled", "stop_reconciliation_required"}
    result = {key: value for key, value in record.items()
              if key in fields and type(value) in (str, int, float, bool, type(None))}
    if type(record.get("last_exchange")) is dict:
        last = {key: value for key, value in record["last_exchange"].items() if key != "last_exchange"}
        result["last_exchange"] = _bench_report_record(last)
    context = record.get("selected_context")
    if type(context) is dict:
        scalar = {"schema", "session_id", "equipment_label", "model", "protocol", "protocol_address", "frame",
                  "observation_max_age_seconds", "exchange_timeout_seconds", "pan_min", "pan_max", "tilt_min",
                  "tilt_max", "max_change_degrees"}
        selected = {key: value for key, value in context.items()
                    if key in scalar and type(value) in (str, int, float, bool, type(None))}
        for name, keys in (("serial_settings", {"port", "baudrate", "bytesize", "parity", "stopbits",
                           "xonxoff", "rtscts", "dsrdtr", "rts", "dtr"}),
                           ("device_identity", {"vendor_id", "product_id", "serial_number", "interface_number", "driver"}),
                           ("no_go_rectangle", {"pan_min", "pan_max", "tilt_min", "tilt_max"})):
            value = context.get(name)
            if type(value) is dict:
                selected[name] = {key: item for key, item in value.items()
                                  if key in keys and type(item) in (str, int, float, bool, type(None))}
            elif name in context and value is None:
                selected[name] = None
        result["selected_context"] = selected
    identity = record.get("release_identity")
    if type(identity) is dict and type(identity.get("distributions")) is dict:
        result["release_identity"] = {"evidence": "package_metadata_only", "distributions": {
            key: value for key, value in identity["distributions"].items()
            if key in ("satgs", "meteor_api", "stomp.py", "ptu_control", "pixhawk", "serialptu")
            and type(value) in (str, type(None))}}
    if type(record.get("steps")) is list:
        if len(record["steps"]) > 4 or any(type(step) is not dict for step in record["steps"]):
            raise OperatorError("Bench operation contains an invalid step record.", "artifact", 4)
        result["steps"] = [_bench_report_record(step) for step in record["steps"]]
    receipts = record.get("exchanges")
    if receipts is not None:
        maximum = 10 if record.get("operation") in ("connect", 1) else 3
        if type(receipts) is not list or len(receipts) > maximum or any(type(row) is not dict for row in receipts):
            raise OperatorError("Bench operation contains invalid exchange records.", "artifact", 4)
        allowed = {"sequence", "operation", "request", "response", "response_truncated",
                   "started_monotonic", "finished_monotonic", "category", "submission", "written", "timing_reference",
                   "interrupted_sequence", "interrupted_response_prefix", "interrupted_response"}
        result["exchanges"] = [{key: value for key, value in receipt.items()
                               if key in allowed and type(value) in (str, int, float, bool, type(None))}
                              for receipt in receipts]
    return result


def _identity(value, label="Operation"):
    if type(value) is not str or _IDENTITY.fullmatch(value) is None:
        raise OperatorError(f"{label} identity must be an exact SHA-256 value.")
    return value


def _activity(error):
    return OperatorError(str(error), error.code, 4 if error.code == "io" else 3)


def _write_new(path, payload):
    path = Path(path)
    if str(path) == "-":
        raise OperatorError("Provide an explicit new report file, not standard output.")
    temporary = path.with_name(f".{path.name}-{uuid4().hex}.pending")
    directory = None
    try:
        absolute = Path(os.path.abspath(path))
        flags = os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        with ExitStack() as parents:
            parent = os.open("/", flags)
            parents.callback(os.close, parent)
            for component in absolute.parent.parts[1:]:
                parent = os.open(component, flags, dir_fd=parent)
                parents.callback(os.close, parent)
            directory = os.dup(parent)
        _write_new_artifact(str(temporary), payload)
        os.link(temporary.name, path.name, src_dir_fd=directory, dst_dir_fd=directory,
                follow_symlinks=False)
    except (LocationError, OSError):
        raise OperatorError("Private artifact could not be completed; an incomplete output may remain.", "io", 4) from None
    finally:
        try:
            if directory is not None:
                try:
                    os.unlink(temporary.name, dir_fd=directory)
                finally:
                    os.close(directory)
        except OSError:
            pass


def _catalog():
    try:
        return build_catalog(load_manifest())
    except DeploymentError:
        raise OperatorError("Canonical component catalog is unavailable.", "catalog", 4) from None


def _declared_location(settings):
    coordinates = ("ground_station_lat", "ground_station_lon", "ground_station_altm")
    if all(settings.get(key) is None for key in coordinates):
        return None
    try:
        location = location_from_settings(settings).to_dict()
    except LocationError:
        raise OperatorError("Saved station location is invalid.") from None
    reference = settings["operator"]["altitude_reference"]
    location.update(altitude_reference=reference, latitude_unit="degrees", longitude_unit="degrees",
                    altitude_unit="metres", reference_provenance="operator_declared_not_measured",
                    altitude_qualified=False)
    location["planning_identity"] = _digest(_bytes({"identity": location["identity"],
                                                     "altitude_reference": reference}))
    return location


def _metadata_identity():
    distributions = {}
    for name in ("satgs", "meteor_api", "stomp.py", "ptu_control", "pixhawk", "serialptu"):
        try:
            distributions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            distributions[name] = None
    return {"evidence": "package_metadata_only", "distributions": distributions,
            "source_bytes_verified": False, "target_installation_verified": False}


def _replay_measurement(state, dimensions):
    observed = state not in ("unknown", "disconnected", "silent")
    coordinates = None
    if state in ("reported_3d", "stale", "critical"):
        coordinates = {"latitude_deg": 43.25, "longitude_deg": -70.75, "altitude_m": 34.0,
                       "latitude_unit": "degrees", "longitude_unit": "degrees", "altitude_unit": "metres",
                       "horizontal_reference": "unspecified", "altitude_reference": "unspecified"}
    reasons = {
        "unknown": "No GPS observation was admitted.", "disconnected": "Replay input is disconnected.",
        "silent": "Replay input is connected but has supplied no messages.",
        "no_fix": "Replay GPS reports no fix; position is unavailable.",
        "mismatched": "Replay observation source does not match the selected source; position is not admitted.",
        "incomplete": "Replay aggregate lacks required coordinate evidence; no complete position is manufactured.",
        "stale": "Replay position is stale and is not eligible for station selection.",
        "reported_3d": "Synthetic 3D report is not an admitted live station-selection source or reference contract.",
        "critical": "Synthetic 3D report coexists with critical system status; navigation remains unqualified.",
    }
    return {"available": observed, "provenance": "synthetic_replay" if observed else "no_admitted_observation",
            "live_hardware_observed": False, "source_id": ("synthetic-replay:2/1" if state == "mismatched" else "synthetic-replay:1/1") if observed else None,
            "observation_time": "2026-10-28T00:00:00Z" if observed else None,
            "time_basis": "synthetic_fixture_not_live_clock", "coordinates": coordinates,
            "latitude_unit": "degrees", "longitude_unit": "degrees", "altitude_unit": "metres",
            "horizontal_reference": "unspecified", "altitude_reference": "unspecified",
            "fix": dimensions["fix"], "freshness": dimensions["freshness"],
            "valid_for_station_selection": False, "unavailable_reason": reasons[state]}


def initialize_workspace(root, case="pelican-qpt130"):
    if case != "pelican-qpt130":
        raise OperatorError("This candidate supports the explicit pelican-qpt130 scratch case only.")
    try:
        path = workspace_path(root)
        parent = path.parent
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        with ExitStack() as descriptors:
            directory = os.open("/", flags)
            descriptors.callback(os.close, directory)
            for component in parent.parts[1:]:
                directory = os.open(component, flags, dir_fd=directory)
                descriptors.callback(os.close, directory)
            os.mkdir(path.name, 0o700, dir_fd=directory)
        settings = {
            MARKER: {"schema_version": 1, "id": uuid4().hex, "root": str(path)},
            "ground_station_name": "Station",
            "ground_station_configured": False,
            "ground_station_lat": None, "ground_station_lon": None, "ground_station_altm": None,
            "operator": {"case": case, "generation": 1, "selection": None,
                         "altitude_reference": "unspecified", "replay_state": "unknown",
                         "provenance": "synthetic_scratch_not_operational", "last_operation": None},
        }
        _write_new(path / "station.json", _bytes(settings))
        return Workspace(path)
    except ActivityError as error:
        raise _activity(error) from None
    except OSError:
        raise OperatorError("Workspace must be a new directory beneath an existing no-symlink parent.", "io", 4) from None


class Workspace:
    def __init__(self, root):
        try:
            self.root = workspace_path(root)
        except ActivityError as error:
            raise _activity(error) from None
        self.station_path = self.root / "station.json"

    @classmethod
    def create(cls, root, case="pelican-qpt130"):
        return initialize_workspace(root, case)

    def _read(self):
        try:
            raw = read_regular_bytes(str(self.station_path), input_kind="Managed station")
            settings = _parse_station_yaml(raw, allow_inline_ca=True)
            marker = validate_marker(self.station_path, settings)
            if marker is None:
                raise OperatorError("Only explicitly marked operator scratch stations are supported.")
            info = self.station_path.lstat()
            if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1:
                raise OperatorError("Managed station must be an owned private 0600 ordinary file.")
            metadata = settings.get("operator")
            if (type(metadata) is not dict or metadata.get("case") != "pelican-qpt130"
                    or metadata.get("altitude_reference") not in ALTITUDE_REFERENCES
                    or type(metadata.get("generation")) is not int or metadata["generation"] < 1
                    or metadata.get("provenance") != "synthetic_scratch_not_operational"
                    or type(metadata.get("replay_state", "unknown")) is not str
                    or metadata.get("replay_state", "unknown") not in REPLAY_STATES):
                raise OperatorError("Managed operator metadata is invalid or unsupported.")
            selection = metadata.get("selection")
            last = metadata.get("last_operation")
            if last is not None:
                if (type(last) is not dict or set(last) != {"preview_id", "kind", "result", "changed", "active_run_changed"}
                        or last.get("kind") not in ("location", "components") or last.get("result") != "saved"
                        or last.get("changed") is not True or last.get("active_run_changed") is not False):
                    raise OperatorError("Saved operation metadata is invalid.")
                _identity(last.get("preview_id"), "Saved operation")
            if selection is not None:
                parse_configuration(selection, _catalog())
            return raw, settings
        except ActivityError as error:
            raise _activity(error) from None
        except (CliInputError, RuntimeConfigurationError, InputError, OSError):
            raise OperatorError("Managed station could not be admitted safely.") from None

    def snapshot(self):
        raw, settings = self._read()
        return _digest(raw), deepcopy(settings)

    def catalog(self):
        return _catalog().to_dict()

    def _artifact(self, name):
        try:
            raw = read_regular_bytes(str(self.root / name), input_kind="Operator artifact")
            return _parse_station_yaml(raw)
        except (CliInputError, RuntimeConfigurationError):
            raise OperatorError("Operator artifact is missing, incomplete or invalid.", "artifact", 4) from None

    def _plans(self, revision):
        try:
            paths = sorted(self.root.iterdir())
        except OSError:
            raise OperatorError("Workspace artifacts cannot be inspected.", "io", 4) from None
        results = []
        for path in paths:
            match = re.fullmatch(r"plan-([0-9a-f]{64})\.json", path.name)
            if match:
                if len(results) >= 256:
                    raise OperatorError("Workspace exceeds the supported 256-plan limit.")
                plan = self._artifact(path.name)
                results.append({"plan_id": match[1], "station_revision": plan.get("station_revision"),
                                "revalidation_required": plan.get("station_revision") != revision,
                                "planning_only": True})
        return results

    def inspect(self):
        raw, settings = self._read()
        metadata = settings["operator"]
        revision = _digest(raw)
        location = _declared_location(settings)
        selection = metadata.get("selection")
        deployment = plan_configuration(parse_configuration(selection, _catalog()), _catalog()).to_dict() if selection else None
        observation = REPLAY_STATES[metadata.get("replay_state", "unknown")]
        dimensions = dict(zip(("connection", "message_receipt", "fix", "freshness", "system_health", "transport_check"), observation))
        dimensions.update(calibration="unqualified", heading="unqualified", installation="unknown",
                          configuration="selected_local" if selection else "unconfigured")
        last_operation = deepcopy(metadata.get("last_operation"))
        if last_operation is not None:
            last_identity = last_operation.get("preview_id")
            _identity(last_identity, "Saved operation")
            last_operation["receipt_recorded"] = (self.root / f"receipt-{last_identity}.json").is_file()
            last_operation["partial"] = not last_operation["receipt_recorded"]
        dimensions["operation_result"] = last_operation["result"] if last_operation else "not_run"
        return {
            "schema_version": 1, "workspace": str(self.root), "workspace_id": settings[MARKER]["id"],
            "station_revision": revision, "generation": metadata["generation"], "case": metadata["case"],
            "station_name": settings.get("ground_station_name", ""), "selection": selection,
            "configuration": selection, "deployment_plan": deployment,
            "location": location, "effective_location": location, "manual_location": location if location and location["source"] == "manual" else None,
            "measured_gps": _replay_measurement(metadata.get("replay_state", "unknown"), dimensions),
            "gps_selection": {"enabled": False, "unmet_requirements": list(GPS_REQUIREMENTS)},
            "status": dimensions, "observations": {"provenance": "synthetic_replay", "state": metadata.get("replay_state", "unknown"),
                                                     "live_hardware_observed": False, **dimensions},
            "installed_identity": _metadata_identity(), "plans": self._plans(revision),
            "owner_state": "not_checked", "owner_context_verified": False,
            "owner_reinitialization_required": True, "planning_only": True,
            "capabilities": {"install": True, "activate": False, "hardware_control": False,
                             "manual_location": True, "local_planning": True, "report_export": True},
            "limits": ["Runtime submission requires a confirmed request binding this saved location to the selected owners.",
                       "Altitude reference is declared only; no datum conversion or measurement is proved.",
                       "Transport reception can pass while system health is critical and heading remains unqualified.",
                       "Incomplete messages and final unpublished aggregates are retained limitations; no final record is manufactured."],
            "last_operation": last_operation,
        }

    status = inspect

    def preview_run(self, **arguments):
        from satgs.operator_runtime import preview_run
        return preview_run(self, **arguments)

    def execute_run(self, request_id, **arguments):
        from satgs.operator_runtime import execute_run
        return execute_run(self, request_id, **arguments)

    def run_status(self, request_id):
        from satgs.operator_runtime import run_status
        return run_status(self, request_id)

    def cancel_run(self, request_id):
        from satgs.operator_runtime import cancel_run
        return cancel_run(self, request_id)

    def _preview(self, kind, raw, settings, proposed, previous, public_proposed):
        revision = _digest(raw)
        record = {"schema_version": 1, "workspace_id": settings[MARKER]["id"], "kind": kind,
                  "expected_revision": revision, "previous": previous, "proposed": public_proposed,
                  "affected_plans": self._plans(revision), "_settings": proposed,
                  "changed": proposed != settings}
        identity = _digest(_bytes(record))
        if (self.root / f"cancel-{identity}.json").exists():
            record["review_attempt"] = uuid4().hex
            identity = _digest(_bytes(record))
        name = f"preview-{identity}.json"
        payload = _bytes({**record, "preview_id": identity})
        path = self.root / name
        if path.exists():
            if read_regular_bytes(str(path), input_kind="Preview") != payload:
                raise OperatorError("Existing preview is incomplete or inconsistent.", "artifact", 4)
        else:
            _write_new(path, payload)
        return {key: value for key, value in {**record, "preview_id": identity}.items() if key != "_settings"}

    def preview_location(self, latitude_deg, longitude_deg, altitude_m, altitude_reference,
                         expected_revision=None):
        if altitude_reference not in ALTITUDE_REFERENCES:
            raise OperatorError("Altitude reference must be unspecified or mean_sea_level; no conversion is inferred.")
        raw, settings = self._read()
        revision = _digest(raw)
        if expected_revision is not None:
            _identity(expected_revision, "Station revision")
        try:
            prepared = prepare_manual_location(settings, latitude_deg=latitude_deg, longitude_deg=longitude_deg,
                                                altitude_m=altitude_m, expected_revision=revision if expected_revision is None else expected_revision,
                                                current_revision=revision)
        except LocationError as error:
            raise OperatorError(str(error), "stale_revision" if expected_revision is not None and expected_revision != revision else "invalid",
                                3 if expected_revision is not None and expected_revision != revision else 2) from None
        proposed = prepared.settings()
        proposed["operator"]["altitude_reference"] = altitude_reference
        proposed["ground_station_configured"] = True
        return self._preview("location", raw, settings, proposed, _declared_location(settings), _declared_location(proposed))

    def preview_components(self, profile, changes=None, ptu_model="QPT130", expected_revision=None):
        raw, settings = self._read()
        revision = _digest(raw)
        if expected_revision is not None:
            _identity(expected_revision, "Station revision")
        if expected_revision is not None and expected_revision != revision:
            raise OperatorError("Station changed; reload before changing component selection.", "stale_revision", 3)
        if ptu_model not in ("QPT130", "QPT-130"):
            raise OperatorError("This physical pelican-qpt130 case requires QPT130, including Custom selections.")
        catalog = _catalog()
        try:
            if profile in ("full_msel", "guided_arrow"):
                document = expand_preset(catalog, profile).to_dict()
            elif profile in ("custom", "Custom"):
                document = deepcopy(settings["operator"].get("selection")) or expand_preset(catalog, "guided_arrow").to_dict()
                document["preset"] = None
                document["id"] = "operator-custom"
            else:
                raise OperatorError("Profile must be full_msel, guided_arrow or custom.")
            if changes is not None:
                if type(changes) is dict and "selections" in changes:
                    document.update(deepcopy(changes))
                elif type(changes) is dict:
                    selections = {item["component"]: item for item in document["selections"]}
                    for identity, value in changes.items():
                        if identity not in selections:
                            raise OperatorError("Component change names an unknown selection.")
                        selections[identity].update({"mode": value} if type(value) is str else value)
                    document["selections"] = list(selections.values())
                else:
                    raise OperatorError("Component changes must be a selection document or component mapping.")
            configuration = parse_configuration(document, catalog)
            plan = plan_configuration(configuration, catalog).to_dict()
            diagnostics = validate_selection_contract(configuration, catalog)
            if diagnostics:
                detail = " ".join(f"{item['component']}: {item['message']}" for item in diagnostics)
                raise OperatorError("Component selection violates the canonical profile or hardware identity contract. " + detail)
            proposed = deepcopy(settings)
            proposed["operator"]["selection"] = configuration.to_dict()
            return self._preview("components", raw, settings, proposed, settings["operator"].get("selection"),
                                 {"configuration": configuration.to_dict(), "plan": plan, "ptu_model": "QPT130"})
        except (InputError, TypeError, KeyError, ValueError) as error:
            if isinstance(error, OperatorError):
                raise
            raise OperatorError("Component selection is invalid or unsupported.") from None

    def _replace(self, original, settings):
        payload = _bytes(settings)
        _parse_station_yaml(payload, allow_inline_ca=True)
        temporary = self.root / f".station-{uuid4().hex}.json"
        _write_new(temporary, payload)
        replaced = False
        try:
            current, _ = self._read()
            if current != original:
                raise OperatorError("Station changed during save; reload before applying.", "stale_revision", 3)
            directory = open_workspace(self.root)
            try:
                os.replace(temporary.name, "station.json", src_dir_fd=directory, dst_dir_fd=directory)
                replaced = True
                try:
                    os.fsync(directory)
                except OSError:
                    return payload, "Configuration saved; directory durability could not be confirmed."
            finally:
                os.close(directory)
            return payload, None
        except OSError:
            raise OperatorError("Configuration could not be saved; previous station remains selected.", "io", 4) from None
        finally:
            if not replaced and temporary.exists():
                temporary.unlink()

    def _validate_preview(self, settings, preview):
        proposed = preview.get("_settings")
        if type(proposed) is not dict or proposed.get(MARKER) != settings[MARKER]:
            raise OperatorError("Preview changes the managed station identity.")
        expected = deepcopy(settings)
        try:
            if preview.get("kind") == "location":
                expected = prepare_manual_location(settings,
                    latitude_deg=proposed.get("ground_station_lat"),
                    longitude_deg=proposed.get("ground_station_lon"),
                    altitude_m=proposed.get("ground_station_altm"),
                    expected_revision=preview["expected_revision"], current_revision=preview["expected_revision"]).settings()
                reference = proposed["operator"]["altitude_reference"]
                if reference not in ALTITUDE_REFERENCES:
                    raise OperatorError("Preview altitude reference is invalid.")
                expected["operator"]["altitude_reference"] = reference
                expected["ground_station_configured"] = True
            elif preview.get("kind") == "components":
                catalog = _catalog()
                configuration = parse_configuration(proposed["operator"]["selection"], catalog)
                if validate_selection_contract(configuration, catalog):
                    raise OperatorError("Preview component selection violates the shared contract.")
                expected["operator"]["selection"] = configuration.to_dict()
            else:
                raise OperatorError("Preview operation is unsupported.")
        except (KeyError, TypeError, LocationError, InputError):
            raise OperatorError("Preview values are invalid.") from None
        if expected != proposed or type(preview.get("changed")) is not bool or preview["changed"] != (settings != proposed):
            raise OperatorError("Preview changes unrelated station settings or has inconsistent results.")
        return proposed

    def apply(self, preview_id):
        identity = _identity(preview_id, "Preview")
        try:
            with StationLease(self.root):
                raw, settings = self._read()
                receipt_path = self.root / f"receipt-{identity}.json"
                if receipt_path.exists():
                    receipt = self._artifact(receipt_path.name)
                    if receipt.get("workspace_id") != settings[MARKER]["id"] or receipt.get("preview_id") != identity:
                        raise OperatorError("Operation receipt identity does not match this station.", "artifact", 4)
                    return receipt
                if (self.root / f"cancel-{identity}.json").exists():
                    raise OperatorError("Preview was cancelled; create a new preview before applying.", "cancelled", 3)
                preview = self._artifact(f"preview-{identity}.json")
                if preview.get("workspace_id") != settings[MARKER]["id"] or preview.get("preview_id") != identity:
                    raise OperatorError("Preview belongs to another station.")
                original_record = {key: value for key, value in preview.items() if key != "preview_id"}
                if _digest(_bytes(original_record)) != identity:
                    raise OperatorError("Preview integrity check failed.", "artifact", 4)
                last = settings["operator"].get("last_operation")
                recovered = bool(last and last.get("preview_id") == identity)
                if not recovered and preview.get("expected_revision") != _digest(raw):
                    raise OperatorError("Station changed after preview; reload and review a new preview.", "stale_revision", 3)
                changed = preview["changed"]
                warning = None
                if not recovered:
                    proposed = self._validate_preview(settings, preview)
                if not recovered and changed:
                    proposed["operator"]["generation"] = settings["operator"]["generation"] + 1
                    proposed["operator"]["last_operation"] = {"preview_id": identity, "kind": preview["kind"],
                        "result": "saved", "changed": True, "active_run_changed": False}
                    raw, warning = self._replace(raw, proposed)
                result = {"operation": "apply", "preview_id": identity, "kind": preview["kind"],
                          "workspace_id": settings[MARKER]["id"],
                          "result": "saved" if changed else "unchanged", "changed": changed,
                          "configuration_saved": changed, "station_revision": _digest(raw),
                          "active_run_changed": False, "planning_revalidation_required": changed,
                          "owner_reinitialization_required": True, "owner_state": "not_checked",
                          "receipt_recorded": True, "partial": bool(warning), "warnings": [warning] if warning else []}
                try:
                    _write_new(receipt_path, _bytes(result))
                except OperatorError:
                    result.update(receipt_recorded=False, partial=True)
                    result["warnings"].append("Configuration outcome is shown, but the immutable receipt could not be completed.")
                return result
        except ActivityError as error:
            raise _activity(error) from None

    def cancel(self, preview_id):
        identity = _identity(preview_id, "Preview")
        try:
            with StationLease(self.root):
                raw, settings = self._read()
                applied = settings["operator"].get("last_operation")
                if ((self.root / f"receipt-{identity}.json").exists()
                        or type(applied) is dict and applied.get("preview_id") == identity):
                    raise OperatorError("An applied preview cannot be cancelled.", "conflict", 3)
                preview = self._artifact(f"preview-{identity}.json")
                result = {"operation": "cancel", "preview_id": identity, "result": "cancelled",
                          "configuration_saved": False, "active_run_changed": False}
                path = self.root / f"cancel-{identity}.json"
                if not path.exists():
                    if preview.get("expected_revision") != _digest(raw):
                        raise OperatorError("Station changed after preview; cancellation cannot assert an unapplied outcome.",
                                            "stale_revision", 3)
                    _write_new(path, _bytes(result))
                return result
        except ActivityError as error:
            raise _activity(error) from None

    def record_plan(self, plan):
        if type(plan) is not dict:
            raise OperatorError("Plan must be a public document.")
        try:
            with StationLease(self.root):
                revision, _ = self.snapshot()
                if plan.get("station_revision") != revision:
                    raise OperatorError("Station changed during planning; recompute from the saved station.", "stale_revision", 3)
                document = deepcopy(plan)
                identity = document.pop("plan_id") if "plan_id" in document else _digest(_bytes(document))
                _identity(identity, "Plan")
                document.update(plan_id=identity, planning_only=True)
                path = self.root / f"plan-{identity}.json"
                payload = _bytes(document)
                if path.exists():
                    if read_regular_bytes(str(path), input_kind="Plan") != payload:
                        raise OperatorError("Plan identity already names different bytes.", "conflict", 3)
                else:
                    _write_new(path, payload)
                return document
        except ActivityError as error:
            raise _activity(error) from None

    def replay(self, state):
        if type(state) is not str or state not in REPLAY_STATES:
            raise OperatorError("Unsupported synthetic replay state.")
        try:
            with StationLease(self.root):
                raw, settings = self._read()
                settings["operator"]["replay_state"] = state
                _, warning = self._replace(raw, settings)
            result = self.inspect()
            result["partial"] = bool(warning)
            return result
        except ActivityError as error:
            raise _activity(error) from None

    def install_software(self, wheelhouse, environment, *, expected_revision=None):
        from satgs.operator_install import install_software

        return install_software(self, wheelhouse, environment, expected_revision=expected_revision)

    def report(self):
        report = self.inspect()
        results = []
        bench_results = []
        installations = []
        paths = sorted(self.root.iterdir())
        names = {path.name for path in paths}
        for path in paths:
            install = re.fullmatch(r"install-([0-9a-f]{32})-(started|result)\.json", path.name)
            if install:
                if len(installations) >= 256:
                    raise OperatorError("Workspace exceeds the supported 256-install-record limit.")
                record = self._artifact(path.name)
                if (record.get("schema") != "satgs-software-install.v1" or record.get("attempt_id") != install[1]
                        or record.get("workspace_id") != report["workspace_id"]):
                    raise OperatorError("Install receipt identity does not match this station or filename.", "artifact", 4)
                fields = {"schema", "operation", "attempt_id", "workspace_id", "station_revision", "environment",
                          "wheelhouse", "configuration_saved", "application_selected", "services_started",
                          "hardware_opened", "software_complete", "profile_complete", "verification",
                          "native_runtime_verified", "unresolved", "result", "partial", "exit_code", "log_file",
                          "python", "error", "packages", "receipt_file", "status_command"}
                exported = {key: value for key, value in record.items() if key in fields}
                exported.update(current_configuration=record.get("station_revision") == report["station_revision"],
                                record_kind=install[2],
                                result_present=f"install-{install[1]}-result.json" in names)
                installations.append(exported)
            bench = re.fullmatch(r"bench-([0-9a-f]{32})-(started|result)\.json", path.name)
            if bench:
                if len(results) + len(bench_results) >= 256:
                    raise OperatorError("Workspace exceeds the supported 256-result limit.")
                record = self._artifact(path.name)
                if record.get("schema") != "satgs-bench-operation.v1" or record.get("attempt_id") != bench[1]:
                    raise OperatorError("Bench record identity does not match its filename.", "artifact", 4)
                exported = _bench_report_record(record)
                exported.update(record_kind=bench[2],
                                result_present="bench-" + bench[1] + "-result.json" in names)
                bench_results.append(exported)
            if re.fullmatch(r"(?:receipt|cancel)-[0-9a-f]{64}\.json", path.name):
                if len(results) + len(bench_results) >= 256:
                    raise OperatorError("Workspace exceeds the supported 256-result limit.")
                record = self._artifact(path.name)
                fields = {"operation", "preview_id", "kind", "workspace_id", "result", "changed",
                          "configuration_saved", "station_revision", "active_run_changed",
                          "planning_revalidation_required", "owner_reinitialization_required",
                          "owner_state", "receipt_recorded", "partial", "warnings"}
                results.append({key: value for key, value in record.items() if key in fields})
        report.update(operation_results=results, bench_results=bench_results, installations=installations,
                      report_kind="operator_workspace_inspection",
                      live_checks_started=False, historical_baseline="carried_forward_separate_evidence",
                      accepted_baseline_commit="280fb4a8dc11efa35c190c27ebb147e5a2db689b")
        return report

    def export_report(self, output):
        report = self.report()
        _write_new(Path(output), _bytes(report))
        return {"operation": "export_report", "result": "exported", "output": str(Path(output)),
                "station_revision": report["station_revision"], "configuration_saved": False,
                "live_checks_started": False}
