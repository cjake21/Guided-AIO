# 7. Operate the PTU through its selected owner

Use PTU for a deliberate manual-control session, not to configure the station's
latitude/longitude or align the antenna. The native page and interactive bench
CLI use one shared session. Explicit local-serial mode owns the driver in that
session; broker mode uses the foreground manager. Both reuse the same owner
command checks and serialptu encoder/parser. Arrow callbacks never build serial
commands themselves. A failed broker connection never switches to local serial.

The QPT130/PTCR20 manual and query-only sessions now use explicit immutable
configuration. Scheduled satellite tracking uses the separate run-request workflow.
Controlled software acceptance does not physically qualify the unit or cable.

## Daily local control without JSON files

Open the existing PTU tab and select **Save local QPT130** once. With the
configuration field empty, this saves the already selected Pelican QPT130
connection in the shared station workspace. It does not open the port. Later
GUI and CLI sessions use that saved connection automatically. Connect remains
an explicit action. If you already have a reviewed local JSON with numeric
limits or a no-go region, choose it before Save to retain those exact settings.
An override file used only for Connect does not replace the saved selection.

After Connect returns current position, hold a directional button to jog and
release it to request Stop. Keyboard arrows work while the PTU direction area
has focus. No degree increment or separate step-enable action is needed in local
mode. Losing focus, changing tabs, hiding or closing the window ends the hold
and requests Stop. A lost renewal or failed exchange also ends further jog
commands. These are software requests, not proof of physical stopping.

If release interrupts a jog reply, the local owner submits Stop before waiting
for that reply to finish. It keeps the interrupted jog reply separate from the
Stop reply, then obtains checked position feedback. Another hold is allowed only
after those checks succeed. A failed Stop or readback leaves motion blocked;
retain the hold and Stop results and inspect the session before reconnecting.
An acknowledgement and returned position still do not prove physical stopping.

Jog uses the original single-axis velocity encoding at normalized speed 1.
The PTU's configured soft limits remain enabled. Unlike the old GUI, this
application does not send the soft-limit override bit. Continuous jog has no
encoded endpoint: the software numeric travel envelope and no-go rectangle
are **not enforced during jog**. Do not interpret successful jogging as path
clearance. Numeric Preview/Move retain their existing endpoint checks.
Position shown while held comes from the jog acknowledgement's returned position;
generic Status does not secretly renew motion.

The equivalent CLI setup and session are:

```sh
satgs-operator bench-configure --transport local-serial
satgs-operator bench
```

Enter `connect`, then `jog right 2` for two seconds of local jogging followed
by Stop. Use `jog left 2`, `jog up 1` or `jog down 1` as appropriate under
supervision. The duration is seconds, not degrees or a measured travel distance.
`stop` or `disarm` interrupts a jog; `quit` and end-of-input also end it.
Durations must be finite, greater than zero and no more than 3600 seconds.
Inspect `status`, then `disconnect`. Reports retain jog submission counts,
last exchange and Stop outcome. Command acceptance is not movement completion.

To save an existing local configuration instead of creating the default:

```sh
satgs-operator bench-configure --transport local-serial --import-configuration "$HOME/satgs/manual-local-ptu.json"
```

Initial saved defaults use the selected QPT130 identity below, one-second
exchanges, five-second feedback age, the inherited numeric pan/tilt envelope,
a 360-degree numeric maximum change and an explicitly unconfigured no-go
rectangle. Saving again without an import preserves existing saved settings.
It cannot replace an active session. No active run's frozen policy changes.
The older file-based commands below remain available for explicit query-only,
custom numeric-policy or broker configurations.

## Prepare access and identify the unit

For the direct local bench, create a query-only configuration without
opening a device, starting a broker or changing the saved station:

```sh
satgs-operator bench-configure --transport local-serial --output "$HOME/satgs/local-ptu.json"
```

The parent directory must already exist. This creates only `local-ptu.json`,
readable/writable only by the creating user, and refuses to replace it. No
broker credentials, broker XML, Messenger connection or manager service is
needed. In the existing PTU tab's Configuration JSON chooser, select
`/home/admin/satgs/local-ptu.json`.
There is no `/absolute` folder to find: that wording in older instructions was
a placeholder, not an installed directory.

This explicitly selects the local serial route for the mechanical bench only.
It does not satisfy the broker, navigation or scheduled-pointing requirements
of Full M-SEL or Guided Arrow. The manager-capable application supplies the
serial prerequisites; a client-only installation does not silently install them.
Keep the distributed route below for workflows that need it.

Manager ID 1 is the software outcome identity, not a PTCR20 wire address or
permission to share a device. In local mode it identifies the session's owner.
The generated one-second exchange timeout and five-second feedback age are
explicit software budgets, not measured hardware guarantees; override them with
`--exchange-timeout` and `--feedback-max-age` if the reviewed arrangement requires it.

For manual control, use a different new output name and explicitly supply
`--manual-max-change-deg` plus either `--no-go-rectangle PAN_MIN PAN_MAX TILT_MIN TILT_MAX`
or `--no-go-unconfigured`. The latter declares a genuinely unconfigured region;
it must not erase an existing restriction. The software envelope comes from the
pinned QPT130 path: pan -215 to +215 degrees and mechanical tilt -90 to 0 degrees.
These are not independently measured mechanical stops. The rectangle must use
the same mechanical frame. The original tracking no-go azimuth 290..330 degrees,
elevation 0..30 degrees would map to pan -70..-30, tilt -90..-60 only with the
original zero pan offset; do not assume that calibration for another installation.
Endpoint checks do not evaluate travel between endpoints.

The following is a complete software configuration example only for a setup
whose one-degree maximum and zero-offset mechanical rectangle are confirmed:

```sh
satgs-operator bench-configure --transport local-serial --output "$HOME/satgs/manual-local-ptu.json" --manual-max-change-deg 1 --no-go-rectangle -70 -30 -90 -60
```

Generating it does not authorize movement. Query-only configurations reject
Move, arrows and Stop. The older `config/isolated-bench/*.example.json` files
remain incomplete TLS templates for separately assigned trust/credentials.

The selected device is
`/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller_EBCUb14C705-if00-port0`:
vendor/product `067b:23a3`, serial `EBCUb14C705`, interface `00`, driver `pl2303`.
The owner verifies its identity before and after opening. Current `/dev/ttyUSB0`
is not a fallback. The Cube's ttyACM interfaces are unrelated.

This candidate retains the original QPT130/PTCR20 settings: 9600 baud, 8 data
bits, no parity, one stop bit, no flow control, RTS/DTR asserted. These are
source-derived settings approved for the candidate, not measurements of the
cable. Opening applies serial settings/control lines and may flush input. It
does not automatically home, reset, calibrate, park or move.

## Retained broker route

This subsection is not required for local-serial operation. To choose the
separate broker route explicitly, generate `bench.json` with
`satgs-operator bench-configure --transport loopback-plaintext-bench --output "$HOME/satgs/bench.json"`.
It creates a matching private `bench.broker.xml` with generated credentials.
Do not attach those files to reports. Existing commands without `--transport`
retain this broker selection for compatibility; use `--transport local-serial`
for the direct route. Mixed local and broker settings are rejected.

The generated broker listener is restricted to `127.0.0.1:61613`, with
authentication, no bridge and no JMX/web-console configuration. Do not expose
plaintext or reuse production credentials. Operational pointing remains TLS-only.
Start only the assigned local broker using its matching private broker XML and
the administrator's existing ActiveMQ Classic installation. This application
update supplies configuration, not Java or a broker installation. The original
61613 recipe is a reference, not proof that ActiveMQ is installed or running on
this Pi. No service starts automatically and there is no production fallback.
With the local broker ready and the physical preflight complete, start the
foreground manager with the same JSON that the GUI/CLI will select:

```sh
~/satgs-jog-20261119-v2-app-manager/bin/satgs-bench-manager --configuration "$HOME/satgs/bench.json" --duration 600
```

For broker manual control, generate an explicit broker manual configuration and
select that same JSON in both places. A local-serial configuration is rejected
by the foreground manager before any transport or device acquisition.
The example's
600 seconds is a software manager lifetime, not a motion or physical-stop
deadline. Keep its output. Connect in the GUI requests that existing manager;
it does not create a second serial owner.
Complete the physical and exclusive-access preflight before manager launch:
activation opens serial, while GUI Connect requests status from that owner.

This page covers PTU pan/tilt control. It does not provide a separate remote
terminal unit (RTU) interface.

## Connect one owner

Only one owner may control the unit. Do not run the old direct-serial GUI, a
manager or another CLI/GUI beside the selected local session. A conflict is rejected rather than forced
through. Opening PTU, editing target numbers, reading Help or changing tabs does
not connect to equipment or request a move.

The broker manual/query manager permits one connected controller, including
when another GUI or CLI uses a different workspace. A competing Connect reports
busy without querying the device. Explicit successful Disconnect releases that
claim. Closing a client locally, losing its connection or cancelling it does
not authorize another client to take over. If no correlated Disconnect is
possible, end the foreground manager under the approved recovery procedure
before starting a replacement. That passive cleanup is not a physical Stop.

The serial owner uses cooperative locking and Linux exclusive-open protection.
It does not evict another process or prove that no pre-existing noncooperating
reader exists. Confirm no other reader is using the adapter before Connect.

On PTU use the saved local connection or choose a temporary Configuration JSON,
then Connect. Local Connect opens
the selected serial connection and queries actual position without movement.
Allow up to five seconds for local Connect. Initial unanswered status probes are
repeated at 0.5-second intervals, at most ten times. After repeated probes produce
feedback, the owner validates subsequent status frames and waits for 0.5 seconds
without new bytes within that same five-second budget. A partial or corrupt reply
fails the connection. This initial phase does not change the saved one-second
timeout for ordinary commands or program the unit's soft limits.

Movement becomes available only after valid current-position feedback. If Connect
reports no reply, open Results > Report: its Connect result retains every probe's
request/response bytes, write count and outcome. A complete write with an empty
response means no reply was received in the bounded initial phase. It does not
identify a cable, power or controller fault. Disconnect before a new attempt.
PTCR20 replies have no transaction identifier; late startup replies cannot be
assigned to a particular repeated query. Unexpected later input remains a failure.
Status requests evidence from that same owner. Disconnect releases the session's local
resources. Neither Connect nor Disconnect requests an automatic move, park or
reset. An unavailable prerequisite leaves controls unavailable with a diagnostic.

## Read reported position without changing the target

Reported pan/tilt and Target pan/tilt have different purposes. Reported values
come from actual protocol/owner position responses. Target fields hold what you
are editing or requesting. A command acknowledgement is not an angle measurement,
and a reported protocol position is not independently measured physical arrival.

Position retains source/time/freshness. Unknown, stale, disconnected or unavailable
readback is not replaced with zero. Controlled/rehearsal provenance is retained.
Background Status polling is non-overlapping, skips a busy session, uses the
configured bounded cadence and stops with its owned session. Refresh never
overwrites a partly typed target.

If readback is stale, mismatched or missing, do not repeatedly press Move or an
arrow. Inspect the exact owner/transport outcome. Movement cannot use requested
coordinates as a substitute for current evidence.

## Use numeric positioning

Enter Target pan and tilt in degrees, click Preview, inspect the proposed
endpoint/policy outcome, then Move. Editing or previewing alone never moves.
The CLI equivalent within an admitted session is `preview PAN TILT`, followed
by `move`. Use finite numbers within the configured limits and allowed change.

Numeric positioning and discrete steps retain frozen policy and final encoded
endpoint checks. Continuous local jog is the separate contract described above.
A numeric target whose encoded value enters a forbidden endpoint is rejected.
Endpoint approval does not establish safe trajectory clearance. No soft-limit
override is added to make a control appear responsive.

Manual context coordinates are mechanical pan/tilt degrees, not azimuth,
elevation, GPS heading or station location. Each request changes one axis by
at most the configured limit; set the other numeric axis to its latest returned
value. Requested and final encoded endpoints both obey the inclusive no-go
rectangle. There is no invented calibration, wrap, clamp or trajectory check.

## Retained discrete steps for broker control and explicit CLI use

The local GUI arrows use press-and-hold jog. This older discrete-step workflow
remains available for broker sessions and explicit CLI `manual`/`step` commands.

In Directions: hold locally / broker steps, enter an explicit
Broker step (degrees), then choose Enable broker steps. There is no default
increment chosen for your unit. The maximum comes from the reviewed
`max_change_degrees`; the minimum meaningful unit is the
selected protocol resolution, 0.1 degree for PTCR20 or 0.01 degree for PTCR96.
Other binding, range and policy checks still apply.

| Control | Requested change from fresh reported position |
| --- | --- |
| Left / `step left` | Decrease pan by one selected step |
| Right / `step right` | Increase pan by one selected step |
| Up / `step up` | Increase tilt by one selected step |
| Down / `step down` | Decrease tilt by one selected step |

One action performs correlated Status, computes one axis's absolute target,
previews it and submits Move through the same owner path as typed positioning.
It requests bounded motion when that session is admitted; it does not merely
edit a number and claim a move. Failed child phases and their correlated outcomes
remain visible. Busy dispatch rejects/skips further work rather than queueing
catch-up motion.

Click Keys in the pad to give arrow keys deliberate control focus. One press
requests one step; release before another press. Arrow keys in target entries,
text selection, scroll areas or another tab keep their normal behavior. Mouse
buttons provide the same four directions without global keyboard shortcuts.

Disarm disables the session-local step authorization. Stop, disconnect, close,
focus loss and tab/window changes also disarm it. Reconnect/restart does not
restore manual authorization. These local changes do not claim physical Stop.

![Retained handbook-release PTU page with directional steps, controlled readback and separate partially typed targets](assets/native-ptu-20261112.png)

Actual handbook-release host capture on CPython 3.11.16/x86-64 and Tcl/Tk 9,
using an owned private Xvfb display. Controlled rehearsal reports pan 0 degrees
and tilt -10 degrees while target fields retain partial edits. The one-degree
step and Keys focus are separate from actual readback. This is not a Pi capture,
live-equipment observation or physical commissioning evidence.

## Interactive CLI and controlled session sequence

The public entry grammar is:

```text
satgs-operator [--workspace PATH] bench [--configuration BENCH.json]
```

Omitting `--configuration` uses the saved local connection. `BENCH.json` denotes
a temporary completed private setup, not an unfilled template. For the generated local example, use
`satgs-operator bench --configuration "$HOME/satgs/manual-local-ptu.json"`.
Do not run this CLI concurrently with a connected GUI. The sequence below is usable only if the one-degree increment,
starting point and resulting travel are authorized for that supervised session:

```text
connect
status
manual 1
step left
step right
step up
step down
disarm
status
disconnect
quit
```

The configured limits must permit a one-degree step. Inspect each
returned phase/outcome and actual starting readback rather than assuming the
requested target became current. For numeric parity, use the reported starting
position and a permitted endpoint with `preview PAN TILT`, then `move`; do not
invent coordinates merely to complete the transcript. The consolidated
acceptance report records the actual fixture values, outcomes and artifacts.

`manual STEP_DEGREES` enables the explicit increment. `step` accepts only left,
right, up or down; `disarm` clears authorization. Existing connect, status,
preview, move, stop, disconnect and quit remain available under their existing
admission. Invalid/nonfinite increment/targets, absent feedback, stale outcomes,
policy violations and concurrent-run conflicts reject without an authorized move.

## Stop failure and safe recovery

Stop is a separate owner operation. Local cancellation, passive disconnect,
park/reset and command acknowledgement do not establish physical stopping.
A required Stop failure remains latched and blocks further motion, including
after status/reconnect. Do not retry movement to clear that state.

Retain the outcome and follow the allocated unit's separately approved physical
recovery procedure. Closing releases owned local resources without automatic
park/reset. A command with an unresolved outcome remains unresolved; do not call
it completed because the window closed cleanly.

The actual PTCR20 Stop packet is the existing zero-jog command with its Stop
bit. Its acknowledgement and the following bounded status query are recorded
separately. Failure of the query does not erase the submitted Stop or its
acknowledgement. None of these establish physical stopping. A query-only
configuration rejects Stop and all motion operations; use manual capability
only after its explicit limits and supervised conditions have been established.

For first use, confirm the QPT130 cable/electrical hookup is the known-working
Pelican arrangement, exclusive access and a clear travel area. Connect and
inspect actual returned angles without requesting movement. Establish the lab's
independent stopping means and verify the supported Stop behavior under the
approved supervised procedure before testing bounded arrows or numeric moves.
Inspect/export the session afterward. The USB ID and inherited software settings
do not independently prove the physical wiring or travel safety.

The workspace retains explicit PTU operation attempts as `bench-<attempt_id>-started.json`
and `bench-<attempt_id>-result.json`. See [Results](results.md#find-what-was-saved-automatically)
for the step outcomes, partial-recording fields and files to preserve before recovery.

## What changed from the original PTU GUI

The original serialptu GUI really did have arrows, numeric controls and live
status updates. Its source is pinned in the [appendix](maintainer-reference.md).

| Interaction | Original serialptu GUI | Current SATGS session |
| --- | --- | --- |
| Left/Right | Press sends pan jog -1/+1; release sends zero jog | Local press/hold sends the same signs; release requests explicit Stop |
| Up/Down | Press sends tilt jog +1/-1; release sends zero jog | Local press/hold sends the same signs; broker arrows retain discrete steps |
| Limits | Jog passes `override_soft_limits=True` | Device soft-limit override stays clear; numeric endpoint/no-go checks do not apply to continuous jog |
| Numeric | Integer degrees; Move To/Return absolute, Move Delta relative | Finite degree targets, Preview then Move; steps use shared absolute owner path |
| Keyboard arrows | No arrow-key bindings | Deliberate Keys focus, press/release handling, no entry/scroll interception |
| Position display | Actual driver responses feed queued GUI status | Actual correlated owner responses, explicit freshness and separate target fields |
| Stop/release | Button release and ALL STOP send zero jog | Renewed local hold ends on release/focus loss/expiry; Stop and its returned outcome stay explicit |

Original keepalive defaults to 0.3-second status cadence with a 0.1-second loop
and bounded query wait; its protocol status path reissues the last jog command.
The local session explicitly refreshes jog at the same 0.3-second cadence while
the GUI renews its hold. Ordinary Status never reissues motion. The new controls
preserve familiar directions while retaining a separate Stop outcome and
truthful readback. Broker arrows retain discrete bounded requests.

Physical commissioning still needs the allocated model/protocol/address and
limits, trustworthy current-position/Stop semantics, calibration/no-go admission,
alignment/trajectory requirements, serial ownership and live response evidence.
Software widget/owner tests do not establish those physical facts.
