"""Actual CLI and shared session with real owners at controlled external boundaries."""
from contextlib import ExitStack
import errno
import json
import io
from pathlib import Path
import queue
import ssl
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from satgs import operator_bench
from satgs.deployment_cli import CliInputError, MAX_INPUT_BYTES, read_json_document
from satgs.operator_activity import ActivityError, StationLease
from satgs.operator_core import OperatorError, initialize_workspace
from satgs.runtime_configuration import _freeze


class BenchAcquisitionLifetimeTests(unittest.TestCase):
    def test_completion_and_inflight_cancel_publish_in_one_order(self):
        local_cancel = threading.Event()
        relay_check = threading.Event()
        release_check = threading.Event()
        body_ready = threading.Event()
        leave_body = threading.Event()
        body_left = threading.Event()
        context_done = threading.Event()
        created, published_after_complete, errors = [], [], []
        original_check = local_cancel.is_set

        def check_cancel():
            if threading.current_thread().name == "operator-bench-acquisition-cancel":
                relay_check.set()
                if not release_check.wait(2):
                    errors.append("relay-check-timeout")
            return original_check()

        local_cancel.is_set = check_cancel

        def event():
            value = threading.Event()
            created.append(value)
            if len(created) == 1:
                original_set = value.set

                def publish_cancel():
                    published_after_complete.append(created[1].is_set())
                    original_set()

                value.set = publish_cancel
            return value

        primitives = SimpleNamespace(Event=event, Lock=threading.Lock, Thread=threading.Thread)

        def acquire():
            try:
                with operator_bench._transport_acquisition_cancel(local_cancel, time.monotonic() + 3):
                    body_ready.set()
                    if not leave_body.wait(2):
                        errors.append("body-release-timeout")
                    body_left.set()
            except BaseException:
                errors.append("acquisition-context")
            finally:
                context_done.set()

        with patch.object(operator_bench, "threading", primitives):
            caller = threading.Thread(target=acquire, name="controlled-acquisition-publication")
            caller.start()
            try:
                self.assertTrue(body_ready.wait(1))
                self.assertTrue(relay_check.wait(1))
                leave_body.set()
                self.assertTrue(body_left.wait(1))
                self.assertFalse(created[1].wait(.05), "completion overtook the relay's in-flight cancel check")
                local_cancel.set()
            finally:
                leave_body.set()
                release_check.set()
                caller.join(2)
            self.assertFalse(caller.is_alive())
            self.assertTrue(context_done.is_set())
            self.assertEqual(errors, [])
            self.assertEqual(published_after_complete, [False])
            self.assertTrue(created[0].is_set())
            self.assertTrue(created[1].is_set())
            late_cancel = threading.Event()
            with operator_bench._transport_acquisition_cancel(late_cancel, time.monotonic() + 1) as lifetime:
                self.assertFalse(lifetime.is_set())
            late_cancel.set()
            self.assertFalse(lifetime.is_set())
        self.assertFalse(any(worker.name == "operator-bench-acquisition-cancel" and worker.is_alive()
                             for worker in threading.enumerate()))


class BenchConfigurationReadTests(unittest.TestCase):
    def setUp(self):
        from test_messenger_lifecycle import PUBLIC_CA

        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "bench.json"
        self.ca = PUBLIC_CA

    def read(self, document):
        payload = json.dumps(document).encode("utf-8")
        self.path.write_bytes(payload)
        return operator_bench.read_bench_configuration(self.path)

    def test_actual_reader_retains_exact_inline_ca_finite_numbers_and_bytes(self):
        document = {"station": {"amq_ca_pem": self.ca, "bench_context": {
            "exchange_timeout_seconds": .1, "pan_min": -100.5}},
            "ptu_id": 2, "elevation_mask": 0.5, "no_go_data": None}
        payload = json.dumps(document, indent=2).encode("utf-8")
        self.path.write_bytes(payload)
        with patch.object(operator_bench, "read_regular_bytes", wraps=operator_bench.read_regular_bytes) as reader:
            actual, decoded = operator_bench.read_bench_configuration(self.path)
        self.assertEqual(reader.call_count, 1)
        self.assertEqual(actual, payload)
        self.assertEqual(decoded, document)
        with self.assertRaises(CliInputError):
            read_json_document(self.path)

    def test_session_and_foreground_adapter_use_the_same_reader_before_admission(self):
        from satgs import operator_bench_manager as adapter

        self.assertIs(adapter.read_bench_configuration, operator_bench.read_bench_configuration)
        self.read({"station": {"amq_ca_pem": self.ca, "timeout": .1}})
        rejected = OperatorError("controlled admission remains closed", "bench_not_admitted", 3)
        with patch.object(operator_bench, "_admit", side_effect=rejected) as admission:
            with self.assertRaises(OperatorError) as caught:
                operator_bench.BenchSession(None, self.path)
            self.assertIs(caught.exception, rejected)
            self.assertEqual(admission.call_count, 1)
        with patch.object(adapter, "_admit", side_effect=rejected) as admission:
            with self.assertRaises(OperatorError) as caught:
                adapter.run_manager(self.path, duration=1, cancel=threading.Event())
            self.assertIs(caught.exception, rejected)
            self.assertEqual(admission.call_count, 1)

    def test_actual_reader_rejects_malformed_duplicate_and_nonfinite_json(self):
        for payload in (b"{not-json", b"\xff", b'{"station":1,"station":2}',
                        b'{"station":{"nested":{"key":1,"key":2}}}',
                        b'{"station":{"value":NaN}}', b'{"station":{"value":Infinity}}',
                        b'{"station":{"value":-Infinity}}', b'{"station":{"value":1e400}}'):
            with self.subTest(payload=payload):
                self.path.write_bytes(payload)
                with self.assertRaises(CliInputError):
                    operator_bench.read_bench_configuration(self.path)

    def test_inline_ca_exception_is_only_exact_root_station_value(self):
        for document in (
            {"amq_ca_pem": self.ca},
            {"station": {"nested": {"amq_ca_pem": self.ca}}},
            {"station": {"amq_ca_pem": self.ca, "unrelated": self.ca}},
            {"station": {"amq_ca_pem": {"nested": self.ca}}},
            {"station": {"amq_ca_pem": [self.ca]}},
            {"station": [{"amq_ca_pem": self.ca}]},
            {"station": {"amq_ca_pem": self.ca}, "no_go_data": {"amq_ca_pem": self.ca}},
        ):
            with self.subTest(shape=list(document)):
                with self.assertRaises(CliInputError):
                    self.read(document)

    def test_inline_ca_data_and_ordinary_strings_keep_their_bounds(self):
        self.read({"station": {"amq_ca_pem": "x" * 65536}})
        for value in ("", "x" * 65537, "bad\x00data", "bad\x7fdata", "bad\vdata", "\u00e9", None, False):
            with self.subTest(kind=type(value).__name__, size=len(value) if isinstance(value, str) else None):
                with self.assertRaises(CliInputError):
                    self.read({"station": {"amq_ca_pem": value}})
        self.read({"station": {"amq_ca_pem": self.ca}, "ordinary": "x" * 4096})
        for value in ("x" * 4097, "bad\ntext", "bad\ttext"):
            with self.assertRaises(CliInputError):
                self.read({"station": {"amq_ca_pem": self.ca}, "ordinary": value})

    def test_actual_reader_keeps_byte_limit_with_inline_ca(self):
        payload = json.dumps({"station": {"amq_ca_pem": self.ca}}).encode("utf-8")
        payload += b" " * (MAX_INPUT_BYTES - len(payload))
        self.path.write_bytes(payload)
        self.assertEqual(operator_bench.read_bench_configuration(self.path)[0], payload)
        self.path.write_bytes(payload + b" ")
        with self.assertRaises(CliInputError):
            operator_bench.read_bench_configuration(self.path)

    def test_actual_reader_keeps_mapping_list_and_key_limits(self):
        for label, allowed, rejected in (
            ("mapping", {str(index): None for index in range(128)}, {str(index): None for index in range(129)}),
            ("list", [None] * 1024, [None] * 1025),
            ("key", {"k" * 80: None}, {"k" * 81: None}),
        ):
            with self.subTest(boundary=label):
                self.read({"station": {"amq_ca_pem": self.ca}, "payload": allowed})
                with self.assertRaises(CliInputError):
                    self.read({"station": {"amq_ca_pem": self.ca}, "payload": rejected})

    def test_actual_reader_counts_inline_ca_in_aggregate_depth_and_nodes(self):
        nested = 0
        for unused in range(31):
            nested = [nested]
        document = {"station": {"amq_ca_pem": self.ca}, "payload": nested}
        self.read(document)
        document["payload"] = [nested]
        with self.assertRaises(CliInputError):
            self.read(document)
        # Root, keys, station, CA, outer list and eight row lists consume 15 nodes.
        rows = [[None] * 1024 for unused in range(7)] + [[None] * 1009]
        document["payload"] = rows
        self.read(document)
        rows[-1].append(None)
        with self.assertRaises(CliInputError):
            self.read(document)


class CommandInput:
    def __init__(self):
        self.lines = queue.Queue()

    def __iter__(self):
        return self

    def __next__(self):
        try:
            return self.lines.get(timeout=5)
        except queue.Empty:
            raise RuntimeError("controlled CLI input timed out") from None

    def send(self, line):
        self.lines.put(line + "\n")


class ResultOutput:
    def __init__(self):
        self.condition = threading.Condition()
        self.pending = ""
        self.records = []

    def write(self, value):
        with self.condition:
            self.pending += value
            while "\n" in self.pending:
                line, self.pending = self.pending.split("\n", 1)
                if line:
                    self.records.append(json.loads(line))
            self.condition.notify_all()
        return len(value)

    def flush(self):
        pass

    def wait(self, predicate, *, after=0, timeout=3):
        deadline = time.monotonic() + timeout
        with self.condition:
            while True:
                for record in self.records[after:]:
                    if predicate(record):
                        return record
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise AssertionError("expected actual CLI result was not received")
                self.condition.wait(remaining)


def selected_bench_fixture(stack, directory, *, query=False, plaintext=False, configured=None):
    from ptu_control.ptu_manager import PtuManager
    from test_messenger_lifecycle import settings
    from test_ptu_bench import controlled_bench_driver, manual_settings, readback_settings
    from runtime_owner_test_support import BrokerHarness, LoopbackBrokerHarness

    configuration = configured if configured is not None else readback_settings() if query else manual_settings()
    if configured is None:
        configuration.update(settings(amq_dial_address="127.0.0.1"))
    if plaintext and configured is None:
        configuration.update(amq_transport="loopback-plaintext-bench", amq_use_ssl=False, amq_port=61613)
        del configuration["amq_ca_pem"], configuration["amq_tls_server_name"]
    context = configuration["readback_context" if query else "manual_context"]
    context.update(exchange_timeout_seconds=1, observation_max_age_seconds=5)
    document = dict(station=configuration, ptu_id=2)
    operator_bench._admit(document)
    path = directory / "selected-bench.json"
    path.write_text(json.dumps(document))
    harness = stack.enter_context((LoopbackBrokerHarness if plaintext else BrokerHarness)(2, 3))
    transport = harness.open(configuration)
    stack.callback(lambda: transport.close(deadline=time.monotonic() + 2))
    driver, native = controlled_bench_driver(stack, configuration)
    stack.callback(lambda: driver.close(deadline=time.monotonic() + 2))
    native.tilt_units = -100
    cancel = threading.Event()
    deadline = time.monotonic() + 30
    manager = PtuManager.open_bench(messenger=transport, settings=configuration, ptu_id=2,
        driver=driver, run_deadline=deadline, cancel=cancel)
    stack.callback(lambda: manager.close(deadline=time.monotonic() + 2))
    manager.activate(deadline=deadline, cancel=cancel)
    return SimpleNamespace(configuration=configuration, configuration_file=path, document=document,
        harness=harness, manager_transport=transport, driver=driver, native=native,
        manager=manager, manager_cancel=cancel, deadline=deadline, protocol=native.proto)


def local_bench_fixture(stack, directory, *, query=False, configured=None):
    from meteor_api.messenger import Messenger
    from ptu_control.ptu_client import PtuClient
    from ptu_control.ptu_manager import PtuManager
    from serialptu.acquisition import _DeviceSnapshot
    from serialptu.proto_impl import PTCR20
    from test_ptu_bench import manual_settings, readback_settings
    from test_ptu_manager_pointing import FollowingSerial

    configuration = configured if configured is not None else readback_settings() if query else manual_settings()
    configuration["bench_transport"] = "local-serial"
    context = configuration["readback_context" if query else "manual_context"]
    context.update(exchange_timeout_seconds=1, observation_max_age_seconds=5)
    document = dict(station=configuration, ptu_id=2)
    operator_bench._admit(document)
    path = directory / "selected-local-bench.json"
    path.write_text(json.dumps(document))
    native = FollowingSerial(PTCR20())
    native.tilt_units = -100
    stack.enter_context(patch("serialptu.ptu.serial.Serial", return_value=native))
    snapshot = _DeviceSnapshot("/dev/ttyUSB0", 7, 13, 188 * 256)
    stack.enter_context(patch("serialptu.ptu.verify_selected_device", return_value=snapshot))
    stack.enter_context(patch("serialptu.ptu.claim_selected_device"))
    for owner, name in ((operator_bench, "_open_transport"), (Messenger, "__init__"),
                        (Messenger, "prepare_transport"), (Messenger, "prepare_bench_loopback_transport"),
                        (PtuClient, "open_bench"), (PtuManager, "open_bench")):
        stack.enter_context(patch.object(owner, name, side_effect=AssertionError("local session acquired messaging")))
    return SimpleNamespace(configuration=configuration, configuration_file=path, document=document,
        manager=None, manager_transport=None, driver=None, native=native, protocol=native.proto)


class LocalSerialConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.path = self.directory / "local.json"

    def test_explicit_cli_creates_only_private_local_json_without_station_or_acquisition(self):
        from contextlib import redirect_stdout
        import stat
        from meteor_api.messenger import Messenger
        from satgs.operator_cli import main
        stream = io.StringIO()
        with redirect_stdout(stream), patch.object(Messenger, "prepare_bench_loopback_transport",
                side_effect=AssertionError("local configuration prepared messaging")), \
                patch("serialptu.ptu.serial.Serial", side_effect=AssertionError("configuration created driver")):
            result = main(["--workspace", str(self.directory / "absent"), "--format", "json",
                           "bench-configure", "--transport", "local-serial", "--output", str(self.path)])
        self.assertEqual(result, 0)
        self.assertEqual(list(self.directory.iterdir()), [self.path])
        self.assertEqual(stat.S_IMODE(self.path.stat().st_mode), 0o600)
        summary = json.loads(stream.getvalue())["result"]
        document = operator_bench.read_bench_configuration(self.path)[1]
        self.assertEqual(set(document["station"]), {"bench_transport", "readback_context"})
        self.assertEqual(summary["transport"], "local-serial")
        self.assertEqual(summary["mode"], "query-only")
        self.assertFalse(summary["device_opened"])
        self.assertFalse(summary["broker_started"])
        self.assertNotIn("broker_configuration", summary)

    def test_local_admission_rejects_mixed_unknown_and_missing_route_before_lease(self):
        from test_ptu_bench import manual_settings
        station = dict(manual_settings(), bench_transport="local-serial")
        for changes in ({"amq_username": "invalid"}, {"amq_password": "invalid"},
                        {"amq_dial_address": "127.0.0.1"}, {"amq_transport": "loopback-plaintext-bench"},
                        {"amq_use_ssl": False}, {"amq_ca_pem": None}, {"amq_unknown": None},
                        {"bench_transport": "unknown"}, {"bench_transport": None}, {"unrecognized": True}):
            with self.subTest(fields=list(changes)):
                self.path.write_text(json.dumps(dict(station=dict(station, **changes), ptu_id=2)))
                with patch.object(operator_bench, "StationLease", side_effect=AssertionError("invalid selection acquired lease")):
                    with self.assertRaises(OperatorError):
                        operator_bench.BenchSession(None, self.path)
        with self.assertRaises(OperatorError):
            operator_bench._admit(dict(station=manual_settings(), ptu_id=2))

    def test_local_configuration_requires_explicit_valid_manual_policy_and_new_file(self):
        for options in ({"max_change_degrees": 1}, {"no_go_rectangle": None}, {"manager_id": 0},
                        {"exchange_timeout": 0}, {"feedback_max_age": float("nan")},
                        {"max_change_degrees": 0, "no_go_rectangle": None}):
            with self.subTest(options=options):
                with self.assertRaises(OperatorError):
                    operator_bench.configure_local_serial_bench(self.path, **options)
                self.assertEqual(list(self.directory.iterdir()), [])
        self.path.symlink_to(self.directory / "absent")
        with self.assertRaises(OperatorError):
            operator_bench.configure_local_serial_bench(self.path)
        self.assertTrue(self.path.is_symlink())

    def test_generated_manual_configuration_reaches_shared_session_and_final_encoder(self):
        summary = operator_bench.configure_local_serial_bench(self.path, manager_id=2, max_change_degrees=9.96,
            no_go_rectangle=dict(pan_min=-70, pan_max=-30, tilt_min=-90, tilt_max=-60))
        before = self.path.read_bytes()
        with self.assertRaises(OperatorError):
            operator_bench.configure_local_serial_bench(self.path)
        self.assertEqual(self.path.read_bytes(), before)
        station = operator_bench.read_bench_configuration(self.path)[1]["station"]
        fixture = local_bench_fixture(self.stack, self.directory, configured=station)
        fixture.native.pan_units, fixture.native.tilt_units = -800, -700
        session = operator_bench.BenchSession(initialize_workspace(self.directory / "station"), self.path)
        self.stack.callback(session.close)
        self.assertFalse(fixture.native.opened)
        self.assertEqual(session.connect()["category"], "ok")
        self.assertIsNone(session.transport)
        self.assertEqual(session.perform("manual", step_degrees=9.96)["category"], "ok")
        self.assertEqual(session.perform("step", direction="right")["category"], "endpoint_rejected")
        self.assertEqual(fixture.native.motion(), [])
        self.assertEqual(session.perform("disconnect")["category"], "ok")
        self.assertFalse(fixture.native.opened)
        self.assertEqual(summary["mode"], "manual")

    def test_local_configuration_is_rejected_by_foreground_manager_before_metadata(self):
        from satgs import operator_bench_manager as adapter
        operator_bench.configure_local_serial_bench(self.path)
        with patch.object(adapter, "version", side_effect=AssertionError("local configuration read manager versions")), \
                patch.object(adapter, "_open_transport", side_effect=AssertionError("local configuration opened broker")):
            with self.assertRaises(OperatorError) as caught:
                adapter.run_manager(self.path, duration=1, cancel=threading.Event())
        self.assertEqual(caught.exception.code, "bench_not_admitted")

    def test_broker_failure_never_selects_the_local_owner(self):
        from ptu_control.bench_local import LocalBenchClient
        operator_bench.configure_loopback_bench(self.path)
        session = operator_bench.BenchSession(initialize_workspace(self.directory / "station"), self.path)
        self.stack.callback(session.close)
        with patch.object(operator_bench, "_open_transport", side_effect=OperatorError("controlled unavailable broker")), \
                patch.object(LocalBenchClient, "open", side_effect=AssertionError("broker failure selected local serial")):
            with self.assertRaises(OperatorError):
                session.connect()
        self.assertTrue(session.released)

    def test_missing_local_serial_prerequisite_reports_owner_version_and_releases_lease(self):
        from ptu_control.bench_local import LocalBenchClient
        operator_bench.configure_local_serial_bench(self.path)
        workspace = initialize_workspace(self.directory / "station")
        session = operator_bench.BenchSession(workspace, self.path)
        self.stack.callback(session.close)
        with patch.object(LocalBenchClient, "open", side_effect=ImportError("controlled missing prerequisite")):
            with self.assertRaises(OperatorError) as caught:
                session.connect()
        self.assertEqual(caught.exception.code, "owner_version")
        self.assertTrue(session.released)
        with StationLease(workspace.root):
            pass


class LoopbackConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.path = self.directory / "bench.json"

    def test_cli_creates_private_matching_broker_and_query_config_without_station_or_effects(self):
        from contextlib import redirect_stdout
        import stat
        import xml.etree.ElementTree as xml
        from satgs.operator_cli import main
        from meteor_api.messenger import Messenger
        stream = io.StringIO()
        with redirect_stdout(stream), patch.object(Messenger, "open_bench_loopback_bounded",
                side_effect=AssertionError("configuration cannot acquire transport")):
            result = main(["--workspace", str(self.directory / "absent-station"), "--format", "json",
                           "bench-configure", "--output", str(self.path), "--manager-id", "2"])
        self.assertEqual(result, 0)
        self.assertFalse((self.directory / "absent-station").exists())
        summary = json.loads(stream.getvalue())["result"]
        document = operator_bench.read_bench_configuration(self.path)[1]
        station = document["station"]
        self.assertEqual(document["ptu_id"], 2)
        self.assertIn("readback_context", station)
        self.assertNotIn("amq_ca_pem", station)
        self.assertEqual(summary["mode"], "query-only")
        self.assertFalse(summary["broker_started"])
        self.assertFalse(summary["device_opened"])
        self.assertTrue(station["amq_password"] not in stream.getvalue(), "credentials must not enter output")
        broker = Path(summary["broker_configuration"])
        for path in (self.path, broker):
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        root = xml.fromstring(broker.read_bytes())
        names = {node.tag.rsplit("}", 1)[-1]: node for node in root.iter()}
        self.assertTrue(names["authenticationUser"].attrib["password"] == station["amq_password"],
                        "private broker and client credentials must match")
        self.assertEqual(names["authenticationUser"].attrib["username"], station["amq_username"])
        self.assertEqual(names["transportConnector"].attrib["uri"], "stomp://127.0.0.1:61613")
        self.assertEqual(names["broker"].attrib["useJmx"], "false")
        self.assertNotIn("networkConnectors", names)
        self.assertNotIn("import", names)
        before = (self.path.read_bytes(), broker.read_bytes())
        with self.assertRaises(OperatorError):
            operator_bench.configure_loopback_bench(self.path)
        self.assertTrue(before == (self.path.read_bytes(), broker.read_bytes()),
                        "existing private configuration must remain unchanged")

    def test_generated_manual_config_reaches_actual_shared_session_and_encoder(self):
        summary = operator_bench.configure_loopback_bench(self.path, manager_id=2,
            max_change_degrees=1, no_go_rectangle=dict(pan_min=-70, pan_max=-30, tilt_min=-90, tilt_max=-60))
        document = operator_bench.read_bench_configuration(self.path)[1]
        context = document["station"]["manual_context"]
        self.assertEqual((context["pan_min"], context["pan_max"], context["tilt_min"], context["tilt_max"]),
                         (-215, 215, -90, 0))
        fixture = selected_bench_fixture(self.stack, self.directory, plaintext=True,
                                         configured=document["station"])
        workspace = initialize_workspace(self.directory / "station")
        session = operator_bench.BenchSession(workspace, self.path)
        self.stack.callback(session.close)
        self.assertEqual(session.connect()["category"], "ok")
        self.assertEqual(fixture.native.motion(), [])
        self.assertEqual(session.perform("manual", step_degrees=1)["category"], "ok")
        self.assertEqual(session.perform("step", direction="right")["category"], "ok")
        self.assertEqual(fixture.native.pan_units, 10)
        from runtime_owner_test_support import LoopbackBrokerSocket
        raw = LoopbackBrokerSocket(fixture.harness, "raw", {"closed": False})
        with self.assertRaises(BlockingIOError):
            raw.recv(1)
        self.assertFalse(hasattr(raw, "pending"))
        raw.close()
        self.assertEqual(fixture.harness.contexts, [])
        self.assertEqual(session.perform("stop")["category"], "ok")
        self.assertEqual(session.perform("disconnect")["category"], "ok")
        self.assertEqual(summary["mode"], "manual")

    def test_incomplete_manual_or_invalid_values_write_nothing(self):
        for options in ({"max_change_degrees": 1}, {"no_go_rectangle": None},
                        {"manager_id": 0}, {"exchange_timeout": 0}, {"feedback_max_age": float("nan")},
                        {"max_change_degrees": 0, "no_go_rectangle": None}):
            with self.subTest(options=options):
                with self.assertRaises(OperatorError):
                    operator_bench.configure_loopback_bench(self.path, **options)
                self.assertEqual(list(self.directory.iterdir()), [])

    def test_existing_broker_and_symlink_are_not_overwritten(self):
        broker = self.path.with_suffix(".broker.xml")
        broker.write_bytes(b"existing-broker")
        with self.assertRaises(OperatorError):
            operator_bench.configure_loopback_bench(self.path)
        self.assertFalse(self.path.exists())
        self.assertEqual(broker.read_bytes(), b"existing-broker")
        link = self.directory / "other.json"
        link.symlink_to(self.directory / "missing")
        with self.assertRaises(OperatorError):
            operator_bench.configure_loopback_bench(link)
        self.assertTrue(link.is_symlink())

    def test_second_write_failure_retains_broker_and_never_overwrites_raced_json(self):
        original = operator_bench._write_new

        def write(path, payload):
            if path == self.path:
                self.path.write_bytes(b"another-writer")
            original(path, payload)

        with patch.object(operator_bench, "_write_new", side_effect=write):
            with self.assertRaises(OperatorError) as failed:
                operator_bench.configure_loopback_bench(self.path)
        self.assertEqual(failed.exception.code, "setup_partial")
        self.assertIn("bench JSON was not completed", str(failed.exception))
        self.assertIn(str(self.path.with_suffix(".broker.xml")), str(failed.exception))
        self.assertEqual(self.path.read_bytes(), b"another-writer")
        self.assertTrue(self.path.with_suffix(".broker.xml").is_file())
        with self.assertRaises(OperatorError):
            operator_bench.configure_loopback_bench(self.path)

    def test_loopback_manual_final_encoded_forbidden_boundary_is_not_written(self):
        operator_bench.configure_loopback_bench(self.path, manager_id=2, max_change_degrees=9.96,
            no_go_rectangle=dict(pan_min=-70, pan_max=-30, tilt_min=-90, tilt_max=-60))
        document = operator_bench.read_bench_configuration(self.path)[1]
        fixture = selected_bench_fixture(self.stack, self.directory, plaintext=True,
                                         configured=document["station"])
        fixture.native.pan_units, fixture.native.tilt_units = -800, -700
        session = operator_bench.BenchSession(initialize_workspace(self.directory / "station"), self.path)
        self.stack.callback(session.close)
        self.assertEqual(session.connect()["category"], "ok")
        self.assertEqual(session.perform("manual", step_degrees=9.96)["category"], "ok")
        result = session.perform("step", direction="right")
        self.assertEqual(result["category"], "endpoint_rejected")
        self.assertEqual(fixture.native.motion(), [])
        self.assertEqual((fixture.native.pan_units, fixture.native.tilt_units), (-800, -700))
        self.assertEqual(session.perform("disconnect")["category"], "ok")


class SelectedBenchCLIControlTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.workspace = initialize_workspace(self.directory / "station")
        self.cli_thread = self.cli_exit = self.session = None
        self.release_reply = threading.Event()

    def prepare(self, query=False):
        fixture = selected_bench_fixture(self.stack, self.directory, query=query,
                                         plaintext=getattr(self, "plaintext", False))
        self.__dict__.update(vars(fixture))
        self.addCleanup(lambda: BenchCLIControlTests.release(self))

    def test_loopback_real_cli_manual_control_and_export(self):
        self.plaintext = True
        self.test_real_cli_manual_connect_arrows_numeric_stop_and_export()
        self.assertEqual(self.harness.contexts, [])
        self.assertEqual(self.harness.wraps, [])
        self.assertFalse(self.manager_transport.strict_instance_compatible(self.configuration))
        self.assertTrue(self.manager_transport.bench_loopback_instance_compatible(self.configuration))
        for raw in self.harness.raws:
            self.assertFalse(hasattr(raw, "pending"))

    def test_loopback_query_only_rejects_all_motion(self):
        self.plaintext = True
        self.test_real_cli_query_only_rejects_motion_and_stop_without_serial_submission()
        self.assertEqual(self.harness.contexts, [])

    def test_loopback_preserves_cross_workspace_controller_ownership(self):
        self.plaintext = True
        self.test_different_workspace_cli_cannot_steal_active_shared_session()
        self.assertEqual(self.harness.wraps, [])

    def test_loopback_policy_binding_distinguishes_transport_and_endpoint(self):
        from ptu_control.bench import ManualContext
        from test_ptu_bench import manual_settings
        from test_messenger_lifecycle import settings
        station = manual_settings()
        station.update(settings(amq_dial_address="127.0.0.1"))
        tls = ManualContext.from_settings(station, 2)
        plain = dict(station, amq_transport="loopback-plaintext-bench", amq_use_ssl=False, amq_port=61613)
        del plain["amq_ca_pem"], plain["amq_tls_server_name"]
        admitted = ManualContext.from_settings(plain, 2)
        self.assertNotEqual(tls.binding, admitted.binding)
        for changes in ({"amq_port": 61615}, {"amq_stomp_host": ""}, {"amq_stomp_host": "bench"}):
            self.assertNotEqual(admitted.binding, ManualContext.from_settings(dict(plain, **changes), 2).binding)
        for changes in ({"amq_dial_address": "127.0.0.2"}, {"amq_use_ssl": True},
                        {"amq_tls_server_name": None}, {"amq_ca_pem": None}):
            with self.assertRaises(OperatorError):
                operator_bench._admit(dict(ptu_id=2, station=dict(plain, **changes)))

    def test_real_cli_manual_connect_arrows_numeric_stop_and_export(self):
        self.prepare()
        BenchCLIControlTests.start_cli(self)
        connected = self.command("connect", "connect")
        self.assertEqual(connected["category"], "ok")
        self.assertEqual(connected["exchanges"][0]["request"], "023100000000003103")
        self.assertEqual(connected["tilt"], -10)
        self.assertEqual(self.native.motion(), [])
        self.assertEqual(self.command("manual 1", "manual")["category"], "ok")
        for direction in ("left", "right", "up", "down"):
            result = self.command("step " + direction, "step")
            self.assertEqual(result["category"], "ok")
            self.assertEqual(result["physical_state"], "indeterminate")
        observed = self.command("status", "status")
        self.assertEqual(observed["category"], "ok")
        self.assertEqual((observed["pan"], observed["tilt"]), (0, -10))
        self.assertEqual(observed["physical_state"], "indeterminate")
        self.assertEqual(self.command("preview 2 -10", "preview")["category"], "ok")
        moved = self.command("move", "move")
        self.assertEqual(moved["category"], "ok")
        self.assertEqual([row["operation"] for row in moved["exchanges"]], ["status", "move"])
        stopped = self.command("stop", "stop")
        self.assertEqual(stopped["category"], "ok")
        self.assertEqual([row["operation"] for row in stopped["exchanges"]], ["stop", "status"])
        self.assertEqual(stopped["exchanges"][0]["request"], "02311b82000000003303")
        before = len(self.native.writes)
        self.assertEqual(self.command("disconnect", "disconnect")["category"], "ok")
        self.assertEqual(len(self.native.writes), before)
        self.close_cli()
        output = self.directory / "export.json"
        self.workspace.export_report(output)
        records = json.loads(output.read_bytes())["bench_results"]
        self.assertTrue(any(row.get("exchanges") for row in records))
        transport = self.configuration.get("bench_transport", self.configuration.get("amq_transport", "tls-broker"))
        self.assertTrue(all(row.get("transport") == transport for row in records))
        if "amq_password" in self.configuration:
            self.assertNotIn(self.configuration["amq_password"], output.read_text())

    def test_different_workspace_cli_cannot_steal_active_shared_session(self):
        self.prepare()
        primary = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.stack.callback(primary.close)
        self.assertEqual(primary.connect()["category"], "ok")
        self.workspace = initialize_workspace(self.directory / "other-station")
        BenchCLIControlTests.start_cli(self)
        before = len(self.native.writes)
        rejected = self.command("connect", "connect")
        self.assertEqual(rejected["category"], "busy")
        self.assertEqual(rejected["exchanges"], [])
        self.assertEqual(len(self.native.writes), before)
        denied_stop = self.command("stop", "stop")
        self.assertNotEqual(denied_stop["category"], "ok")
        self.assertFalse(self.manager._bench_stop_pending.is_set())
        self.assertFalse(self.manager._bench_stop_failed)
        self.assertFalse(self.manager._invalid)
        self.assertEqual(len(self.native.writes), before)
        self.assertEqual(primary.perform("status")["category"], "ok")
        self.assertEqual(primary.perform("disconnect")["category"], "ok")
        self.command("disconnect", "disconnect")
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        self.assertEqual(self.command("status", "status")["category"], "ok")
        self.assertEqual(self.command("disconnect", "disconnect")["category"], "ok")
        self.close_cli(expected_exit=4)
        self.assertEqual(self.native.motion(), [])

    def test_real_cli_passive_cleanup_retry_is_recorded_without_remote_command(self):
        from satgs.operator_bench import BenchSession
        from satgs.operator_core import OperatorError
        self.prepare()
        BenchCLIControlTests.start_cli(self)
        self.assertEqual(self.command("connect", "connect")["category"], "ok")

        def failed_close(session):
            session._closed = True
            raise OperatorError("controlled passive failure", "cleanup", 7)

        with patch.object(BenchSession, "close", autospec=True, side_effect=failed_close) as closing:
            failed = self.command("disconnect", "disconnect")
            self.assertEqual(closing.call_count, 1)
            self.assertTrue(failed["partial"])
            self.assertFalse(failed["cleanup_complete"])
        before = len(self.native.writes)
        recovered = self.command("disconnect", "disconnect")
        self.assertEqual(recovered["category"], "ok")
        self.assertTrue(recovered["passive_cleanup_retry"])
        self.assertTrue(recovered["cleanup_complete"])
        self.assertFalse(recovered["partial"])
        self.assertEqual(len(self.native.writes), before)
        self.close_cli(expected_exit=7)
        output = self.directory / "cleanup-export.json"
        self.workspace.export_report(output)
        records = json.loads(output.read_bytes())["bench_results"]
        self.assertTrue(any(row.get("attempt_id") == failed["attempt_id"] and row.get("partial") for row in records))
        self.assertTrue(any(row.get("attempt_id") == recovered["attempt_id"] and
                            row.get("passive_cleanup_retry") and row.get("cleanup_complete") for row in records))

    def test_real_cli_query_only_rejects_motion_and_stop_without_serial_submission(self):
        self.prepare(query=True)
        BenchCLIControlTests.start_cli(self)
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        before = len(self.native.writes)
        for text, operation in (("preview 1 -10", "preview"), ("move", "move"),
                                ("stop", "stop"), ("manual 1", "manual"), ("step right", "step")):
            self.assertNotEqual(self.command(text, operation)["category"], "ok")
        self.assertEqual(len(self.native.writes), before)
        self.assertEqual(self.command("status", "status")["category"], "ok")
        self.assertEqual(self.command("disconnect", "disconnect")["category"], "ok")
        self.close_cli(expected_exit=4)
        self.assertEqual(self.native.motion(), [])

    def test_selected_shared_smallest_step_from_nonzero_tenth(self):
        self.prepare()
        self.native.pan_units = 11
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.assertEqual(self.session.connect()["category"], "ok")
        self.assertEqual(self.session.perform("manual", step_degrees=.1)["category"], "ok")
        right = self.session.perform("step", direction="right")
        self.assertEqual(right["category"], "ok")
        self.assertEqual(right["encoded_pan_units"], 12)
        left = self.session.perform("step", direction="left")
        self.assertEqual(left["category"], "ok")
        self.assertEqual(left["encoded_pan_units"], 11)

    def command(self, *args, **kwargs):
        return BenchCLIControlTests.command(self, *args, **kwargs)

    def idle(self):
        return BenchCLIControlTests.idle(self)

    def close_cli(self, **kwargs):
        return BenchCLIControlTests.close_cli(self, **kwargs)


class BenchCLIControlTests(unittest.TestCase):
    def setUp(self):
        from ptu_control import bench
        from ptu_control.ptu_manager import PtuManager
        from serialptu.proto_impl import PTCR20
        from serialptu.ptu import PTU
        from test_messenger_lifecycle import settings as transport_settings
        from test_ptu_bench import bench_settings
        from test_ptu_manager_pointing import FollowingSerial
        from runtime_owner_test_support import BrokerHarness

        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.manager = self.manager_transport = self.driver = self.native = None
        self.cli_thread = self.cli_exit = self.session = None
        self.release_reply = threading.Event()
        self.addCleanup(self.release)
        self.directory = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.workspace = initialize_workspace(self.directory / "station")
        self.harness = self.stack.enter_context(BrokerHarness(2, 3))
        self.configuration = bench_settings()
        self.configuration.update(transport_settings())
        self.configuration["bench_context"]["exchange_timeout_seconds"] = 1
        self.configuration["bench_context"]["observation_max_age_seconds"] = 5
        self.document = {"station": self.configuration, "ptu_id": 2, "elevation_mask": 0, "no_go_data": None}
        self.configuration_file = self.directory / "bench.json"
        self.configuration_file.write_text(json.dumps(self.document))
        self.stack.enter_context(patch.object(operator_bench, "_admit",
                                             side_effect=lambda document: _freeze(document["station"])))
        self.manager_transport = self.harness.open(self.configuration)
        self.protocol = PTCR20()
        self.native = FollowingSerial(self.protocol)
        with patch("serialptu.ptu.serial.Serial", return_value=self.native):
            self.driver = PTU(self.protocol, "recording-only", pointing=True)
        self.manager_cancel = threading.Event()
        self.deadline = time.monotonic() + 30
        with patch.object(bench, "_controlled_rehearsal_boundary", return_value=True):
            self.manager = PtuManager.open_bench(messenger=self.manager_transport,
                settings=self.configuration, ptu_id=2, driver=self.driver, elevation_mask=0, no_go_data=None,
                run_deadline=self.deadline, cancel=self.manager_cancel)
        self.manager.activate(deadline=self.deadline, cancel=self.manager_cancel)

    def release(self):
        failures = []

        def attempt(name, action):
            try:
                action()
            except BaseException:
                failures.append(name)

        self.release_reply.set()
        if self.cli_thread is not None and self.cli_thread.is_alive():
            self.input.send("quit")
            self.cli_thread.join(4)
            if self.cli_thread.is_alive():
                failures.append("cli-worker")
        if self.session is not None:
            attempt("session", self.session.close)
        if self.manager is not None:
            attempt("manager", lambda: self.manager.close(deadline=time.monotonic() + 2))
        if self.driver is not None and not self.driver._pointing_closed:
            attempt("driver", lambda: self.driver.close(deadline=time.monotonic() + 2))
        if self.manager_transport is not None:
            attempt("transport", lambda: self.manager_transport.close(deadline=time.monotonic() + 2))
        if self.manager is not None and self.manager._bench_worker is not None and self.manager._bench_worker.is_alive():
            failures.append("owner-worker")
        if self.native is not None and self.native.opened:
            failures.append("serial-open")
        self.assertEqual(failures, [])

    def start_cli(self):
        from satgs import operator_cli
        self.input, self.output = CommandInput(), ResultOutput()

        def invoke():
            with patch.object(operator_cli.sys, "stdin", self.input), patch.object(operator_cli.sys, "stdout", self.output):
                self.cli_exit = operator_cli.main(["--format", "json", "--workspace", str(self.workspace.root),
                    "bench", "--configuration", str(self.configuration_file)])

        self.cli_thread = threading.Thread(target=invoke, name="controlled-actual-bench-cli")
        self.cli_thread.start()

    def idle(self):
        deadline = time.monotonic() + 3
        while True:
            workers = [worker for worker in threading.enumerate() if worker.name.startswith("operator-cli-ptu-")]
            if not workers:
                return
            for worker in workers:
                worker.join(max(0, deadline - time.monotonic()))
            if time.monotonic() >= deadline:
                self.fail("actual CLI operation worker did not become idle")

    def command(self, line, operation):
        self.idle()
        after = len(self.output.records)
        self.input.send(line)
        result = self.output.wait(lambda record: record.get("operation") == operation and "category" in record,
                                  after=after)
        self.idle()
        return result

    def close_cli(self, expected_exit=0):
        self.input.send("quit")
        self.cli_thread.join(4)
        self.assertFalse(self.cli_thread.is_alive())
        self.assertEqual(self.cli_exit, expected_exit)

    def test_actual_cli_reads_stop_while_move_reply_is_held(self):
        self.start_cli()
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        self.assertEqual(self.command("preview 10 0", "preview")["category"], "ok")
        held = threading.Event()
        original_read = self.native.read

        def read(count):
            if held.is_set() and not self.release_reply.is_set():
                return b""
            return original_read(count)

        self.native.read = read
        self.native.before_write = lambda command: held.set() if command == 0x33 else None
        after = len(self.output.records)
        self.input.send("move")
        self.assertTrue(held.wait(1))
        self.input.send("stop")
        try:
            self.assertTrue(self.manager._bench_stop_pending.wait(.5),
                            "actual CLI could not read Stop while Move was waiting")
            self.assertFalse(self.release_reply.is_set())
        finally:
            self.release_reply.set()
        moved = self.output.wait(lambda record: record.get("operation") == "move" and "category" in record, after=after)
        stopped = self.output.wait(lambda record: record.get("operation") == "stop" and "category" in record, after=after)
        self.assertEqual(moved["category"], "ok")
        self.assertEqual(stopped["category"], "ok")
        self.assertEqual(stopped["physical_state"], "indeterminate")
        self.assertEqual(len(self.native.motion()), 1)
        packets = [self.protocol._decode_strict_packet(packet, 2) for packet in self.native.writes]
        move_index = next(index for index, packet in enumerate(packets) if packet[0] == 0x33)
        self.assertEqual(packets[move_index + 1][:2], b"\x31\x02")
        self.idle()
        self.close_cli()

    def test_actual_cli_disconnect_releases_lease_and_connect_uses_a_fresh_session(self):
        self.start_cli()
        first = self.command("connect", "connect")
        self.assertEqual(first["category"], "ok")
        with self.assertRaises(ActivityError):
            StationLease(self.workspace.root).acquire()
        self.assertEqual(self.command("preview 10 0", "preview")["category"], "ok")
        before = len(self.native.writes)
        disconnected = self.command("disconnect", "disconnect")
        self.assertTrue(disconnected["cleanup_complete"])
        self.assertEqual(len(self.native.writes), before)
        with StationLease(self.workspace.root):
            pass
        second = self.command("connect", "connect")
        self.assertEqual(second["category"], "ok")
        self.assertNotEqual(second["sender"], first["sender"])
        with self.assertRaises(ActivityError):
            StationLease(self.workspace.root).acquire()
        result = self.command("move", "move")
        self.assertEqual(result["category"], "preview_required")
        self.assertEqual(self.native.motion(), [])
        self.assertEqual(self.native.opens, 1)
        self.assertEqual(self.command("disconnect", "disconnect")["category"], "ok")
        with StationLease(self.workspace.root):
            pass
        self.close_cli(expected_exit=4)
        summary = self.output.records[-1]["result"]
        self.assertEqual(summary["operations"], {"requested": 6, "completed": 6,
                         "failed": 1, "rejected": 0, "partial": 0})

    def test_actual_cli_failed_connect_stays_failed_after_quit(self):
        self.harness.connect_result = errno.ECONNREFUSED
        self.start_cli()
        result = self.command("connect", "connect")
        self.assertNotEqual(result["category"], "ok")
        with StationLease(self.workspace.root):
            pass
        self.close_cli(expected_exit=4)
        final = self.output.records[-1]
        self.assertEqual(final["status"], "FAIL")
        self.assertEqual(final["result"]["operations"], {"requested": 1, "completed": 1,
                         "failed": 1, "rejected": 0, "partial": 0})
        self.assertEqual(self.native.motion(), [])
        records = self.workspace.report()["bench_results"]
        failed = [row for row in records if row["record_kind"] == "result"]
        self.assertEqual(len(failed), 1)
        self.assertEqual(failed[0]["operation"], "connect")
        self.assertNotEqual(failed[0]["category"], "ok")
        self.assertTrue(failed[0]["cleanup_complete"])

    def test_actual_cli_manual_step_disarm_and_reconnect_require_new_enable(self):
        self.start_cli()
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        self.assertEqual(self.command("manual 1", "manual")["category"], "ok")
        moved = self.command("step right", "step")
        self.assertEqual(moved["category"], "ok")
        self.assertEqual(moved["requested_pan"], 1)
        self.assertEqual([part["phase"] for part in moved["steps"]], ["status", "preview", "move"])
        self.assertEqual(self.command("disarm", "disarm")["category"], "ok")
        self.assertEqual(self.command("step left", "step")["category"], "manual_required")
        self.assertEqual(self.command("disconnect", "disconnect")["category"], "ok")
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        self.assertEqual(self.command("step left", "step")["category"], "manual_required")
        self.assertEqual(len(self.native.motion()), 1)
        self.close_cli(expected_exit=4)

    def test_actual_cli_owner_status_failure_stays_failed_after_quit(self):
        self.start_cli()
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        self.native.auto_ack = False
        result = self.command("status", "status")
        self.assertNotEqual(result["category"], "ok")
        self.native.auto_ack = True
        self.close_cli(expected_exit=4)
        final = self.output.records[-1]
        self.assertEqual(final["status"], "FAIL")
        self.assertEqual(final["result"]["operations"], {"requested": 2, "completed": 2,
                         "failed": 1, "rejected": 0, "partial": 0})
        self.assertEqual(self.native.motion(), [])

    def test_shared_acquisition_cancel_reaches_held_tls_and_releases_lease(self):
        from meteor_api.messenger import MessengerError

        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        baseline = len(self.harness.raws)
        held = threading.Event()

        def hold_handshake():
            held.set()
            raise ssl.SSLWantReadError()

        def cancel_acquisition():
            if held.wait(1):
                self.session.cancel.set()

        self.harness.hooks["handshake"] = hold_handshake
        caller = threading.Thread(target=cancel_acquisition, name="controlled-bench-acquisition-cancel")
        caller.start()
        try:
            with self.assertRaises(MessengerError) as caught:
                self.session.connect()
        finally:
            self.session.cancel.set()
            self.harness.hooks.pop("handshake", None)
            caller.join(2)
        self.assertTrue(held.is_set())
        self.assertFalse(caller.is_alive())
        self.assertEqual(caught.exception.primary, "cancelled")
        self.assertTrue(self.session.released)
        acquired = self.harness.raws[baseline:]
        self.assertTrue(acquired)
        self.assertTrue(all(endpoint.resource["closed"] for endpoint in acquired))
        self.assertTrue(all(endpoint.tls.sent == [] for endpoint in acquired))
        self.assertFalse(any(worker.name == "operator-bench-acquisition-cancel" and worker.is_alive()
                             for worker in threading.enumerate()))
        with StationLease(self.workspace.root):
            pass
        self.assertEqual(self.native.motion(), [])

    def test_shared_local_cancel_preserves_transport_for_passive_unsubscription(self):
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.assertEqual(self.session.connect()["category"], "ok")
        client, transport = self.session.client, self.session.transport
        self.assertIsNot(transport._cancel, self.session.cancel)
        self.assertTrue(client._registrations)
        self.assertFalse(any(worker.name == "operator-bench-acquisition-cancel" and worker.is_alive()
                             for worker in threading.enumerate()))
        before = len(self.native.writes)
        self.session.cancel.set()
        self.assertFalse(transport._cancel.is_set())
        self.assertFalse(transport._gate)
        self.session.close()
        self.assertTrue(self.session.released)
        self.assertEqual(client._registrations, [])
        self.assertTrue(transport._closed)
        self.assertTrue(self.harness.raws[-1].resource["closed"])
        self.assertEqual(len(self.native.writes), before)
        self.assertEqual(self.native.motion(), [])
        with StationLease(self.workspace.root):
            pass

    def test_actual_cli_final_encoder_rejects_289_96_to_forbidden_290(self):
        from ptu_control import bench
        from ptu_control.ptu_manager import PtuManager
        from serialptu.ptu import PTU
        from test_ptu_manager_pointing import FollowingSerial, rectangle

        self.manager.close(deadline=time.monotonic() + 2)
        self.manager = None
        zone = rectangle()
        self.configuration["bench_context"].update(pan_min=-100, pan_max=0, tilt_min=-90,
                                                  tilt_max=-1, max_change_degrees=20)
        self.document["no_go_data"] = zone
        self.configuration_file.write_text(json.dumps(self.document))
        self.native = FollowingSerial(self.protocol)
        self.native.pan_units, self.native.tilt_units = -800, -700
        with patch("serialptu.ptu.serial.Serial", return_value=self.native):
            self.driver = PTU(self.protocol, "recording-only", pointing=True)
        with patch.object(bench, "_controlled_rehearsal_boundary", return_value=True):
            self.manager = PtuManager.open_bench(messenger=self.manager_transport,
                settings=self.configuration, ptu_id=2, driver=self.driver, elevation_mask=0, no_go_data=zone,
                run_deadline=self.deadline, cancel=self.manager_cancel)
        self.manager.activate(deadline=self.deadline, cancel=self.manager_cancel)
        self.assertEqual((self.manager._policy.pan_to_az, self.manager._policy.tilt_to_el), (0, 90))
        self.manager._bench.check_target(-70.04, -70, (-80, -70))
        self.assertEqual(self.manager._policy.check_endpoint(289.96, 20), (289.96, 20))
        self.start_cli()
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        result = self.command("preview -70.04 -70", "preview")
        self.assertEqual(result["category"], "endpoint_rejected")
        self.assertEqual(self.command("move", "move")["category"], "preview_required")
        self.assertEqual(self.native.motion(), [])
        self.close_cli(expected_exit=4)
        self.assertEqual(self.output.records[-1]["status"], "FAIL")
        self.assertEqual(self.output.records[-1]["result"]["operations"]["failed"], 2)

    def fail_stop_recording(self, observations):
        original = operator_bench._write_new
        original_write = self.native.write

        def write(packet):
            decoded = self.protocol._decode_strict_packet(packet, 2)
            if decoded[:2] == b"\x31\x02":
                observations.append("stop")
            return original_write(packet)

        def record(path, payload):
            if json.loads(payload).get("operation") == "stop":
                observations.append("record")
                raise OperatorError("controlled disk failure", "io", 4)
            return original(path, payload)

        self.native.write = write
        return patch.object(operator_bench, "_write_new", side_effect=record)

    def test_shared_stop_attempt_precedes_failed_start_and_result_recording(self):
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.assertEqual(self.session.connect()["category"], "ok")
        self.assertEqual(self.session.perform("preview", pan=10, tilt=0)["category"], "ok")
        self.assertEqual(self.session.perform("move")["category"], "ok")
        observations = []
        with self.fail_stop_recording(observations):
            result = self.session.perform("stop")
        self.assertEqual(observations, ["stop", "record", "record"])
        self.assertEqual(result["category"], "ok")
        self.assertTrue(result["partial"])
        self.assertFalse(result["recorded"])
        self.assertFalse(result["started_recorded"])
        self.assertFalse(result["result_recorded"])
        self.assertEqual(result["recording_errors"], ["started", "result"])
        self.assertEqual(result["physical_state"], "indeterminate")
        self.assertEqual(len(self.native.motion()), 1)

    def test_actual_cli_stop_is_attempted_even_when_its_recorder_fails(self):
        self.start_cli()
        self.assertEqual(self.command("connect", "connect")["category"], "ok")
        observations = []
        with self.fail_stop_recording(observations):
            result = self.command("stop", "stop")
        self.assertEqual(observations, ["stop", "record", "record"])
        self.assertEqual(result["category"], "ok")
        self.assertTrue(result["partial"])
        self.assertFalse(result["recorded"])
        self.assertEqual(self.native.motion(), [])
        self.close_cli(expected_exit=4)


class LocalSerialBenchCLIControlTests(unittest.TestCase):
    setUp = SelectedBenchCLIControlTests.setUp
    command = SelectedBenchCLIControlTests.command
    idle = SelectedBenchCLIControlTests.idle
    close_cli = SelectedBenchCLIControlTests.close_cli
    test_local_cli_manual_numeric_arrows_stop_and_export = SelectedBenchCLIControlTests.test_real_cli_manual_connect_arrows_numeric_stop_and_export
    test_local_cli_query_only_has_no_motion_or_stop_submission = SelectedBenchCLIControlTests.test_real_cli_query_only_rejects_motion_and_stop_without_serial_submission
    test_local_cli_passive_cleanup_retry_is_recorded = SelectedBenchCLIControlTests.test_real_cli_passive_cleanup_retry_is_recorded_without_remote_command
    test_local_smallest_step_from_nonzero_tenth = SelectedBenchCLIControlTests.test_selected_shared_smallest_step_from_nonzero_tenth

    def prepare(self, query=False):
        self.__dict__.update(vars(local_bench_fixture(self.stack, self.directory, query=query)))
        self.addCleanup(lambda: BenchCLIControlTests.release(self))

    def test_local_cli_connect_recovers_a_lost_initial_reply_without_motion(self):
        self.prepare()
        self.native.before_write = lambda command: setattr(self.native, "auto_ack", len(self.native.writes) > 1)
        BenchCLIControlTests.start_cli(self)
        connected = self.command("connect", "connect")
        self.assertEqual(connected["category"], "ok")
        self.assertEqual(connected["connection_budget_seconds"], 5)
        self.assertEqual(connected["response_correlation"], "unsequenced-initial-status")
        self.assertEqual([exchange["category"] for exchange in connected["exchanges"]], ["deadline", "ok"])
        self.assertEqual(connected["exchanges"][0]["response"], "")
        self.assertEqual([exchange["request"] for exchange in connected["exchanges"]],
                         ["023100000000003103"] * 2)
        self.assertEqual((connected["pan"], connected["tilt"]), (0, -10))
        observed = self.command("status", "status")
        self.assertEqual(observed["category"], "ok")
        self.assertEqual(len(observed["exchanges"]), 1)
        for packet in self.native.writes:
            self.protocol.validate_nonmoving_status_packet(packet)
        self.assertEqual(self.command("disconnect", "disconnect")["category"], "ok")
        self.close_cli()

    def test_local_connect_exhaustion_reports_all_probes_and_preserves_station(self):
        self.prepare()
        station_before = (self.workspace.root / "station.json").read_bytes()
        configuration_before = self.configuration_file.read_bytes()
        self.native.auto_ack = False
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        clock = [time.monotonic()]

        def read(count):
            clock[0] += .125
            return b""

        self.native.read = read
        with patch("time.monotonic", side_effect=lambda: clock[0]):
            result = self.session.connect()
        self.assertEqual(result["category"], "deadline")
        self.assertEqual(result["connection_budget_seconds"], 5)
        self.assertEqual(result["message"], "PTU Connect received no reply to its initial status probes.")
        self.assertFalse(result["has_observation"])
        self.assertEqual(result["physical_state"], "unobserved")
        self.assertEqual(len(result["exchanges"]), 10)
        self.assertTrue(all(exchange["written"] == 9 and exchange["submission"] == "complete"
                            and exchange["response"] == "" and exchange["category"] == "deadline"
                            for exchange in result["exchanges"]))
        report = next(record for record in self.workspace.report()["bench_results"]
                      if record.get("record_kind") == "result")
        self.assertEqual(report["exchanges"], result["exchanges"])
        self.assertEqual(report["connection_budget_seconds"], 5)
        self.assertEqual(report["message"], result["message"])
        before = len(self.native.writes)
        with self.assertRaises(OperatorError):
            self.session.connect()
        repeated = self.session.client.connect(deadline=time.monotonic() + 1, cancel=threading.Event()).as_record()
        self.assertEqual(repeated["category"], "context_changed")
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(self.session.readback_snapshot()["manual_enabled"])
        self.assertEqual((self.workspace.root / "station.json").read_bytes(), station_before)
        self.assertEqual(self.configuration_file.read_bytes(), configuration_before)
        self.assertEqual(self.document["station"]["manual_context"]["exchange_timeout_seconds"], 1)

    def test_local_slow_connect_keeps_conservative_age_and_refreshes_immediately(self):
        self.prepare()
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        clock = [time.monotonic()]
        self.native.on_open = lambda: clock.__setitem__(0, clock[0] + 4.75)
        with patch("time.monotonic", side_effect=lambda: clock[0]):
            result = self.session.connect()
            self.assertEqual(result["category"], "ok")
            snapshot = self.session.readback_snapshot()
            self.assertTrue(snapshot["poll_due"])
            self.assertGreaterEqual(clock[0] - self.session._observation_started, 4.75)
            self.assertEqual(snapshot["freshness"], "fresh")

    def test_local_same_workspace_is_rejected_before_second_device_open(self):
        self.prepare()
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.assertEqual(self.session.connect()["category"], "ok")
        competing = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.stack.callback(competing.close)
        before = len(self.native.writes), self.native.opens
        with self.assertRaises(ActivityError):
            competing.connect()
        self.assertEqual((len(self.native.writes), self.native.opens), before)
        self.assertEqual(self.session.perform("status")["category"], "ok")

    def test_local_different_workspaces_still_share_exclusive_device_ownership(self):
        from serial import SerialException
        from serialptu.proto_impl import PTCR20
        from test_ptu_manager_pointing import FollowingSerial
        self.prepare()
        registry, instances = {}, []

        class ExclusiveSerial(FollowingSerial):
            def open(native):
                if native.port in registry:
                    raise SerialException(errno.EBUSY, "controlled device ownership")
                super().open()
                registry[native.port] = native

            def close(native):
                super().close()
                if registry.get(native.port) is native:
                    del registry[native.port]

        def serial(*, baudrate, timeout, exclusive):
            self.assertEqual((baudrate, timeout, exclusive), (9600, 0, True))
            native = ExclusiveSerial(PTCR20())
            native.tilt_units = -100
            instances.append(native)
            return native

        other_workspace = initialize_workspace(self.directory / "other-station")
        with patch("serialptu.ptu.serial.Serial", side_effect=serial):
            self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
            self.assertEqual(self.session.connect()["category"], "ok")
            self.native = instances[0]
            competing = operator_bench.BenchSession(other_workspace, self.configuration_file)
            self.stack.callback(competing.close)
            before = len(self.native.writes)
            denied = competing.connect()
            self.assertEqual(denied["category"], "busy")
            self.assertEqual(denied["exchanges"], [])
            self.assertEqual(instances[1].writes, [])
            self.assertEqual(len(self.native.writes), before)
            competing.close()
            self.assertTrue(self.native.opened)
            self.assertEqual(self.session.perform("status")["category"], "ok")
            self.assertEqual(self.session.perform("disconnect")["category"], "ok")
            replacement = operator_bench.BenchSession(other_workspace, self.configuration_file)
            self.stack.callback(replacement.close)
            self.assertEqual(replacement.connect()["category"], "ok")
            self.assertEqual(replacement.perform("disconnect")["category"], "ok")
        self.assertEqual(registry, {})
        self.assertTrue(all(not native.opened and native.motion() == [] for native in instances))

    def test_local_failed_passive_close_retains_client_and_lease_until_retry(self):
        self.prepare()
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.assertEqual(self.session.connect()["category"], "ok")
        self.native.close_failure = True
        before = len(self.native.writes)
        try:
            result = self.session.perform("disconnect")
            self.assertFalse(result["cleanup_complete"])
            self.assertTrue(result["partial"])
            self.assertIsNotNone(self.session.client)
            self.assertIsNotNone(self.session._lease)
            with self.assertRaises(ActivityError):
                StationLease(self.workspace.root).acquire()
        finally:
            self.native.close_failure = False
        result = self.session.perform("disconnect")
        self.assertTrue(result["passive_cleanup_retry"])
        self.assertTrue(result["cleanup_complete"])
        self.assertTrue(self.session.released)
        self.assertFalse(self.native.opened)
        self.assertEqual(len(self.native.writes), before)

    def test_local_cancelled_session_close_is_passive_and_releases_lease(self):
        self.prepare()
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.assertEqual(self.session.connect()["category"], "ok")
        before = len(self.native.writes)
        self.session.cancel.set()
        self.session.close()
        self.assertTrue(self.session.released)
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(self.native.opened)
        with StationLease(self.workspace.root):
            pass

    def test_local_stale_or_disarmed_steps_do_not_submit_and_require_fresh_enable(self):
        self.prepare()
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.assertEqual(self.session.connect()["category"], "ok")
        self.assertEqual(self.session.perform("manual", step_degrees=1)["category"], "ok")
        self.session._observation_started -= 6
        before = len(self.native.writes)
        self.assertEqual(self.session.perform("step", direction="right")["category"], "readback_required")
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(self.session.readback_snapshot()["manual_enabled"])
        self.assertEqual(self.session.perform("status")["category"], "ok")
        self.assertEqual(self.session.perform("step", direction="right")["category"], "manual_required")
        self.assertEqual(self.session.perform("manual", step_degrees=1)["category"], "ok")
        self.assertEqual(self.session.perform("step", direction="right")["category"], "ok")


class LocalJogSessionTests(unittest.TestCase):
    setUp = SelectedBenchCLIControlTests.setUp

    def connect(self):
        self.__dict__.update(vars(local_bench_fixture(self.stack, self.directory)))
        self.session = operator_bench.BenchSession(self.workspace, self.configuration_file)
        self.stack.callback(self.session.close)
        self.assertEqual(self.session.connect()["category"], "ok")
        return self.session

    def wait_for(self, predicate, timeout=2):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return
            time.sleep(.005)
        self.fail("controlled jog observation did not arrive")

    def packets(self):
        decoded = [self.protocol._decode_strict_packet(packet, 2) for packet in self.native.writes]
        return [packet[1:] for packet in decoded if packet[0] == 0x31]

    def test_hold_renews_real_jog_packets_and_release_stops_without_steps(self):
        session = self.connect()
        self.assertFalse(session.readback_snapshot()["manual_enabled"])
        token = session.start_jog("right")["jog_token"]
        deadline = time.monotonic() + .85
        while time.monotonic() < deadline:
            self.assertTrue(session.renew_jog(token))
            time.sleep(.05)
        self.assertTrue(session.end_jog(token))
        session._finish_jog()
        packets = self.packets()
        moving = [packet for packet in packets if packet[1] or packet[2]]
        self.assertGreaterEqual(len(moving), 3)
        self.assertTrue(all(packet[0] == 0 and packet[1] == 255 and packet[2] == 0 for packet in moving))
        self.assertTrue(any(packet[0] == 2 and packet[1:3] == b"\0\0" for packet in packets))
        self.assertEqual(session.readback_snapshot()["observation"]["tilt"], -10)
        result = session.drain_jog_results()[-1]
        self.assertEqual(result["category"], "ok")
        self.assertEqual(result["stop_category"], "ok")
        self.assertFalse(result["no_go_enforced"])
        self.assertFalse(result["software_endpoint_limits_enforced"])
        self.assertEqual(result["physical_state"], "indeterminate")
        self.assertEqual(result["jog_exchange_count"], len(moving))
        report = self.workspace.report()
        self.assertIn("device-soft-limits-jog.v1", json.dumps(report))

    def test_lost_renewal_stops_and_old_token_cannot_release_a_new_hold(self):
        session = self.connect()
        token = session.start_jog("left")["jog_token"]
        self.wait_for(lambda: session.readback_snapshot()["jog"]["token"] is None)
        session._finish_jog()
        first = session.drain_jog_results()[-1]
        self.assertEqual(first["jog_end_reason"], "renewal_expired")
        self.assertEqual(first["stop_category"], "ok")
        self.assertFalse(session.renew_jog(token))
        replacement = session.start_jog("up")["jog_token"]
        self.assertNotEqual(token, replacement)
        self.assertFalse(session.end_jog(token))
        self.assertTrue(session.renew_jog(replacement))
        session.end_jog(replacement)
        session._finish_jog()

    def test_stop_interrupts_hold_and_status_never_renews_motion(self):
        session = self.connect()
        token = session.start_jog("right")["jog_token"]
        self.wait_for(lambda: session.readback_snapshot()["jog"]["state"] == "active")
        before = len(self.native.writes)
        with self.assertRaises(OperatorError) as caught:
            session.perform("status")
        self.assertEqual(caught.exception.code, "busy")
        self.assertEqual(len(self.native.writes), before)
        stopped = session.perform("stop")
        self.assertEqual(stopped["category"], "ok")
        self.assertFalse(session.renew_jog(token))
        self.assertEqual(session.perform("status")["category"], "ok")
        self.assertEqual(self.packets()[-1][1:3], b"\0\0")

    def test_cancel_and_close_use_independent_stop_before_passive_release(self):
        session = self.connect()
        session.start_jog("down")
        self.wait_for(lambda: session.readback_snapshot()["jog"]["state"] == "active")
        session.cancel.set()
        session.close()
        self.assertTrue(session.released)
        self.assertFalse(self.native.opened)
        self.assertTrue(any(packet[0] == 2 for packet in self.packets()))
        self.assertEqual(session.drain_jog_results()[-1]["stop_category"], "ok")
        self.assertFalse(session._jog_worker.is_alive())

    def test_stale_feedback_and_competing_direction_do_not_start_new_motion(self):
        session = self.connect()
        session._observation_started -= 6
        before = len(self.native.writes)
        with self.assertRaises(OperatorError):
            session.start_jog("left")
        self.assertEqual(len(self.native.writes), before)
        session.perform("status")
        token = session.start_jog("left")["jog_token"]
        with self.assertRaises(OperatorError) as caught:
            session.start_jog("right")
        self.assertEqual(caught.exception.code, "busy")
        session.end_jog(token)
        session._finish_jog()

    def test_jog_failure_preserves_prior_submissions_and_stops(self):
        session = self.connect()
        original, calls = session.client.jog, []

        def fail_second(*args, **kwargs):
            calls.append(True)
            if len(calls) == 2:
                raise RuntimeError("controlled second exchange failure")
            return original(*args, **kwargs)

        with patch.object(session.client, "jog", side_effect=fail_second):
            session.start_jog("left")
            self.wait_for(lambda: session.readback_snapshot()["jog"]["token"] is None)
        result = session.drain_jog_results()[-1]
        self.assertEqual(result["jog_exchange_count"], 2)
        self.assertEqual(result["jog_acknowledged_count"], 1)
        self.assertEqual(result["jog_uncertain_count"], 1)
        self.assertEqual(result["submission"], "multiple")
        self.assertEqual(result["stop_category"], "ok")
        self.assertEqual(session.readback_snapshot()["jog"]["state"], "failed")
        self.assertFalse(session.readback_snapshot()["jog_allowed"])

    def test_close_and_stop_block_new_hold_through_prior_completion_handoff(self):
        for action in ("close", "stop"):
            with self.subTest(action=action):
                session = self.connect()
                session.start_jog("left")
                self.wait_for(lambda: session.readback_snapshot()["jog"]["state"] == "active")
                completed, release = threading.Event(), threading.Event()
                original_finish, outcomes = session._finish_jog, []

                def hold_completed_generation():
                    result = original_finish()
                    completed.set()
                    if not release.wait(2):
                        raise RuntimeError("controlled handoff release missing")
                    return result

                def finish():
                    try:
                        outcomes.append(session.close() if action == "close" else session.perform("stop"))
                    except Exception as error:
                        outcomes.append(error)

                with patch.object(session, "_finish_jog", side_effect=hold_completed_generation):
                    worker = threading.Thread(target=finish, name="controlled-jog-handoff")
                    worker.start()
                    try:
                        self.assertTrue(completed.wait(2))
                        self.assertFalse(session._jog_worker.is_alive())
                        self.assertIsNone(session.readback_snapshot()["jog"]["token"])
                        before = len(self.native.writes)
                        with self.assertRaises(OperatorError):
                            session.start_jog("right")
                        self.assertEqual(len(self.native.writes), before)
                    finally:
                        release.set()
                        worker.join(2)
                self.assertFalse(worker.is_alive())
                self.assertEqual(len(outcomes), 1)
                self.assertNotIsInstance(outcomes[0], Exception)
                if action == "stop":
                    self.assertEqual(outcomes[0]["category"], "ok")
                    replacement = session.start_jog("right")["jog_token"]
                    session.end_jog(replacement)
                    session._finish_jog()
                session.close()

    def test_expected_release_before_native_write_retains_receipt_and_allows_new_hold(self):
        session = self.connect()
        released = []
        before = len(self.native.writes)

        def release_before_write(native):
            if not released:
                released.append(session.end_jog(session.readback_snapshot()["jog"]["token"]))
            return len(native.response)

        with patch.object(type(self.native), "in_waiting", property(release_before_write)):
            session.start_jog("right")
            self.wait_for(lambda: session.readback_snapshot()["jog"]["token"] is None)
        session._finish_jog()
        record = session.drain_jog_results()[-1]
        self.assertEqual(released, [True])
        self.assertEqual(record["category"], "ok")
        self.assertEqual(record["submission"], "none")
        self.assertEqual(record["last_exchange"]["category"], "cancelled")
        self.assertEqual(record["last_exchange"]["exchanges"][0]["submission"], "none")
        self.assertEqual(record["stop_category"], "ok")
        self.assertFalse(any(packet[1] or packet[2] for packet in self.packets()))
        self.assertGreater(len(self.native.writes), before)
        self.assertTrue(session.readback_snapshot()["jog_allowed"])
        token = session.start_jog("left")["jog_token"]
        self.wait_for(lambda: session.readback_snapshot()["jog"]["state"] == "active")
        session.end_jog(token)
        session._finish_jog()
        self.assertEqual(self.native.opens, 1)

    def test_release_during_jog_reply_reconciles_stop_and_allows_the_next_hold(self):
        session = self.connect()
        original_read = self.native.read
        released = []
        self.native.pan_units = 49
        self.native.tilt_units = -14

        def release_after_ack_prefix(count):
            chunk = original_read(count)
            if not released and chunk == b"\x06":
                released.append(session.end_jog(session.readback_snapshot()["jog"]["token"]))
            return chunk

        with patch.object(self.native, "read", side_effect=release_after_ack_prefix):
            session.start_jog("up")
            self.wait_for(lambda: session.readback_snapshot()["jog"]["token"] is None)
            session._finish_jog()
        stop, hold = session.drain_jog_results()[-2:]
        self.assertEqual(released, [True])
        self.assertEqual(hold["category"], "ok")
        self.assertTrue(hold["jog_reply_interrupted"])
        self.assertTrue(hold["jog_reply_reconciled"])
        self.assertEqual((hold["jog_uncertain_count"], hold["stop_category"]), (1, "ok"))
        interrupted = hold["last_exchange"]["exchanges"][0]
        self.assertEqual((interrupted["category"], interrupted["submission"], interrupted["response"]),
                         ("cancelled", "complete", "06"))
        self.assertEqual([row["operation"] for row in stop["exchanges"]], ["stop", "status"])
        receipt = stop["exchanges"][0]
        self.assertEqual(receipt["interrupted_sequence"], interrupted["sequence"])
        self.assertEqual(receipt["interrupted_response_prefix"], "06")
        self.assertTrue(receipt["interrupted_response"].startswith("06"))
        self.assertTrue(receipt["response"].startswith("06"))
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        self.assertEqual(bytes(self.native.response), b"")
        self.assertTrue(session.readback_snapshot()["jog_allowed"])
        self.assertEqual(session.perform("status")["category"], "ok")
        exported = self.directory / "interrupted-jog-report.json"
        self.workspace.export_report(exported)
        rows = json.loads(exported.read_bytes())["bench_results"]
        recorded = next(row for row in rows if row.get("attempt_id") == stop["attempt_id"]
                        and row.get("record_kind") == "result")
        self.assertEqual(recorded["exchanges"], stop["exchanges"])
        self.assertTrue(recorded["jog_reply_reconciled"])
        token = session.start_jog("right")["jog_token"]
        self.wait_for(lambda: session.readback_snapshot()["jog"]["state"] == "active")
        session.end_jog(token)
        session._finish_jog()
        self.assertTrue(session.readback_snapshot()["jog_allowed"])
        self.assertEqual(self.native.opens, 1)

    def test_release_with_missing_stop_reply_retains_interrupted_bytes_and_blocks_new_hold(self):
        session = self.connect()
        original_read = self.native.read
        released = []

        def release_after_ack_prefix(count):
            chunk = original_read(count)
            if not released and chunk == b"\x06":
                released.append(session.end_jog(session.readback_snapshot()["jog"]["token"]))
                self.native.auto_ack = False
            return chunk

        with patch.object(self.native, "read", side_effect=release_after_ack_prefix):
            session.start_jog("left")
            self.wait_for(lambda: session.readback_snapshot()["jog"]["token"] is None)
            session._finish_jog()
        stop, hold = session.drain_jog_results()[-2:]
        self.assertEqual((hold["category"], hold["stop_category"]), ("stop_failed", "deadline"))
        self.assertFalse(hold["jog_reply_reconciled"])
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        receipt = stop["exchanges"][0]
        self.assertEqual(receipt["interrupted_response_prefix"], "06")
        self.assertTrue(receipt["interrupted_response"].endswith("03"))
        self.assertEqual(receipt["response"], "")
        before = len(self.native.writes)
        with self.assertRaises(OperatorError):
            session.start_jog("right")
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(session.readback_snapshot()["jog_allowed"])

    def test_release_at_owner_preflight_is_not_falsely_reported_as_uncertain_submission(self):
        session = self.connect()
        original_jog = session.client.jog

        def release_at_entry(*args, **kwargs):
            session.end_jog(session.readback_snapshot()["jog"]["token"])
            return original_jog(*args, **kwargs)

        with patch.object(session.client, "jog", side_effect=release_at_entry):
            session.start_jog("right")
            self.wait_for(lambda: session.readback_snapshot()["jog"]["token"] is None)
        session._finish_jog()
        record = session.drain_jog_results()[-1]
        self.assertEqual(record["category"], "ok")
        self.assertEqual(record["submission"], "none")
        self.assertEqual(record["jog_uncertain_count"], 0)
        self.assertEqual(record["stop_category"], "ok")
        self.assertFalse(any(packet[1] or packet[2] for packet in self.packets()))
        self.assertTrue(session.readback_snapshot()["jog_allowed"])

    def test_cli_disarm_stops_timed_jog_and_cannot_renew_it(self):
        self.__dict__.update(vars(local_bench_fixture(self.stack, self.directory)))
        self.addCleanup(lambda: BenchCLIControlTests.release(self))
        original_renew = operator_bench.BenchSession.renew_jog

        def renew(session, token):
            self.session = session
            return original_renew(session, token)

        with patch.object(operator_bench.BenchSession, "renew_jog", autospec=True, side_effect=renew):
            BenchCLIControlTests.start_cli(self)
            self.input.send("connect")
            connected = self.output.wait(lambda row: row.get("operation") == "connect" and "category" in row)
            self.assertEqual(connected["category"], "ok")
            BenchCLIControlTests.idle(self)
            self.input.send("jog right 5")
            self.wait_for(lambda: self.session is not None
                          and self.session.readback_snapshot()["jog"]["state"] == "active")
            token = self.session.readback_snapshot()["jog"]["token"]
            self.input.send("disarm")
            disarmed = self.output.wait(lambda row: row.get("operation") == "disarm" and "category" in row)
            self.assertEqual(disarmed["category"], "ok")
            result = self.output.wait(lambda row: row.get("operation") == "jog" and "stop_category" in row)
            self.assertEqual(result["stop_category"], "ok")
            BenchCLIControlTests.idle(self)
            self.assertFalse(self.session.renew_jog(token))
            self.assertIsNone(self.session.readback_snapshot()["jog"]["token"])
            stop_index = next(index for index, packet in enumerate(self.packets()) if packet[0] == 2)
            self.assertFalse(any(packet[1] or packet[2] for packet in self.packets()[stop_index + 1:]))
            BenchCLIControlTests.close_cli(self)

    def test_jog_start_record_failure_submits_no_motion(self):
        session = self.connect()
        original_write = operator_bench._write_new
        before = len(self.native.writes)

        def reject_start(path, payload):
            if path.name.endswith("-started.json") and json.loads(payload)["operation"] == "jog":
                raise OSError("controlled start record failure")
            return original_write(path, payload)

        with patch.object(operator_bench, "_write_new", side_effect=reject_start):
            session.start_jog("right")
            self.wait_for(lambda: session.readback_snapshot()["jog"]["token"] is None)
        session._finish_jog()
        record = session.drain_jog_results()[-1]
        self.assertNotEqual(record["category"], "ok")
        self.assertFalse(record["started_recorded"])
        self.assertEqual(record["submission"], "none")
        self.assertEqual(record["jog_exchange_count"], 0)
        self.assertEqual(len(self.native.writes), before)

    def test_stop_record_failure_never_prevents_actual_stop(self):
        session = self.connect()
        token = session.start_jog("right")["jog_token"]
        self.wait_for(lambda: session.readback_snapshot()["jog"]["state"] == "active")
        original_write = operator_bench._write_new
        failures = []

        def reject_stop_record(path, payload):
            if json.loads(payload)["operation"] == "stop":
                failures.append(path.name)
                raise OSError("controlled Stop record failure")
            return original_write(path, payload)

        with patch.object(operator_bench, "_write_new", side_effect=reject_stop_record):
            session.end_jog(token)
            session._finish_jog()
        rows = session.drain_jog_results()
        stop, record = rows[-2:]
        self.assertEqual(len(failures), 2)
        self.assertEqual(stop["category"], "ok")
        self.assertEqual(stop["submission"], "complete")
        self.assertTrue(stop["partial"])
        self.assertEqual(record["category"], "stop_failed")
        self.assertTrue(any(packet[0] == 2 for packet in self.packets()))
        self.assertFalse(session.readback_snapshot()["jog_allowed"])

    def test_saved_local_selection_is_shared_frozen_and_does_not_open_on_setup(self):
        from satgs import operator_cli
        self.assertIsNone(operator_bench.saved_bench_configuration(self.workspace))
        args = operator_cli.parser().parse_args(["--workspace", str(self.workspace.root),
                                               "bench-configure", "--transport", "local-serial"])
        self.assertTrue(operator_cli.dispatch(args)["saved"])
        before = self.workspace.station_path.read_bytes()
        self.assertFalse(operator_bench.save_local_bench(self.workspace)["changed"])
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        session = operator_bench.BenchSession(self.workspace)
        self.assertIsNone(session.client)
        self.assertIsNone(session.transport)
        self.assertEqual(session._transport_kind, "local-serial")
        self.assertEqual(session._context["max_change_degrees"], 360)
        self.assertIsNone(session._context["no_go_rectangle"])
        self.assertIsNone(operator_cli.parser().parse_args(["bench"]).configuration)

    def test_import_saved_local_configuration_preserves_policy_and_active_session(self):
        self.__dict__.update(vars(local_bench_fixture(self.stack, self.directory)))
        operator_bench.save_local_bench(self.workspace, self.configuration_file)
        session = operator_bench.BenchSession(self.workspace)
        self.stack.callback(session.close)
        self.assertEqual(session.connect()["category"], "ok")
        saved = operator_bench.saved_bench_configuration(self.workspace)
        self.assertEqual(saved, self.document)
        before = self.workspace.station_path.read_bytes()
        with self.assertRaises(ActivityError):
            operator_bench.save_local_bench(self.workspace)
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.configuration_file.write_text("{changed source}")
        self.assertEqual(session.perform("status")["category"], "ok")
        session.close()
        replacement = operator_bench.BenchSession(self.workspace)
        self.assertEqual(replacement.document, saved)
        replacement.close()


class ForegroundBenchManagerTests(unittest.TestCase):
    def test_exact_paired_release_versions_are_required_before_transport(self):
        from satgs import operator_bench_manager as adapter
        from test_ptu_bench import bench_settings

        with tempfile.TemporaryDirectory() as directory:
            configuration = Path(directory) / "manager.json"
            configuration.write_text(json.dumps({"station": bench_settings("operational"),
                "ptu_id": 2, "elevation_mask": 0, "no_go_data": None}))
            with patch.object(adapter, "_admit", side_effect=lambda value: _freeze(value["station"])), \
                    patch.object(adapter, "version", side_effect=("0.0.1+runtime.20261110.1",) * 3):
                with self.assertRaises(OperatorError) as caught:
                    adapter.run_manager(configuration, duration=1, cancel=threading.Event())
            self.assertEqual(caught.exception.code, "owner_version")

    def fixture(self, stack):
        from ptu_control import bench
        from satgs import operator_bench_manager as adapter
        from serialptu.proto_impl import PTCR20
        from test_messenger_lifecycle import settings as transport_settings
        from test_ptu_bench import bench_settings
        from test_ptu_manager_pointing import FollowingSerial
        from runtime_owner_test_support import BrokerHarness

        root = Path(stack.enter_context(tempfile.TemporaryDirectory()))
        harness = stack.enter_context(BrokerHarness(2, 3))
        station = bench_settings("operational")
        station.update(transport_settings())
        station["bench_context"]["exchange_timeout_seconds"] = .5
        document = {"station": station, "ptu_id": 2, "elevation_mask": 0, "no_go_data": None}
        configuration = root / "manager.json"
        configuration.write_text(json.dumps(document))
        native = FollowingSerial(PTCR20())
        stack.enter_context(patch("serialptu.ptu.serial.Serial", return_value=native))
        stack.enter_context(patch.object(bench, "_controlled_rehearsal_boundary", return_value=True))
        stack.enter_context(patch.object(adapter, "_admit", side_effect=lambda value: _freeze(value["station"])))
        versions = {"satgs": "0.0.1+jog.20261119.2", "ptu-control": "0.0.1+jog.20261119.2",
                    "serialptu": "0.0.1+jog.20261119.2"}
        stack.enter_context(patch.object(adapter, "version", side_effect=versions.__getitem__))
        return adapter, configuration, harness, native

    def test_unadmitted_manager_stops_before_metadata_transport_or_driver(self):
        from satgs import operator_bench_manager as adapter
        from test_ptu_bench import bench_settings

        with tempfile.TemporaryDirectory() as directory:
            configuration = Path(directory) / "manager.json"
            configuration.write_text(json.dumps({"station": bench_settings("operational"),
                "ptu_id": 2, "elevation_mask": 0, "no_go_data": None}))
            with patch.object(adapter, "version", side_effect=AssertionError("metadata after closed admission")):
                with self.assertRaises(OperatorError) as caught:
                    adapter.run_manager(configuration, duration=1, cancel=threading.Event())
            self.assertEqual(caught.exception.code, "bench_not_admitted")

    def test_actual_manager_main_missing_and_malformed_config_are_structured(self):
        from satgs import operator_bench_manager as adapter

        with tempfile.TemporaryDirectory() as directory:
            missing = Path(directory) / "missing.json"
            malformed = Path(directory) / "malformed.json"
            malformed.write_text("{not-json")
            for configuration in (missing, malformed):
                with self.subTest(configuration=configuration.name):
                    output = io.StringIO()
                    with patch.object(adapter, "version", side_effect=AssertionError("metadata before config")), \
                            patch("sys.stdout", output):
                        code = adapter.main(["--configuration", str(configuration), "--duration", "1"])
                    record = json.loads(output.getvalue())
                    self.assertEqual((code, record["category"]), (3, "bench_input"))
                    self.assertFalse(record["activated"])
                    self.assertEqual(record["cleanup"], [])

    def test_actual_manager_main_missing_distribution_reports_owner_version(self):
        from importlib.metadata import PackageNotFoundError
        from satgs import operator_bench_manager as adapter
        from test_ptu_bench import bench_settings

        with tempfile.TemporaryDirectory() as directory:
            configuration = Path(directory) / "manager.json"
            configuration.write_text(json.dumps({"station": bench_settings("operational"),
                "ptu_id": 2, "elevation_mask": 0, "no_go_data": None}))
            output = io.StringIO()
            with patch.object(adapter, "_admit", side_effect=lambda value: _freeze(value["station"])), \
                    patch.object(adapter, "version", side_effect=PackageNotFoundError("ptu-control")), \
                    patch("sys.stdout", output):
                code = adapter.main(["--configuration", str(configuration), "--duration", "1"])
            record = json.loads(output.getvalue())
            self.assertEqual((code, record["category"]), (3, "owner_version"))
            self.assertFalse(record["activated"])
            self.assertEqual(record["cleanup"], [])
            output = io.StringIO()
            with patch.object(adapter, "_admit", side_effect=ImportError("controlled missing owner")), \
                    patch.object(adapter, "version", side_effect=AssertionError("metadata after missing owner")), \
                    patch("sys.stdout", output):
                code = adapter.main(["--configuration", str(configuration), "--duration", "1"])
            record = json.loads(output.getvalue())
            self.assertEqual((code, record["category"]), (3, "owner_version"))
            self.assertFalse(record["activated"])

    def test_actual_manager_acquisition_cancel_returns_130_and_closes_socket(self):
        with ExitStack() as stack:
            adapter, configuration, harness, native = self.fixture(stack)
            cancel = threading.Event()
            held = threading.Event()

            def hold_handshake():
                held.set()
                raise ssl.SSLWantReadError()

            def cancel_acquisition():
                if held.wait(1):
                    cancel.set()

            harness.hooks["handshake"] = hold_handshake
            caller = threading.Thread(target=cancel_acquisition, name="controlled-manager-acquisition-cancel")
            caller.start()
            try:
                result = adapter.run_manager(configuration, duration=1, cancel=cancel)
            finally:
                cancel.set()
                harness.hooks.pop("handshake", None)
                caller.join(2)
            self.assertTrue(held.is_set())
            self.assertFalse(caller.is_alive())
            self.assertEqual((result["exit_code"], result["category"]), (130, "cancelled"))
            self.assertFalse(result["activated"])
            self.assertEqual(result["cleanup"], [])
            self.assertEqual(native.opens, 0)
            self.assertTrue(harness.raws)
            self.assertTrue(all(endpoint.resource["closed"] for endpoint in harness.raws))
            self.assertTrue(all(endpoint.tls.sent == [] for endpoint in harness.raws))
            self.assertFalse(any(worker.name == "operator-bench-acquisition-cancel" and worker.is_alive()
                                 for worker in threading.enumerate()))

    def test_uncertain_move_keeps_same_foreground_owner_for_status_and_stop(self):
        from ptu_control.constants import Topics
        from ptu_control.ptu_client import PtuClient
        from satgs import operator_bench_manager as adapter
        from serialptu.acquisition import _DeviceSnapshot
        from serialptu.proto_impl import PTCR20
        from test_messenger_lifecycle import settings as transport_settings
        from test_ptu_bench import manual_settings
        from test_ptu_manager_pointing import FollowingSerial
        from runtime_owner_test_support import BrokerHarness

        with ExitStack() as stack:
            directory = Path(stack.enter_context(tempfile.TemporaryDirectory()))
            station = manual_settings()
            station.update(transport_settings(amq_dial_address="127.0.0.1"))
            station["manual_context"]["exchange_timeout_seconds"] = .2
            configuration = directory / "manual-manager.json"
            configuration.write_text(json.dumps(dict(station=station, ptu_id=2)))
            harness = stack.enter_context(BrokerHarness(2, 3))
            native = FollowingSerial(PTCR20())
            native.tilt_units = -100
            stack.enter_context(patch("serialptu.ptu.serial.Serial", return_value=native))
            stack.enter_context(patch("serialptu.ptu.verify_selected_device",
                return_value=_DeviceSnapshot("/dev/ttyUSB0", 7, 13, 188 * 256)))
            stack.enter_context(patch("serialptu.ptu.claim_selected_device"))
            versions = {"satgs": "0.0.1+jog.20261119.2", "ptu-control": "0.0.1+jog.20261119.2",
                        "serialptu": "0.0.1+jog.20261119.2"}
            stack.enter_context(patch.object(adapter, "version", side_effect=versions.__getitem__))
            cancel, finished = threading.Event(), threading.Event()
            outcomes, errors = [], []

            def foreground():
                try:
                    outcomes.append(adapter.run_manager(configuration, duration=4, cancel=cancel))
                except BaseException as error:
                    errors.append(error)
                finally:
                    finished.set()

            caller = threading.Thread(target=foreground, name="controlled-foreground-recovery")
            caller.start()
            client = transport = None
            try:
                ready = False
                deadline = time.monotonic() + 2
                while time.monotonic() < deadline and not finished.is_set():
                    with harness.broker.lock:
                        ready = Topics.BENCH_COMMAND + "_2" in harness.broker.subscriptions.values()
                    if ready:
                        break
                    finished.wait(.001)
                self.assertTrue(ready)
                transport = harness.open(station)
                controls = dict(deadline=time.monotonic() + 2, cancel=threading.Event())
                client = PtuClient.open_bench(messenger=transport, settings=station, ptu_id=2,
                    log_dir=directory, **controls)
                self.assertEqual(client.connect(**controls).category, "ok")
                preview = client.preview(1, -10, **controls)
                self.assertEqual(preview.category, "ok")

                def withhold_move_response(command):
                    if command == 0x33:
                        native.auto_ack = False

                native.before_write = withhold_move_response
                moved = client.move(preview.preview_sequence, **controls)
                self.assertEqual((moved.category, moved.submission), ("deadline", "complete"))
                self.assertEqual(moved.physical_state, "indeterminate")
                native.before_write = None
                native.auto_ack = True
                self.assertFalse(finished.wait(.1), "foreground exited before same-owner recovery")
                status = client.status(**controls)
                self.assertEqual((status.category, status.pan), ("ok", 1))
                stopped = client.stop(**controls).as_record()
                self.assertEqual(stopped["category"], "ok")
                self.assertEqual([item["operation"] for item in stopped["exchanges"]], ["stop", "status"])
                self.assertEqual(stopped["physical_state"], "indeterminate")
                self.assertEqual(client.preview(2, -10, **controls).category, "busy")
                self.assertEqual((native.opens, len(native.motion())), (1, 1))
            finally:
                native.before_write = None
                native.auto_ack = True
                try:
                    if client is not None:
                        client.close(deadline=time.monotonic() + 1)
                    if transport is not None:
                        transport.close(deadline=time.monotonic() + 1)
                finally:
                    cancel.set()
                    caller.join(2)
            self.assertFalse(caller.is_alive())
            self.assertEqual(errors, [])
            self.assertEqual(len(outcomes), 1)
            self.assertEqual((outcomes[0]["exit_code"], outcomes[0]["category"]), (130, "cancelled"))
            self.assertTrue(outcomes[0]["activated"])
            self.assertFalse(outcomes[0]["physical_stop_established"])
            self.assertEqual(outcomes[0]["cleanup"], [])
            self.assertEqual((native.opens, native.closes), (1, 1))

    def test_actual_foreground_lifetime_releases_real_owners_without_motion(self):
        with ExitStack() as stack:
            adapter, configuration, harness, native = self.fixture(stack)
            baseline = set(threading.enumerate())
            result = adapter.run_manager(configuration, duration=.1, cancel=threading.Event())
            self.assertTrue(result["activated"])
            self.assertEqual(result["exit_code"], 0)
            self.assertEqual(result["cleanup"], [])
            self.assertFalse(result["physical_stop_established"])
            self.assertEqual((native.opens, native.closes), (1, 1))
            self.assertFalse(native.opened)
            self.assertEqual(native.motion(), [])
            for packet in native.writes:
                native.proto.validate_nonmoving_status_packet(packet)
            self.assertTrue(all(endpoint.resource["closed"] for endpoint in harness.raws))
            self.assertFalse(any(worker not in baseline and worker.name == "ptu-bench-owner"
                                 and worker.is_alive() for worker in threading.enumerate()))
            self.assertFalse(any(worker.name == "operator-bench-acquisition-cancel" and worker.is_alive()
                                 for worker in threading.enumerate()))

    def test_actual_foreground_cancellation_is_passive_and_joins_worker(self):
        with ExitStack() as stack:
            adapter, configuration, harness, native = self.fixture(stack)
            baseline = set(threading.enumerate())
            cancel = threading.Event()
            activated = threading.Event()

            def cancel_active_owner():
                deadline = time.monotonic() + 2
                while time.monotonic() < deadline:
                    if any(worker not in baseline and worker.name == "ptu-bench-owner"
                           and worker.is_alive() for worker in threading.enumerate()):
                        activated.set()
                        cancel.set()
                        return
                    threading.Event().wait(.001)
                cancel.set()

            caller = threading.Thread(target=cancel_active_owner, name="controlled-manager-cancel")
            caller.start()
            try:
                result = adapter.run_manager(configuration, duration=3, cancel=cancel)
            finally:
                cancel.set()
                caller.join(2)
            self.assertTrue(activated.is_set())
            self.assertTrue(result["activated"])
            self.assertEqual(result["exit_code"], 130)
            self.assertEqual(result["cleanup"], [])
            self.assertFalse(native.opened)
            self.assertEqual(native.motion(), [])
            for packet in native.writes:
                native.proto.validate_nonmoving_status_packet(packet)
            self.assertTrue(all(endpoint.resource["closed"] for endpoint in harness.raws))
            self.assertFalse(any(worker.name == "operator-bench-acquisition-cancel" and worker.is_alive()
                                 for worker in threading.enumerate()))
