import hashlib
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import tarfile
import types
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]


def load(relative, name):
    path = ROOT / relative
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(path.read_bytes(), str(path), 'exec', dont_inherit=True), vars(module))
    return module


release = load('support/release_update.py', 'tested_release_update')
source = load('tools/source_status.py', 'tested_source_status')
builder = load('tools/build_release.py', 'tested_source_builder')
packager = load('tools/package_release.py', 'tested_release_packager')


class ReleaseWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='satgs-source-workflow-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def test_release_pairs_owners_and_retains_dependency_base_without_migrations(self):
        manifest = release.release_manifest()
        self.assertEqual(manifest['packages']['satgs'], manifest['packages']['ptu-control'])
        self.assertEqual(manifest['packages']['serialptu'], '0.0.1+jog.20261119.2')
        self.assertEqual(manifest['selection'], 'jog5')
        self.assertEqual(manifest['packages']['meteor-api'], '2.2.0+bench.20261117.1')
        self.assertEqual(manifest['packages']['stomp-py'], '8.1.0+bench.20261117.1')
        self.assertEqual(set(manifest['replacement_wheels']),
                         {'satgs', 'ptu-control', 'serialptu', 'meteor-api', 'stomp-py'})
        self.assertEqual(manifest['packages']['pixhawk'], '0.0.1')
        self.assertEqual(manifest['dependency_base']['manager_distributions'], 31)
        self.assertEqual(manifest['workspace']['migrations'], [])
        for constraints in ('runtime-constraints.txt', 'development-constraints.txt'):
            pins = dict(line.split('==') for line in
                        (ROOT / 'requirements' / constraints).read_text().splitlines() if '==' in line)
            for name, version in manifest['packages'].items():
                self.assertEqual(pins[name], version, (constraints, name))
        self.assertEqual(manifest['activity_source_sha256'], hashlib.sha256(
            (ROOT / 'components/ground_station/src/satgs/operator_activity.py').read_bytes()).hexdigest())

    def test_manifest_rejects_different_pairing_workspace_duplicate_fields_and_traversal(self):
        original = release.release_manifest()
        path = self.root / 'release.json'
        for change in ('pairing', 'meteor', 'lower', 'replacements', 'workspace', 'duplicate', 'traversal', 'guard'):
            with self.subTest(change=change):
                value = json.loads(json.dumps(original))
                if change == 'pairing':
                    value['packages']['ptu-control'] = '0.0.1'
                elif change == 'meteor':
                    value['packages']['meteor-api'] = '2.2.0'
                elif change == 'lower':
                    value['packages']['stomp-py'] = '8.1.0'
                elif change == 'replacements':
                    del value['replacement_wheels']['stomp-py']
                elif change == 'workspace':
                    value['workspace']['schema_version'] = 2
                elif change == 'traversal':
                    value['paths']['installer'] = '/tmp/../unreviewed'
                elif change == 'guard':
                    value['activity_source_sha256'] = '0' * 64
                raw = json.dumps(value)
                if change == 'duplicate':
                    raw = raw[:-1] + ', "schema": "satgs-offline-release.v1"}'
                path.write_text(raw)
                with self.assertRaises(ValueError):
                    release.release_manifest(path)

    def test_status_reports_missing_release_artifact_without_writing_or_selecting(self):
        manifest, daily = release.release_manifest(), release.daily_module()
        with mock.patch.object(release, 'ROOT', self.root), \
                mock.patch.object(release, 'release_manifest', return_value=manifest), \
                mock.patch.object(release, 'daily_module', return_value=daily):
            before = list(self.root.iterdir())
            result = release.status(home=self.root)
        self.assertEqual({row['status'] for row in result['replacement_wheels'].values()}, {'MISSING'})
        self.assertFalse(result['network_requested'])
        self.assertEqual(list(self.root.iterdir()), before)
        for target in ('jog2', 'jog', 'bench', 'ptu', 'handbook', 'guide', 'ui', 'runtime'):
            with self.subTest(target=target), \
                    mock.patch.object(daily, 'select', return_value={'selected': target}) as selected, \
                    mock.patch.object(release, 'daily_module', return_value=daily), redirect_stdout(io.StringIO()):
                self.assertEqual(release.main(['rollback', '--target', target]), 0)
            selected.assert_called_once_with(Path.home(), target)

    def test_stage_requires_trust_and_passes_only_explicit_installer_overrides(self):
        args = types.SimpleNamespace(accept_trusted_native=False)
        with self.assertRaises(ValueError):
            release.stage(args)
        setup = types.SimpleNamespace(main=mock.Mock(return_value=1))
        manifest = release.release_manifest()
        args = types.SimpleNamespace(accept_trusted_native=True, previous_bundle=self.root / 'offline',
                                     application=self.root / 'new-app', installer=None, output_root=None)
        with mock.patch.object(release, 'module', return_value=setup), \
                mock.patch.object(release, 'release_manifest', return_value=manifest):
            self.assertEqual(release.stage(args), 1)
        setup.main.assert_called_once_with(['--previous-bundle', str(args.previous_bundle),
                                            '--application', str(args.application)])

    def test_occupied_candidate_and_unavailable_bundle_are_preserved(self):
        installer = load('support/setup_operator_update.py', 'tested_source_installer')
        occupied = self.root / 'occupied-app'
        occupied.mkdir()
        retained = occupied / 'retained'
        retained.write_text('unchanged candidate')
        with self.assertRaisesRegex(RuntimeError, 'new path'):
            installer.new_environment(occupied, ())
        with self.assertRaises(FileNotFoundError):
            installer.selected_wheels(self.root / 'unavailable-bundle', self.root / 'missing.whl')
        self.assertEqual(retained.read_text(), 'unchanged candidate')
        self.assertEqual(list(self.root.iterdir()), [occupied])

    def test_build_inputs_are_six_ordinary_owners_and_exact_pinned_tools(self):
        self.assertEqual(set(builder.COMPONENTS), {
            'ground_station', 'sat_tracker', 'serialptu', 'pixhawk', 'meteor-api', 'stomp.py'})
        self.assertEqual(set(builder.tool_versions()), {'build', 'packaging', 'pyproject-hooks', 'setuptools', 'wheel'})
        text = (ROOT / 'tools/build_release.py').read_text()
        self.assertNotIn('/workspace/', text)
        self.assertIn('--no-isolation', text)
        self.assertIn("PIP_NO_INDEX='1'", text)

    def test_setup_replaces_exact_five_wheels_and_preserves_other_retained_dependencies(self):
        installer = load('support/setup_operator_update.py', 'tested_five_wheel_installer')
        versions = dict(line.split('==') for line in
                        (ROOT / 'support/reference/requirements/development-constraints.txt').read_text().splitlines())
        versions['satgs'] = installer.OLD_VERSION
        bundle, wheels = self.root / 'bundle', self.root / 'wheels'
        manifest = dict(schema_version=1, runtime_counts=dict(manager=31),
                        source=dict(commit=installer.RELEASE['dependency_base']['source_commit']),
                        installer=dict(version='26.2', wheel='installer/pip-26.2-py3-none-any.whl', lock='installer/lock.txt'),
                        locks=dict(manager='locks/manager.txt'),
                        files=[dict(kind='wheel', path='wheelhouse/' + name + '.whl', name=name, version=version)
                               for name, version in versions.items()])
        manager_lock = '\n'.join(name + ('[pointing]' if name == 'satgs' else
                                '[manager]' if name in ('ptu-control', 'pixhawk') else '') + '==' + version
                                 for name, version in versions.items()).encode()

        def read_lock(path, limit):
            return b'pip==26.2\n' if path == bundle / 'installer/lock.txt' else manager_lock

        def wheel_details(path, name, version):
            return dict(path=str(path), name=name, version=version, tags=['py3-none-any'],
                        scripts={'satgs-bench-manager': 'satgs.operator_bench_manager:main'} if name == 'satgs' else {})

        with mock.patch.object(installer, 'json_input', return_value=manifest), \
                mock.patch.object(installer, 'read', side_effect=read_lock), \
                mock.patch.object(installer, 'wheel_details', side_effect=wheel_details):
            _, _, selected, inputs = installer.selected_wheels(
                bundle, wheels / Path(installer.RELEASE['replacement_wheels']['satgs']).name)
        self.assertEqual(len(selected), 31)
        changed = {row['name'] for row in selected if Path(row['path']).parent == wheels}
        self.assertEqual(changed, {'satgs', 'ptu-control', 'serialptu', 'meteor-api', 'stomp-py'})
        for row in selected:
            name = row['name']
            self.assertEqual(row['version'], installer.RELEASE['packages'][name] if name in changed else versions[name])
            self.assertIn(str(bundle / ('wheelhouse/' + name + '.whl')), inputs)
            if name in changed:
                self.assertEqual(Path(row['path']).name, Path(installer.RELEASE['replacement_wheels'][name]).name)
        self.assertEqual(next(row['selected_extras'] for row in selected if row['name'] == 'satgs'), ['pointing', 'gui'])


class PackageReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='satgs-portable-package-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def test_exact_replacement_import_roots_reject_foreign_native_and_mismatched_metadata(self):
        versions = release.release_manifest()['packages']
        for distribution, package in packager.REPLACEMENT_PACKAGES.items():
            metadata = distribution.replace('-', '_') + '-' + versions[distribution] + '.dist-info/METADATA'
            details = dict(version=versions[distribution], members=[package + '/__init__.py', metadata])
            self.assertIsNone(packager.verify_replacement_members(distribution, details))
            for invalid in ('foreign/__init__.py', package + '/native.so', package + '/cached.pyc',
                            package + '/startup.pth', distribution.replace('-', '_') + '-wrong.dist-info/METADATA'):
                with self.subTest(distribution=distribution, invalid=invalid), self.assertRaises(ValueError):
                    packager.verify_replacement_members(distribution, dict(details, members=[*details['members'], invalid]))
        with self.assertRaises(ValueError):
            packager.verify_replacement_members('stomp-py', dict(version=versions['stomp-py'], members=['stomp_py/__init__.py']))
        with self.assertRaises(ValueError):
            packager.verify_replacement_members('unreviewed', dict(version='1', members=['unreviewed/__init__.py']))

    def test_archive_is_deterministic_and_contains_only_ordinary_versioned_members(self):
        instructions = packager.transfer_readme(release.release_manifest(), 'satgs-jog-20261119.2').decode()
        self.assertIn('--select jog5\n', instructions)
        self.assertIn('Rollback selection is `. ./launchers/setup_daily.sh --select bench`', instructions)
        payload = {'README.md': (b'controlled release fixture\n', 0o644),
                   'run_pi_operator_checks.sh': (b'#!/bin/sh\n', 0o755)}
        epoch = 1794441600
        first = packager.archive_bytes('satgs-fixture', payload, epoch)
        self.assertEqual(first, packager.archive_bytes('satgs-fixture', payload, epoch))
        self.assertEqual(int.from_bytes(first[4:8], 'little'), epoch)
        with tarfile.open(fileobj=io.BytesIO(first), mode='r:gz') as archive:
            self.assertEqual(archive.getnames(), ['satgs-fixture/README.md', 'satgs-fixture/run_pi_operator_checks.sh'])
            for member in archive.getmembers():
                self.assertTrue(member.isfile())
                self.assertEqual(member.mtime, epoch)
                self.assertEqual((member.uid, member.gid), (0, 0))

    def test_source_tree_rejects_traversal_links_private_state_and_execution_outputs(self):
        for name in ('../escape', '/absolute', 'one//two', 'one\\two'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                packager.member_name(name)
        folder = self.root / 'source'
        folder.mkdir()
        for name in ('station.json', '.env', 'capture.log', 'private.pem', 'artifact.whl'):
            with self.subTest(name=name):
                path = folder / name
                path.write_text('controlled excluded fixture')
                with self.assertRaises(ValueError):
                    packager.files(folder)
                path.unlink()
        (folder / 'linked.py').symlink_to(self.root / 'absent')
        with self.assertRaises(ValueError):
            packager.files(folder)

    def test_build_record_requires_exact_current_six_owner_source(self):
        payload = {'components/' + name + '/source.py': (name.encode(), 0o644) for name in packager.COMPONENTS}
        inputs = {name: {'source.py': dict(bytes=len(name), sha256=hashlib.sha256(name.encode()).hexdigest())}
                  for name in packager.COMPONENTS}
        packager.verify_build_sources(dict(source_inputs=inputs), payload)
        changed = dict(payload)
        changed['components/ground_station/source.py'] = b'changed after build', 0o644
        with self.assertRaisesRegex(ValueError, 'differs'):
            packager.verify_build_sources(dict(source_inputs=inputs), changed)
        with self.assertRaisesRegex(ValueError, 'differs'):
            packager.verify_build_sources(dict(source_inputs={}), payload)

    def test_changed_source_is_detected_without_rewriting_it(self):
        path = self.root / 'source.py'
        path.write_bytes(b'original source\n')
        observed = {}
        packager.read(path, observed)
        path.write_bytes(b'changed source\n')
        with self.assertRaisesRegex(ValueError, 'changed'):
            packager.unchanged(observed, {})
        self.assertEqual(path.read_bytes(), b'changed source\n')

    def test_occupied_output_is_preserved_before_any_collection(self):
        wheels = self.root / 'wheels'
        wheels.mkdir()
        output = self.root / 'occupied'
        output.mkdir()
        retained = output / 'retained'
        retained.write_text('existing package')
        with mock.patch.object(packager, 'collect') as collect:
            with self.assertRaisesRegex(ValueError, 'occupied'):
                packager.package(types.SimpleNamespace(wheels=wheels, output_root=output))
            collect.assert_not_called()
        self.assertEqual(retained.read_text(), 'existing package')

    def test_failed_postcheck_retains_archive_and_explicit_failed_result(self):
        wheels = self.root / 'wheels'
        wheels.mkdir()
        output = self.root / 'failed-package'
        release_record = dict(release='controlled.1', source_date_epoch=1794441600)
        payload = {'README.md': (b'controlled fixture\n', 0o644)}
        with mock.patch.object(packager, 'collect', return_value=(release_record, payload, {}, {})), \
                mock.patch.object(packager, 'unchanged', side_effect=[None, ValueError('source changed')]):
            self.assertEqual(packager.package(types.SimpleNamespace(wheels=wheels, output_root=output)), 1)
        self.assertTrue((output / 'satgs-controlled.1.tar.gz').is_file())
        result = json.loads((output / 'package-result.json').read_text())
        self.assertEqual(result['status'], 'FAIL')
        self.assertIn('source changed', result['primary']['message'])
        self.assertFalse((output / 'satgs-controlled.1.tar.gz.sha256').exists())


class SourceStatusTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='satgs-local-source-status-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        (self.root / '.git').mkdir()

    def test_inspection_is_local_and_does_not_synchronize_or_activate(self):
        commit = 'a' * 40
        with mock.patch.object(source, 'git', side_effect=['refs/heads/feature/test', commit, commit, '']) as git:
            result = source.inspect('refs/heads/feature/test', root=self.root)
        self.assertTrue(result['synchronized'])
        self.assertFalse(result['network_requested'])
        self.assertFalse(result['installation_modified'])
        self.assertNotIn('fetch', str(git.call_args_list))

    def test_dirty_checkout_missing_ref_and_application_workspace_fail_closed(self):
        commit = 'a' * 40
        with mock.patch.object(source, 'git', side_effect=['refs/heads/feature/test', commit, commit, ' M changed.py']):
            with self.assertRaisesRegex(ValueError, 'dirty'):
                source.inspect('refs/heads/feature/test', root=self.root)
        with mock.patch.object(source, 'git', side_effect=ValueError('requested source/ref is unavailable')):
            with self.assertRaisesRegex(ValueError, 'unavailable'):
                source.inspect('refs/heads/absent', root=self.root)
        (self.root / 'pyvenv.cfg').write_text('fixture application')
        with mock.patch.object(source, 'git') as git:
            with self.assertRaisesRegex(ValueError, 'application environment'):
                source.inspect('refs/heads/feature/test', root=self.root)
            git.assert_not_called()

    def test_git_failure_is_sanitized_and_uses_noninteractive_no_lazy_fetch_envelope(self):
        response = types.SimpleNamespace(returncode=1, stdout='', stderr='controlled private diagnostic not for output')
        with mock.patch.object(source.subprocess, 'run', return_value=response) as run:
            with self.assertRaisesRegex(ValueError, 'No network request') as error:
                source.git(['rev-parse', '--verify', 'refs/heads/absent'], root=self.root)
        self.assertNotIn('private diagnostic', str(error.exception))
        call = run.call_args
        self.assertEqual(call.kwargs['cwd'], self.root)
        self.assertEqual(call.kwargs['env']['GIT_OPTIONAL_LOCKS'], '0')
        self.assertEqual(call.kwargs['env']['GIT_NO_LAZY_FETCH'], '1')
        self.assertEqual(call.kwargs['env']['GIT_TERMINAL_PROMPT'], '0')
        self.assertIn('core.fsmonitor=false', call.args[0])


class AcceptanceBindingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='satgs-workflow-binding-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.acceptance = load('support/run_acceptance.py', 'tested_acceptance_binding')
        self.policy = load('support/pi_guard.py', 'tested_workflow_policy')
        self.application = self.root / 'application'
        self.runtime = self.root / 'runtime'
        self.canonical = self.root / 'components/ground_station'
        self.reference = self.root / 'support/reference/ground_station'
        self.activity = self.canonical / 'src/satgs/operator_activity.py'
        for folder in (self.application, self.runtime / 'lib/python3.11',
                       self.activity.parent, self.reference / 'src/satgs',
                       *(self.root / name for name in ('launchers', 'tests', 'tools', 'requirements'))):
            folder.mkdir(parents=True, exist_ok=True)
        self.activity.write_bytes(b'fixture activity source\n')
        (self.reference / 'src/satgs/operator_activity.py').write_bytes(self.activity.read_bytes())
        self.neighbor = self.activity.with_name('unrelated.py')
        self.neighbor.write_bytes(b'not an additional workflow input\n')
        (self.root / 'release.json').write_text('{}\n')
        for name in ('runtime-constraints.txt', 'development-constraints.txt'):
            (self.root / 'requirements' / name).write_bytes((ROOT / 'requirements' / name).read_bytes())
        for name, value in (('ROOT', self.root), ('HERE', self.root / 'support')):
            patcher = mock.patch.object(self.acceptance, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)

    def inputs(self, source=None):
        return self.acceptance.candidate_inputs(source or self.reference, self.application, self.runtime)

    def test_exact_addition_in_delivered_layout_and_no_change_in_canonical_layout(self):
        for source in (self.reference, self.canonical):
            with self.subTest(source=source):
                previous, directories, native = self.acceptance.inventory((
                    self.runtime / 'lib/python3.11', self.application, source, self.root / 'support',
                    *(self.root / name for name in ('launchers', 'tests', 'tools', 'requirements'))),
                    self.runtime / 'lib/python3.11')
                previous[str(self.root / 'release.json')] = self.acceptance.sha(self.root / 'release.json')
                files, actual_directories, actual_native = self.inputs(source)
                self.assertEqual(files, dict(previous, **{str(self.activity): self.acceptance.sha(self.activity)}))
                self.assertEqual(actual_directories, directories)
                self.assertEqual(actual_native, native)
                if source == self.reference:
                    self.assertEqual(set(files) - set(previous), {str(self.activity)})
                    self.assertNotIn(str(self.neighbor), files)
                    self.assertNotIn(str(self.activity.parent), actual_directories)
                else:
                    self.assertEqual(files, previous)

    def test_missing_and_nonordinary_activity_are_rejected(self):
        self.activity.unlink()
        with self.assertRaises(FileNotFoundError):
            self.inputs()
        self.activity.mkdir()
        with self.assertRaisesRegex(RuntimeError, 'ordinary'):
            self.inputs()

    def test_symlinked_activity_and_ancestor_are_rejected(self):
        self.activity.unlink()
        self.activity.symlink_to(self.reference / 'src/satgs/operator_activity.py')
        with self.assertRaisesRegex(RuntimeError, 'ordinary'):
            self.inputs()
        self.activity.unlink()
        self.activity.parent.rename(self.canonical / 'moved')
        self.activity.parent.symlink_to(self.canonical / 'moved', target_is_directory=True)
        with self.assertRaisesRegex(RuntimeError, 'ordinary'):
            self.inputs()

    def test_changed_activity_invalidates_bound_identity_and_original_checksum_assertion(self):
        files, unused_directories, unused_native = self.inputs()
        provenance = self.acceptance.provenance
        binding = dict(inputs=files, input_identities={name: provenance.identity(name) for name in files})
        self.assertEqual(provenance.current(binding), [])
        manifest = release.release_manifest()
        manifest['activity_source_sha256'] = files[str(self.activity)]
        assertion = ReleaseWorkflowTests('test_release_pairs_owners_and_retains_dependency_base_without_migrations')
        with mock.patch.object(sys.modules[__name__], 'ROOT', self.root), \
                mock.patch.object(release, 'release_manifest', return_value=manifest):
            assertion.test_release_pairs_owners_and_retains_dependency_base_without_migrations()
            self.activity.write_bytes(b'changed fixture activity source\n')
            with self.assertRaisesRegex(RuntimeError, 'modified'):
                provenance.current(binding)
            with self.assertRaises(AssertionError):
                assertion.test_release_pairs_owners_and_retains_dependency_base_without_migrations()

    def test_exact_read_policy_does_not_admit_neighbor_writes_or_directory_listing(self):
        files, directories, native = self.inputs()
        guard = self.policy.CheckGuard(files, directories, native)
        guard.audit('open', (str(self.activity), 'r', os.O_CLOEXEC))
        denied = (
            ('open', (str(self.neighbor), 'r', os.O_CLOEXEC)),
            ('open', (str(self.activity), 'w', os.O_WRONLY | os.O_CLOEXEC)),
            ('os.listdir', (str(self.activity.parent),)),
        )
        with redirect_stdout(io.StringIO()):
            for event, arguments in denied:
                with self.subTest(event=event), self.assertRaises(PermissionError):
                    guard.audit(event, arguments)
        self.assertEqual(len(guard.denials), len(denied))


if __name__ == '__main__':
    unittest.main()
