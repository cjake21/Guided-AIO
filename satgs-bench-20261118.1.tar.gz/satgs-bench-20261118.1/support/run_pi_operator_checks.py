"""Observe the actual acceptance-runner exit and finalize one operator handoff."""

import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import time


HERE = Path(__file__).resolve().parent
DIAGNOSTIC_APPLICATION = Path('/home/admin/satgs-operator-20261028-r3-app-client')
DIAGNOSTIC_OUTPUT = Path('/home/admin/satgs-operator-20261028-r3-acceptance')


def load(name):
    path = HERE / (name + '.py')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--accept-trusted-native', action='store_true')
    parser.add_argument('--startup-diagnostic', action='store_true',
                        help='Record one protected Tk startup only; never an acceptance pass.')
    parser.add_argument('--owned-host-display-fixture', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--owned-host-native-scratch', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--capture-widgets-only', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--installed-preflight', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--headless-development', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--application', type=Path)
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--source', type=Path)
    parser.add_argument('--controls-only', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--launcher-followup', action='store_true',
                        help='Check launcher wiring without repeating product/native suites.')
    args = parser.parse_args()
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise RuntimeError('use run_pi_operator_checks.sh')
    recording, target, runner = load('recording'), load('pi_target'), load('run_acceptance')
    release = load('release_update').release_manifest()
    selected_lanes, scope = runner.route(args)
    if args.owned_host_native_scratch is not None and not args.owned_host_display_fixture:
        raise RuntimeError('Owned native scratch requires the host display fixture.')
    recording.report_text = runner.report_text
    output = recording.ordinary(args.output_root or (DIAGNOSTIC_OUTPUT if args.startup_diagnostic
                                else Path(release['paths']['acceptance_output'])))
    app = (args.application or (DIAGNOSTIC_APPLICATION if args.startup_diagnostic
                               else Path(release['paths']['application']))).resolve()
    source = (args.source or HERE / ('diagnostic-reference/ground_station' if args.startup_diagnostic
                                    else 'reference/ground_station')).resolve()
    runtime_error = None
    runtime = Path(sys.base_prefix).resolve()
    try:
        runtime = runner.declared_runtime(app, recording)
    except (OSError, RuntimeError) as error:
        runtime_error = error
    if any(output == root or root in output.parents for root in (HERE, app, source, runtime, Path(sys.base_prefix).resolve())):
        raise RuntimeError('output must be separate from application, support, references and interpreter runtime')
    output.mkdir(mode=0o700, parents=True, exist_ok=True)
    attempt = Path(tempfile.mkdtemp(prefix='operator-acceptance-', dir=output))
    summary = dict(schema='operator-consolidated-acceptance.v2', status='FAIL', application=str(app),
                   scope=scope,
                   source=str(source), phases={name: dict(status='NOT RUN') for name in selected_lanes},
                   primary=None, cleanup=dict(status='NOT RUN'), capture_errors=[], signals=[],
                   packaging=dict(status='NOT RUN'), provenance={}, native_selection={})
    started = time.monotonic()
    interrupts = recording.Interrupts()
    previous = {number: signal.signal(number, interrupts.handler) for number in (signal.SIGINT, signal.SIGTERM)}
    selected_keys = ('HOME',) if args.launcher_followup else ('DISPLAY', 'XAUTHORITY', 'HOME', 'XDG_SESSION_TYPE')
    selected = {key: os.environ[key] for key in selected_keys if key in os.environ}
    context = dict(schema='operator-launch-context.v1', selected_application=str(app),
                   outer_interpreter=sys.executable, operator_display_environment=selected,
                   owned_host_display_fixture=args.owned_host_display_fixture,
                   authentication_contents='not read or archived by the launcher',
                   operator_reported_prior_smoke='Cole reports r3 GUI opened/clicked and CLI ran without observed errors; not automated acceptance',
                   start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    observed = None
    complete = False
    try:
        recording.write_json(attempt / 'operator-context.json', context)
        if runtime_error is not None:
            summary['status'] = 'BLOCKED'
            raise runtime_error
        if not args.accept_trusted_native:
            summary['status'] = 'BLOCKED'
            raise RuntimeError('use --accept-trusted-native for the documented CPython/native-runtime trust boundary')
        interpreter = app / 'bin/python'
        if not interpreter.is_file() or not source.is_dir():
            summary['status'] = 'BLOCKED'
            raise FileNotFoundError('existing application interpreter or bundled references are missing; do not reinstall')
        environment = dict(target.ENV)
        environment.update(selected)
        command = [str(interpreter), '-I', '-B', '-S', str(HERE / 'run_acceptance.py'),
                   '--application', str(app), '--source', str(source), '--attempt', str(attempt)]
        if args.owned_host_display_fixture:
            command.append('--owned-host-display-fixture')
        if args.owned_host_native_scratch is not None:
            command.extend(('--owned-host-native-scratch', str(args.owned_host_native_scratch)))
        if args.startup_diagnostic:
            command.append('--startup-diagnostic')
        if args.controls_only:
            command.append('--controls-only')
        if args.capture_widgets_only:
            command.append('--capture-widgets-only')
        if args.installed_preflight:
            command.append('--installed-preflight')
        if args.headless_development:
            command.append('--headless-development')
        if args.launcher_followup:
            command.append('--launcher-followup')
        observed = target.supervise(command, attempt / 'runner', cwd=HERE, environment=environment,
                                    timeout=1200, cap=4 * 1024 * 1024, terminate_grace=30)
        inner = recording.load_json(attempt / 'inner-summary.json')
        recording.require(inner['schema'] == summary['schema'] and inner['application'] == str(app)
                          and inner['source'] == str(source) and inner['scope'] == summary['scope']
                          and set(inner['phases']) == set(selected_lanes),
                          'runner summary scope differs from selected inputs')
        summary = inner
        expected = 0 if summary['status'] == 'PASS' else 78 if summary['status'] == 'BLOCKED' else 1
        if (observed.get('exit') != expected or observed.get('final_exit') != expected
                or not target.supervision_passed(dict(observed, exit=0))):
            summary['status'] = 'FAIL'
            summary['primary'] = summary.get('primary') or dict(type='RunnerSupervisionFailure',
                message='observed runner exit, timeout, output or cleanup differs from its reported outcome')
    except BaseException as error:
        summary['primary'] = summary.get('primary') or dict(type=type(error).__name__, message=recording.error_text(error))
        if summary['status'] != 'BLOCKED':
            summary['status'] = 'FAIL'
    finally:
        interrupts.finalizing = True
        summary['signals'] = list(interrupts.received)
        if interrupts.received:
            summary['status'] = 'FAIL'
        summary['launcher'] = dict(observed_runner_exit=observed.get('final_exit') if observed else None,
                                   supervision=observed, exit_to_return=None,
                                   scope='actual supervised acceptance process exit; outer launcher return decision follows recording')
        if observed is not None and (observed.get('quiescent') is not True or observed.get('cleanup_errors')):
            summary['status'] = 'FAIL'
            summary['cleanup'] = dict(status='FAIL', runner=observed.get('cleanup_errors'))
        summary['duration_seconds'] = time.monotonic() - started
        if not summary.get('provenance'):
            summary['provenance'] = runner.provenance.summary(runner.provenance.optional_checksums(HERE))
        try:
            recording.write_json(attempt / 'provenance.json', summary['provenance'])
            summary['packaging'] = runner.package_attempt(recording, attempt)
        except BaseException as error:
            summary['status'] = 'FAIL'
            summary['packaging'] = dict(status='FAIL', type=type(error).__name__, error=recording.error_text(error))
        summary['launcher']['exit_to_return'] = 0 if summary['status'] == 'PASS' else 78 if summary['status'] == 'BLOCKED' else 1
        complete = recording.finalize_records(attempt, summary, interrupts)
        for number, handler in previous.items():
            signal.signal(number, handler)
        print(summary['status'] + ': ' + str(attempt / 'report.txt'))
        print('Evidence: ' + str(attempt / 'evidence.tar.gz'))
        print('Completion: ' + str(attempt / 'completion.json'))
        print('Observed acceptance-runner exit: ' + str(summary['launcher']['observed_runner_exit']))
    return summary['launcher']['exit_to_return'] if complete else 1


if __name__ == '__main__':
    raise SystemExit(main())
