"""Selected local desktop capability for source-controlled native widget tests.

This is not a hostile-Python or native-syscall sandbox. Tcl_Init, Tk's native
initialization and the installed runtime are trusted. Tcl command effects are
guarded before product widgets run. No display server or session is managed.
"""

import ast
import dis
import errno
import importlib
import os
from pathlib import Path
import re
import stat
import sys
import sysconfig
import threading
import types


SCHEMA = 'operator-selected-local-desktop.v1'
DISPLAY = re.compile(r'^(?:unix/)?:([0-9]{1,5})(?:\.([0-9]{1,2}))?$')
CONTROL_NAMESPACE = '::__satgs_desktop_control'
HOST_FIXTURE_LABEL = 'explicit development-owned display fixture; label is not ownership proof'
NATIVE_TESTS = 38
TK_NATIVE_NAMES = {'8.6': frozenset(('libtk8.6.so', 'libtk8.6.so.0')),
                   '9.0': frozenset(('libtcl9tk9.0.so',))}
MAX_RESOURCES = 8192
MAX_DENIALS = 128
MAX_MODULE_EVENTS = 256
MAX_CATALOG_EVENTS = 32
MAX_STARTUP_SOURCE = 128 * 1024
NATIVE_NAMES = re.compile(r'^(?:_tkinter\.|lib(?:tcl|tk|X11|Xau|Xdmcp|xcb|fontconfig|freetype|python3(?:\.11)?(?:\.so|$)))')
DENIED = frozenset(('socket', 'exec', 'load', 'unload', 'exit', 'cd', 'send',
                    'clipboard', 'selection', 'bell', 'zipfs'))
FILE_READS = frozenset(('atime', 'dirname', 'executable', 'exists', 'extension',
    'isdirectory', 'isfile', 'join', 'lstat', 'mtime', 'nativename', 'normalize',
    'owned', 'pathtype', 'readable', 'rootname', 'separator', 'size', 'split',
    'stat', 'tail', 'type', 'volumes', 'writable'))
FILE_PURE = frozenset(('dirname', 'extension', 'join', 'pathtype', 'rootname',
                      'separator', 'split', 'tail', 'volumes'))
CHANNEL_COMMANDS = frozenset(('read', 'gets', 'eof', 'close', 'seek', 'tell',
                             'fblocked', 'fconfigure', 'fileevent', 'flush', 'puts'))
WM_ALLOWED = frozenset(('title', 'iconname', 'transient', 'minsize', 'maxsize', 'geometry', 'protocol',
    'resizable', 'deiconify', 'withdraw', 'state', 'positionfrom', 'sizefrom'))
WINFO_ALLOWED = frozenset(('children', 'class', 'depth', 'exists', 'fpixels',
    'geometry', 'height', 'ismapped', 'manager', 'name', 'parent', 'pixels',
    'reqheight', 'reqwidth', 'rootx', 'rooty', 'screen', 'screencells',
    'screendepth', 'screenheight', 'screenmmheight', 'screenmmwidth', 'screenwidth',
    'toplevel', 'viewable', 'visual', 'vrootheight', 'vrootwidth', 'vrootx',
    'vrooty', 'width', 'x', 'y'))
CREATORS = frozenset(('button', 'canvas', 'checkbutton', 'entry', 'frame', 'label',
    'labelframe', 'listbox', 'menu', 'menubutton', 'message', 'panedwindow',
    'radiobutton', 'scale', 'scrollbar', 'spinbox', 'text', 'toplevel'))
TK_TEARDOWN_TRACES = {
    '::bell': 'denied:bell', '::button': 'creator', '::canvas': 'creator',
    '::checkbutton': 'creator', '::clipboard': 'denied:clipboard', '::destroy': 'destroy',
    '::entry': 'creator', '::event': 'event', '::focus': 'focus', '::frame': 'creator',
    '::grab': 'grab', '::image': 'image', '::label': 'creator',
    '::labelframe': 'creator', '::listbox': 'creator', '::menu': 'creator',
    '::menubutton': 'creator', '::message': 'creator', '::option': 'option',
    '::panedwindow': 'creator', '::radiobutton': 'creator', '::scale': 'creator',
    '::scrollbar': 'creator', '::selection': 'denied:selection', '::send': 'denied:send',
    '::spinbox': 'creator', '::text': 'creator', '::tk': 'tk', '::toplevel': 'creator',
    '::winfo': 'winfo', '::wm': 'wm'}


class DesktopBlocked(RuntimeError):
    """A selected display or required native control is unsupported."""


class DesktopUnavailable(DesktopBlocked):
    """A native ABI/profile is outside the admitted lane before Tk creation."""


class DesktopGuardBlocked(DesktopBlocked):
    """A retained guard denial blocked protected native startup."""


def _tk_teardown_issues_supported(count, issues):
    return (count == len(issues) and count <= len(TK_TEARDOWN_TRACES)
            and all(row['present'] and not row['expected_trace_present']
                    and TK_TEARDOWN_TRACES.get(row['name']) == row['category'] for row in issues))


def require(value, reason):
    if not value:
        raise DesktopBlocked(reason)


def _absolute(path):
    require(isinstance(path, (str, Path)) and str(path) and Path(path).is_absolute(),
            'desktop paths must be explicit absolute paths')
    return Path(os.path.abspath(path))


def target_path_safe(value):
    return (type(value) is str and 0 < len(value) <= 4096 and Path(value).is_absolute()
            and all(character.isprintable() for character in value)
            and 'xauthority' not in value.lower() and 'cookie' not in value.lower())


def _startup_script(row, runtime):
    require(runtime['resources'].get(row['path']) is row
            and row['identity'][5] <= MAX_STARTUP_SOURCE
            and _same_metadata(row, resource_roots=runtime['resource_roots']),
            'startup diagnostic source must be bounded and already bound')
    descriptor = os.open(row['path'], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        info = os.fstat(descriptor)
        actual = [info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
                  info.st_size, info.st_mtime_ns, info.st_ctime_ns]
        require(actual == row['identity'], 'startup diagnostic source was replaced')
        raw = os.read(descriptor, MAX_STARTUP_SOURCE + 1)
        require(len(raw) == info.st_size and len(raw) <= MAX_STARTUP_SOURCE
                and _same_metadata(row, resource_roots=runtime['resource_roots']),
                'startup diagnostic source changed or exceeded its bound')
        return dict(path=row['path'], bytes=len(raw), source_utf8=raw.decode('utf-8'))
    finally:
        os.close(descriptor)


def _metadata(path, *, directory=False, authority=False, resource_roots=(), runtime_role=None):
    path = _absolute(path)
    for ancestor in (path, *path.parents):
        info = ancestor.lstat()
        require(not stat.S_ISLNK(info.st_mode), 'desktop input has a symlink component: ' + str(path))
    info = path.stat()
    require(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode),
            'desktop input has the wrong file type: ' + str(path))
    base = Path(sys.base_prefix)
    host_owned = (not directory and not authority and stat.S_ISREG(info.st_mode)
        and stat.S_IMODE(info.st_mode) in (0o664, 0o775) and info.st_uid == os.geteuid()
        and info.st_gid == os.getegid() and sys.platform == 'linux'
        and sys.version_info[:3] == (3, 11, 16)
        and sysconfig.get_config_var('SOABI') == 'cpython-311-x86_64-linux-gnu'
        and not path.is_relative_to(Path('/usr')))
    host_resource = (host_owned and stat.S_IMODE(info.st_mode) == 0o664
        and any(Path(root).parent == base / 'lib'
                and Path(root).name in ('tcl9', 'tcl9.0', 'tk9.0')
                and path.is_relative_to(Path(root)) for root in resource_roots))
    native_extension = base / 'lib/python3.11/lib-dynload/_tkinter.cpython-311-x86_64-linux-gnu.so'
    tkinter_source = base / 'lib/python3.11/tkinter/__init__.py'
    host_native = {native_extension, *(base / 'lib' / name for name in
        ('libtcl9.0.so', 'libtcl9tk9.0.so', 'libpython3.11.so.1.0', 'libpython3.so'))}
    host_runtime = (host_owned and (
        runtime_role == 'tkinter-extension' and path == native_extension
        or runtime_role == 'tkinter-source' and path == tkinter_source and stat.S_IMODE(info.st_mode) == 0o664
        or runtime_role == 'loaded-native' and path in host_native))
    require(not info.st_mode & 0o022 or host_resource or host_runtime,
            'desktop input is group/world writable outside the finite host resource policy: ' + str(path))
    if authority:
        require(info.st_uid == os.geteuid() and not info.st_mode & 0o077,
                'selected authority must be an ordinary private owner-readable file')
        require(os.access(path, os.R_OK), 'selected authority is not readable')
    result = dict(path=str(path), identity=[info.st_dev, info.st_ino, info.st_mode,
        info.st_uid, info.st_gid, info.st_size, info.st_mtime_ns, info.st_ctime_ns])
    if host_resource:
        result['permission_basis'] = 'selected host Tcl9 resource; exact0664 current owner and primary group'
    elif host_runtime:
        result['permission_basis'] = 'selected host ' + runtime_role + '; exact0664/0775 current owner and primary group'
    return result


def _interpreter_metadata(path, application, base):
    selected = current = _absolute(path)
    allowed = {application / 'bin', base / 'bin'}
    aliases = {'python', 'python3', 'python3.11'}
    links, seen = [], set()
    while True:
        require(current.parent in allowed and current.name in aliases and current not in seen,
                'interpreter alias leaves the selected application/base interpreter paths')
        seen.add(current)
        _metadata(current.parent, directory=True)
        info = current.lstat()
        if not stat.S_ISLNK(info.st_mode):
            break
        require(len(links) < 8 and info.st_uid in (0, os.geteuid()), 'unsupported interpreter alias chain')
        target = os.readlink(current)
        links.append(dict(path=str(current), target=target,
            identity=[info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
                      info.st_size, info.st_mtime_ns, info.st_ctime_ns]))
        current = _absolute(target) if Path(target).is_absolute() else Path(os.path.abspath(current.parent / target))
    return dict(path=str(selected), resolved=str(current), links=links, target=_metadata(current))


def _same_interpreter(row):
    for link in row['links']:
        info = Path(link['path']).lstat()
        observed = [info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
                    info.st_size, info.st_mtime_ns, info.st_ctime_ns]
        if not stat.S_ISLNK(info.st_mode) or observed != link['identity'] or os.readlink(link['path']) != link['target']:
            return False
    return (str(Path(row['path']).resolve(strict=True)) == row['resolved']
            and _metadata(row['resolved']) == row['target'])


def _runtime_inputs(application):
    config = application / 'pyvenv.cfg'
    _metadata(config)
    raw = config.read_text(encoding='utf-8')
    require(len(raw) <= 16384, 'venv configuration exceeds the desktop metadata bound')
    values = dict(line.split(' = ', 1) for line in raw.splitlines() if ' = ' in line)
    base = _absolute(values.get('home', '')).parent
    version = values.get('version', '')
    require(re.fullmatch(r'3\.11\.[0-9]+', version), 'desktop capability requires the selected CPython 3.11 venv')
    roots = []
    for parent in (base / 'lib', base / 'share/tcltk'):
        if not parent.is_dir():
            continue
        for item in sorted(parent.iterdir()):
            if not re.fullmatch(r'(?:tcl|tk)[89](?:\.[0-9]+)?', item.name) or not item.is_dir():
                continue
            marker = 'init.tcl' if item.name.startswith('tcl') else 'tk.tcl'
            if re.fullmatch(r'tcl[89]', item.name) or (item / marker).is_file():
                _metadata(item, directory=True)
                roots.append(item)
    require(roots, 'no ordinary Tcl/Tk resource roots were found in the selected runtime')
    files, directories = {}, {}
    for root in roots:
        for current, names, members in os.walk(root, followlinks=False):
            names.sort()
            current = Path(current)
            directories[str(current)] = _metadata(current, directory=True)
            for name in sorted(members):
                path = current / name
                files[str(path)] = _metadata(path, resource_roots=roots)
                require(len(files) <= MAX_RESOURCES, 'Tcl/Tk resource inventory exceeds its bound')
            for name in names:
                _metadata(current / name, directory=True)
    stdlib = base / 'lib/python3.11'
    extensions = sorted((stdlib / 'lib-dynload').glob('_tkinter.*.so'))
    if not extensions and base == Path('/usr'):
        extensions = sorted(Path('/usr/lib/python3.11/lib-dynload').glob('_tkinter.*.so'))
    require(len(extensions) == 1, 'selected runtime must contain one unambiguous _tkinter extension')
    return dict(base=str(base), version=version, resources=files, resource_directories=directories,
        resource_roots=[str(path) for path in roots], extension=_metadata(extensions[0], runtime_role='tkinter-extension'),
        tkinter=_metadata(stdlib / 'tkinter/__init__.py', runtime_role='tkinter-source'), venv=_metadata(config))


_TCL86_MODULE_ROOTS_PROFILE = r'''
proc ::tcl::tm::roots {paths} {
regexp {^(\d+)\.(\d+)} [package provide Tcl] - major minor
foreach pa $paths {
set p [file join $pa tcl$major]
for {set n $minor} {$n >= 0} {incr n -1} {
set px [file join $p ${major}.${n}]
if {![interp issafe]} {set px [file normalize $px]}
path add $px
}
set px [file join $p site-tcl]
if {![interp issafe]} {set px [file normalize $px]}
path add $px
}
return
}
if {![interp issafe]} {::tcl::tm::Defaults}
if {![interp issafe]} { ::tcl::tm::roots {/usr/lib/tcltk /usr/share/tcltk} }
'''.strip()


def _module_distribution_roots(runtime, library, version):
    path = str(Path(library) / 'tm.tcl')
    if (version != '8.6' or Path(library).name != 'tcl8.6'
            or library not in runtime['resource_roots'] or path not in runtime['resources']
            or str(Path(library) / 'init.tcl') not in runtime['resources']):
        return ()
    source = _startup_script(runtime['resources'][path], runtime)['source_utf8']
    lines = [line.strip() for line in source.splitlines() if line.strip() and not line.lstrip().startswith('#')]
    profile = '\n'.join(lines)
    if (profile.endswith(_TCL86_MODULE_ROOTS_PROFILE)
            and profile.count('proc ::tcl::tm::roots {paths} {') == 1
            and profile.count('::tcl::tm::roots {/usr/lib/tcltk /usr/share/tcltk}') == 1):
        return ('/usr/lib/tcltk', '/usr/share/tcltk')
    return ()


def _module_candidates(library, executable, version, runtime):
    match = re.fullmatch(r'([89])\.([0-9])', version)
    require(match is not None, 'unsupported Tcl module default version')
    major, minor = match[1], int(match[2])
    roots = {Path(library).parent, Path(executable).parent.parent / 'lib',
             *map(Path, _module_distribution_roots(runtime, library, version))}
    return {str(root / ('tcl' + major) / suffix) for root in roots
            for suffix in ([major + '.' + str(number) for number in range(minor, -1, -1)] + ['site-tcl'])}


def _missing(path):
    try:
        Path(path).lstat()
    except FileNotFoundError as error:
        require(error.errno == errno.ENOENT and str(error.filename) == str(path),
                'module absence requires an exact ENOENT result')
        return True
    return False


def _stable_directory(path):
    path = _absolute(path)
    info = path.lstat()
    require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode),
            'module metadata ancestor must be an ordinary directory')
    return dict(path=str(path), identity=[info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid])


def _module_metadata(runtime, application):
    candidates = set()
    for library in runtime['resource_roots']:
        match = re.fullmatch(r'tcl([89]\.[0-9])', Path(library).name)
        if match is not None and str(Path(library) / 'init.tcl') in runtime['resources']:
            for executable in (application / 'bin/python', Path(runtime['base']) / 'bin/python'):
                candidates.update(_module_candidates(library, executable, match[1], runtime))
    require(len(candidates) <= 64, 'Tcl module metadata table exceeds its bound')
    rows = {}
    for path in sorted(candidates):
        if not _missing(path):
            require(path in runtime['resource_directories'] and _same_metadata(
                runtime['resource_directories'][path], directory=True),
                'existing default module root is outside current bound resources')
            rows[path] = dict(path=path, kind='resource',
                              ancestors=[_stable_directory(item) for item in Path(path).parents])
            continue
        missing, current = [path], Path(path).parent
        while _missing(current):
            missing.append(str(current))
            current = current.parent
        rows[path] = dict(path=path, kind='absence', missing=missing,
                          ancestors=[_stable_directory(item) for item in (current, *current.parents)])
    return rows


def _same_module_metadata(row, runtime):
    try:
        if row['kind'] == 'resource':
            return row['path'] in runtime['resource_directories'] and _same_metadata(
                runtime['resource_directories'][row['path']], directory=True) and (
                row['ancestors'] == [_stable_directory(item) for item in Path(row['path']).parents])
        missing, ancestors = row['missing'], row['ancestors']
        return (row['kind'] == 'absence' and bool(missing) and bool(ancestors) and missing[0] == row['path']
                and all(str(Path(child).parent) == parent for child, parent in zip(missing, missing[1:]))
                and str(Path(missing[-1]).parent) == ancestors[0]['path']
                and all(str(Path(child['path']).parent) == parent['path'] for child, parent in zip(ancestors, ancestors[1:]))
                and ancestors[-1]['path'] == '/'
                and all(_missing(path) for path in row['missing'])
                and all(_stable_directory(item['path']) == item for item in row['ancestors']))
    except (OSError, DesktopBlocked, KeyError, TypeError, ValueError):
        return False


def _catalog_metadata(runtime):
    rows = {}
    for root in runtime['resource_roots']:
        if str(Path(root) / 'tk.tcl') not in runtime['resources']:
            continue
        folder = str(Path(root) / 'msgs')
        if not _missing(folder):
            require(folder in runtime['resource_directories'] and _same_metadata(
                runtime['resource_directories'][folder], directory=True), 'Tk catalog folder is not a current bound resource')
            continue
        for name in ('c.msg', 'ROOT.msg'):
            path = str(Path(folder) / name)
            require(_missing(path), 'expected absent C catalog appeared during selection')
            missing, current = [path], Path(path).parent
            while _missing(current):
                missing.append(str(current))
                current = current.parent
            rows[path] = dict(path=path, kind='absence', missing=missing,
                              ancestors=[_stable_directory(item) for item in (current, *current.parents)])
    require(len(rows) <= 8, 'Tk C catalog metadata table exceeds its bound')
    return rows


def select_from_environment(application, scratch, console_script=None, *, owned_host_fixture=False):
    """Inspect only the current selected desktop, without connecting or reading cookies."""
    application, scratch = _absolute(application), _absolute(scratch)
    _metadata(application, directory=True)
    _metadata(scratch, directory=True)
    info = scratch.stat()
    require(info.st_uid == os.geteuid() and stat.S_IMODE(info.st_mode) == 0o700,
            'native scratch must be private and owned by the current user')
    original = os.environ.get('DISPLAY')
    require(isinstance(original, str),
            'current operator DISPLAY is absent; no display was guessed or started')
    match = DISPLAY.fullmatch(original)
    require(match is not None, 'only the explicitly selected local Unix DISPLAY is supported')
    number, screen = match.groups()
    require(int(number) <= 65535, 'selected local display number is outside the supported bound')
    selected = 'unix/:' + number + ('.' + screen if screen is not None else '')
    authority_path = os.environ.get('XAUTHORITY')
    authority_source = 'explicit XAUTHORITY'
    if authority_path is None:
        authority_source = 'current HOME/.Xauthority'
        previous_home = os.environ.get('HOME')
        candidate = _absolute(previous_home) / '.Xauthority' if previous_home else None
        authority_path = str(candidate) if candidate is not None and candidate.exists() else None
    authority = _metadata(authority_path, authority=True) if authority_path is not None else None
    runtime = _runtime_inputs(application)
    require(type(owned_host_fixture) is bool, 'owned host fixture selection must be explicit')
    if owned_host_fixture:
        require(sys.platform == 'linux' and sys.version_info[:3] == (3, 11, 16)
                and runtime['version'] == '3.11.16'
                and sysconfig.get_config_var('SOABI') == 'cpython-311-x86_64-linux-gnu'
                and str(Path(runtime['base']) / 'lib/tk9.0/tk.tcl') in runtime['resources'],
                'owned host display fixture requires the selected Linux CPython3.11.16/Tk9 runtime')
    interpreter = _interpreter_metadata(application / 'bin/python', application, Path(runtime['base']))
    console = _metadata(_absolute(console_script) if console_script is not None
                        else application / 'bin/satgs-operator-gui')
    require(Path(console['path']).parent == application / 'bin', 'GUI console origin is outside selected application')
    console_raw = Path(console['path']).read_text(encoding='utf-8')
    require(len(console_raw) <= 16384, 'GUI console entrypoint exceeds its bound')
    first = console_raw.splitlines()[0] if console_raw.splitlines() else ''
    require(first.startswith('#!') and not any(character.isspace() for character in first[2:]),
            'GUI console must select one explicit application interpreter')
    console_interpreter = _interpreter_metadata(first[2:], application, Path(runtime['base']))
    require(Path(console_interpreter['path']).parent == application / 'bin',
            'GUI console interpreter is outside the selected application')
    same_file = os.path.samefile(interpreter['resolved'], console_interpreter['resolved'])
    if not same_file:
        require(interpreter['target']['identity'][5] <= 64 * 1024 * 1024
                and console_interpreter['target']['identity'][5] <= 64 * 1024 * 1024,
                'selected interpreter image exceeds the compatibility comparison bound')
        require(Path(interpreter['resolved']).read_bytes() == Path(console_interpreter['resolved']).read_bytes(),
                'GUI console selects a distinct interpreter image whose runtime compatibility is not established')
    require(_same_interpreter(interpreter) and _same_interpreter(console_interpreter),
            'selected interpreter alias changed during compatibility inspection')
    console_tree = ast.parse(console_raw, filename=console['path'])
    require(any(isinstance(node, ast.ImportFrom) and node.module == 'satgs.operator_gui'
                and any(alias.name == 'main' for alias in node.names) for node in ast.walk(console_tree)),
            'GUI console entrypoint does not import the installed operator GUI')
    for name in ('desktop-home', 'desktop-tmp'):
        require(not os.path.lexists(scratch / name), 'desktop HOME/TMPDIR must be fresh')
        (scratch / name).mkdir(mode=0o700)
    return dict(schema=SCHEMA, application=str(application), scratch=str(scratch),
        original_display=original, display=selected, transport='explicit Xlib unix transport; no TCP fallback',
        authority=authority, authority_source=authority_source if authority else 'no selected authority file',
        authority_policy='support Python never reads/copies/hashes/logs/archives cookie contents; native Xlib may read the exact selected authority',
        home=str(scratch / 'desktop-home'), tmpdir=str(scratch / 'desktop-tmp'),
        interpreter=interpreter, console=console, console_interpreter=console_interpreter,
        console_interpreter_comparison='same current file' if same_file else 'same current executable image; no historical byte identity claim',
        owned_host_fixture=HOST_FIXTURE_LABEL if owned_host_fixture else None,
        runtime=runtime,
        module_metadata=_module_metadata(runtime, application),
        catalog_metadata=_catalog_metadata(runtime),
        metadata_read_paths=[str(application / 'pyvenv.cfg'), interpreter['resolved'], console_interpreter['resolved'], console['path'],
                             runtime['extension']['path'], runtime['tkinter']['path'], '/proc/self/maps'],
        resource_files=sorted(runtime['resources']), resource_directories=sorted(runtime['resource_directories']),
        runtime_comparison='r3 stripped DISPLAY; this lane preserves only the current explicitly selected local desktop',
        trust_limit='source-controlled Python; native Tcl_Init and Tk/Xlib internals trusted; no hostile introspection or syscall isolation')


def child_environment(base, descriptor):
    require(descriptor.get('schema') == SCHEMA, 'unsupported desktop descriptor')
    environment = dict(base)
    for name in tuple(environment):
        if re.fullmatch(r'TCL[89](?:\.[0-9]+|_[0-9]+)_TM_PATH', name):
            environment.pop(name)
    for name in ('DISPLAY', 'XAUTHORITY', 'HOME', 'TMPDIR', 'TCL_LIBRARY', 'TK_LIBRARY',
                 'TCLLIBPATH', 'XENVIRONMENT', 'XAPPLRESDIR', 'SESSION_MANAGER', 'DBUS_SESSION_BUS_ADDRESS'):
        environment.pop(name, None)
    environment.update(DISPLAY=descriptor['display'], HOME=descriptor['home'], TMPDIR=descriptor['tmpdir'])
    if descriptor['authority'] is not None:
        environment['XAUTHORITY'] = descriptor['authority']['path']
    return environment


def _same_metadata(row, *, directory=False, authority=False, resource_roots=(), runtime_role=None):
    return _metadata(row['path'], directory=directory, authority=authority,
                     resource_roots=resource_roots, runtime_role=runtime_role) == row


def _loaded_native_origins():
    with open('/proc/self/maps', 'r', encoding='ascii') as stream:
        raw = stream.read(1024 * 1024 + 1)
    require(len(raw) <= 1024 * 1024, 'own-process native map evidence exceeds its bound')
    origins = {}
    for line in raw.splitlines():
        values = line.split(maxsplit=5)
        if len(values) != 6 or not values[5].startswith('/'):
            continue
        path = values[5]
        if NATIVE_NAMES.match(Path(path).name) is None:
            continue
        require(not path.endswith(' (deleted)'), 'a loaded native runtime object was deleted')
        origins[path] = dict(path=path, device=values[3], inode=values[4])
    return [origins[path] for path in sorted(origins)]


def _validate_native_origins(rows, descriptor):
    extension = descriptor['runtime']['extension']['path']
    require(any(row['path'] == extension for row in rows), 'selected native extension is absent from actual loaded origins')
    base = Path(descriptor['runtime']['base'])
    for row in rows:
        path = Path(row['path'])
        require(any(path.is_relative_to(root) for root in
                    (base / 'lib', base / 'lib64', Path('/usr/lib'), Path('/usr/lib64'))),
                'loaded Tcl/Tk/Xlib/Python object origin is outside the selected base or ordinary system libraries')
        metadata = _metadata(path, runtime_role='loaded-native')
        major, minor = (int(value, 16) for value in row['device'].split(':', 1))
        device, inode = metadata['identity'][:2]
        require(os.major(device) == major and os.minor(device) == minor and inode == int(row['inode']),
                'loaded native object no longer matches its actual mapped file identity')
        row['identity'] = metadata['identity']
        if 'permission_basis' in metadata:
            row['permission_basis'] = metadata['permission_basis']
    return rows


def _restore_native_environment(interpreter, key):
    original = interpreter.owner.environment_snapshot
    if key in original:
        os.putenv(key, original[key])
    else:
        os.unsetenv(key)


class _InterpreterControl:
    def __init__(self, owner, app, root):
        self.owner, self.app, self.root = owner, app, root
        self.callbacks, self.guarded, self.channels = {}, {}, set()
        self.permission = None
        self.bootstrap = True
        self.tk_initialization = None
        self.tk_load_frame = None
        self.tk_init_renamed = False
        self.expected_retirements = []
        self.root_destruction = dict(status='NOTRUN', attempts=0,
                                     genuine_destroy_returned=False, root_command_absent=False,
                                     live_trace_verification='NOTRUN', trace_rearm=dict(status='NOTRUN'))
        self.cleanup = dict(status='NOTRUN', stage='NOTRUN', root_destruction=self.root_destruction)
        self.alias_used, self.rename_used = False, set()
        self.probe_phase = False
        self.closed = False
        self.trace_token = os.urandom(24).hex()
        self.pending = {}
        self.alias_dispatch = None
        self.ensemble_dispatch = None
        self.ensemble_operation = None
        self.ensemble_used, self.ensemble_maps, self.ensemble_receipts = set(), {}, []
        self.force_import_dispatch = self.force_import_operation = None
        self.force_import_used, self.force_import_receipts = False, []
        self.module_metadata_events = []
        self.catalog_metadata_events = []
        self.tcl_library = str(app.call('info', 'library'))
        self.tcl_executable = str(app.call('info', 'nameofexecutable'))
        interpreter = owner.descriptor['interpreter']
        require(self.tcl_executable in (interpreter['path'], interpreter['resolved']) and _same_interpreter(interpreter),
                'actual Tcl executable does not identify the bound selected interpreter')
        normalized = str(Path(self.tcl_executable).resolve(strict=True))
        require(normalized == interpreter['resolved'], 'actual Tcl executable resolves outside the selected interpreter')
        self.module_candidates = _module_candidates(self.tcl_library, normalized, owner.native.TCL_VERSION,
                                                    owner.descriptor['runtime'])
        require(self.module_candidates <= set(owner.descriptor['module_metadata']),
                'actual Tcl module defaults exceed the selected metadata table')
        self.verify_module_metadata()
        self.verify_catalog_metadata()
        values = tuple(map(str, app.splitlist(app.call('array', 'get', '::env'))))
        self.native_environment = dict(zip(values[::2], values[1::2]))
        require(self.native_environment == owner.environment_snapshot,
                'initial native environment differs from the fixed child environment')
        self.restoring_environment = False
        self.environment_restoration = None
        self.app.call('namespace', 'eval', CONTROL_NAMESPACE, '')
        self._scan()
        environment_callback = CONTROL_NAMESPACE + '::environment'

        def environment_trace(token, name, element, operation):
            token, name, element, operation = map(str, (token, name, element, operation))
            if token != self.trace_token:
                self.deny('forged-native-environment-callback')
            if self.restoring_environment:
                return ''
            if not element:
                self.deny('native-environment-array-unset')
            self.restoring_environment = True
            self.environment_restoration = (sys._getframe(), element)
            try:
                _restore_native_environment(self, element)
                variable = '::env(' + element + ')'
                if element in self.native_environment:
                    self._internal('set', (variable, self.native_environment[element]), 'set')
                else:
                    self._internal('unset', ('-nocomplain', variable), 'unset')
            finally:
                self.environment_restoration = None
                self.restoring_environment = False
            self.deny('native-process-environment-change')

        self.app.createcommand(environment_callback, environment_trace)
        self.environment_callback = environment_trace
        self.callbacks[environment_callback] = environment_trace
        self._internal('trace', ('add', 'variable', '::env', ('write', 'unset'),
                                (environment_callback, self.trace_token)), 'trace')
        runtime = owner.descriptor['runtime']
        self.autoload_paths = tuple(root for root in runtime['resource_roots']
                                    if str(Path(root) / 'tclIndex') in runtime['resources'])
        require(self.autoload_paths, 'selected Tcl runtime has no bound autoload index roots')
        self.app.setvar('auto_path', self.autoload_paths)

    def deny(self, category, diagnostic=None):
        self.owner._deny(category, 'negative' if self.probe_phase else 'functional', diagnostic=diagnostic)

    def _commands(self):
        pending, commands, count = ['::'], set(), 0
        while pending:
            namespace = pending.pop()
            commands.update(map(str, self.app.splitlist(self.app.call('info', 'commands', namespace.rstrip(':') + '::*'))))
            pending.extend(map(str, self.app.splitlist(self.app.call('namespace', 'children', namespace))))
            count += 1
            require(count <= 2048 and len(commands) <= 32768, 'native command inventory exceeds its bound')
        return commands

    def _category(self, name):
        tail = name.rsplit('::', 1)[-1]
        if name.startswith(('::tcl::unsupported::', '::tk::unsupported::')):
            return 'denied:' + tail
        if name in ('::tk::print', '::tk::systray', '::tk::sysnotify') or name.startswith(
                ('::tk::print::', '::tk::systray::', '::tk::sysnotify::')):
            return 'denied:tk-session'
        if name.startswith('::tcl::zipfs::'):
            return 'denied:zipfs'
        if name.startswith('::tcl::file::'):
            return 'file:' + tail
        if name.startswith('::tcl::chan::'):
            return 'channel:' + tail
        for prefix in ('interp', 'trace', 'namespace', 'encoding', 'array'):
            if name.startswith('::tcl::' + prefix + '::'):
                return prefix + ':' + tail
        if name in ('::tcl::set', '::tcl::unset', '::tcl::upvar'):
            return tail
        if name.lstrip(':').startswith('.'):
            return 'widget'
        if name.startswith('::ttk::') and tail in CREATORS | {'combobox', 'notebook', 'progressbar', 'separator', 'sizegrip', 'treeview'}:
            return 'creator'
        if name.count('::') != 1:
            return None
        if tail in DENIED:
            return 'denied:' + tail
        if tail in CHANNEL_COMMANDS:
            return 'channel:' + tail
        if tail in CREATORS:
            return 'creator'
        if tail in ('source', 'open', 'file', 'glob', 'trace', 'interp', 'rename',
                    'proc', 'namespace', 'chan', 'encoding', 'image', 'option',
                    'wm', 'winfo', 'focus', 'grab', 'event', 'tk', 'destroy', 'set', 'unset', 'array', 'upvar'):
            return tail
        return None

    def _scan(self):
        for name in sorted(self._commands()):
            category = self._category(name)
            if category is not None and name not in self.guarded:
                self._attach(name, category)

    def verify_traces(self, *, refresh_exit=False, final=False, teardown=False):
        root_absent = False
        issue_count, issues = 0, []
        if teardown:
            frame = sys._getframe(1)
            parent = frame.f_back
            if (final or refresh_exit or frame.f_code is not _InterpreterControl._rearm_destroy_traces.__code__
                    or frame.f_globals is not globals() or frame.f_locals.get('self') is not self
                    or parent is None or parent.f_code is not self.owner.destroy_wrapper_code
                    or parent.f_globals is not globals() or parent.f_locals.get('self') is not self.owner
                    or parent.f_locals.get('control') is not self or parent.f_locals.get('root') is not self.root
                    or self.root.tk is not self.app or self.root._w != '.'
                    or threading.get_ident() != self.owner.thread or self.owner.finished or self.closed
                    or self.root_destruction['live_trace_verification'] != 'PASS'
                    or not self._root_retired()):
                self.deny('unauthenticated-native-teardown-verification')
            self.owner._verify_bindings()
            root_absent = True
        elif final:
            frame = sys._getframe(1)
            require(frame.f_code is _InterpreterControl.finish.__code__
                    and frame.f_globals is globals() and frame.f_locals.get('self') is self,
                    'native final trace verification requires its original cleanup owner')
            root_absent = self._root_retired()
        for name, (category, callback, operations) in tuple(self.guarded.items()):
            if not self.app.call('info', 'commands', name):
                if name == '::exit' and category == 'denied:exit' and root_absent:
                    if final and name not in self.expected_retirements:
                        self.expected_retirements.append(name)
                    continue
                if category not in ('widget', 'image-instance'):
                    if not final and not teardown:
                        require(False, 'a protected native command disappeared')
                    issue_count += 1
                    if len(issues) < 64:
                        issues.append(dict(name=name[:256], category=category[:80],
                                           present=False, expected_trace_present=False))
                continue
            traces = self._internal('trace', ('info', 'execution', name), 'trace')
            expected = (callback, self.trace_token)
            present = any(tuple(map(str, self.app.splitlist(self.app.splitlist(row)[1]))) == expected
                          for row in self.app.splitlist(traces))
            if not present and refresh_exit and name == '::exit':
                self._attach(name, category)
            elif not present:
                if not final and not teardown:
                    require(False, 'a native effect trace was removed or replaced')
                issue_count += 1
                if len(issues) < 64:
                    issues.append(dict(name=name[:256], category=category[:80],
                                       present=True, expected_trace_present=False))
        if final:
            self.cleanup['protected_trace_issue_count'] = issue_count
            self.cleanup['protected_trace_issues'] = issues
            require(not issue_count, 'a protected native command or effect trace disappeared')
        if teardown:
            return issue_count, issues

    def _rearm_destroy_traces(self):
        count, issues = self.verify_traces(teardown=True)
        receipt = self.root_destruction['trace_rearm']
        require(receipt['status'] == 'NOTRUN', 'native teardown traces may be rearmed only once')
        receipt.update(status='INITIALIZING', issue_count_before=count, issues_before=issues, rearmed=[])
        require(_tk_teardown_issues_supported(count, issues),
                'native teardown changed a command outside the finite Tk lifecycle set')
        for row in issues:
            self._attach(row['name'], row['category'])
            receipt['rearmed'].append(dict(name=row['name'], category=row['category']))
        count, issues = self.verify_traces(teardown=True)
        receipt['issue_count_after'] = count
        receipt['issues_after'] = issues
        require(not count, 'a protected native trace remained absent after finite Tk teardown rearm')
        receipt['status'] = 'PASS'

    def _root_retired(self):
        return (self.tk_initialization is not None and self.tk_initialization['status'] == 'PASS'
                and self.root_destruction['status'] == 'PASS'
                and self.root_destruction['attempts'] == 1
                and self.root_destruction['genuine_destroy_returned']
                and self.root_destruction['root_command_absent']
                and not self.app.call('info', 'commands', '.'))

    def _attach(self, name, category):
        name = name if name.startswith('::') else '::' + name
        callback_name = CONTROL_NAMESPACE + '::c' + str(len(self.callbacks))

        def callback(*arguments):
            self.owner._verify_bindings()
            arguments = tuple(map(str, arguments))
            if not arguments or arguments[0] != self.trace_token:
                self.deny('forged-command-trace-callback')
            arguments = arguments[1:]
            if len(arguments) not in (2, 4) or arguments[-1] not in ('enter', 'leave'):
                self.deny('malformed-command-trace-callback')
            command_values = self.app.splitlist(arguments[0])
            command = tuple(map(str, command_values))
            if arguments[-1] == 'leave':
                if (category == 'namespace' and command[1:2] != ('ensemble',)
                        and command[1:3] != ('import', '-force')):
                    return ''
                if self.pending.pop(callback_name, None) != command:
                    self.deny('unpaired-command-trace-leave')
                if int(arguments[1]) == 0 and category == 'open':
                    result = str(arguments[2])
                    if not re.fullmatch(r'file[0-9]+', result):
                        self.deny('nonfile-read-channel')
                    self.channels.add(result)
                elif category == 'interp':
                    self.alias_dispatch = None
                elif category == 'namespace':
                    if command[1:2] == ('ensemble',):
                        operation = self.ensemble_operation
                        self.ensemble_operation = self.ensemble_dispatch = None
                        if operation is not None and int(arguments[1]) == 0:
                            source, namespace, action = operation
                            if action == 'query':
                                self.ensemble_maps[source] = self._ensemble_map(arguments[2])
                            self.ensemble_receipts.append(dict(source=source, namespace=namespace, action=action))
                    else:
                        operation = self.force_import_operation
                        self.force_import_operation = self.force_import_dispatch = None
                        if operation is not None and int(arguments[1]) == 0:
                            source, namespace, origins = operation
                            for target, origin in origins.items():
                                if str(self.app.call('namespace', 'origin', '::tk::print::' + target)) != origin:
                                    self.deny('native-force-import-origin')
                            self.force_import_receipts.append(dict(source=source, namespace=namespace, origins=origins))
                elif (category == 'channel:close' or category == 'chan' and command[1:2] == ('close',)) and int(arguments[1]) == 0:
                    values = command[2:] if category == 'chan' else command[1:]
                    if values:
                        self.channels.discard(values[0])
                elif int(arguments[1]) == 0 and category in ('creator', 'image'):
                    result = str(arguments[2])
                    canonical = result if result.startswith('::') else '::' + result
                    if canonical in self.guarded:
                        return ''
                    if category == 'creator' and self._owned(result):
                        self._attach(result, 'widget')
                        if '#' in result:
                            require(len(result) <= 256 and len(self.owner.observations) < 256,
                                    'owned menu clone observation exceeds its bound')
                            self.owner.observations.append(dict(kind='owned-menu-clone', target=result,
                                widget_trace_present=canonical in self.guarded))
                    elif category == 'image' and len(command) > 1 and command[1] == 'create':
                        self._attach(result, 'image-instance')
                return ''
            permit = self.permission
            if permit is not None:
                frame = sys._getframe(1)
                if (permit and permit[0][0] == category and permit[0][1] == command[1:]
                        and frame.f_code is _InterpreterControl._internal.__code__
                        and frame.f_globals is globals() and frame.f_locals.get('self') is self):
                    permit.pop(0)
                    if not permit:
                        self.permission = None
                    return ''
                diagnostic = None
                if self.owner.internal_diagnostic_count < 16:
                    self.owner.internal_diagnostic_count += 1
                    diagnostic = dict(native_command=name[:160], actual_category=category[:80],
                        actual_argument_count=len(command) - 1, guarded_commands=len(self.guarded),
                        actual_argument_types=[type(value).__name__[:32] for value in command_values[1:9]],
                        caller_code_matches=frame.f_code is _InterpreterControl._internal.__code__,
                        caller_namespace_matches=frame.f_globals is globals(),
                        caller_self_matches=frame.f_locals.get('self') is self,
                        expected=[dict(category=expected_category[:80], argument_count=len(expected_args),
                            argument_count_matches=len(expected_args) == len(command) - 1,
                            arguments_match=expected_args == command[1:],
                            per_argument_equal=[left == right for left, right in zip(expected_args[:8], command[1:9])])
                            for expected_category, expected_args in permit[:8]])
                self.deny('internal-token-mismatch', diagnostic=diagnostic)
            if category == 'interp:alias' and self.alias_dispatch == ('alias', *command[1:]):
                self.alias_dispatch = None
            elif category == 'namespace:ensemble' and self.ensemble_dispatch == ('ensemble', *command[1:]):
                self.ensemble_dispatch = None
            elif category == 'namespace:import' and self.force_import_dispatch == ('import', *command[1:]):
                self.force_import_dispatch = None
            else:
                self._validate(category, command[1:])
            if category == 'wm' and command[1:3] == ('protocol', '.'):
                self.verify_traces(refresh_exit=True)
            if (category in ('creator', 'image', 'open', 'interp', 'channel:close', 'chan')
                    or category == 'namespace' and (command[1:2] == ('ensemble',)
                                                   or command[1:3] == ('import', '-force'))):
                if callback_name in self.pending:
                    self.deny('reentrant-command-trace-enter')
                self.pending[callback_name] = command
            return ''

        self.app.createcommand(callback_name, callback)
        self.callbacks[callback_name] = callback
        operations = ('enter', 'leave') if category in ('creator', 'image', 'open', 'interp', 'channel:close', 'chan', 'namespace') else ('enter',)
        self._internal('trace', ('add', 'execution', name, operations,
                                (callback_name, self.trace_token)), 'trace')
        self.guarded[name] = (category, callback_name, operations)

    def _internal(self, name, arguments, category):
        require(self.permission is None, 'nested native control token')
        present = {row[0] for row in self.guarded.values()}
        nested_category = category + ':' + str(arguments[0]) if arguments else None
        if category in present or nested_category in present:
            canonical = tuple(self._tcl_text(value) for value in arguments)
            self.permission = []
            if category in present:
                self.permission.append((category, canonical))
            if nested_category in present:
                self.permission.append((nested_category, canonical[1:]))
        try:
            return self.app.call(name, *arguments)
        finally:
            self.permission = None

    def _tcl_text(self, value):
        encoded = self.app.call('encoding', 'convertto', 'utf-8', value)
        require(type(encoded) is bytes, 'native Tcl UTF-8 conversion did not return a bytearray value')
        return encoded.decode('utf-8', 'strict')

    def initialize_tk(self):
        self.owner._verify_bindings()
        require(self.bootstrap and self.tk_initialization is None
                and threading.get_ident() == self.owner.thread,
                'Tk bootstrap is not a one-shot control-owned operation')
        require(not self.app.call('package', 'provide', 'Tk')
                and str(self.app.call('info', 'exists', 'tk_version')) == '0',
                'Tk was initialized outside the controlled bootstrap')
        names = TK_NATIVE_NAMES.get(self.owner.native.TK_VERSION)
        require(names is not None, 'Tk native library version has no supported bootstrap binding')
        runtime = self.owner.descriptor['runtime']
        libraries = [root for root in runtime['resource_roots']
                     if Path(root).name == 'tk' + self.owner.native.TK_VERSION
                     and str(Path(root) / 'tk.tcl') in runtime['resources']]
        require(len(libraries) == 1, 'Tk bootstrap requires one bound script root matching the extension ABI')
        library = libraries[0]
        script = runtime['resources'][str(Path(library) / 'tk.tcl')]
        require(_same_metadata(script, resource_roots=runtime['resource_roots'])
                and _same_metadata(runtime['resource_directories'][library], directory=True),
                'selected Tk bootstrap script/root identity changed')
        if str(self.app.call('info', 'exists', 'tk_library')) == '1':
            require(str(self.app.getvar('tk_library')) == library, 'existing Tk script root differs from selected resources')
        self.app.setvar('tk_library', library)
        adjustment = None
        if self.owner.descriptor.get('owned_host_fixture') == HOST_FIXTURE_LABEL:
            require(self.owner.native.TK_VERSION == '9.0' and sys.platform == 'linux'
                    and sys.version_info[:3] == (3, 11, 16)
                    and sysconfig.get_config_var('SOABI') == 'cpython-311-x86_64-linux-gnu',
                    'owned host fixture adjustment is unsupported on this actual Tk/interpreter')
            self.app.call('namespace', 'eval', '::tk', '')
            self.app.setvar('::tk::doneScalingInitX11', 1)
            adjustment = 'owned fixture only: skip external desktop scaling discovery; actual Tk scaling unchanged; no font/HiDPI qualification'
        origins = _validate_native_origins(_loaded_native_origins(), self.owner.descriptor)
        selected = [row for row in origins if Path(row['path']).name in names]
        require(len(selected) == 1, 'Tk bootstrap requires exactly one already-mapped compatible Tk object')
        origin = selected[0]
        metadata = _metadata(origin['path'], runtime_role='loaded-native')
        require(metadata['identity'] == origin['identity'], 'Tk bootstrap object changed after mapped-origin validation')
        self.tk_initialization = dict(path=origin['path'], identity=origin['identity'],
                                     entry='Tkapp.call/load', package='Tk', count=1, status='INITIALIZING',
                                     tkInit_cleanup_count=0, tk_library=library, auto_path=self.autoload_paths,
                                     host_fixture_adjustment=adjustment, ensemble_bootstrap=self.ensemble_receipts,
                                     force_import_bootstrap=self.force_import_receipts,
                                     expected_retirements=self.expected_retirements,
                                     cleanup=self.cleanup,
                                     module_metadata_events=self.module_metadata_events,
                                     catalog_metadata_events=self.catalog_metadata_events)
        # loadtk() lacks the Tcl callback thread-state boundary on the selected
        # runtime. The normal call path initializes the already-linked object.
        self.tk_load_frame = sys._getframe()
        try:
            self._internal('load', (origin['path'], 'Tk'), 'denied:load')
        except self.owner.native.TclError:
            self.tk_initialization['status'] = 'FAIL'
            self.tk_initialization['failure'] = self._initialization_failure()
            raise
        finally:
            self.tk_load_frame = None
        version = str(self.app.call('package', 'provide', 'Tk'))
        require(version == str(self.app.getvar('tk_patchLevel'))
                and str(self.app.getvar('tk_version')) == self.owner.native.TK_VERSION,
                'controlled Tk package differs from the actual extension ABI/version')
        require(_same_metadata(metadata, runtime_role='loaded-native'),
                'Tk bootstrap object identity changed in flight')
        require(str(self.app.getvar('tk_library')) == library
                and _same_metadata(script, resource_roots=runtime['resource_roots']),
                'actual Tk script root/bootstrap script differs after initialization')
        self.tk_initialization['version'] = version
        self.tk_initialization['status'] = 'PASS'

    def finish_bootstrap(self):
        require(self.bootstrap and self.tk_load_frame is None and self.permission is None
                and not self.pending and self.ensemble_operation is None and self.force_import_operation is None,
                'native bootstrap ended with an active operation')
        self.verify_module_metadata()
        self.verify_catalog_metadata()
        self.alias_dispatch = self.ensemble_dispatch = self.force_import_dispatch = None
        self.bootstrap = False
        self.tk_initialization['forward_markers_expired'] = True

    def _initialization_failure(self):
        try:
            code = self.app.splitlist(self.app.getvar('errorCode'))
        except self.owner.native.TclError:
            code = ()
        public = set(self.guarded) | {name.removeprefix('::') for name in self.guarded}
        public.update(('auto_path', 'tcl_library', 'tk_library', 'tcl_pkgPath'))
        private = set(self.owner.environment_snapshot.values()) | {app.trace_token for app in self.owner.apps}
        fields = []
        for index, value in enumerate(code[:16]):
            text = str(value)
            if (text not in private and (index < 3 and re.fullmatch(r'[A-Z_]{1,80}', text)
                    or index >= 3 and text in public and len(text) <= 160)):
                fields.append(dict(value=text))
            else:
                fields.append(dict(redacted=True, type=type(value).__name__, length=len(text)))
        try:
            information = str(self.app.getvar('errorInfo'))
        except self.owner.native.TclError:
            information = ''
        resources = self.owner.descriptor['runtime']['resources']
        frames = []
        for match in re.finditer(r'\(file "([^"]+)" line ([0-9]{1,7})\)', information):
            if match[1] in resources:
                frames.append(dict(path=match[1], line=int(match[2])))
                if len(frames) == 8:
                    break
        return dict(exception_type='TclError', error_code_count=len(code), error_code=fields,
                    resource_frames=frames)

    def _owned_load(self, caller):
        frame = self.tk_load_frame
        return (frame is not None and self.tk_initialization is not None
            and frame.f_code is _InterpreterControl.initialize_tk.__code__
            and frame.f_globals is globals() and frame.f_locals.get('self') is self
            and caller.f_code is _InterpreterControl._internal.__code__
            and caller.f_globals is globals() and caller.f_locals.get('self') is self
            and caller.f_back is frame and caller.f_locals.get('name') == 'load'
            and caller.f_locals.get('category') == 'denied:load'
            and caller.f_locals.get('arguments') == (self.tk_initialization['path'], 'Tk'))

    def _ensemble_map(self, value):
        values = tuple(map(str, self.app.splitlist(value)))
        if len(values) > 512 or len(values) % 2 or len(set(values[::2])) != len(values) // 2:
            self.deny('native-ensemble-map-shape')
        return dict(zip(values[::2], values[1::2]))

    def _namespace_diagnostic(self, args, caller):
        if self.owner.namespace_diagnostic_count >= 16:
            return None
        self.owner.namespace_diagnostic_count += 1
        source, namespace = self.app.eval('info script'), self.app.eval('namespace current')
        private = set(self.owner.environment_snapshot.values()) | {app.trace_token for app in self.owner.apps}
        bound = source in self.owner.descriptor['runtime']['resources'] and source not in private
        namespaces = ('::', '::tcl::tm', '::msgcat::mcutil', '::tk::print', '::tk::print::cups', '::tk::systray')
        callback_codes = {callback.__code__ for callback in self.callbacks.values()}
        frames, frame, category = [], caller, 'other'
        for index in range(4):
            if frame is None:
                break
            if frame.f_code in callback_codes:
                value = frame.f_locals.get('category')
                if value in ('namespace', 'namespace:ensemble', 'namespace:import'):
                    category = value
            frames.append(dict(supplied_back=index, internal=frame.f_code is _InterpreterControl._internal.__code__,
                initialize=frame.f_code is _InterpreterControl.initialize_tk.__code__,
                validate=frame.f_code is _InterpreterControl._validate.__code__,
                callback=frame.f_code in callback_codes, namespace_matches=frame.f_globals is globals(),
                self_matches=frame.f_locals.get('self') is self,
                validation_category_is_native_ensemble=frame.f_locals.get('category') == 'namespace:ensemble'))
            frame = frame.f_back
        for offset in (2, 3, 4):
            frame = sys._getframe(offset)
            if frame.f_code in callback_codes:
                value = frame.f_locals.get('category')
                if value in ('namespace', 'namespace:ensemble', 'namespace:import'):
                    category = value
        validation_parent = sys._getframe(3)
        owned_frame = self.tk_load_frame
        initialized = self.tk_initialization is not None
        operation = ('import' if args[:1] == ('import',) else args[1]
            if len(args) > 1 and args[0] == 'ensemble' and args[1] in ('create', 'configure', 'exists') else 'other')
        return dict(bootstrap=self.bootstrap, initializing=initialized and self.tk_initialization['status'] == 'INITIALIZING',
            current_thread=threading.get_ident() == self.owner.thread, owned_load=self._owned_load(caller),
            caller_code_matches=caller.f_code is _InterpreterControl._internal.__code__,
            caller_is_validate=caller.f_code is _InterpreterControl._validate.__code__,
            caller_is_callback=caller.f_code in callback_codes,
            validation_parent_is_native_ensemble=validation_parent.f_code is _InterpreterControl._validate.__code__
                and validation_parent.f_locals.get('category') == 'namespace:ensemble',
            caller_namespace_matches=caller.f_globals is globals(), caller_self_matches=caller.f_locals.get('self') is self,
            caller_parent_is_owned_frame=owned_frame is not None and caller.f_back is owned_frame,
            caller_name_is_load=caller.f_locals.get('name') == 'load',
            caller_load_args_match=initialized and caller.f_locals.get('arguments') == (self.tk_initialization['path'], 'Tk'),
            owned_frame_code_matches=owned_frame is not None and owned_frame.f_code is _InterpreterControl.initialize_tk.__code__,
            owned_frame_namespace_matches=owned_frame is not None and owned_frame.f_globals is globals(),
            owned_frame_self_matches=owned_frame is not None and owned_frame.f_locals.get('self') is self,
            category=category, frames=frames, ensemble_dispatch_pending=self.ensemble_dispatch is not None,
            import_dispatch_pending=self.force_import_dispatch is not None,
            operation=operation, argument_count=len(args), namespace=namespace if namespace in namespaces else 'other',
            source=source if bound else 'unbound',
            msgcat_create_args=args == ('ensemble', 'create', '-prefix', '0'),
            tm_path_create_args=args == ('ensemble', 'create', '-command', 'path', '-subcommands', 'add remove list'),
            plain_create_args=args == ('ensemble', 'create'),
            map_query_args=args == ('ensemble', 'configure', 'tk', '-map'),
            map_write_args=len(args) == 5 and args[:4] == ('ensemble', 'configure', 'tk', '-map'),
            print_import_args=args == ('import', '-force', '::tk::msgcat::*'))

    def _ensemble(self, args, caller):
        if (not self.bootstrap or self.tk_initialization is None
                or self.tk_initialization['status'] != 'INITIALIZING'
                or threading.get_ident() != self.owner.thread or not self._owned_load(caller)):
            self.deny('native-ensemble-change', diagnostic=self._namespace_diagnostic(args, caller))
        source = self.app.eval('info script')
        namespace = self.app.eval('namespace current')
        runtime = self.owner.descriptor['runtime']
        if source not in runtime['resources']:
            self.deny('native-ensemble-source', diagnostic=self._namespace_diagnostic(args, caller))
        library = Path(self.tk_initialization['tk_library'])
        print_source, systray_source = str(library / 'print.tcl'), str(library / 'systray.tcl')
        create = ((namespace == '::msgcat::mcutil'
                   and re.fullmatch(r'msgcat-[0-9]+(?:\.[0-9]+)*\.tm', Path(source).name)
                   and args == ('ensemble', 'create', '-prefix', '0'))
            or (namespace == '::tcl::tm' and source == str(Path(self.tcl_library) / 'tm.tcl')
                and args == ('ensemble', 'create', '-command', 'path', '-subcommands', 'add remove list'))
            or (source == print_source and namespace in ('::tk::print', '::tk::print::cups')
                and args == ('ensemble', 'create'))
            or (source == systray_source and namespace == '::tk::systray'
                and args == ('ensemble', 'create')))
        if create:
            action = 'create'
        elif (source in (print_source, systray_source) and namespace == '::'
                and args[:4] == ('ensemble', 'configure', 'tk', '-map') and len(args) in (4, 5)
                and str(self.app.call('namespace', 'which', '-command', 'tk')) == '::tk'):
            action = 'query' if len(args) == 4 else 'map'
            if action == 'map':
                previous = self.ensemble_maps.get(source)
                additions = ({'print': '::tk::print'} if source == print_source else
                             {'systray': '::tk::systray', 'sysnotify': '::tk::sysnotify::sysnotify'})
                if previous is None or self._ensemble_map(args[4]) != dict(previous, **additions):
                    self.deny('native-ensemble-map-extension', diagnostic=self._namespace_diagnostic(args, caller))
        else:
            self.deny('native-ensemble-change', diagnostic=self._namespace_diagnostic(args, caller))
        key = (source, namespace, action)
        if key in self.ensemble_used or len(self.ensemble_used) >= 16 or self.ensemble_operation is not None:
            self.deny('native-ensemble-repeated-operation', diagnostic=self._namespace_diagnostic(args, caller))
        self.ensemble_used.add(key)
        self.ensemble_operation = key
        self.ensemble_dispatch = args

    def _force_import(self, args, caller):
        source, namespace = self.app.eval('info script'), self.app.eval('namespace current')
        if (args != ('import', '-force', '::tk::msgcat::*') or not self.bootstrap
                or self.tk_initialization is None or self.tk_initialization['status'] != 'INITIALIZING'
                or threading.get_ident() != self.owner.thread or not self._owned_load(caller)
                or self.force_import_used or namespace != '::tk::print'
                or source != str(Path(self.tk_initialization['tk_library']) / 'print.tcl')
                or source not in self.owner.descriptor['runtime']['resources']):
            self.deny('namespace-force-import', diagnostic=self._namespace_diagnostic(args, caller))
        exports = set(map(str, self.app.splitlist(self.app.eval('namespace eval ::tk::msgcat {namespace export}'))))
        if exports != {'mc', 'mcmax'}:
            self.deny('namespace-force-import-exports')
        origins = {}
        for name in ('mc', 'mcmax'):
            source_command, destination = '::tk::msgcat::' + name, '::tk::print::' + name
            if (not self.app.call('info', 'commands', source_command)
                    or self.app.call('info', 'commands', destination) or destination in self.guarded):
                self.deny('namespace-force-import-replacement')
            origin = str(self.app.call('namespace', 'origin', source_command))
            if origin not in ('::msgcat::' + name, source_command):
                self.deny('namespace-force-import-origin')
            origins[name] = origin
        self.force_import_used = True
        self.force_import_operation = (source, namespace, origins)
        self.force_import_dispatch = args

    @staticmethod
    def _owned(value):
        return (value == '.' or bool(re.fullmatch(r'\.[A-Za-z0-9_!][A-Za-z0-9_!.]*', value))
                or bool(len(value) <= 256 and '#' in value and re.fullmatch(
                    r'\.#?[A-Za-z0-9_!]+(?:#[A-Za-z0-9_!]+)*(?:\.#?[A-Za-z0-9_!]+(?:#[A-Za-z0-9_!]+)*)*', value)))

    def _path(self, value, *, directory=False):
        try:
            require(not value.startswith(('~', '|')), 'unsupported Tcl path syntax')
            path = str(_absolute(value))
            rows = self.owner.descriptor['runtime']['resource_directories' if directory else 'resources']
            row = rows.get(path)
            require(row is not None and _same_metadata(row, directory=directory,
                resource_roots=self.owner.descriptor['runtime']['resource_roots']), 'unbound native resource')
        except (DesktopBlocked, OSError, ValueError, TypeError):
            self.deny('resource-origin')
        return path

    def verify_module_metadata(self):
        runtime = self.owner.descriptor['runtime']
        rows = self.owner.descriptor['module_metadata']
        for path in self.module_candidates:
            require(path in rows and rows[path]['path'] == path and _same_module_metadata(rows[path], runtime),
                    'selected Tcl module metadata/absence identity changed')

    def _module_query(self, operation, args, path, caller):
        interpreter = self.owner.descriptor['interpreter']
        selected_executable = path in (interpreter['path'], interpreter['resolved'])
        row = self.owner.descriptor['module_metadata'].get(path)
        absent = path in self.module_candidates and row is not None and row['kind'] == 'absence'
        if not selected_executable and not absent:
            return False
        source = self.app.eval('info script')
        try:
            procedure = self.app.eval('namespace which -command [lindex [info level 0] 0]')
        except self.owner.native.TclError:
            procedure = 'other'
        tm_source = str(Path(self.tcl_library) / 'tm.tcl')
        bound_source = source in self.owner.descriptor['runtime']['resources']
        known = ('::tcl::tm::Defaults', '::tcl::tm::roots', '::tcl::tm::UnknownHandler')
        context = ((procedure == known[0] and selected_executable and operation == 'normalize' and source == tm_source)
            or (procedure == known[1] and absent and operation == 'normalize' and source == tm_source)
            or (procedure == known[2] and absent and operation == 'exists' and bound_source))
        if (len(args) != 1 or not context or not self.bootstrap or self.tk_initialization is None
                or self.tk_initialization['status'] != 'INITIALIZING'
                or threading.get_ident() != self.owner.thread or not self._owned_load(caller)):
            self.deny('module-metadata-context', diagnostic=dict(operation=operation,
                procedure=procedure if procedure in known else 'other', source=source if bound_source else 'unbound',
                selected_executable=selected_executable, absent_candidate=absent,
                owned_load=self._owned_load(caller), bootstrap=self.bootstrap))
        if len(self.module_metadata_events) >= MAX_MODULE_EVENTS:
            self.deny('module-metadata-budget')
        if selected_executable:
            if not _same_interpreter(interpreter):
                self.deny('module-interpreter-identity')
        elif row['path'] != path or not _same_module_metadata(row, self.owner.descriptor['runtime']):
            self.deny('module-root-identity')
        self.module_metadata_events.append(dict(operation=operation, procedure=procedure, path=path,
            kind='selected-interpreter' if selected_executable else 'absent-module-root'))
        return True

    def verify_catalog_metadata(self):
        for path, row in self.owner.descriptor['catalog_metadata'].items():
            require(path == row['path'] and _same_module_metadata(row, self.owner.descriptor['runtime']),
                    'selected absent C catalog identity changed')

    def _file_origin_diagnostic(self, operation, args, path, caller):
        if self.owner.file_origin_diagnostic_count >= 16:
            return None
        self.owner.file_origin_diagnostic_count += 1
        runtime, descriptor = self.owner.descriptor['runtime'], self.owner.descriptor
        target = dict(kind='unbound', length=len(path) if path is not None else 0)
        for kind, values in (('C-catalog-candidate', descriptor['catalog_metadata']),
                ('module-candidate', descriptor['module_metadata']), ('resource-file', runtime['resources']),
                ('resource-directory', runtime['resource_directories'])):
            if path in values:
                target = dict(kind=kind, path=path)
                break
        else:
            if path in (descriptor['interpreter']['path'], descriptor['interpreter']['resolved']):
                target = dict(kind='selected-interpreter', path=path)
            elif path is not None:
                for root in runtime['resource_roots']:
                    if Path(path).is_relative_to(Path(root)):
                        target = dict(kind='unknown-within-resource-root', root=root,
                            depth=len(Path(path).relative_to(Path(root)).parts), length=len(path))
                        break
        source = self.app.eval('info script')
        try:
            procedure = self.app.eval('namespace which -command [lindex [info level 0] 0]')
        except self.owner.native.TclError:
            procedure = 'other'
        known = ('::tcl::tm::Defaults', '::tcl::tm::roots', '::tcl::tm::UnknownHandler',
                 '::msgcat::mcpackageconfig', '::msgcat::mcload', '::msgcat::Load')
        diagnostic = dict(operation=operation, argument_count=len(args), target=target,
            source=source if source in runtime['resources'] else 'unbound',
            procedure=procedure if procedure in known else 'other', bootstrap=self.bootstrap,
            owned_load=self._owned_load(caller), current_thread=threading.get_ident() == self.owner.thread)
        if self._startup_target_eligible(operation, args, path, source, procedure, caller):
            self.owner.startup_diagnostic_count += 1
            diagnostic['startup_denied_target'] = dict(attempted_path=args[0], lexical_absolute_path=path,
                operation=operation, procedure=procedure, source=source,
                tcl_version=self.owner.native.TCL_VERSION, tk_version=self.owner.native.TK_VERSION,
                tcl_library=self.tcl_library, status='DENIED; concrete target requires review')
        return diagnostic

    def _startup_target_eligible(self, operation, args, path, source, procedure, caller):
        return (self.owner.descriptor.get('startup_diagnostic') is True
                and self.owner.startup_diagnostic_count == 0 and self.owner.native.TCL_VERSION == '8.6'
                and not self.probe_phase and self.bootstrap and self.tk_initialization is not None
                and self.tk_initialization['status'] == 'INITIALIZING'
                and operation == 'normalize' and len(args) == 1 and type(args[0]) is str
                and path is not None and target_path_safe(args[0])
                and path == str(_absolute(args[0]))
                and procedure == '::tcl::tm::roots' and source == str(Path(self.tcl_library) / 'tm.tcl')
                and source in self.owner.descriptor['runtime']['resources']
                and threading.get_ident() == self.owner.thread and self._owned_load(caller))

    def _catalog_query(self, operation, args, path, caller):
        row = self.owner.descriptor['catalog_metadata'].get(path)
        if row is None:
            return False
        source = self.app.eval('info script')
        try:
            procedure = self.app.eval('namespace which -command [lindex [info level 0] 0]')
        except self.owner.native.TclError:
            procedure = 'other'
        library = self.tk_initialization['tk_library'] if self.tk_initialization is not None else None
        expected = {str(Path(library) / 'msgs' / name) for name in ('c.msg', 'ROOT.msg')} if library else set()
        if (operation != 'exists' or len(args) != 1 or path not in expected
                or not self.bootstrap or self.tk_initialization is None or self.tk_initialization['status'] != 'INITIALIZING'
                or threading.get_ident() != self.owner.thread or not self._owned_load(caller)
                or self.owner.environment_snapshot.get('LC_ALL') != 'C' or procedure != '::msgcat::Load'
                or source != str(Path(library) / 'tk.tcl') or source not in self.owner.descriptor['runtime']['resources']):
            self.deny('C-catalog-metadata-context', diagnostic=self._file_origin_diagnostic(operation, args, path, caller))
        if len(self.catalog_metadata_events) >= MAX_CATALOG_EVENTS:
            self.deny('C-catalog-metadata-budget')
        if row['path'] != path or not _same_module_metadata(row, self.owner.descriptor['runtime']):
            self.deny('C-catalog-absence-identity')
        self.catalog_metadata_events.append(dict(operation='exists', path=path, procedure='::msgcat::Load'))
        return True

    def _file(self, operation, args):
        if operation not in FILE_READS:
            self.deny('file-mutation')
        if operation in FILE_PURE:
            return
        if operation in ('atime', 'mtime') and len(args) != 1:
            self.deny('file-time-write')
        if not args:
            self.deny('file-query-arguments')
        try:
            path = str(_absolute(args[0]))
        except (DesktopBlocked, ValueError, TypeError):
            self.deny('file-query-origin', diagnostic=self._file_origin_diagnostic(operation, args, None, sys._getframe(3)))
        if self._module_query(operation, args, path, sys._getframe(3)):
            return
        if self._catalog_query(operation, args, path, sys._getframe(3)):
            return
        runtime = self.owner.descriptor['runtime']
        if path in runtime['resources'] or path in runtime['resource_directories']:
            self._path(path, directory=path in runtime['resource_directories'])
        elif str(Path(path).parent) in runtime['resource_directories'] and not os.path.lexists(path):
            return
        else:
            self.deny('file-query-origin', diagnostic=self._file_origin_diagnostic(operation, args, path, sys._getframe(3)))

    def _channel(self, operation, args):
        if operation == 'read' and args and args[0] == '-nonewline':
            args = args[1:]
        if operation not in ('read', 'gets', 'eof', 'close', 'seek', 'tell', 'blocked',
                             'fblocked', 'configure', 'fconfigure', 'fileevent', 'event', 'names'):
            self.deny('channel-write-or-create')
        if operation == 'names':
            self.deny('channel-enumeration')
        if not args or args[0] not in self.channels:
            self.deny('unowned-channel')
        if operation in ('configure', 'fconfigure') and len(args) > 1:
            options = args[1::2]
            if (len(args) not in (3, 5, 7) or len(set(options)) != len(options)
                    or any(option not in ('-encoding', '-translation', '-eofchar') for option in options)):
                self.deny('channel-configuration')
        if operation in ('fileevent', 'event') and (len(args) < 2 or args[1] != 'readable'):
            self.deny('channel-write-event')

    def _validate(self, category, args):
        for prefix in ('interp', 'trace', 'namespace', 'encoding', 'array'):
            if category.startswith(prefix + ':'):
                return self._validate(prefix, (category.split(':', 1)[1], *args))
        if category.startswith('denied:'):
            self.deny(category)
        elif category.startswith('file:'):
            self._file(category.split(':', 1)[1], args)
        elif category.startswith('channel:'):
            self._channel(category.split(':', 1)[1], args)
        elif category == 'file':
            if not args:
                self.deny('file-arguments')
            self._file(args[0], args[1:])
        elif category == 'source':
            if len(args) == 1:
                path = args[0]
            elif len(args) == 2 and args[0] == '-nopkg' and self.owner.native.TCL_VERSION == '9.0':
                path = args[1]
            elif len(args) == 3 and args[:2] == ('-encoding', 'utf-8'):
                path = args[2]
            else:
                self.deny('source-arguments')
            self._path(path)
            if Path(path).suffix not in ('.tcl', '.tm', '.msg') and Path(path).name != 'tclIndex':
                self.deny('source-resource-type')
            self._scan()
        elif category == 'open':
            if len(args) not in (1, 2) or len(args) == 2 and args[1] not in ('r', 'rb'):
                self.deny('open-write-or-pipeline')
            self._path(args[0])
        elif category == 'glob':
            values = list(args)
            while values and values[0] == '-nocomplain':
                values.pop(0)
            if len(values) < 3 or values[0] != '-directory':
                self.deny('glob-unbounded-resource-search')
            self._path(values[1], directory=True)
            patterns = values[2:]
            if patterns and patterns[0] == '--':
                patterns = patterns[1:]
            if not patterns or any('/' in item or item.startswith(('-', '~')) for item in patterns):
                self.deny('glob-resource-traversal')
        elif category == 'chan':
            if not args:
                self.deny('channel-arguments')
            self._channel(args[0], args[1:])
        elif category == 'encoding':
            if args and args[0] == 'dirs' and len(args) != 1:
                self.deny('encoding-resource-path-change')
        elif category == 'trace':
            if not args or args[0] not in ('add', 'remove', 'info') or len(args) < 2 or args[1] != 'variable':
                self.deny('execution-trace-change')
            if len(args) < 3 or args[2].lstrip(':').split('(', 1)[0] == 'env':
                self.deny('native-environment-trace-change')
        elif category == 'interp':
            if args in (('issafe',), ('issafe', '')):
                return
            expected = ('alias', '', '::ttk::paned', '', "ttk::do'deprecate", '::ttk::paned', '::ttk::panedwindow')
            if self.bootstrap and not self.alias_used and args == expected and self._source_is('ttk.tcl'):
                self.alias_used = True
                self.alias_dispatch = args
                return
            self.deny('interpreter-or-alias-operation')
        elif category == 'rename':
            helper = args[0].removeprefix('::') if args else ''
            owned_load = self._owned_load(sys._getframe(2))
            if (args == ('tkInit', '') and self.bootstrap and not self.tk_init_renamed
                    and self.tk_initialization is not None and self.tk_initialization['status'] == 'INITIALIZING'
                    and threading.get_ident() == self.owner.thread and owned_load
                    and str(self.app.call('namespace', 'which', '-command', 'tkInit')) == '::tkInit'):
                self.tk_init_renamed = True
                self.tk_initialization['tkInit_cleanup_count'] = 1
                return
            if (self.bootstrap and len(args) == 2 and args[1] == ''
                    and helper in ('ttk::LoadThemes', 'ttk::DefaultTheme')
                    and helper not in self.rename_used and self._source_is('ttk.tcl')):
                self.rename_used.add(helper)
                return
            diagnostic = None
            if self.owner.rename_diagnostic_count < 16:
                self.owner.rename_diagnostic_count += 1
                source = self.app.eval('info script')
                diagnostic = dict(argument_count=len(args), empty_target=len(args) == 2 and args[1] == '',
                    known_helper=helper if helper in ('tkInit', 'ttk::LoadThemes', 'ttk::DefaultTheme') else 'other',
                    bootstrap=self.bootstrap, unseen_helper=helper not in self.rename_used,
                    source_empty=not source, source_bound=source in self.owner.descriptor['runtime']['resources'],
                    source_basename_is_ttk=Path(source).name == 'ttk.tcl', owned_load_frame=owned_load,
                    current_thread=threading.get_ident() == self.owner.thread,
                    argument_types=[type(value).__name__ for value in args[:4]])
            self.deny('command-rename', diagnostic=diagnostic)
        elif category == 'proc':
            if not args or self._qualified(args[0]).startswith(CONTROL_NAMESPACE + '::') or self._protected_name(args[0]):
                self.deny('protected-command-replacement')
        elif category == 'namespace':
            if not args:
                self.deny('namespace-arguments')
            if args[0] == 'import' and '-force' in args:
                self._force_import(args, sys._getframe(2))
            if args[0] == 'upvar' and any(item.lstrip(':').split('(', 1)[0] == 'env' for item in args[1:]):
                self.deny('native-environment-alias')
            if args[0] in ('delete', 'eval', 'inscope'):
                targets = args[1:] if args[0] == 'delete' else args[1:2]
                for target in targets:
                    canonical = self._qualified(target)
                    if canonical == CONTROL_NAMESPACE or canonical.startswith(CONTROL_NAMESPACE + '::'):
                        self.deny('control-namespace-change')
                    if args[0] == 'delete' and (canonical == '::' or any(canonical == prefix or canonical.startswith(prefix + '::')
                                                                        for prefix in ('::tcl', '::tk', '::ttk'))):
                        self.deny('protected-namespace-delete')
            if args[0] == 'ensemble' and len(args) > 1 and args[1] != 'exists':
                self._ensemble(args, sys._getframe(2))
        elif category in ('creator', 'widget', 'image-instance'):
            if category == 'creator' and (not args or not self._owned(args[0]) or any(item in args for item in ('-use', '-container'))):
                self.deny('foreign-or-embedded-window', diagnostic=dict(
                    target=args[0][:256] if args else None, argument_count=len(args),
                    owned=bool(args and self._owned(args[0])),
                    embedding_option=any(item in args for item in ('-use', '-container'))))
            if category == 'image-instance' and args and any(full.startswith(args[0]) for full in ('read', 'write')):
                self.deny('native-image-file-operation')
            if category == 'widget' and args and 'postscript'.startswith(args[0]):
                self.deny('native-postscript-export')
            self._options(args)
        elif category == 'image':
            self._options(args)
            if args and args[0] == 'create' and (len(args) < 2 or args[1] not in ('photo', 'bitmap')):
                self.deny('unsupported-native-image-type')
        elif category == 'option':
            if args and 'readfile'.startswith(args[0]):
                self.deny('native-option-file-read')
        elif category == 'wm':
            if len(args) < 2 or args[0] not in WM_ALLOWED or not self._owned(args[1]):
                self.deny('window-manager-scope')
            if args[0] == 'iconname' and len(args) not in (2, 3):
                self.deny('window-manager-iconname-arity')
            if args[0] == 'transient' and (len(args) not in (2, 3)
                    or len(args) == 3 and not self._owned(args[2])):
                self.deny('window-manager-transient-scope')
            self._options(args)
        elif category == 'winfo':
            if len(args) < 2 or args[0] not in WINFO_ALLOWED or not self._owned(args[1]):
                self.deny('window-query-scope')
        elif category == 'focus':
            if args and not self._owned(args[-1]):
                self.deny('focus-scope')
        elif category == 'grab':
            if len(args) != 2 or args[0] not in ('current', 'set', 'release'):
                self.deny('grab-local-arguments')
            target = args[1]
            registered = self.guarded.get('::' + target)
            if (len(target) > 256 or not self._owned(target) or registered is None
                    or registered[0] != 'widget' or not self.app.call('info', 'commands', '::' + target)
                    or not self.app.call('winfo', 'exists', target)):
                self.deny('grab-widget-scope')
            if (self.bootstrap or self.closed or self.owner.finished or self not in self.owner.apps
                    or self.tk_initialization is None or self.tk_initialization['status'] != 'PASS'
                    or threading.get_ident() != self.owner.thread or self.root.tk is not self.app
                    or self.root._w != '.' or not self.app.call('info', 'commands', '.')):
                self.deny('grab-interpreter-lifetime')
        elif category == 'event':
            if not args or args[0] not in ('add', 'delete', 'generate', 'info'):
                self.deny('abbreviated-event-operation')
            if args and args[0] == 'generate' and (len(args) < 3 or not self._owned(args[1])):
                self.deny('event-window-scope')
            if any(item.startswith('-') and len(item) > 1 and '-warp'.startswith(item) for item in args):
                self.deny('global-pointer-warp')
        elif category == 'destroy':
            if not args or not all(self._owned(item) for item in args):
                self.deny('destroy-window-scope')
        elif category == 'tk':
            if not args or args[0] not in ('windowingsystem', 'useinputmethods', 'scaling', 'appname', 'caret'):
                self.deny('native-tk-session-operation')
            if '-displayof' in args:
                index = args.index('-displayof')
                if len(args) <= index + 1 or not self._owned(args[index + 1]):
                    self.deny('tk-display-scope')
        elif category in ('set', 'unset', 'array', 'upvar'):
            names = args[:1] if category == 'set' else args
            if category == 'set' and len(args) == 1:
                return
            if category == 'array' and args and args[0] in ('get', 'names', 'exists', 'size', 'statistics'):
                return
            if any(item.lstrip(':').split('(', 1)[0] == 'env' for item in names):
                self.deny('native-process-environment-change')

    def _source_is(self, name):
        path = self.app.eval('info script')
        return Path(path).name == name and path in self.owner.descriptor['runtime']['resources']

    def _protected_name(self, name):
        resolved = str(self.app.call('namespace', 'which', '-command', self._qualified(name)))
        return resolved in self.guarded or resolved.startswith(CONTROL_NAMESPACE + '::')

    def _qualified(self, name):
        current = self.app.eval('namespace current')
        value = name if name.startswith('::') else current.rstrip(':') + '::' + name
        return '::' + '::'.join(part for part in value.split('::') if part)

    def _options(self, args):
        unsafe = ('-file', '-maskfile', '-use', '-container', '-bitmap', '-cursor', '-iconbitmap', '-window')
        if any(item.startswith('-') and len(item) > 1 and item != full and full.startswith(item)
               for item in args for full in unsafe):
            self.deny('abbreviated-native-file-or-session-option')
        if any(item in args for item in ('-file', '-maskfile', '-use', '-container')):
            self.deny('native-file-or-embedding-option')
        for index, item in enumerate(args[:-1]):
            if item in ('-bitmap', '-cursor', '-iconbitmap'):
                try:
                    parts = self.app.splitlist(args[index + 1])
                except self.owner.native.TclError:
                    self.deny('unsupported-native-bitmap-or-cursor')
                if any(str(part).startswith('@') for part in parts):
                    self.deny('native-bitmap-or-cursor-file')
            if item == '-window' and not self._owned(args[index + 1]):
                self.deny('foreign-widget-window')

    def probes(self):
        commands = [('socket', '127.0.0.1', '9'), ('exec', '/bin/true'),
            ('fconfigure', 'stdin', '-encoding', 'utf-8'),
            ('chan', 'configure', 'stdout', '-translation', 'lf'),
            ('open', str(Path(self.owner.descriptor['scratch']) / 'native-denied-write'), 'w'),
            ('file', 'delete', str(Path(self.owner.descriptor['scratch']) / 'native-denied-write')),
            ('load', str(Path(self.owner.descriptor['scratch']) / 'absent-native.so')),
            ('interp', 'create'), ('rename', 'socket', 'uncontrolled_socket'),
            ('trace', 'remove', 'execution', 'socket', 'enter',
             (self.guarded['::socket'][1], self.trace_token)),
            ('proc', self.guarded['::socket'][1], 'args', 'return'),
            ('namespace', 'delete', CONTROL_NAMESPACE),
            ('namespace', 'eval', CONTROL_NAMESPACE, 'return'),
            (self.guarded['::open'][1], 'not-the-private-prefix', 'open ignored', '0', 'stdin', 'leave'),
            ('set', '::env(DISPLAY)', 'unselected.invalid:1'), ('unset', '::env'),
            ('lappend', '::env(HOME)', 'native-denied-environment-value'),
            ('trace', 'remove', 'variable', '::env', ('write', 'unset'),
             (CONTROL_NAMESPACE + '::environment', self.trace_token)),
            ('source', 'relative-unreviewed.tcl')]
        for name in ('::tcl::file::delete', '::tcl::file::tempfile'):
            if name in self.guarded:
                commands.append((name, str(Path(self.owner.descriptor['scratch']) / 'native-denied-write')))
        if '::tcl::array::unset' in self.guarded:
            commands.append(('::tcl::array::unset', '::env'))
        zipfs_commands = {
            'mkzip': (str(Path(self.owner.descriptor['scratch']) / 'native-denied.zip'), ()),
            'mkimg': (str(Path(self.owner.descriptor['scratch']) / 'native-denied.img'), (), 'absent-image'),
            'mountdata': ('not-an-archive', '/__operator_absent_mount'),
            'unmount': ('/__operator_absent_mount',)}
        for name, arguments in zipfs_commands.items():
            command = '::tcl::zipfs::' + name
            if command in self.guarded:
                commands.append((command, *arguments))
        self.probe_phase = True
        channel = None
        try:
            for path in sorted(self.module_candidates):
                row = self.owner.descriptor['module_metadata'][path]
                if row['kind'] == 'absence':
                    first = dict(row['ancestors'][0], identity=list(row['ancestors'][0]['identity']))
                    first['identity'][1] += 1
                    forged = dict(row, ancestors=[first, *row['ancestors'][1:]])
                    require(not _same_module_metadata(forged, self.owner.descriptor['runtime']),
                            'module absence accepted a stale synthetic ancestor identity')
                    self.owner.negative_controls.append('module-absence:stale-synthetic-ancestor')
                    break
            for row in self.owner.descriptor['catalog_metadata'].values():
                first = dict(row['ancestors'][0], identity=list(row['ancestors'][0]['identity']))
                first['identity'][1] += 1
                forged = dict(row, ancestors=[first, *row['ancestors'][1:]])
                require(not _same_module_metadata(forged, self.owner.descriptor['runtime']),
                        'C catalog absence accepted a stale synthetic ancestor identity')
                self.owner.negative_controls.append('C-catalog-absence:stale-synthetic-ancestor')
                break
            resource = str(Path(str(self.app.call('info', 'library'))) / 'init.tcl')
            require(resource in self.owner.descriptor['runtime']['resources'],
                    'native channel negatives require the selected Tcl initialization resource')
            channel = str(self.app.call('open', resource, 'r'))
            require(channel in self.channels, 'native channel negative did not acquire an owned read-only channel')
            commands.extend((('source', '-nopk', resource),
                ('source', '-nopkg', resource, 'unsupported-extra-argument'),
                ('source', '-nopkg', str(Path(self.owner.descriptor['scratch']) / 'native-unbound-source.tcl')),
                ('fconfigure', channel, '-blocking', '0'),
                ('fconfigure', channel, '-encoding', 'utf-8', '-encoding', 'utf-8'),
                ('fconfigure', channel, '-encoding'),
                ('chan', 'configure', channel, '-e', 'utf-8'),
                ('chan', 'configure', channel, '-encoding', 'utf-8', '-translation', 'lf',
                 '-eofchar', '', '-blocking', '0')))
            for command in commands:
                before = len(self.owner.denials)
                try:
                    self.app.call(*command)
                except self.owner.native.TclError:
                    require(len(self.owner.denials) == before + 1, 'native negative did not reach its effect control')
                else:
                    raise DesktopBlocked('native negative escaped: ' + command[0])
                self.owner.negative_controls.append(command[0] + ':' + self.owner.denials[-1]['category'])
                self.verify_environment()
        finally:
            try:
                if channel is not None:
                    self.app.call('close', channel)
            finally:
                self.probe_phase = False

    def verify_environment(self):
        values = tuple(map(str, self.app.splitlist(self.app.call('array', 'get', '::env'))))
        require(dict(zip(values[::2], values[1::2])) == self.native_environment,
                'native process environment changed despite its control')

    def runtime_probes(self):
        require(all(self._owned(name) for name in ('.#!menu', '.#!menu.#!menu2', '.!menu.#!menu',
                    '.#!menu.#!menu#!menu')),
                'same-interpreter menu clone names were rejected')
        require(not any(self._owned(name) for name in ('#!menu', '0x1234', '.#', '.##menu',
                    '.#!menu..#!child', '.#!menu/foreign', '.#!menu;exec', '.#!menu##child',
                    '.#!menu#', '.#' + 'a' * 256)),
                'malformed or foreign menu names were admitted')
        self.owner.negative_controls.append('owned-menu-clone-name-boundaries')
        require(self.app.call('info', 'commands', '.') and not self._root_retired(),
                'an unattested live root was admitted as retired')
        self.owner.negative_controls.append('unattested-live-root-not-retired')
        for name, category, present in (('::exec', 'denied:exec', True),
                ('::bell', 'denied:exec', True), ('::bell', 'denied:bell', False)):
            issue = dict(name=name, category=category, present=present, expected_trace_present=False)
            require(not _tk_teardown_issues_supported(1, [issue]),
                    'native teardown admitted a core, mismatched or missing-command repair')
        require(not _tk_teardown_issues_supported(2, []), 'native teardown accepted a truncated issue list')
        self.owner.negative_controls.append('native-teardown-exact-issue-set-negatives')
        commands = [('load', self.tk_initialization['path'], 'Tk'),
            ('menu', '#!foreign'),
            ('toplevel', '.#!embedded', '-use', '0x1234'),
            ('toplevel', '.#!container', '-container', '1'),
            ('wm', 'iconname', '0x1234'),
            ('wm', 'iconname', '.', 'name', 'extra'),
            ('wm', 'transient', '.', '0x1234'),
            ('wm', 'transient', '.', '.', 'extra'),
            ('file', 'normalize', self.tcl_executable),
            ('rename', 'tkInit', ''),
            ('namespace', 'ensemble', 'configure', 'tk', '-map'),
            ('namespace', 'ensemble', 'create', '-command', CONTROL_NAMESPACE + '::uncontrolled'),
            ('namespace', 'import', '-force', '::tk::msgcat::*'),
            ('namespace', 'ensemble', 'create', '-command', 'path', '-subcommands', 'add remove list'),
            ('interp', 'alias', '', '::ttk::paned', '', "ttk::do'deprecate", '::ttk::paned', '::ttk::panedwindow'),
            ('send', 'unselected-application', 'set value forbidden'),
            ('clipboard', 'clear', '-displayof', '.'), ('selection', 'clear', '-displayof', '.'),
            ('event', 'generate', '.', '<Motion>', '-warp', '1'),
            ('event', 'gen', '.', '<Motion>'),
            ('image', 'create', 'photo', '-fi', str(Path(self.owner.descriptor['scratch']) / 'absent-image')),
            ('label', '.__desktop_negative', '-b', '@' + str(Path(self.owner.descriptor['scratch']) / 'absent-bitmap'))]
        grab_denials = {command: 'grab-local-arguments' for command in (
            ('grab',), ('grab', '.'), ('grab', 'current'), ('grab', 'current', '.', 'extra'),
            ('grab', 'cur', '.'), ('grab', 's', '.'), ('grab', 'rel', '.'), ('grab', 'status', '.'),
            ('grab', 'set', '-global', '.'), ('grab', '-global', '.'))}
        grab_denials.update({command: 'grab-widget-scope' for command in (
            ('grab', 'current', '0x1234'), ('grab', 'set', '.unregistered'),
            ('grab', 'release', '.unregistered'), ('grab', 'current', '.!bad/foreign'))})
        grab_denials['grab', 'current', '.'] = 'grab-interpreter-lifetime'
        commands.extend(grab_denials)
        direct = {
            '::tcl::namespace::ensemble': ('configure', 'tk', '-map'),
            '::tcl::namespace::import': ('-force', '::tk::msgcat::*'),
            '::tcl::interp::alias': ('', '::ttk::paned', '', "ttk::do'deprecate", '::ttk::paned', '::ttk::panedwindow'),
            '::tk::print': ('.',), '::tk::print::cups': ('defaultprinter',),
            '::tk::systray': ('exists',), '::tk::systray::_systray': ('.__desktop_negative_tray', '-visible', 'false'),
            '::tk::sysnotify::sysnotify': ('desktop negative', 'must not notify'),
            '::tk::sysnotify::_sysnotify': ('desktop negative', 'must not notify')}
        for name, arguments in direct.items():
            if name in self.guarded:
                commands.append((name, *arguments))
        if '::tcl::namespace::ensemble' in self.guarded:
            commands.append(('::tcl::namespace::ensemble', 'create', '-command', 'path', '-subcommands', 'add remove list'))
        if '::tcl::file::normalize' in self.guarded:
            commands.append(('::tcl::file::normalize', self.tcl_executable))
        for path in sorted(self.module_candidates):
            if self.owner.descriptor['module_metadata'][path]['kind'] == 'absence':
                commands.extend((('file', 'normalize', path), ('file', 'exists', path)))
                for operation in ('normalize', 'exists'):
                    name = '::tcl::file::' + operation
                    if name in self.guarded:
                        commands.append((name, path))
                break
        catalogs = [path for path in self.owner.descriptor['catalog_metadata']
                    if Path(path).parent == Path(self.tk_initialization['tk_library']) / 'msgs']
        for path in sorted(catalogs):
            commands.append(('file', 'exists', path))
            if '::tcl::file::exists' in self.guarded:
                commands.append(('::tcl::file::exists', path))
        if catalogs:
            path = sorted(catalogs)[0]
            commands.extend((('open', path, 'r'), ('source', '-encoding', 'utf-8', path),
                ('glob', '-nocomplain', '-directory', str(Path(path).parent), '*.msg')))
        self.probe_phase = True
        try:
            before = len(self.owner.denials)
            try:
                self._rearm_destroy_traces()
            except self.owner.native.TclError:
                require(len(self.owner.denials) == before + 1,
                        'native teardown negative missed its original-destroy lifetime control')
            else:
                raise DesktopBlocked('native teardown repair escaped its original-destroy lifetime')
            self.owner.negative_controls.append('native-teardown-rearm-outside-genuine-destroy')
            for command in commands:
                before = len(self.owner.denials)
                try:
                    self.app.call(*command)
                except self.owner.native.TclError:
                    require(len(self.owner.denials) == before + 1, 'native session negative missed its effect control')
                    if command in grab_denials:
                        require(self.owner.denials[-1]['category'] == grab_denials[command],
                                'native grab negative reached a different scope or lifetime control')
                else:
                    raise DesktopBlocked('native session negative escaped: ' + command[0])
                self.owner.negative_controls.append(command[0] + ':' + self.owner.denials[-1]['category'])
            self.verify_environment()
        finally:
            self.probe_phase = False

    def finish(self):
        errors = []
        self.cleanup.update(status='INITIALIZING', stage='environment')
        self.verify_environment()
        self.cleanup['stage'] = 'module-metadata'
        self.verify_module_metadata()
        self.cleanup['stage'] = 'catalog-metadata'
        self.verify_catalog_metadata()
        self.cleanup['stage'] = 'root-attestation'
        root_present = bool(self.app.call('info', 'commands', '.'))
        if not self._root_retired():
            errors.append('genuine owned root destruction was not attested')
        self.cleanup['stage'] = 'traces'
        self.verify_traces(refresh_exit=True, final=True)
        if root_present:
            errors.append('test root remained alive after native test cleanup')
            self.cleanup['stage'] = 'owned-root-fallback'
            self.app.call('destroy', '.')
        self.cleanup['stage'] = 'channels'
        for channel in tuple(self.channels):
            try:
                self.app.call('close', channel)
            except self.owner.native.TclError:
                errors.append('owned read channel cleanup failed')
        self.closed = True
        self.cleanup.update(status='FAIL' if errors else 'PASS', stage='COMPLETE')
        return errors

    def startup_context(self):
        require(self.owner.descriptor.get('startup_diagnostic') is True,
                'startup source context is diagnostic-only')
        runtime = self.owner.descriptor['runtime']
        library = self.tk_initialization['tk_library'] if self.tk_initialization is not None else None
        if library is None:
            selected = [root for root in runtime['resource_roots'] if Path(root).name == 'tk' + self.owner.native.TK_VERSION
                        and str(Path(root) / 'tk.tcl') in runtime['resources']]
            require(len(selected) == 1, 'diagnostic requires one selected Tk script root')
            library = selected[0]
        paths = [str(Path(self.tcl_library) / name) for name in ('init.tcl', 'tm.tcl')]
        paths.append(str(Path(library) / 'tk.tcl'))
        context = dict(status='PASS', public_startup={}, scripts=[], per_script_limit=MAX_STARTUP_SOURCE,
                       aggregate_limit=3 * MAX_STARTUP_SOURCE)
        for name in ('tcl_pkgPath', 'tcl_version', 'tcl_patchLevel', 'tcl_library',
                     'tk_version', 'tk_patchLevel', 'tk_library'):
            try:
                value = str(self.app.getvar(name))
                require(len(value.encode('utf-8')) <= 16384, 'public startup value exceeds diagnostic bound')
                context['public_startup'][name] = value
            except self.owner.native.TclError:
                context['public_startup'][name] = dict(state='unavailable')
            except DesktopBlocked:
                context['status'] = 'FAIL'
                context['public_startup'][name] = dict(state='exceeds bound')
        context['public_startup']['nameofexecutable'] = str(self.app.call('info', 'nameofexecutable'))
        for path in paths:
            try:
                require(Path(path).parent.as_posix() in runtime['resource_roots'],
                        'startup source root is outside selected resources')
                context['scripts'].append(_startup_script(runtime['resources'][path], runtime))
            except (OSError, DesktopBlocked, KeyError, UnicodeError) as error:
                context['status'] = 'FAIL'
                context['scripts'].append(dict(path=path, state='unavailable', error_type=type(error).__name__))
        require(len(paths) <= 3 and sum(row.get('bytes', 0) for row in context['scripts']) <= 3 * MAX_STARTUP_SOURCE,
                'startup diagnostic source aggregate exceeded its bound')
        return context


class DesktopControl:
    def __init__(self, descriptor, guard=None):
        require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
                'desktop child requires isolated no-site no-bytecode startup followed by genuine guarded site initialization')
        require(descriptor.get('schema') == SCHEMA, 'unsupported desktop descriptor')
        require(str(Path(sys.executable)) == descriptor['interpreter']['path'], 'desktop interpreter differs from selected application')
        require(str(Path(sys.base_prefix)) == descriptor['runtime']['base']
                and str(Path(sys.prefix)) == descriptor['application'], 'actual desktop base/venv origins differ from selected runtime')
        require(sys.version.split()[0] == descriptor['runtime']['version'], 'desktop selected runtime version differs from actual interpreter')
        require(os.environ.get('DISPLAY') == descriptor['display'] and os.environ.get('HOME') == descriptor['home']
                and os.environ.get('TMPDIR') == descriptor['tmpdir'], 'desktop environment differs from selected descriptor')
        require(not any(name in os.environ for name in ('TCL_LIBRARY', 'TK_LIBRARY', 'TCLLIBPATH', 'XENVIRONMENT', 'XAPPLRESDIR')),
                'unreviewed ambient Tcl/Tk resource override')
        require(not any(re.fullmatch(r'TCL[89](?:\.[0-9]+|_[0-9]+)_TM_PATH', name) for name in os.environ),
                'unreviewed environment-derived Tcl module path')
        require(not any(name in os.environ for name in ('LD_PRELOAD', 'LD_LIBRARY_PATH', 'LD_AUDIT')),
                'unreviewed native loader environment override')
        self.descriptor, self.guard = descriptor, guard
        self.environment_snapshot = dict(os.environ)
        self.denials, self.negative_controls, self.observations, self.apps = [], [], [], []
        self.finished = False
        self.negative_phase = False
        self.internal_diagnostic_count = 0
        self.rename_diagnostic_count = 0
        self.namespace_diagnostic_count = 0
        self.file_origin_diagnostic_count = 0
        self.startup_diagnostic_count = 0
        require('tkinter' not in sys.modules and '_tkinter' not in sys.modules, 'desktop control must precede the first Tk import')
        native = importlib.import_module('_tkinter')
        require(type(native) is types.ModuleType and native.__file__ == descriptor['runtime']['extension']['path'],
                '_tkinter actual installed origin differs from selected runtime')
        fixture = descriptor.get('owned_host_fixture')
        require(fixture in (None, HOST_FIXTURE_LABEL), 'unsupported owned display fixture context')
        if native.TK_VERSION not in ('8.6', '9.0'):
            raise DesktopUnavailable('selected native Tk ABI is not supported by these controls; this does not show GUI unavailable')
        if native.TK_VERSION == '9.0' and fixture != HOST_FIXTURE_LABEL:
            raise DesktopUnavailable('Tk9 desktop-discovery scope not admitted; this does not show GUI unavailable')
        self.native = native
        original = native.create
        require(isinstance(original, types.BuiltinFunctionType), 'native Tk creation primitive was replaced')
        self.tk = importlib.import_module('tkinter')
        require(self.tk.__file__ == descriptor['runtime']['tkinter']['path'], 'tkinter actual installed origin differs from selected runtime')
        self.tk_class = self.tk.Tk
        constructor = self.tk.Tk.__init__
        self.constructor, self.constructor_code = constructor, constructor.__code__
        self.constructor_globals = constructor.__globals__
        original_destroy = self.tk.Tk.destroy
        self.original_destroy, self.destroy_code = original_destroy, original_destroy.__code__
        self.destroy_globals = original_destroy.__globals__
        self.misc_destroy = self.tk.Misc.destroy
        self.misc_destroy_code, self.misc_destroy_globals = self.misc_destroy.__code__, self.misc_destroy.__globals__
        instructions = tuple(dis.get_instructions(constructor))
        create_indices = [index for index, item in enumerate(instructions)
                          if item.opname == 'LOAD_ATTR' and item.argval == 'create']
        require(len(create_indices) == 1, 'Tk constructor does not have one supported native primitive callsite')
        index = next((index for index in range(create_indices[0] + 1, len(instructions))
                      if instructions[index].opname == 'CALL'), None)
        require(index is not None and index + 1 < len(instructions), 'Tk native primitive callsite is unsupported')
        self.call_offsets = frozenset(range(instructions[index].offset, instructions[index + 1].offset, 2))
        self.thread = threading.get_ident()

        def create(*args, **kwargs):
            self._verify_bindings()
            frame = sys._getframe(1)
            basename = Path(sys.argv[0]).name
            stem, suffix = os.path.splitext(basename)
            basename = stem if suffix in ('.py', '.pyc') else basename
            expected = (None, basename, 'Tk', False, True, True, False, None)
            if (kwargs or args != expected or frame.f_code is not self.constructor_code
                    or frame.f_globals is not self.constructor_globals or frame.f_lasti not in self.call_offsets
                    or type(frame.f_locals.get('self')) is not self.tk.Tk
                    or threading.get_ident() != self.thread
                    or len(self.apps) >= (1 if descriptor.get('startup_diagnostic') else NATIVE_TESTS)
                    or self.finished
                    or any(row['phase'] != 'negative' for row in self.denials)):
                self._deny('uncontrolled-native-interpreter', 'negative' if self.negative_phase else 'functional')
            require(_same_metadata(descriptor['runtime']['extension'], runtime_role='tkinter-extension'),
                    'native extension identity changed in flight')
            if descriptor['authority'] is not None:
                require(_same_metadata(descriptor['authority'], authority=True), 'selected authority metadata changed in flight')
            root = frame.f_locals['self']
            constructor_children = root.__dict__.get('children')
            app = original(descriptor['display'], basename, 'Tk', False, True, False, False, None)
            library = str(app.call('info', 'library'))
            require(library in descriptor['runtime']['resource_roots'], 'actual Tcl library origin is not selected')
            require(str(app.getvar('tcl_version')) == native.TCL_VERSION, 'Tcl native ABI/version differs from extension headers')
            control = _InterpreterControl(self, app, frame.f_locals['self'])
            self.apps.append(control)
            if len(self.apps) == 1:
                control.probes()
            try:
                control.initialize_tk()
            except native.TclError as error:
                if any(row['phase'] != 'negative' for row in self.denials):
                    raise DesktopGuardBlocked('protected Tk startup blocked by a retained guard denial') from error
                raise
            if any(row['phase'] != 'negative' for row in self.denials):
                primary = DesktopGuardBlocked('protected Tk startup recorded a caught guard denial')
                recovery = dict(status='INITIALIZING', boundary='caught-denial-before-native-create-return')
                control.cleanup['initialization_failure_recovery'] = recovery
                try:
                    self._verify_bindings()
                    require(frame is sys._getframe(1) and frame.f_code is self.constructor_code
                            and frame.f_globals is self.constructor_globals and frame.f_lasti in self.call_offsets
                            and frame.f_locals.get('self') is root and control.root is root and control.app is app
                            and self.apps[-1] is control and type(root) is self.tk_class
                            and threading.get_ident() == self.thread and not self.finished and not control.closed
                            and control.bootstrap and control.tk_load_frame is None and control.permission is None
                            and not control.pending and control.ensemble_operation is None
                            and control.force_import_operation is None and control.tk_initialization['status'] == 'PASS'
                            and set(root.__dict__) == {'master', 'children', '_tkloaded', 'tk'}
                            and root.master is None and root.children is constructor_children
                            and type(constructor_children) is dict and not constructor_children
                            and root._tkloaded is False and root.tk is None and root._w == '.'
                            and bool(app.call('info', 'commands', '.')),
                            'caught startup denial has no recoverable in-progress owned root')
                    control._scan()
                    root.tk = app
                    self.tk.Tk.destroy(root)
                    require(control._root_retired(), 'caught startup denial did not retire its genuine owned root')
                    recovery['status'] = 'PASS'
                except BaseException as error:
                    recovery.update(status='FAIL', error_type=type(error).__name__)
                raise primary
            control._scan()
            control.finish_bootstrap()
            control.verify_environment()
            if len(self.apps) == 1:
                control.runtime_probes()
            require(str(app.getvar('tk_version')) == native.TK_VERSION, 'Tk native ABI/version differs from extension headers')
            tk_library = str(app.getvar('tk_library'))
            require(tk_library in descriptor['runtime']['resource_roots'], 'actual Tk library origin is not selected')
            self.observations.append(dict(tcl_version=str(app.getvar('tcl_version')),
                tcl_patchlevel=str(app.getvar('tcl_patchLevel')), tcl_library=library,
                tk_version=str(app.getvar('tk_version')), tk_patchlevel=str(app.getvar('tk_patchLevel')),
                tk_library=tk_library, actual_screen=str(app.call('winfo', 'screen', '.')),
                genuine_tkapp_type=type(app).__name__, guarded_commands=len(control.guarded),
                tk_initialization=control.tk_initialization))
            return app

        self.wrapper = create
        native.create = create

        def destroy(root):
            self._verify_bindings()
            control = next((app for app in self.apps if app.root is root), None)
            if (control is None or type(root) is not self.tk.Tk or root.tk is not control.app
                    or root._w != '.' or threading.get_ident() != self.thread
                    or self.finished or control.closed or control.root_destruction['attempts']):
                self._deny('uncontrolled-owned-root-destruction',
                           'negative' if self.negative_phase else 'functional')
            receipt = control.root_destruction
            receipt.update(status='INITIALIZING', attempts=1)
            try:
                control.verify_traces(refresh_exit=False)
                receipt['live_trace_verification'] = 'PASS'
                result = original_destroy(root)
                receipt['genuine_destroy_returned'] = True
                # The Tk application has ended; only Tcl commands remain safe to query.
                receipt['root_command_absent'] = not bool(control.app.call('info', 'commands', '.'))
                require(receipt['root_command_absent'], 'genuine Tk destruction left its owned root command alive')
                receipt['status'] = 'PASS'
                control._rearm_destroy_traces()
                return result
            except BaseException as error:
                receipt.update(status='FAIL', error_type=type(error).__name__)
                if receipt['trace_rearm']['status'] == 'INITIALIZING':
                    receipt['trace_rearm']['status'] = 'FAIL'
                raise

        self.destroy_wrapper = destroy
        self.destroy_wrapper_code = destroy.__code__
        self.tk.Tk.destroy = destroy
        sys.addaudithook(self._audit)
        self.negative_phase = True
        try:
            for label, arguments in (('direct-empty', ()),
                    ('direct-wantTk', (None, 'desktop-probe', 'Tk', False, True, True, False, None)),
                    ('direct-Tcl-only', (None, 'desktop-probe', 'Tk', False, True, False, False, None))):
                before = len(self.denials)
                try:
                    native.create(*arguments)
                except native.TclError:
                    require(len(self.denials) == before + 1, 'native primitive negative missed its caller control')
                else:
                    raise DesktopBlocked('uncontrolled native primitive request escaped')
                self.negative_controls.append(label)
            for root in (None, object()):
                before = len(self.denials)
                try:
                    self.tk.Tk.destroy(root)
                except native.TclError:
                    require(len(self.denials) == before + 1,
                            'unowned destructor negative missed its identity control')
                else:
                    raise DesktopBlocked('unowned native root destruction escaped')
                self.negative_controls.append('unowned-genuine-root-destruction')
        finally:
            self.negative_phase = False

    def _audit(self, event, args):
        if event == 'import' and args[0] == '_tkinter':
            self._deny('native-extension-reimport', 'functional')

    def _deny(self, category, phase, diagnostic=None):
        require(len(self.denials) < MAX_DENIALS, 'desktop denial evidence overflow')
        row = dict(category=category, phase=phase)
        if diagnostic is not None:
            row['diagnostic'] = diagnostic
        self.denials.append(row)
        if phase != 'negative' and category == 'uncontrolled-native-interpreter':
            raise DesktopGuardBlocked('protected Tk startup blocked after a retained guard denial')
        raise self.native.TclError('desktop effect denied: ' + category)

    def _verify_bindings(self):
        require(sys.modules.get('_tkinter') is self.native and self.native.create is self.wrapper,
                'native primitive module or wrapper binding changed')
        require(sys.modules.get('tkinter') is self.tk and self.tk.Tk is self.tk_class
                and self.tk.Tk.__init__ is self.constructor
                and self.constructor.__code__ is self.constructor_code
                and self.constructor.__globals__ is self.constructor_globals
                and self.constructor_globals.get('_tkinter') is self.native,
                'genuine Tk constructor binding changed')
        require(self.tk.Tk.destroy is self.destroy_wrapper
                and self.destroy_wrapper.__code__ is self.destroy_wrapper_code
                and self.original_destroy.__code__ is self.destroy_code
                and self.original_destroy.__globals__ is self.destroy_globals
                and self.destroy_globals.get('Misc') is self.tk.Misc
                and self.tk.Misc.destroy is self.misc_destroy
                and self.misc_destroy.__code__ is self.misc_destroy_code
                and self.misc_destroy.__globals__ is self.misc_destroy_globals,
                'genuine Tk destruction binding changed')

    def finish(self):
        self._verify_bindings()
        cleanup_errors = []
        for app in self.apps:
            try:
                cleanup_errors.extend(app.finish())
            except BaseException as error:
                app.cleanup['status'] = 'FAIL'
                cleanup_errors.append(type(error).__name__ + ': owned native root cleanup failed')
        self.finished = True
        runtime = self.descriptor['runtime']
        require(_same_metadata(runtime['extension'], runtime_role='tkinter-extension')
                and _same_metadata(runtime['tkinter'], runtime_role='tkinter-source'),
                'selected Tk extension/source identity changed in flight')
        require(_same_interpreter(self.descriptor['interpreter'])
                and _same_interpreter(self.descriptor['console_interpreter'])
                and _same_metadata(self.descriptor['console']), 'desktop executable/console identity changed in flight')
        for row in runtime['resources'].values():
            require(_same_metadata(row, resource_roots=runtime['resource_roots']),
                    'Tcl/Tk resource identity changed in flight')
        for row in runtime['resource_directories'].values():
            require(_same_metadata(row, directory=True), 'Tcl/Tk resource directory identity changed in flight')
        functional_denials = [row for row in self.denials if row['phase'] != 'negative']
        required = 1 if self.descriptor.get('startup_diagnostic') else NATIVE_TESTS
        return dict(schema=SCHEMA, status='PASS' if not cleanup_errors and not functional_denials
                    and len(self.apps) == required else 'FAIL',
            original_display=self.descriptor['original_display'], selected_display=self.descriptor['display'],
            owned_host_fixture=self.descriptor.get('owned_host_fixture'),
            interpreter=self.descriptor['interpreter'], console=self.descriptor['console'],
            console_interpreter=self.descriptor['console_interpreter'],
            console_interpreter_comparison=self.descriptor['console_interpreter_comparison'],
            soabi=sysconfig.get_config_var('SOABI'), native_extension=runtime['extension'],
            tkinter=runtime['tkinter'], native_primitive_audit='not available; no such audit event is assumed',
            trust_limit=self.descriptor['trust_limit'], runtime_observations=self.observations,
            tk_initializations=[app.tk_initialization for app in self.apps if app.tk_initialization is not None],
            negative_controls=self.negative_controls, denials=self.denials,
            loaded_native_origins=_validate_native_origins(_loaded_native_origins(), self.descriptor),
            native_interpreters=len(self.apps), required_native_interpreters=required,
            startup_diagnostic_only=bool(self.descriptor.get('startup_diagnostic')),
            cleanup_errors=cleanup_errors, authority_policy=self.descriptor['authority_policy'])


def install(descriptor, *, guard=None):
    """Install after guarded site initialization, before product/test Tk imports."""
    return DesktopControl(descriptor, guard=guard)
