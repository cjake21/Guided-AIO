"""Scratch-only operator additions to the retained effect and native-init guards."""

import ast
import builtins
import dis
import hashlib
from contextlib import redirect_stdout
import errno
import importlib.metadata as metadata
import importlib._bootstrap_external as external
import json
import fcntl
import os
import posix
from pathlib import Path
import stat
import sys
import types
import zipfile

from pi_guard import CheckGuard, require
from behavior_guard import ActiveModules, BehaviorGuard
from ctypes_initialization import CtypesInitialization, _call_offsets
from pi_target import utc_source_policy, utc_identity_matches, numpy_metadata_snapshot, read_numpy_metadata


DESKTOP_MAPS_LIMIT = 39  # One read for each of 38 reviewed roots, then final verification.


class CandidateGuard(CheckGuard):
    MODE = 'offline-pixhawk'
    def __init__(self, files, directories, native, stdlib, package_site, scratch, public_utc,
                 runtime_profile, scipy_rpath_absence, graphical=False, numpy_metadata=None):
        super().__init__(files, directories, native)
        self.bound_hashes = dict(files)
        self.stdlib, self.site, self.scratch = Path(stdlib), Path(package_site), Path(scratch)
        self.graphical = graphical
        self.public_utc = public_utc
        self.verify_utc()
        self.scipy_rpath_absence = scipy_rpath_absence
        self.verify_science_absence()
        profiles = ('compatible-host-cpython31116-no-startup-hooks', 'compatible-pi-cpython3112-semantic-startup')
        require(runtime_profile in profiles, 'unreviewed runtime/native initialization profile')
        paths = (str(self.stdlib / 'ctypes/__init__.py'), str(self.site / 'numpy/_core/_internal.py'),
                 str(self.site / 'numpy/testing/_private/utils.py'))
        self.selected = {}
        self.METADATA = ActiveModules()
        self.sources, self.expected = {}, {}
        for path in paths:
            info = self.real_lstat(path)
            require(path in self.files and self.directory_identity(str(Path(path).parent)) is not None
                    and stat.S_ISREG(info.st_mode) and info.st_size <= 1024 * 1024,
                    'bounded ordinary admitted initialization source required')
            raw = Path(path).read_bytes()
            require(len(raw) == info.st_size and self.file_identity(self.real_lstat(path)) == self.file_identity(info),
                    'native initialization source changed while binding')
            self.selected[path] = hashlib.sha256(raw).hexdigest()
            self.sources[path] = raw
            self.expected[path] = compile(raw, path, 'exec', dont_inherit=True)
        self.ctypes_sha = self.selected[paths[0]]
        self.ctypes_init = CtypesInitialization(self)
        self.loader_exec = external._LoaderBasics.exec_module
        self.loader_exec_code = self.loader_exec.__code__
        self.loader_type = external.SourceFileLoader
        self.home_offsets = None
        self.real_flock = fcntl.flock
        self.allowance_negatives = []
        self.diagnostic_stream = sys.stderr
        self.effect_diagnostics = []
        self.readers = []
        self.flock_methods = {}
        self.desktop_reader = None
        self.desktop_maps_count = 0
        self.desktop_maps_negatives = []
        self.desktop_environment = None
        self.desktop_environment_count = 0
        self.desktop_environment_negatives = []
        self.desktop_environment_originals = (os.putenv, os.unsetenv)
        require(os.putenv is posix.putenv and os.unsetenv is posix.unsetenv
                and all(type(function) is types.BuiltinFunctionType and function.__module__ == 'posix'
                        for function in self.desktop_environment_originals),
                'canonical native environment primitives required')
        self.secure_input = str(self.site / 'satgs/data/operator_tle.csv')
        require(self.secure_input in files, 'packaged TLE must be bound')
        self.secure_identity = self.file_identity(self.real_lstat(self.secure_input))
        self.secure_chain = self.directory_identity(str(Path(self.secure_input).parent))
        require(self.secure_chain is not None, 'ordinary packaged TLE ancestors required')
        self.metadata_zip = str(self.stdlib.parent / 'python311.zip')
        self.metadata_chain = self.directory_identity(str(Path(self.metadata_zip).parent))
        require(self.metadata_chain is not None, 'ordinary metadata zip parent required')
        self.metadata_functions = (metadata.FastPath.children, metadata.FastPath.zip_children,
                                   zipfile.ZipFile.__init__, zipfile.CompleteDirs.make.__func__,
                                   zipfile.Path.__init__)
        self.metadata_codes = tuple(item.__code__ for item in self.metadata_functions)
        self.metadata_counts = {'os.listdir': 0, 'open': 0}
        self.metadata_negatives = []
        self.metadata_pending = None
        require(self.metadata_missing(), 'reviewed metadata zip must genuinely be absent')
        self.numpy_metadata = numpy_metadata_snapshot(self.site) if numpy_metadata is None else numpy_metadata
        require(self.numpy_metadata == numpy_metadata_snapshot(self.site), 'selected NumPy metadata binding changed')
        require(self.numpy_metadata['path'] not in self.files, 'optional NumPy metadata must not be generally readable')
        self.numpy_code, self.numpy_offsets = None, frozenset()
        self.numpy_reads, self.numpy_receipts, self.numpy_reading = 0, [], None
        self.numpy_original_reader = metadata.PathDistribution.read_text
        self.numpy_original_reader_code = self.numpy_original_reader.__code__

        def read_text(distribution, filename):
            if filename != 'direct_url.json':
                return self.numpy_original_reader(distribution, filename)
            caller = sys._getframe(1)
            if not self.numpy_metadata_target(distribution):
                self.deny('numpy-optional-metadata-target')
            if not self.numpy_metadata_eligible(distribution, filename, caller):
                self.deny('numpy-optional-metadata-caller')
            self.numpy_reads += 1
            receipt = dict(path=self.numpy_metadata['path'], state=self.numpy_metadata['kind'],
                           bytes=self.numpy_metadata.get('identity', [None] * 4)[3])
            self.numpy_receipts.append(receipt)
            self.numpy_reading = sys._getframe()
            try:
                value = read_numpy_metadata(self.numpy_metadata)
                if value is not None:
                    try:
                        parsed = json.loads(value)
                    except (ValueError, TypeError):
                        receipt['content'] = 'malformed-json'
                    else:
                        receipt['content'] = 'json-object' if type(parsed) is dict else 'non-object-json'
                return value
            except OSError as error:
                receipt.update(state='access-error', error_type=type(error).__name__, errno=error.errno)
                raise
            except BaseException as error:
                receipt.update(state='read-error', error_type=type(error).__name__)
                raise
            finally:
                self.numpy_reading = None

        self.numpy_reader, self.numpy_reader_code = read_text, read_text.__code__
        metadata.PathDistribution.read_text = read_text

    def bind_exec(self, code, caller):
        BehaviorGuard.bind_exec(self, code, caller)
        path = str(self.site / 'numpy/testing/_private/utils.py')
        if code.co_filename != path:
            return
        tree = ast.parse(self.sources[path], filename=path)
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute) and node.func.attr == 'read_text'
                 and len(node.args) == 1 and not node.keywords and isinstance(node.args[0], ast.Constant)
                 and node.args[0].value == 'direct_url.json']
        require(len(calls) == 1 and self.numpy_code is None, 'one genuine NumPy optional metadata call required')
        self.numpy_code, self.numpy_offsets = code, _call_offsets(code, calls[0])

    def numpy_metadata_target(self, distribution):
        path = vars(distribution).get('_path') if type(distribution) is metadata.PathDistribution else None
        return type(path) is type(self.site) and path == Path(self.numpy_metadata['path']).parent

    def numpy_metadata_eligible(self, distribution, filename, caller):
        if (caller is None or self.numpy_reads >= 1 or filename != 'direct_url.json'
                or not self.numpy_metadata_target(distribution)
                or metadata.PathDistribution.read_text is not self.numpy_reader
                or self.numpy_reader.__code__ is not self.numpy_reader_code
                or self.numpy_original_reader.__code__ is not self.numpy_original_reader_code
                or caller.f_code is not self.numpy_code or caller.f_lasti not in self.numpy_offsets):
            return False
        namespace = self.METADATA.exact_binding(self.METADATA.active_modules, self.numpy_code)
        return (namespace is not None and caller.f_globals is namespace
                and namespace.get('__file__') == str(self.site / 'numpy/testing/_private/utils.py'))

    def numpy_metadata_open(self, args, caller):
        if (caller is None or caller.f_code is not CheckGuard.tracked_open.__code__
                or caller.f_globals is not CheckGuard.tracked_open.__globals__
                or caller.f_locals.get('self') is not self):
            return False
        caller = caller.f_back
        parent = caller.f_back if caller is not None else None
        return (self.numpy_reading is not None and parent is self.numpy_reading
                and caller is not None
                and caller.f_code is read_numpy_metadata.__code__
                and caller.f_globals is read_numpy_metadata.__globals__
                and caller.f_locals.get('row') is self.numpy_metadata
                and parent.f_code is self.numpy_reader_code and parent.f_globals is globals()
                and args == (self.numpy_metadata['path'], None, os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK))

    def verify_utc(self):
        for row in self.public_utc['identities']:
            path = Path(row['path'])
            info = path.lstat()
            actual = dict(path=str(path), device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
                          uid=info.st_uid, gid=info.st_gid, bytes=info.st_size,
                          mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns,
                          link=os.readlink(path) if stat.S_ISLNK(info.st_mode) else None)
            require(utc_identity_matches(row, actual), 'public UTC input identity changed')
        raw = Path(self.public_utc['resolved']).read_bytes()
        utc_source_policy(raw)

    def verify_science_absence(self):
        if self.scipy_rpath_absence is None:
            return
        require(self.scipy_rpath_absence['path'] ==
                '/opt/_internal/cpython-3.11.10/lib/python3.11/site-packages/scipy_openblas32/lib',
                'unreviewed scientific native RPATH')
        for row in self.scipy_rpath_absence['ancestors']:
            try:
                info = self.real_lstat(row['path'])
            except FileNotFoundError:
                require(row['identity'] is None, 'scientific native RPATH ancestor disappeared')
            else:
                require([info.st_dev, info.st_ino, info.st_mode] == row['identity']
                        and stat.S_ISDIR(info.st_mode), 'scientific native RPATH ancestor changed')
        require(not os.path.lexists(self.scipy_rpath_absence['path']), 'scientific native RPATH appeared')

    def deny(self, event):
        if self.phase != 'negative' and len(self.effect_diagnostics) < 16:
            frame = sys._getframe(1)
            frames, arguments = [], None
            for unused in range(24):
                if frame is None:
                    break
                filename = frame.f_code.co_filename
                bound = filename in self.bound_hashes
                frames.append(dict(source=filename if bound else 'sha256:' + hashlib.sha256(filename.encode()).hexdigest(),
                                   sha256=self.bound_hashes.get(filename), function=frame.f_code.co_name if bound else None,
                                   line=frame.f_lineno, offset=frame.f_lasti))
                if (frame.f_code is CandidateGuard.audit.__code__ and frame.f_globals is globals()
                        and frame.f_locals.get('self') is self):
                    arguments = frame.f_locals.get('args')
                frame = frame.f_back
            row = dict(event=event, frames=frames)
            if arguments and isinstance(arguments[0], (str, bytes)):
                raw = os.fsdecode(arguments[0])
                path = os.path.abspath(raw)
                public = path in ('/etc/localtime', '/etc/timezone') or path.startswith(('/usr/share/zoneinfo/', '/usr/share/locale/'))
                controlled = path in self.bound_hashes or path == str(self.scratch) or path.startswith(str(self.scratch) + '/')
                row['path'] = path if public or controlled else 'sha256:' + hashlib.sha256(os.fsencode(raw)).hexdigest()
                row['path_bytes'] = len(os.fsencode(raw))
                if event == 'open' and len(arguments) == 3:
                    row.update(mode=arguments[1], flags=arguments[2])
            self.effect_diagnostics.append(row)
            print('OPERATOR_DENIAL_DIAGNOSTIC ' + json.dumps(row, sort_keys=True), file=self.diagnostic_stream, flush=True)
        with redirect_stdout(self.diagnostic_stream):
            return super().deny(event)

    def bind_readers(self):
        require(not self.readers, 'reader binding replay')
        for name, attribute in (
                ('satgs.deployment_cli', 'read_regular_bytes'),
                ('satgs.station_location_cli', '_write_new_artifact'),
                ('satgs.operator_activity', 'open_workspace'),
                ('satgs.operator_core', '_write_new'),
                ('satgs.operator_core', 'initialize_workspace')):
            owner = sys.modules.get(name)
            function = getattr(owner, attribute, None)
            origin = str(self.site / (name.replace('.', '/') + '.py'))
            require(type(owner) is types.ModuleType and type(function) is types.FunctionType
                    and function.__globals__ is vars(owner) and function.__code__.co_filename == origin
                    and vars(owner).get('__file__') == origin and origin in self.files
                    and type(vars(owner).get('__loader__')) is self.loader_type,
                    'genuine installed reader required before test patching')
            self.readers.append((owner, function, function.__code__, attribute))
        owner = sys.modules.get('satgs.operator_activity')
        lease = getattr(owner, 'StationLease', None)
        origin = str(self.site / 'satgs/operator_activity.py')
        tree = ast.parse(Path(origin).read_bytes(), filename=origin)
        classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'StationLease']
        require(len(classes) == 1 and type(lease) is type and lease.__module__ == owner.__name__,
                'genuine installed station lease required')
        for operation, attribute, expression in (
                (fcntl.LOCK_EX | fcntl.LOCK_NB, 'acquire', 'fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)'),
                (fcntl.LOCK_UN, 'release', 'fcntl.flock(descriptor, fcntl.LOCK_UN)')):
            function = vars(lease).get(attribute)
            definitions = [node for node in classes[0].body
                           if isinstance(node, ast.FunctionDef) and node.name == attribute]
            require(len(definitions) == 1 and type(function) is types.FunctionType
                    and function.__globals__ is vars(owner) and function.__code__.co_filename == origin,
                    'original installed station lease method required')
            calls = [node for node in ast.walk(definitions[0])
                     if isinstance(node, ast.Call) and ast.unparse(node) == expression]
            require(len(calls) == 1, 'one station lock callsite required')
            self.flock_methods[operation] = (owner, lease, function, function.__code__,
                                              _call_offsets(function.__code__, calls[0]))

    def bind_desktop(self, function):
        require(self.graphical and self.desktop_reader is None, 'desktop metadata binding requires one graphical owner')
        owner = sys.modules.get('operator_desktop')
        origin = str(Path(__file__).resolve().parent / 'desktop_display.py')
        require(type(owner) is types.ModuleType and type(function) is types.FunctionType
                and vars(owner).get('_loaded_native_origins') is function
                and function.__globals__ is vars(owner) and function.__code__.co_filename == origin
                and vars(owner).get('__file__') == origin and origin in self.files,
                'original bound desktop metadata inspector required')
        tree = ast.parse(Path(origin).read_bytes(), filename=origin)
        definitions = [node for node in tree.body
                       if isinstance(node, ast.FunctionDef) and node.name == '_loaded_native_origins']
        require(len(definitions) == 1, 'one desktop metadata inspector required')
        calls = [node for node in ast.walk(definitions[0])
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'open'
                 and 1 <= len(node.args) <= 2 and isinstance(node.args[0], ast.Constant)
                 and node.args[0].value == '/proc/self/maps'
                 and (len(node.args) == 1 or (isinstance(node.args[1], ast.Constant)
                                             and node.args[1].value in ('r', 'rb', 'rt')))]
        require(len(calls) == 1, 'one readonly native metadata open callsite required')
        offsets = set(_call_offsets(function.__code__, calls[0]))
        positions = (calls[0].lineno, calls[0].end_lineno, calls[0].col_offset, calls[0].end_col_offset)
        instructions = tuple(dis.get_instructions(function, show_caches=True))
        for index, instruction in enumerate(instructions):
            if instruction.opname == 'PRECALL' and tuple(instruction.positions) == positions:
                offsets.add(instruction.offset)
                for following in instructions[index + 1:]:
                    if following.opname != 'CACHE':
                        break
                    offsets.add(following.offset)
        self.desktop_reader = (owner, function, function.__code__, frozenset(offsets), builtins.open)

    def desktop_maps_eligible(self, args, caller):
        if (self.desktop_reader is None or caller is None or self.desktop_maps_count >= DESKTOP_MAPS_LIMIT
                or len(args) != 3 or type(args[0]) is not str or args[0] != '/proc/self/maps'
                or args[1:] != ('r', os.O_CLOEXEC)):
            return False
        owner, function, code, offsets, opening = self.desktop_reader
        namespace = vars(owner)
        return (self.graphical and sys.modules.get('operator_desktop') is owner
                and function.__code__ is code and function.__globals__ is namespace
                and namespace.get('_loaded_native_origins') is function
                and namespace.get('__file__') == code.co_filename
                and caller.f_code is code and caller.f_globals is namespace and caller.f_lasti in offsets
                and builtins.open is opening and namespace.get('open', opening) is opening)

    def desktop_maps(self, args, caller):
        if not self.desktop_maps_eligible(args, caller):
            return False
        def changed(**values):
            return types.SimpleNamespace(**dict(
                {name: getattr(caller, name) for name in ('f_code', 'f_globals', 'f_lasti')}, **values))
        for label, frame in (
                ('copied-code', changed(f_code=caller.f_code.replace())),
                ('copied-namespace', changed(f_globals=dict(caller.f_globals))),
                ('wrong-callsite', changed(f_lasti=-1)), ('wrong-caller', None)):
            require(not self.desktop_maps_eligible(args, frame), 'desktop metadata caller negative failed')
            if label not in self.desktop_maps_negatives:
                self.desktop_maps_negatives.append(label)
        for label, arguments in (
                ('other-proc-path', ('/proc/self/status', *args[1:])),
                ('file-descriptor', (0, *args[1:])), ('write-mode', (args[0], 'w', args[2])),
                ('write-flags', (args[0], args[1], os.O_RDWR))):
            require(not self.desktop_maps_eligible(arguments, caller), 'desktop metadata target negative failed')
            if label not in self.desktop_maps_negatives:
                self.desktop_maps_negatives.append(label)
        count = self.desktop_maps_count
        try:
            for probe_count, allowed in ((DESKTOP_MAPS_LIMIT - 1, True),
                                         (DESKTOP_MAPS_LIMIT, False),
                                         (DESKTOP_MAPS_LIMIT + 1, False)):
                self.desktop_maps_count = probe_count
                require(self.desktop_maps_eligible(args, caller) is allowed,
                        'desktop metadata budget boundary failed')
        finally:
            self.desktop_maps_count = count
        if 'budget' not in self.desktop_maps_negatives:
            self.desktop_maps_negatives.append('budget')
        self.desktop_maps_count += 1
        return True

    def bind_desktop_environment(self, function):
        require(self.graphical and self.desktop_environment is None,
                'native environment correction requires one graphical binding')
        owner = sys.modules.get('operator_desktop')
        origin = str(Path(__file__).resolve().parent / 'desktop_display.py')
        require(type(owner) is types.ModuleType and type(function) is types.FunctionType
                and vars(owner).get('_restore_native_environment') is function
                and function.__globals__ is vars(owner) and function.__code__.co_filename == origin
                and vars(owner).get('__file__') == origin and origin in self.files,
                'original bound native environment correction required')
        classes = tuple(vars(owner).get(name) for name in ('DesktopControl', '_InterpreterControl'))
        require(all(type(item) is type and item.__module__ == owner.__name__ for item in classes),
                'original desktop control classes required')
        initializer = vars(classes[1]).get('__init__')
        require(type(initializer) is types.FunctionType and initializer.__globals__ is vars(owner)
                and initializer.__code__.co_filename == origin, 'original native control initializer required')
        callbacks = [code for code in initializer.__code__.co_consts
                     if isinstance(code, types.CodeType) and code.co_name == 'environment_trace']
        require(len(callbacks) == 1 and callbacks[0].co_freevars == ('self',),
                'one finite native environment callback required')
        tree = ast.parse(Path(origin).read_bytes(), filename=origin)
        definitions = [node for node in tree.body
                       if isinstance(node, ast.FunctionDef) and node.name == '_restore_native_environment']
        require(len(definitions) == 1, 'one native environment correction helper required')
        offsets = {}
        for event, expression in (('os.putenv', 'os.putenv(key, original[key])'),
                                  ('os.unsetenv', 'os.unsetenv(key)')):
            calls = [node for node in ast.walk(definitions[0])
                     if isinstance(node, ast.Call) and ast.unparse(node) == expression]
            require(len(calls) == 1, 'one exact native environment correction callsite required')
            offsets[event] = _call_offsets(function.__code__, calls[0])
        self.desktop_environment = (owner, function, function.__code__, classes, initializer,
                                    initializer.__code__, callbacks[0], offsets, dict(os.environ))

    def desktop_environment_eligible(self, event, args, caller):
        if (self.desktop_environment is None or caller is None or self.desktop_environment_count >= 64
                or event not in ('os.putenv', 'os.unsetenv')):
            return False
        owner, function, code, classes, initializer, init_code, callback_code, offsets, snapshot = self.desktop_environment
        namespace = vars(owner)
        interpreter = caller.f_locals.get('interpreter')
        parent = caller.f_back
        if (not self.graphical or sys.modules.get('operator_desktop') is not owner
                or namespace.get('_restore_native_environment') is not function
                or function.__code__ is not code or function.__globals__ is not namespace
                or namespace.get('__file__') != code.co_filename
                or tuple(namespace.get(name) for name in ('DesktopControl', '_InterpreterControl')) != classes
                or vars(classes[1]).get('__init__') is not initializer or initializer.__code__ is not init_code
                or caller.f_code is not code or caller.f_globals is not namespace or caller.f_lasti not in offsets[event]
                or type(interpreter) is not classes[1] or type(interpreter.owner) is not classes[0]
                or interpreter.owner.guard is not self or interpreter.owner.environment_snapshot != snapshot
                or caller.f_locals.get('original') is not interpreter.owner.environment_snapshot
                or not interpreter.restoring_environment or parent is None):
            return False
        callback = interpreter.environment_callback
        key = caller.f_locals.get('key')
        if (type(callback) is not types.FunctionType or callback.__code__ is not callback_code
                or callback.__globals__ is not namespace or len(callback.__closure__ or ()) != 1
                or callback.__closure__[0].cell_contents is not interpreter
                or parent.f_code is not callback_code or parent.f_globals is not namespace
                or parent.f_locals.get('self') is not interpreter or parent.f_locals.get('element') != key
                or parent.f_locals.get('token') != interpreter.trace_token
                or interpreter.environment_restoration != (parent, key) or type(key) is not str
                or not key or '=' in key or '\0' in key
                or os.putenv is not self.desktop_environment_originals[0]
                or posix.putenv is not self.desktop_environment_originals[0]
                or os.unsetenv is not self.desktop_environment_originals[1]
                or posix.unsetenv is not self.desktop_environment_originals[1]
                or namespace.get('os') is not os):
            return False
        expected = (os.fsencode(key), os.fsencode(snapshot[key])) if key in snapshot else (os.fsencode(key),)
        if event != ('os.putenv' if key in snapshot else 'os.unsetenv') or len(args) != len(expected):
            return False
        return all(type(value) in (str, bytes) and os.fsencode(value) == wanted
                   for value, wanted in zip(args, expected))

    def desktop_environment_correction(self, event, args, caller):
        if not self.desktop_environment_eligible(event, args, caller):
            return False
        def changed(**values):
            return types.SimpleNamespace(**dict({name: getattr(caller, name)
                for name in ('f_code', 'f_globals', 'f_lasti', 'f_locals', 'f_back')}, **values))
        cases = (('copied-code', changed(f_code=caller.f_code.replace())),
                 ('copied-namespace', changed(f_globals=dict(caller.f_globals))),
                 ('wrong-callsite', changed(f_lasti=-1)), ('outside-callback', changed(f_back=None)),
                 ('wrong-key', changed(f_locals=dict(caller.f_locals, key='__satgs_unbound_environment_key__'))),
                 ('copied-snapshot', changed(f_locals=dict(caller.f_locals,
                                                        original=dict(caller.f_locals['original'])))))
        for label, frame in cases:
            require(not self.desktop_environment_eligible(event, args, frame),
                    'native environment correction identity negative failed')
            if label not in self.desktop_environment_negatives:
                self.desktop_environment_negatives.append(label)
        wrong = (b'__satgs_unbound_environment_key__', *args[1:])
        require(not self.desktop_environment_eligible(event, wrong, caller),
                'native environment correction target negative failed')
        if event == 'os.putenv':
            require(not self.desktop_environment_eligible(event, (args[0], b'__satgs_unbound_value__'), caller),
                    'native environment correction value negative failed')
        count = self.desktop_environment_count
        try:
            self.desktop_environment_count = 64
            require(not self.desktop_environment_eligible(event, args, caller),
                    'native environment correction budget bypassed')
        finally:
            self.desktop_environment_count = count
        for label in ('wrong-target', 'wrong-value', 'budget'):
            if label not in self.desktop_environment_negatives:
                self.desktop_environment_negatives.append(label)
        self.desktop_environment_count += 1
        return True

    def metadata_missing(self):
        if self.directory_identity(str(Path(self.metadata_zip).parent)) != self.metadata_chain:
            return False
        try:
            self.real_lstat(self.metadata_zip)
        except FileNotFoundError as error:
            return error.errno == errno.ENOENT and error.filename == self.metadata_zip
        except OSError:
            pass
        return False

    def metadata_identity(self, frame, index):
        function = self.metadata_functions[index]
        return (frame is not None and frame.f_code is self.metadata_codes[index]
                and frame.f_globals is function.__globals__ and function.__code__ is self.metadata_codes[index])

    def metadata_eligible(self, event, args, caller):
        current = (metadata.FastPath.children, metadata.FastPath.zip_children,
                   zipfile.ZipFile.__init__, zipfile.CompleteDirs.make.__func__, zipfile.Path.__init__)
        if (current != self.metadata_functions or args[0] != self.metadata_zip
                or sum(self.metadata_counts.values()) >= 4096 or not self.metadata_missing()):
            return False
        if event == 'os.listdir':
            frame = caller
        elif event == 'open':
            if args[1:] != ('r', os.O_CLOEXEC) or self.metadata_pending is None:
                return False
            frame = caller
            for index in (2, 3, 4, 1):
                if not self.metadata_identity(frame, index):
                    return False
                if index == 2 and (frame.f_locals.get('file') != self.metadata_zip
                                   or frame.f_locals.get('mode') != 'r'
                                   or frame.f_locals.get('filemode') != 'rb'):
                    return False
                frame = frame.f_back
        else:
            return False
        if not self.metadata_identity(frame, 0):
            return False
        instance = frame.f_locals.get('self')
        return (type(instance) is metadata.FastPath and instance.root == self.metadata_zip
                and (event != 'open' or instance is self.metadata_pending))

    def metadata_absence(self, event, args, caller):
        if not self.metadata_eligible(event, args, caller):
            return False
        changed = lambda **values: types.SimpleNamespace(**dict(
            {name: getattr(caller, name) for name in ('f_code', 'f_globals', 'f_locals', 'f_back')}, **values))
        for label, frame in (('copied-code', changed(f_code=caller.f_code.replace())),
                             ('copied-namespace', changed(f_globals=dict(caller.f_globals))),
                             ('wrong-caller', None)):
            require(not self.metadata_eligible(event, args, frame), 'metadata absence negative failed')
            if event + ':' + label not in self.metadata_negatives:
                self.metadata_negatives.append(event + ':' + label)
        require(not self.metadata_eligible(event, ('/__satgs_guard_outside__', *args[1:]), caller),
                'metadata outside path admitted')
        chain = self.metadata_chain
        try:
            self.metadata_chain = None
            require(not self.metadata_eligible(event, args, caller), 'metadata stale ancestor admitted')
        finally:
            self.metadata_chain = chain
        count = self.metadata_counts[event]
        try:
            self.metadata_counts[event] = 4096
            require(not self.metadata_eligible(event, args, caller), 'metadata absence budget bypassed')
        finally:
            self.metadata_counts[event] = count
        if event == 'open':
            require(not self.metadata_eligible(event, (args[0], 'w', os.O_WRONLY), caller),
                    'metadata write admitted')
            self.metadata_pending = None
            require(not self.metadata_eligible(event, args, caller), 'metadata open replay admitted')
        else:
            self.metadata_pending = caller.f_locals['self']
        self.metadata_counts[event] += 1
        for label in ('outside-path', 'stale-ancestor', 'budget', *(('wrong-flags', 'replay') if event == 'open' else ())):
            if event + ':' + label not in self.metadata_negatives:
                self.metadata_negatives.append(event + ':' + label)
        raise FileNotFoundError(errno.ENOENT, 'bound metadata zip absent without access', self.metadata_zip)

    def output_path(self, value, directory_fd=None):
        path = Path(self.path(value, directory_fd))
        return path == self.scratch or self.scratch in path.parents

    def reader_target(self, path, flags, directory_fd=None):
        allowed = (os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                   os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        return flags in allowed and Path(self.path(path, directory_fd)) in self.scratch.parents

    def reader_identity(self, frame):
        for owner, function, code, unused in self.readers:
            if (type(function) is types.FunctionType and sys.modules.get(owner.__name__) is owner
                    and function.__code__ is code and frame.f_code is code and frame.f_globals is vars(owner)):
                return True
        return False

    def secure_reader_target(self, args, directory_fd, frame):
        if (not self.reader_identity(frame) or frame.f_code.co_name != 'read_regular_bytes'
                or type(frame.f_locals.get('path')) is not str
                or os.path.abspath(frame.f_locals['path']) != self.secure_input
                or args[2] != os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
                or Path(self.path(args[0], directory_fd)) not in Path(self.secure_input).parents):
            return False
        return (self.directory_identity(str(Path(self.secure_input).parent)) == self.secure_chain
                and self.file_identity(self.real_lstat(self.secure_input)) == self.secure_identity)

    def reader_walk(self, args, directory_fd):
        frame = sys._getframe(1)
        for unused in range(8):
            if frame is None:
                break
            if self.reader_identity(frame) and (self.reader_target(args[0], args[2], directory_fd)
                                                or self.secure_reader_target(args, directory_fd, frame)):
                require(not self.reader_identity(types.SimpleNamespace(f_code=frame.f_code.replace(), f_globals=frame.f_globals)),
                        'reader copied-code caller admitted')
                require(not self.reader_identity(types.SimpleNamespace(f_code=frame.f_code, f_globals=dict(frame.f_globals))),
                        'reader copied-namespace caller admitted')
                if self.secure_reader_target(args, directory_fd, frame):
                    require(not self.secure_reader_target((args[0], args[1], os.O_RDWR), directory_fd, frame),
                            'secure input writing walk admitted')
                    require(not self.secure_reader_target(('/__satgs_guard_outside__', *args[1:]), None, frame),
                            'secure input outside walk admitted')
                    changed = types.SimpleNamespace(f_code=frame.f_code, f_globals=frame.f_globals,
                                                    f_locals=dict(frame.f_locals, path='/__satgs_guard_outside__'))
                    require(not self.secure_reader_target(args, directory_fd, changed), 'secure input provenance lost')
                    identity = self.secure_identity
                    try:
                        self.secure_identity = ()
                        require(not self.secure_reader_target(args, directory_fd, frame), 'secure input stale identity admitted')
                    finally:
                        self.secure_identity = identity
                    for label in ('secure-input-wrong-flags', 'secure-input-outside-path',
                                  'secure-input-provenance', 'secure-input-stale-identity'):
                        if label not in self.allowance_negatives:
                            self.allowance_negatives.append(label)
                return True
            frame = frame.f_back
        return False

    def audit(self, event, args):
        if event in ('os.putenv', 'os.unsetenv') and self.graphical:
            if self.desktop_environment_correction(event, args, sys._getframe(1)):
                return
            self.deny('desktop-native-environment:' + event)
        if event == 'import' and len(args) > 1 and args[1] is not None and str(args[1]).endswith('.so'):
            self.verify_science_absence()
        if event in ('os.listdir', 'open'):
            self.metadata_absence(event, args, sys._getframe(1))
        caller = sys._getframe(1) if event in ('exec', 'ctypes.dlopen') else None
        if event == 'exec':
            self.bind_exec(args[0], caller)
        if event == 'ctypes.dlopen' and self.ctypes_init.permit(event, args, caller):
            return
        if event == 'import' and not self.graphical and str(args[0]).split('.')[0] in ('tkinter', '_tkinter'):
            self.deny('headless-tk-import')
        if event == 'open':
            if self.numpy_metadata_open(args, sys._getframe(1)):
                return
            if self.desktop_maps(args, sys._getframe(1)):
                return
            pending = getattr(self.context, 'opening', None)
            directory_fd = pending[1] if pending and pending[0] == args[0] else None
            if self.output_path(args[0], directory_fd) or self.reader_walk(args, directory_fd):
                return
        if event in ('os.listdir', 'os.scandir') and self.output_path(args[0]):
            return
        if event in ('os.remove', 'os.rmdir') and self.output_path(args[0], args[1]):
            return
        if event in ('os.mkdir', 'os.chmod') and self.output_path(args[0], args[2]):
            return
        if event == 'os.utime' and self.output_path(args[0], args[3]):
            return
        if event in ('os.rename', 'os.link') and all(self.output_path(args[i], args[i + 2]) for i in (0, 1)):
            return
        if event == 'os.symlink' and self.output_path(args[0]) and self.output_path(args[1], args[2]):
            return
        return super().audit(event, args)

    def absent_import_cache(self, path, frame):
        if (frame is not None and frame.f_code is CandidateGuard.audit.__code__
                and frame.f_globals is globals() and frame.f_locals.get('self') is self):
            frame = frame.f_back
        return super().absent_import_cache(path, frame)

    def flock_target(self, descriptor, operation):
        return (type(descriptor) is int and operation in (fcntl.LOCK_EX | fcntl.LOCK_NB, fcntl.LOCK_UN)
                and self.output_path(descriptor) and Path(self.path(descriptor)).name == '.activity.lock')

    def flock_identity(self, caller, operation):
        row = self.flock_methods.get(operation)
        if row is None or caller is None:
            return False
        owner, lease, function, code, offsets = row
        return (sys.modules.get('satgs.operator_activity') is owner
                and vars(owner).get('StationLease') is lease and function.__code__ is code
                and caller.f_code is code and caller.f_globals is vars(owner)
                and caller.f_lasti in offsets and type(caller.f_locals.get('self')) is lease)

    def station_flock(self, descriptor, operation):
        caller = sys._getframe(1)
        if (self.flock_target(descriptor, operation) and self.flock_identity(caller, operation)
                and caller.f_locals.get('descriptor') == descriptor):
            require(not self.flock_identity(types.SimpleNamespace(f_code=caller.f_code.replace(), f_globals=caller.f_globals,
                        f_lasti=caller.f_lasti, f_locals=caller.f_locals), operation),
                    'flock copied-code caller admitted')
            require(not self.flock_identity(types.SimpleNamespace(f_code=caller.f_code, f_globals=dict(caller.f_globals),
                        f_lasti=caller.f_lasti, f_locals=caller.f_locals), operation),
                    'flock copied-namespace caller admitted')
            require(not self.flock_identity(types.SimpleNamespace(f_code=caller.f_code, f_globals=caller.f_globals,
                        f_lasti=-1, f_locals=caller.f_locals), operation), 'flock wrong callsite admitted')
            for label in ('flock-copied-code', 'flock-copied-namespace', 'flock-wrong-callsite'):
                if label not in self.allowance_negatives:
                    self.allowance_negatives.append(label)
            return self.real_flock(descriptor, operation)
        self.deny('api.fcntl.flock')

    def probes(self):
        count = super().probes()
        self.phase = 'negative'
        flags = os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        ancestor = str(self.scratch.parent)
        require(self.reader_target(ancestor, flags), 'reader positive target classifier failed')
        require(not self.reader_target(ancestor, os.O_RDWR), 'reader writing flags admitted')
        require(not self.reader_target('/__satgs_guard_outside__', flags), 'reader outside ancestor admitted')
        require(not self.reader_walk((ancestor, 'r', flags), None), 'reader wrong caller admitted')
        self.allowance_negatives.extend(('reader-wrong-flags', 'reader-outside-path', 'reader-wrong-caller'))
        path = self.scratch / '.activity.lock'
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_RDWR | os.O_CLOEXEC, 0o600)
        outside = os.open(__file__, os.O_RDONLY | os.O_CLOEXEC)
        try:
            operation = fcntl.LOCK_EX | fcntl.LOCK_NB
            require(self.flock_target(descriptor, operation), 'flock positive target classifier failed')
            require(not self.flock_target(descriptor, 0), 'flock wrong flags admitted')
            require(not self.flock_target(outside, operation), 'flock outside scratch admitted')
            try:
                fcntl.flock(descriptor, operation)
            except PermissionError:
                count += 1
            else:
                raise RuntimeError('flock wrong caller admitted')
            self.allowance_negatives.extend(('flock-wrong-flags', 'flock-outside-path', 'flock-wrong-caller'))
        finally:
            os.close(outside)
            os.close(descriptor)
            os.unlink(path)
        self.phase = 'runtime'
        return count

    def activate(self):
        super().activate()
        fcntl.flock = self.station_flock
        os.supports_dir_fd = os.supports_dir_fd | {os.open}

    def finish_candidate(self):
        self.verify_science_absence()
        self.verify_utc()
        require(all(row['state'] in ('present', 'absent')
                    and row.get('content', 'json-object') == 'json-object' for row in self.numpy_receipts),
                'optional NumPy metadata access or content failed')
        self.finish()
        require(not any(self.METADATA.exact_binding(self.METADATA.active_modules, row[0]) is not None
                        for row in self.METADATA.namespaces.values()), 'unfinished native initialization')
        return dict(cache_absence=self.cache_receipts(),
                    ctypes_initialization=self.ctypes_init.observations,
                    ctypes_classifier_negatives=self.ctypes_init.negative_controls,
                    new_allowance_negatives=self.allowance_negatives,
                    numpy_optional_metadata=dict(reads=self.numpy_reads, limit=1, observations=self.numpy_receipts,
                        scope='selected NumPy initializer; exact optional metadata; bounded readonly descriptor'),
                    metadata_zip_absence=dict(path=self.metadata_zip, policy='ENOENT before list/open access',
                                              counts=self.metadata_counts, negatives=self.metadata_negatives,
                                              limit=4096),
                    desktop_native_metadata=dict(bound=self.desktop_reader is not None, reads=self.desktop_maps_count,
                                                 limit=DESKTOP_MAPS_LIMIT, negatives=self.desktop_maps_negatives,
                                                 scope='bound desktop inspector, readonly /proc/self/maps only'),
                    desktop_environment_correction=dict(bound=self.desktop_environment is not None,
                        events=self.desktop_environment_count, limit=64, negatives=self.desktop_environment_negatives,
                        scope='authenticated live native callback; exact initial value restoration or new-key removal only'),
                    native_trust='bound CPython/scientific/Tk internals, not syscall isolation')
