"""Transport-neutral mechanical operations shared by serial and broker owners."""

import math
import time

from google.protobuf.timestamp_pb2 import Timestamp
from serialptu.ptu import ExchangeReceipt

from ptu_control import ptu_msg_pb2 as pb
from ptu_control.pointing import PointingError


class _BenchOperations:
    def _bench_exchange(self, operation, callback):
        if len(self._bench_exchanges) >= 3:
            raise PointingError("context_changed")
        previous = self._driver.last_exchange
        sequence = previous.sequence if previous is not None else 0
        try:
            return callback()
        finally:
            receipt = self._driver.last_exchange
            if receipt is not previous:
                if type(receipt) is not ExchangeReceipt or receipt.sequence <= sequence or receipt.operation != operation:
                    raise PointingError("serial_failure")
                self._bench_exchanges.append(receipt)

    def _bench_status(self, deadline, cancel):
        data = self._bench_exchange("status", lambda: self._driver.observe_bounded(
            self._handle, deadline=deadline, cancel=cancel))[1]
        raw = data.get("status_bytes")
        if type(raw) is not bytes or len(raw) != 3:
            raise PointingError("serial_failure")
        if self._policy is None:
            pan, tilt = data.get("pan"), data.get("tilt")
            if (data.get("message_type") not in ("move_response", "status_response")
                    or any(type(value) not in (int, float) or not math.isfinite(value)
                           for value in (pan, tilt)) or type(data.get("status")) is not list):
                raise PointingError("serial_failure")
            if self._bench.motion_allowed:
                self._bench_motion_active = bool(raw[2] & 0x4f)
                if raw[0] or raw[1]:
                    self._invalid = True
        else:
            pan, tilt = self._observe(data)
        if self._bench_observation_sequence == 2**64 - 1:
            raise PointingError("context_changed")
        self._bench_observation_sequence += 1
        stamp = Timestamp()
        stamp.GetCurrentTime()
        self._bench_observation = (pan, tilt, raw, stamp.SerializeToString(), time.monotonic(),
                                   self._bench_observation_sequence)
        if self._bench.mode == "rehearsal" and not raw[2] & 0x4f:
            self._bench_motion_active = False
        return self._bench_observation

    def _check_bench_packet(self, packet, start):
        if self._policy is None:
            self._bench.check_encoded(packet, start)
        else:
            self._policy.check_encoded(packet)

    def _bench_execute(self, command, deadline, *, cancel):
        if self._bench.mode == "query-only" and command.operation not in (
                pb.BenchCommand.CONNECT, pb.BenchCommand.STATUS, pb.BenchCommand.DISCONNECT):
            raise PointingError("unsupported")
        stop = command.operation == pb.BenchCommand.STOP
        acquired = False
        category, submission = "ok", "none"
        preview = None
        observation = None
        message = None
        try:
            while not self._operation.acquire(timeout=self._deadline(deadline, cancel)):
                pass
            acquired = True
            self._bench_exchanges = []
            if self._closing.is_set() or not self._active:
                raise PointingError("disconnected")
            with self._bench_slots:
                if (self._policy is None and command.operation == pb.BenchCommand.CONNECT
                        and self._bench_connected and command.sender not in self._bench_connected):
                    raise PointingError("busy")
                previous = self._bench_senders.get(command.sender)
                if previous is None:
                    if command.operation != pb.BenchCommand.CONNECT or len(self._bench_senders) >= 128:
                        raise PointingError("disconnected")
                elif command.sequence <= previous:
                    raise PointingError("context_changed")
                self._bench_senders[command.sender] = command.sequence
                if command.operation != pb.BenchCommand.CONNECT and command.sender not in self._bench_connected:
                    raise PointingError("disconnected")
            if not stop and self._bench_stop_pending.is_set():
                raise PointingError("busy")
            if command.operation == pb.BenchCommand.CONNECT:
                observation = self._bench_status(deadline, cancel)
                with self._bench_slots:
                    self._bench_connected.add(command.sender)
            elif command.operation == pb.BenchCommand.STATUS:
                observation = self._bench_status(deadline, cancel)
            elif command.operation == pb.BenchCommand.PREVIEW:
                if self._bench_motion_active or self._invalid:
                    raise PointingError("busy")
                observation = self._bench_status(deadline, cancel)
                if self._bench_motion_active or self._invalid:
                    raise PointingError("busy")
                self._bench.check_target(command.pan, command.tilt, observation[:2])
                packet = self._driver.prepare_move_to(self._handle, command.pan, command.tilt,
                    deadline=deadline, cancel=cancel)
                self._check_bench_packet(packet, observation[:2])
                encoded = (packet.pan_units / packet.units_per_degree, packet.tilt_units / packet.units_per_degree)
                self._bench.check_target(*encoded, observation[:2])
                preview = (command.sequence, command.pan, command.tilt, packet, observation)
                self._bench_previews[command.sender] = preview
            elif command.operation == pb.BenchCommand.MOVE:
                preview = self._bench_previews.pop(command.sender, None)
                if (preview is None or preview[0] != command.preview_sequence or self._bench_motion_active
                        or self._invalid or self._bench_stop_pending.is_set()):
                    raise PointingError("context_changed")
                if not self._bench.motion_allowed:
                    raise PointingError("unsupported")
                if time.monotonic() - preview[4][4] > self._bench.observation_max_age_seconds:
                    raise PointingError("context_changed")
                observed = self._bench_status(deadline, cancel)
                if observed[:2] != preview[4][:2] or observed[2] != preview[4][2]:
                    raise PointingError("context_changed")
                self._check_bench_packet(preview[3], observed[:2])
                self._bench.check_target(preview[3].pan_units / preview[3].units_per_degree,
                                         preview[3].tilt_units / preview[3].units_per_degree, observed[:2])
                observation = observed
                with self._driver.pointing_guard(self._handle, deadline=deadline, cancel=cancel):
                    if self._bench_stop_pending.is_set() or self._invalid or self._bench_stop_failed:
                        raise PointingError("busy")
                    self._bench_possible_motion = True
                    self._bench_motion_active = True
                    self._bench_exchange("move", lambda: self._driver.submit_prepared_move(
                        self._handle, preview[3], deadline=deadline, cancel=cancel))
                submission = "complete"
                self._bench_previews.clear()
            elif stop:
                self._bench_previews.clear()
                if not self._bench.motion_allowed:
                    raise PointingError("unsupported")
                self._bench_exchange("stop", lambda: self._driver.stop_bounded(
                    self._handle, deadline=deadline, cancel=cancel))
                submission = "complete"
                observation = self._bench_status(deadline, cancel)
                if not observation[2][2] & 0x4f:
                    self._bench_motion_active = False
            else:
                self._bench_previews.pop(command.sender, None)
                with self._bench_slots:
                    self._bench_connected.discard(command.sender)
            self._state = ("stop_failed" if self._bench_stop_failed else
                           "submitted" if command.operation == pb.BenchCommand.MOVE else
                           "disconnected" if command.operation == pb.BenchCommand.DISCONNECT else "connected")
        except Exception as error:
            failure = self._translated(error)
            category = failure.primary
            if submission != "complete":
                submission = failure.submission
            if command.operation == pb.BenchCommand.MOVE and submission != "none":
                self._bench_possible_motion = True
                self._bench_motion_active = True
                self._invalid = True
            with self._bench_slots:
                stop_owner = self._policy is not None or command.sender in self._bench_connected
            if stop and stop_owner:
                self._bench_stop_failed = True
                self._bench_possible_motion = True
                self._bench_motion_active = True
                self._invalid = True
                self._state = "stop_failed"
        finally:
            if acquired:
                try:
                    message = self._bench_message(command, category, submission, preview, observation,
                                                  self._bench_exchanges)
                finally:
                    self._operation.release()
            if stop:
                with self._bench_priority:
                    self._bench_stop_count -= 1
                    if not self._bench_stop_count:
                        self._bench_stop_pending.clear()
        if message is None:
            message = self._bench_message(command, category, submission, None, None, ())
        return message

    def _bench_message(self, command, category, submission, preview, observation, exchanges):
        context = self._bench
        message = pb.BenchOutcome(manager_id=self._manager_id, binding=context.binding,
            sender=command.sender, sequence=command.sequence, operation=command.operation,
            category=category, state=self._state, mode=context.mode,
            physical_state="indeterminate" if self._bench_possible_motion else "unobserved",
            position_reference="protocol-reported-unqualified", submission=submission,
            units_per_degree=10 if self._policy is None or self._policy.protocol == "PTCR20" else 100,
            equipment_label=context.equipment_label, frame="mechanical-pan-tilt-degrees.v1",
            possible_motion=self._bench_possible_motion)
        if context.mode != "query-only":
            for name in ("pan_min", "pan_max", "tilt_min", "tilt_max", "max_change_degrees"):
                setattr(message, name, getattr(context, name))
        for receipt in exchanges:
            exchange = message.exchanges.add(sequence=receipt.sequence, operation=receipt.operation,
                request=receipt.request, response=receipt.response, response_truncated=receipt.response_truncated,
                started_monotonic=receipt.started_monotonic, finished_monotonic=receipt.finished_monotonic,
                category=receipt.category, submission=receipt.submission)
            if receipt.written is not None:
                exchange.written = receipt.written
        if observation is not None:
            message.has_observation = True
            message.pan, message.tilt, message.status_bytes = observation[:3]
            message.observed_at.ParseFromString(observation[3])
            message.observation_sequence = observation[5]
        if preview is not None:
            message.preview_sequence, message.requested_pan, message.requested_tilt = preview[:3]
            message.encoded_pan_units = preview[3].pan_units
            message.encoded_tilt_units = preview[3].tilt_units
            message.units_per_degree = preview[3].units_per_degree
        return message
