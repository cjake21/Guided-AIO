"""Foreground lifecycle adapter for the selected strict bench owner."""

import argparse
from importlib.metadata import PackageNotFoundError, version
import json
import math
import signal
import threading
import time

from satgs.deployment_cli import CliInputError
from satgs.operator_bench import _admit, _open_transport, _transport_acquisition_cancel, read_bench_configuration
from satgs.operator_core import OperatorError
from satgs.runtime_configuration import _freeze


def run_manager(configuration, *, duration, cancel):
    if (type(duration) not in (int, float) or not math.isfinite(duration)
            or not 0 < duration <= 3600 or not isinstance(cancel, threading.Event)):
        raise OperatorError("Supply a finite foreground lifetime up to 3600 seconds.")
    try:
        unused, document = read_bench_configuration(configuration)
    except (CliInputError, OSError, ValueError):
        raise OperatorError("Bench configuration could not be read.", "bench_input", 3) from None
    try:
        settings = _admit(document)
    except ImportError:
        raise OperatorError("Install the matched bench owner prerequisites.", "owner_version", 3) from None
    if settings.get("bench_transport") == "local-serial":
        raise OperatorError("Local serial sessions connect directly from PTU or the bench CLI; do not start a manager.",
                            "bench_not_admitted", 3)
    try:
        selected = tuple(version(name) for name in ("satgs", "ptu-control", "serialptu"))
    except PackageNotFoundError:
        raise OperatorError("Install the matched bench owner combination.", "owner_version", 3) from None
    if selected != ("0.0.1+bench.20261118.1", "0.0.1+bench.20261118.1", "0.0.1+bench.20261117.1"):
        raise OperatorError("Install the matched bench owner combination.", "owner_version", 3)
    from ptu_control.bench import BenchContext, ManualContext, ReadbackContext
    from ptu_control.pointing import PointingPolicy
    from ptu_control.ptu_manager import PtuManager
    from serialptu.proto_impl import PTCR20
    from serialptu.ptu import PTU

    mechanical = "readback_context" in settings or "manual_context" in settings
    if mechanical:
        context_type = ManualContext if "manual_context" in settings else ReadbackContext
        context = context_type.from_settings(settings, document["ptu_id"])
        protocol = context.protocol
    else:
        policy = PointingPolicy.from_settings(settings, document["ptu_id"], document["elevation_mask"],
                                              _freeze(document["no_go_data"]))
        context = BenchContext.from_settings(settings, policy)
        protocol = policy.protocol
    if context.mode not in ("operational", "manual", "query-only") or protocol != "PTCR20":
        raise OperatorError("The foreground manager requires an admitted operational setup.", "bench_not_admitted", 3)
    if cancel.is_set():
        return dict(exit_code=130, category="cancelled", activated=False, cleanup=[], physical_state="unobserved")
    run_deadline = time.monotonic() + duration
    transport = driver = manager = None
    record = dict(exit_code=0, category="lifetime_complete", activated=False,
                  cleanup=[], physical_state="indeterminate", physical_stop_established=False)

    def deadline():
        return min(run_deadline, time.monotonic() + context.exchange_timeout_seconds)

    try:
        acquisition_deadline = deadline()
        with _transport_acquisition_cancel(cancel, acquisition_deadline) as transport_cancel:
            transport = _open_transport(settings, acquisition_deadline, transport_cancel)
        acquisition = {}
        if mechanical:
            from serialptu.acquisition import SerialDeviceIdentity, SerialSettings
            acquisition = dict(serial_settings=SerialSettings(**context.serial_settings),
                               device_identity=SerialDeviceIdentity(**context.device_identity),
                               serial_capability="manual" if context.motion_allowed else "readback")
        driver = PTU(PTCR20(), context.serial_port, baud=context.baud, pointing=True, **acquisition)
        manager = PtuManager.open_bench(messenger=transport, settings=settings, ptu_id=document["ptu_id"],
            driver=driver, elevation_mask=document.get("elevation_mask"), no_go_data=_freeze(document.get("no_go_data")),
            run_deadline=run_deadline, cancel=cancel)
        manager.activate(deadline=deadline(), cancel=cancel)
        record["activated"] = True
        while not cancel.wait(min(.05, max(0, run_deadline - time.monotonic()))):
            if time.monotonic() >= run_deadline:
                break
            # Invalidated motion still permits bounded Stop and readback on this owner.
            if manager._bench_shutdown.is_set() or not manager._bench_worker.is_alive():
                record.update(exit_code=4, category="manager_failure")
                break
        if cancel.is_set():
            record.update(exit_code=130, category="cancelled")
    except Exception as error:
        category = getattr(error, "primary", "owner_failure")
        record.update(exit_code=130 if cancel.is_set() else 4, category=category if category in (
            "deadline", "cancelled", "disconnected", "unsupported", "policy_mismatch", "busy", "serial_failure") else "owner_failure")
    finally:
        # Shutdown is passive, never a compensating move, park or physical Stop.
        for name, owner in (("manager", manager if manager is not None else driver), ("transport", transport)):
            if owner is not None:
                try:
                    owner.close(deadline=time.monotonic() + context.exchange_timeout_seconds)
                except Exception:
                    record["cleanup"].append(name)
        if record["cleanup"] and record["exit_code"] == 0:
            record["exit_code"] = 7
    return record


def main(argv=None):
    parser = argparse.ArgumentParser(description="Selected bench manager, foreground only.", allow_abbrev=False)
    parser.add_argument("--configuration", required=True)
    parser.add_argument("--duration", required=True, type=float)
    args = parser.parse_args(argv)
    cancel = threading.Event()
    previous = {}
    try:
        for name in (signal.SIGINT, signal.SIGTERM):
            previous[name] = signal.signal(name, lambda unused_signal, unused_frame: cancel.set())
        result = run_manager(args.configuration, duration=args.duration, cancel=cancel)
    except OperatorError as error:
        result = dict(exit_code=error.exit_code, category=error.code, activated=False, cleanup=[],
                      physical_state="unobserved", message=str(error))
    except ImportError:
        result = dict(exit_code=3, category="owner_version", activated=False, cleanup=[],
                      physical_state="unobserved", message="Install the matched bench owner prerequisites.")
    finally:
        for name, handler in previous.items():
            signal.signal(name, handler)
    print(json.dumps(result, sort_keys=True))
    return result["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
