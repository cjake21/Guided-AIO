# 10. Original M-SEL to current SATGS

The original M-SEL ground station installs a collection of cooperating services,
schedules satellite passes through a broker and runs a hardware/RF-oriented pass
procedure. Native SATGS adds a shared saved-workspace workflow for configuration,
manual position, local calculation and reviewed runtime requests. It is not a
replacement GUI for every original service or command.

This comparison uses the fixed original source revision identified in the
[maintainer reference](maintainer-reference.md#revision-and-source-boundaries).
Original command forms below were source reviewed, not executed as part of this
documentation work. They can contact brokers, change TLE files, start devices,
transmit commands or invoke other programs. Do not run them as tutorial steps.

## Start with the task you already know

The following walkthroughs explain where familiar work now belongs. The detailed
command comparison follows them. Unchanged means an existing owner still handles
the task. Changed-but-supported means the native workflow performs a useful
equivalent with different inputs/state. Legacy-only means the original path is
retained but has no native replacement. Newly added identifies saved-workspace
review/identity features. Not yet implemented identifies a real missing native
capability, not a command to be guessed.

## Bring an existing full station into the operator workflow

Before, the full installer prepared a fixed set of packages and operators
configured separate services. That remains a legacy deployment responsibility.
The native update installs its reviewed operator/pointing combination beside the
accepted environment; it does not replace every RF service.

Open the existing station and inspect its saved selection. In a new practice
workspace, follow [the Full M-SEL sequence](configurations.md#save-a-full-m-sel-selection-in-a-practice-station):
Setup > full_msel > Preview, inspect Review, then Save and Reload. Its CLI
sequence obtains the actual returned preview ID before applying it. Compare
the selection with the [component handbook](component-handbook.md), especially
the RF, recording, processing and independent broker/time responsibilities.

The result is persistent full-station intent with a retained receipt, not a new
software installation. Queue submission, RF controls, post-processing and Box
remain in their configured legacy tools. This is changed-but-supported selection
and newly added review, alongside unchanged owner responsibilities.

## Prepare a portable site or a partial deployment

Before, a partial installation meant deploying individual microservices or
changing the fixed installer. Now Setup names packages, capabilities and providers
explicitly. For the canonical portable foundation choose Guided Arrow; it still
requires Pixhawk/dual GPS, PTU, broker, time and queue/run/orbit roles. It is not a
new name for PTU-only control.

Use [the practice sequence](operator-tutorial.md#select-guided-arrow-and-retain-returned-identities)
to Preview/Save Guided Arrow, then inspect the reported deployment conflicts.
Sponsor-provided RF/power/recording/processing are external responsibilities,
not installed connectors. The current queue requirement conflicts with that
boundary. Keep local planning usable while arranging the missing deployment
contract rather than claiming a complete operational portable station.

For a narrower bench choose Custom. Start from the declared Guided instances,
change only the intended modes/providers, Preview and review the result. The
[configuration chapter](configurations.md#custom) explains why Full-to-Custom
can need explicit hardware identities. Partial configuration is supported;
an arbitrary combination's operational installation is not implied.

## Move to a new site and maintain orbit inputs

Before, a primary site came from YAML; an alternate locale used `--at` and a
named locale entry. The same numerical planning purpose remains. Now use a
separate workspace for another locale, or deliberately Preview/Save relocation.
The [complete exercise](operator-tutorial.md#cancel-a-location-preview) enters
manual coordinates, cancels one preview, saves a new one, reopens the station,
plans from an explicit local historical CSV and changes longitude for a new plan.
Its commands retain actual preview and plan identities.

Location > Preview > Save and Results > Calculate are the matching actions.
The saved plan records site/reference/revision and TLE identity. Relocation marks
old plans for revalidation; it does not align the antenna. This numerical path
is changed-but-supported, with newly added revision/input binding.

The old add/delete/refresh-TLE commands still belong to their legacy path and
may perform network/filesystem effects. Native planning accepts an approved
local file unchanged; it has no TLE fetch/editor, legacy category filters or
named-locale selector. Preserve those legacy-only distinctions.

## Replace a direct run only where parity exists

Before, direct runs initialized selected hardware/RF clients, while queue tools
submitted jobs through ActiveMQ. Now a native reviewed request binds a saved
plan, site, owner/configuration/TLE inputs and duration. Follow [run review](operator-tutorial.md#review-a-run-request)
for the supported input/review part; Start run needs separate confirmation and
actual owner admission.

A local plan or request is not a queued job. Native queue submission, schedule
import, queue inspection/removal/clear and RF controls remain legacy-only.
Ordinary live owner admission is not yet implemented for this release. Controlled
rehearsal exercises real shared software with controlled boundaries, not live
tracking. Read its actual result and partial/failure evidence, not just the word
Completed in an old queue log.

## Use manual PTU controls and navigation observations

The original PTU GUI is in serialptu. It has press/release jog arrows, numeric
absolute/relative controls and actual response-driven status. It was not absent
merely because there was no original whole-station native window.

The new [PTU session](ptu-operation.md) preserves direction signs and numeric
positioning through the shared manager/owner path. Explicitly enabled discrete
steps replace continuous jog/soft-limit override. Mouse buttons and focused
keyboard arrows use fresh actual readback, not target-field arithmetic. The
chapter provides exact old/current interaction comparison and controlled CLI
sequence; the acceptance report records actual values/outcomes. Live unit
position/Stop/alignment commissioning remains separate.

For Pixhawk, the owner still publishes and subscribes to selected observations.
Home/Location now distinguish source, fix, health and freshness and preserve
synthetic provenance. Native manager startup and live GPS station selection are
not supplied. Entering a manual site remains usable without those observations.

## Retain old recordings while using new reports

Before, pass outputs lived under configured `logging_dir`; processing consumed
those directories and optional Box handled its conditional synchronization.
Keep that data tree and its owner prerequisites. Native station artifacts add
plans, previews/receipts and request/progress/result records in the workspace.

Use Results > Report and Export... or the [paired complete commands](results.md#export-a-report-to-a-new-file)
for a new private JSON snapshot. Reopen the same workspace to continue station
work and use actual run-status IDs to inspect retained runs. Export refuses an
existing filename; that harmless failure preserves the old bytes. Full run/log
retention and failed/partial outcomes are explained in [Results](results.md).
The JSON is not an RF capture, runsheet, database insert or Box upload.

For updates, follow the [maintained release workflow](updates-troubleshooting.md)
instead of replacing an active environment. Stage/check/select a separate
candidate, retain workspace data and roll selection back to the prior compatible
guide when needed. This is a newly maintained application-release path; it does
not undo independent service/data/physical effects.

## Read the command notation

In this chapter only, uppercase argument names are descriptions, not runnable
values. `OLD_CONFIG` is the approved original YAML configuration file;
`OLD_SAT_DB` its local satellite CSV; `SIGNAL_DB` its emission-ID CSV;
`NORAD_ID` a satellite in that database; `JOB_ID` an ID returned by the original
queue; and `SECONDS`, `DAYS` and `DEGREES` have the units named. `DOWNLINK_MHZ`
and `UPLINK_MHZ` are approved RF frequencies in MHz, not numbers supplied by this
guide. `SAMPLE_MSPS` is the approved RF sample rate in millions of samples per
second. `LOCALE` names an existing `pass_finder_locales` entry. `PIX_ID` is a
configured sensor ID, `PTU_ID` is a configured application positioner ID, and
`SERIAL_PORT` is that deployment's assigned operating-system device path. An
optional subscriber/client ID of 0 selects all configured application IDs; it
is not an instruction to use physical wire address 0. Current `PREVIEW_ID`,
`PLAN_ID` and `REQUEST_ID` are full actual returned identities from the selected
workspace's JSON. They are not interchangeable with legacy numeric job IDs.

## Installation, selection and location

| Operator goal and original supported input | Original effect | Current command and matching GUI | Preserved, changed or absent parity |
| --- | --- | --- | --- |
| Install the complete suite: `./build.sh` in the original checkout with all pinned submodules present | Copies five missing configuration/notebook templates, then invokes ten pip package installations in order. Host preparation, service setup and operational configuration are separate. | Review/install the side-by-side candidate with its supplied setup procedure. `components-preview --profile full_msel`, then confirmed `apply`; Setup > Profile full_msel > Preview > Save records configuration intent only. | Full M-SEL installer remains in the shared product. The native Save action is deliberately not that installer. |
| Choose fewer components by editing the old installer or individual service deployment | Original build.sh installs its fixed full set and has no profile parser. README advises direct microservice setup for partial deployments. | Shared deployment CLI provides catalog/validate/plan/compare; `./build.sh --profile guided_arrow --dry-run` is static deployment planning. Native `components-preview --profile guided_arrow` or Custom mirrors canonical selection constraints. | Explicit component/provider identities, install/reuse/external/omit and compatibility constraints are added. Guided Arrow installer apply is not delivered. External owners remain independently provisioned. |
| Set `ground_station_lat`, `ground_station_lon`, `ground_station_altm` in OLD_CONFIG | PassFinder/QueueClient use configured site coordinates for orbit calculations; PassRunner initializes its own observer. Coordinates are degrees and altitude metres. | `location-preview --latitude-deg ... --longitude-deg ... --altitude-m ... --altitude-reference ...`, then `apply --preview PREVIEW_ID --confirm`; Location > Preview > Save. | Units and station-planning purpose are preserved. Current explicit manual source, declared altitude reference, revision binding and conflict checks are new. Saving location does not align or move an antenna. |
| Calculate at another configured locale: `pass_finder -config OLD_CONFIG -sf OLD_SAT_DB --sids NORAD_ID --at LOCALE -d DAYS --elmask DEGREES` | Selects `pass_finder_locales[LOCALE]` lat/long/alt rather than the primary site. Original default at_locale=None uses the primary site. | Use a separate current workspace for another site, or explicitly preview/save relocation and calculate again. Home > Open station... and Location expose that workflow. | The numerical goal is supported, but no current `--at` alias or locale-name selector exists. Current position changes persist and invalidate old plans. |
| Install/start the original ground_station, Pixhawk, PTU and other systemd services | Service templates run their configured processes. Original README separately instructs daemon-reload, enable and start. | No native service activation command or button. | Preserved deployment responsibility, no GUI replacement. Opening SATGS does not start those services. |

The original README says build.sh compiles all protobufs. Its actual script only
copies templates and invokes pip. Compilation is delegated to the original
package build tooling (`setuptools-protobuf` in pyproject), so success depends on
that tooling and compiler. The current wheel workflow explicitly generates
protobuf modules during reviewed build staging; runtime does not need the
compiler. Original broad recursive/world-writable permission examples are
historical instructions, not recommended current deployment practice.

The original build script has no fail-fast shell setting or explicit per-command
checks. The later shared installer adds guarded validation and failure
propagation while retaining the Full M-SEL package order. Do not attribute those
later modular installer guarantees to the fixed original revision.

## Prediction and TLE inputs

| Operator goal and original command | Original effect | Current command and matching GUI | Changed defaults, persistence and limits |
| --- | --- | --- | --- |
| Find passes: `pass_finder -config OLD_CONFIG -sf OLD_SAT_DB --sids NORAD_ID -d DAYS --elmask DEGREES` | Calculates opportunities after checking selected TLE age, conditionally refreshing from Celestrak and writing an updated satellite CSV. UTC output is default; `--local` selects configured US/Eastern presentation. | `plan --start ISO8601_WITH_OFFSET --norad-id NORAD_ID --span-days DAYS --elevation-deg DEGREES --tle-file LOCAL_CSV`; Results > Calculate with matching fields. | Actual orbit calculation is retained. Current path is offline/read-only for TLEs, one selected NORAD per plan, explicit saved location/revision and stored plans. Default is historical NOAA 15, one day and 20 degrees; original declared constants are seven days and 15 degrees. |
| Add/delete a satellite: `add_tle NORAD_ID -sf OLD_SAT_DB` and `del_tle NORAD_ID -sf OLD_SAT_DB` | Add fetches through Celestrak scraping and updates CSV; delete removes the entry and rewrites CSV. | No native TLE catalog editor or fetch command. Supply an explicitly approved local CSV to plan. | Legacy-only editing/fetching is preserved in its own path. Current planning does not silently perform it. |
| Export a runsheet: `pass_finder -config OLD_CONFIG -sf OLD_SAT_DB --sids NORAD_ID -d DAYS --to_csv` | Writes a schedule CSV in configured run_sheet_dir for the original batch queue workflow. | Current Report/Export... exports a JSON operator report. | No equivalent runsheet/queue export in the native window. A JSON report is not an add_schedule input. |
| Filter GNSS/radar/weather or visualize: `pass_finder --gnss`, `--sband-radar`, `--lband-weather`; `plot_sky_view` and `pass_plotter` | Original selection masks and plotting tools use their own inputs/dependencies and may use PassFinder's refresh path. | Current Results accepts explicit NORAD ID and numerical inputs. | These legacy category filters/plot windows have no current native equivalent. Local numerical planning is not a claim of complete plotting parity. |

The README's exact example uses `pass_finder --sids ... --d ... --elmask ...`.
The parser declares `--duration` and `-d`. Because the original argparse parser
allows unique long-option abbreviation, `--d` can resolve to `--duration` there;
it is not a separately declared option. Prefer canonical spelling in source
references. Current `satgs-operator` disables abbreviation.

Original `DEFAULTS.tle_validity` is actually 0.5 days even though its nearby
docstring says two days. The declared constants and call paths, not that
comment, determine behavior. TLE freshness remains an operator assessment
in the current explicit local path. A separate original IAU `fetch_tle` function
does not describe the Celestrak refresh/add-TLE path.

## Direct and queued operations

| Operator goal and original supported form | Original effect | Current form and matching GUI | Preserved behavior and parity boundary |
| --- | --- | --- | --- |
| Execute a direct pass: `run_pass -config OLD_CONFIG -sf OLD_SAT_DB -tf SIGNAL_DB -id NORAD_ID -dlfc DOWNLINK_MHZ -dlfs SAMPLE_MSPS --duration SECONDS` | Loads configured hardware/transport clients, predicts/sets a pass window, primes/tracks/parks, records logs and optional RF data. Uplink/downlink emission IDs or RF options select additional behavior. | `run-preview` with actual saved plan, deployment/runtime/owner/TLE inputs, then separately confirmed `run-start --run-id REQUEST_ID --confirm`; Run > Review run > Start run. | Strict revision/input/owner admission and outcome distinctions are added. Ordinary live admission is unavailable. A plan preview or controlled rehearsal is not a real pass replacement. Current native forms do not reproduce legacy RF controls. |
| Submit the next numbered pass: `add_pass -config OLD_CONFIG --svid NORAD_ID --passnumber 1 -dlfc DOWNLINK_MHZ -dlbw BANDWIDTH_MHZ` | QueueClient calculates a candidate pass and publishes a job request to QueueManager. At least one uplink/downlink is required. Duration is seconds; frequencies/bandwidth are MHz. | No native queue-submission form. run-preview creates a local reviewed request, not a queued job. | Legacy broker queue remains a separate supported deployment path, not native parity. |
| Submit an explicit time: `add_pass -config OLD_CONFIG --svid NORAD_ID --starttime YYYY-MM-DD-HH:MM:SS --duration SECONDS -dlfc DOWNLINK_MHZ -dlbw BANDWIDTH_MHZ` | Treats the supplied time as UTC and submits through the original broker path; start time and pass number are mutually exclusive. | Current planning takes an explicit UTC offset; Run selects a plan opportunity. | No matching queue action. Do not confuse original compact UTC strings with current ISO 8601 input or assume --local changes submitted UTC interpretation. |
| Import a schedule: `add_schedule -config OLD_CONFIG [--continue-id]` or `[--start-id INTEGER]` | Requests queue and chooses the most recently modified regular file in configured run_sheet_dir, then parses/queues its rows. It does not take a schedule filename argument. | None in the native GUI/CLI. | Preserved legacy-only. Do not pass current JSON export to this command or imply a native schedule editor exists. |
| Inspect/remove/clear jobs: `request_gs_queue -config OLD_CONFIG`; `remove_pass -config OLD_CONFIG --jobid JOB_ID`; `clear_gs_queue -config OLD_CONFIG` | Publishes broker requests; remove edits pending queue entries and clear replaces the in-memory queue/state. | `status` inspects the workspace; `run-status --run-id REQUEST_ID` reads a run record; neither reads the legacy queue. | No native queue manager equivalent. Queue removal/clear does not prove termination of an already running child or physical stopping. |
| Cancel an operation | Original pass runner shutdown/parking paths and queue edits have different meanings; queue clear/remove do not retain a terminating child-process handle. | `cancel --preview PREVIEW_ID` cancels only a configuration preview. `run-cancel --run-id REQUEST_ID` requests local cancellation of a started run; matching Review > Cancel and Run > Cancel run. | Current cancellation is explicit and records remote/physical-stop limits. No software cancellation is a measured physical Stop. |

Original `run_pass` defaults its config to relative `config/config.yaml`, so its
working directory matters. Original pass-finder and queue public defaults use
the home-based ground_station configuration. The current daily wrapper resolves
the shared workspace regardless of normal working directory. Direct developer
entry points still have their own documented workspace default.

Original direct-run omission flags are `--nopixhawk`, `--nofrontend`, `--noptu`
and `--nopdu`; original QueueManager `--testmode` supplies those to its child.
Pixhawk/PTU manager `--nohw` selects simulated hardware, not an isolated
documentation sandbox. In particular, original `_initialize_ptu` still creates
a Messenger before selecting PtuClient test mode. These flags do not establish
zero broker/filesystem effects, current controlled-owner admission or physical
safety. The new tutorial therefore uses local planning and a separately
controlled rehearsal, not an improvised legacy no-hardware run.

The original QueueClient constructs its broker/TLE path before several semantic
add-pass argument checks. Even a command later rejected for missing RF intent
can already have effects. None of those legacy commands is used as an offline
documentation example. The current docs path bypasses all such owners.

Original QueueManager runs a pass with blocking `subprocess.run(check=True)` in a
job thread. On child failure it catches/logs the error, still logs Completed Pass
and advances into post-processing. Those words are not proof the pass succeeded,
let alone physical completion. The current request/result path retains primary
failure, cleanup, submission, software-completion and physical-state evidence
separately.

## Pixhawk, PTU and results

| Operator goal and original configuration/path | Original effect | Current command and matching GUI | Preserved or missing equivalence |
| --- | --- | --- | --- |
| Observe Pixhawk position/attitude through configured IDs and original Pixhawk manager/subscriber | Original pass runner creates PixhawkSubscriber for logging. A message contains observations; receipt alone is not fix/health/heading qualification. | Home status and Location GPS expose separate evidence; `replay --state ...` selects only synthetic observations. Use GPS remains disabled. | Original observations and strict owner work remain separate from live GPS station selection. No native manager startup or admitted live measured-location workflow. |
| Inspect original telemetry: `echo_pixhawk PIX_ID -config OLD_CONFIG`; manager form `python -m pixhawk.pixhawk_manager --pix-id PIX_ID --port SERIAL_PORT -config OLD_CONFIG` | Subscriber selects configured sensor IDs and subscribes/logs broker observations; manager opens the assigned serial source and publishes. PIX_ID=0 in subscriber selects all configured sensors, not a physical device address. | Current Home/Location display admitted local/replay dimensions. There is no native live Pixhawk manager launch action. | The original README's manager flag --ptu-id differs from its actual --pix-id parser. No current GPS selection equivalence is claimed. |
| Select PTU model/protocol/baud/no-go policy in original YAML and per-owner setup | Original PTU client/manager own addressing and serial protocol; pass runner issues load/prime/track/park commands. Original README lists QPT-130/200/500 and PTCR96/PTCR20. | Pelican case accepts QPT130 only. PTU bench configuration has deliberate session/target review and current-position/Stop admission gates. | Wider shared Full M-SEL model contracts are preserved. Human PTU labels, positive application manager IDs and serial wire addresses are different identities. No automatic conversion or physical qualification is claimed. |
| Original PTU client tools: `echo_ptu PTU_ID -config OLD_CONFIG`, `calibrate_ptu PTU_ID -config OLD_CONFIG`, `reset_ptu PTU_ID -config OLD_CONFIG`, `park_ptu PTU_ID -config OLD_CONFIG` | Uses configured broker/positioner identities. ID 0 targets all configured application positioners. park_ptu resets the owner, waits, then requests park; it is not a dedicated physical Stop contract. | PTU bench session has Status/Preview/Move/Stop/Disconnect with unavailable live admission. No current native Calibrate/Reset/Park equivalent. | Preserve legacy command meanings and unavailable parity. Do not map a park request to current Stop or interpret acknowledgements as measured stopping. |
| Keep original pass artifacts under configured logging_dir | Original runner writes truth, Pixhawk/PTU/front-end logs, TLE/test details and configured captures. QueueManager can run quick_look/post-processing on a latest result directory. | `report`, `export --output NEW_FILE`; Results > Report/Export... retains local station plans and operation evidence. | Native JSON report is not an RF recording or legacy directory replacement. Runtime result artifacts preserve software/physical outcomes; keep partial evidence. |
| Share results with Box when `box_connectivity` is enabled | Original QueueManager invokes box_sync after analysis for satellite 63231; this is narrower than a generic claim that all results always synchronize. | None in native workflow. | Optional legacy-only feature requires package, credentials and assigned storage. Current GUI does not install/enable it or claim uploads. |
| Use browser dashboard/database history | Original deployment includes separately owned dashboard services. The pinned backend initializes broker clients and reads satellite CSV in app/config.py; its captured code does not establish a persistent database-history implementation. | Native SATGS window and local JSON report are separate. | No native database-history browser, database migration or dashboard startup. Neither a TLE CSV named database nor dashboard connectivity proves database persistence. |

Exact original component pins, source symbols and current implementation paths
are in the [technical appendix](maintainer-reference.md). Model/protocol names in
an original README establish historical configuration vocabulary, not an
allocated unit's current behavior, calibration or physical Stop contract.

In the original PTU manager, `--ptu-id` selects a positive application
`positioners[].id`, and `--port` chooses the serial connection. YAML supplies
protocol and baud; the parsed `--protocol` is explicitly ignored. The pinned
serial factory creates PTCR20 without a wire ID and PTCR96 with wire ID 0.
Application ID 2 therefore does not imply serial address 2. Historical serialptu
guidance pairs non-high-resolution QPT130/PTCR20/9600 and QPT200/500/PTCR96/57600;
those are source-reviewed historical combinations, not permission to choose an
allocated unit's settings. The current bench binding keeps application and wire
identities explicit and retains the closed admission gates.
