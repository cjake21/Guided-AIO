# 7. Operate the PTU through its selected owner

Use PTU for a deliberate manual-control session, not to configure the station's
latitude/longitude or align the antenna. The native page and interactive bench
CLI use one shared session. Explicit local-serial mode owns the driver in that
session; broker mode uses the foreground manager. Both reuse the same owner
command checks and serialptu encoder/parser. Arrow callbacks never build serial
commands themselves. A failed broker connection never switches to local serial.

The QPT130/PTCR20 manual and query-only sessions now use explicit immutable
configuration. Satellite tracking admission remains separate and closed.
Controlled software acceptance does not physically qualify the unit or cable.

## Prepare access and identify the unit

For the direct local bench, create a query-only configuration without
opening a device, starting a broker or changing the saved station:

```sh
satgs-operator bench-configure --transport local-serial --output "$HOME/satgs/local-ptu.json"
```

The parent directory must already exist. This creates only `local-ptu.json`,
readable/writable only by the creating user, and refuses to replace it. No
broker credentials, broker XML, Messenger connection or manager service is
needed. In the existing PTU tab's Configuration JSON chooser, select
`/home/admin/satgs/local-ptu.json`.
There is no `/absolute` folder to find: that wording in older instructions was
a placeholder, not an installed directory.

This explicitly selects the local serial route for the mechanical bench only.
It does not satisfy the broker, navigation or scheduled-pointing requirements
of Full M-SEL or Guided Arrow. The manager-capable application supplies the
serial prerequisites; a client-only installation does not silently install them.
Keep the distributed route below for workflows that need it.

Manager ID 1 is the software outcome identity, not a PTCR20 wire address or
permission to share a device. In local mode it identifies the session's owner.
The generated one-second exchange timeout and five-second feedback age are
explicit software budgets, not measured hardware guarantees; override them with
`--exchange-timeout` and `--feedback-max-age` if the reviewed arrangement requires it.

For manual control, use a different new output name and explicitly supply
`--manual-max-change-deg` plus either `--no-go-rectangle PAN_MIN PAN_MAX TILT_MIN TILT_MAX`
or `--no-go-unconfigured`. The latter declares a genuinely unconfigured region;
it must not erase an existing restriction. The software envelope comes from the
pinned QPT130 path: pan -215 to +215 degrees and mechanical tilt -90 to 0 degrees.
These are not independently measured mechanical stops. The rectangle must use
the same mechanical frame. The original tracking no-go azimuth 290..330 degrees,
elevation 0..30 degrees would map to pan -70..-30, tilt -90..-60 only with the
original zero pan offset; do not assume that calibration for another installation.
Endpoint checks do not evaluate travel between endpoints.

The following is a complete software configuration example only for a setup
whose one-degree maximum and zero-offset mechanical rectangle are confirmed:

```sh
satgs-operator bench-configure --transport local-serial --output "$HOME/satgs/manual-local-ptu.json" --manual-max-change-deg 1 --no-go-rectangle -70 -30 -90 -60
```

Generating it does not authorize movement. Query-only configurations reject
Move, arrows and Stop. The older `config/isolated-bench/*.example.json` files
remain incomplete TLS templates for separately assigned trust/credentials.

The selected device is
`/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller_EBCUb14C705-if00-port0`:
vendor/product `067b:23a3`, serial `EBCUb14C705`, interface `00`, driver `pl2303`.
The owner verifies its identity before and after opening. Current `/dev/ttyUSB0`
is not a fallback. The Cube's ttyACM interfaces are unrelated.

This candidate retains the original QPT130/PTCR20 settings: 9600 baud, 8 data
bits, no parity, one stop bit, no flow control, RTS/DTR asserted. These are
source-derived settings approved for the candidate, not measurements of the
cable. Opening applies serial settings/control lines and may flush input. It
does not automatically home, reset, calibrate, park or move.

## Retained broker route

This subsection is not required for local-serial operation. To choose the
separate broker route explicitly, generate `bench.json` with
`satgs-operator bench-configure --transport loopback-plaintext-bench --output "$HOME/satgs/bench.json"`.
It creates a matching private `bench.broker.xml` with generated credentials.
Do not attach those files to reports. Existing commands without `--transport`
retain this broker selection for compatibility; use `--transport local-serial`
for the direct route. Mixed local and broker settings are rejected.

The generated broker listener is restricted to `127.0.0.1:61613`, with
authentication, no bridge and no JMX/web-console configuration. Do not expose
plaintext or reuse production credentials. Operational pointing remains TLS-only.
Start only the assigned local broker using its matching private broker XML and
the administrator's existing ActiveMQ Classic installation. This application
update supplies configuration, not Java or a broker installation. The original
61613 recipe is a reference, not proof that ActiveMQ is installed or running on
this Pi. No service starts automatically and there is no production fallback.
With the local broker ready and the physical preflight complete, start the
foreground manager with the same JSON that the GUI/CLI will select:

```sh
~/satgs-bench-20261118-app-manager/bin/satgs-bench-manager --configuration "$HOME/satgs/bench.json" --duration 600
```

For broker manual control, generate an explicit broker manual configuration and
select that same JSON in both places. A local-serial configuration is rejected
by the foreground manager before any transport or device acquisition.
The example's
600 seconds is a software manager lifetime, not a motion or physical-stop
deadline. Keep its output. Connect in the GUI requests that existing manager;
it does not create a second serial owner.
Complete the physical and exclusive-access preflight before manager launch:
activation opens serial, while GUI Connect requests status from that owner.

This page covers PTU pan/tilt control. It does not provide a separate remote
terminal unit (RTU) interface.

## Connect one owner

Only one owner may control the unit. Do not run the old direct-serial GUI, a
manager or another CLI/GUI beside the selected local session. A conflict is rejected rather than forced
through. Opening PTU, editing target numbers, reading Help or changing tabs does
not connect to equipment or request a move.

The broker manual/query manager permits one connected controller, including
when another GUI or CLI uses a different workspace. A competing Connect reports
busy without querying the device. Explicit successful Disconnect releases that
claim. Closing a client locally, losing its connection or cancelling it does
not authorize another client to take over. If no correlated Disconnect is
possible, end the foreground manager under the approved recovery procedure
before starting a replacement. That passive cleanup is not a physical Stop.

The serial owner uses cooperative locking and Linux exclusive-open protection.
It does not evict another process or prove that no pre-existing noncooperating
reader exists. Confirm no other reader is using the adapter before Connect.

On PTU choose the reviewed Configuration JSON, then Connect. Local Connect opens
the selected serial connection and queries actual position without movement.
Status requests evidence from that same owner. Disconnect releases the session's local
resources. Neither Connect nor Disconnect requests an automatic move, park or
reset. An unavailable prerequisite leaves controls unavailable with a diagnostic.

## Read reported position without changing the target

Reported pan/tilt and Target pan/tilt have different purposes. Reported values
come from actual protocol/owner position responses. Target fields hold what you
are editing or requesting. A command acknowledgement is not an angle measurement,
and a reported protocol position is not independently measured physical arrival.

Position retains source/time/freshness. Unknown, stale, disconnected or unavailable
readback is not replaced with zero. Controlled/rehearsal provenance is retained.
Background Status polling is non-overlapping, skips a busy session, uses the
configured bounded cadence and stops with its owned session. Refresh never
overwrites a partly typed target.

If readback is stale, mismatched or missing, do not repeatedly press Move or an
arrow. Inspect the exact owner/transport outcome. Movement cannot use requested
coordinates as a substitute for current evidence.

## Use numeric positioning

Enter Target pan and tilt in degrees, click Preview, inspect the proposed
endpoint/policy outcome, then Move. Editing or previewing alone never moves.
The CLI equivalent within an admitted session is `preview PAN TILT`, followed
by `move`. Use finite numbers within the configured limits and allowed change.

Both numeric and directional paths retain frozen policy and final encoded
endpoint checks. A target whose encoded value enters a forbidden endpoint is rejected.
Endpoint approval does not establish safe trajectory clearance. No soft-limit
override is added to make a control appear responsive.

Manual context coordinates are mechanical pan/tilt degrees, not azimuth,
elevation, GPS heading or station location. Each request changes one axis by
at most the configured limit; set the other numeric axis to its latest returned
value. Requested and final encoded endpoints both obey the inclusive no-go
rectangle. There is no invented calibration, wrap, clamp or trajectory check.

## Enable discrete directional steps

In Directional steps, enter an explicit Step (degrees), then choose
Enable manual steps. There is no default increment chosen for your unit. The maximum comes
from the reviewed `max_change_degrees`; the minimum meaningful unit is the
selected protocol resolution, 0.1 degree for PTCR20 or 0.01 degree for PTCR96.
Other binding, range and policy checks still apply.

| Control | Requested change from fresh reported position |
| --- | --- |
| Left / `step left` | Decrease pan by one selected step |
| Right / `step right` | Increase pan by one selected step |
| Up / `step up` | Increase tilt by one selected step |
| Down / `step down` | Decrease tilt by one selected step |

One action performs correlated Status, computes one axis's absolute target,
previews it and submits Move through the same owner path as typed positioning.
It requests bounded motion when that session is admitted; it does not merely
edit a number and claim a move. Failed child phases and their correlated outcomes
remain visible. Busy dispatch rejects/skips further work rather than queueing
catch-up motion.

Click Keys in the pad to give arrow keys deliberate control focus. One press
requests one step; release before another press. Arrow keys in target entries,
text selection, scroll areas or another tab keep their normal behavior. Mouse
buttons provide the same four directions without global keyboard shortcuts.

Disarm disables the session-local step authorization. Stop, disconnect, close,
focus loss and tab/window changes also disarm it. Reconnect/restart does not
restore manual authorization. These local changes do not claim physical Stop.

![Current native PTU page with directional steps fresh controlled readback and separate partially typed targets](assets/native-ptu-20261112.png)

Actual handbook-release host capture on CPython 3.11.16/x86-64 and Tcl/Tk 9,
using an owned private Xvfb display. Controlled rehearsal reports pan 0 degrees
and tilt -10 degrees while target fields retain partial edits. The one-degree
step and Keys focus are separate from actual readback. This is not a Pi capture,
live-equipment observation or physical commissioning evidence.

## Interactive CLI and controlled session sequence

The public entry grammar is:

```text
satgs-operator [--workspace PATH] bench --configuration BENCH.json
```

`BENCH.json` denotes the completed private selected setup, not an unfilled
template. For the generated local example, use
`satgs-operator bench --configuration "$HOME/satgs/manual-local-ptu.json"`.
Do not run this CLI concurrently with a connected GUI. The sequence below is usable only if the one-degree increment,
starting point and resulting travel are authorized for that supervised session:

```text
connect
status
manual 1
step left
step right
step up
step down
disarm
status
disconnect
quit
```

The configured limits must permit a one-degree step. Inspect each
returned phase/outcome and actual starting readback rather than assuming the
requested target became current. For numeric parity, use the reported starting
position and a permitted endpoint with `preview PAN TILT`, then `move`; do not
invent coordinates merely to complete the transcript. The consolidated
acceptance report records the actual fixture values, outcomes and artifacts.

`manual STEP_DEGREES` enables the explicit increment. `step` accepts only left,
right, up or down; `disarm` clears authorization. Existing connect, status,
preview, move, stop, disconnect and quit remain available under their existing
admission. Invalid/nonfinite increment/targets, absent feedback, stale outcomes,
policy violations and concurrent-run conflicts reject without an authorized move.

## Stop failure and safe recovery

Stop is a separate owner operation. Local cancellation, passive disconnect,
park/reset and command acknowledgement do not establish physical stopping.
A required Stop failure remains latched and blocks further motion, including
after status/reconnect. Do not retry movement to clear that state.

Retain the outcome and follow the allocated unit's separately approved physical
recovery procedure. Closing releases owned local resources without automatic
park/reset. A command with an unresolved outcome remains unresolved; do not call
it completed because the window closed cleanly.

The actual PTCR20 Stop packet is the existing zero-jog command with its Stop
bit. Its acknowledgement and the following bounded status query are recorded
separately. Failure of the query does not erase the submitted Stop or its
acknowledgement. None of these establish physical stopping. A query-only
configuration rejects Stop and all motion operations; use manual capability
only after its explicit limits and supervised conditions have been established.

For first use, confirm the QPT130 cable/electrical hookup is the known-working
Pelican arrangement, exclusive access and a clear travel area. Connect and
inspect actual returned angles without requesting movement. Establish the lab's
independent stopping means and verify the supported Stop behavior under the
approved supervised procedure before testing bounded arrows or numeric moves.
Inspect/export the session afterward. The USB ID and inherited software settings
do not independently prove the physical wiring or travel safety.

The workspace retains explicit PTU operation attempts as `bench-<attempt_id>-started.json`
and `bench-<attempt_id>-result.json`. See [Results](results.md#find-what-was-saved-automatically)
for the step outcomes, partial-recording fields and files to preserve before recovery.

## What changed from the original PTU GUI

The original serialptu GUI really did have arrows, numeric controls and live
status updates. Its source is pinned in the [appendix](maintainer-reference.md).

| Interaction | Original serialptu GUI | Current SATGS session |
| --- | --- | --- |
| Left/Right | Press sends pan jog -1/+1; release sends zero jog | One bounded negative/positive pan step from fresh correlated readback |
| Up/Down | Press sends tilt jog +1/-1; release sends zero jog | One bounded positive/negative tilt step |
| Limits | Jog passes `override_soft_limits=True` | Same frozen policy/final encoded checks as numeric moves, no override |
| Numeric | Integer degrees; Move To/Return absolute, Move Delta relative | Finite degree targets, Preview then Move; steps use shared absolute owner path |
| Keyboard arrows | No arrow-key bindings | Deliberate Keys focus, press/release handling, no entry/scroll interception |
| Position display | Actual driver responses feed queued GUI status | Actual correlated owner responses, explicit freshness and separate target fields |
| Stop/release | Button release and ALL STOP send zero jog | No continuous jog latch; explicit disarm and separate Stop outcome |

Original keepalive defaults to 0.3-second status cadence with a 0.1-second loop
and bounded query wait; its protocol status path reissues the last jog command.
That continuous behavior is deliberately not reused. The new controls preserve
familiar direction/signs while choosing discrete bounded requests, explicit
authorization and truthful readback.

Physical commissioning still needs the allocated model/protocol/address and
limits, trustworthy current-position/Stop semantics, calibration/no-go admission,
alignment/trajectory requirements, serial ownership and live response evidence.
Software widget/owner tests do not establish those physical facts.
