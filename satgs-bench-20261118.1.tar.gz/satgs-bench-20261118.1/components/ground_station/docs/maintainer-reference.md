# Maintainer reference

This appendix records technical identities and deployment details that do not
belong in the everyday native window. The guide's operator narrative and
[tutorial](operator-tutorial.md) remain the starting points for daily use.

## Revision and source boundaries

| Record | Exact identity | What it establishes |
| --- | --- | --- |
| Original M-SEL ground_station comparison | `dd4ebf15f98d66cd8e973c7bd83becebef243276`, tree `789bd5b2087609e62b5834f1ef279f2b43931839` | Fixed source reviewed in the September 22 Slice 0 record and recaptured from existing local Git objects for this guide. No moving upstream main substituted. |
| Original inherited base | `5307276bf9a51be3ab858a2c0cef38469d10e5fb` | Historical base, not the selected current native implementation. |
| October 8 delivery baseline | `280fb4a8dc11efa35c190c27ebb147e5a2db689b` | Historical delivery provenance only. Not the original comparison revision or current UI revision. |
| Accepted native UI artifact | `9bdd7bfa3ebb76d8c840d36baa3625c932aec77d`, tree `30f31565d8ae37273a8c334fcc05e4f02c5eeac9` | Carries accepted plain component source and satgs `0.0.1+ui.20261111.1`. Artifact identity is distinct from component Git identity. |
| Accepted launcher correction | `d36b5729c56d71b27682c68261a61f022d27c8ba` | Reviewed launcher-fix artifact used as the launcher baseline. |
| Accepted guide baseline | `9cb4042d78d1bcc57bc80739fd65bef97e1d2945`, satgs and paired PTU `0.0.1+guide.20261112.1` | Latest accepted guide/UI/runtime source, not the October 8 snapshot. |
| Retained handbook release | satgs and reciprocal PTU package `0.0.1+handbook.20261112.1` | Preserved preceding application and rollback selection, not the current PTU candidate. |
| This PTU candidate | satgs, ptu_control and serialptu `0.0.1+ptu.20261117.1` | Normal descendant maintained source with version-matched docs. Final source/release identity belongs to its delivery record, not a self-referential invented commit. |

The original comparison capture records README blob
`fe40011dfdc20081179b7c95474d975179697e65`, SHA-256
`ee1df4ef1a1ac14542e63c448e1fefa2ca59ad6a831152374e91010845f85f3b`,
and build.sh blob `a55603e0d4435d9f2b8e3f95e2cedebccaa571b6`, SHA-256
`aeb8d308c5a4e8b4fcc070025b66f576767776df13c90e79e0660d3fb9ee45a0`.
The source-only capture and copied-baseline manifest are review evidence, not
runtime dependencies. They are excluded from the installed guide's lookup path.

Original documentation at that revision contains `docs/activemq_setup.md`, not
the later native operator guide. The operator-guide/tutorial chapters extend
the retained October 28 native documentation, whose separate current-operator
provenance records ground_station checkpoint
`ea4ad6ce9100f1ba0cd482f86994518ae08357ae` and delivery checkpoint
`7e7ffdf26e4f5dabcf1574738e6c55af168132fb`. Do not attribute those later manual
location/native controls to the original M-SEL revision.

## Original component pins

These gitlinks come from the fixed original parent tree. They are historical
source identities, not current release admission or installed package checks.

| Original component path | Exact selected revision |
| --- | --- |
| `lib/cyberpowerpdu` | `96fb02eccc923c2d2831dd0c9023415b3e743c88` |
| `lib/dsi_instruments` | `534c3a982b5e0af15efcd3ba276a13b70cda9888` |
| `lib/live_dashboard_be` | `ea161c4109b26af3dd840b365a55d5647130a862` |
| `lib/live_dashboard_fe` | `05c6d5993605064ced17445328b3da837ddb6e89` |
| `lib/meteor-api` | `2d0b8fd06e50ef1669cb5e46983441d4139a608f` |
| `lib/msel_post_processing` | `1211977cc2440aa8c8abd0b8c89d27f0c2762c9e` |
| `lib/pixhawk` | `2c641d3ca3331a829452327e1704a824b95fc968` |
| `lib/sat_tracker` | `d042abb35e12da465e29474476ae7acb25c64796` |
| `lib/signal_hound` | `6bb6af2bf75068a8b87d02b9feef8e2eb85fe2cb` |
| nested `lib/sat_tracker/lib/serialptu` | `b9f9c7b03c3c519bd9bf10da1ba291c7c6e6f3d4` |

The original PTU GUI is `serialptu/ptu_gui.py` at that nested revision, blob
`2e18a6ab272d0d6f48264d566210ba1ef7e83fda`, working-byte SHA-256
`dafb8218d41a3e86682e1cdcb3439b906378f1e9701ee4a05e39b31f7e2014cc`.
Its press/release jog callbacks, numeric controls and response-driven status
were source inspected, not executed against hardware. See the task-focused
[old/current interaction comparison](ptu-operation.md#what-changed-from-the-original-ptu-gui).

The current accepted native/runtime source retains six separately owned
components: ground_station, meteor-api, stomp.py, pixhawk, sat_tracker and
serialptu. Changed guide/package metadata does not qualify their production
owner contracts or import their complete original Git histories.

## Source map for behavior claims

All original paths below are relative to ground_station at the fixed original
revision unless a pinned component is named. Current paths are relative to the
selected candidate's ground_station component. Python basenames in the table
mean `src/satgs/BASENAME` for ground_station, `src/ptu_control/BASENAME` for
sat_tracker, `src/pixhawk/BASENAME` for pixhawk and `serialptu/BASENAME` for the
serialptu package. This map is intended for source review, not clickable runtime
file lookup.

| Behavior | Original file and symbol | Current file and symbol |
| --- | --- | --- |
| Public command spelling | `pyproject.toml` project.scripts; `pass_finder.py:main`; `queue_client.py:addJob/addSchedule/removeJob/clearQueue/requestQueue`; `pass_runner.py:main` | `operator_cli.py:parser/dispatch/main`; metadata keeps original console entries separately |
| Full suite installation | `build.sh`, ordered five copy-if-missing operations and ten pip invocations; original `pyproject.toml` setuptools-protobuf configuration | `build.sh` profile validation/apply guards; `deployment_cli.py` and `deployment_plan.py`; native preview does not invoke installer |
| Configured/alternate planning site | `pass_finder.py:PassFinder.__init__`, `at_locale`; `queue_client.py:QueueClient.__init__`; `pass_runner.py:PassRunner.__init__` | `operator_core.py:Workspace.preview_location/apply/inspect`; `station_location.py:Location/prepare_manual_location/location_from_settings`; `runtime_configuration.py` binding validation |
| TLE update/fetch/persistence | `pass_finder.py:PassFinder.__init__/add_sat_to_db/del_sat_from_db`; `utils.py:update_tle_db/add_new_tle/scrape_url` | `operator_planning.py:plan_workspace`; `runtime_configuration.py:_read_tle`; no refresh call in local operator planning |
| Pass calculation | `utils.py:find_passes`; `pass_finder.py:run_sat_passes/generate_csv_file` | `operator_planning.py:plan_workspace`, reuses `utils.py:find_passes`; `Workspace.record_plan` stores revision-bound output |
| Queue effects/cancellation | `queue_client.py` public adapters and setupClient; `queue_manager.py:clearQueueCb/deleteJob/job_thread/run` | `operator_runtime.py:preview_run/execute_run/run_status/cancel_run`; no native broker queue editor |
| Physical tracking and observations | `pass_runner.py:_initialize_pixhawk/_initialize_ptu/main/shutdown`, PixhawkSubscriber and PtuClient acquisition/commands; pinned component owners | `pass_runner.py` strict runtime-context/admission and owned lifecycle; `operator_runtime.py` result/physical-state separation; production admission remains unavailable |
| Pixhawk manager flag and position source | Pinned pixhawk `pixhawk_manager.py:main` declares --pix-id, not README's --ptu-id; manager GLOBAL_POSITION_INT handling scales lat/lon by 1e-7 and altitude by 1e-3; `pixhawk_subscriber.py:echo` selects sensor IDs | `operator_core.py:_replay_measurement` and `station_location.py` preserve explicit source/reference/units; no admitted live GPS selection |
| PTU application/wire identities | Pinned sat_tracker `ptu_manager.py:main` selects positioners ID and YAML protocol/baud; pinned serialptu `make_ptu`, `proto_impl.py:PTCR20/PTCR96`, `protocol.py:Quickset._build_message` retain no-ID versus wire-0 semantics | `operator_bench.py` admits selected QPT130/PTCR20 manual/readback configuration with isolated local TLS; satellite pointing admission remains closed |
| Output/post-processing/Box | `pass_runner.py` log setup/truth/test-details/TLE writes; `queue_manager.py:job_thread/analyze_thread/post_analyze_thread` | `operator_core.py:Workspace.report/export_report`; `operator_runtime.py` progress/results; no native Box/database workflow |
| Status meaning and human presentation | Original per-client observations/logging, not a shared native station view | `operator_core.py:Workspace.inspect/_replay_measurement/_metadata_identity`; `operator_presentation.py:human_text/presentation_document` |
| Native widget labels/actions | No original native operator application | `operator_gui.py:OperatorWindow._build_home/_build_setup/_build_location/_build_review/_build_results/_build_bench` and Help menu callback |
| Original PTU GUI and directional steps | Pinned serialptu `ptu_gui.py:ControlFrame.jog_controls/send_jog/get_coords`, `serialptu/ptu.py:PTU.KeepAlive`, protocol jog/status | `operator_bench.py` shared manual/step/disarm session, `operator_gui.py` focused directional pad and readback, owner bench status/preview/move |
| Documentation dispatch/build | No original docs entry point | `operator_docs.py`; `operator_cli.py`; `operator_gui.py`; `tools/build_operator_docs.py`; `setup.py:BuildPackage.run` |

The original full installer package order is meteor-api, ground_station,
msel_post_processing, cyberpowerpdu, dsi_instruments, pixhawk, sat_tracker,
sat_tracker/lib/serialptu, signal_hound, and signal_hound/lib. The native release
does not claim that its six-component candidate installed every optional full
deployment package.

## Daily launcher and desktop entry

| Item | Verified source contract |
| --- | --- |
| Menu application name | SATGS |
| Desktop entry category | `Categories=Science;` |
| Desktop file | `~/.local/share/applications/satgs-runtime-20261110.desktop`; historical filename retained |
| Exec target | Absolute quoted path to `~/.local/bin/satgs-operator-gui` for the setup account; for admin, `/home/admin/.local/bin/satgs-operator-gui` |
| Terminal GUI command | `satgs-operator-gui`, or the explicit installed wrapper if PATH is absent |
| Terminal status command | `satgs-operator status` |
| Shared daily selection | `~/.config/satgs/operator.json`, schema `satgs-daily-selection.v1`; application identity, candidate version and workspace are validated |
| Usual saved daily workspace | `/home/admin/satgs/station`, preserved unless explicitly changed through an approved selection operation |
| Current terminal PATH | Sourcing setup prepends the per-user bin path in that shell only; profiles and global PATH are untouched |

The accepted UI identity registers
`/home/admin/satgs-native-ui-20261111-app-manager`. The retained runtime identity
registers `/home/admin/satgs-runtime-20261110-app-manager`. The accepted guide
identity is `/home/admin/satgs-user-guide-20261112-app-manager`, selected as `guide`.
The preceding handbook is `/home/admin/satgs-handbook-20261112-app-manager`,
retained as `handbook` for rollback. The current PTU candidate is
`/home/admin/satgs-ptu-20261117-app-manager`, selected as `ptu` only after acceptance.
These technical paths are not manual
operator launch prerequisites. The dispatch wrappers resolve the selected
environment without activating it.

`source launchers/setup_daily.sh --select ptu` selects the registered PTU candidate
and shared workspace. It does not click the menu, open a window, initialize
station data, choose a component profile, select a replay/live source or prove
hardware readiness. Rollback `--select handbook` follows the same separation and
requires the same idle managed-station check. The GUI and CLI wrappers both load the
shared selection and supply its workspace to the chosen installed entry point.
An explicit `--workspace` overrides only that invocation.

Desktop category metadata and source-correct Exec are verifiable locally. The
remaining Pi observation is an actual SATGS menu click in the user's graphical
session, confirmation of that desktop's displayed submenu and the opened saved
station. A report that setup printed a menu item, or a separate runner exited
zero, is not evidence that the menu was clicked. SSH-only users should use CLI
documentation rather than force a display/session permission.

## Offline documentation build and packaging

Twelve canonical Markdown chapters and the maintainer appendix under
ground_station/docs produce one linked
`satgs/data/user-guide.html`, one `user-guide.txt`, local `user-guide.css` and a
deterministic `user-guide-manifest.json`. Finite actual native screenshot assets
have explicit source/output names in the builder; captions distinguish host
captures from Pi and physical evidence. Their source and output bytes are bound
in the manifest. The builder supports the small source
subset used here: headings, paragraphs, code fences, tables, lists and explicit
links. It escapes source text, checks internal links, and requires no external
Markdown library. The package build calls it through the existing build_py
flow. The compiler stays in source/build tooling, outside runtime imports.

The manifest records relative canonical source names/hashes, selected package
version and output hashes. It omits current timestamps and local checkout paths
so identical source/version produces identical resources. HTML uses system
fonts, local CSS, semantic headings/landmarks, a skip link, visible focus,
scrollable tables and print styling. It has no scripts, analytics or remote
assets. The terminal edition retains exact code examples, screenshot alternative
text and the provenance caption without HTML markup or image bytes.

Installed lookup is relative to the selected satgs package, never current
directory, Downloads or a source checkout. The same wheel carries the content
opened by CLI and Help. Older installations keep their own guide, if they have
one; selecting this release does not search for a newer manual on a moving
branch. Documentation-only paths avoid workspace/configuration loaders and
optional owner stacks. Default-viewer dispatch uses a known local executable
and argument array, never a shell command, BROWSER string, pager or server.

## Validation and evidence interpretation

The accompanying candidate acceptance report is the authority for commands
actually executed, installed origins, assertions and artifacts. Review these
distinct checks: fresh wheel resources outside checkout; all three docs forms;
missing/invalid station; wrong working directory; paths with spaces; old/new
installed resources; headless/SSH/text; viewer success/failure/timeout; and
documentation-only imports with effects denied. A controlled viewer substitution
tests dispatch mechanics, not the desktop's rendered content.

The native check must invoke the real Help callback with real widgets, preserve
unsaved draft/result/tab state, demonstrate event-loop responsiveness and retain
owned cleanup. Content checks compare CLI parser/options and current widget
labels, validate internal links/assets and execute worked examples only in new
private workspaces under the existing guards. Legacy broker/hardware commands
remain source reviewed. Prior Pi/native/telemetry evidence is retained without
rerunning unrelated historical suites or attributing its PASS to changed bytes.

If a current capability is implemented but not target-tested, report that exact
state. Do not convert an operator-observed PASS into a new independent run, or
call a source-reviewed command an executed example. Reports keep software
completion, submission and physical state separate.

## Update, selection and rollback

Use the candidate's supplied side-by-side setup command and consolidated
acceptance command. They reuse retained offline dependency inputs and create
separate candidate environments. They do not patch accepted site-packages,
move virtual environments, reset the saved station or select a release merely
because setup succeeded. Candidate selection is explicit after reviewed
acceptance.

If the candidate is rejected, retain the prior selection. If an already selected
PTU candidate must be rolled back, use its retained reviewed launcher setup
to select the preceding compatible `handbook` identity. Preserve environments, workspaces,
partial results and evidence. Rollback is selection, not deletion or a claim of
physical stopping. No database migration or workspace schema conversion is
introduced by this feature.

## Accepted target baseline and evidence layers

The supplied guide acceptance attempt `operator-acceptance-89c0lgy3` ran on
CPython 3.11.2/aarch64 against the accepted guide application. Its ten phases
passed; independent source/data review checked actual raw completions,
summary/completion/archive consistency and installed resource identity. It
does not accept the subsequently changed handbook/PTU/update bytes.

The operator separately supplied the unchanged daily selection document identifying
`guide`, application `/home/admin/satgs-user-guide-20261112-app-manager`, and
workspace `/home/admin/satgs/station`. That is operator-reported selection,
not a new independent SSH/Pi read. This task makes no direct Pi or physical
commissioning claim for the current PTU release.

For this release, use its own reports to distinguish source implemented,
host tested, Pi tested and physically commissioned. Actual host screenshots
show widgets and their labeled controlled/unavailable states, not live equipment.
The old retained daily-support `rehearse.sh` targets its older runtime application;
its output is not a current-release run result. Export's historical baseline
fields are carried-forward technical provenance, not the selected application
version or a new acceptance claim.
