# 12. CLI reference and glossary

The public application commands are `satgs-operator` and
`satgs-operator-gui`. Installed daily wrappers choose the saved application and
workspace. They work outside the extraction directory. The direct CLI package
entry point used without those wrappers defaults to `./satgs-workspace`; the
direct GUI without `--workspace` opens with no station selected. Specify an
absolute `--workspace` when using either directly, instead of confusing those
developer behaviors with the shared daily selection.

## Command grammar

```text
satgs-operator [--workspace PATH] [--format human|json] COMMAND [OPTIONS]
satgs-operator --read-docs
satgs-operator-gui [--workspace PATH]
```

Global options precede the command. Arguments are not abbreviated. Quote paths
containing spaces. `--workspace` affects one invocation, not the saved daily
selection. Human output uses readable fields and omits low-level IDs and paths.
JSON returns the established `status` and `result`, or `status` and `error`,
envelope. Read a returned ID from `result`; never invent one. JSON errors retain
their code and message. Use `satgs-operator --help` or `COMMAND --help` for the
installed parser's exact option spelling.

## Documentation

| Form | Behavior |
| --- | --- |
| `satgs-operator docs` | Opens the bundled HTML with the ordinary local default viewer on a usable desktop; otherwise prints readable terminal text. |
| `satgs-operator --read-docs` | Alias of the same docs dispatcher, with the same selection and fallback behavior. |
| `satgs-operator docs --text` | Prints the terminal guide directly; no display, Tk, browser or pager. |
| `satgs-operator --format json docs --text` | Preserves the CLI JSON envelope, including documentation mode/message/text and technical resource identity. |

Docs are available with missing or invalid configuration and before station
initialization. SSH sessions use terminal fallback even if an inherited display
variable exists. Viewer absence, failure or timeout falls back to text. Exit 0
then means documentation was delivered, not that a window rendered. Missing or
unreadable packaged resources return docs_unavailable, exit 4. There is no topic
option; `docs --topic anything` is invalid input, exit 2.

## Workspace inspection and creation

| Command | Options | Effect and matching GUI action |
| --- | --- | --- |
| `init` | `--case pelican-qpt130`, the default and only supported case | Creates a new private workspace only. Home > New station.... Refuses existing or unsuitable targets rather than resetting them. |
| `status` | None | Reads saved station, generation/revision, configuration, manual/effective/replay position and independent status dimensions. Home > Reload (Ctrl+R). |
| `reload` | None | Same saved-state read as status. Required after another interface saves. |
| `catalog` | None | Reads canonical profiles, components and constraints. Corresponds to Setup's available choices, not installed hardware inventory. |
| `report` | None | Reads the redacted station report, retained plan summaries and receipt/cancel results. Results > Report. Full plan/run files remain separate. |

`status` and `report` do not create or initialize a workspace, contact a broker or
construct operational owners. Reports are local evidence, not proof of an active
process. Keep credentials and workspace data outside source history.

## Component selection

```text
components-preview --profile guided_arrow|full_msel|custom
                   [--changes JSON_PATH] [--ptu-model QPT130]
                   [--expected-revision SHA256]
```

The profile is required. Model defaults to QPT130; QPT-130 is also accepted by
the shared case validator. Other models are rejected for this Pelican case.
`--changes` reads a bounded ordinary UTF-8 JSON file containing either canonical
selection fields or a component-to-change mapping. Unknown components,
unsupported provider combinations and missing stable hardware instance
identities are rejected. The CLI and Setup use the same validator.

For example, `{"rf.frontend":"omit"}` expresses an explicit component-mode
change for a Custom draft. It is not an instruction to uninstall a package or
switch off equipment. Complete canonical documents must satisfy their real
identity, provider and version contracts. Do not infer those from this one-field
example.

Preview returns `result.preview_id`, previous/proposed values, the expected
station revision and affected plans. It saves a preview artifact without
applying configuration. Supplying `--expected-revision` allows a caller to reject
a concurrent change explicitly. A revision is the exact saved document's
64-character SHA-256 identity from JSON status, not a generation number.

## Manual location

```text
location-preview --latitude-deg NUMBER --longitude-deg NUMBER
                 --altitude-m NUMBER
                 --altitude-reference unspecified|mean_sea_level
                 [--expected-revision SHA256]
```

All four location inputs are required. Latitude/longitude are decimal degrees,
north/east positive. Altitude is metres, not feet. Values must be finite and
pass the shared station-location validator; latitude is [-90,90], longitude
[-180,180]. The reference is declared, not measured or converted. Location >
Preview is equivalent. The returned preview does not move equipment.

## Apply or cancel a preview

```text
apply --preview PREVIEW_ID --confirm
cancel --preview PREVIEW_ID
```

`PREVIEW_ID` is the exact returned preview identity. Apply requires explicit
confirmation after review. Review > Save applies the same operation. Cancel
corresponds to Review > Cancel (Esc), leaves station settings unchanged and
records cancellation. Repeated successful apply/cancel is idempotent. A
cancelled preview, stale revision or conflicting active managed runner cannot
be forced through. A successful save can be followed by partial receipt/I/O
failure; inspect retained state before retrying.

## Numerical pass planning

```text
plan [--start ISO8601_WITH_OFFSET] [--norad-id INTEGER]
     [--span-days NUMBER] [--elevation-deg NUMBER]
     [--tle-file LOCAL_CSV]
```

| Option | Default | Units and restriction |
| --- | --- | --- |
| `--start` | `2025-05-16T03:00:00Z` | Explicit UTC offset required; normalized to UTC. Historical replay default. |
| `--norad-id` | `25338` | Positive integer through 2147483647, present unambiguously in the CSV. |
| `--span-days` | `1` | Finite days from 1/24 through 7. |
| `--elevation-deg` | `20` | Finite degrees from 0 through 90. |
| `--tle-file` | Bundled historical NOAA 15 CSV | Bounded ordinary local CSV; no refresh, URL, broker lookup or source modification. |

This uses the real numerical orbit calculation and records a plan, with at most
256 opportunities. Results > Calculate is equivalent. Missing saved location,
invalid time/units, malformed or mismatched TLEs and missing scientific
dependencies are reported. A plan records its input location/reference/revision,
TLE hash and epoch, refresh=false and execution_enabled=false. It is not a queue
submission or completed tracking run.

## Runtime request review and execution

The following is a grammar reference, not a ready-to-run hardware example:

```text
run-preview --plan-id PLAN_ID --deployment-config CONFIG.json
            --runtime-bindings BINDINGS.json --station-config OWNERS.json
            --tle-file LOCAL.csv --duration SECONDS
            [--opportunity INTEGER] [--mode operational|rehearsal]
run-start --run-id REQUEST_ID --confirm
run-status --run-id REQUEST_ID
run-cancel --run-id REQUEST_ID
```

`PLAN_ID` is an existing saved plan identity. `CONFIG.json` is the canonical
deployment configuration matching the saved selection. `BINDINGS.json` is the
reviewed runtime-owner binding document. `OWNERS.json` contains the explicit
station/owner settings accepted by the runtime reader. `LOCAL.csv` must match
the exact local TLE used for planning. These are separately supplied private
reviewed inputs, not filenames that SATGS creates automatically.

Duration is positive finite seconds that fit the selected opportunity.
Opportunity is 1-based and defaults to 1. Mode defaults to `operational`.
Review run freezes all input identities and the saved position/reference;
Start run separately confirms. Changes after review require a new request.
Ordinary production admission remains empty. `rehearsal` records intent, not a
permission bypass. No valid live owner recipe is supplied by this release.

`run-start` owns synchronous CLI execution and prints progress on stderr. Use a
separate terminal with the same workspace and request ID for status or local
cancellation. `run-status` before start reports not_started. A saved unfinished
progress record does not establish a live process. Cancel run does not prove
remote cancellation or physical Stop. A finished result is returned on repeated
execution of that request rather than silently repeated motion.

## Reports, export and replay

```text
export --output NEW_FILE
replay --state STATE
```

Export writes one new private JSON report and refuses an existing output. The
parent directory must already be suitable; `-` is not an output path. Results >
Export... is equivalent. No database or remote-storage action is implied.

Replay is an explicit CLI-only synthetic observation selection. States are
`unknown`, `disconnected`, `silent`, `no_fix`, `reported_3d`, `stale`,
`mismatched`, `incomplete` and `critical`. Home > Reload displays the saved
scenario. It does not overwrite the manual position, connect hardware or make
GPS eligible for station selection. Source/time/fix/freshness remain distinct.

## PTU command session

```text
bench-configure --transport local-serial --output BENCH.json [--manager-id ID] [--exchange-timeout SECONDS] [--feedback-max-age SECONDS]
bench-configure --transport local-serial --output BENCH.json --manual-max-change-deg DEGREES (--no-go-rectangle PAN_MIN PAN_MAX TILT_MIN TILT_MAX | --no-go-unconfigured)
bench --configuration BENCH.json
```

`bench-configure --transport local-serial` creates one private JSON without
opening a station, socket or device. The session directly owns the existing
serialptu driver, with no broker credentials, Messenger or manager service.
Without manual arguments it grants query-only capability. Existing files are
never overwritten. `--transport loopback-plaintext-bench` retains the separate
private JSON plus ActiveMQ XML workflow at `127.0.0.1:61613`; omitting transport
retains that prior broker default. No mode installs or starts ActiveMQ and there
is no transport fallback. Retain any partial broker configuration after a write failure.
See the [complete examples and inherited frame/limits](ptu-operation.md).

The interactive commands are `connect`, `status`, `preview PAN TILT`, `move`,
`manual STEP_DEGREES`, `step left|right|up|down`, `disarm`, `stop`, `disconnect`
and `quit`. Pan/tilt and step are degrees. The same session operations
back the PTU page. `BENCH.json` is an approved private setup document with exact
manager, serial identity/settings, protocol, timing and trust inputs; manual
capability adds mechanical limits and no-go policy. Selected QPT130/PTCR20
manual and query-only sessions use validated explicit local serial configuration
or an isolated broker, either retained TLS or selected loopback plaintext.
Only the broker route requires a separately running manager and broker.
Satellite pointing admission remains closed.
Neither a device label nor a guessed USB path supplies those inputs. Follow
the [PTU first-use procedure](ptu-operation.md) before equipment access.
Passive cleanup or a returned acknowledgement is not physical Stop.

`manual` requires an explicit finite increment within the selected protocol
resolution and configured allowed change. Each `step` uses fresh correlated
Status, computes one-axis target and performs Preview/Move through that owner.
`disarm` clears session-local step authorization. Stop/disconnect/close and GUI
focus/tab/window changes also disarm; reconnect does not enable it. A required
Stop failure blocks motion. See [PTU operation](ptu-operation.md) for focus,
readback, outcome and physical commissioning distinctions.

## Exit codes and result meaning

| Exit | Meaning |
| --- | --- |
| 0 | Requested local operation completed, or documentation delivered. Not installation/navigation readiness or physical completion. |
| 2 | Invalid arguments, invalid input, unsupported choice, or a missing/malformed station document rejected by the package reader. |
| 3 | Conflict, stale/cancelled preview, workspace activity/private-directory/marker admission rejection, unavailable prerequisite, not_started or rejected owner/runtime admission. |
| 4 | I/O, calculation, partial local operation, unavailable guide resource or unexpected local failure. |
| 5 | Runtime execution failure. |
| 6 | Runtime result/progress persistence failure. Keep partial artifacts. |
| 7 | Runtime cleanup failure where reported by the runner. |
| 8 | Physical state indeterminate. JSON status is INDETERMINATE, not PASS. |
| 130 | Local CLI/run cancellation or interruption. Does not establish physical Stop. |

For runtime results inspect `primary`, `manager_outcome`, `software_completed`,
`physical_state`, submission details and cleanup/save fields together. The
operation's evidence is more specific than a single process exit code.

The daily wrapper validates its own selection, application and workspace before
the package runs. Its missing/unsuitable selected-path failures can return exit
1 with a launcher diagnostic rather than the package JSON envelope. Keep the
launcher and package failure layers separate. Docs bypasses station validation,
not the selected-application identity check.

See the [hands-on examples](operator-tutorial.md) for real returned-ID handling,
and the [maintainer appendix](maintainer-reference.md) for installed resource and
launcher details.

## Glossary

| Term | Meaning in this handbook |
| --- | --- |
| AIO | All-in-one physical packaging. It does not by itself establish software modularity. |
| ActiveMQ | Independently provisioned message-broker server used by application clients. |
| ACK | Acknowledgement of a protocol/owner exchange, not measured angle or physical completion. |
| Application manager ID | Positive configured client/manager identity. It is not the serial wire address. |
| Admission | Checks allowing an exact selected owner/session/input contract to proceed. A mode label is not admission. |
| Calibration / heading | Mechanical/pointing frame and directional qualification, separate from site coordinates. |
| Canonical component | An actual shared catalog identity, either software, hardware, system or capability. |
| Configuration intent | Saved choice of components/providers/modes; not installed or ready equipment. |
| Cube / Pixhawk | Navigation controller observed through the assigned host connection; GPS receiver UARTs are separate. |
| Generation / revision | Saved configuration sequence / exact saved document identity. Neither is an installation result. |
| GPS / GNSS | Global Positioning System / global navigation satellite systems. Fix, health, freshness and heading are separate evidence. |
| HPA / PDU | High-power amplifier / power distribution unit. Outlet mapping and physical condition need equipment evidence. |
| IQ / SigMF | In-phase/quadrature recording / signal metadata format used by legacy RF captures. |
| JSON | Structured local data format used for current station artifacts and reports. |
| MAVLink | Message protocol carrying Pixhawk/navigation observations. Receipt alone does not establish a valid selected position. |
| Messenger / STOMP | Shared Python application messaging / its selected broker transport protocol. Neither is the server installation. |
| NORAD ID | Positive satellite catalog identity selected unambiguously from the local orbit input. |
| No-go policy | Reviewed forbidden pointing regions enforced with selected calibration/policy, including final encoded endpoint checks. |
| Opportunity / plan | Predicted visibility interval / retained calculation inputs and opportunities, not an executed pass. |
| PTU | Pan/tilt unit. A separate RTU, if intended, has not been identified by this task. |
| RF | Radio frequency; front-end controls/captures remain distinct from numerical planning. |
| Rehearsal / replay | Controlled execution intent / synthetic observation selection. Neither enables live hardware. |
| Request / run result | Frozen reviewed runtime input / actual recorded outcome. IDs are not legacy numeric queue job IDs. |
| TLE | Two-line element orbit data, with selected satellite identity and source epoch. |
| TLS | Verified transport encryption/identity. Private keys and credentials stay outside source and shared reports. |
| UTC | Coordinated Universal Time. Current planning requires an explicit time offset. |
| Wire address | Low-level protocol address, distinct from application manager ID or equipment label. |
| Workspace | Private managed station directory containing settings and artifacts, bound to its original absolute path. |
