# 4. Install and prepare the selected deployment

An already accepted daily application normally needs no reinstall. Inspect it
with `satgs-operator status` and read its installed guide first. Install an
update into a separate candidate environment, check it, then explicitly select
it. Keep the current application, station, dependencies and failed attempts.

## Prerequisites and assigned responsibilities

The native release pairs satgs and ptu_control at `0.0.1+bench.20261118.1` with
unchanged serialptu `0.0.1+bench.20261117.1`. It retains the paired Meteor/lower
loopback versions. Other reviewed runtime dependencies are reused. Explicit
local-serial bench control does not require ActiveMQ or a manager service.
The established target route uses the existing CPython 3.11 environment and its
offline dependency inputs. Native GUI work needs usable Tk/Tcl and a normal
desktop session; CLI docs and local station operations do not need a display.

Before preparing an installation, assign the runtime account, candidate and
evidence directories, preserved station workspace and intended software roles.
For services, also assign the responsible administrator and real resource
identities. Do not turn a PTU label, USB example or sample broker address into
an operational binding.

| Resource | Responsible role | Information required before operational use |
| --- | --- | --- |
| Application and offline dependency inputs | Release maintainer/operator | Exact release content, compatible interpreter/platform, separate candidate paths |
| ActiveMQ and time | Host/service administrator | Broker release, Java runtime, address/identity/trust, private authentication, time source |
| PTU manager and physical unit | Pointing/equipment owner | Stable instance, application ID, model/protocol/baud/wire address, policy and position/Stop contracts |
| Pixhawk and dual GPS | Navigation owner | Sensor/PTU IDs, host connection, receiver connections, source/fix/time/reference/heading qualification |
| RF, power and recording | RF/equipment owners | Instruments, outlet mapping, receiver/native support, frequency/power constraints and output capacity |
| Processing and optional storage | Data/service owner | Parser compatibility, input/output directories, retention and private service access |

## Install the native release offline

Obtain the versioned PTU update through its existing internal browser/download
route. Extract it into its own new directory and open a Bash terminal there.
Do not extract over an older delivery or copy files into accepted site-packages.
The release's root README is the exact handoff for that package.

The setup entry point is:

```sh
. ./setup_update.sh --accept-trusted-native
```

The trusted-native flag acknowledges the reviewed CPython/stdlib/native boundary;
the Python API/audit controls are not syscall isolation. Setup reuses retained
offline dependencies and stages a separate candidate. It does not select it,
reset a station, connect equipment or start operational services.

After setup succeeds, run the consolidated acceptance from the same extraction.
Select only after its report passes and there is no conflicting activity:

```sh
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select bench
```

The target application is `/home/admin/satgs-bench-20261118-app-manager`.
The preceding `/home/admin/satgs-ptu-20261117-app-manager` is retained for rollback.
The saved station remains `/home/admin/satgs/station` unless the operator has
deliberately selected another workspace. Setup/acceptance print their separate
report and attempt paths. Keep `report.txt`, `summary.json`, `completion.json`,
`evidence.tar.gz` and failed/partial environments. Failure is a reason to retain
the current selection, not to delete the new attempt and try over its files.

Verify the selected commands from a different normal working directory:

```sh
satgs-operator docs --text
satgs-operator status
```

On the desktop, open SATGS from the menu and inspect the saved station. A setup
message about a menu item does not establish that the menu was clicked. Changed
host tests, Pi checks and equipment commissioning stay separately reported.

## Software roles and package selection

This table explains the maintained dependency selections. It is not an instruction
to run pip inside an accepted application. The reviewed setup builds/installs
the appropriate wheels together; a source pull alone does not install them.

| Role | Exact selected package or extra | Separate prerequisites |
| --- | --- | --- |
| Shared operator/planning application | `satgs==0.0.1+bench.20261118.1` | Python 3.10+, actual scientific dependencies; Tk only for the window |
| Pointing clients | `satgs[pointing]==0.0.1+bench.20261118.1` | Paired PTU client and `pixhawk==0.0.1`, assigned external owners if used |
| Local PTU owner prerequisites | `ptu_control[manager]==0.0.1+bench.20261118.1` | Retained `serialptu==0.0.1+bench.20261117.1`, SciPy; local bench needs no broker or running manager |
| Local Pixhawk manager | `pixhawk[manager]==0.0.1` | pyserial, pymavlink, NumPy and assigned observation source |
| Shared messaging | `meteor_api==2.2.0+bench.20261117.1` and `stomp.py==8.1.0+bench.20261117.1` | Independent ActiveMQ server and explicit reviewed transport settings |
| Optional Meteor ZeroMQ | `meteor_api[zmq]==2.2.0+bench.20261117.1` | NumPy/pyzmq for its actual METEOR paths |
| Plotting/front-end libraries | `satgs[plotting]`, `satgs[frontend]`, or `satgs[full]` at the same satgs version | Their libraries, plus separately provisioned RF owners/equipment |
| Optional Box integration | `satgs[box]` at the same satgs version | Internal package access, private credentials and assigned Box destination |

The `gui` extra is empty because Tk is a system/native prerequisite rather than
a pip-provisioned GUI framework. The build generates the reviewed protobuf
modules before packaging. Runtime installations use those generated modules and
do not need a compiler. A developer needs the maintained build instructions,
not an arbitrary system protoc chosen from an old compatibility table.

## Prepare messaging and time

Local planning needs neither server. A manager/queue deployment does. The
service administrator first records its assigned ActiveMQ release, compatible
Java, service account, listener and storage location. The historical source
runbook describes ActiveMQ Classic and `activemq.service`; it is not proof of a
newly qualified server installation for every target OS.

Configure verified TLS identity/trust and private broker authentication through
the service owner's approved route. Keep public certificate trust distinct
from certificate private keys. Application settings separately identify the
dial address, TLS server name, STOMP host where required and credentials.
Do not disable TLS verification or paste production values into this guide.

The separately selected mechanical bench also supports explicit plaintext STOMP
on `127.0.0.1:61613`, matching the original local recipe's protocol. Use
`satgs-operator bench-configure` to create matching private JSON/XML. It never
changes an operational TLS configuration, starts a server or installs Java.
This exception is not available to satellite pointing. See [PTU operation](ptu-operation.md).

After the administrator's separately authorized provisioning/start procedure,
these are useful service/time inspections on that assigned host:

```sh
systemctl status activemq.service --no-pager
chronyc sources
timedatectl
```

Confirm the selected source and actual synchronization, then the application's
exact transport/owner result. An installed Java/Python package is not a running
broker; a running broker is not healthy equipment. If the site has no maintained
broker install procedure and assigned resources, new server provisioning remains
a deployment gap. Do not use an unreviewed generic configuration script to fill it.

## Prepare a PTU owner

Decide whether the serial owner runs locally or is independently supplied.
Only a local owner needs the local manager/driver role. Allocate the exact
physical QPT130 and record the stable hardware instance, positive application
manager ID and separate serial wire identity. Confirm the model/protocol, baud,
adapter, permissions, calibration/no-go policy, reported-position semantics and
required Stop contract with the equipment owner.

The retained `ptu.service` shows the owning manager program, not a runnable recipe
for this unit. Its historical username, serial path and arguments must not be
copied as commissioning values. Use a reviewed bench setup document and owner
binding instead. Selected QPT130/PTCR20 manual and query-only sessions are admitted
through their validated private configuration and isolated local broker, using
either verified TLS or the explicit loopback-only plaintext bench selection.
Satellite pointing admission remains closed; software admission does not establish
physical commissioning.

The supported software check uses the controlled owner path in consolidated
acceptance, then verifies the actual session outcomes and displayed provenance.
Do not start the original direct-serial GUI concurrently. See [PTU operation](ptu-operation.md)
for deliberate connect, readback, numeric moves, discrete steps and cleanup.

## Prepare navigation observations

Assign the Pixhawk application ID and PTU mapping, then the host-side Cube USB
connection. Separately record the two receiver UART connections and navigation
stack. A local `pixhawk[manager]` installation does not configure firmware,
receiver links, moving-baseline heading or antenna alignment.

The retained manager parser uses `--pix-id` and `--port`; its old README contains
a different ID flag. Treat the historical service file as a template only.
Before live use, the navigation owner supplies source identity, fix/health,
timestamp/freshness, coordinate/altitude references and heading/alignment evidence.
This task does not change Cube or GPS settings. Use manual station coordinates
for supported local planning; Use GPS remains disabled.

## Prepare RF power and recording

A complete Full M-SEL deployment needs the actual dsi_instruments, cyberpowerpdu
and signal_hound owners, plus the native wrapper/vendor runtime and equipment.
The native six-owner update does not install them. Full M-SEL's retained installer
supports its complete package order only when the real owner tree, generated
modules and native prerequisites have been prepared.

The RF/equipment owner assigns instrument ports/names, PDU identity and outlet
mapping, receiver model/serial/native compatibility, approved operating limits
and output capacity. Adapt the corresponding service units to the runtime
account and reviewed configuration. Do not use broad recursive/world-writable
permissions from historical examples.

Inspect configuration and reported state under the equipment runbook before an
RF task. Turning on an HPA, switching routes or starting a recording is an
operational action, not an installer smoke test. A new receiver installation
without a maintained model/native/platform procedure remains unsupported until
that procedure is provided. Sponsor external selections do not repair it.

## Prepare legacy processing and storage

Post-processing consumes legacy pass directories, not the native report JSON.
The data owner installs the compatible msel_post_processing package and parser,
plotting/report dependencies with the full station. It assigns input/output
locations, capacity, retention and backup. Retain raw captures and failures so
analysis can be repeated.

Box is optional and historically disabled by default. It requires separately
available internal `box-api-sync` tooling, private authentication, an assigned
destination and deliberate `box_connectivity` configuration. The retained queue's
automatic Box path is narrower than a general upload service. Native Export
does not use it. Optional email also needs protected owner-supplied SMTP settings.

There is no native database-history installation, migration or upload workflow.
Do not create a database or infer successful storage from a dashboard connection
or a CSV named database. Read [Results](results.md) for the files saved here and
the [migration comparison](legacy-comparison.md) for old output behavior.

## Source access and complete Full M-SEL installations

Maintainers obtain the maintained integration source through the internal
repository route described in [Updates](updates-troubleshooting.md). Keep its
six ownership boundaries and notices. The separate Full M-SEL source route needs
all actual legacy owners and their compatible dependencies, not fabricated empty
submodule directories in a native release checkout.

In that complete, prepared ground_station owner checkout the retained commands
for inspection and guarded legacy installation are:

```sh
./build.sh --non-interactive --profile full_msel --dry-run
./build.sh --non-interactive --profile full_msel
```

Run the second only under the separately approved full deployment procedure,
after its prerequisites and intended environment are reviewed. For Guided Arrow,
only the static dry-run route is supplied:

```sh
./build.sh --non-interactive --profile guided_arrow --dry-run
```

There is no Guided Arrow apply or native one-click service installer. Use the
working offline native setup for supported station tasks and keep the precise
operational gaps visible when preparing a larger installation.
