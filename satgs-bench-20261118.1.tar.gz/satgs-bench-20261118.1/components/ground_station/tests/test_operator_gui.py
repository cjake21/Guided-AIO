"""Presenter coverage and real native-widget coverage are separate test classes."""

from copy import deepcopy
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
from types import SimpleNamespace
import sys
import tempfile
import threading
import time
import traceback
import unittest
from unittest.mock import patch

from satgs import operator_core as core
from satgs.operator_core import Workspace, initialize_workspace
from satgs.operator_activity import StationLease
from satgs.operator_gui import OperatorPresenter, OperatorWindow, display_unavailable
from satgs.operator_presentation import LEGACY_STATION_NAME, human_text


class OperatorFixture:
    def make_workspace(self):
        temporary = tempfile.TemporaryDirectory(prefix="satgs-gui-test-")
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.workspace = initialize_workspace(self.directory / "practice")
        self.presenter = OperatorPresenter(self.workspace)
        self.assertTrue(self.presenter.dispatch("refresh")["ok"])

    def preview_location(self, **overrides):
        values = {"latitude_deg": "42.3", "longitude_deg": "-71.1", "altitude_m": "12.5",
                  "altitude_reference": "unspecified"}
        values.update(overrides)
        return self.presenter.dispatch("preview_location", **values)


class HeadlessOperatorPresenterTests(OperatorFixture, unittest.TestCase):
    def setUp(self):
        self.make_workspace()

    def test_00_import_does_not_require_tk_display_or_load_runner(self):
        self.assertIn("satgs.operator_gui", sys.modules)
        self.assertNotIn("tkinter", sys.modules)
        self.assertNotIn("satgs.pass_runner", sys.modules)

    def test_only_display_connection_errors_are_classified_as_display_unavailable(self):
        for message in ("no display name and no $DISPLAY environment variable",
                        'couldn\'t connect to display ":15"', 'cannot open display ":15"'):
            with self.subTest(message=message):
                self.assertTrue(display_unavailable(RuntimeError(message)))
        for message in ("Can't find a usable init.tcl", "guard denied normalization",
                        "invalid command name", "could not read Tcl package"):
            with self.subTest(message=message):
                self.assertFalse(display_unavailable(RuntimeError(message)))

    def test_real_shared_preview_apply_and_reload(self):
        before = self.workspace.station_path.read_bytes()
        outcome = self.preview_location()
        self.assertTrue(outcome["ok"], outcome)
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        preview = outcome["result"]
        expected = self.workspace.preview_location(42.3, -71.1, 12.5, "unspecified",
                                                    expected_revision=self.presenter.revision)
        self.assertEqual(preview, expected)
        self.assertIsNone(preview["previous"])
        self.assertEqual(preview["proposed"]["altitude_reference"], "unspecified")
        outcome = self.presenter.dispatch("apply")
        self.assertTrue(outcome["ok"], outcome)
        self.assertEqual(outcome["result"]["result"], "saved")
        reloaded = OperatorPresenter(Workspace(self.workspace.root))
        self.assertTrue(reloaded.dispatch("refresh")["ok"])
        self.assertEqual(reloaded.status["manual_location"]["latitude_deg"], 42.3)
        self.assertEqual(reloaded.revision, self.presenter.revision)
        self.assertFalse(reloaded.status["manual_location"]["altitude_qualified"])
        self.assertFalse(outcome["result"]["active_run_changed"])

    def test_cancel_and_invalid_inputs_do_not_save(self):
        before = self.workspace.station_path.read_bytes()
        self.assertTrue(self.preview_location()["ok"])
        outcome = self.presenter.dispatch("cancel")
        self.assertTrue(outcome["ok"], outcome)
        self.assertEqual(outcome["result"]["result"], "cancelled")
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        for values in ({"latitude_deg": "nan"}, {"longitude_deg": "181"}, {"altitude_m": "infinity"},
                       {"latitude_deg": "not-a-number"}, {"altitude_reference": "invented-datum"}):
            with self.subTest(values=values):
                self.assertFalse(self.preview_location(**values)["ok"])
                self.assertIsNone(self.presenter.preview)
                self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.assertFalse(self.presenter.dispatch("apply")["ok"])

    def test_stale_revision_is_rejected_by_shared_operation(self):
        other = Workspace(self.workspace.root)
        pending = other.preview_location(40, -70, 25, "mean_sea_level")
        other.apply(pending["preview_id"])
        saved = self.workspace.station_path.read_bytes()
        outcome = self.preview_location()
        self.assertFalse(outcome["ok"])
        self.assertEqual(outcome["error"]["code"], "stale_revision")
        self.assertEqual(saved, self.workspace.station_path.read_bytes())
        self.assertTrue(self.presenter.dispatch("refresh")["ok"])
        self.assertTrue(self.preview_location()["ok"])

    def test_profile_dispatch_matches_canonical_plan_and_preserves_case_constraint(self):
        for profile in ("full_msel", "guided_arrow", "custom"):
            with self.subTest(profile=profile):
                outcome = self.presenter.dispatch("preview_components", profile=profile)
                self.assertTrue(outcome["ok"], outcome)
                self.assertEqual(outcome["result"], self.workspace.preview_components(profile))
        before = self.workspace.station_path.read_bytes()
        outcome = self.presenter.dispatch("preview_components", profile="custom", ptu_model="QPT111")
        self.assertFalse(outcome["ok"])
        self.assertIn("QPT130", outcome["error"]["message"])
        self.assertEqual(before, self.workspace.station_path.read_bytes())

    def test_full_custom_requires_explicit_hardware_intent_without_invented_instances(self):
        before = self.workspace.station_path.read_bytes()
        self.assertTrue(self.presenter.dispatch("preview_components", profile="full_msel")["ok"])
        full = deepcopy(self.presenter.preview["proposed"]["configuration"])
        full_record = self.workspace.root / f"preview-{self.presenter.preview['preview_id']}.json"
        full_record_bytes = full_record.read_bytes()
        custom = {**deepcopy(full), "preset": None, "id": "operator-custom"}
        outcome = self.presenter.dispatch("preview_components", profile="custom", changes=custom)
        self.assertFalse(outcome["ok"])
        self.assertEqual(outcome["error"]["code"], "invalid")
        for component in ("pointing.qpt130", "pointing.dual_gps"):
            self.assertIn(component, outcome["error"]["message"])
        self.assertIn("explicit stable instance identifiers", outcome["error"]["message"])
        self.assertIsNone(self.presenter.preview)
        self.assertEqual(custom["instances"], [])
        self.assertEqual(full["preset"], "full_msel")
        self.assertEqual(full_record.read_bytes(), full_record_bytes)
        for selection in custom["selections"]:
            if selection["component"] in ("pointing.qpt130", "pointing.dual_gps"):
                selection["mode"] = "omit"
        outcome = self.presenter.dispatch("preview_components", profile="custom", changes=custom)
        self.assertTrue(outcome["ok"], outcome)
        self.assertEqual(self.presenter.preview["proposed"]["configuration"], custom)
        self.assertEqual(before, self.workspace.station_path.read_bytes())

    def test_inspection_report_export_and_existing_output_error(self):
        self.workspace.replay("critical")
        self.presenter.dispatch("refresh")
        status = self.presenter.status
        self.assertEqual(status["status"]["transport_check"], "transport_pass")
        self.assertEqual(status["status"]["system_health"], "critical")
        self.assertEqual(status["status"]["heading"], "unqualified")
        self.assertFalse(status["gps_selection"]["enabled"])
        self.assertEqual(len(status["gps_selection"]["unmet_requirements"]), 4)
        output = self.directory / "report.json"
        outcome = self.presenter.dispatch("export_report", output=output)
        self.assertTrue(outcome["ok"], outcome)
        report = json.loads(output.read_bytes())
        self.assertEqual(report, self.workspace.report())
        self.assertFalse(report["live_checks_started"])
        saved = output.read_bytes()
        self.assertFalse(self.presenter.dispatch("export_report", output=output)["ok"])
        self.assertEqual(saved, output.read_bytes())

    def test_workspace_creation_requires_explicit_action(self):
        presenter = OperatorPresenter()
        path = self.directory / "new-practice"
        self.assertFalse(path.exists())
        self.assertFalse(presenter.dispatch("refresh")["ok"])
        self.assertFalse(path.exists())
        self.assertTrue(presenter.dispatch("create_scratch", root=path)["ok"])
        self.assertTrue(path.is_dir())
        self.assertEqual(presenter.status["observations"]["provenance"], "synthetic_replay")
        self.assertFalse(presenter.dispatch("create_scratch", root=path)["ok"])

    def test_failed_open_keeps_previous_workspace_and_status(self):
        revision = self.presenter.revision
        outcome = self.presenter.dispatch("open_workspace", root=self.directory / "missing")
        self.assertFalse(outcome["ok"])
        self.assertEqual(self.presenter.workspace.root, self.workspace.root)
        self.assertEqual(self.presenter.revision, revision)

    def test_actual_activity_lease_rejects_apply_without_changing_admitted_input(self):
        self.assertTrue(self.preview_location()["ok"])
        before = self.workspace.station_path.read_bytes()
        with StationLease(self.workspace.root):
            outcome = self.presenter.dispatch("apply")
            self.assertFalse(outcome["ok"])
            self.assertEqual(before, self.workspace.station_path.read_bytes())
            self.assertIsNotNone(self.presenter.preview)
        self.assertTrue(self.presenter.dispatch("apply")["ok"])

    def test_partial_receipt_failure_is_fail_without_hiding_actual_saved_location(self):
        self.assertTrue(self.preview_location()["ok"])
        preview_id = self.presenter.preview["preview_id"]
        before = self.workspace.station_path.read_bytes()
        write_new = core._write_new

        def fail_receipt(path, payload):
            if Path(path).name.startswith("receipt-"):
                raise core.OperatorError("controlled receipt failure", "io", 4)
            return write_new(path, payload)

        with patch.object(core, "_write_new", side_effect=fail_receipt):
            outcome = self.presenter.dispatch("apply")
        self.assertFalse(outcome["ok"])
        self.assertEqual(outcome["status"], "FAIL")
        self.assertEqual(outcome["error"]["code"], "partial_result")
        self.assertTrue(outcome["result"]["partial"])
        self.assertTrue(outcome["result"]["configuration_saved"])
        self.assertFalse(outcome["result"]["receipt_recorded"])
        self.assertTrue(outcome["result"]["warnings"])
        self.assertNotEqual(before, self.workspace.station_path.read_bytes())
        self.assertEqual(self.workspace.inspect()["manual_location"]["latitude_deg"], 42.3)
        self.assertEqual(self.presenter.revision, self.workspace.inspect()["station_revision"])
        self.assertFalse((self.workspace.root / f"receipt-{preview_id}.json").exists())

    def test_planning_button_adapter_uses_saved_station_and_real_calculation(self):
        self.assertTrue(self.preview_location()["ok"])
        self.assertTrue(self.presenter.dispatch("apply")["ok"])
        outcome = self.presenter.dispatch("plan", start_time="2025-05-16T03:00:00Z", norad_id="25338",
                                          span_days="1", elevation_deg="20")
        self.assertTrue(outcome["ok"], outcome)
        plan = outcome["result"]
        self.assertEqual(plan["station_revision"], self.presenter.revision)
        self.assertEqual(plan["location"]["latitude_deg"], 42.3)
        self.assertEqual(plan["source"], "bundled_historical_replay")
        self.assertFalse(plan["refresh_performed"])
        self.assertFalse(plan["execution_enabled"])
        self.assertTrue((self.workspace.root / f"plan-{plan['plan_id']}.json").is_file())


@unittest.skipUnless(os.environ.get("DISPLAY"),
                     "NOT RUN: native widgets require a reviewed local DISPLAY; headless presenter tests are separate")
class NativeOperatorWidgetTests(OperatorFixture, unittest.TestCase):
    def setUp(self):
        self.make_workspace()
        try:
            import tkinter as tk
            from tkinter import filedialog, ttk
        except ImportError:
            self.skipTest("NOT RUN: reviewed native Tk runtime is unavailable")
        self.tk, self.ttk = tk, ttk
        try:
            self.root = tk.Tk()
        except tk.TclError as error:
            if display_unavailable(error):
                self.skipTest("NOT RUN: reviewed local graphical display could not be opened")
            raise
        self.callback_errors = []
        self.root.report_callback_exception = self._report_callback_exception
        self.addCleanup(self._close_native_root)
        self.before_window_station = self.workspace.station_path.read_bytes()
        self.before_window_files = sorted(item.name for item in self.workspace.root.iterdir())
        self.window = OperatorWindow(self.root, self.presenter, tk=tk, ttk=ttk, filedialog=filedialog)
        self.root.update()
        self._assert_no_callback_errors()

    def _report_callback_exception(self, exception, value, trace):
        self.callback_errors.append("".join(traceback.format_exception(exception, value, trace)))

    def _assert_no_callback_errors(self):
        self.assertEqual(self.callback_errors, [], "Native Tk callback exceptions:\n" + "\n".join(self.callback_errors))

    def _close_native_root(self):
        if getattr(self, "window", None) is not None and self.window._window_closed:
            self._assert_no_callback_errors()
            return
        try:
            self.root.update()
        finally:
            try:
                self.root.destroy()
            finally:
                self._assert_no_callback_errors()

    def enter_location(self, **overrides):
        values = {"latitude_deg": "42.3", "longitude_deg": "-71.1", "altitude_m": "12.5"}
        values.update(overrides)
        self.window.notebook.select(self.window.pages["Location"])
        for key, value in values.items():
            self.window.location_vars[key].set(value)
        self.window.altitude_reference.set("unspecified")
        self.root.update()

    def text(self, name):
        return self.window.widgets[name].get("1.0", "end")

    def wait_task(self):
        deadline = time.monotonic() + 10
        while self.window._task_thread is not None and time.monotonic() < deadline:
            self.root.update()
            self._assert_no_callback_errors()
            time.sleep(.002)
        self.assertIsNone(self.window._task_thread, "Owned foreground task did not finish")
        self.root.update()

    def wait_docs(self):
        deadline = time.monotonic() + 10
        while self.window._docs_thread is not None and time.monotonic() < deadline:
            self.root.update()
            self._assert_no_callback_errors()
            time.sleep(.002)
        self.assertIsNone(self.window._docs_thread, "Owned documentation task did not finish")
        self.root.update()

    def test_help_menu_uses_real_docs_dispatch_and_preserves_drafts_results_and_tab(self):
        from satgs import operator_docs
        from satgs.operator_cli import main

        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        self.enter_location(latitude_deg="41.125", longitude_deg="-72.625", altitude_m="19")
        self.window.profile.set("custom")
        before = (self.window._location_values(), self.window.profile.get(),
                  self.window.notebook.select(), deepcopy(self.presenter.result),
                  deepcopy(self.presenter.preview), self.window.message.get(),
                  self.workspace.station_path.read_bytes())
        self.assertEqual(self.window.menu.entrycget(0, "label"), "Help")
        self.assertEqual(self.window.help_menu.entrycget(0, "label"), "User Guide")
        with patch.object(os, "environ", dict(os.environ, SSH_CONNECTION="", SSH_CLIENT="", SSH_TTY="")), \
                patch.object(operator_docs.subprocess, "run", return_value=SimpleNamespace(returncode=0)) as viewer:
            output = io.StringIO()
            with redirect_stdout(output):
                self.assertEqual(main(["docs"]), 0)
            self.window.help_menu.invoke(0)
            self.wait_docs()
        self.assertEqual(viewer.call_count, 2)
        expected = ["/usr/bin/xdg-open", str(operator_docs._GUIDE_DIRECTORY / "user-guide.html")]
        self.assertEqual(viewer.call_args_list[0].args[0], expected)
        self.assertEqual(viewer.call_args_list[1].args[0], expected)
        self.assertEqual(self.window._docs_result["mode"], "viewer_dispatched")
        self.assertIn("Window visibility is not confirmed", output.getvalue())
        self.assertIsNone(self.window._guide_window)
        self.assertEqual(before, (self.window._location_values(), self.window.profile.get(),
                  self.window.notebook.select(), self.presenter.result, self.presenter.preview,
                  self.window.message.get(), self.workspace.station_path.read_bytes()))

    def test_help_without_workspace_has_nonmodal_read_only_packaged_text_on_viewer_failure(self):
        from satgs import operator_docs

        self.presenter.workspace = None
        before = deepcopy(self.presenter.result)
        station_before = self.workspace.station_path.read_bytes()
        content = (operator_docs._GUIDE_DIRECTORY / "user-guide.txt").read_text(encoding="utf-8")
        with patch.object(os, "environ", dict(os.environ, SSH_CONNECTION="", SSH_CLIENT="", SSH_TTY="")), \
                patch.object(operator_docs.subprocess, "run", side_effect=FileNotFoundError()) as viewer, \
                patch.object(self.tk.Misc, "grab_set", side_effect=AssertionError("Guide must not grab input.")) as grab, \
                patch.object(self.tk.Misc, "grab_set_global", side_effect=AssertionError("Guide must not grab global input.")) as global_grab, \
                patch.object(self.tk.Misc, "wait_window", side_effect=AssertionError("Guide must not block the main window.")) as wait_window:
            self.window.help_menu.invoke(0)
            self.wait_docs()
            self.assertTrue(self.window._guide_window.winfo_ismapped())
            self.window.notebook.select(self.window.pages["Location"])
            entry = self.window.widgets["latitude_deg"]
            self.window.location_vars["latitude_deg"].set("")
            entry.focus_force()
            self.root.update()
            entry.event_generate("<KeyPress-1>")
            entry.event_generate("<KeyRelease-1>")
            repainted = []
            self.root.after(0, lambda: repainted.append(True))
            self.root.update()
            self._assert_no_callback_errors()
            self.assertEqual(self.window.location_vars["latitude_deg"].get(), "1")
            self.assertEqual(self.root.focus_get(), entry)
            self.assertEqual(repainted, [True])
            self.assertTrue(self.window._guide_window.winfo_ismapped())
            grab.assert_not_called()
            global_grab.assert_not_called()
            wait_window.assert_not_called()
        viewer.assert_called_once()
        self.assertEqual(self.window._docs_result["reason"], "viewer_unavailable")
        self.assertEqual(self.window._guide_window.title(), "SATGS User Guide")
        self.assertEqual(self.window._guide_text.get("1.0", "end-1c"), content)
        self.assertEqual(str(self.window._guide_text.cget("state")), "disabled")
        self.assertEqual(self.presenter.result, before)
        self.assertEqual(self.workspace.station_path.read_bytes(), station_before)

    def test_help_worker_is_single_flight_responsive_and_owned_until_close(self):
        from satgs import operator_docs

        entered, release = threading.Event(), threading.Event()
        callers = []

        def delayed():
            callers.append(threading.get_ident())
            entered.set()
            if not release.wait(5):
                raise RuntimeError("fixture barrier expired")
            return {"mode": "viewer_dispatched", "message": "Controlled viewer dispatch.", "text": ""}

        with patch.object(operator_docs, "dispatch_docs", side_effect=delayed):
            try:
                self.window.help_menu.invoke(0)
                self.assertTrue(entered.wait(1))
                worker = self.window._docs_thread
                self.assertEqual(str(self.window.help_menu.entrycget(0, "state")), "disabled")
                self.window.help_menu.invoke(0)
                self.assertEqual(len(callers), 1)
                self.assertNotEqual(callers[0], threading.get_ident())
                repainted = []
                self.root.after(0, lambda: repainted.append(True))
                self.root.update()
                self.assertEqual(repainted, [True])
                self.window._close()
                self.root.update()
                self.assertFalse(self.window._window_closed)
                self.assertTrue(worker.is_alive())
            finally:
                release.set()
                deadline = time.monotonic() + 10
                while not self.window._window_closed and time.monotonic() < deadline:
                    self.root.update()
                    time.sleep(.002)
        self.assertTrue(self.window._window_closed)
        self.assertFalse(worker.is_alive())
        self.assertIsNone(self.window._docs_thread)
        self.assertEqual(self.window._timers, {})

    def test_real_native_startup_only_reads_workspace(self):
        before = self.workspace.station_path.read_bytes()
        files = sorted(item.name for item in self.workspace.root.iterdir())
        self.assertEqual(self.before_window_station, before)
        self.assertEqual(self.before_window_files, files)
        self.window.widgets["refresh"].invoke()
        self.root.update()
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.assertEqual(files, sorted(item.name for item in self.workspace.root.iterdir()))
        self.assertTrue(self.root.winfo_ismapped())
        self.assertEqual(len(self.window.pages), 7)
        self.assertEqual(self.root.title(), "SATGS")
        self.assertEqual(self.window.station.get(), "Station")
        self.assertFalse(hasattr(self.window, "banner"))
        self.assertNotIn("synthetic_replay", self.text("status_detail"))
        self.assertEqual(self.presenter.status["observations"]["provenance"], "synthetic_replay")
        self.assertEqual(self.window.widgets["status_dimensions"].item("system_health", "values")[1], "unknown")
        gps = self.text("gps_detail")
        self.assertNotIn("synthetic_fixture_not_live_clock", gps)
        self.assertNotIn("Time basis:", gps)
        self.assertEqual(self.presenter.status["measured_gps"]["time_basis"], "synthetic_fixture_not_live_clock")
        for actual in ("Available: No", "Live hardware observed: No", "Fix: unknown",
                       "Freshness: unknown", "Valid for station selection: No"):
            self.assertIn(actual, gps)

    def test_existing_default_and_custom_station_names_are_presentation_only(self):
        _, settings = self.workspace.snapshot()
        for name, expected in ((LEGACY_STATION_NAME, "Station"), ("Cole's station", "Cole's station"),
                               (LEGACY_STATION_NAME + " north", LEGACY_STATION_NAME + " north")):
            with self.subTest(name=name):
                settings["ground_station_name"] = name
                self.workspace.station_path.write_text(json.dumps(settings))
                before = self.workspace.station_path.read_bytes()
                status = self.workspace.inspect()
                self.window.widgets["refresh"].invoke()
                self.root.update()
                self.assertEqual(self.window.station.get(), expected)
                self.assertIn(f"Station name: {expected}\n", self.text("status_detail"))
                self.assertEqual(self.presenter.status["station_name"], name)
                self.assertEqual(self.presenter.status["workspace_id"], status["workspace_id"])
                self.assertEqual(self.presenter.revision, status["station_revision"])
                self.assertEqual(before, self.workspace.station_path.read_bytes())

    def test_no_warning_banners_badges_or_replacement_copy(self):
        self.workspace.replay("critical")
        self.window.widgets["refresh"].invoke()
        self.root.update()
        pending = [self.window.shell]
        visible_copy = [self.root.title(), self.window.station.get(), self.window.identity.get(),
                        self.window.message.get()]
        while pending:
            widget = pending.pop()
            pending.extend(widget.winfo_children())
            self.assertNotEqual(widget.winfo_class(), "Toplevel")
            if widget.winfo_class() in ("TLabel", "TLabelframe", "TButton"):
                visible_copy.append(str(widget.cget("text")))
        visible_copy.extend(self.text(name) for name in
                            ("status_detail", "gps_detail", "review_detail", "result_detail"))
        text = "\n".join(visible_copy).casefold()
        for removed in ("synthetic operator practice station", "local configuration only",
                        "evidence is not physical readiness", "no physical readiness claim",
                        "planning only", "sample data", "warning", "caution", "no force override"):
            with self.subTest(removed=removed):
                self.assertNotIn(removed, text)
        self.assertFalse(hasattr(self.window, "banner"))
        self.assertNotIn("synthetic_replay", self.text("status_detail"))
        self.assertEqual(self.presenter.status["observations"]["provenance"], "synthetic_replay")
        self.assertEqual(self.window.widgets["status_dimensions"].item("system_health", "values")[1], "critical")
        self.assertTrue(self.window.widgets["use_gps"].instate(["disabled"]))
        self.assertTrue(self.window.widgets["apply"].instate(["disabled"]))

    def test_resize_handles_default_zero_pixel_and_unit_wraplengths(self):
        parent = self.ttk.Frame(self.window.shell)
        parent.grid(row=5, column=0)
        default = self.ttk.Label(parent, text="Default wrap")
        zero = self.ttk.Label(parent, text="Zero wrap", wraplength=0)
        pixels = self.ttk.Label(parent, text="Pixel wrap", wraplength=100)
        distance = self.ttk.Label(parent, text="Tk distance wrap", wraplength="1i")
        for row, label in enumerate((default, zero, pixels, distance)):
            label.grid(row=row, column=0)
        default_wrap, zero_wrap = default.cget("wraplength"), zero.cget("wraplength")
        self.root.geometry("900x650")
        self.root.event_generate("<Configure>")
        self.root.update()
        self._assert_no_callback_errors()
        self.assertEqual(default.cget("wraplength"), default_wrap)
        self.assertEqual(zero.cget("wraplength"), zero_wrap)
        width = max(280, self.root.winfo_width() - 80)
        for label in (pixels, distance):
            self.assertEqual(label.winfo_pixels(label.cget("wraplength")), width)

    def test_location_widgets_review_confirm_and_reload_actual_workspace(self):
        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        self.assertEqual(self.window.notebook.select(), str(self.window.pages["Review"]))
        review = self.text("review_detail")
        for field in ("Previous", "Proposed", "Affected plans", "Altitude unit"):
            self.assertIn(field, review)
        self.assertNotIn("expected_revision", review)
        self.assertEqual(self.presenter.preview["expected_revision"], self.presenter.revision)
        self.window.widgets["apply"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        self.assertEqual(Workspace(self.workspace.root).inspect()["manual_location"]["latitude_deg"], 42.3)
        self.assertEqual(self.window.location_vars["latitude_deg"].get(), "42.3")
        self.assertIn("saved", self.text("result_detail"))
        self.assertEqual(self.window.message.get(), "Location saved.")
        self.assertIn("Source: manual", self.text("status_detail"))
        self.assertTrue(self.window.widgets["apply"].instate(["disabled"]))

    def test_cancel_button_preserves_station_and_error_is_visible(self):
        before = self.workspace.station_path.read_bytes()
        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        self.window.widgets["cancel"].invoke()
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.assertIn("cancelled", self.text("result_detail"))
        self.enter_location(latitude_deg="nan")
        self.window.widgets["preview_location"].invoke()
        self.root.update()
        self.assertFalse(self.presenter.result["ok"])
        self.assertIn("finite", self.text("result_detail"))
        self.assertIn("failed", self.window.message.get())
        self.assertEqual(before, self.workspace.station_path.read_bytes())

    def test_active_work_error_is_visible_and_confirm_cannot_bypass_lease(self):
        before = self.workspace.station_path.read_bytes()
        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        with StationLease(self.workspace.root):
            self.window.widgets["apply"].invoke()
            self.root.update()
            self.assertFalse(self.presenter.result["ok"])
            self.assertIn("failed", self.window.message.get())
            self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.window.widgets["apply"].invoke()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)

    def test_setup_buttons_use_canonical_choices_and_custom_edit_dispatch(self):
        self.assertIsNone(self.window._component_configuration)
        self.window.profile.set("custom")
        self.window.widgets["preview_components"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        self.assertEqual(self.presenter.preview, self.workspace.preview_components("custom",
                                                                                   expected_revision=self.presenter.revision))
        self.window.profile.set("guided_arrow")
        self.window.widgets["preview_components"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        original = self.presenter.preview["proposed"]["configuration"]
        self.assertEqual(set(self.window.component_controls), {item["component"] for item in original["selections"]})
        self.window.widgets["apply"].invoke()
        self.window.profile.set("custom")
        identity = next(item["component"] for item in original["selections"] if item["provider"] == "repository")
        self.window.component_controls[identity][0].set("reuse")
        self.window.widgets["preview_components"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        proposed = self.presenter.preview["proposed"]["configuration"]
        self.assertIsNone(proposed["preset"])
        self.assertEqual(next(item["mode"] for item in proposed["selections"] if item["component"] == identity), "reuse")

    def test_unsaved_full_msel_preview_is_preserved_when_switching_to_custom(self):
        before = self.workspace.station_path.read_bytes()
        self.window.profile.set("full_msel")
        self.window.widgets["preview_components"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        full_preview = deepcopy(self.presenter.preview["proposed"]["configuration"])
        self.assertEqual(full_preview["preset"], "full_msel")
        self.assertIsNone(self.workspace.inspect()["selection"])

        self.window.profile.set("custom")
        self.window.widgets["preview_components"].invoke()
        self.root.update()
        self.assertFalse(self.presenter.result["ok"], self.presenter.result)
        self.assertIsNone(self.presenter.preview)
        self.assertTrue(self.window.widgets["apply"].instate(["disabled"]))
        review = self.text("review_detail")
        self.assertIn("Status: Not saved", review)
        self.assertIn("Confirmation enabled: No", review)
        self.assertIn("explicit stable instance identifiers", review)
        for component in ("pointing.qpt130", "pointing.dual_gps"):
            self.assertIn(component, review)
        custom_preview = deepcopy(self.window._component_configuration)
        self.assertIsNone(custom_preview["preset"])
        self.assertEqual(custom_preview["id"], "operator-custom")
        expected = {**full_preview, "preset": None, "id": "operator-custom"}
        self.assertEqual(custom_preview, expected)
        self.assertEqual(review.strip(), human_text({"status": "Not saved", "proposed": expected,
                         "error": self.presenter.result["error"], "confirmation_enabled": False}))
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.assertEqual(full_preview["preset"], "full_msel")

        for component in ("pointing.qpt130", "pointing.dual_gps"):
            self.assertEqual(self.window.component_controls[component][0].get(), "install")
            self.window.component_controls[component][0].set("omit")
        self.window.widgets["preview_components"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        custom_preview = deepcopy(self.presenter.preview["proposed"]["configuration"])
        expected = deepcopy(expected)
        for selection in expected["selections"]:
            if selection["component"] in ("pointing.qpt130", "pointing.dual_gps"):
                selection["mode"] = "omit"
        self.assertEqual(custom_preview, expected)
        self.assertEqual(custom_preview["instances"], [])
        self.assertEqual(before, self.workspace.station_path.read_bytes())

        identity = next(item["component"] for item in custom_preview["selections"] if item["provider"] == "repository")
        self.window.component_controls[identity][0].set("reuse")
        self.window.widgets["preview_components"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        edited = self.presenter.preview["proposed"]["configuration"]
        for key in ("instances", "host_roles", "target", "release_id"):
            self.assertEqual(edited[key], full_preview[key])
        expected["selections"] = deepcopy(expected["selections"])
        for selection in expected["selections"]:
            if selection["component"] == identity:
                selection["mode"] = "reuse"
        self.assertEqual(edited, expected)
        self.assertEqual(before, self.workspace.station_path.read_bytes())

    def test_independent_critical_transport_and_unqualified_states_are_rendered(self):
        self.workspace.replay("critical")
        self.window.widgets["refresh"].invoke()
        self.root.update()
        tree = self.window.widgets["status_dimensions"]
        rows = {tree.item(item)["values"][0]: tree.item(item)["values"][1] for item in tree.get_children()}
        self.assertEqual(rows["System health"], "critical")
        self.assertEqual(rows["Transport check"], "transport_pass")
        self.assertEqual(rows["Heading qualification"], "unqualified")
        self.assertEqual(rows["Fix / validity"], "reported_3d")
        self.assertTrue(self.window.widgets["use_gps"].instate(["disabled"]))
        self.assertEqual(self.presenter.status["gps_selection"]["unmet_requirements"], list(core.GPS_REQUIREMENTS))
        self.assertFalse(self.presenter.status["gps_selection"]["enabled"])
        gps = self.text("gps_detail")
        self.assertIn("Selection enabled: No", gps)
        self.assertIn("Source id: synthetic-replay:1/1", gps)
        self.assertIn("Fix: reported_3d", gps)
        self.assertIn("Valid for station selection: No", gps)

    def test_report_export_button_writes_actual_shared_report(self):
        output = self.directory / "widget-report.json"
        self.window.report_output.set(str(output))
        self.window.widgets["export_report"].invoke()
        self.wait_task()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        self.assertEqual(json.loads(output.read_bytes()), self.workspace.report())
        self.window.widgets["export_report"].invoke()
        self.wait_task()
        self.assertFalse(self.presenter.result["ok"])
        self.assertIn("Error:", self.text("result_detail"))

    def test_calculate_button_keeps_real_plan_source_without_warning_copy(self):
        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        self.window.widgets["apply"].invoke()
        self.window.widgets["plan"].invoke()
        self.wait_task()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        plan = self.presenter.result["result"]
        self.assertEqual(plan["source"], "bundled_historical_replay")
        self.assertEqual(plan["station_revision"], self.presenter.revision)
        self.assertEqual(plan["location"]["source"], "manual")
        self.assertEqual(plan["location"]["latitude_deg"], 42.3)
        self.assertFalse(plan["execution_enabled"])
        self.assertFalse(plan["refresh_performed"])
        self.assertTrue(plan["warnings"])
        stored = json.loads((self.workspace.root / f"plan-{plan['plan_id']}.json").read_bytes())
        self.assertEqual(stored, plan)
        visible = self.text("result_detail")
        self.assertIn(f"Source: {plan['source']}", visible)
        for opportunity in plan["opportunities"]:
            self.assertIn(str(opportunity["maximum_elevation_deg"]), visible)
        self.assertIn("Execution enabled: No", visible)
        self.assertNotIn("Warnings:", visible)
        self.assertNotIn("Planning only:", visible)
        self.assertEqual(self.window.message.get(), "Calculation complete.")

    def test_real_keyboard_tab_order_and_escape_cancel(self):
        mnemonics = []
        for tab in self.window.notebook.tabs():
            label = self.window.notebook.tab(tab, "text")
            underline = int(self.window.notebook.tab(tab, "underline"))
            mnemonics.append(label[underline].lower())
        self.assertEqual(len(mnemonics), len(set(mnemonics)))
        self.enter_location()
        latitude = self.window.widgets["latitude_deg"]
        longitude = self.window.widgets["longitude_deg"]
        latitude.focus_force()
        self.root.update()
        latitude.event_generate("<Tab>")
        self.root.update()
        self.assertEqual(self.root.focus_get(), longitude)
        longitude.event_generate("<Shift-Tab>")
        self.root.update()
        self.assertEqual(self.root.focus_get(), latitude)
        before = self.workspace.station_path.read_bytes()
        self.window.widgets["preview_location"].invoke()
        self.root.update()
        self.window.widgets["apply"].event_generate("<Escape>")
        self.root.update()
        self.assertIsNone(self.presenter.preview)
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.assertIn("cancelled", self.text("result_detail"))

    def test_visible_metadata_is_removed_without_rewriting_shared_state(self):
        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        self.window.widgets["apply"].invoke()
        self.window.widgets["plan"].invoke()
        self.wait_task()
        before = self.workspace.station_path.read_bytes()
        plan = deepcopy(self.presenter.result["result"])
        visible = "\n".join(self.text(name) for name in (
            "status_detail", "gps_detail", "review_detail", "result_detail", "run_detail", "bench_detail"))
        for private in (str(self.workspace.root), self.presenter.revision, plan["tle_sha256"],
                        plan["plan_id"], "Workspace:", "checksum", "synthetic_replay"):
            self.assertNotIn(private, visible)
        self.assertEqual(self.window.identity.get(), "")
        self.assertTrue(plan["station_revision"])
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.assertEqual(json.loads((self.workspace.root / f"plan-{plan['plan_id']}.json").read_bytes()), plan)
        choices = self.window.widgets["runtime_plan_id"].cget("values")
        self.assertEqual(len(choices), 1)
        self.assertNotIn(plan["plan_id"], str(choices))
        self.window.plan_choice.set(choices[0])
        self.window._select_plan()
        self.assertEqual(self.window.runtime_vars["plan_id"].get(), plan["plan_id"])

    def test_unchanged_refresh_preserves_text_selection_scroll_tree_and_focus(self):
        self.window.notebook.select(self.window.pages["Home"])
        detail = self.window.widgets["status_detail"]
        self.root.update()
        detail.yview_moveto(.5)
        detail.tag_add("sel", "2.0", "2.6")
        detail.mark_set("insert", "2.3")
        detail.focus_force()
        tree = self.window.widgets["status_dimensions"]
        tree.selection_set("system_health")
        tree.focus("system_health")
        before = (detail.yview(), tuple(map(str, detail.tag_ranges("sel"))), str(detail.index("insert")),
                  tuple(tree.get_children()), tuple(tree.selection()), tree.focus())
        self.window.perform("refresh")
        self.root.update()
        after = (detail.yview(), tuple(map(str, detail.tag_ranges("sel"))), str(detail.index("insert")),
                 tuple(tree.get_children()), tuple(tree.selection()), tree.focus())
        self.assertEqual(before, after)
        self.assertEqual(self.root.focus_get(), detail)
        self.assertEqual(self.window.notebook.select(), str(self.window.pages["Home"]))

    def test_unsaved_location_survives_external_revision_reload(self):
        self.enter_location(latitude_deg="41.125", longitude_deg="-72.625", altitude_m="19")
        focused = self.window.widgets["longitude_deg"]
        focused.focus_force()
        self.root.update()
        draft = self.window._location_values()
        other = Workspace(self.workspace.root)
        pending = other.preview_location(44, -70, 55, "mean_sea_level")
        other.apply(pending["preview_id"])
        saved = self.workspace.station_path.read_bytes()
        self.window.perform("refresh")
        self.root.update()
        self.assertEqual(self.window._location_values(), draft)
        self.assertEqual(self.root.focus_get(), focused)
        self.assertEqual(self.window.notebook.select(), str(self.window.pages["Location"]))
        self.assertEqual(self.presenter.status["effective_location"]["latitude_deg"], 44)
        self.assertEqual(self.workspace.station_path.read_bytes(), saved)
        self.window.widgets["preview_location"].invoke()
        self.assertTrue(self.presenter.result["ok"])
        self.assertEqual(self.presenter.preview["previous"]["latitude_deg"], 44)
        self.assertEqual(self.presenter.preview["proposed"]["latitude_deg"], 41.125)

    def test_saved_profile_and_unsaved_custom_selection_survive_reload(self):
        self.presenter.dispatch("preview_components", profile="full_msel")
        self.presenter.dispatch("apply")
        self.window.perform("refresh")
        self.assertEqual(self.window.profile.get(), "full_msel")
        self.window.profile.set("custom")
        identity = next(iter(self.window.component_controls))
        mode = self.window.component_controls[identity][0]
        mode.set("omit")
        self.window.perform("refresh")
        self.assertEqual(self.window.profile.get(), "custom")
        self.assertIs(self.window.component_controls[identity][0], mode)
        self.assertEqual(mode.get(), "omit")
        self.assertEqual(self.workspace.inspect()["selection"]["preset"], "full_msel")

    def test_planning_is_single_flight_and_keeps_tk_responsive(self):
        from satgs import operator_planning
        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        self.window.widgets["apply"].invoke()
        entered, release = threading.Event(), threading.Event()
        original = operator_planning.plan_workspace
        callers = []
        def delayed(*args, **kwargs):
            callers.append(threading.get_ident())
            entered.set()
            if not release.wait(5):
                raise RuntimeError("fixture barrier expired")
            return original(*args, **kwargs)
        with patch.object(operator_planning, "plan_workspace", side_effect=delayed):
            try:
                self.window.widgets["plan"].invoke()
                self.assertTrue(entered.wait(1))
                self.assertTrue(self.window.widgets["plan"].instate(["disabled"]))
                self.window.widgets["plan"].invoke()
                self.assertFalse(self.window._plan()["ok"])
                repainted = []
                self.root.after(0, lambda: repainted.append(True))
                self.root.update()
                self.assertEqual(repainted, [True])
                self.assertNotEqual(self.window.message.get(), "Calculation complete.")
                self.assertEqual(len(callers), 1)
                self.assertNotEqual(callers[0], threading.get_ident())
            finally:
                release.set()
                self.wait_task()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        plan = self.presenter.result["result"]
        self.assertEqual(json.loads((self.workspace.root / f"plan-{plan['plan_id']}.json").read_bytes()), plan)

    def test_close_waits_for_owned_export_without_abandoning_worker(self):
        entered, release = threading.Event(), threading.Event()
        original = self.workspace.export_report
        output = self.directory / "closing-report.json"
        def delayed(path):
            entered.set()
            if not release.wait(5):
                raise RuntimeError("fixture barrier expired")
            return original(path)
        with patch.object(self.workspace, "export_report", side_effect=delayed):
            try:
                self.window.report_output.set(str(output))
                self.window.widgets["export_report"].invoke()
                self.assertTrue(entered.wait(1))
                worker = self.window._task_thread
                self.window._close()
                self.root.update()
                self.assertFalse(self.window._window_closed)
                self.assertTrue(worker.is_alive())
                repainted = []
                self.root.after(0, lambda: repainted.append(True))
                self.root.update()
                self.assertEqual(repainted, [True])
            finally:
                release.set()
                deadline = time.monotonic() + 10
                while not self.window._window_closed and time.monotonic() < deadline:
                    self.root.update()
                    time.sleep(.002)
        self.assertTrue(self.window._window_closed)
        self.assertFalse(worker.is_alive())
        self.assertIsNone(self.window._task_thread)
        self.assertEqual(self.window._timers, {})
        self.assertEqual(json.loads(output.read_bytes()), self.workspace.report())

    def test_run_cancel_cannot_replace_completed_foreground_plan(self):
        self.enter_location()
        self.window.widgets["preview_location"].invoke()
        self.window.widgets["apply"].invoke()
        entered, release = threading.Event(), threading.Event()
        original = self.presenter._refresh

        def delayed_refresh():
            entered.set()
            if not release.wait(5):
                raise RuntimeError("fixture barrier expired")
            return original()

        with patch.object(self.presenter, "_refresh", side_effect=delayed_refresh):
            try:
                self.window.widgets["plan"].invoke()
                self.assertTrue(entered.wait(10))
                planned = list(self.workspace.root.glob("plan-*.json"))
                self.assertEqual(len(planned), 1)
                canonical = json.loads(planned[0].read_bytes())
                cancellation = self.window.perform("run_cancel", request_id="b" * 64)
                cancellation_before = deepcopy(cancellation)
                self.assertFalse(cancellation["ok"])
                self.assertEqual(cancellation["action"], "run_cancel")
                self.assertIn("Error:", human_text(cancellation))
                self.assertTrue(self.window._task_thread.is_alive())
            finally:
                release.set()
                self.wait_task()
        self.assertEqual(cancellation, cancellation_before)
        self.assertIsNot(self.presenter.result, cancellation)
        self.assertEqual(self.presenter.result["action"], "plan")
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        self.assertEqual(self.presenter.result["result"], canonical)
        self.assertEqual(json.loads(planned[0].read_bytes()), canonical)
        self.assertEqual(self.window.message.get(), "Calculation complete.")
        self.assertNotIn("Error:", self.text("result_detail"))

    def test_owned_operation_failure_is_visible_and_preserves_destination(self):
        output = self.directory / "occupied-report.json"
        output.write_bytes(b"keep-existing")
        self.window.report_output.set(str(output))
        self.window.widgets["export_report"].invoke()
        self.wait_task()
        self.assertFalse(self.presenter.result["ok"])
        self.assertIn("Error:", self.text("result_detail"))
        self.assertEqual(output.read_bytes(), b"keep-existing")
        self.assertTrue(self.window.widgets["export_report"].instate(["!disabled"]))

    def test_native_layout_scaling_and_actual_screenshots(self):
        original_scale = float(self.root.tk.call("tk", "scaling"))
        geometries = ((700, 460), (900, 650), (1040, 800))
        try:
            for scale in (original_scale, original_scale * 1.25):
                self.root.tk.call("tk", "scaling", scale)
                for width, height in geometries:
                    if width > self.root.winfo_screenwidth() or height > self.root.winfo_screenheight():
                        continue
                    self.root.geometry(f"{width}x{height}")
                    for page, names in (("Home", ("open_workspace", "refresh")),
                                        ("Setup", ("preview_components",)),
                                        ("Location", ("latitude_deg", "preview_location")),
                                        ("Results", ("plan", "export_report")),
                                        ("Run", ("run_preview", "run_start", "run_cancel")),
                                        ("PTU", ("bench_connect", "bench_preview", "bench_move", "bench_stop"))):
                        self.window.notebook.select(self.window.pages[page])
                        self.root.update()
                        for name in names:
                            widget = self.window.widgets[name]
                            self.assertTrue(widget.winfo_ismapped(), (scale, width, height, page, name))
                            self.assertGreaterEqual(widget.winfo_rootx(), self.root.winfo_rootx())
                            self.assertGreaterEqual(widget.winfo_rooty(), self.root.winfo_rooty())
                            self.assertLessEqual(widget.winfo_rootx() + widget.winfo_width(),
                                                 self.root.winfo_rootx() + self.root.winfo_width())
                            self.assertLessEqual(widget.winfo_rooty() + widget.winfo_height(),
                                                 self.root.winfo_rooty() + self.root.winfo_height())
            self.root.tk.call("tk", "scaling", original_scale)
            self.root.geometry("1040x800")
            self.enter_location()
            self.window.widgets["preview_location"].invoke()
            self.window.widgets["apply"].invoke()
            self.window.profile.set("guided_arrow")
            self.window.widgets["preview_components"].invoke()
            self.window.widgets["apply"].invoke()
            self.window.widgets["plan"].invoke()
            self.wait_task()
            adapter = sys.modules.get("ui_capture")
            for label, page in (("setup", "Setup"), ("location", "Location"),
                                ("results", "Results"), ("run", "Run")):
                self.window.notebook.select(self.window.pages[page])
                self.root.update()
                self._assert_no_callback_errors()
                if adapter is not None:
                    adapter.capture(self.root, label)
            self.assertTrue(self.window.widgets["bench_move"].instate(["disabled"]))
        finally:
            if not self.window._window_closed:
                self.root.tk.call("tk", "scaling", original_scale)


if __name__ == "__main__":
    unittest.main()
