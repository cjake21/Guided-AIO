"""Hardware-free contracts using the real PTCR20/PTCR96 encoders."""
from dataclasses import FrozenInstanceError
import errno
import threading
import time
import unittest
from unittest.mock import Mock, patch

from serial import SerialException
from serialptu.acquisition import AcquisitionError, SerialDeviceIdentity, SerialSettings, _DeviceSnapshot
from serialptu.errors import CorruptedMessageError
from serialptu.proto_impl import PTCR20, PTCR96
from serialptu.ptu import PTU, PointingError


def acknowledgement(proto, command=0x33, pan=0, tilt=0):
    pack = proto._pack_int_16 if type(proto) is PTCR20 else proto._pack_int_24
    packet = proto._build_message(bytes([command]) + pack(pan) + pack(tilt) + bytes(3))
    return b"\x06" + packet[1:]


class RecordingSerial:
    def __init__(self, proto):
        self.proto = proto
        self.port = None
        self.baudrate = 57600
        self.bytesize = 8
        self.parity = "N"
        self.stopbits = 1
        self.xonxoff = self.rtscts = self.dsrdtr = False
        self.timeout = 0
        self.write_timeout = None
        self.opened = False
        self.opens = self.closes = 0
        self.writes = []
        self.response = bytearray()
        self.result = None
        self.on_write = None
        self.on_open = None
        self.close_failure = False
        self.auto_ack = True

    def isOpen(self):
        return self.opened

    @property
    def in_waiting(self):
        return len(self.response)

    def open(self):
        self.opens += 1
        self.opened = True
        if self.on_open:
            self.on_open()

    def close(self):
        self.closes += 1
        if self.close_failure:
            raise OSError("injected")
        self.opened = False

    def write(self, data):
        self.writes.append(data)
        if self.on_write:
            self.on_write()
        if isinstance(self.result, BaseException):
            raise self.result
        if self.auto_ack:
            command = self.proto._decode_strict_packet(data, 2)[0]
            self.response.extend(acknowledgement(self.proto, command))
        return len(data) if self.result is None else self.result

    def read(self, count):
        result = bytes(self.response[:count])
        del self.response[:count]
        return result


class PreparedPointingTests(unittest.TestCase):
    def make(self, proto=None, opened=True, logger=None):
        proto = PTCR20() if proto is None else proto
        native = RecordingSerial(proto)
        with patch("serialptu.ptu.serial.Serial", return_value=native):
            driver = PTU(proto, "recording-only", pointing=True, logger=logger)
        cancel = threading.Event()
        deadline = time.monotonic() + 2
        handle = driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
        if opened:
            driver.open_bounded(deadline=deadline, cancel=cancel)

        def release():
            native.close_failure = False
            driver.close(deadline=time.monotonic() + 1)
        self.addCleanup(release)
        return driver, native, handle, deadline, cancel

    def prepare(self, driver, handle, deadline, cancel, pan=12.34, tilt=-56.78):
        return driver.prepare_move_to(handle, pan, tilt, deadline=deadline, cancel=cancel)

    def submit(self, driver, handle, prepared, deadline, cancel):
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            return driver.submit_prepared_move(handle, prepared, deadline=deadline, cancel=cancel)

    def test_literal_legacy_encoder_bytes_are_unchanged(self):
        self.assertEqual(PTCR20().move_to(0, 0), bytes.fromhex("02 33 00 00 00 00 00 00 33 03"))
        self.assertEqual(PTCR96().move_to(0, 0),
                         bytes.fromhex("02 00 33 00 00 00 00 00 00 00 00 00 00 33 03"))

    def test_actual_encoder_truncation_and_signed_integer_decode(self):
        for proto, expected in ((PTCR20(), (-700, -567, 10)),
                                (PTCR96(), (-7004, -5678, 100))):
            with self.subTest(protocol=type(proto).__name__):
                driver, native, handle, deadline, cancel = self.make(proto)
                prepared = self.prepare(driver, handle, deadline, cancel, -70.04, -56.78)
                self.assertEqual((prepared.pan_units, prepared.tilt_units,
                                  prepared.units_per_degree), expected)
                self.assertEqual(native.writes, [])

    def test_canonical_escape_roundtrip_and_malformed_packets(self):
        for proto in (PTCR20(), PTCR96()):
            packet = proto.move_to(0.2, 0.3)
            self.assertEqual(proto.decode_move_to_packet(packet),
                             (int(0.2 * proto._degree_factor), int(0.3 * proto._degree_factor),
                              int(proto._degree_factor)))
            malformed = [bytearray(packet), packet[:-1], packet + b"\x00",
                         b"\x02\x33\x1b\x03", b"\x02\x33\x1b\x80\x03",
                         b"\x02\x33\x02\x03", packet[:-2] + b"\xff\x03"]
            for value in malformed:
                with self.assertRaises(CorruptedMessageError):
                    proto.decode_move_to_packet(value)

    def test_packet_decoder_rejects_wrong_kind_address_aux_and_length(self):
        for proto in (PTCR20(), PTCR96()):
            width = proto._coordinate_width
            for data in (b"\x34" + bytes(width * 2 + proto._move_aux_bytes),
                         b"\x33" + bytes(width * 2) + b"\x01" + bytes(proto._move_aux_bytes - 1),
                         b"\x33" + bytes(width * 2 + proto._move_aux_bytes + 1)):
                with self.assertRaises(CorruptedMessageError):
                    proto.decode_move_to_packet(proto._build_message(data))
        proto = PTCR96()
        packet = proto.move_to(0, 0)
        with self.assertRaises(CorruptedMessageError):
            proto.decode_move_to_packet(packet[:1] + b"\x01" + packet[2:-2] + b"\x32\x03")

    def test_strict_constructor_is_inert_and_legacy_constructor_default_is_unchanged(self):
        for strict, expected in ((True, 0), (False, 1)):
            native = RecordingSerial(PTCR20())
            logger = Mock()
            with patch("serialptu.ptu.serial.Serial", return_value=native):
                driver = PTU(native.proto, "recording-only", pointing=strict, logger=logger)
            self.assertEqual(native.opens, expected)
            self.assertIsNone(driver._keepalive)
            if strict:
                logger.assert_not_called()
                self.assertEqual(logger.method_calls, [])
                with self.assertRaises(PointingError):
                    driver.open_bounded(deadline=time.monotonic() + 1, cancel=threading.Event())
                self.assertEqual(native.opens, 0)
                driver.close(deadline=time.monotonic() + 1)
            else:
                driver.close()

    def test_bind_then_open_starts_no_keepalive_and_does_not_claim_position(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        self.assertEqual(native.opens, 0)
        driver.open_bounded(deadline=deadline, cancel=cancel)
        self.assertEqual(native.opens, 1)
        self.assertIsNone(driver._keepalive)
        self.assertEqual(native.writes, [])
        self.assertEqual(handle.binding, bytes(32))
        with self.assertRaises(PointingError):
            PTU.KeepAlive(driver)

    def test_failed_or_late_open_invalidates_but_retains_passive_cleanup(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        native.on_open = cancel.set
        with self.assertRaises(PointingError):
            driver.open_bounded(deadline=deadline, cancel=cancel)
        self.assertTrue(native.opened)
        cancel.clear()
        with self.assertRaises(PointingError):
            self.prepare(driver, handle, deadline, cancel)
        driver.close(deadline=deadline)
        self.assertFalse(native.opened)

    def test_prepared_record_and_handle_are_immutable(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        for record, field in ((handle, "binding"), (prepared, "packet"),
                              (prepared, "pan_units"), (prepared, "generation")):
            with self.assertRaises(AttributeError):
                setattr(record, field, None)
            with self.assertRaises(AttributeError):
                delattr(record, field)
        self.assertIs(type(prepared.packet), bytes)

    def test_prepared_submission_encodes_once_and_writes_exact_same_bytes_once(self):
        for proto in (PTCR20(), PTCR96()):
            driver, native, handle, deadline, cancel = self.make(proto)
            proto.move_to = Mock(wraps=proto.move_to)
            prepared = self.prepare(driver, handle, deadline, cancel)
            result = self.submit(driver, handle, prepared, deadline, cancel)
            proto.move_to.assert_called_once_with(12.34, -56.78)
            self.assertEqual(native.writes, [prepared.packet])
            self.assertIs(native.writes[0], prepared.packet)
            self.assertTrue(result[0])
            self.assertEqual(result[1]["message_type"], "move_response")
            self.assertGreater(native.write_timeout, 0)
            self.assertLessEqual(native.write_timeout, 2)

    def test_submit_requires_guard_and_exact_original_controls(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        with self.assertRaises(PointingError):
            driver.submit_prepared_move(handle, prepared, deadline=deadline, cancel=cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            for other_deadline, other_cancel in ((deadline + 1, cancel), (deadline, threading.Event())):
                with self.assertRaises(PointingError):
                    driver.submit_prepared_move(handle, prepared,
                                                deadline=other_deadline, cancel=other_cancel)
        self.assertEqual(native.writes, [])

    def test_foreign_handle_and_prepared_record_are_rejected(self):
        driver, native, handle, deadline, cancel = self.make()
        other, other_native, other_handle, other_deadline, other_cancel = self.make()
        prepared = self.prepare(other, other_handle, other_deadline, other_cancel)
        with self.assertRaises(PointingError):
            self.prepare(driver, other_handle, deadline, cancel)
        with self.assertRaises(PointingError):
            self.submit(driver, handle, prepared, deadline, cancel)
        self.assertEqual(native.writes, [])
        self.assertEqual(other_native.writes, [])

    def test_explicit_invalidation_rejects_existing_and_future_preparations(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
        with self.assertRaises(PointingError):
            self.submit(driver, handle, prepared, deadline, cancel)
        with self.assertRaises(PointingError):
            self.prepare(driver, handle, deadline, cancel)
        with self.assertRaises(PointingError):
            driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
        self.assertEqual(native.writes, [])

    def test_context_changes_invalidate_pending_preparations(self):
        for change in ("protocol", "baudrate", "timeout", "jog", "scale"):
            driver, native, handle, deadline, cancel = self.make()
            prepared = self.prepare(driver, handle, deadline, cancel)
            if change == "protocol":
                driver._protocol = PTCR20()
            elif change == "jog":
                driver.protocol._last_jog_pan = 0.5
            elif change == "scale":
                driver.protocol._degree_factor = 100
            else:
                setattr(native, change, 1)
            with self.assertRaises(PointingError):
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertTrue(driver._pointing_blocked)
            self.assertEqual(native.writes, [])

    def test_all_legacy_routes_deny_before_stateful_encoders(self):
        driver, native, handle, deadline, cancel = self.make()
        driver.protocol.jog = Mock(side_effect=AssertionError("encoder must not run"))
        driver.protocol.reset = Mock(side_effect=AssertionError("reset must not run"))
        calls = [(driver.get_status, ()), (driver.jog, (1, 1)), (driver.move_to_zero, ()),
                 (driver.move_to, (1, 1)), (driver.move_delta, (1, 1)), (driver.move_home, ()),
                 (driver.get_soft_limit, ("CW",)), (driver.set_soft_limit, ("CW",)),
                 (driver.get_max_speed, ()), (driver.get_min_speed, ()),
                 (driver.set_max_speed, (1, 1)), (driver.set_min_speed, (1, 1)),
                 (driver.reset_motor_timeout, ()), (driver.open, ()),
                 (driver._send_message, (b"unvalidated",)), (driver._receive_message, ()),
                 (driver.set_status_rate, (1,)), (driver.connect_status_listener, (lambda: None,)),
                 (driver.disconnect_status_listener, (lambda: None,))]
        for function, args in calls:
            with self.assertRaises(PointingError) as failure:
                function(*args)
            self.assertEqual(failure.exception.primary, "legacy-disabled")
        driver.protocol.jog.assert_not_called()
        driver.protocol.reset.assert_not_called()
        self.assertEqual(native.writes, [])

    def test_only_validated_zero_jog_status_is_submitted(self):
        for proto in (PTCR20(), PTCR96()):
            driver, native, handle, deadline, cancel = self.make(proto)
            result = driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
            self.assertEqual(result[1]["message_type"], "status_response")
            self.assertEqual(len(native.writes), 1)
            proto.validate_nonmoving_status_packet(native.writes[0])
            proto._last_jog_tilt = 1
            with self.assertRaises(PointingError):
                driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
            self.assertEqual(len(native.writes), 1)

    def test_control_admission_and_coordinate_domain_have_no_effect(self):
        driver, native, handle, deadline, cancel = self.make()

        class HostileEvent(threading.Event):
            def is_set(self):
                raise AssertionError("must not dispatch")

        for invalid_deadline, invalid_cancel in ((True, cancel), (float("nan"), cancel),
                                                (float("inf"), cancel), (10 ** 1000, cancel),
                                                (deadline, HostileEvent()), (deadline, object())):
            with self.assertRaises(PointingError):
                self.prepare(driver, handle, invalid_deadline, invalid_cancel)
        for pan, tilt in ((True, 0), (float("nan"), 0), (0, float("inf")),
                          (999.99, 0), (361, 0), (0, 181), (10 ** 1000, 0)):
            with self.assertRaises(PointingError):
                self.prepare(driver, handle, deadline, cancel, pan, tilt)
        self.assertEqual(native.writes, [])

    def test_cancel_and_deadline_at_guard_recheck_prevent_write(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            cancel.set()
            with self.assertRaises(PointingError) as failure:
                driver.submit_prepared_move(handle, prepared, deadline=deadline, cancel=cancel)
            self.assertEqual(failure.exception.primary, "cancelled")
        cancel.clear()
        with patch("serialptu.ptu.time.monotonic", return_value=deadline):
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertEqual(failure.exception.primary, "deadline")
        self.assertEqual(native.writes, [])

    def test_lock_wait_uses_original_deadline_and_cancellation(self):
        driver, native, handle, deadline, cancel = self.make()
        entered = threading.Event()
        release = threading.Event()

        def holder():
            with driver._lock:
                entered.set()
                release.wait(1)

        thread = threading.Thread(target=holder)
        thread.start()
        try:
            self.assertTrue(entered.wait(0.5))
            with self.assertRaises(PointingError) as failure:
                self.prepare(driver, handle, time.monotonic() + 0.02, cancel)
            self.assertEqual(failure.exception.primary, "deadline")
            cancel.set()
            with self.assertRaises(PointingError) as failure:
                self.prepare(driver, handle, deadline, cancel)
            self.assertEqual(failure.exception.primary, "cancelled")
        finally:
            release.set()
            thread.join(0.5)
            self.assertFalse(thread.is_alive())
        self.assertEqual(native.writes, [])

    def test_short_unknown_and_failed_writes_are_not_retried(self):
        for count, disposition in ((0, "none"), (1, "partial"), (True, "unknown"),
                                   (-1, "unknown"), (OSError("injected"), "unknown")):
            driver, native, handle, deadline, cancel = self.make()
            prepared = self.prepare(driver, handle, deadline, cancel)
            native.result = count
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertEqual(failure.exception.submission, disposition)
            self.assertEqual(len(native.writes), 1)
            with self.assertRaises(PointingError):
                self.submit(driver, handle, prepared, deadline, cancel)
            self.assertEqual(len(native.writes), 1)

    def test_cancel_after_full_native_write_is_complete_submission_not_success(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        native.on_write = cancel.set
        with self.assertRaises(PointingError) as failure:
            self.submit(driver, handle, prepared, deadline, cancel)
        self.assertEqual(failure.exception.primary, "cancelled")
        self.assertEqual(failure.exception.submission, "complete")
        self.assertEqual(failure.exception.written, len(prepared.packet))
        self.assertEqual(len(native.writes), 1)

    def test_deadline_after_full_native_write_is_not_success(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        clock = [deadline - 1]
        native.on_write = lambda: clock.__setitem__(0, deadline)
        with patch("serialptu.ptu.time.monotonic", side_effect=lambda: clock[0]):
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, deadline, cancel)
        self.assertEqual(failure.exception.primary, "deadline")
        self.assertEqual(failure.exception.submission, "complete")
        self.assertTrue(driver._pointing_blocked)

    def test_missing_or_wrong_response_never_resends(self):
        for response in (b"", acknowledgement(PTCR20(), 0x31), b"\x06\x33\x03"):
            driver, native, handle, deadline, cancel = self.make()
            prepared = self.prepare(driver, handle, deadline, cancel)
            native.auto_ack = False
            native.response.extend(response)
            with self.assertRaises(PointingError) as failure:
                self.submit(driver, handle, prepared, time.monotonic() + 0.03, cancel)
            self.assertEqual(failure.exception.submission, "complete")
            self.assertEqual(len(native.writes), 1)

    def test_expired_close_releases_passively_but_does_not_claim_timely_success(self):
        driver, native, handle, deadline, cancel = self.make()
        driver.protocol.reset = Mock(side_effect=AssertionError("no compensating motion"))
        with self.assertRaises(PointingError) as failure:
            driver.close(deadline=time.monotonic() - 1)
        self.assertEqual(failure.exception.primary, "close-deadline")
        self.assertFalse(native.opened)
        self.assertTrue(driver._pointing_closed)
        driver.close(deadline=deadline)
        self.assertEqual(native.closes, 1)
        self.assertEqual(native.writes, [])
        driver.protocol.reset.assert_not_called()

    def test_close_failure_retains_release_debt_and_blocks_commands(self):
        driver, native, handle, deadline, cancel = self.make()
        native.close_failure = True
        with self.assertRaises(PointingError) as failure:
            driver.close(deadline=deadline)
        self.assertEqual(failure.exception.primary, "close-io")
        self.assertTrue(native.opened)
        self.assertFalse(driver._pointing_closed)
        self.assertTrue(driver._pointing_blocked)
        native.close_failure = False
        driver.close(deadline=deadline)
        self.assertFalse(native.opened)


    def test_public_context_is_read_only_and_checks_the_seal(self):
        for proto, expected in ((PTCR20(), ("PTCR20", 10, None)),
                                (PTCR96(), ("PTCR96", 100, 0))):
            native = RecordingSerial(proto)
            with patch("serialptu.ptu.serial.Serial", return_value=native):
                driver = PTU(proto, "recording-only", pointing=True)
            self.assertEqual(driver.pointing_context, expected)
            with self.assertRaises(AttributeError):
                driver.pointing_context = expected
            deadline = time.monotonic() + 1
            driver.bind_pointing(bytes(32), deadline=deadline, cancel=threading.Event())
            self.assertEqual(driver.pointing_context, expected)
            native.baudrate += 1
            with self.assertRaises(PointingError):
                _ = driver.pointing_context
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
            self.assertEqual(native.opens, 0)
            driver.close(deadline=deadline)

    def test_close_lock_timeout_retains_release_debt_and_blocks_future_writes(self):
        driver, native, handle, deadline, cancel = self.make()
        entered = threading.Event()
        release = threading.Event()

        def holder():
            with driver._lock:
                entered.set()
                release.wait(1)

        thread = threading.Thread(target=holder)
        thread.start()
        try:
            self.assertTrue(entered.wait(0.5))
            with self.assertRaises(PointingError) as failure:
                driver.close(deadline=time.monotonic() - 1)
            self.assertEqual(failure.exception.primary, "close-deadline")
            self.assertTrue(native.opened)
            self.assertFalse(driver._pointing_closed)
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
        finally:
            release.set()
            thread.join(0.5)
            self.assertFalse(thread.is_alive())
        driver.close(deadline=deadline)
        self.assertFalse(native.opened)


    def test_invalidation_completion_shares_the_prewrite_lock_and_survives_restore(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        before_write = threading.Event()
        permit_write = threading.Event()
        invalidation_waiting = threading.Event()
        invalidation_completed = threading.Event()
        failures = []
        order = []
        original_lock = driver._lock
        original_write = native.write
        invalidator_identity = []

        class ObservedLock:
            def acquire(self, *args, **kwargs):
                if invalidator_identity and threading.get_ident() == invalidator_identity[0]:
                    invalidation_waiting.set()
                return original_lock.acquire(*args, **kwargs)

            def release(self):
                return original_lock.release()

        def paused_write(packet):
            before_write.set()
            if not permit_write.wait(1):
                raise AssertionError('prewrite barrier was not released')
            order.append('write')
            return original_write(packet)

        def sender():
            try:
                self.submit(driver, handle, prepared, deadline, cancel)
            except BaseException as error:
                failures.append(('sender', error))

        def invalidator():
            invalidator_identity.append(threading.get_ident())
            try:
                driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
                order.append('invalidation')
                invalidation_completed.set()
                native.baudrate += 1
                native.baudrate -= 1
            except BaseException as error:
                failures.append(('invalidator', error))

        driver._lock = ObservedLock()
        native.write = paused_write
        send_thread = threading.Thread(target=sender)
        invalidate_thread = threading.Thread(target=invalidator)
        send_thread.start()
        try:
            self.assertTrue(before_write.wait(0.5))
            invalidate_thread.start()
            self.assertTrue(invalidation_waiting.wait(0.5))
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
            self.assertFalse(invalidation_completed.is_set())
            self.assertEqual(driver._pointing_generation, prepared.generation)
            self.assertEqual(native.writes, [])
        finally:
            permit_write.set()
            send_thread.join(0.5)
            if invalidate_thread.ident is not None:
                invalidate_thread.join(0.5)
            self.assertFalse(send_thread.is_alive())
            self.assertFalse(invalidate_thread.is_alive())
        self.assertEqual(order, ['write', 'invalidation'])
        self.assertTrue(invalidation_completed.is_set())
        self.assertEqual(len(failures), 1)
        self.assertEqual(failures[0][0], 'sender')
        self.assertIs(type(failures[0][1]), PointingError)
        self.assertEqual(failures[0][1].submission, 'complete')
        self.assertNotEqual(driver._pointing_generation, prepared.generation)
        self.assertEqual(native.writes, [prepared.packet])
        with self.assertRaises(PointingError):
            self.submit(driver, handle, prepared, deadline, cancel)
        with self.assertRaises(PointingError):
            self.prepare(driver, handle, deadline, cancel)
        self.assertEqual(native.writes, [prepared.packet])

    def test_timed_out_invalidation_requests_stop_without_claiming_completion(self):
        driver, native, handle, deadline, cancel = self.make()
        prepared = self.prepare(driver, handle, deadline, cancel)
        entered = threading.Event()
        release = threading.Event()

        def holder():
            with driver._lock:
                entered.set()
                release.wait(1)

        thread = threading.Thread(target=holder)
        thread.start()
        try:
            self.assertTrue(entered.wait(0.5))
            with self.assertRaises(PointingError) as failure:
                driver.invalidate_pointing(handle, deadline=time.monotonic() + 0.02, cancel=cancel)
            self.assertEqual(failure.exception.primary, 'deadline')
            self.assertTrue(driver._pointing_stop_requested)
            self.assertFalse(driver._pointing_blocked)
            self.assertEqual(driver._pointing_generation, prepared.generation)
        finally:
            release.set()
            thread.join(0.5)
            self.assertFalse(thread.is_alive())
        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
        self.assertTrue(driver._pointing_blocked)
        self.assertNotEqual(driver._pointing_generation, prepared.generation)
        self.assertEqual(native.writes, [])


    def test_public_availability_is_nonreserving_and_false_for_every_nonfresh_state(self):
        for state in ('fresh', 'bound', 'requested', 'invalidated', 'closed', 'invalid-profile', 'legacy'):
            with self.subTest(state=state):
                proto = PTCR20()
                native = RecordingSerial(proto)
                strict = state != 'legacy'
                with patch('serialptu.ptu.serial.Serial', return_value=native):
                    driver = PTU(proto, 'recording-only', pointing=strict, logger=Mock())
                deadline = time.monotonic() + 1
                cancel = threading.Event()
                if state in ('bound', 'invalidated'):
                    handle = driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
                    if state == 'invalidated':
                        driver.invalidate_pointing(handle, deadline=deadline, cancel=cancel)
                elif state == 'requested':
                    driver._pointing_stop_requested = True
                elif state == 'closed':
                    driver.close(deadline=deadline)
                elif state == 'invalid-profile':
                    proto._degree_factor = 999
                before = (native.opens, native.closes, driver._pointing_handle,
                          driver._pointing_stop_requested, driver._pointing_generation)
                self.assertIs(driver.pointing_available, state == 'fresh')
                self.assertIs(driver.pointing_available, state == 'fresh')
                with self.assertRaises(AttributeError):
                    driver.pointing_available = True
                self.assertEqual(before, (native.opens, native.closes, driver._pointing_handle,
                                          driver._pointing_stop_requested, driver._pointing_generation))
                self.assertEqual(native.writes, [])
                if strict:
                    driver.close(deadline=deadline)
                else:
                    driver.close()


class SelectedBenchDriverTests(unittest.TestCase):
    def make(self, capability='readback', opened=True, bound=True):
        proto = PTCR20()
        native = RecordingSerial(proto)
        settings = SerialSettings('/dev/serial/by-id/usb-recording-only', 9600, 8, 'N', 1,
                                  False, False, False, True, True)
        identity = SerialDeviceIdentity('067b', '23a3', 'recording-only', '00', 'pl2303')
        with patch('serialptu.ptu.serial.Serial', return_value=native) as factory:
            driver = PTU(proto, settings.port, baud=9600, pointing=True, serial_settings=settings,
                         device_identity=identity, serial_capability=capability)
        factory.assert_called_once_with(baudrate=9600, timeout=0, exclusive=True)
        self.assertEqual((native.opens, native.writes), (0, []))
        deadline, cancel = time.monotonic() + 2, threading.Event()
        handle = None
        if bound:
            bind = driver.bind_readback if capability == 'readback' else driver.bind_manual
            handle = bind(bytes(32), deadline=deadline, cancel=cancel)
        if opened:
            self.open(driver, deadline, cancel)

        def release():
            native.close_failure = False
            driver.close(deadline=time.monotonic() + 1)

        self.addCleanup(release)
        return driver, native, handle, deadline, cancel

    def open(self, driver, deadline, cancel):
        snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
        with patch('serialptu.ptu.verify_selected_device', return_value=snapshot) as verify, \
                patch('serialptu.ptu.claim_selected_device') as claim:
            driver.open_bounded(deadline=deadline, cancel=cancel)
        verify.assert_called_once_with(driver.readback_context.serial_settings,
                                       driver.readback_context.device_identity)
        claim.assert_called_once()

    def test_explicit_lines_and_context_are_staged_before_open_without_commands(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        context = driver.readback_context
        self.assertEqual((context.protocol, context.units_per_degree, context.protocol_address),
                         ('PTCR20', 10, None))
        self.assertEqual((native.baudrate, native.bytesize, native.parity, native.stopbits), (9600, 8, 'N', 1))
        self.assertEqual((native.xonxoff, native.rtscts, native.dsrdtr), (False, False, False))
        self.assertEqual((native.rts, native.dtr, native.exclusive), (True, True, True))
        self.assertIsNone(driver.last_exchange)
        self.open(driver, deadline, cancel)
        self.assertEqual(native.port, '/dev/ttyUSB0')
        self.assertEqual(driver.readback_context, context)
        self.assertEqual(native.writes, [])
        self.assertIsNone(driver._keepalive)
        with self.assertRaises(FrozenInstanceError):
            context.protocol = 'PTCR96'
        with self.assertRaises(AttributeError):
            driver.serial_capability = 'manual'

    def test_both_bench_capabilities_reject_tracking_bind_before_open(self):
        for capability in ('readback', 'manual'):
            driver, native, handle, deadline, cancel = self.make(capability, opened=False, bound=False)
            with self.subTest(capability=capability), self.assertRaisesRegex(PointingError, '^readback-only$'):
                driver.bind_pointing(bytes(32), deadline=deadline, cancel=cancel)
            self.assertEqual((native.opens, native.writes, driver._pointing_handle), (0, [], None))

    def test_readback_and_manual_binding_cannot_upgrade_each_other(self):
        for capability in ('readback', 'manual'):
            driver, native, handle, deadline, cancel = self.make(capability, opened=False, bound=False)
            wrong = driver.bind_manual if capability == 'readback' else driver.bind_readback
            with self.subTest(capability=capability), self.assertRaises(PointingError):
                wrong(bytes(32), deadline=deadline, cancel=cancel)
            self.assertEqual((native.opens, native.writes, driver._pointing_handle), (0, [], None))

    def test_readback_rejects_preparation_submission_stop_and_legacy_before_encoder_mutation(self):
        driver, native, handle, deadline, cancel = self.make()
        with patch.object(driver.protocol, 'move_to') as move, \
                patch.object(driver.protocol, 'stop_packet') as stop, \
                patch.object(driver.protocol, 'jog') as jog:
            attempts = (lambda: driver.prepare_move_to(handle, 1, -1, deadline=deadline, cancel=cancel),
                        lambda: driver.submit_prepared_move(handle, None, deadline=deadline, cancel=cancel),
                        lambda: driver.stop_bounded(handle, deadline=deadline, cancel=cancel),
                        lambda: driver.move_to(1, -1), lambda: driver.jog(1, 0),
                        driver.reset_motor_timeout, driver.move_to_zero, driver.open)
            for attempt in attempts:
                with self.assertRaises(PointingError):
                    attempt()
            move.assert_not_called()
            stop.assert_not_called()
            jog.assert_not_called()
        self.assertEqual(native.writes, [])

    def test_manual_reuses_prepared_encoder_guard_and_zero_jog_stop(self):
        driver, native, handle, deadline, cancel = self.make('manual')
        packet = driver.prepare_move_to(handle, 12.34, -56.78, deadline=deadline, cancel=cancel)
        self.assertEqual((packet.pan_units, packet.tilt_units), (123, -567))
        with self.assertRaisesRegex(PointingError, '^guard-required$'):
            driver.submit_prepared_move(handle, packet, deadline=deadline, cancel=cancel)
        with driver.pointing_guard(handle, deadline=deadline, cancel=cancel):
            driver.submit_prepared_move(handle, packet, deadline=deadline, cancel=cancel)
        self.assertEqual(native.writes, [packet.packet])
        self.assertEqual(driver.last_exchange.operation, 'move')
        driver.stop_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(native.writes[1], bytes.fromhex('02 31 1b 82 00 00 00 00 33 03'))
        self.assertEqual(driver.last_exchange.operation, 'stop')
        driver.close(deadline=deadline)
        self.assertEqual(len(native.writes), 2)

    def test_identity_mismatch_refuses_open_and_preserves_passive_cleanup(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        with patch('serialptu.ptu.verify_selected_device', side_effect=AcquisitionError('device-identity')):
            with self.assertRaisesRegex(PointingError, '^device-identity$'):
                driver.open_bounded(deadline=deadline, cancel=cancel)
        self.assertEqual((native.opens, native.writes), (0, []))
        driver.close(deadline=deadline)

    def test_busy_native_owner_is_reported_without_retry_or_write(self):
        driver, native, handle, deadline, cancel = self.make(opened=False)
        snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
        with patch('serialptu.ptu.verify_selected_device', return_value=snapshot), \
                patch.object(native, 'open', side_effect=SerialException(errno.EAGAIN, 'fixture')) as opening:
            with self.assertRaisesRegex(PointingError, '^device-busy$'):
                driver.open_bounded(deadline=deadline, cancel=cancel)
        opening.assert_called_once_with()
        self.assertEqual(native.writes, [])

    def test_legacy_constructor_requests_same_cooperating_exclusion_and_releases_passively(self):
        native = RecordingSerial(PTCR20())
        with patch('serialptu.ptu.serial.Serial', return_value=native) as factory:
            driver = PTU(native.proto, 'recording-only', baud=9600, logger=Mock())
        factory.assert_called_once_with(baudrate=9600, timeout=0, exclusive=True)
        self.assertEqual(native.opens, 1)
        self.assertEqual(native.writes, [])
        driver.close()
        self.assertEqual(native.closes, 1)
        self.assertEqual(native.writes, [])

    def test_failed_post_open_identity_retains_owned_release_without_query(self):
        for capability in ('readback', 'manual'):
            for failure in ('device-identity', 'device-ownership'):
                driver, native, handle, deadline, cancel = self.make(capability, opened=False)
                snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
                with patch('serialptu.ptu.verify_selected_device', return_value=snapshot), \
                        patch('serialptu.ptu.claim_selected_device', side_effect=AcquisitionError(failure)):
                    with self.assertRaises(PointingError):
                        driver.open_bounded(deadline=deadline, cancel=cancel)
                self.assertTrue(native.opened)
                attempts = (lambda: driver.get_status_bounded(handle, deadline=deadline, cancel=cancel),
                            lambda: driver.observe_bounded(handle, deadline=deadline, cancel=cancel),
                            lambda: driver.stop_bounded(handle, deadline=deadline, cancel=cancel),
                            lambda: driver.prepare_move_to(handle, 1, -1, deadline=deadline, cancel=cancel),
                            lambda: driver.submit_prepared_move(handle, None, deadline=deadline, cancel=cancel))
                for attempt in attempts:
                    with self.subTest(capability=capability, failure=failure), self.assertRaises(PointingError):
                        attempt()
                self.assertEqual(native.writes, [])
                driver.close(deadline=deadline)
                self.assertFalse(native.opened)

    def test_control_line_and_native_mode_drift_reject_before_query(self):
        for name, value in (('rts', False), ('dtr', False), ('exclusive', False),
                            ('inter_byte_timeout', .1), ('rs485_mode', object()), ('rtscts', True)):
            driver, native, handle, deadline, cancel = self.make()
            setattr(native, name, value)
            with self.subTest(name=name), self.assertRaises(PointingError):
                driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
            self.assertEqual(native.writes, [])

    def test_status_receipt_retains_exact_bytes_and_monotonic_receipt_not_arrival(self):
        driver, native, handle, deadline, cancel = self.make()
        result = driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
        receipt = driver.last_exchange
        self.assertEqual(native.writes, [bytes.fromhex('02 31 00 00 00 00 00 31 03')])
        self.assertEqual(receipt.request, native.writes[0])
        self.assertEqual(receipt.response, acknowledgement(driver.protocol, 0x31))
        self.assertEqual((receipt.sequence, receipt.operation, receipt.category, receipt.submission),
                         (1, 'status', 'ok', 'complete'))
        self.assertEqual(receipt.written, len(receipt.request))
        self.assertLessEqual(receipt.started_monotonic, receipt.finished_monotonic)
        self.assertFalse(receipt.response_truncated)
        self.assertEqual(result[1]['message_type'], 'status_response')
        with self.assertRaises(FrozenInstanceError):
            receipt.category = 'changed'
        driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(driver.last_exchange.sequence, 2)
        self.assertEqual(receipt.sequence, 1)

    def test_stale_feedback_refusal_has_a_new_receipt_without_write_or_consumption(self):
        driver, native, handle, deadline, cancel = self.make()
        stale = acknowledgement(driver.protocol, 0x31, 123, 456)
        native.response.extend(stale)
        with self.assertRaisesRegex(PointingError, '^stale-response$'):
            driver.get_status_bounded(handle, deadline=deadline, cancel=cancel)
        receipt = driver.last_exchange
        self.assertEqual((receipt.category, receipt.submission, receipt.response), ('stale-response', 'none', b''))
        self.assertEqual(bytes(native.response), stale)
        self.assertEqual(native.writes, [])

    def test_partial_write_and_bad_protocol_responses_keep_failure_evidence(self):
        for mode in ('short', 'checksum', 'nak', 'oversize'):
            driver, native, handle, deadline, cancel = self.make()
            native.auto_ack = False
            response = b''
            if mode == 'short':
                native.result = 2
            else:
                response = (b'\x06\x31\x00\x03' if mode == 'checksum' else
                            b'\x15' + acknowledgement(driver.protocol, 0x31)[1:] if mode == 'nak' else b'\x00' * 65)
                native.on_write = lambda response=response: native.response.extend(response)
            with self.subTest(mode=mode), self.assertRaises(PointingError):
                driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
            receipt = driver.last_exchange
            self.assertEqual(len(native.writes), 1)
            self.assertEqual(receipt.category, {'short': 'short-write', 'checksum': 'strict-checksum',
                                               'nak': 'strict-nak', 'oversize': 'response'}[mode])
            self.assertEqual(receipt.response, response[:64])
            self.assertEqual(receipt.response_truncated, mode == 'oversize')
            self.assertEqual(receipt.submission, 'partial' if mode == 'short' else 'complete')

    def test_partial_or_missing_response_timeout_keeps_received_bytes_without_retry(self):
        for response in (b'', b'\x06\x31'):
            driver, native, handle, deadline, cancel = self.make()
            native.auto_ack = False
            native.on_write = lambda response=response: native.response.extend(response)
            original_read = native.read
            now = [time.monotonic()]

            def read(count):
                result = original_read(count)
                if not result:
                    now[0] += 2
                return result

            native.read = read
            with patch('serialptu.ptu.time.monotonic', side_effect=lambda: now[0]):
                with self.assertRaisesRegex(PointingError, '^deadline$'):
                    driver.observe_bounded(handle, deadline=now[0] + 1, cancel=cancel)
            self.assertEqual(driver.last_exchange.response, response)
            self.assertEqual(driver.last_exchange.category, 'deadline')
            self.assertEqual(driver.last_exchange.submission, 'complete')
            self.assertEqual(len(native.writes), 1)

    def test_delayed_partial_response_is_decoded_without_resend(self):
        driver, native, handle, deadline, cancel = self.make()
        native.auto_ack = False
        expected = acknowledgement(driver.protocol, 0x31, -123, 456)
        reads = [0]
        original_read = native.read

        def read(count):
            reads[0] += 1
            if reads[0] == 2:
                native.response.extend(expected[:3])
            elif reads[0] == 6:
                native.response.extend(expected[3:])
            return original_read(count)

        native.read = read
        result = driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual((result[1]['pan'], result[1]['tilt']), (-12.3, 45.6))
        self.assertEqual(driver.last_exchange.response, expected)
        self.assertEqual(driver.last_exchange.category, 'ok')
        self.assertEqual(len(native.writes), 1)

    def test_cancellation_after_native_read_keeps_the_received_byte(self):
        driver, native, handle, deadline, cancel = self.make()
        original_read = native.read

        def read(count):
            value = original_read(count)
            cancel.set()
            return value

        native.read = read
        with self.assertRaisesRegex(PointingError, '^cancelled$'):
            driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertEqual(driver.last_exchange.response, b'\x06')
        self.assertEqual(driver.last_exchange.submission, 'complete')

    def test_receipt_sequence_never_wraps_or_reuses_previous_receipt(self):
        driver, native, handle, deadline, cancel = self.make()
        driver._exchange_sequence = 2**64 - 2
        driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        receipt = driver.last_exchange
        self.assertEqual(receipt.sequence, 2**64 - 1)
        with self.assertRaisesRegex(PointingError, '^exchange-sequence$'):
            driver.observe_bounded(handle, deadline=deadline, cancel=cancel)
        self.assertIs(driver.last_exchange, receipt)
        self.assertEqual(len(native.writes), 1)


if __name__ == "__main__":
    unittest.main()
