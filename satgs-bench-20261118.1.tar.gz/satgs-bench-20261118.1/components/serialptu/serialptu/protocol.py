###############################################################################
# Description:  Moog Quickset pan-tilt control protocol definitions.
#
#               Supports the Moog Quickset PTCR-96 control protocol.
#
#               Modified from code originally developed by Ed Klacza
#               <eklacza@mitre.org> in 2009.
#
#               Modified to separate protocol from the control logic, since
#               different Quickset PTUs use slightly different protocols
#
# Developer(s): Adam Shapiro <ashapiro@mitre.org>,
#               Collin Hockey <chockey@mitre.org>
#
# Date:         Created 2012/5/23
###############################################################################
# NOTICE
#
# This software was produced for the U.S. Government
# under Contract No. W15P7T-13-C-A802, and is
# subject to the Rights in Noncommercial Computer Software
# and Noncommercial Computer Software Documentation Clause
# (DFARS) 252.227-7014 (JUN 1995)
#
# (C) 2014 The MITRE Corporation
###############################################################################

import collections
import struct
import math
from serialptu.errors import CorruptedMessageError
# from serialptu.protocol import MessageInfo
CW = "CW"
CCW = "CCW"
UP = "UP"
DOWN = "DOWN"
AXIS_LIST = [CW, CCW, UP, DOWN]


class Protocol(object):
    """
    Base class for protocol definitions. Implementing classes should override
    any protocol messages they provide.

    IMPORTANT: Protocols often need to track some state, so access to these classes
    should be synchronized with sending commands to the PTU. For instance, on Quickset
    PTUs, any jog commands sent will need to be remembered so future get status requests
    don't inadvertantly stop the PTU from moving.
    """
    def __init__(self):
        pass

    def reset(self):
        """
        Reset any internal counters so we're ready to make a new PTU connection
        """
        return

    def get_end_of_packet(self):
        """
        Return the character or sequence marking the end of a packet.
        BufferedSerialReader can use this as an eop marker.
        """
        raise NotImplementedError("get_end_of_packet not implemented by {}".format(type(self).__name__))

    def get_status_definitions(self):
        """
        Return the layout of the status information sent back by get_status.

        This should be returned as a list of tuples. The first field is the
        status category, often PTUs report general status and status about
        each axis. The second field is another list of tuples, a shortened
        name, and a full name of each field in the status report.

        For example:

        [
            ("General", [ ("ENC", "Encoder Installed"), ("EXEC", "Executing Remote Command") ... ] ),
            ("Pan", [ ("CWSL", "Clockwise Soft Limit"), ... ] ),
            ("Tilt", [ ("USL", "Up Soft Limit"), ... ] ),
        ]
        """
        raise NotImplementedError("get_status_definitions not implemented by {}".format(type(self).__name__))

    MessageInfo = collections.namedtuple("MessageInfo",
                             ['message', 'acked', 'start_index', 'end_index', 'error'])

    def check_message(self, msgbuffer):
        """
        Scans a message buffer for the first available message.
        msgbuffer: A string of binary data that may or may not contain a valid message.

        Returns a named-tuple with fields message, acked,
        start_index, end_index and error:

        message:     The message itself. It will be cleared of escape characters,
                     the start and end markers and checksum.
        acked:       True if the response was an ACK, False if NAK.
        start_index: Index into the buffer the start of the message was found
        end_index:   Index into the buffer the end of the message was found. Often
                     this means the client code should slice the buffer to remove
                     the message by: msgbuffer = msgbuffer[end_index + 1:]
        error:       If there was an error processing a message, this will contain a
                     string describing it.

        If no message is found, this function returns the tuple:
        message:     ""
        acked:       False
        start_index: -1
        end_index:   -1
        error:       ""

        If there is an error in processing the message, this function returns a
        tuple describing the error and what portion of the buffer should be
        removed:
        message:     None
        acked:       False
        start_index: <undefined>
        end_index:   ending index of corrupted data
        error:       string describing the error

        Errors detected could be out of order start/end indexes, checksum
        failures, or is a message is too short.

        """
        raise NotImplementedError("check_message not implemented by {}".format(type(self).__name__))

    def parse_message(self, message):
        """Parse a message as returned by check_message. It should have the
        starting and ending bytes and the checksum stripped.

        Returns an implementation defined structure for the parsed message.
        """
        raise NotImplementedError("parse_message not implemented by {}".format(type(self).__name__))

    def get_status(self):
        """
        Create the message which retrieves the current pan/tilt positions
        """
        raise NotImplementedError("get_status not implemented by {}".format(type(self).__name__))

    def jog(self, pan_velocity, tilt_velocity, override_soft_limits = False):
        """
        Create a jog message
        pan_velocity: [-1,1] value where 0 is stationary and 1 is the max pan speed
        tilt_velocity: [-1,1] value where 0 is stationary and 1 is the max tilt speed
        override_soft_limits: True if the jog should ignore soft limits set in the PTU

        """
        raise NotImplementedError("jog not implemented by {}".format(type(self).__name__))

    def move_to_preset(self, preset):
        """
        Create a message to move to a preset value
        preset: The preset number to move to
        """
        raise NotImplementedError("move_to_preset not implemented by {}".format(type(self).__name__))

    def move_to(self, pan, tilt):
        """
        Create a message to move the PTU to a particular offset coordinate.

        pan: Pan angle (in degrees) [-360.0, 360.0]. Set to 999.99 to lock axis.
        tilt: Tilt angle (in degrees) [-180.0, 180.0]. Set to 999.99 to lock axis.
        """
        raise NotImplementedError("move_to_coord not implemented by {}".format(type(self).__name__))

    def move_delta(self, pan, tilt):
        """
        Create a message to move axes to the specified distance from their current positions.

        pan: Delta pan angle (in degrees) [-360.0, 360.0].
        tilt: Delta tilt angle (in degrees) [-180.0, 180.0].
        timeout: The response timeout (in seconds).
        """
        raise NotImplementedError("move_delta_coord not implemented by {}".format(type(self).__name__))

    def move_to_zero(self):
        """
        Create a message to move to the zero position.
        """
        raise NotImplementedError("move_to_zero not implemented by {}".format(type(self).__name__))

    def get_ramp_params(self):
        """
        Create a message to get current ramp parameters
        """
        raise NotImplementedError("get_ramp_params not implemented by {}".format(type(self).__name__))

    def set_ramp_params(self,
                      pan_start_speed=0, pan_acc_rate=0.1, pan_dec_start=1,
                      tilt_start_speed=0, tilt_acc_rate=0.1, tilt_dec_start=1):
        """
        Set the auto-positioning control loop ramp parameters.

        pan_start_speed: The starting/stopping pan speed as a fraction of the
                         specified minimum and maximum speeds [0, 1]. For
                         instance, 0 yields the minimum speed while 1 yields
                         the maximum speed.
        pan_acc_rate: The acceleration/deceleration rate (in seconds/speed
                      increment) [0, 0.01275]. The total ramp length is equal
                      to this value multiplied by the number of speed
                      increments from the start speed to the maximum. For
                      example, if the start velocity is 50 and the maximum is
                      100, a rate of 0.01 would take 0.5 seconds to reach full
                      speed.
        pan_dec_start: The deceleration starting point, specified as the
                       multiple the number of speed increments to return to the
                       starting speed [0.25, 63.75]. For example, if the
                       maximum speed is 100 and the starting speed is 40, there
                       are 60 speed steps to cover. If the multiplier is set to
                       0.5, the deceleration will begin 30 encoder ticks (RUs)
                       from the target position.
        tilt_start_speed: The starting/stopping tilt speed as a fraction of the
                          specified minimum and maximum speeds [0, 1]. For
                          instance, 0 yields the minimum speed while 1 yields
                          the maximum speed.
        tilt_acc_rate: The acceleration/deceleration rate (in seconds/speed
                       increment) [0, 0.01275]. The total ramp length is equal
                       to this value multiplied by the number of speed
                       increments from the start speed to the maximum. For
                       example, if the start velocity is 50 and the maximum is
                       100, a rate of 0.01 would take 0.5 seconds to reach full
                       speed.
        tilt_dec_start: The deceleration starting point, specified as the
                        multiple the number of speed increments to return to the
                        starting speed [0.25, 63.75]. For example, if the
                        maximum speed is 100 and the starting speed is 40, there
                        are 60 speed steps to cover. If the multiplier is set to
                        0.5, the deceleration will begin 30 encoder ticks (RUs)
                        from the target position.
        """
        raise NotImplementedError("set_ramp_params not implemented by {}".format(type(self).__name__))

    def get_max_speed(self):
        """
        Create a message to get the max speed setting
        """
        raise NotImplementedError("get_max_speed not implemented by {}".format(type(self).__name__))

    def set_max_speed(self, pan_speed, tilt_speed, non_volatile=False):
        """
        Set the maximum allowable speed for each axis.

        pan_speed: The maximum pan axis speed as a fraction of the maximum
                   speed the unit is capable of performing (0, 1].
        tilt_speed: The maximum tilt axis speed as a fraction of the maximum
                    speed the unit is capable of performing [0, 1].
        non_volatile: If true, the value is stored in non-volatile memory
                      and will be maintained on a power cycle. If set when
                      query_only is set, the values returned will be stored in
                      non-volatile memory.
        """
        raise NotImplementedError("get_max_speed not implemented by {}".format(type(self).__name__))

    def get_soft_limit(self, axis):
        """
        Create a message to query the soft limit values

        axis: should be one of CW (pan), CCW (pan), UP (tilt), DOWN (tilt)
        """
        raise NotImplementedError("get_soft_limit not implemented by {}".format(type(self).__name__))

    def set_soft_limit(self, axis):
        """
        Create a message which sets the soft limit to the current position.

        axis: should be one of CW (pan), CCW (pan), UP (tilt), DOWN (tilt)
        """
        raise NotImplementedError("set_soft_limit not implemented by {}".format(type(self).__name__))

    def _check_axis(self, axis):
        """
        Check whether an axis value is valid
        """
        if not axis in AXIS_LIST:
            raise ValueError("Axis must be one of " + ", ".join(AXIS_LIST))

    def _pack_int_24(self, value):
        """
        Pack a signed integer into a 3-byte value
        """
        return struct.pack('<i', int(value))[0:3]

    def _pack_uint_24(self, value):
        """
        Pack an unsigned integer into a 3-byte value
        """
        return struct.pack('<I', int(value))[0:3]

    def _unpack_int_24(self, data):
        """
        Unpack a signed integer from a 3-byte value
        """
        return struct.unpack('<i', data + (b'\0' if data[2] < 0x80 else b'\xFF'))[0]

    def _unpack_uint_24(self, data):
        """
        Unpacked an unsigned integer from a 3-byte value
        """
        return struct.unpack('<i', data + b'\0')[0]

    def _pack_int_16(self, value):
        """
        Pack a signed integer into a 2-byte value
        """
        return struct.pack('<h', int(value))

    def _pack_uint_16(self, value):
        """
        Pack an unsigned integer into a 2-byte value
        """
        return struct.pack('<H', int(value))

    def _unpack_int_16(self, data):
        """
        Unpack a 2-byte signed integer
        """
        return struct.unpack('<h', data)[0]

    def _unpack_uint_16(self, data):
        """
        Unpack a 2-byte unsigned integer
        """
        return struct.unpack('<H', data)[0]

    def _limit(self, value, min_value, max_value):
        value = float(value)
        if(value > max_value):
            return max_value
        elif(value < min_value):
            return min_value
        else:
            return value

    def _bytes_to_hex(self, msg):
        return " ".join("{:02x}".format(c for c in msg))


class Quickset(Protocol):

    _coordinate_width = 2

    def _decode_strict_packet(self, packet, marker):
        if (type(packet) is not bytes or not 4 <= len(packet) <= 64
                or packet[0] != marker or packet[-1] != self._special_chars['etx']):
            raise CorruptedMessageError("strict-frame")
        encoded = packet[1:-1]
        special = tuple(self._special_chars.values())
        index = 0
        while index < len(encoded):
            value = encoded[index]
            if value == self._special_chars['esc']:
                index += 1
                if index == len(encoded) or encoded[index] not in tuple(v | 0x80 for v in special):
                    raise CorruptedMessageError("strict-escape")
            elif value in special:
                raise CorruptedMessageError("strict-escape")
            index += 1
        decoded = self._unescape_message(encoded)
        if not decoded or not self._verify_checksum(decoded):
            raise CorruptedMessageError("strict-checksum")
        if self._ptu_id is not None:
            if len(decoded) < 2 or decoded[0] != self._ptu_id:
                raise CorruptedMessageError("strict-address")
            decoded = decoded[1:]
        return decoded[:-1]

    def decode_move_to_packet(self, packet):
        data = self._decode_strict_packet(packet, self._special_chars['stx'])
        width = self._coordinate_width
        if (width not in (2, 3) or self._degree_factor != (10 if width == 2 else 100)
                or len(data) != 1 + width * 2 + self._move_aux_bytes
                or data[0] != self._commands['move_to']
                or data[1 + width * 2:] != bytes(self._move_aux_bytes)):
            raise CorruptedMessageError("strict-move")
        unpack = self._unpack_int_16 if width == 2 else self._unpack_int_24
        return (unpack(data[1:1 + width]), unpack(data[1 + width:1 + width * 2]),
                int(self._degree_factor))

    def validate_nonmoving_status_packet(self, packet):
        data = self._decode_strict_packet(packet, self._special_chars['stx'])
        if (len(data) != 4 + self._jog_aux_bytes or data[0] != self._commands['jog']
                or data[1:] != bytes(3 + self._jog_aux_bytes)):
            raise CorruptedMessageError("strict-status")
        return packet

    def stop_packet(self):
        return self.jog(0, 0, override_soft_limits=False, stop=True, reset_errors=False)

    def validate_stop_packet(self, packet):
        data = self._decode_strict_packet(packet, self._special_chars['stx'])
        if (len(data) != 4 + self._jog_aux_bytes or data[0] != self._commands['jog']
                or data[1] != 2 or data[2:] != bytes(2 + self._jog_aux_bytes)):
            raise CorruptedMessageError("strict-stop")
        return packet

    def decode_pointing_response(self, packet, command):
        if type(packet) is not bytes or not packet:
            raise CorruptedMessageError("strict-response")
        if packet[0] == self._special_chars['nak']:
            self._decode_strict_packet(packet, self._special_chars['nak'])
            raise CorruptedMessageError("strict-nak")
        data = self._decode_strict_packet(packet, self._special_chars['ack'])
        if (command not in (self._commands['move_to'], self._commands['jog'])
                or len(data) != 4 + self._coordinate_width * 2 or data[0] != command):
            raise CorruptedMessageError("strict-response")
        return self.parse_message(data)

    _commands = {
        "jog" : 0x31,

        "move_to_preset" : 0x32,
        "move_to" :        0x33,
        "move_delta" :     0x34,
        "move_to_zero" :   0x35,
        "move_to_home" :   0x36,

        "start_preset_tour" : 0x37,
        "get_soft_limit" : 0x81, #0x71,
        "set_soft_limit" : 0x81,

        "get_pt_ramp_params": 0x92, #ptcr96 only
        "get_min_speeds" : 0x92,    #ptcr20 only
        "set_min_speeds" : 0x93,    #ptcr20 only
        "get_max_speeds" : 0x98,    #ptcr20 only
        "set_max_speeds" : 0x99,    #ptcr20 only
    }

    _command_lookup = {command : name for name, command in _commands.items()}

    _axis = {
        CW   : 0,
        CCW  : 1,
        UP   : 2,
        DOWN : 3
    }

    _axis_lookup = {axis : name for name, axis in _axis.items()}

    # Special (control) characters.
    _special_chars = {"stx": 0x02,
                      "etx": 0x03,
                      "ack": 0x06,
                      "nak": 0x15,
                      "esc": 0x1b}

    _ptu_id = 0x0

    def __init__(self, ptu_id, jog_aux_bytes, move_aux_bytes, degree_factor = 10):
        super(Quickset,self).__init__()

        self._ptu_id = ptu_id
        self._jog_aux_bytes = jog_aux_bytes
        self._move_aux_bytes = move_aux_bytes
        self._degree_factor = float(degree_factor)

        self._last_jog_pan = 0
        self._last_jog_tilt = 0
        self._last_jog_override = False

    def reset(self):
        self._last_jog_pan = 0
        self._last_jog_tilt = 0
        self._last_jog_override = False

    def get_end_of_packet(self):
        return self._special_chars['etx']

    def check_message(self, msgbuffer):
        # Find the first of ack or nacks in the buffer
        try:
            first = next(c for c in msgbuffer if c in [self._special_chars['ack'], self._special_chars['nak']])
            start_idx = msgbuffer.find(first)
        except:
            start_idx = -1

        end_idx   = msgbuffer.find(self._special_chars["etx"])

        # An end without a start of packet
        if start_idx == -1 and end_idx != -1:
            # print("end without start of packet")
            return Protocol.MessageInfo(message = None,
                                        acked = False,
                                        start_index = -1,
                                        end_index = end_idx,
                                        error = "Unexpected ending index")

        # Don't see an end of packet yet, just return empty
        if end_idx < 0:
            return Protocol.MessageInfo(message = None,
                               acked = False,
                               start_index = -1,
                               end_index = -1,
                               error = "")

        # Partial message in buffer
        # Have the client erase up to the first start of packed indicator
        if start_idx > end_idx:
            # print("partial message in buffer")
            return Protocol.MessageInfo(message = None,
                                        acked = False,
                                        start_index = -1,
                                        end_index = start_idx - 1,
                                        error = "Unexpected ending index")

        message = msgbuffer[start_idx + 1:end_idx]
        message = self._unescape_message(message)
        if not self._verify_checksum(message):

            return Protocol.MessageInfo(message = None,
                                        acked = False,
                                        start_index = start_idx,
                                        end_index = end_idx,
                                        error = "Message checksum failure")

        message_start = 0 if self._ptu_id is None else 1
        return Protocol.MessageInfo(message = message[message_start:-1],
                                    acked = True if msgbuffer[start_idx] == self._special_chars["ack"] else False,
                                    start_index = start_idx,
                                    end_index = end_idx,
                                    error = "")

    def parse_message(self, message):
        command = message[0]
        #print(f"Received command: {self._command_lookup[command]}") # Name of the command in _commands
        #if self._commands['jog'] <= command <= self._commands['move_to_home']:
            #return self._parse_move_message(message)
        if command == self._commands['jog']:
            return self.parse_status_message(message)
        elif self._commands['jog'] < command <= self._commands['move_to_home']:
            return self.parse_move_message(message)
        elif command == self._commands['get_soft_limit'] or command == self._commands['set_soft_limit']:
            return self.parse_limit_message(message)
        elif command == self._commands['get_min_speeds'] or command == self._commands['set_min_speeds'] or command == self._commands['get_max_speeds'] or command == self._commands['set_max_speeds']:
            return self.parse_speed_limit_message(message)
        else:
            return None

    def get_status(self):
        return self.jog(self._last_jog_pan, self._last_jog_tilt, override_soft_limits=self._last_jog_override, stop=False)

    def move_to(self, pan_coord, tilt_coord):
        return self._coord_only_message(self._commands["move_to"], pan_coord, tilt_coord)

    def move_delta(self, pan, tilt):
        return self._coord_only_message(self._commands["move_delta"], pan, tilt)

    def move_to_zero(self):
        return self._build_message(bytes([self._commands["move_to_zero"]]))

    def reset_motor_timeout(self):
        # self._logger.debug("Attempting to reset motor error")
        return self.jog(self._last_jog_pan, self._last_jog_tilt, reset_errors=True)

    def jog(self, pan_velocity, tilt_velocity,
            override_soft_limits=False, stop=None, reset_errors=False):
        return self._build_jog(pan_velocity, tilt_velocity,
                               override_soft_limits=override_soft_limits,
                               stop=stop,
                               reset_errors=reset_errors)

    def set_soft_limit(self, axis):
        """
        DEPRECATED: Specific protocols should override this and provide an
        implementation
        """
        #self._check_axis(axis)

        #axis_num = self._axis[axis]

        #return self._build_message(bytes([self._commands["set_soft_limit"], axis_num]))
        return None

    def _coord_only_message(self, command, pan, tilt):
        data = (bytes([command]) +
                self._pack_int_16(pan * self._degree_factor) +
                self._pack_int_16(tilt * self._degree_factor) +
                bytes(self._move_aux_bytes))

        return self._build_message(data)

    def _build_jog(self, pan_velocity, tilt_velocity,
                   dir_bit=True,
                   max_speed=127, extra_cmd_mask=0x0,
                   override_soft_limits=False, stop=None, reset_errors=False):

        self._last_jog_pan = pan_velocity
        self._last_jog_tilt = tilt_velocity
        self._last_jog_override = override_soft_limits

        if stop is None:
            if pan_velocity == 0 and tilt_velocity == 0:
                stop = True
            else:
                stop = False

        cmd = 0
        if override_soft_limits: cmd = cmd | 0x4
        if stop:                 cmd = cmd | 0x2
        if reset_errors:         cmd = cmd | 0x1

        cmd = cmd | extra_cmd_mask

        pan_dir  = 1 if pan_velocity > 0 else 0
        tilt_dir = 1 if tilt_velocity > 0 else 0

        pan_velocity = abs(pan_velocity)
        tilt_velocity = abs(tilt_velocity)

        pan_velocity = int(math.ceil(self._limit(pan_velocity, 0, 1.0) * max_speed))
        tilt_velocity = int(math.ceil(self._limit(tilt_velocity, 0, 1.0) * max_speed))

        # print("pan vel int: {}".format(pan_velocity))
        # print("tilt vel int: {}".format(tilt_velocity))

        if dir_bit:
            pan_velocity  = (pan_velocity << 1)  | pan_dir
            tilt_velocity = (tilt_velocity << 1) | tilt_dir

        #print(f"The value of jog is:", bytes([self._commands["jog"]])) # always represented as b'1' (0x31)
        # print(f"The value of cmd is: {bytes(cmd)}")
        # print(f"The value of pan_velocity is: {bytes(pan_velocity)}")
        # print(f"The value of tilt_velocity is: {bytes(tilt_velocity)}")
        #print(f"The value of 'jog_aux_bytes' is: {bytes(self._jog_aux_bytes)}") # always \x00\x00 at this point

        data = (bytes([self._commands["jog"]]) +
		bytes([cmd, pan_velocity, tilt_velocity]) +
                bytes(self._jog_aux_bytes))

        # print(f"The hex representation of 'data' is: {data.hex()}")

        return self._build_message(data)

    def _build_message(self, data):
        if self._ptu_id is not None:
            data = bytes([self._ptu_id]) + data

        chk = self._calculate_checksum(data)
        #check the data type here...
        data += bytes([chk])
        #data += bytes([chk])
        data = self._escape_message(data)

        completed_packet = bytes([self._special_chars['stx']]) + data + bytes([self._special_chars['etx']])
        # print(f"Completed packet is: {completed_packet.hex()}")
        return completed_packet

    def _parse_move_message(self, message):
        """
        DEPRECATED: Use protocol-specific implementation
        """
        #if len(message) < 9:
            #raise CorruptedMessageError("Move response too short")

        #parsed = {
        #    'message_type' : 'move_response',
        #    'command'      : self._command_lookup[message[0]],
        #    'pan'          : self._unpack_int_16(message[1:3]) / self._degree_factor,
        #    'tilt'         : self._unpack_int_16(message[3:5]) / self._degree_factor,
        #    'status'       : self._parse_status_bits(message[5:8])
        #}

        #return parsed
        return None

    def _parse_status_bits(self, bitfields):
        """Specific protocols should override this function and provide an
        implementation"""
        return None

    def _parse_limit_message(self, message):
        """
        DEPRECATED: Use protocol-specific implementation
        """
        #if len(message) < 3:
         #   raise CorruptedMessageError("Get/Set Limit response too short")

        #parsed = {
        #    'message_type' : 'limit_response',
        #    'command'      : self._command_lookup[message[0]],
        #    'axis'         : self._axis_lookup[message[1]],
        #    'limit'        : self._unpack_int_16(message[2:4]) / self._degree_factor
        #}

        #return parsed
        return None

    def _verify_checksum(self, message):
        """
        Verify the checksum on a message
        """
        return self._calculate_checksum(message) == 0

    def _calculate_checksum(self, message):
        """
        Calculate the checksum for a message.
        """
        xor_sum = 0
        for c in message:
            xor_sum ^= c
        return xor_sum

    def _escape_message(self, message):
        """
        Insert escape codes for certain bytes
        """
        b = b""
        for c in message:
            b += self._escape(c)

        return b

    def _unescape_message(self, message):
        """
        Remove escape codes from bytes in a message
        """
        message = list(message)
        out = []
        n=0
        while n < len(message):
            if message[n] == self._special_chars["esc"]:
                # Clear the high bit in the escaped byte.
                message[n+1] = message[n+1] & 0x7f
                n += 1
            out.append(message[n])
            n += 1
        return(bytes(out))

    def _escape(self, char):
        if char in self._special_chars.values():
            return bytes([self._special_chars['esc'], (char | 0x80)])
        else:
            return bytes([char])

