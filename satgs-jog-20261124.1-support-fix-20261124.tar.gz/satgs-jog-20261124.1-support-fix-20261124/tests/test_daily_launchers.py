import hashlib
import fcntl
from contextlib import redirect_stdout
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


SOURCE = Path(__file__).resolve().parents[1] / 'launchers/daily.py'
PREVIOUS_UI_SOURCE = Path(__file__).resolve().parent / 'data/daily-ui-20261111.py'
PREVIOUS_GUIDE_SOURCE = Path(__file__).resolve().parent / 'data/daily-guide-20261112.py'
PREVIOUS_HANDBOOK_SOURCE = Path(__file__).resolve().parent / 'data/daily-handbook-20261112.py'
PREVIOUS_PTU_SOURCE = Path(__file__).resolve().parent / 'data/daily-ptu-20261117.py'
PREVIOUS_BENCH_SOURCE = Path(__file__).resolve().parent / 'data/daily-bench-20261118.py'
PREVIOUS_JOG_SOURCE = Path(__file__).resolve().parent / 'data/daily-jog-20261118.py'
PREVIOUS_JOG2_SOURCE = Path(__file__).resolve().parent / 'data/daily-jog2-20261118.py'
ACTIVITY_SOURCE = SOURCE.parents[1] / 'components/ground_station/src/satgs/operator_activity.py'
SPEC = importlib.util.spec_from_file_location('native_daily_launchers', SOURCE)
daily = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = daily
SPEC.loader.exec_module(daily)
ENTRY = '''import argparse
import json
import os
from pathlib import Path
import sys
parser = argparse.ArgumentParser(description='Controlled launcher fixture')
parser.add_argument('--workspace', required=True)
parser.add_argument('command', nargs='?', choices=('status',))
args = parser.parse_args()
station = Path(args.workspace) / 'station.json'
if not station.is_file():
    print('Station configuration is unavailable.', file=sys.stderr)
    raise SystemExit(4)
value = json.loads(station.read_text())
print(json.dumps(dict(fixture_profile=PROFILE, workspace=args.workspace,
                     station_name=value['station_name'],
                     hostname_scan=os.environ.get('STOMP_SKIP_HOSTNAME_SCAN'),
                     pythonpath=os.environ.get('PYTHONPATH'), virtualenv=os.environ.get('VIRTUAL_ENV'))))
'''
DOCS_ENTRY = '''import argparse
import json
import sys
parser = argparse.ArgumentParser(description='Controlled documentation launcher fixture')
parser.add_argument('--workspace', required=True)
parser.add_argument('--format', choices=('human', 'json'), default='human')
parser.add_argument('--read-docs', action='store_true')
parser.add_argument('--text', action='store_true')
parser.add_argument('command', nargs='?', choices=('docs',))
args = parser.parse_args()
if not args.read_docs and args.command != 'docs':
    parser.error('Select documentation.')
print(json.dumps(dict(fixture_profile=PROFILE, workspace=args.workspace,
                     docs=True, text=args.text, station_read=False)))
'''


class DailyLauncherTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='satgs-native-launcher-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.home = self.root / "home with spaces and 'quotes'"
        self.home.mkdir(mode=0o700)
        self.workspace = self.home / 'satgs/station'
        self.workspace.mkdir(parents=True, mode=0o700)
        (self.workspace / 'station.json').write_text(json.dumps({
            'station_name': 'Custom station', 'satgs_operator_workspace': {
                'schema_version': 1, 'id': 'a' * 32, 'root': str(self.workspace)}}))
        (self.workspace / 'station.json').chmod(0o600)
        (self.workspace / '.activity.lock').write_text('fixture station lease\n')
        (self.workspace / '.activity.lock').chmod(0o600)
        self.profile = {}
        for name, version in daily.VERSIONS.items():
            app = self.root / (name + ' application')
            (app / 'bin').mkdir(parents=True)
            interpreter = app / 'bin/python'
            interpreter.write_text('#!/bin/sh\nexec /usr/bin/python3 -S "$@"\n')
            interpreter.chmod(0o700)
            for entry_name in ('satgs-operator', 'satgs-operator-gui'):
                entry = app / 'bin' / entry_name
                entry.write_text('PROFILE = ' + repr(name) + '\n' + ENTRY)
                entry.chmod(0o700)
            metadata = app / 'lib/python3.11/site-packages' / ('satgs-' + version + '.dist-info/METADATA')
            metadata.parent.mkdir(parents=True)
            metadata.write_text('Metadata-Version: 2.1\nName: satgs\nVersion: ' + version + '\n\nFixture only.\n')
            if name in ('handbook', 'ptu', 'bench', 'jog', 'jog2', 'jog3', 'jog4', 'jog5', 'jog6'):
                package = metadata.parent.parent / 'satgs'
                package.mkdir()
                (package / '_package_layout.py').write_text('INSTALLED = True\n')
                (package / 'operator_activity.py').write_bytes(ACTIVITY_SOURCE.read_bytes())
            self.profile[name] = dict(application=str(app), candidate_version=version)

    def prepare(self):
        return daily.prepare(self.home, identities=self.profile)

    def select(self, target):
        return daily.select(self.home, target, identities=self.profile)

    def paths(self):
        return daily._paths(self.home)

    def snapshot(self, root=None):
        selected = root or self.home
        return {str(path.relative_to(selected)): (path.read_bytes(), stat.S_IMODE(path.stat().st_mode))
                for path in selected.rglob('*') if path.is_file() and not path.is_symlink()}

    def invoke(self, name, *arguments, cwd=None):
        environment = dict(PATH='/usr/bin:/bin', HOME=str(self.home), LANG='C', LC_ALL='C', TZ='UTC',
                           PYTHONPATH='/unrelated', VIRTUAL_ENV='/unrelated')
        return subprocess.run([str(self.home / '.local/bin' / name), *arguments],
                              cwd=cwd or self.root, env=environment, capture_output=True, text=True,
                              timeout=15, check=False)

    def legacy(self):
        paths = self.paths()
        dispatcher = self.home / '.local/share/satgs-launchers/runtime-20261110/daily.py'
        dispatcher.parent.mkdir(parents=True)
        legacy_bytes = b'controlled previous-dispatcher fixture; never executed\n'
        dispatcher.write_bytes(legacy_bytes)
        dispatcher.chmod(0o600)
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['runtime'],
                                                     workspace=str(self.workspace))) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, legacy_bytes

    def prepare_legacy(self, legacy_bytes):
        with mock.patch.object(daily, 'LEGACY_SOURCE_SHA256', hashlib.sha256(legacy_bytes).hexdigest()):
            return self.prepare()

    def previous_ui(self):
        source = PREVIOUS_UI_SOURCE.read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), daily.PREVIOUS_UI_SOURCE_SHA256)
        expected = {name: self.profile[name] for name in ('runtime', 'ui')}
        source = source.replace(b'BOUND_IDENTITIES = None\n',
                                ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
        dispatcher = self.home / '.local/share/satgs-launchers/ui-20261111/daily.py'
        dispatcher.parent.mkdir(parents=True, exist_ok=True)
        dispatcher.write_bytes(source)
        dispatcher.chmod(0o600)
        paths = self.paths()
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True, exist_ok=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['ui'],
                                                     workspace=str(self.workspace)), indent=2) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, source

    def enable_docs_fixture(self):
        entry = Path(self.profile['guide']['application']) / 'bin/satgs-operator'
        entry.write_text("PROFILE = 'guide'\n" + DOCS_ENTRY)

    def previous_guide(self):
        source = PREVIOUS_GUIDE_SOURCE.read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), daily.PREVIOUS_GUIDE_SOURCE_SHA256)
        expected = {name: self.profile[name] for name in ('runtime', 'ui', 'guide')}
        source = source.replace(b'BOUND_IDENTITIES = None\n',
                                ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
        dispatcher = self.home / '.local/share/satgs-launchers/guide-20261112/daily.py'
        dispatcher.parent.mkdir(parents=True, exist_ok=True)
        dispatcher.write_bytes(source)
        dispatcher.chmod(0o600)
        paths = self.paths()
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True, exist_ok=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['guide'],
                                                     workspace=str(self.workspace))) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, source

    def previous_handbook(self):
        source = PREVIOUS_HANDBOOK_SOURCE.read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), daily.PREVIOUS_HANDBOOK_SOURCE_SHA256)
        expected = {name: self.profile[name] for name in ('runtime', 'ui', 'guide', 'handbook')}
        source = source.replace(b'BOUND_IDENTITIES = None\n',
                                ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
        dispatcher = self.home / '.local/share/satgs-launchers/handbook-20261112/daily.py'
        dispatcher.parent.mkdir(parents=True, exist_ok=True)
        dispatcher.write_bytes(source)
        dispatcher.chmod(0o600)
        paths = self.paths()
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True, exist_ok=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['handbook'],
                                                     workspace=str(self.workspace)), indent=2) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, source

    def previous_ptu(self):
        source = PREVIOUS_PTU_SOURCE.read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), daily.PREVIOUS_PTU_SOURCE_SHA256)
        expected = {name: self.profile[name] for name in ('runtime', 'ui', 'guide', 'handbook', 'ptu')}
        source = source.replace(b'BOUND_IDENTITIES = None\n',
                                ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
        dispatcher = self.home / '.local/share/satgs-launchers/ptu-20261117/daily.py'
        dispatcher.parent.mkdir(parents=True, exist_ok=True)
        dispatcher.write_bytes(source)
        dispatcher.chmod(0o600)
        paths = self.paths()
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True, exist_ok=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['ptu'],
                                                     workspace=str(self.workspace)), indent=2) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, source

    def previous_bench(self):
        source = PREVIOUS_BENCH_SOURCE.read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), daily.PREVIOUS_BENCH_SOURCE_SHA256)
        expected = {name: self.profile[name] for name in ('runtime', 'ui', 'guide', 'handbook', 'ptu', 'bench')}
        source = source.replace(b'BOUND_IDENTITIES = None\n',
                                ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
        dispatcher = self.home / '.local/share/satgs-launchers/bench-20261118/daily.py'
        dispatcher.parent.mkdir(parents=True, exist_ok=True)
        dispatcher.write_bytes(source)
        dispatcher.chmod(0o600)
        paths = self.paths()
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True, exist_ok=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['bench'],
                                                     workspace=str(self.workspace)), indent=2) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, source

    def previous_jog(self):
        source = PREVIOUS_JOG_SOURCE.read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), daily.PREVIOUS_JOG_SOURCE_SHA256)
        expected = {name: self.profile[name] for name in ('runtime', 'ui', 'guide', 'handbook', 'ptu', 'bench', 'jog')}
        source = source.replace(b'BOUND_IDENTITIES = None\n',
                                ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
        dispatcher = self.home / '.local/share/satgs-launchers/jog-20261118/daily.py'
        dispatcher.parent.mkdir(parents=True, exist_ok=True)
        dispatcher.write_bytes(source)
        dispatcher.chmod(0o600)
        paths = self.paths()
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True, exist_ok=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['jog'],
                                                     workspace=str(self.workspace)), indent=2) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, source

    def previous_jog2(self):
        source = PREVIOUS_JOG2_SOURCE.read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), daily.PREVIOUS_JOG2_SOURCE_SHA256)
        expected = {name: self.profile[name] for name in ('runtime', 'ui', 'guide', 'handbook', 'ptu', 'bench', 'jog', 'jog2')}
        source = source.replace(b'BOUND_IDENTITIES = None\n',
                                ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
        dispatcher = self.home / '.local/share/satgs-launchers/jog-20261118-v2/daily.py'
        dispatcher.parent.mkdir(parents=True, exist_ok=True)
        dispatcher.write_bytes(source)
        dispatcher.chmod(0o600)
        paths = self.paths()
        for name in ('cli', 'gui'):
            paths[name].parent.mkdir(parents=True, exist_ok=True)
            paths[name].write_bytes(daily._wrapper(dispatcher, paths['selection'], name))
            paths[name].chmod(0o700)
        paths['menu'].parent.mkdir(parents=True, exist_ok=True)
        paths['menu'].write_bytes(daily._menu(self.home))
        paths['menu'].chmod(0o644)
        paths['selection'].parent.mkdir(parents=True, exist_ok=True)
        paths['selection'].write_text(json.dumps(dict(schema=daily.SCHEMA, **self.profile['jog2'],
                                                     workspace=str(self.workspace)), indent=2) + '\n')
        paths['selection'].chmod(0o600)
        return dispatcher, source

    def test_exact_previous_bench_upgrade_preserves_selection_and_explicit_jog_rollback(self):
        for prior_release, current in (('bench', 'jog'), ('jog', 'jog2'), ('jog2', 'jog3')):
            with self.subTest(previous=prior_release, current=current):
                if prior_release != 'bench':
                    self.setUp()
                dispatcher, source = getattr(self, 'previous_' + prior_release)()
                paths = self.paths()
                previous = {name: paths[name].read_bytes() for name in ('cli', 'gui', 'menu', 'selection')}
                station = self.snapshot(self.workspace)
                applications = {name: self.snapshot(Path(row['application'])) for name, row in self.profile.items()}
                prepared = self.prepare()
                self.assertEqual(prepared['selected_version'], daily.VERSIONS[prior_release])
                self.assertFalse(prepared['application_launched'])
                self.assertEqual(paths['selection'].read_bytes(), previous['selection'])
                self.assertEqual(paths['dispatcher'].parent.name, 'jog-20261124')
                self.assertEqual(len(daily.registered(self.profile)), 12)
                for name, content in previous.items():
                    self.assertEqual((Path(prepared['backup']) / name).read_bytes(), content)
                self.assertEqual(json.loads(self.invoke('satgs-operator', 'status').stdout)['fixture_profile'], prior_release)
                selected = self.select(current)
                self.assertFalse(selected['application_launched'])
                self.assertEqual(selected['selected_version'], daily.VERSIONS[current])
                self.assertEqual((Path(selected['backup']) / 'selection').read_bytes(), previous['selection'])
                for entry in ('satgs-operator', 'satgs-operator-gui'):
                    arguments = ('status',) if entry == 'satgs-operator' else ()
                    result = self.invoke(entry, *arguments)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual(json.loads(result.stdout)['fixture_profile'], current)
                self.select(prior_release)
                self.assertEqual(json.loads(paths['selection'].read_bytes()), json.loads(previous['selection']))
                self.assertEqual(dispatcher.read_bytes(), source)
                self.assertEqual(self.snapshot(self.workspace), station)
                for name, row in self.profile.items():
                    self.assertEqual(self.snapshot(Path(row['application'])), applications[name])

    def test_previous_bench_tampering_rejects_before_managed_writes(self):
        for prior_release, current in (('bench', 'jog'), ('jog', 'jog2'), ('jog2', 'jog3')):
            with self.subTest(previous=prior_release, current=current):
                if prior_release != 'bench':
                    self.setUp()
                for change in ('code', 'namespace', 'application', 'version', 'extra_identity', 'expression', 'wrapper_path'):
                    with self.subTest(change=change):
                        dispatcher, source = getattr(self, 'previous_' + prior_release)()
                        expected = {name: dict(self.profile[name])
                                    for name in ('runtime', 'ui', 'guide', 'handbook', 'ptu', 'bench')
                                    + (('jog', 'jog2') if prior_release == 'jog2' else
                                       ('jog',) if prior_release == 'jog' else ())}
                        line = ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode()
                        if change == 'code':
                            source += b'\n# controlled changed source\n'
                        elif change == 'namespace':
                            source = source.replace(line, line.replace(b'BOUND_IDENTITIES', b'OTHER_IDENTITIES'))
                        elif change == 'expression':
                            source = source.replace(line, b'BOUND_IDENTITIES = __import__("unapproved")\n')
                        else:
                            if change == 'application':
                                expected[prior_release]['application'] = str(self.root / ('unregistered ' + prior_release))
                            elif change == 'version':
                                expected[prior_release]['candidate_version'] = 'wrong'
                            elif change == 'extra_identity':
                                expected[current] = self.profile[current]
                            source = source.replace(line, ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
                        dispatcher.write_bytes(source)
                        if change == 'wrapper_path':
                            self.paths()['cli'].write_bytes(daily._wrapper(dispatcher.parent / 'other.py',
                                                                          self.paths()['selection'], 'cli'))
                        before = self.snapshot()
                        with self.assertRaises(ValueError):
                            self.prepare()
                        self.assertEqual(self.snapshot(), before)

    def test_previous_bench_race_preserves_selection_and_launchers(self):
        for prior_release, current in (('bench', 'jog'), ('jog', 'jog2'), ('jog2', 'jog3')):
            with self.subTest(previous=prior_release, current=current):
                if prior_release != 'bench':
                    self.setUp()
                dispatcher, source = getattr(self, 'previous_' + prior_release)()
                paths = self.paths()
                previous = {name: paths[name].read_bytes() for name in ('cli', 'gui', 'menu', 'selection')}
                lock = daily._lock

                def change_before_lock(home):
                    dispatcher.write_bytes(source + b'\n# changed before selection lock\n')
                    return lock(home)

                with mock.patch.object(daily, '_lock', side_effect=change_before_lock):
                    with self.assertRaisesRegex(ValueError, prior_release + ' dispatcher changed'):
                        self.prepare()
                for name, content in previous.items():
                    self.assertEqual(paths[name].read_bytes(), content)
                self.assertFalse(paths['dispatcher'].exists())

    def test_uninstalled_or_wrong_version_jog_cannot_replace_bench_selection(self):
        for prior_release, current in (('bench', 'jog'), ('jog', 'jog2'), ('jog2', 'jog3')):
            with self.subTest(previous=prior_release, current=current):
                if prior_release != 'bench':
                    self.setUp()
                getattr(self, 'previous_' + prior_release)()
                self.prepare()
                before = self.paths()['selection'].read_bytes()
                app = Path(self.profile[current]['application'])
                metadata = app / 'lib/python3.11/site-packages' / ('satgs-' + daily.VERSIONS[current] + '.dist-info/METADATA')
                metadata.write_text('Name: satgs\nVersion: wrong\n')
                with self.assertRaises(ValueError):
                    self.select(current)
                self.assertEqual(self.paths()['selection'].read_bytes(), before)
                metadata.unlink()
                with self.assertRaises(OSError):
                    self.select(current)
                self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_broken_jog_interpreter_allows_guarded_bench_rollback(self):
        for prior_release, current in (('bench', 'jog'), ('jog', 'jog2'), ('jog2', 'jog3')):
            with self.subTest(previous=prior_release, current=current):
                if prior_release != 'bench':
                    self.setUp()
                self.prepare()
                self.select(current)
                Path(self.profile[current]['application']).joinpath('bin/python').unlink()
                self.select(prior_release)
                result = self.invoke('satgs-operator', 'status')
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout)['fixture_profile'], prior_release)

    def test_exact_previous_ptu_upgrade_preserves_selection_and_explicit_bench_rollback(self):
        dispatcher, source = self.previous_ptu()
        paths = self.paths()
        previous = {name: paths[name].read_bytes() for name in ('cli', 'gui', 'menu', 'selection')}
        station = self.snapshot(self.workspace)
        applications = {name: self.snapshot(Path(row['application'])) for name, row in self.profile.items()}
        prepared = self.prepare()
        self.assertEqual(prepared['selected_version'], daily.VERSIONS['ptu'])
        self.assertFalse(prepared['application_launched'])
        self.assertEqual(paths['selection'].read_bytes(), previous['selection'])
        self.assertEqual(paths['dispatcher'].parent.name, 'jog-20261124')
        self.assertEqual(len(daily.registered(self.profile)), 12)
        for name, content in previous.items():
            self.assertEqual((Path(prepared['backup']) / name).read_bytes(), content)
        self.assertEqual(json.loads(self.invoke('satgs-operator', 'status').stdout)['fixture_profile'], 'ptu')
        selected = self.select('bench')
        self.assertFalse(selected['application_launched'])
        self.assertEqual(selected['selected_version'], daily.VERSIONS['bench'])
        self.assertEqual((Path(selected['backup']) / 'selection').read_bytes(), previous['selection'])
        for entry in ('satgs-operator', 'satgs-operator-gui'):
            arguments = ('status',) if entry == 'satgs-operator' else ()
            result = self.invoke(entry, *arguments)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)['fixture_profile'], 'bench')
        self.select('ptu')
        self.assertEqual(json.loads(paths['selection'].read_bytes()), json.loads(previous['selection']))
        self.assertEqual(dispatcher.read_bytes(), source)
        self.assertEqual(self.snapshot(self.workspace), station)
        for name, row in self.profile.items():
            self.assertEqual(self.snapshot(Path(row['application'])), applications[name])

    def test_previous_ptu_tampering_rejects_before_managed_writes(self):
        for change in ('code', 'namespace', 'application', 'version', 'extra_identity', 'expression', 'wrapper_path'):
            with self.subTest(change=change):
                dispatcher, source = self.previous_ptu()
                expected = {name: dict(self.profile[name]) for name in ('runtime', 'ui', 'guide', 'handbook', 'ptu')}
                line = ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode()
                if change == 'code':
                    source += b'\n# controlled changed source\n'
                elif change == 'namespace':
                    source = source.replace(line, line.replace(b'BOUND_IDENTITIES', b'OTHER_IDENTITIES'))
                elif change == 'expression':
                    source = source.replace(line, b'BOUND_IDENTITIES = __import__("unapproved")\n')
                else:
                    if change == 'application':
                        expected['ptu']['application'] = str(self.root / 'unregistered ptu')
                    elif change == 'version':
                        expected['ptu']['candidate_version'] = 'wrong'
                    elif change == 'extra_identity':
                        expected['bench'] = self.profile['bench']
                    source = source.replace(line, ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
                dispatcher.write_bytes(source)
                if change == 'wrapper_path':
                    self.paths()['cli'].write_bytes(daily._wrapper(dispatcher.parent / 'other.py',
                                                                  self.paths()['selection'], 'cli'))
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.prepare()
                self.assertEqual(self.snapshot(), before)

    def test_previous_ptu_race_preserves_selection_and_launchers(self):
        dispatcher, source = self.previous_ptu()
        paths = self.paths()
        previous = {name: paths[name].read_bytes() for name in ('cli', 'gui', 'menu', 'selection')}
        lock = daily._lock

        def change_before_lock(home):
            dispatcher.write_bytes(source + b'\n# changed before selection lock\n')
            return lock(home)

        with mock.patch.object(daily, '_lock', side_effect=change_before_lock):
            with self.assertRaisesRegex(ValueError, 'PTU dispatcher changed'):
                self.prepare()
        for name, content in previous.items():
            self.assertEqual(paths[name].read_bytes(), content)
        self.assertFalse(paths['dispatcher'].exists())

    def test_uninstalled_or_wrong_version_bench_cannot_replace_ptu_selection(self):
        self.previous_ptu()
        self.prepare()
        before = self.paths()['selection'].read_bytes()
        app = Path(self.profile['bench']['application'])
        metadata = app / 'lib/python3.11/site-packages' / ('satgs-' + daily.VERSIONS['bench'] + '.dist-info/METADATA')
        metadata.write_text('Name: satgs\nVersion: wrong\n')
        with self.assertRaises(ValueError):
            self.select('bench')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)
        metadata.unlink()
        with self.assertRaises(OSError):
            self.select('bench')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_broken_bench_interpreter_allows_guarded_ptu_rollback(self):
        self.prepare()
        self.select('bench')
        Path(self.profile['bench']['application']).joinpath('bin/python').unlink()
        self.select('ptu')
        result = self.invoke('satgs-operator', 'status')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['fixture_profile'], 'ptu')

    def test_exact_previous_handbook_upgrade_preserves_bytes_and_explicit_ptu_rollback(self):
        dispatcher, source = self.previous_handbook()
        paths = self.paths()
        previous = {name: paths[name].read_bytes() for name in ('cli', 'gui', 'menu', 'selection')}
        station = self.snapshot(self.workspace)
        applications = {name: self.snapshot(Path(row['application'])) for name, row in self.profile.items()}
        prepared = self.prepare()
        self.assertEqual(prepared['selected_version'], daily.VERSIONS['handbook'])
        self.assertFalse(prepared['application_launched'])
        self.assertEqual(paths['selection'].read_bytes(), previous['selection'])
        self.assertEqual(paths['dispatcher'].parent.name, 'jog-20261124')
        for name, content in previous.items():
            self.assertEqual((Path(prepared['backup']) / name).read_bytes(), content)
        self.assertEqual(json.loads(self.invoke('satgs-operator', 'status').stdout)['fixture_profile'], 'handbook')
        selected = self.select('ptu')
        self.assertFalse(selected['application_launched'])
        self.assertEqual(selected['selected_version'], daily.VERSIONS['ptu'])
        self.assertEqual((Path(selected['backup']) / 'selection').read_bytes(), previous['selection'])
        for entry in ('satgs-operator', 'satgs-operator-gui'):
            arguments = ('status',) if entry == 'satgs-operator' else ()
            result = self.invoke(entry, *arguments)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)['fixture_profile'], 'ptu')
        self.select('handbook')
        self.assertEqual(json.loads(paths['selection'].read_bytes()), json.loads(previous['selection']))
        self.assertEqual(dispatcher.read_bytes(), source)
        self.assertEqual(self.snapshot(self.workspace), station)
        for name, row in self.profile.items():
            self.assertEqual(self.snapshot(Path(row['application'])), applications[name])

    def test_previous_handbook_tampering_is_rejected_before_managed_writes(self):
        for change in ('code', 'namespace', 'application', 'version', 'extra_identity', 'expression', 'wrapper_path'):
            with self.subTest(change=change):
                dispatcher, source = self.previous_handbook()
                expected = {name: dict(self.profile[name]) for name in ('runtime', 'ui', 'guide', 'handbook')}
                line = ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode()
                if change == 'code':
                    source += b'\n# controlled changed source\n'
                elif change == 'namespace':
                    source = source.replace(line, line.replace(b'BOUND_IDENTITIES', b'OTHER_IDENTITIES'))
                elif change == 'expression':
                    source = source.replace(line, b'BOUND_IDENTITIES = __import__("unapproved")\n')
                else:
                    if change == 'application':
                        expected['handbook']['application'] = str(self.root / 'unregistered handbook')
                    elif change == 'version':
                        expected['handbook']['candidate_version'] = 'wrong'
                    elif change == 'extra_identity':
                        expected['ptu'] = self.profile['ptu']
                    source = source.replace(line, ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
                dispatcher.write_bytes(source)
                if change == 'wrapper_path':
                    self.paths()['cli'].write_bytes(daily._wrapper(dispatcher.parent / 'other.py',
                                                                  self.paths()['selection'], 'cli'))
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.prepare()
                self.assertEqual(self.snapshot(), before)

    def test_previous_handbook_race_preserves_selection_and_launchers(self):
        dispatcher, source = self.previous_handbook()
        paths = self.paths()
        previous = {name: paths[name].read_bytes() for name in ('cli', 'gui', 'menu', 'selection')}
        lock = daily._lock

        def change_before_lock(home):
            dispatcher.write_bytes(source + b'\n# changed before selection lock\n')
            return lock(home)

        with mock.patch.object(daily, '_lock', side_effect=change_before_lock):
            with self.assertRaisesRegex(ValueError, 'handbook dispatcher changed'):
                self.prepare()
        for name, content in previous.items():
            self.assertEqual(paths[name].read_bytes(), content)
        self.assertFalse(paths['dispatcher'].exists())

    def test_uninstalled_or_wrong_version_ptu_cannot_replace_handbook_selection(self):
        self.previous_handbook()
        self.prepare()
        before = self.paths()['selection'].read_bytes()
        app = Path(self.profile['ptu']['application'])
        metadata = app / 'lib/python3.11/site-packages' / ('satgs-' + daily.VERSIONS['ptu'] + '.dist-info/METADATA')
        metadata.write_text('Name: satgs\nVersion: wrong\n')
        with self.assertRaises(ValueError):
            self.select('ptu')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)
        metadata.unlink()
        with self.assertRaises(OSError):
            self.select('ptu')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_broken_ptu_interpreter_allows_guarded_handbook_rollback(self):
        self.prepare()
        self.select('ptu')
        Path(self.profile['ptu']['application']).joinpath('bin/python').unlink()
        self.select('handbook')
        result = self.invoke('satgs-operator', 'status')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['fixture_profile'], 'handbook')

    def test_exact_previous_ui_upgrade_preserves_selection_source_and_application_bytes(self):
        dispatcher, source = self.previous_ui()
        paths = self.paths()
        previous = {name: paths[name].read_bytes() for name in ('cli', 'gui', 'menu', 'selection')}
        station = self.snapshot(self.workspace)
        applications = {name: self.snapshot(Path(row['application'])) for name, row in self.profile.items()}
        result = self.prepare()
        self.assertEqual(result['selected_version'], daily.VERSIONS['ui'])
        self.assertFalse(result['application_launched'])
        self.assertEqual(paths['selection'].read_bytes(), previous['selection'])
        self.assertEqual(dispatcher.read_bytes(), source)
        self.assertEqual(paths['dispatcher'].parent.name, 'jog-20261124')
        self.assertIn(str(paths['dispatcher']).replace("'", "'\\''"), paths['cli'].read_text())
        for name, content in previous.items():
            self.assertEqual((Path(result['backup']) / name).read_bytes(), content)
        self.assertEqual(self.snapshot(self.workspace), station)
        for name, row in self.profile.items():
            self.assertEqual(self.snapshot(Path(row['application'])), applications[name])
        self.assertEqual(self.invoke('satgs-operator', 'status').returncode, 0)
        self.assertEqual(json.loads(self.invoke('satgs-operator', 'status').stdout)['fixture_profile'], 'ui')

    def test_previous_ui_tampering_is_rejected_before_any_managed_write(self):
        for change in ('code', 'namespace', 'application', 'version', 'extra_identity', 'expression', 'wrapper_path'):
            with self.subTest(change=change):
                dispatcher, source = self.previous_ui()
                expected = {name: dict(self.profile[name]) for name in ('runtime', 'ui')}
                line = ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode()
                if change == 'code':
                    source += b'\n# changed source\n'
                elif change == 'namespace':
                    source = source.replace(line, line.replace(b'BOUND_IDENTITIES', b'OTHER_IDENTITIES'))
                elif change == 'expression':
                    source = source.replace(line, b'BOUND_IDENTITIES = __import__("unapproved")\n')
                elif change in ('application', 'version', 'extra_identity'):
                    if change == 'application':
                        expected['ui']['application'] = str(self.root / 'unregistered ui')
                    elif change == 'version':
                        expected['ui']['candidate_version'] = 'wrong'
                    else:
                        expected['guide'] = self.profile['guide']
                    source = source.replace(line, ('BOUND_IDENTITIES = ' + repr(expected) + '\n').encode())
                dispatcher.write_bytes(source)
                if change == 'wrapper_path':
                    self.paths()['cli'].write_bytes(daily._wrapper(dispatcher.parent / 'other.py',
                                                                  self.paths()['selection'], 'cli'))
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.prepare()
                self.assertEqual(self.snapshot(), before)

    def test_all_registered_application_paths_must_be_distinct(self):
        for first, second in ((first, second) for first in self.profile for second in self.profile if first < second):
            with self.subTest(first=first, second=second):
                profile = {name: dict(row) for name, row in self.profile.items()}
                profile[second]['application'] = profile[first]['application']
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    daily.prepare(self.home, identities=profile)
                self.assertEqual(self.snapshot(), before)

    def test_guide_selection_is_explicit_and_rolls_back_to_previous_ui_without_data_changes(self):
        dispatcher, source = self.previous_ui()
        selection = self.paths()['selection'].read_bytes()
        station = self.snapshot(self.workspace)
        self.prepare()
        self.assertEqual(self.paths()['selection'].read_bytes(), selection)
        result = self.select('guide')
        self.assertEqual(result['selected_version'], daily.VERSIONS['guide'])
        self.assertFalse(result['application_launched'])
        self.assertEqual((Path(result['backup']) / 'selection').read_bytes(), selection)
        value = json.loads(self.invoke('satgs-operator', 'status').stdout)
        self.assertEqual(value['fixture_profile'], 'guide')
        self.assertEqual(value['workspace'], str(self.workspace))
        self.select('ui')
        self.assertEqual(json.loads(self.invoke('satgs-operator', 'status').stdout)['fixture_profile'], 'ui')
        self.assertEqual(json.loads(self.paths()['selection'].read_bytes()), json.loads(selection))
        self.assertEqual(dispatcher.read_bytes(), source)
        self.assertEqual(self.snapshot(self.workspace), station)

    def test_generated_docs_forms_do_not_require_or_initialize_a_station_directory(self):
        self.enable_docs_fixture()
        self.prepare()
        self.select('guide')
        before = self.paths()['selection'].read_bytes()
        missing = self.home / 'no station with spaces'
        unsuitable = self.home / 'not a station directory'
        unsuitable.write_text('retained ordinary file')
        for workspace in (missing, unsuitable):
            for arguments in (('docs',), ('--read-docs',), ('docs', '--text'), ('--format', 'json', 'docs', '--text')):
                with self.subTest(workspace=workspace, arguments=arguments):
                    result = self.invoke('satgs-operator', '--workspace', str(workspace), *arguments)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    value = json.loads(result.stdout)
                    self.assertTrue(value['docs'])
                    self.assertFalse(value['station_read'])
                    self.assertEqual(value['workspace'], str(workspace))
        self.assertFalse(missing.exists())
        self.assertEqual(unsuitable.read_text(), 'retained ordinary file')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_docs_bypass_does_not_bypass_application_identity_or_non_docs_checks(self):
        self.prepare()
        missing = self.home / 'missing station'
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), \
                mock.patch.object(daily.os, 'execve') as execute:
            for mode, arguments in (('cli', ['status']), ('cli', ['status', 'docs']),
                                    ('cli', ['--format', 'docs', 'status']),
                                    ('cli', ['status', '--read-docs']), ('gui', ['docs'])):
                with self.subTest(mode=mode, arguments=arguments), self.assertRaises((ValueError, OSError)):
                    daily.launch(mode, ['--workspace', str(missing), *arguments], self.paths()['selection'])
            metadata = Path(self.profile['runtime']['application']) / 'lib/python3.11/site-packages' / (
                'satgs-' + daily.VERSIONS['runtime'] + '.dist-info/METADATA')
            metadata.write_text('Name: satgs\nVersion: wrong\n')
            with self.assertRaises(ValueError):
                daily.launch('cli', ['--workspace', str(missing), 'docs'], self.paths()['selection'])
            execute.assert_not_called()

    def test_docs_launch_keeps_ssh_and_desktop_markers_but_no_browser_command(self):
        self.prepare()
        environment = {'SSH_CONNECTION': 'ssh-fixture', 'SSH_CLIENT': 'ssh-client-fixture', 'SSH_TTY': 'ssh-tty-fixture',
                       'WAYLAND_DISPLAY': 'wayland-fixture', 'BROWSER': 'untrusted command'}
        with mock.patch.dict(os.environ, environment, clear=True), \
                mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile):
            _, _, selected = daily.launch_plan('cli', ['docs'], self.paths()['selection'])
        for name in environment:
            if name == 'BROWSER':
                self.assertNotIn(name, selected)
            else:
                self.assertEqual(selected[name], environment[name])

    def test_preparation_and_selection_output_never_auto_launch_the_gui(self):
        self.previous_ui()
        station = self.snapshot(self.workspace)
        output = io.StringIO()
        with mock.patch.object(daily.Path, 'home', return_value=self.home), \
                mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), \
                mock.patch.object(daily.os, 'execve', side_effect=AssertionError('unexpected application launch')), \
                redirect_stdout(output):
            self.assertEqual(daily.main([]), 0)
            self.assertEqual(daily.main(['--select', 'guide']), 0)
        self.assertIn('Selected: ui\n', output.getvalue())
        self.assertIn('Selected: guide\n', output.getvalue())
        self.assertIn('Selection only: the GUI was not opened.', output.getvalue())
        self.assertNotIn('Science', output.getvalue())
        self.assertIn('Categories=Science;', self.paths()['menu'].read_text())
        self.assertIn('GUI terminal alternative: satgs-operator-gui', output.getvalue())
        self.assertEqual(self.snapshot(self.workspace), station)

    def test_explicit_init_plan_checks_parent_without_creating_a_workspace(self):
        self.prepare()
        target = self.home / 'separate practice with spaces'
        before = self.snapshot()
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), \
                mock.patch.object(daily.os, 'execve') as execute:
            for arguments in (['--workspace', str(target), 'init'],
                              ['--workspace=' + str(target), '--format=json', 'init']):
                with self.subTest(arguments=arguments):
                    _, command, _ = daily.launch_plan('cli', arguments, self.paths()['selection'])
                    self.assertEqual(command[4:6], ['--workspace', str(target)])
                    self.assertEqual(command[-1], 'init')
            execute.assert_not_called()
        self.assertFalse(target.exists())
        self.assertEqual(self.snapshot(), before)

    def test_init_without_explicit_workspace_keeps_an_absent_daily_station_absent(self):
        self.prepare()
        (self.workspace / 'station.json').unlink()
        (self.workspace / '.activity.lock').unlink()
        self.workspace.rmdir()
        before = self.snapshot()
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), \
                mock.patch.object(daily.os, 'execve') as execute:
            with self.assertRaises(FileNotFoundError):
                daily.launch('cli', ['init'], self.paths()['selection'])
            execute.assert_not_called()
        self.assertFalse(self.workspace.exists())
        self.assertEqual(self.snapshot(), before)

    def test_explicit_init_refuses_unsuitable_parents_and_link_or_nondirectory_targets(self):
        self.prepare()
        file_parent = self.home / 'ordinary parent file'
        file_parent.write_text('retained parent bytes')
        link_parent = self.home / 'linked parent'
        link_parent.symlink_to(self.workspace, target_is_directory=True)
        link_target = self.home / 'linked target'
        link_target.symlink_to(self.workspace, target_is_directory=True)
        dangling_target = self.home / 'dangling target'
        dangling_target.symlink_to(self.home / 'absent linked destination', target_is_directory=True)
        occupied = self.home / 'ordinary occupied target'
        occupied.write_text('retained target bytes')
        links = {path: os.readlink(path) for path in (link_parent, link_target, dangling_target)}
        before = self.snapshot()
        targets = (self.home / 'missing parent' / 'practice', file_parent / 'practice',
                   link_parent / 'practice', link_target, dangling_target, occupied)
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), \
                mock.patch.object(daily.os, 'execve') as execute:
            for target in targets:
                with self.subTest(target=target), self.assertRaises((ValueError, OSError)):
                    daily.launch('cli', ['--workspace', str(target), 'init'], self.paths()['selection'])
            execute.assert_not_called()
        self.assertEqual(self.snapshot(), before)
        self.assertEqual({path: os.readlink(path) for path in links}, links)

    def test_init_token_in_another_command_does_not_bypass_workspace_checks(self):
        self.prepare()
        target = self.home / 'missing practice'
        before = self.snapshot()
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), \
                mock.patch.object(daily.os, 'execve') as execute:
            for mode, arguments in (('cli', ['status', 'init']), ('cli', ['--format', 'init', 'status']),
                                    ('cli', ['report', 'init']), ('gui', ['init'])):
                with self.subTest(mode=mode, arguments=arguments), self.assertRaises((ValueError, OSError)):
                    daily.launch(mode, ['--workspace', str(target), *arguments], self.paths()['selection'])
            with self.assertRaises(ValueError):
                daily.launch('cli', ['--workspace', str(target), '--workspace', str(target), 'init'],
                             self.paths()['selection'])
            execute.assert_not_called()
        self.assertFalse(target.exists())
        self.assertEqual(self.snapshot(), before)

    def test_existing_init_target_is_forwarded_to_product_refusal_without_wrapper_changes(self):
        self.prepare()
        before = self.snapshot()
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), \
                mock.patch.object(daily.os, 'execve') as execute:
            _, command, _ = daily.launch_plan('cli', ['--workspace', str(self.workspace), 'init'],
                                              self.paths()['selection'])
            self.assertEqual(command[4:], ['--workspace', str(self.workspace), 'init'])
            execute.assert_not_called()
        self.assertEqual(self.snapshot(), before)

    def test_preparation_preserves_default_station_and_application_bytes(self):
        station = self.snapshot(self.workspace)
        runtime = self.snapshot(Path(self.profile['runtime']['application']))
        primitive_mkdir = os.mkdir
        attempted = []

        def fixture_mkdir(path, mode=0o777, *, dir_fd=None):
            if dir_fd is None:
                self.assertTrue(Path(path).is_relative_to(self.home))
            else:
                parent = os.fstat(dir_fd)
                allowed = (self.home, *(item for item in self.home.rglob('*') if item.is_dir()))
                self.assertIn((parent.st_dev, parent.st_ino),
                              {(item.stat().st_dev, item.stat().st_ino) for item in allowed})
            attempted.append(path)
            return primitive_mkdir(path, mode, dir_fd=dir_fd)

        with mock.patch.object(daily.os, 'execve', side_effect=AssertionError('unexpected execution')), \
                mock.patch.object(daily.os, 'mkdir', side_effect=fixture_mkdir):
            first = self.prepare()
            before = self.snapshot()
            second = self.prepare()
        self.assertTrue(attempted)
        self.assertEqual(first['selected_version'], daily.VERSIONS['runtime'])
        self.assertEqual(second['selected_version'], daily.VERSIONS['runtime'])
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.snapshot(self.workspace), station)
        self.assertEqual(self.snapshot(Path(self.profile['runtime']['application'])), runtime)
        self.assertFalse(first['workspace_modified'])

    def test_prepare_never_initializes_an_absent_station(self):
        (self.workspace / 'station.json').unlink()
        (self.workspace / '.activity.lock').unlink()
        self.workspace.rmdir()
        self.workspace.parent.rmdir()
        self.prepare()
        self.assertFalse(self.workspace.exists())
        selection = json.loads(self.paths()['selection'].read_bytes())
        self.assertEqual(selection['workspace'], str(self.workspace))

    def test_fresh_account_bootstraps_candidate_without_runtime_or_station(self):
        import shutil

        shutil.rmtree(Path(self.profile['runtime']['application']))
        shutil.rmtree(self.workspace.parent)
        result = daily.prepare(self.home, identities=self.profile, initial_target='jog6')
        self.assertEqual(result['selected_version'], daily.VERSIONS['jog6'])
        self.assertFalse(self.workspace.exists())
        before = self.paths()['selection'].read_bytes()
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile):
            _, command, _ = daily.launch_plan('gui', [], self.paths()['selection'])
        self.assertNotIn('--workspace', command)
        daily.prepare(self.home, identities=self.profile, initial_target='bench')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_bootstrap_missing_candidate_does_not_write_selection_or_launchers(self):
        import shutil

        shutil.rmtree(Path(self.profile['jog6']['application']))
        before = self.snapshot()
        with self.assertRaises((OSError, ValueError)):
            daily.prepare(self.home, identities=self.profile, initial_target='jog6')
        self.assertEqual(self.snapshot(), before)

    def test_bootstrap_explicit_station_uses_product_initializer_and_preserves_existing_choice(self):
        target = self.home / 'new station'
        with mock.patch.object(daily.subprocess, 'run', return_value=mock.Mock(returncode=1)):
            with self.assertRaisesRegex(ValueError, 'initialization failed'):
                daily.prepare(self.home, identities=self.profile, initial_target='jog6', initialize_station=target)
        self.assertFalse(self.paths()['selection'].exists())
        with mock.patch.object(daily.subprocess, 'run', return_value=mock.Mock(returncode=0)) as initialize:
            result = daily.prepare(self.home, identities=self.profile, initial_target='jog6', initialize_station=target)
        self.assertTrue(result['workspace_modified'])
        self.assertEqual(result['workspace'], str(target))
        command = initialize.call_args.args[0]
        self.assertEqual(command[-5:], ['--workspace', str(target), '--format', 'json', 'init'])
        self.assertEqual(command[0], self.profile['jog6']['application'] + '/bin/python')
        before = self.snapshot()
        with mock.patch.object(daily.subprocess, 'run') as initialize:
            with self.assertRaisesRegex(ValueError, 'selection already exists'):
                daily.prepare(self.home, identities=self.profile, initial_target='jog6', initialize_station=self.home / 'other')
            initialize.assert_not_called()
        self.assertEqual(self.snapshot(), before)

    def test_existing_jog_dispatchers_upgrade_without_changing_selection(self):
        for prior, generation, fixture, expected in (
                ('jog3', 'jog-20261118-v3', 'daily-jog3-20261118.py', daily.PREVIOUS_JOG3_SOURCE_SHA256),
                ('jog4', 'profile-install-20261118', 'daily-jog4-20261119.py', daily.PREVIOUS_JOG4_SOURCE_SHA256),
                ('jog5', 'jog-20261119-v2', 'daily-jog5-20261119.py', daily.PREVIOUS_JOG5_SOURCE_SHA256)):
            with self.subTest(previous=prior):
                if prior != 'jog3':
                    self.setUp()
                old = self.home / '.local/share/satgs-launchers' / generation / 'daily.py'
                source = (SOURCE.parents[1] / 'tests/data' / fixture).read_bytes()
                self.assertEqual(hashlib.sha256(source).hexdigest(), expected)
                names = ('runtime', 'ui', 'guide', 'handbook', 'ptu', 'bench', 'jog', 'jog2', 'jog3')
                previous_profile = {name: self.profile[name] for name in names + (('jog4',) if prior in ('jog4', 'jog5') else ()) + (('jog5',) if prior == 'jog5' else ())}
                source = source.replace(b'BOUND_IDENTITIES = None\n', ('BOUND_IDENTITIES = ' + repr(previous_profile) + '\n').encode())
                old.parent.mkdir(parents=True)
                old.write_bytes(source)
                old.chmod(0o600)
                paths = self.paths()
                for name in ('cli', 'gui'):
                    paths[name].parent.mkdir(parents=True, exist_ok=True)
                    paths[name].write_bytes(daily._wrapper(old, paths['selection'], name))
                    paths[name].chmod(0o700)
                paths['selection'].parent.mkdir(parents=True)
                selection = json.dumps(dict(schema=daily.SCHEMA, **self.profile[prior], workspace=str(self.workspace))).encode()
                paths['selection'].write_bytes(selection)
                paths['selection'].chmod(0o600)
                old.write_bytes(source + b'\n# controlled changed dispatcher\n')
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.prepare()
                self.assertEqual(self.snapshot(), before)
                old.write_bytes(source)
                self.prepare()
                self.assertEqual(paths['dispatcher'].parent.name, 'jog-20261124')
                self.assertEqual(paths['selection'].read_bytes(), selection)
                self.assertEqual(old.read_bytes(), source)
                station = self.snapshot(self.workspace)
                self.select('jog6')
                selected = self.invoke('satgs-operator', 'status')
                self.assertEqual(selected.returncode, 0, selected.stderr)
                self.assertEqual(json.loads(selected.stdout)['fixture_profile'], 'jog6')
                self.select(prior)
                self.assertEqual(json.loads(paths['selection'].read_bytes()), json.loads(selection))
                self.assertEqual(self.snapshot(self.workspace), station)
                self.assertEqual(old.read_bytes(), source)

    def test_legacy_upgrade_preserves_selection_and_complete_managed_backup(self):
        old_dispatcher, old_bytes = self.legacy()
        paths = self.paths()
        prior = {key: path.read_bytes() for key, path in paths.items() if key != 'dispatcher'}
        result = self.prepare_legacy(old_bytes)
        backup = Path(result['backup'])
        self.assertEqual(paths['selection'].read_bytes(), prior['selection'])
        self.assertEqual(old_dispatcher.read_bytes(), old_bytes)
        for key, content in prior.items():
            self.assertEqual((backup / key).read_bytes(), content)
            self.assertEqual(stat.S_IMODE((backup / key).stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(backup.stat().st_mode), 0o700)
        self.assertEqual(json.loads((backup / 'mapping.json').read_bytes())['selection']['original'], str(paths['selection']))

    def test_modified_legacy_dispatcher_is_rejected_before_writes(self):
        self.legacy()
        before = self.snapshot()
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(before, self.snapshot())

    def test_unknown_wrapper_menu_or_selection_is_preserved(self):
        for key in ('dispatcher', 'cli', 'gui', 'menu', 'selection'):
            with self.subTest(key=key):
                path = self.paths()[key]
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('unrecognized user file')
                path.chmod(0o700 if key in ('cli', 'gui') else 0o600)
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.prepare()
                self.assertEqual(before, self.snapshot())
                path.unlink()

    def test_managed_file_symlinks_are_rejected_without_touching_targets(self):
        target = self.root / 'retained-user-file'
        target.write_text('retained user bytes')
        for key, path in self.paths().items():
            with self.subTest(key=key):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.symlink_to(target)
                with self.assertRaises(OSError):
                    self.prepare()
                self.assertEqual(target.read_text(), 'retained user bytes')
                self.assertTrue(path.is_symlink())
                path.unlink()

    def test_symlink_selection_parent_and_executable_are_rejected(self):
        outside = self.root / 'outside'
        outside.mkdir()
        (self.home / '.config').symlink_to(outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(list(outside.iterdir()), [])
        (self.home / '.config').unlink()
        application = Path(self.profile['runtime']['application'])
        entry = application / 'bin/python'
        original = entry.read_bytes()
        entry.unlink()
        other = self.root / 'other-python'
        other.write_bytes(original)
        entry.symlink_to(other)
        with self.assertRaises(ValueError):
            self.prepare()

    def test_group_writable_managed_parent_is_rejected_before_changes(self):
        directory = self.home / '.local/bin'
        directory.mkdir(parents=True)
        directory.chmod(0o777)
        before = self.snapshot()
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(before, self.snapshot())

    def test_shared_selection_switch_and_rollback_preserve_daily_data(self):
        self.prepare()
        station = self.snapshot(self.workspace)
        old_selection = self.paths()['selection'].read_bytes()
        selected = self.select('ui')
        self.assertEqual(Path(selected['backup']).joinpath('selection').read_bytes(), old_selection)
        self.assertEqual(json.loads(self.paths()['selection'].read_bytes())['application'], self.profile['ui']['application'])
        self.assertEqual(self.snapshot(self.workspace), station)
        self.select('runtime')
        self.assertEqual(json.loads(self.paths()['selection'].read_bytes())['application'], self.profile['runtime']['application'])
        self.assertEqual(self.snapshot(self.workspace), station)

    def test_uninstalled_or_wrong_version_candidate_cannot_be_selected(self):
        self.prepare()
        before = self.paths()['selection'].read_bytes()
        app = Path(self.profile['ui']['application'])
        metadata = app / 'lib/python3.11/site-packages' / ('satgs-' + daily.VERSIONS['ui'] + '.dist-info/METADATA')
        metadata.write_text('Name: satgs\nVersion: wrong\n')
        with self.assertRaises(ValueError):
            self.select('ui')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)
        metadata.unlink()
        with self.assertRaises(OSError):
            self.select('ui')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_generated_cli_and_gui_share_default_and_bound_fixture_interpreter(self):
        self.prepare()
        generated = self.paths()['dispatcher'].read_text()
        self.assertIn('BOUND_IDENTITIES = ' + repr(daily.registered(self.profile)), generated)
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), mock.patch.object(daily.os, 'execve') as execute:
            interpreter, command, environment = daily.launch_plan('cli', ['status'], self.paths()['selection'])
            execute.assert_not_called()
        self.assertEqual(interpreter, str(Path(self.profile['runtime']['application']) / 'bin/python'))
        self.assertEqual(command[4:], ['--workspace', str(self.workspace), 'status'])
        self.assertEqual(environment['STOMP_SKIP_HOSTNAME_SCAN'], '1')
        for name, arguments in (('satgs-operator', ('status',)), ('satgs-operator-gui', ())):
            with self.subTest(name=name):
                result = self.invoke(name, *arguments)
                self.assertEqual(result.returncode, 0, result.stderr)
                value = json.loads(result.stdout)
                self.assertEqual(value['fixture_profile'], 'runtime')
                self.assertEqual(value['workspace'], str(self.workspace))
                self.assertEqual(value['station_name'], 'Custom station')
                self.assertEqual(value['hostname_scan'], '1')
                self.assertIsNone(value['pythonpath'])
                self.assertIsNone(value['virtualenv'])
        self.select('ui')
        result = self.invoke('satgs-operator', 'status')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['fixture_profile'], 'ui')

    def test_real_generated_help_works_with_missing_workspace_for_both_modes(self):
        self.prepare()
        missing = self.home / 'not-created'
        for name in ('satgs-operator', 'satgs-operator-gui'):
            with self.subTest(name=name):
                result = self.invoke(name, '--workspace', str(missing), '--help')
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn('Controlled launcher fixture', result.stdout)
                self.assertFalse(missing.exists())
        result = self.invoke('satgs-operator', '--workspace', str(missing), 'status', '--help')
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_real_generated_override_is_invocation_only_and_cwd_independent(self):
        self.prepare()
        original = self.paths()['selection'].read_bytes()
        alternate = self.home / 'another station'
        alternate.mkdir()
        (alternate / 'station.json').write_text(json.dumps({'station_name': 'Another station'}))
        for name, arguments in (('satgs-operator', ('--workspace', 'another station', 'status')),
                                ('satgs-operator-gui', ('--workspace=another station',))):
            with self.subTest(name=name):
                result = self.invoke(name, *arguments, cwd=self.home)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout)['workspace'], str(alternate))
        for cwd in (self.root, alternate):
            result = self.invoke('satgs-operator', 'status', cwd=cwd)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)['workspace'], str(self.workspace))
        self.assertEqual(self.paths()['selection'].read_bytes(), original)

    def test_real_generated_missing_or_unsuitable_station_does_not_fall_back(self):
        self.prepare()
        other = self.home / 'unconfigured station'
        other.mkdir()
        result = self.invoke('satgs-operator', '--workspace', str(other), 'status')
        self.assertEqual(result.returncode, 4)
        self.assertEqual(list(other.iterdir()), [])
        result = self.invoke('satgs-operator', '--workspace', str(self.home / 'missing'), 'status')
        self.assertEqual(result.returncode, 1)
        self.assertNotIn(str(self.root), result.stderr)
        self.assertFalse((self.home / 'missing').exists())

    def test_invalid_overrides_and_unknown_selection_never_execute(self):
        self.prepare()
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), mock.patch.object(daily.os, 'execve') as execute:
            for arguments in (['--workspace'], ['--workspace='], ['--workspace', 'one', '--workspace', 'two'], ['unsupported']):
                with self.subTest(arguments=arguments), self.assertRaises((ValueError, OSError)):
                    daily.launch('gui', arguments, self.paths()['selection'])
            execute.assert_not_called()
        value = json.loads(self.paths()['selection'].read_bytes())
        value['application'] = '/unregistered/application'
        self.paths()['selection'].write_text(json.dumps(value))
        with mock.patch.object(daily, 'BOUND_IDENTITIES', self.profile), mock.patch.object(daily.os, 'execve') as execute:
            with self.assertRaises(ValueError):
                daily.launch('cli', ['status'], self.paths()['selection'])
            execute.assert_not_called()

    def test_selection_refuses_partial_or_changed_preparation(self):
        self.prepare()
        old = self.paths()['selection'].read_bytes()
        self.paths()['gui'].write_text('changed user launcher')
        with self.assertRaises(ValueError):
            self.select('ui')
        self.assertEqual(self.paths()['selection'].read_bytes(), old)

    def test_backup_failure_preserves_original_managed_files(self):
        _, old_bytes = self.legacy()
        paths = self.paths()
        before = {key: path.read_bytes() for key, path in paths.items() if key != 'dispatcher'}
        original_new = daily._new

        def fail_mapping(path, data, mode):
            if path.name == 'mapping.json':
                raise OSError('controlled backup failure')
            return original_new(path, data, mode)

        with mock.patch.object(daily, '_new', side_effect=fail_mapping), mock.patch.object(daily, 'LEGACY_SOURCE_SHA256', hashlib.sha256(old_bytes).hexdigest()):
            with self.assertRaises(OSError):
                self.prepare()
        for key, data in before.items():
            self.assertEqual(paths[key].read_bytes(), data)

    def test_interrupted_upgrade_retains_old_choice_and_selection_refuses_partial_wiring(self):
        _, old_bytes = self.legacy()
        before = self.paths()['selection'].read_bytes()
        original_change = daily._change

        def interrupt_cli(path, old, new, mode):
            if path.name == 'satgs-operator':
                raise KeyboardInterrupt
            return original_change(path, old, new, mode)

        with mock.patch.object(daily, '_change', side_effect=interrupt_cli), mock.patch.object(daily, 'LEGACY_SOURCE_SHA256', hashlib.sha256(old_bytes).hexdigest()):
            with self.assertRaises(KeyboardInterrupt):
                self.prepare()
        self.assertEqual(self.paths()['selection'].read_bytes(), before)
        with self.assertRaises(ValueError):
            self.select('ui')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_backup_destination_collision_preserves_originals(self):
        _, old_bytes = self.legacy()
        destination = self.home / '.local/share/satgs-launchers/backups/jog-20261124-collision'
        destination.mkdir(parents=True)
        (destination / 'retained').write_text('existing backup')
        before = self.snapshot()
        with mock.patch.object(daily.secrets, 'token_hex', return_value='collision'), mock.patch.object(daily, 'LEGACY_SOURCE_SHA256', hashlib.sha256(old_bytes).hexdigest()):
            with self.assertRaises(FileExistsError):
                self.prepare()
        self.assertEqual(before, self.snapshot())

    def test_rollback_does_not_require_broken_new_application(self):
        self.prepare()
        self.select('ui')
        Path(self.profile['ui']['application']).joinpath('bin/python').unlink()
        self.select('runtime')
        result = self.invoke('satgs-operator', 'status')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['fixture_profile'], 'runtime')

    def test_source_setup_updates_only_current_shell_path_and_preserves_profiles(self):
        self.prepare()
        script = self.paths()['dispatcher'].parent / 'setup_daily.sh'
        script.write_bytes((SOURCE.parent / 'setup_daily.sh').read_bytes())
        profile = self.home / '.profile'
        profile.write_text('preserved profile\n')
        environment = dict(PATH='/usr/bin:/bin', HOME=str(self.home), LANG='C', LC_ALL='C')
        result = subprocess.run(['/bin/bash', '--noprofile', '--norc', '-c',
                                 'satgs_fixture_script=$1; shift; . "$satgs_fixture_script" && command -v satgs-operator', 'fixture', str(script)],
                                env=environment, cwd=self.root, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('Ready in this terminal', result.stdout)
        self.assertIn(str(self.home / '.local/bin/satgs-operator'), result.stdout)
        self.assertEqual(profile.read_text(), 'preserved profile\n')
        fresh = subprocess.run(['/bin/bash', '--noprofile', '--norc', '-c', 'printf "%s" "$PATH"'],
                               env=environment, capture_output=True, text=True, timeout=15)
        self.assertEqual(fresh.stdout, '/usr/bin:/bin')

    def test_exact_previous_guide_upgrade_retains_choice_and_real_rollback(self):
        dispatcher, source = self.previous_guide()
        before = self.paths()['selection'].read_bytes()
        station = self.snapshot(self.workspace)
        prepared = self.prepare()
        self.assertEqual(prepared['selected_version'], daily.VERSIONS['guide'])
        self.assertEqual(self.paths()['selection'].read_bytes(), before)
        selected = self.select('handbook')
        self.assertEqual(selected['selected_version'], daily.VERSIONS['handbook'])
        self.assertEqual((Path(selected['backup']) / 'selection').read_bytes(), before)
        self.assertEqual(json.loads(self.invoke('satgs-operator', 'status').stdout)['fixture_profile'], 'handbook')
        self.select('guide')
        self.assertEqual(json.loads(self.paths()['selection'].read_bytes()), json.loads(before))
        self.assertEqual(self.snapshot(self.workspace), station)
        self.assertEqual(dispatcher.read_bytes(), source)

    def test_modified_previous_guide_dispatcher_is_preserved_before_writes(self):
        dispatcher, source = self.previous_guide()
        dispatcher.write_bytes(source + b'\n# controlled changed source\n')
        before = self.snapshot()
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(self.snapshot(), before)

    def test_selection_and_rollback_fail_closed_while_station_is_busy(self):
        self.prepare()
        self.select('handbook')
        before = self.paths()['selection'].read_bytes()
        station = self.snapshot(self.workspace)
        with (self.workspace / '.activity.lock').open('r+') as lease:
            fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
            for target in ('guide', 'handbook', 'ptu', 'bench', 'jog', 'jog2', 'jog3', 'jog4', 'jog5', 'jog6'):
                with self.subTest(target=target), self.assertRaisesRegex(ValueError, 'active work'):
                    self.select(target)
            self.assertEqual(self.paths()['selection'].read_bytes(), before)
        self.select('guide')
        self.assertEqual(self.snapshot(self.workspace), station)

    def test_real_station_lease_is_held_through_atomic_selection_write(self):
        self.prepare()
        change = daily._change
        observed = []

        def check_change(path, old, new, mode):
            if path == self.paths()['selection']:
                with (self.workspace / '.activity.lock').open('r+') as lease:
                    with self.assertRaises(BlockingIOError):
                        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
                observed.append(True)
            return change(path, old, new, mode)

        with mock.patch.object(daily, '_change', side_effect=check_change):
            self.select('ptu')
            self.select('handbook')
            self.select('guide')
        self.assertEqual(observed, [True, True, True])

    def test_unmarked_workspace_and_changed_passive_guard_cannot_change_selection(self):
        self.prepare()
        before = self.paths()['selection'].read_bytes()
        station = self.workspace / 'station.json'
        original = station.read_bytes()
        station.write_text('{"station_name": "unmarked fixture"}')
        with self.assertRaisesRegex(ValueError, 'managed station marker'):
            self.select('handbook')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)
        station.write_bytes(original)
        package = Path(self.profile['jog6']['application']) / 'lib/python3.11/site-packages/satgs'
        activity = package / 'operator_activity.py'
        activity.write_bytes(activity.read_bytes() + b'\n# controlled changed source\n')
        with self.assertRaisesRegex(ValueError, 'passive station guard differs'):
            self.select('handbook')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)

    def test_broken_handbook_interpreter_does_not_prevent_guarded_guide_rollback(self):
        self.prepare()
        self.select('handbook')
        Path(self.profile['handbook']['application']).joinpath('bin/python').unlink()
        self.select('guide')
        self.assertEqual(json.loads(self.invoke('satgs-operator', 'status').stdout)['fixture_profile'], 'guide')

    def test_selection_failure_retains_previous_choice_and_releases_station_lease(self):
        self.prepare()
        before = self.paths()['selection'].read_bytes()
        with mock.patch.object(daily, '_backup', side_effect=OSError('controlled backup failure')):
            with self.assertRaises(OSError):
                self.select('handbook')
        self.assertEqual(self.paths()['selection'].read_bytes(), before)
        with (self.workspace / '.activity.lock').open('r+') as lease:
            fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(lease, fcntl.LOCK_UN)

    def test_source_setup_preserves_existing_command_function(self):
        self.prepare()
        script = self.paths()['dispatcher'].parent / 'setup_daily.sh'
        script.write_bytes((SOURCE.parent / 'setup_daily.sh').read_bytes())
        result = subprocess.run(['/bin/bash', '--noprofile', '--norc', '-c',
                                 'satgs-operator() { :; }; satgs_fixture_script=$1; shift; . "$satgs_fixture_script"; code=$?; declare -F satgs-operator; exit "$code"',
                                 'fixture', str(script)], env=dict(PATH='/usr/bin:/bin', HOME=str(self.home)),
                                cwd=self.root, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 1)
        self.assertIn('overrides', result.stderr)
        self.assertIn('satgs-operator', result.stdout)


if __name__ == '__main__':
    unittest.main()
