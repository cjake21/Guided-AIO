# Releases, updates and rollback

A release is an explicit reviewed source checkpoint plus versioned wheels, offline documentation, platform dependency records and acceptance support. A branch name or package version alone does not identify amended component bytes. Publish normal descendant source changes separately from binary download artifacts; never merge artifact-only roots into product history.

The current release descriptor is [release.json](release.json). Release `jog-20261124.1` pairs satgs, ptu_control and serialptu at `0.0.1+jog.20261124.1`. Published November 24, 2026 on `artifacts/releases` at `c874e712d9d88736a7bc027b34d67ab27d98a3cc`. Pi acceptance and physical qualification of jog6 remain pending. Five replacement wheels include the retained Meteor/lower loopback combination for the existing r3 dependency base. Workspace schema remains 1 and no migration is declared.

Jog5 (`jog-20261119.2`) was published November 20, 2026 on `artifacts/releases` at `7b0f9bcffa6a51b2a3a471ed04c74d3cd34e4c9c`. Its supplied Pi software checks passed and Connect returned position, but status `008000` blocked all motion before a JOG packet was sent. Jog6 handles that Up soft limit per direction without overriding the unit's limits.

## Prepare a release

1. Reconcile the current accepted source and provenance on a normal descendant. Keep six owners and legal notices. Review PTU behavior, handbook content and update tooling separately.
2. Use [BUILDING.md](BUILDING.md) from a fresh clone. Build all six wheels with the locked offline tools. Preserve four genuine generated protobuf modules and separate client/manager dependency closures.
3. Package the five replacement pure wheels beside `release.json`, `launchers/` and the existing `support/`. Current source must be present in the maintained checkout. Bundled acceptance references are generated copies of that exact reviewed source, not fallback copies from another workspace.
4. Reuse unchanged, approved platform-specific offline dependencies. Record actual selected wheel filenames, versions and hashes automatically. Do not reuse old local-owner hashes merely because an upstream version is unchanged.
5. Run source, installed, docs/examples, PTU/widget and update-preservation checks through admitted controls. Test an occupied candidate, dirty checkout, absent ref/artifact, busy station, failed staging and real selection rollback in disposable workspaces. Record simulated authentication errors as simulations, not observations of target SSH.
6. Obtain independent source, motion-lifecycle and update-preservation review. Record remaining Pi and physical commissioning requirements separately.
7. Publish only the explicitly authorized normal source candidate and internal download content. Use immutable versioned release tags after review when that exact action is approved. Never retarget an existing tag or infer authority to change the server default or permissions.

The current internal browser/download route remains available for this release and prior rollback artifacts. An organization-managed release/file store with equivalent access controls and retention is preferable for future wheelhouses, but no replacement registry/location is assumed available. Confirm a concrete approved destination and verify callers before migrating. Do not create a new artifact branch for every local test or silently move binaries to LFS/public hosting.

## Checker-only jog6 follow-up

Cole's first jog6 acceptance stopped before any phase because it required the
removed `/home/admin/satgs-jog-20261118-app-manager/bin/python`. Earlier application
directories are optional. The corrected checker retains input checks for historical
files still present and validates the selected current application normally.
See [the follow-up procedure](docs/JOG6_CHECKER_UPDATE_20261124.md). An installed
jog6 needs no setup, dependency download, application replacement or station change.

## Operator-controlled offline update

Obtain and extract the release through the internal browser/download route. Today's Pi has no Git prerequisite. Keep the retained r3 dependency bundle at its existing path. In a Bash terminal, use:

```sh
. ./setup_update.sh --accept-trusted-native
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog6
```

The first command prints the exact release and stages a new application and installer. It reuses retained offline dependencies, runs the existing guarded installer/check/metadata stages and prepares launchers. It never modifies an installed environment, the station or the current daily selection. A failed stage keeps its candidate and automatic report/evidence paths.

The second command records consolidated acceptance. Its explicit selection runs only after successful checks. Selection verifies all managed launcher bytes, application identity and the exact reviewed installed passive station-lease source. It holds the real StationLease across the atomic selection write. An active managed run, PTU session, save or competing selector blocks it. A missing/unmarked/unsafe station cannot establish cooperative idleness and is refused without reset.

The daily station remains `/home/admin/satgs/station`. The new application is
`/home/admin/satgs-jog-20261124-app-manager`, selected by `jog6`. Earlier aliases
remain registered for installations still present, but neither checking nor
selecting jog6 requires them. Cole removed earlier jog directories to reclaim Pi
disk space; a deleted installation cannot be used for rollback. Setup, acceptance
output and station results stay separate. No GUI, manager, service or equipment
connection starts during setup or selection. After selection, open SATGS from the
application menu or run `satgs-operator-gui` in a desktop terminal. Host checks do
not replace Pi acceptance.

For machine-readable intended content and local artifact availability, without staging or selection:

```sh
python3.11 -I -B -S support/release_update.py status
```

The same helper has explicit `stage --accept-trusted-native`, `select` and `rollback --target bench` commands. Older rollback targets remain available. Prefer the two-command operator handoff above so current-shell command lookup is prepared and acceptance is not omitted.

## Rollback and failures

If the compatible bench application is still installed, select it with:

```sh
. ./launchers/setup_daily.sh --select bench
```

This uses the same idle lease and preserves workspace settings/results. Selection backups are retained under `~/.local/share/satgs-launchers/backups/`; earlier dispatchers are not overwritten by the new `jog-20261124` dispatcher. A broken candidate interpreter does not prevent rollback while that candidate's exact passive guard and version metadata remain intact. Missing/tampered guard source fails closed; preserve records and ask the maintainer to restore the exact release, not to bypass the lease or edit the selection JSON.

An occupied application/output is not an update target. Missing artifacts, incompatible platform facts, failed native prerequisites or package checks require investigation with the retained records. Do not repeatedly reinstall, remove failed evidence, disable TLS/SSH verification, copy development environments across architectures or substitute public wheels.

Rollback changes which compatible application is launched next. It is not atomic code/data/service rollback and cannot undo data history or physical effects. This release declares no database/schema migration. A later incompatible migration requires a new reviewed compatibility and rollback plan.

Source synchronization is separate. The read-only `tools/source_status.py` checks an inactive checkout; approved explicit fetch and fast-forward-only synchronization are described in [CONTRIBUTING.md](CONTRIBUTING.md). No pull, cron job or GUI startup activates a release.

## Historical routes and repository administration

Earlier downloads, artifact-only roots and release/rollback anchors remain retained. Consult the delivery's exact ref-to-tip retention/action table before any cleanup. No deletion, tag move, default replacement, protected merge, force push, history rewrite or permission change is part of this routine workflow. Such work needs one exact separately approved mutation list and verified restoration destination.
