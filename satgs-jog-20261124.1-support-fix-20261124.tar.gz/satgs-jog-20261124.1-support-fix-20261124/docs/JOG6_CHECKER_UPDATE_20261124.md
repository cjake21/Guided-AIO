# Check the installed jog6 after removing older releases

Cole's jog6 run returned BLOCKED before any of its 18 phases ran. The checker
required `/home/admin/satgs-jog-20261118-app-manager/bin/python`, even though it
was checking `/home/admin/satgs-jog-20261124-app-manager`. Cole removed previous
jog directories to reclaim disk space. That is the cause of this result.

The follow-up changes acceptance support only. It uses the same jog6 runtime
wheels, application version and `jog6` alias. Missing historical installs no longer
block acceptance. Files still present retain their input checks, and selected
application checks remain required. This does not establish a physical PTU result.

Download `satgs-jog-20261124.1-support-fix-20261124.tar.gz` from the internal
`artifacts/releases` download branch. Extract it into a new directory. Close the
SATGS GUI and CLI sessions, then open a Bash terminal in the extracted directory
on the Pi desktop. The installed jog6 application must still be at
`/home/admin/satgs-jog-20261124-app-manager`.

Run the checks and select jog6 after they pass:

```sh
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog6
satgs-operator-gui
```

Skip `setup_update.sh` for this follow-up when jog6 is already installed. It stages
a new environment and is unnecessary here. No older jog directory needs restoring,
and no dependencies need downloading. Checks print their report and evidence paths
automatically. Keep the first BLOCKED result as history.

The daily station remains `/home/admin/satgs/station`. In the PTU tab, use the saved
local QPT130 connection and Connect. At status `008000`, Up should be unavailable
while Left, Right and Down remain available after fresh stationary feedback. Cole
performs the physical movement test. A software check result alone does not prove
movement. Earlier aliases can only launch or roll back to applications still
installed; this update does not recreate deleted versions.
