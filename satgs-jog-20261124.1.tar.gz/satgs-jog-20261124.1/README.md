# SATGS Modular Suite

The `jog-20261124.1` candidate handles QPT130 device soft limits per direction,
retains bounded local connection establishment and reconciles interrupted
jog/Stop replies. It includes
**Setup > Install software**, CLI `install-software`, fresh-account launcher
`--bootstrap`, and the task-based operator playbook. See the
[installation guide](components/ground_station/docs/installation.md) and
[current project state](docs/PROJECT_STATE.md) for validation and delivery status.

Jog5 was published November 20 after internal Bitbucket access returned.
[Download the retained jog5 update](https://git.codev.mitre.org/users/cjacobson/repos/satgs-modular-suite/browse/satgs-jog-20261119.2.tar.gz?at=7b0f9bcffa6a51b2a3a471ed04c74d3cd34e4c9c).
Source and documentation use the maintained `feature/operator-handbook-ptu`
branch. The supplied jog5 Pi software checks passed and Connect worked, but
status `008000` rejected every jog before a JOG packet was sent. Jog6 corrects
that directional soft-limit handling; its Pi and physical acceptance are pending.
The operator-confirmed jog4 installation remains intact.

SATGS is one modular ground-station product with shared native GUI and CLI operations. This maintained integration checkout contains six separately owned components. It is not a separate Guided Arrow product or a replacement for their upstream repositories.

The current source candidate is `0.0.1+jog.20261124.1`, release `jog-20261124.1`. Ground station, the higher-level PTU owner and serialptu use this paired version. The retained broker route pairs Meteor `2.2.0+bench.20261117.1` with lower STOMP `8.1.0+bench.20261117.1`. Explicit local serial needs neither a broker nor a manager service. Source, host test, Pi test and physical commissioning are separate claims.

Start with the [operator handbook](components/ground_station/docs/operator-guide.md). It covers configuration choices, all canonical components, installation roles, daily operation, location, PTU controls, planning, results, migration and rollback.

The development handbook now includes [TLE-only and PTU-only package recipes](components/ground_station/docs/configurations.md#choose-packages-for-a-specific-job),
[worked TLE maintenance, local PTU and Full M-SEL procedures](components/ground_station/docs/operator-tutorial.md#maintain-a-tle-catalog),
and a [walkthrough of every native tab](components/ground_station/docs/daily-operation.md#walk-through-every-tab).
It gives exact package selections, inputs and commands for each supported task.
Maintainer gaps are recorded separately in [SUITE_GAPS.md](docs/SUITE_GAPS.md).

Installed offline copies are available before workspace initialization:

```sh
satgs-operator docs
satgs-operator docs --text
satgs-operator --read-docs
```

Opening the GUI does not connect to equipment or activate managers. Full M-SEL, Guided Arrow and Custom retain their actual catalog constraints. A PTU-only Custom choice is not a complete Guided Arrow installation. The maintained capability backlog is separate from the operator playbooks.

## Source ownership

| Directory | Distribution | Responsibility |
| --- | --- | --- |
| components/ground_station | satgs | Selection, station configuration, planning and orchestration |
| components/sat_tracker | ptu_control | Higher-level PTU client, manager, tracking and outcomes |
| components/serialptu | serialptu | Low-level protocol encoding and serial driver |
| components/pixhawk | pixhawk | Navigation observation, client and optional manager |
| components/meteor-api | meteor_api | Shared Messenger and message definitions |
| components/stomp.py | stomp.py | Amended lower messaging transport |

Coordinated edits are made in the reviewed integration candidate, then contributed to the owning repositories with Cole and Ian. Do not maintain unmanaged parallel owner copies. Retained notices apply; this repository does not invent a blanket license or external redistribution right. See [contribution guidance](CONTRIBUTING.md), [provenance](PROVENANCE.md) and [NOTICES.md](NOTICES.md).

## Obtain and build source

Internal repository: `ssh://git@git.codev.mitre.org/~cjacobson/satgs-modular-suite.git`.

The PTU update includes the complete maintained source in its versioned archive. The corresponding source, installer and handbook changes are maintained on `feature/operator-handbook-ptu`, separately from binary downloads on `artifacts/releases`. The retained jog5 archive preserves its reviewed November 19 preparation snapshot; its local/on-hold notes are historical. The November 20 publication receipt records that release's source and artifact commits. Jog6 publication is pending. Use an explicit source branch when cloning because the server has not advertised a usable default HEAD. No default or integration branch is changed by this update.

See [BUILDING.md](BUILDING.md) for a fresh clone, pinned offline build tools, all six wheel builds and separate client/manager dependency selections. No build path falls back to another workstation or evidence directory. Genuine generated protobuf modules are retained in source; the compiler is build-only.

```sh
python3.11 -I -B -S tools/check_source.py
```

Only in an actual Git checkout of a separately published source commit:

```sh
python3.11 -I -B -S tools/source_status.py --ref refs/heads/feature/operator-handbook-ptu
```

These are finite source checks, not installed application or hardware qualification. The source-status command is read-only and never fetches. Product acceptance uses the release's consolidated checks and admitted runtime/effect controls.

## Stage the Pi release offline

Today's Pi does not require Git or repository authentication. Obtain the versioned bundle through its retained internal browser/download route. Keep the already downloaded r3 dependency bundle and known-good environments. The update replaces five pure wheels in a new 31-distribution manager environment and reuses unchanged offline dependencies.

From the extracted release directory in a Bash terminal:

```sh
. ./setup_update.sh --accept-trusted-native
./run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select jog6
```

Setup stages `/home/admin/satgs-jog-20261124-app-manager` and prepares launchers without changing the current daily choice. Checks automatically retain reports and evidence. The final explicit selection holds the existing managed-station lease and refuses active work or a PTU session. It does not open the GUI. Open SATGS from the menu or run `satgs-operator-gui` afterward.

The original jog application remains at `/home/admin/satgs-jog-20261118-app-manager` under alias `jog`; `jog2` retains `/home/admin/satgs-jog-20261118-v2-app-manager`. Their failed Pi attempts remain preserved. This layout update passed host checks, but the Pi's font rendering still requires acceptance. The preserved compatible bench application is `/home/admin/satgs-bench-20261118-app-manager`. The daily station stays `/home/admin/satgs/station`. To select that previous compatible application again:

```sh
. ./launchers/setup_daily.sh --select bench
```

Rollback changes application selection, not data history, physical effects or services. Do not delete a failed candidate, overwrite an occupied environment, pull into an installed environment or reset the station to recover. See [release/update guidance](RELEASING.md) and the handbook's [updates chapter](components/ground_station/docs/updates-troubleshooting.md).

For direct QPT130 control, choose **Save local QPT130** once in the existing PTU tab, then Connect. GUI and CLI share the saved connection; no repeated JSON workflow is needed. Hold an arrow to jog and release it to request Stop. Device soft limits remain enabled, but continuous jog does not enforce software endpoint/no-go checks. Numeric Preview/Move retain their checks. The equivalent setup is `satgs-operator bench-configure --transport local-serial`, followed by `satgs-operator bench`; enter `connect`, `jog right 2`, `status`, and `disconnect` under supervision. Follow the [PTU chapter](components/ground_station/docs/ptu-operation.md) for overrides, inherited settings and first-use instructions. Broker mode remains separately selected and operational pointing remains TLS-only. This release does not install ActiveMQ or establish physical readiness.

## Historical material and limits

Root `docs/`, `tools/operator-acceptance/`, `DELIVERY.md`, `component-source-map.json` and retained dependency locks preserve earlier delivery facts. They are not today's installation procedure, active source inventory or current wheel hashes. Current version constraints are in `requirements/runtime-constraints.txt` and `requirements/development-constraints.txt`. Current operator documentation is under `components/ground_station/docs/`; current acceptance support is under `support/`.

No source commit or host result establishes Pi or physical readiness. No live PTU movement, operational broker/service startup, Cube change, database migration or Box upload is enabled by these source tools.
