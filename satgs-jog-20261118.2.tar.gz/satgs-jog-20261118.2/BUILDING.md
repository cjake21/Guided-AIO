# Build and validate the maintained source

Use an inactive source checkout, a separate build environment and a new output directory. Do not build or synchronize inside an installed application or the daily station. Nothing here starts a manager, opens equipment or contacts a broker.

## Fresh checkout

Use the institution-approved SSH identity and host-verification configuration already provisioned on the development host. Never copy its private key to the Pi, disable host/TLS verification or put credentials in a clone URL. Authentication is not established on today's Pi; it uses the offline release route.

The current PTU release supplies its source in the versioned offline archive. Its artifact publication does not update remote source refs. The following clone route applies only to an exact source commit with a separate source-publication receipt, after approval for the specific Git operation:

```sh
export GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0
git -c core.fsmonitor=false -c core.hooksPath=/dev/null clone --single-branch --branch feature/operator-handbook-ptu -- ssh://git@git.codev.mitre.org/~cjacobson/satgs-modular-suite.git SATGS-Modular-Suite
cd SATGS-Modular-Suite
python3.11 -I -B -S tools/source_status.py --ref refs/heads/feature/operator-handbook-ptu
```

The feature ref is an integration candidate, not an immutable release identity. Compare the returned commit to the separately recorded publication checkpoint before using it. If that exact ref or authentication is unavailable, stop. Do not clone an implicit default, another artifact root or a public mirror. Source status rejects a dirty checkout and never fetches, pulls or changes installed software.

## Offline build tools

The selected Python language/runtime is CPython 3.11. Build tooling is pinned in `requirements/build.lock`, with pip separately pinned in `requirements/bootstrap.lock`. Put the approved wheel artifacts listed in `requirements/build-artifacts.json` in a sibling `satgs-build-inputs` directory. These commands do not download them. Missing artifacts must be obtained through the approved internal route; this repository does not invent a wheelhouse service.

From the checkout:

```sh
python3.11 -m venv ../satgs-build-env
../satgs-build-env/bin/python -I -B -m pip --isolated --disable-pip-version-check --no-input install --no-index --find-links ../satgs-build-inputs --require-hashes -r requirements/bootstrap.lock
../satgs-build-env/bin/python -I -B -m pip --isolated --disable-pip-version-check --no-input install --no-index --find-links ../satgs-build-inputs --require-hashes -r requirements/build.lock
python3.11 -I -B -S tools/build_release.py --build-python "$(cd ../satgs-build-env/bin && pwd -P)/python" --output-root "$(cd .. && pwd -P)/satgs-source-build"
```

Both environment and output must be new paths. An occupied output is retained and refused. The helper checks actual build-tool versions against the lock, copies only the six ordinary component source directories, builds all six wheels offline with no build isolation/download, and records commands, exits, wheel identities and source hashes in `build-result.json`. It uses the release manifest's fixed `SOURCE_DATE_EPOCH`, not the wall clock. Source changes during the build fail the attempt. Failed output is preserved for diagnosis.

The four genuine generated protobuf modules are committed build inputs. The owners' build hooks reject missing modules. Protoc 33.6 produced them for protobuf runtime 6.33.6. Regeneration is an explicit maintainer build task, never an application startup dependency. Do not install a protobuf compiler into client or manager runtime environments.

## Dependencies and installation

`requirements/client.in` selects `satgs[pointing,gui]`. It retains the five needed local distributions but does not require serialptu, pyserial or pymavlink. The empty GUI extra does not supply native Tk/Tcl or a display.

`requirements/manager.in` adds the PTU and Pixhawk manager extras. The retained platform manager closure has 31 distributions; the client closure has 26. Serialptu and pymavlink remain manager-only. Plotting, browser dashboard, database and Box capabilities are not silently installed by these selections.

`requirements/runtime-constraints.txt` records the current selected versions without workstation paths. It is a portable version specification, not a platform artifact/hash lock. A release packager must combine the newly built amended owners with the approved platform-specific third-party wheels and generate fresh filename/hash records. Even unchanged upstream version numbers must not substitute unrelated Meteor or stomp bytes. Resolve both sides of the satgs/PTU dependency cycle together.

The older `development-client.lock`, `development-manager.lock` and artifact JSON files are historical development inputs. Their old local-owner hashes and versions are not valid for this release or ARM64. Do not install this release from them. `development-constraints.txt` now records the current selected versions; like runtime constraints, it is not an artifact/hash lock.

Today's supported target installation command is the root [offline update procedure](README.md#stage-the-pi-release-offline), which reuses the retained r3 platform wheels and supplies five reviewed replacement wheels: satgs, PTU, serialptu and the retained Meteor/lower pair. It does not reinstall or modify an existing application environment.

## Checks suitable for available CI

Run the finite source-only check without product imports:

```sh
python3.11 -I -B -S tools/check_source.py
```

It parses Python with the 3.11 grammar, checks owner version pairing and client/manager dependency boundaries, and requires all thirteen canonical handbook source documents. The ground-station wheel build runs the existing offline documentation compiler and packages its finite versioned resources.

Installed origin, protobuf, docs/examples, shared operations, native widgets and launcher/update checks use the existing consolidated acceptance support and its reviewed runtime/effect controls. Do not use blanket test discovery over retained legacy hardware scripts or interpret source parsing as an installed acceptance result. The publisher records the exact checked source, interpreter, commands and outcomes.

No Bitbucket Cloud Pipelines configuration or artifact registry is assumed. These finite commands can be called by an organization-approved runner once that runner's runtime and effect boundary are assigned. Native display coverage must be reported blocked if the admitted display profile is unavailable.
