# Operator-supplied configuration

The example has the existing station schema's field names, not admitted values. Null required fields intentionally fail closed. Supply canonical numeric broker dial IP, a separately verified TLS identity, public CA certificate text, assigned port/credentials and absolute non-root application/log directories. Optional STOMP host is independent of dial/TLS identity. Never place private keys in CA data.

Supply measured latitude/longitude in degrees and altitude in metres, not invented defaults. Assign positive manager IDs and reciprocal positioner/Pixhawk associations matching the separately prepared runtime bindings. A unit label is not a manager ID or power/model identification. The explicit positioner is QPT-130 only.

The template's null no_go_config is an unresolved operator decision, not authorization for an unrestricted run. The existing parser interprets a retained null as explicitly unconfigured, so the operator must confirm that policy or supply the admitted rectangle before use. The strict owner's pointing_context, actual protocol, rotation and device limits also remain unset and fail closed. An actual run must use the approved policy, frame, calibration generations, run identity and TLE digest matching the manager. Do not derive these values from unit labels or invent calibration. Malformed or nonfinite configured policy must not silently become absent.

Deployment configuration, its exact hash-bound runtime bindings and selected local TLE data are separate required inputs. No operational satellite database, credentials, calibration or automatic service setup is supplied. No database or storage settings are invented. Do not connect to any system merely to fill these fields.
