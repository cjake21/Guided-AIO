# Historical development delivery validation

The records below preserve earlier delivery validation, not current candidate
instructions. Use [RELEASING.md](RELEASING.md), [release.json](release.json) and
the separately bound current acceptance/publication records for the handbook
release. Historical revision-3 and October results remain unchanged below.

2026-10-08. This source snapshot was validated separately from the original accepted installations. The platform was Linux x86-64, CPython3.11.16. No Pi or hardware execution occurred.

| Actual delivery check | Result |
| --- | --- |
| Six component builds with the normal setuptools backend | Passed; full source payload, metadata, generated modules, package resource and applicable notices verified |
| Fresh client installation | 26 exact distributions; complete dependency closure, wheel payload and installed RECORD ownership verified |
| Fresh manager installation | 31 exact distributions; complete closure, payload, entry points and 26 standard pymavlink script relocations verified |
| Installed client check | 16 selected modules, canonical package resource, five literal protobuf round trips and unconfigured-example rejection passed |
| Installed manager-package check | 18 selected modules and the same resource/protobuf checks passed; no manager construction |
| Telemetry structural tests | All23 passed, retaining16 original methods and adding7 primary/cleanup regressions |
| Genuine MAVLink parser tests | All4 passed using real generated common v1/v2 modules and the genuine Python CRC fallback |
| Source-only compilation | All94 Python files compiled in memory and passed current-interpreter Python3.11 grammar; this is not another runtime test |

All26 guarded build/install/application invocations completed successfully. Each used fresh recorded inputs, bounded owning-process supervision and active offline effect controls. Deliberately denied probes were recorded separately; no unexpected application or late denial occurred. Pip's inspected optional capability/platform probes remained blocked and its temporary cleanup was checked after exit. Test discovery and real package initialization occurred under the active controls. The source-bound symlink test exercised actual O_NOFOLLOW rejection, not a successful-read substitute.

Source-only reader mistakes and independent scratch-reader corrections were retained in local review evidence. They were not product failures or passing tests. The original528-method acceptance remains attached to its original inputs and is not added to this delivery's test count. No original suite was relabeled as having run on the new installations.

The application check is deliberately limited. It does not cold-start the PTU/Pixhawk managers, open serial, import mavutil, run scientific/native owner integration or establish navigation validity. The four parser tests do not qualify native fastcrc, real telemetry, firmware, sensors or physical outcomes. The approved source-level owner behavior and earlier installed acceptance remain separate evidence.

## Contents and ownership

The snapshot contains the approved120 component source files, four unchanged generated protobuf modules, a delivery-specific ground_station README, five telemetry-tool files with the scoped cleanup correction, and separately identified root documentation, configuration and portable build/runtime inputs. Component Git histories, virtual environments, wheels, raw captures, operational configuration and internal review controls/logs are excluded. Component ancestry and original/derived identities are in provenance.json.

The22 initial exclusions remain excluded. The three held data files and three notebooks remain omitted; the held original ground_station README is replaced. Missing optional Full M-SEL owners, SDKs, service templates and operator data are not silently fetched. The original component notices and ownership remain intact; see NOTICES.md. Internal preparation is not a blanket redistribution grant or first-push approval.

## Reusing the portable inputs

The requirements directory provides exact development artifact identities, not binaries or an ARM64 lock. Use only a separately verified wheelhouse and installer. Present the complete local amended wheel set together, including the ground_station/PTU dependency cycle. Same-version public packages are not substitutes. Keep pip, build tools and protoc outside application environments that do not need them.

For a source rebuild, make byte-verified staging copies of the six components in an owned build area. Use the five pinned tools from requirements/build.lock and the normal backend. The four included generated protobuf modules already match protoc33.6/protobuf6.33.6; runtime generation is unnecessary. Rebuilt wheels require payload, metadata, notice and resource checks before new hashes are admitted. Build metadata must not alter the reviewed source snapshot.

The following are unexecuted portable command forms, not the guarded commands used above and not target authorization. Run from the delivery root only after the interpreter, wheelhouse, effect controls and output locations are admitted. VERIFIED_INSTALLER_PYTHON means a separate verified pip26.2 interpreter; it is not a supplied binary. The checker and unittest are not sandboxes.

```bash
APPROVED_PYTHON -I -B -m venv --without-pip .venv-client
APPROVED_PYTHON -I -B -m venv --without-pip .venv-manager
VERIFIED_INSTALLER_PYTHON -I -B -m pip --isolated --python .venv-client install --no-index --find-links wheelhouse --only-binary=:all: --require-hashes -r requirements/development-client.lock
VERIFIED_INSTALLER_PYTHON -I -B -m pip --isolated --python .venv-manager install --no-index --find-links wheelhouse --only-binary=:all: --require-hashes -r requirements/development-manager.lock
STOMP_SKIP_HOSTNAME_SCAN=1 .venv-client/bin/python -I -B tools/check_installed.py
STOMP_SKIP_HOSTNAME_SCAN=1 .venv-manager/bin/python -I -B tools/check_installed.py --manager
```

The telemetry README defines separately gated bounded raw-file/stdin capture and offline test forms. No live serial command is part of this delivery's executed validation.

## Remaining target decisions

The operator-reported target is guided-arrow-aio-01, aarch64, Python3.11.2. Its existing mavlink-test-venv/pymavlink2.4.50 diagnostic setup must remain separate. This development closure uses pymavlink2.4.49. Target-compatible artifacts, their notices/hashes and Python3.11.2/ARM64 behavior remain unqualified. Do not copy x86-64 binaries or environments to that host.

Navigation timestamp/provenance/validity rules, measured geometry and heading qualification remain unresolved. Matching-ID pong or parsed telemetry is not health evidence. Software completion, command submission, manager outcomes and physical completion remain distinct; local cancellation does not establish remote cancellation or physical stopping. The Pelican power constraint remains QPT130-only, and a unit label does not establish model or manager identity.

Production owner-map/pin activation, publication, deployment, services, Pi execution, firmware changes, database/Box access, RF activity and PTU movement remain outside this delivery. The first push requires approval of the exact local commit and full manifest for the internal Bitbucket branch delivery/installed-baseline-20261008.
# Operator candidate revision 3

`satgs 0.0.1+operator.20261028.3` is independently accepted for the bounded
hardware-free installed development-host scope. CPython3.11.16/Linux x86-64
passed all eight consolidated lanes: 305 distinct unittest methods, including
ten actual native Tk9 widget tests, plus thirteen separately counted CLI
examples. There were no skips, callback errors, unexpected runtime denials or
cleanup errors. Actual local scientific planning used the saved station.

Ground-station checkpoint: `ea4ad6ce9100f1ba0cd482f86994518ae08357ae`.
Pure-wheel SHA-256:
`6c62ef6913a9eae4a1464c115b1f1e24042ca31a7099570189118c07753ef29d`.
The other five component source combinations and their notices are carried
forward unchanged. Current provenance, locks and component-source-map.json
separate the operator candidate from the original baseline.

The accepted telemetry result remains separate and unchanged. No new candidate
installation or GUI execution has occurred on the Pi. Target Tk/Tcl/display,
navigation, timing, heading, owner location reinitialization and physical
commissioning remain unqualified. Native display tests trust the bound
Tk/static-Xlib internals, not syscall or client-transport isolation. Production
owner admission, services and hardware operation remain unavailable.

Use the root README and bundle README for this candidate. The original delivery
record above is historical, not tests or runnable instructions for the new bytes.
