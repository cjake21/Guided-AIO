"""Fixed guarded candidate acceptance child. No service or hardware lane exists."""

import argparse
import ast
from contextlib import redirect_stdout
import hashlib
import io
import json
import os
from pathlib import Path
import site
import sys
import tempfile
import traceback
import types
import unittest

HERE = Path(__file__).resolve().parent
LANES = {
    'presenter': ('test_operator_gui.HeadlessOperatorPresenterTests',),
    'core-cli': ('test_operator_core', 'test_operator_activity', 'test_operator_cli'),
    'planning': ('test_operator_planning',),
    'regression': ('test_station_location', 'test_station_location_cli',
                   'test_runtime_configuration', 'test_pass_runner_capabilities', 'test_deployment_plan'),
    'native-widgets': ('test_operator_gui.NativeOperatorWidgetTests',),
}
EXCLUDED = frozenset((
    'test_actual_module_child_propagates_guard_and_indeterminate_exit',
    'test_actual_module_child_unsupported_owner_exit_is_three',
    'test_actual_module_child_invalid_input_exit_is_two',
))


def load(path, name, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise RuntimeError('support source identity changed')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec', dont_inherit=True), vars(module))
    return module


def tests(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from tests(item)
        else:
            yield item


def cli_examples(scratch):
    from satgs.operator_cli import main
    root = scratch / 'documented-practice'
    examples = []
    def dispatch(arguments, expected=0):
        arguments = ['--workspace', str(root), '--format', 'json', *arguments]
        stream = io.StringIO()
        with redirect_stdout(stream):
            try:
                returned = main(arguments)
            except SystemExit as error:
                returned = error.code
        if returned != expected:
            raise AssertionError('documented CLI dispatch returned an unexpected exit')
        text = stream.getvalue()
        examples.append(dict(arguments=arguments, exit=returned, output=text))
        return json.loads(text) if text.lstrip().startswith('{') else None
    dispatch(['--help'])
    dispatch(['init'])
    dispatch(['status'])
    dispatch(['components-preview', '--profile', 'guided_arrow'])
    coordinates = ['--latitude-deg', '42.0', '--longitude-deg', '-71.0', '--altitude-m', '12.5',
                   '--altitude-reference', 'unspecified']
    pending = dispatch(['location-preview', *coordinates])['result']
    dispatch(['apply', '--preview', pending['preview_id'], '--confirm'])
    dispatch(['reload'])
    dispatch(['plan'])
    pending = dispatch(['location-preview', *coordinates])['result']
    dispatch(['cancel', '--preview', pending['preview_id']])
    dispatch(['report'])
    dispatch(['export', '--output', str(scratch / 'documented-report.json')])
    dispatch(['location-preview', '--latitude-deg', 'nan', '--longitude-deg', '0', '--altitude-m', '0',
              '--altitude-reference', 'unspecified'], expected=2)
    return dict(status='PASS', examples=examples, tests=len(examples), skipped=[], exclusions=[])


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--binding-sha', required=True)
    parser.add_argument('--lane', choices=('static', 'installed', 'cli-examples', *LANES), required=True)
    parser.add_argument('--scratch', type=Path, required=True)
    args = parser.parse_args()
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise RuntimeError('use the fixed isolated no-site child startup')
    if sys.version_info[:3] not in ((3, 11, 16), (3, 11, 2)):
        raise RuntimeError('only reviewed host3.11.16 or retained Pi3.11.2 runtime profiles are supported')
    raw = args.binding.read_bytes()
    if hashlib.sha256(raw).hexdigest() != args.binding_sha:
        raise RuntimeError('candidate binding changed')
    binding = json.loads(raw)
    for name, expected in binding['inputs'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('bound input changed before guarded startup')
    for row in binding['source_installed_mapping'].values():
        if (hashlib.sha256(Path(row['source']).read_bytes()).hexdigest() != row['source_sha256']
                or hashlib.sha256(Path(row['installed']).read_bytes()).hexdigest() != row['installed_sha256']):
            raise RuntimeError('selected G source/installed module mapping changed before first import')
    application = Path(binding['application'])
    if Path(sys.executable) != Path(binding['interpreter']):
        raise RuntimeError('wrong candidate application interpreter')
    expected_path = [str(Path(binding['runtime']) / name) for name in
                     ('lib/python311.zip', 'lib/python3.11', 'lib/python3.11/lib-dynload')]
    if sys.path != expected_path or site.ENABLE_USER_SITE is not None:
        raise RuntimeError('application site initialized before protection')
    inputs = binding['inputs']
    target = load(HERE / 'pi_target.py', 'pi_target', inputs[str(HERE / 'pi_target.py')])
    if binding['startup_tree'] is not None:
        if binding['runtime_profile'] != 'reviewed-pi-cpython3112-exact-startup' or sys.version_info[:3] != (3, 11, 2):
            raise RuntimeError('Pi runtime profile/version mismatch')
        target.target_facts()
        target.require(target.live_startup_policy(binding['startup_tree'], application) is True,
                       'retained Pi startup snapshot changed before guard')
    elif binding['runtime_profile'] != 'reviewed-host-cpython31116-no-startup-hooks' or sys.version_info[:3] != (3, 11, 16):
        raise RuntimeError('host runtime profile/version mismatch')
    if dict(os.environ) != binding['environments'][args.lane]:
        raise RuntimeError('child environment differs from binding')
    package_site = target.startup_policy(application)
    for name in ('pi_guard', 'ctypes_initialization', 'behavior_guard', 'candidate_guard'):
        load(HERE / (name + '.py'), name, inputs[str(HERE / (name + '.py'))])
    graphical = args.lane == 'native-widgets'
    if graphical and (binding['runtime_profile'] != 'reviewed-host-cpython31116-no-startup-hooks'
                      or binding.get('native_display') is None
                      or os.environ.get('DISPLAY') != binding['native_display']['display']):
        raise RuntimeError('native child requires the exact bound owned host display')
    guard_type = sys.modules['candidate_guard'].CandidateGuard
    guard = guard_type(inputs, set(binding['directories']), set(binding['native']),
                       Path(binding['runtime']) / 'lib/python3.11', package_site,
                       args.scratch, binding['public_utc'], binding['runtime_profile'],
                       binding['scipy_rpath_absence'], graphical=graphical)
    tempfile.tempdir = str(args.scratch)
    guard.activate()
    negative_controls = guard.probes()
    startup = target.initialize_site(application, expected_path, [package_site], startup_tree=binding['startup_tree'])
    sys.path.insert(0, binding['tests'])
    outcome = None
    try:
        if args.lane not in ('static', 'installed'):
            __import__('satgs.operator_core')
            guard.bind_readers()
        if args.lane == 'static':
            sources = sorted(Path(binding['source']).rglob('*.py'))
            for path in sources:
                payload = path.read_bytes()
                compile(payload, str(path), 'exec', dont_inherit=True)
                ast.parse(payload, filename=str(path), feature_version=(3, 11))
            outcome = dict(status='PASS', scope='source-only-current-runtime-compile-and-Python3.11-grammar',
                           files=len(sources), executed_product_source=False)
        elif args.lane == 'installed':
            checker = load(HERE / 'installed_check.py', 'candidate_installed_check',
                           inputs[str(HERE / 'installed_check.py')])
            outcome = checker.check(binding)
        elif args.lane == 'cli-examples':
            outcome = cli_examples(args.scratch)
        else:
            selected, excluded = [], []
            for name in LANES[args.lane]:
                for case in tests(unittest.defaultTestLoader.loadTestsFromName(name)):
                    if args.lane == 'regression' and case.id().rsplit('.', 1)[-1] in EXCLUDED:
                        excluded.append(case.id())
                    else:
                        selected.append(case)
            if not selected:
                raise RuntimeError('required lane discovered no tests')
            if graphical and len(selected) != 10:
                raise RuntimeError('required native lane must discover all ten actual widget tests')
            result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
            outcome = dict(status='FAIL' if not result.wasSuccessful() else 'BLOCKED' if result.skipped else 'PASS',
                           tests=result.testsRun, test_ids=[case.id() for case in selected],
                           failures=len(result.failures), errors=len(result.errors),
                           skipped=[dict(test=case.id(), reason=reason) for case, reason in result.skipped],
                           exclusions=excluded)
        if args.lane == 'presenter' and 'tkinter' in sys.modules:
            raise RuntimeError('headless presenter imported Tk')
        if args.lane == 'planning' and len(guard.ctypes_init.observations) != 1:
            raise RuntimeError('scientific lane did not exercise admitted real native initialization')
        outcome.update(native_test_lane_executed=graphical and outcome.get('tests', 0) > 0,
                       native_test_methods_attempted=outcome.get('tests', 0) if graphical else 0)
        receipts = guard.finish_candidate()
        outcome.update(lane=args.lane, site=startup, negative_controls=negative_controls,
                       controls=receipts, runtime_denials=[], native_widgets_passed=graphical and outcome['status'] == 'PASS')
    except BaseException as error:
        traceback.print_exc()
        outcome = dict(outcome or {}, status='FAIL', lane=args.lane, runner_error=type(error).__name__,
                       runtime_denials=[row for row in guard.denials if row['phase'] != 'negative'],
                       denial_diagnostics=guard.effect_diagnostics,
                       native_widgets_passed=False,
                       guard_overflow=guard.overflow)
    print('OPERATOR_LANE_RESULT ' + json.dumps(outcome, sort_keys=True, allow_nan=False), flush=True)
    return 0 if outcome['status'] == 'PASS' else 78 if outcome['status'] == 'BLOCKED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
