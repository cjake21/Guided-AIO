"""Scratch-only operator additions to the retained effect and native-init guards."""

import hashlib
from contextlib import redirect_stdout
import errno
import importlib.metadata as metadata
import importlib._bootstrap_external as external
import json
import fcntl
import os
from pathlib import Path
import stat
import sys
import types
import zipfile

from pi_guard import CheckGuard, require
from behavior_guard import ActiveModules, BehaviorGuard
from ctypes_initialization import CtypesInitialization


class CandidateGuard(CheckGuard):
    MODE = 'offline-pixhawk'
    bind_exec = BehaviorGuard.bind_exec

    def __init__(self, files, directories, native, stdlib, package_site, scratch, public_utc,
                 runtime_profile, scipy_rpath_absence, graphical=False):
        super().__init__(files, directories, native)
        self.bound_hashes = dict(files)
        self.stdlib, self.site, self.scratch = Path(stdlib), Path(package_site), Path(scratch)
        self.graphical = graphical
        self.public_utc = public_utc
        self.verify_utc()
        self.scipy_rpath_absence = scipy_rpath_absence
        self.verify_science_absence()
        profiles = {
            'reviewed-host-cpython31116-no-startup-hooks': 'a31058a86719567745b80200dcc40218663e7516026a79ac0911d97c67574f71',
            'reviewed-pi-cpython3112-exact-startup': '608671c6b49e5e027e3348fcf492718c33f69f919d99f4ff170522c40bd4c550',
        }
        require(runtime_profile in profiles, 'unreviewed runtime/native initialization profile')
        self.ctypes_sha = profiles[runtime_profile]
        self.selected = {
            str(self.stdlib / 'ctypes/__init__.py'): self.ctypes_sha,
            str(self.site / 'numpy/_core/_internal.py'): '07cb7a9b1bda0e8bb113e08e474d74bf8fcf507373385f261e015ab513e52569',
        }
        self.METADATA = ActiveModules()
        self.ctypes_init = CtypesInitialization(self)
        self.sources, self.expected = {}, {}
        for path, expected in self.selected.items():
            raw = Path(path).read_bytes()
            require(hashlib.sha256(raw).hexdigest() == expected, 'native initialization source drift')
            self.sources[path] = raw
            self.expected[path] = compile(raw, path, 'exec', dont_inherit=True)
        self.loader_exec = external._LoaderBasics.exec_module
        self.loader_exec_code = self.loader_exec.__code__
        self.loader_type = external.SourceFileLoader
        self.home_offsets = None
        self.real_flock = fcntl.flock
        self.allowance_negatives = []
        self.diagnostic_stream = sys.stderr
        self.effect_diagnostics = []
        self.readers = []
        self.secure_input = str(self.site / 'satgs/data/operator_tle.csv')
        require(self.secure_input in files, 'packaged TLE must be bound')
        self.secure_identity = self.file_identity(self.real_lstat(self.secure_input))
        self.secure_chain = self.directory_identity(str(Path(self.secure_input).parent))
        require(self.secure_chain is not None, 'ordinary packaged TLE ancestors required')
        self.metadata_zip = str(self.stdlib.parent / 'python311.zip')
        self.metadata_chain = self.directory_identity(str(Path(self.metadata_zip).parent))
        require(self.metadata_chain is not None, 'ordinary metadata zip parent required')
        self.metadata_functions = (metadata.FastPath.children, metadata.FastPath.zip_children,
                                   zipfile.ZipFile.__init__, zipfile.CompleteDirs.make.__func__,
                                   zipfile.Path.__init__)
        self.metadata_codes = tuple(item.__code__ for item in self.metadata_functions)
        self.metadata_counts = {'os.listdir': 0, 'open': 0}
        self.metadata_negatives = []
        self.metadata_pending = None
        require(self.metadata_missing(), 'reviewed metadata zip must genuinely be absent')

    def verify_utc(self):
        for row in self.public_utc['identities']:
            path = Path(row['path'])
            info = path.lstat()
            actual = dict(path=str(path), device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
                          uid=info.st_uid, gid=info.st_gid, bytes=info.st_size,
                          mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns,
                          link=os.readlink(path) if stat.S_ISLNK(info.st_mode) else None)
            require(actual == row, 'public UTC input identity changed')
        raw = Path(self.public_utc['resolved']).read_bytes()
        require(len(raw) == 114 and hashlib.sha256(raw).hexdigest() == self.public_utc['sha256'],
                'public UTC input changed')

    def verify_science_absence(self):
        if self.scipy_rpath_absence is None:
            return
        require(self.scipy_rpath_absence['path'] ==
                '/opt/_internal/cpython-3.11.10/lib/python3.11/site-packages/scipy_openblas32/lib',
                'unreviewed scientific native RPATH')
        for row in self.scipy_rpath_absence['ancestors']:
            try:
                info = self.real_lstat(row['path'])
            except FileNotFoundError:
                require(row['identity'] is None, 'scientific native RPATH ancestor disappeared')
            else:
                require([info.st_dev, info.st_ino, info.st_mode] == row['identity']
                        and stat.S_ISDIR(info.st_mode), 'scientific native RPATH ancestor changed')
        require(not os.path.lexists(self.scipy_rpath_absence['path']), 'scientific native RPATH appeared')

    def deny(self, event):
        if self.phase != 'negative' and len(self.effect_diagnostics) < 16:
            frame = sys._getframe(1)
            frames, arguments = [], None
            for unused in range(24):
                if frame is None:
                    break
                filename = frame.f_code.co_filename
                bound = filename in self.bound_hashes
                frames.append(dict(source=filename if bound else 'sha256:' + hashlib.sha256(filename.encode()).hexdigest(),
                                   sha256=self.bound_hashes.get(filename), function=frame.f_code.co_name if bound else None,
                                   line=frame.f_lineno, offset=frame.f_lasti))
                if (frame.f_code is CandidateGuard.audit.__code__ and frame.f_globals is globals()
                        and frame.f_locals.get('self') is self):
                    arguments = frame.f_locals.get('args')
                frame = frame.f_back
            row = dict(event=event, frames=frames)
            if arguments and isinstance(arguments[0], (str, bytes)):
                raw = os.fsdecode(arguments[0])
                path = os.path.abspath(raw)
                public = path in ('/etc/localtime', '/etc/timezone') or path.startswith(('/usr/share/zoneinfo/', '/usr/share/locale/'))
                controlled = path in self.bound_hashes or path == str(self.scratch) or path.startswith(str(self.scratch) + '/')
                row['path'] = path if public or controlled else 'sha256:' + hashlib.sha256(os.fsencode(raw)).hexdigest()
                row['path_bytes'] = len(os.fsencode(raw))
                if event == 'open' and len(arguments) == 3:
                    row.update(mode=arguments[1], flags=arguments[2])
            self.effect_diagnostics.append(row)
            print('OPERATOR_DENIAL_DIAGNOSTIC ' + json.dumps(row, sort_keys=True), file=self.diagnostic_stream, flush=True)
        with redirect_stdout(self.diagnostic_stream):
            return super().deny(event)

    def bind_readers(self):
        require(not self.readers, 'reader binding replay')
        for name, attribute in (
                ('satgs.deployment_cli', 'read_regular_bytes'),
                ('satgs.station_location_cli', '_write_new_artifact'),
                ('satgs.operator_activity', 'open_workspace'),
                ('satgs.operator_core', '_write_new'),
                ('satgs.operator_core', 'initialize_workspace')):
            owner = sys.modules.get(name)
            function = getattr(owner, attribute, None)
            origin = str(self.site / (name.replace('.', '/') + '.py'))
            require(type(owner) is types.ModuleType and type(function) is types.FunctionType
                    and function.__globals__ is vars(owner) and function.__code__.co_filename == origin
                    and vars(owner).get('__file__') == origin and origin in self.files
                    and type(vars(owner).get('__loader__')) is self.loader_type,
                    'genuine installed reader required before test patching')
            self.readers.append((owner, function, function.__code__, attribute))

    def metadata_missing(self):
        if self.directory_identity(str(Path(self.metadata_zip).parent)) != self.metadata_chain:
            return False
        try:
            self.real_lstat(self.metadata_zip)
        except FileNotFoundError as error:
            return error.errno == errno.ENOENT and error.filename == self.metadata_zip
        except OSError:
            pass
        return False

    def metadata_identity(self, frame, index):
        function = self.metadata_functions[index]
        return (frame is not None and frame.f_code is self.metadata_codes[index]
                and frame.f_globals is function.__globals__ and function.__code__ is self.metadata_codes[index])

    def metadata_eligible(self, event, args, caller):
        current = (metadata.FastPath.children, metadata.FastPath.zip_children,
                   zipfile.ZipFile.__init__, zipfile.CompleteDirs.make.__func__, zipfile.Path.__init__)
        if (current != self.metadata_functions or args[0] != self.metadata_zip
                or sum(self.metadata_counts.values()) >= 4096 or not self.metadata_missing()):
            return False
        if event == 'os.listdir':
            frame = caller
        elif event == 'open':
            if args[1:] != ('r', os.O_CLOEXEC) or self.metadata_pending is None:
                return False
            frame = caller
            for index in (2, 3, 4, 1):
                if not self.metadata_identity(frame, index):
                    return False
                if index == 2 and (frame.f_locals.get('file') != self.metadata_zip
                                   or frame.f_locals.get('mode') != 'r'
                                   or frame.f_locals.get('filemode') != 'rb'):
                    return False
                frame = frame.f_back
        else:
            return False
        if not self.metadata_identity(frame, 0):
            return False
        instance = frame.f_locals.get('self')
        return (type(instance) is metadata.FastPath and instance.root == self.metadata_zip
                and (event != 'open' or instance is self.metadata_pending))

    def metadata_absence(self, event, args, caller):
        if not self.metadata_eligible(event, args, caller):
            return False
        changed = lambda **values: types.SimpleNamespace(**dict(
            {name: getattr(caller, name) for name in ('f_code', 'f_globals', 'f_locals', 'f_back')}, **values))
        for label, frame in (('copied-code', changed(f_code=caller.f_code.replace())),
                             ('copied-namespace', changed(f_globals=dict(caller.f_globals))),
                             ('wrong-caller', None)):
            require(not self.metadata_eligible(event, args, frame), 'metadata absence negative failed')
            if event + ':' + label not in self.metadata_negatives:
                self.metadata_negatives.append(event + ':' + label)
        require(not self.metadata_eligible(event, ('/__satgs_guard_outside__', *args[1:]), caller),
                'metadata outside path admitted')
        chain = self.metadata_chain
        try:
            self.metadata_chain = None
            require(not self.metadata_eligible(event, args, caller), 'metadata stale ancestor admitted')
        finally:
            self.metadata_chain = chain
        count = self.metadata_counts[event]
        try:
            self.metadata_counts[event] = 4096
            require(not self.metadata_eligible(event, args, caller), 'metadata absence budget bypassed')
        finally:
            self.metadata_counts[event] = count
        if event == 'open':
            require(not self.metadata_eligible(event, (args[0], 'w', os.O_WRONLY), caller),
                    'metadata write admitted')
            self.metadata_pending = None
            require(not self.metadata_eligible(event, args, caller), 'metadata open replay admitted')
        else:
            self.metadata_pending = caller.f_locals['self']
        self.metadata_counts[event] += 1
        for label in ('outside-path', 'stale-ancestor', 'budget', *(('wrong-flags', 'replay') if event == 'open' else ())):
            if event + ':' + label not in self.metadata_negatives:
                self.metadata_negatives.append(event + ':' + label)
        raise FileNotFoundError(errno.ENOENT, 'bound metadata zip absent without access', self.metadata_zip)

    def output_path(self, value, directory_fd=None):
        path = Path(self.path(value, directory_fd))
        return path == self.scratch or self.scratch in path.parents

    def reader_target(self, path, flags, directory_fd=None):
        allowed = (os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                   os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        return flags in allowed and Path(self.path(path, directory_fd)) in self.scratch.parents

    def reader_identity(self, frame):
        for owner, function, code, unused in self.readers:
            if (type(function) is types.FunctionType and sys.modules.get(owner.__name__) is owner
                    and function.__code__ is code and frame.f_code is code and frame.f_globals is vars(owner)):
                return True
        return False

    def secure_reader_target(self, args, directory_fd, frame):
        if (not self.reader_identity(frame) or frame.f_code.co_name != 'read_regular_bytes'
                or type(frame.f_locals.get('path')) is not str
                or os.path.abspath(frame.f_locals['path']) != self.secure_input
                or args[2] != os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
                or Path(self.path(args[0], directory_fd)) not in Path(self.secure_input).parents):
            return False
        return (self.directory_identity(str(Path(self.secure_input).parent)) == self.secure_chain
                and self.file_identity(self.real_lstat(self.secure_input)) == self.secure_identity)

    def reader_walk(self, args, directory_fd):
        frame = sys._getframe(1)
        for unused in range(8):
            if frame is None:
                break
            if self.reader_identity(frame) and (self.reader_target(args[0], args[2], directory_fd)
                                                or self.secure_reader_target(args, directory_fd, frame)):
                require(not self.reader_identity(types.SimpleNamespace(f_code=frame.f_code.replace(), f_globals=frame.f_globals)),
                        'reader copied-code caller admitted')
                require(not self.reader_identity(types.SimpleNamespace(f_code=frame.f_code, f_globals=dict(frame.f_globals))),
                        'reader copied-namespace caller admitted')
                if self.secure_reader_target(args, directory_fd, frame):
                    require(not self.secure_reader_target((args[0], args[1], os.O_RDWR), directory_fd, frame),
                            'secure input writing walk admitted')
                    require(not self.secure_reader_target(('/__satgs_guard_outside__', *args[1:]), None, frame),
                            'secure input outside walk admitted')
                    changed = types.SimpleNamespace(f_code=frame.f_code, f_globals=frame.f_globals,
                                                    f_locals=dict(frame.f_locals, path='/__satgs_guard_outside__'))
                    require(not self.secure_reader_target(args, directory_fd, changed), 'secure input provenance lost')
                    identity = self.secure_identity
                    try:
                        self.secure_identity = ()
                        require(not self.secure_reader_target(args, directory_fd, frame), 'secure input stale identity admitted')
                    finally:
                        self.secure_identity = identity
                    for label in ('secure-input-wrong-flags', 'secure-input-outside-path',
                                  'secure-input-provenance', 'secure-input-stale-identity'):
                        if label not in self.allowance_negatives:
                            self.allowance_negatives.append(label)
                return True
            frame = frame.f_back
        return False

    def audit(self, event, args):
        if event == 'import' and len(args) > 1 and args[1] is not None and str(args[1]).endswith('.so'):
            self.verify_science_absence()
        if event in ('os.listdir', 'open'):
            self.metadata_absence(event, args, sys._getframe(1))
        caller = sys._getframe(1) if event in ('exec', 'ctypes.dlopen') else None
        if event == 'exec':
            self.bind_exec(args[0], caller)
        if event == 'ctypes.dlopen' and self.ctypes_init.permit(event, args, caller):
            return
        if event == 'import' and not self.graphical and str(args[0]).split('.')[0] in ('tkinter', '_tkinter'):
            self.deny('headless-tk-import')
        if event == 'open':
            pending = getattr(self.context, 'opening', None)
            directory_fd = pending[1] if pending and pending[0] == args[0] else None
            if self.output_path(args[0], directory_fd) or self.reader_walk(args, directory_fd):
                return
        if event in ('os.listdir', 'os.scandir') and self.output_path(args[0]):
            return
        if event in ('os.remove', 'os.rmdir') and self.output_path(args[0], args[1]):
            return
        if event in ('os.mkdir', 'os.chmod') and self.output_path(args[0], args[2]):
            return
        if event == 'os.utime' and self.output_path(args[0], args[3]):
            return
        if event in ('os.rename', 'os.link') and all(self.output_path(args[i], args[i + 2]) for i in (0, 1)):
            return
        if event == 'os.symlink' and self.output_path(args[0]) and self.output_path(args[1], args[2]):
            return
        return super().audit(event, args)

    def absent_import_cache(self, path, frame):
        if (frame is not None and frame.f_code is CandidateGuard.audit.__code__
                and frame.f_globals is globals() and frame.f_locals.get('self') is self):
            frame = frame.f_back
        return super().absent_import_cache(path, frame)

    def flock_target(self, descriptor, operation):
        return (type(descriptor) is int and operation in (fcntl.LOCK_EX | fcntl.LOCK_NB, fcntl.LOCK_UN)
                and self.output_path(descriptor) and Path(self.path(descriptor)).name == '.activity.lock')

    def flock_identity(self, caller, operation):
        owner = sys.modules.get('satgs.operator_activity')
        lease = getattr(owner, 'StationLease', None)
        attribute = {fcntl.LOCK_EX | fcntl.LOCK_NB: 'acquire', fcntl.LOCK_UN: 'release'}.get(operation)
        function = getattr(lease, attribute, None) if attribute else None
        return type(function) is types.FunctionType and caller.f_code is function.__code__ and caller.f_globals is vars(owner)

    def station_flock(self, descriptor, operation):
        caller = sys._getframe(1)
        if self.flock_target(descriptor, operation) and self.flock_identity(caller, operation):
            require(not self.flock_identity(types.SimpleNamespace(f_code=caller.f_code.replace(), f_globals=caller.f_globals), operation),
                    'flock copied-code caller admitted')
            require(not self.flock_identity(types.SimpleNamespace(f_code=caller.f_code, f_globals=dict(caller.f_globals)), operation),
                    'flock copied-namespace caller admitted')
            return self.real_flock(descriptor, operation)
        self.deny('api.fcntl.flock')

    def probes(self):
        count = super().probes()
        self.phase = 'negative'
        flags = os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        ancestor = str(self.scratch.parent)
        require(self.reader_target(ancestor, flags), 'reader positive target classifier failed')
        require(not self.reader_target(ancestor, os.O_RDWR), 'reader writing flags admitted')
        require(not self.reader_target('/__satgs_guard_outside__', flags), 'reader outside ancestor admitted')
        require(not self.reader_walk((ancestor, 'r', flags), None), 'reader wrong caller admitted')
        self.allowance_negatives.extend(('reader-wrong-flags', 'reader-outside-path', 'reader-wrong-caller'))
        path = self.scratch / '.activity.lock'
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_RDWR | os.O_CLOEXEC, 0o600)
        outside = os.open(__file__, os.O_RDONLY | os.O_CLOEXEC)
        try:
            operation = fcntl.LOCK_EX | fcntl.LOCK_NB
            require(self.flock_target(descriptor, operation), 'flock positive target classifier failed')
            require(not self.flock_target(descriptor, 0), 'flock wrong flags admitted')
            require(not self.flock_target(outside, operation), 'flock outside scratch admitted')
            try:
                fcntl.flock(descriptor, operation)
            except PermissionError:
                count += 1
            else:
                raise RuntimeError('flock wrong caller admitted')
            self.allowance_negatives.extend(('flock-wrong-flags', 'flock-outside-path', 'flock-wrong-caller'))
        finally:
            os.close(outside)
            os.close(descriptor)
            os.unlink(path)
        self.phase = 'runtime'
        return count

    def activate(self):
        super().activate()
        fcntl.flock = self.station_flock
        os.supports_dir_fd = os.supports_dir_fd | {os.open}

    def finish_candidate(self):
        self.verify_science_absence()
        self.verify_utc()
        self.finish()
        require(not any(self.METADATA.exact_binding(self.METADATA.active_modules, row[0]) is not None
                        for row in self.METADATA.namespaces.values()), 'unfinished native initialization')
        return dict(cache_absence=self.cache_receipts(),
                    ctypes_initialization=self.ctypes_init.observations,
                    ctypes_classifier_negatives=self.ctypes_init.negative_controls,
                    new_allowance_negatives=self.allowance_negatives,
                    metadata_zip_absence=dict(path=self.metadata_zip, policy='ENOENT before list/open access',
                                              counts=self.metadata_counts, negatives=self.metadata_negatives,
                                              limit=4096),
                    native_trust='bound CPython/scientific/Tk internals, not syscall isolation')
