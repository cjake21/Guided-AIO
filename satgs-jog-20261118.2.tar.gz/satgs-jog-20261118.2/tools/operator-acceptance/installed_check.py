"""Version-aware variant of the retained installed origin/resource/protobuf checks."""

import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys


def check(binding):
    site = Path(binding['application']) / 'lib/python3.11/site-packages'
    for row in binding['source_installed_mapping'].values():
        if (hashlib.sha256(Path(row['source']).read_bytes()).hexdigest() != row['source_sha256']
                or hashlib.sha256(Path(row['installed']).read_bytes()).hexdigest() != row['installed_sha256']):
            raise RuntimeError('source-to-installed G module mapping mismatch')
    if sys.prefix == sys.base_prefix or os.environ.get('STOMP_SKIP_HOSTNAME_SCAN') != '1':
        raise RuntimeError('isolated candidate application environment required')
    canonical = lambda value: value.lower().replace('_', '-').replace('.', '-')
    rows = list(importlib.metadata.distributions(path=[str(site)]))
    actual = {canonical(row.metadata['Name']): row for row in rows}
    expected = binding['expected_distributions']
    if len(actual) != len(rows) or set(actual) != set(expected):
        raise RuntimeError('installed distribution set mismatch')
    if any(row.version != expected[name] or Path(row.locate_file('')).resolve() != site
           for name, row in actual.items()):
        raise RuntimeError('installed version or distribution origin mismatch')
    names = (
        'satgs', 'satgs._package_layout', 'satgs.deployment', 'satgs.runtime_configuration',
        'meteor_api', 'meteor_api.messenger', 'stomp', 'ptu_control', 'ptu_control.pointing',
        'ptu_control.tracking', 'pixhawk', 'satgs.jobs_msg_pb2',
        'meteor_api.protobufs.Meteor_pb2', 'ptu_control.ptu_msg_pb2', 'pixhawk.pixhawk_pb2',
        'google.protobuf.timestamp_pb2', 'satgs.operator_core', 'satgs.operator_activity',
        'satgs.operator_cli', 'satgs.operator_gui',
    )
    modules, origins = {}, {}
    for name in names:
        module = importlib.import_module(name)
        path = Path(module.__file__).resolve()
        if site not in path.parents or not path.is_file():
            raise RuntimeError('module escaped candidate installation')
        modules[name] = module
        origins[name] = dict(relative_path=str(path.relative_to(site)),
                             sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    if modules['satgs._package_layout'].INSTALLED is not True:
        raise RuntimeError('source layout imported instead of installed layout')
    resource = site / 'satgs/data/deployment_profiles.json'
    if (modules['satgs.deployment'].DEFAULT_MANIFEST_PATH != resource
            or hashlib.sha256(resource.read_bytes()).hexdigest() != binding['resource_sha256']):
        raise RuntimeError('canonical installed manifest mismatch')
    modules['satgs.deployment'].load_manifest()
    tle = site / 'satgs/data/operator_tle.csv'
    if hashlib.sha256(tle.read_bytes()).hexdigest() != binding['tle_sha256']:
        raise RuntimeError('operator replay resource mismatch')
    cases = (
        (modules['satgs.jobs_msg_pb2'].JobRequest, {'sat_id': 1}, '0801'),
        (modules['meteor_api.protobufs.Meteor_pb2'].PdapParamsMsg, {'min_pulse_size': 1}, '1801'),
        (modules['ptu_control.ptu_msg_pb2'].PingCmd, {'ping': True}, '0801'),
        (modules['pixhawk.pixhawk_pb2'].PingCmd, {'ping': True}, '0801'),
        (modules['google.protobuf.timestamp_pb2'].Timestamp, {'seconds': 1}, '0801'),
    )
    for message_type, fields, encoded in cases:
        message = message_type(**fields)
        if message.SerializeToString().hex() != encoded:
            raise RuntimeError('protobuf literal wire mismatch')
        parsed = message_type()
        parsed.ParseFromString(bytes.fromhex(encoded))
        if any(getattr(parsed, key) != value for key, value in fields.items()):
            raise RuntimeError('protobuf parse mismatch')
    configuration = modules['satgs.runtime_configuration']
    example = json.loads(Path(binding['example']).read_bytes())
    try:
        configuration._station_settings(example, None, None)
    except configuration.RuntimeConfigurationError:
        pass
    else:
        raise RuntimeError('unconfigured example admitted')
    entries = {row.name: row for row in actual['satgs'].entry_points if row.group == 'console_scripts'}
    for name, value in {'satgs-operator': 'satgs.operator_cli:main',
                        'satgs-operator-gui': 'satgs.operator_gui:main'}.items():
        if name not in entries or entries[name].value != value or not callable(entries[name].load()):
            raise RuntimeError('operator console entry mismatch')
    if 'tkinter' in sys.modules or 'satgs.pass_runner' in sys.modules:
        raise RuntimeError('installed interface import loaded Tk or runner')
    return dict(status='PASS', scope='candidate-installed-origins-resources-entrypoints-protobuf',
                distributions=len(actual), origins=origins, protobuf_cases=len(cases),
                candidate_version=actual['satgs'].version, owner_constructed=False,
                hardware_qualified=False, navigation_qualified=False)
