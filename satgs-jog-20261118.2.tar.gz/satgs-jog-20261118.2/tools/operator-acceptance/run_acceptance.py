"""One fixed offline candidate acceptance attempt, reusing admitted supervision/finalization."""

import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import stat
import sys
import tarfile
import tempfile
import time
import tomllib
import types

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LANES = ('static', 'installed', 'presenter', 'core-cli', 'planning', 'regression', 'cli-examples', 'native-widgets')
PINNED = {
    'pi_target.py': 'dd905f46e6b5a1b5a0e5a7f7aadc28272fc0910e465fe6dd4f57c4391edae80b',
    'pi_guard.py': '7283e3f9db6f3a38e3e0208f86b60723c39e1a28969eab518e4c8044319cc4ab',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path, name, expected=None):
    raw = path.read_bytes()
    if expected is not None and hashlib.sha256(raw).hexdigest() != expected:
        raise RuntimeError('retained support identity mismatch')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec', dont_inherit=True), vars(module))
    return module


def inventory(roots, stdlib=None):
    files, directories, native = {}, set(), set()
    for root in roots:
        if not root.is_dir():
            raise FileNotFoundError('required candidate input directory unavailable: ' + str(root))
        directories.add(str(root.resolve()))
        for path in root.rglob('*'):
            if root == stdlib and any(name in path.relative_to(root).parts for name in ('site-packages', 'dist-packages')):
                continue
            if '.git' in path.relative_to(root).parts or '__pycache__' in path.parts:
                continue
            if path.is_symlink():
                resolved = path.resolve(strict=True)
                if resolved.is_dir():
                    continue
            else:
                resolved = path
            if resolved.is_file():
                if stat.S_ISREG(resolved.stat().st_mode):
                    files[str(resolved)] = sha(resolved)
                    if resolved.suffix == '.so':
                        native.add(str(resolved))
            elif resolved.is_dir():
                directories.add(str(resolved))
    return files, directories, native


class UnsupportedRuntime(RuntimeError):
    pass


def public_utc_input():
    source = Path('/usr/share/zoneinfo/UTC')
    try:
        resolved = source.resolve(strict=True)
        if resolved not in (source, Path('/usr/share/zoneinfo/Etc/UTC')):
            raise UnsupportedRuntime('Public UTC resolved outside the two reviewed resource paths')
        rows = []
        for item in sorted(set((source, *source.parents, resolved, *resolved.parents)), key=str):
            info = item.lstat()
            link = os.readlink(item) if stat.S_ISLNK(info.st_mode) else None
            if link is not None:
                if item != source or link not in ('Etc/UTC', '/usr/share/zoneinfo/Etc/UTC'):
                    raise UnsupportedRuntime('Unreviewed public UTC symlink chain')
            elif item != resolved and not stat.S_ISDIR(info.st_mode):
                raise UnsupportedRuntime('Nonordinary public UTC ancestor')
            rows.append(dict(path=str(item), device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
                             uid=info.st_uid, gid=info.st_gid, bytes=info.st_size,
                             mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns, link=link))
        expected = '8b85846791ab2c8a5463c83a5be3c043e2570d7448434d41398969ed47e3e6f2'
        if not stat.S_ISREG(resolved.lstat().st_mode) or resolved.stat().st_size != 114 or sha(resolved) != expected:
            raise UnsupportedRuntime('Public UTC resource differs from reviewed114-byte timezone data pin')
        return dict(source=str(source), resolved=str(resolved), sha256=expected, bytes=114, identities=rows,
                    role='public UTC timezone data only, not clock synchronization or installed tzdata byte equivalence')
    except OSError as error:
        raise UnsupportedRuntime('Public UTC resource identity unavailable: ' + type(error).__name__) from None


def pi_science_absence():
    path = Path('/opt/_internal/cpython-3.11.10/lib/python3.11/site-packages/scipy_openblas32/lib')
    rows = []
    for item in reversed((path, *path.parents)):
        try:
            info = item.lstat()
        except FileNotFoundError:
            rows.append(dict(path=str(item), identity=None))
            break
        if not stat.S_ISDIR(info.st_mode):
            raise UnsupportedRuntime('Pi SciPy native RPATH has a nonordinary ancestor')
        rows.append(dict(path=str(item), identity=[info.st_dev, info.st_ino, info.st_mode]))
    else:
        raise UnsupportedRuntime('Pi SciPy native RPATH provider exists; separate dependency review required')
    return dict(path=str(path), ancestors=rows, policy='exact known native RPATH remains absent')


def declared_runtime(application, recording):
    settings = recording.read(application / 'pyvenv.cfg').decode('utf-8').splitlines()
    homes = [line.partition('=')[2].strip() for line in settings if line.partition('=')[0].strip() == 'home']
    if len(homes) != 1 or not Path(homes[0]).is_absolute():
        raise UnsupportedRuntime('application must declare exactly one absolute interpreter home')
    runtime = Path(homes[0]).parent.resolve()
    return runtime


def application_runtime(application, recording, target):
    runtime = declared_runtime(application, recording)
    source = runtime / 'lib/python3.11/ctypes/__init__.py'
    digest = sha(source) if source.is_file() else None
    if digest == '608671c6b49e5e027e3348fcf492718c33f69f919d99f4ff170522c40bd4c550':
        if runtime != Path('/usr') or sys.version_info[:3] != (3, 11, 2):
            raise UnsupportedRuntime('Exact retained Pi runtime layout/version required')
        target.target_facts()
        tree = target.snapshot(runtime / 'lib/python3.11')
        if target.live_startup_policy(tree, application) is not True:
            raise UnsupportedRuntime('Exact retained Pi startup hook/cache profile required')
        if sha(application / 'bin/python') != sha(runtime / 'bin/python3.11'):
            raise UnsupportedRuntime('copied Pi application interpreter differs from reviewed base')
        pi_science_absence()
        return runtime, 'reviewed-pi-cpython3112-exact-startup', tree
    if digest != 'a31058a86719567745b80200dcc40218663e7516026a79ac0911d97c67574f71':
        raise UnsupportedRuntime('Only reviewed host3.11.16 or retained Pi3.11.2 runtime profiles are supported')
    if sha(application / 'bin/python3.11') != sha(runtime / 'bin/python3.11'):
        raise UnsupportedRuntime('copied application interpreter differs from its declared base')
    stdlib = runtime / 'lib/python3.11'
    if any(path.name.startswith(('sitecustomize', 'usercustomize')) for path in stdlib.rglob('*')):
        raise UnsupportedRuntime('Host gate forbids base startup hooks; target reviewed hook/cache needs its separate retained policy.')
    return runtime, 'reviewed-host-cpython31116-no-startup-hooks', None


def bind(source, application, runtime, environments, profile, startup_tree):
    site = application / 'lib/python3.11/site-packages'
    files, directories, native = inventory((runtime / 'lib/python3.11', application, source, HERE), runtime / 'lib/python3.11')
    if startup_tree is not None:
        for relative, row in startup_tree['files'].items():
            path = str(Path(startup_tree['root']) / relative)
            files[path] = row['sha256']
            if path.endswith('.so'):
                native.add(path)
        for row in startup_tree['links'].values():
            files[row['resolved']] = row['sha256']
        directories.update(str(Path(startup_tree['root']) / relative) for relative in startup_tree['directories'])
    utc = public_utc_input()
    files[utc['resolved']] = utc['sha256']
    project = tomllib.loads((source / 'pyproject.toml').read_text())['project']
    expected = {}
    for line in (HERE / 'reference/requirements/development-constraints.txt').read_text().splitlines():
        name, version = line.split('==')
        name = name.lower().replace('_', '-').replace('.', '-')
        if name not in {'serialptu', 'pyserial', 'pymavlink', 'lxml', 'fastcrc'}:
            expected[name] = project['version'] if name == 'satgs' else version
    allowed_native = set()
    prefixes = ('numpy/', 'pandas/', 'scipy/', 'ephem/', 'yaml/', 'google/')
    for path in native:
        if str(runtime / 'lib/python3.11/lib-dynload') + '/' in path:
            allowed_native.add(path)
        elif path.startswith(str(site) + '/') and path[len(str(site)) + 1:].startswith(prefixes):
            allowed_native.add(path)
    mapping = {}
    for path in sorted((source / 'src/satgs').rglob('*.py')):
        relative = path.relative_to(source / 'src')
        installed = site / relative
        installed_expected = hashlib.sha256(b'INSTALLED = True\n').hexdigest() if str(relative) == 'satgs/_package_layout.py' else sha(path)
        if installed.is_symlink() or not installed.is_file() or sha(installed) != installed_expected:
            raise RuntimeError('installed G module bytes differ from selected source: ' + str(relative))
        mapping[str(relative)] = dict(source=str(path), installed=str(installed), installed_sha256=installed_expected,
                                      source_sha256=sha(path),
                                      exemption='exact generated installed layout marker' if str(relative) == 'satgs/_package_layout.py' else None)
    return dict(schema='operator-candidate-acceptance.v1', source=str(source), application=str(application),
                runtime=str(runtime), runtime_profile=profile, startup_tree=startup_tree,
                interpreter=str(application / 'bin' / ('python' if startup_tree is not None else 'python3.11')),
                scipy_rpath_absence=pi_science_absence() if startup_tree is not None else None,
                inputs=files, directories=sorted(directories), native=sorted(allowed_native),
                tests=str(source / 'tests'), expected_distributions=expected,
                source_installed_mapping=mapping,
                public_utc=utc,
                resource_sha256=sha(source / 'config/deployment_profiles.json'),
                tle_sha256=sha(source / 'src/satgs/data/operator_tle.csv'),
                example=str(HERE / 'reference/config/station.example.json'), environments=environments,
                hardware_enabled=False, network_enabled=False, services_enabled=False)


def unchanged(binding, target):
    if binding['startup_tree'] is not None:
        target.require(target.live_startup_policy(binding['startup_tree'], Path(binding['application'])) is True,
                       'retained Pi startup snapshot changed')
    if public_utc_input() != binding['public_utc']:
        raise RuntimeError('public UTC input source or ancestor identity changed')
    if binding['scipy_rpath_absence'] is not None and pi_science_absence() != binding['scipy_rpath_absence']:
        raise RuntimeError('Pi scientific native RPATH absence changed')
    if any(sha(path) != expected for path, expected in binding['inputs'].items()):
        raise RuntimeError('candidate input changed during acceptance; dependent work stopped')


def package_attempt(recording, attempt):
    allowed_root = {'binding.json', 'input-identities.json', 'phase-summary.json'}
    allowed_lane = {'attempt.json', 'result.json', 'stdout', 'stderr'}
    files, total = {}, 0
    for path in sorted(attempt.rglob('*')):
        recording.ordinary(path)
        relative = path.relative_to(attempt)
        if path.is_dir():
            recording.require((len(relative.parts) == 1 and relative.name in LANES) or
                              (len(relative.parts) == 2 and relative.parts[0] == 'native-widgets'
                               and relative.parts[1] in ('server', 'child')), 'unexpected evidence directory')
            continue
        permitted = (len(relative.parts) == 1 and relative.name in allowed_root) or (
            len(relative.parts) == 2 and relative.parts[0] in LANES and relative.name in allowed_lane) or (
            len(relative.parts) == 2 and relative.parts[0] == 'native-widgets' and relative.name == 'owner-result.json') or (
            len(relative.parts) == 3 and relative.parts[0] == 'native-widgets'
            and relative.parts[1] in ('server', 'child') and relative.name in allowed_lane)
        recording.require(permitted, 'unexpected evidence member')
        data = recording.read(path)
        total += len(data)
        recording.require(total <= recording.MAX_EVIDENCE and len(files) < 64, 'evidence limit exceeded')
        files[str(relative)] = data
    checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n'
                        for name, data in files.items()).encode()
    recording.write_bytes(attempt / 'EVIDENCE-SHA256SUMS', checksums)
    files['EVIDENCE-SHA256SUMS'] = checksums
    partial = attempt / 'evidence.partial.tar.gz'
    with partial.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as archive:
            for name, data in files.items():
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), 0o600, 0
                archive.addfile(member, io.BytesIO(data))
        stream.flush()
        os.fsync(stream.fileno())
    with tarfile.open(partial, 'r:gz') as archive:
        recording.require(archive.getnames() == list(files), 'archive membership mismatch')
        for member in archive.getmembers():
            recording.require(member.isfile() and archive.extractfile(member).read() == files[member.name],
                              'archive content mismatch')
    final = attempt / 'evidence.tar.gz'
    os.link(partial, final)
    partial.unlink()
    digest = recording.digest(final)
    recording.write_bytes(attempt / 'evidence.tar.gz.sha256', (digest + '  evidence.tar.gz\n').encode())
    return dict(status='PASS', path=str(final), sha256=digest, files=len(files), uncompressed_bytes=total,
                excludes='final report/summary/completion bind the verified archive after packaging')


def report_text(summary):
    lines = ['Operator candidate acceptance: ' + summary['status'],
             'Application: ' + summary['application'], 'Source: ' + summary['source'],
             'Offline: no hardware, broker/database/Box, service activation, RF or PTU commands.',
             'Required native widgets and headless/presenter coverage remain separate.']
    lines.append('Server listeners are source-bound abstract Unix only. Exact bound Tk9/static Xlib/XCB native local IPC is trusted under the owned display/private authority, not client no-TCP or syscall isolation. Python sockets remain denied.')
    lines.append('Supported Xvfb displayfd disables lock handling before OsInit; redundant non-root-warning -nolock is omitted. Lock bypass is source-derived, not inferred from post-cleanup absence.')
    for lane, row in summary['phases'].items():
        lines.append('%s: %s; child exit=%s; %s' %
                     (lane, row['status'], row.get('child_exit', 'NOT RUN'), row.get('reason', '')))
    lines.extend(['Primary: ' + json.dumps(summary['primary'], sort_keys=True),
                  'Packaging: ' + json.dumps(summary['packaging'], sort_keys=True),
                  'Duration seconds: %.3f' % summary['duration_seconds'],
                  'Prior bounded Pixhawk PASS is carried forward only for its unchanged matching baseline scope.',
                  'Navigation, calibrated heading, physical health/readiness and Pi GUI execution are not qualified.',
                  'Protection trusts exact reviewed runtime/native internals, not hostile-code syscall isolation.',
                  'Completion binds report/summary; the verified archive contains actual child records, not scratch fixtures.'])
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    reference = HERE / 'reference/ground_station'
    revision = ROOT / 'revision-3/frozen-source'
    if not revision.is_dir():
        revision = ROOT / 'revision-2/frozen-source'
    parser.add_argument('--source', type=Path, default=reference if reference.is_dir() else revision if revision.is_dir() else ROOT / 'frozen-source')
    parser.add_argument('--application', type=Path, default=Path(sys.executable).parent.parent)
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--diagnostic-planning', action='store_true')
    args = parser.parse_args()
    args.application, args.source = args.application.resolve(), args.source.resolve()
    args.output_root = Path(os.path.abspath(args.output_root))
    if any(args.output_root == root or root in args.output_root.parents for root in (HERE, args.source, args.application)):
        parser.error('--output-root must be outside support, selected reference source and application')
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise RuntimeError('use python3.11 -I -B -S')
    target = load(HERE / 'pi_target.py', 'acceptance_supervisor', PINNED['pi_target.py'])
    recording = load(HERE / 'recording.py', 'acceptance_recording')
    recording.report_text = report_text
    runtime_root = declared_runtime(args.application, recording)
    if args.output_root == runtime_root or runtime_root in args.output_root.parents:
        parser.error('--output-root must be outside the declared runtime')
    recording.ordinary(args.output_root)
    args.output_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    attempt = Path(tempfile.mkdtemp(prefix='operator-acceptance-', dir=args.output_root))
    started = time.monotonic()
    summary = dict(schema='operator-consolidated-acceptance.v1', status='BLOCKED', application=str(args.application),
                   source=str(args.source), phases={lane: dict(status='NOT RUN') for lane in LANES}, primary=None,
                   cleanup=dict(status='NOT RUN'), capture_errors=[], packaging=dict(status='NOT RUN'), signals=[])
    summary['diagnostic_only'] = args.diagnostic_planning
    interrupts = recording.Interrupts()
    previous = {number: signal.signal(number, interrupts.handler) for number in (signal.SIGINT, signal.SIGTERM)}
    binding = None
    native_context = native_state = native_owner = None
    try:
        environments = {lane: dict(target.ENV) for lane in LANES}
        runtime, profile, startup_tree = application_runtime(args.application.resolve(), recording, target)
        target.require(runtime == runtime_root and args.output_root != runtime and runtime not in args.output_root.parents,
                       'runtime changed or evidence output overlaps the runtime')
        native_reason = 'No reviewed owned ARM64 display/runtime profile; retained Pi CLI/headless lanes are independent and no x86 display is used.'
        manifest = ROOT / 'gui-runtime/xvfb-rebuild/manifest.json'
        if startup_tree is None and not args.diagnostic_planning:
            if manifest.is_file():
                native_owner = load(HERE / 'native_owner.py', 'operator_native_owner')
                native_context = tempfile.TemporaryDirectory(prefix='operator-native-', dir=args.output_root)
                native_state = native_owner.prepare(target, manifest, Path(native_context.name))
                environments['native-widgets'] = native_state['client_environment']
            else:
                native_reason = 'Reviewed host native manifest unavailable; no display or native child started.'
        binding = bind(args.source.resolve(), args.application.resolve(), runtime, environments, profile, startup_tree)
        if native_state is not None:
            binding['inputs'].update(native_state['inputs'])
            binding['native_display'] = dict(manifest=str(manifest), manifest_sha256=native_owner.MANIFEST_SHA,
                                            display=':' + native_state['display'],
                                            resource_links=native_state['resource_links'],
                                            color_data_absence=native_state['color_data_absence'],
                                            allowed_ipc='owned local display only; Python socket effects remain denied',
                                            trusted_client='exact bound Tk9/static Xlib/XCB; not client transport or syscall isolation')
        else:
            binding['native_display'] = None
        binding['network_policy'] = 'External network/other Python socket effects denied; native display trust is explicit, not syscall isolation'
        target.startup_policy(args.application.resolve())
        recording.write_json(attempt / 'binding.json', binding)
        recording.write_json(attempt / 'input-identities.json', binding['inputs'])
        binding_sha = sha(attempt / 'binding.json')
        installed_ok = False
        for lane in LANES:
            if args.diagnostic_planning and lane not in ('static', 'installed', 'planning'):
                summary['phases'][lane] = dict(status='NOT RUN', reason='Fixed planning-denial diagnostic only; no full acceptance claim.')
                continue
            if lane == 'native-widgets':
                if not installed_ok:
                    summary['phases'][lane] = dict(status='NOT RUN', reason='Dependent installed identity/resource check did not pass.')
                    continue
                if native_state is None:
                    summary['phases'][lane] = dict(status='BLOCKED', reason=native_reason)
                    continue
                unchanged(binding, target)
                command = [binding['interpreter'], '-I', '-B', '-S', str(HERE / 'child.py'),
                           '--binding', str(attempt / 'binding.json'), '--binding-sha', binding_sha,
                           '--lane', lane, '--scratch', str(native_state['child_scratch'])]
                owned = native_owner.run(target, native_state, command, attempt / lane, cwd=HERE, interrupts=interrupts)
                unchanged(binding, target)
                result = owned.get('children', {}).get('child', {})
                stdout = attempt / lane / 'child/stdout'
                output = stdout.read_text(errors='replace').splitlines() if stdout.is_file() else []
                rows = [json.loads(line[len('OPERATOR_LANE_RESULT '):]) for line in output if line.startswith('OPERATOR_LANE_RESULT ')]
                row = rows[-1] if len(rows) == 1 else dict(status='FAIL', runner_error='missing-or-ambiguous-child-result')
                status = 'PASS' if owned['status'] == row['status'] == 'PASS' else 'BLOCKED' if owned['status'] == row['status'] == 'BLOCKED' else 'FAIL'
                summary['phases'][lane] = dict(status=status, child_exit=result.get('exit'), supervision=result,
                                               owner=owned, result=row)
                continue
            if lane not in ('static', 'installed') and not installed_ok:
                summary['phases'][lane] = dict(status='NOT RUN', reason='Dependent installed identity/resource check did not pass.')
                continue
            unchanged(binding, target)
            with tempfile.TemporaryDirectory(prefix='operator-lane-', dir=args.output_root) as scratch:
                command = [binding['interpreter'], '-I', '-B', '-S', str(HERE / 'child.py'),
                           '--binding', str(attempt / 'binding.json'), '--binding-sha', binding_sha,
                           '--lane', lane, '--scratch', scratch]
                result = target.supervise(command, attempt / lane, cwd=HERE, environment=environments[lane], timeout=120)
            unchanged(binding, target)
            output = (attempt / lane / 'stdout').read_text(errors='replace').splitlines()
            rows = [json.loads(line[len('OPERATOR_LANE_RESULT '):]) for line in output if line.startswith('OPERATOR_LANE_RESULT ')]
            row = rows[-1] if len(rows) == 1 else dict(status='FAIL', runner_error='missing-or-ambiguous-child-result')
            supervised = target.supervision_passed(result)
            clean_blocked = (result.get('exit') == result.get('final_exit') == 78
                             and target.supervision_passed(dict(result, exit=0)))
            status = 'PASS' if supervised and row['status'] == 'PASS' else 'BLOCKED' if clean_blocked and row['status'] == 'BLOCKED' else 'FAIL'
            summary['phases'][lane] = dict(status=status, child_exit=result.get('exit'), supervision=result, result=row)
            if lane == 'installed':
                installed_ok = status == 'PASS'
        statuses = {row['status'] for row in summary['phases'].values()}
        summary['status'] = 'FAIL' if 'FAIL' in statuses else 'BLOCKED' if statuses != {'PASS'} else 'PASS'
        if interrupts.received:
            summary['status'] = 'FAIL'
            summary['primary'] = dict(type='RunInterrupted', message='operator interruption')
        summary['cleanup'] = dict(status='PASS' if all(
            row.get('supervision', {}).get('quiescent', True)
            and not row.get('supervision', {}).get('cleanup_errors')
            and not row.get('supervision', {}).get('residual_descendants')
            and not row.get('owner', {}).get('cleanup_errors')
            and all(child.get('quiescent') is True for child in row.get('owner', {}).get('children', {}).values())
            for row in summary['phases'].values()) else 'FAIL')
    except BaseException as error:
        summary['status'] = 'BLOCKED' if binding is None and isinstance(error, (FileNotFoundError, UnsupportedRuntime)) else 'FAIL'
        summary['primary'] = dict(type=type(error).__name__, message=recording.error_text(error))
    finally:
        interrupts.finalizing = True
        summary['signals'] = list(interrupts.received)
        summary['duration_seconds'] = time.monotonic() - started
        if native_context is not None:
            try:
                native_context.cleanup()
            except BaseException as error:
                summary['status'] = 'FAIL'
                summary['cleanup'] = dict(status='FAIL', error=recording.error_text(error))
        try:
            recording.write_json(attempt / 'phase-summary.json', summary['phases'])
            summary['packaging'] = package_attempt(recording, attempt)
        except BaseException as error:
            summary['status'] = 'FAIL'
            summary['packaging'] = dict(status='FAIL', error=recording.error_text(error))
        complete = recording.finalize_records(attempt, summary, interrupts)
        for number, handler in previous.items():
            signal.signal(number, handler)
        print(summary['status'])
        print('report.txt: ' + str(attempt / 'report.txt'))
        print('evidence.tar.gz: ' + str(attempt / 'evidence.tar.gz'))
        print('completion.json: ' + str(attempt / 'completion.json'))
    return 0 if complete and summary['status'] == 'PASS' else 78 if complete and summary['status'] == 'BLOCKED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
