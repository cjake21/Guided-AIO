"""Check a local inactive source checkout without fetching or changing it."""

import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def git(arguments, *, root=ROOT):
    environment = dict(PATH='/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC',
                       GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0',
                       GIT_ASKPASS='/bin/false', GIT_CONFIG_NOSYSTEM='1',
                       GIT_CONFIG_GLOBAL=os.devnull)
    command = ['git', '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=' + os.devnull,
               '-c', 'credential.helper=', '-C', str(root), *arguments]
    result = subprocess.run(command, cwd=root, env=environment, capture_output=True,
                            text=True, timeout=15, check=False)
    if result.returncode:
        raise ValueError('Local Git inspection failed; requested source/ref is unavailable. No network request was made.')
    if len(result.stdout) > 4 * 1024 * 1024:
        raise ValueError('Local Git inspection output exceeded its bound.')
    return result.stdout.rstrip('\n')


def inspect(ref, *, root=ROOT):
    root = Path(root)
    if not root.is_absolute() or root.is_symlink() or not (root / '.git').is_dir():
        raise ValueError('Use an ordinary source checkout, not an installed application or archive.')
    if (root / 'pyvenv.cfg').exists() or (root / 'station.json').exists():
        raise ValueError('Source synchronization is not allowed in an application environment or station workspace.')
    if not isinstance(ref, str) or not ref.startswith(('refs/heads/', 'refs/remotes/', 'refs/tags/')):
        raise ValueError('Use one exact fully qualified local source ref.')
    if not re.fullmatch(r'refs/(?:heads|remotes|tags)/[A-Za-z0-9][A-Za-z0-9._/-]*', ref) or '..' in ref:
        raise ValueError('The requested local source ref is invalid.')
    branch = git(['symbolic-ref', '--quiet', 'HEAD'], root=root)
    head = git(['rev-parse', '--verify', 'HEAD^{commit}'], root=root)
    requested = git(['rev-parse', '--verify', ref + '^{commit}'], root=root)
    for value in (head, requested):
        if not re.fullmatch(r'[0-9a-f]{40}', value):
            raise ValueError('Local source object identity is unsupported.')
    if git(['status', '--porcelain=v1', '--untracked-files=normal'], root=root):
        raise ValueError('Source checkout is dirty; preserve and review local changes before synchronization or release build.')
    return dict(status='PASS', branch=branch, head=head, requested_ref=ref, requested_commit=requested,
                synchronized=head == requested, network_requested=False, source_modified=False,
                installation_modified=False,
                next_step='Fetch/synchronize explicitly in this inactive checkout; build and stage separately.')


def main(argv=None):
    parser = argparse.ArgumentParser(allow_abbrev=False, description=__doc__)
    parser.add_argument('--ref', required=True)
    result = inspect(parser.parse_args(argv).ref)
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        print('SATGS source: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
