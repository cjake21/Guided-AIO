"""Finite hardware-free source checks. No product module is imported."""

import ast
import importlib.util
from pathlib import Path
import sys
import tomllib


ROOT = Path(__file__).resolve().parents[1]


def check(root=ROOT):
    root = Path(root)
    spec = importlib.util.spec_from_file_location('_satgs_static_release', root / 'support/release_update.py')
    release_module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = release_module
    spec.loader.exec_module(release_module)
    release = release_module.release_manifest()
    components = {'ground_station': 'satgs', 'sat_tracker': 'ptu-control',
                  'serialptu': 'serialptu', 'pixhawk': 'pixhawk',
                  'meteor-api': 'meteor-api', 'stomp.py': 'stomp-py'}
    parsed = 0
    projects = {}
    for component, distribution in components.items():
        directory = root / 'components' / component
        metadata = tomllib.loads((directory / 'pyproject.toml').read_text())
        project = metadata['tool']['poetry'] if component == 'stomp.py' else metadata['project']
        if project['version'] != release['packages'][distribution]:
            raise ValueError('Component version differs: ' + component)
        projects[component] = project
        for path in directory.rglob('*.py'):
            if any(part in ('.git', '__pycache__', 'build', 'dist') or part.endswith('.egg-info')
                   for part in path.relative_to(directory).parts):
                continue
            if path.is_symlink():
                raise ValueError('Source symlink is unsupported.')
            ast.parse(path.read_bytes(), filename=str(path), feature_version=(3, 11))
            parsed += 1
    pointing = projects['ground_station']['optional-dependencies']['pointing']
    if pointing != ['ptu_control==' + release['application_version'], 'pixhawk==0.0.1']:
        raise ValueError('Pointing optional-owner pairing differs.')
    manager_only = {'serialptu', 'pyserial', 'pymavlink'}
    for component in ('ground_station', 'sat_tracker', 'pixhawk'):
        names = {value.split('=', 1)[0].split('[', 1)[0].lower().replace('_', '-')
                 for value in projects[component]['dependencies']}
        if names & manager_only:
            raise ValueError('Manager-only dependency leaked into a client base: ' + component)
    docs = root / 'components/ground_station/docs'
    for chapter in release_module.CHAPTERS:
        if not (docs / (chapter + '.md')).is_file():
            raise ValueError('Canonical handbook chapter missing: ' + chapter)
    for path in (root / 'launchers').glob('*.py'):
        ast.parse(path.read_bytes(), filename=str(path), feature_version=(3, 11))
    for path in (root / 'tools').glob('*.py'):
        ast.parse(path.read_bytes(), filename=str(path), feature_version=(3, 11))
    return dict(python_sources=parsed, component_owners=len(components), chapters=len(release_module.CHAPTERS),
                product_imported=False, network_requested=False, equipment_opened=False)


if __name__ == '__main__':
    import json
    try:
        print(json.dumps(dict(status='PASS', result=check()), sort_keys=True))
    except (OSError, ValueError, KeyError, SyntaxError) as error:
        print('SATGS source check: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
