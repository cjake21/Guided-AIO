"""Build six maintained source owners offline in a fresh output directory."""

import argparse
from email.parser import BytesParser
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import sys
import tomllib
import zipfile


ROOT = Path(__file__).resolve().parents[1]
COMPONENTS = {'ground_station': 'satgs', 'sat_tracker': 'ptu-control',
              'serialptu': 'serialptu', 'pixhawk': 'pixhawk',
              'meteor-api': 'meteor-api', 'stomp.py': 'stomp-py'}
GENERATED = {'ground_station': 'src/satgs/jobs_msg_pb2.py',
             'sat_tracker': 'src/ptu_control/ptu_msg_pb2.py',
             'pixhawk': 'src/pixhawk/pixhawk_pb2.py',
             'meteor-api': 'src/meteor_api/protobufs/Meteor_pb2.py'}
IGNORED = frozenset(('.git', '__pycache__', 'build', 'dist', '.pytest_cache'))


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def canonical(value):
    return re.sub(r'[-_.]+', '-', value).lower()


def inventory(root):
    rows = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if any(part in IGNORED or part.endswith('.egg-info') for part in relative.parts):
            continue
        require(not path.is_symlink(), 'Source must not contain symlinks: ' + str(relative))
        if path.is_file():
            raw = path.read_bytes()
            rows[str(relative)] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        else:
            require(path.is_dir(), 'Source contains a nonordinary member.')
    return rows


def check_sources(release):
    sources = {}
    for component, distribution in COMPONENTS.items():
        path = ROOT / 'components' / component
        require(path.is_dir(), 'Missing maintained component: ' + component)
        metadata = tomllib.loads((path / 'pyproject.toml').read_text())
        project = metadata['tool']['poetry'] if component == 'stomp.py' else metadata['project']
        require(canonical(project['name']) == distribution
                and project['version'] == release['packages'][distribution],
                'Component identity differs from release: ' + component)
        if component in GENERATED:
            require((path / GENERATED[component]).is_file(), 'Retained generated module missing: ' + component)
        sources[component] = inventory(path)
    return sources


def tool_versions():
    rows = {}
    for line in (ROOT / 'requirements/build.lock').read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        match = re.fullmatch(r'([a-zA-Z0-9_.-]+)==([^ ]+) --hash=sha256:([0-9a-f]{64})', line)
        require(match is not None, 'Unsupported build lock row.')
        name, version, digest = match.groups()
        require(name not in rows, 'Duplicate build lock distribution.')
        rows[name] = version
    require(set(rows) == {'build', 'packaging', 'pyproject-hooks', 'setuptools', 'wheel'},
            'Build lock tool membership differs.')
    return rows


def wheel_identity(path, distribution, version):
    with zipfile.ZipFile(path) as archive:
        names = [name for name in archive.namelist() if name.endswith('.dist-info/METADATA')]
        require(len(names) == 1, 'Wheel metadata is ambiguous.')
        metadata = BytesParser().parsebytes(archive.read(names[0]))
        require(canonical(metadata['Name']) == distribution and metadata['Version'] == version,
                'Built wheel identity differs.')
    raw = path.read_bytes()
    return dict(filename=path.name, name=distribution, version=version,
                bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def build(args):
    updater = load(ROOT / 'support/release_update.py', '_satgs_build_release')
    daily = updater.daily_module()
    release = updater.release_manifest()
    source_inputs = check_sources(release)
    lock = daily.regular_bytes(ROOT / 'requirements/build.lock', mode=0o644)
    expected_tools = tool_versions()
    require(args.build_python.is_absolute() and args.output_root.is_absolute(),
            'Build interpreter and output must be explicit absolute paths.')
    interpreter = Path(os.path.abspath(args.build_python))
    require(os.access(interpreter, os.X_OK),
            'Use an explicit installed build interpreter.')
    output = Path(os.path.abspath(args.output_root))
    daily.ordinary_directory(output.parent)
    require(not os.path.lexists(output), 'Build output must be a new path; existing output was retained.')
    require(all(output != path and output not in path.parents and path not in output.parents
                for path in (ROOT, interpreter.parent.parent)),
            'Build output overlaps source or build environment.')
    output.mkdir(mode=0o700)
    target = load(ROOT / 'support/pi_target.py', '_satgs_build_supervision')
    summary = dict(schema='satgs-source-build.v1', status='FAIL', release=release['release'],
                   source_inputs=source_inputs, commands=[], artifacts=[], network_requested=False,
                   application_imported=False)
    environment = dict(target.ENV, PIP_CONFIG_FILE=os.devnull, PIP_NO_INDEX='1', PIP_NO_CACHE_DIR='1',
                       SOURCE_DATE_EPOCH=str(release['source_date_epoch']))
    received = []

    def interrupted(number, frame):
        received.append(number)
        raise KeyboardInterrupt('Build interrupted; retained supervisor owns active-child cleanup.')

    previous = {number: signal.signal(number, interrupted) for number in (signal.SIGINT, signal.SIGTERM)}
    try:
        code = ('import importlib.metadata,json; print(json.dumps({name: importlib.metadata.version(name)'
                ' for name in ' + repr(tuple(expected_tools)) + '}, sort_keys=True))')
        probe = target.supervise([str(interpreter), '-I', '-B', '-c', code],
                                  output / 'build-tools', cwd=ROOT, environment=environment,
                                  timeout=30, cap=65536, terminate_grace=5)
        summary['commands'].append(probe)
        require(target.supervision_passed(probe), 'Pinned build-tool metadata check failed.')
        actual_tools = json.loads((output / 'build-tools/stdout').read_text())
        require(actual_tools == expected_tools, 'Build interpreter does not match requirements/build.lock.')
        summary['build_tools'] = actual_tools
        wheels = output / 'wheels'
        wheels.mkdir(mode=0o700)
        copies = output / 'source'
        copies.mkdir(mode=0o700)
        for component, distribution in COMPONENTS.items():
            source = ROOT / 'components' / component
            copied = copies / component
            shutil.copytree(source, copied, ignore=shutil.ignore_patterns(
                '.git', '__pycache__', '*.pyc', '*.egg-info', 'build', 'dist', '.pytest_cache'))
            require(inventory(copied) == source_inputs[component], 'Build copy differs: ' + component)
            before = set(wheels.iterdir())
            result = target.supervise([str(interpreter), '-I', '-B', '-m', 'build', '--wheel',
                                       '--no-isolation', '--outdir', str(wheels), str(copied)],
                                      output / ('build-' + component), cwd=copied, environment=environment,
                                      timeout=180, cap=4 * 1024 * 1024, terminate_grace=5)
            summary['commands'].append(result)
            require(target.supervision_passed(result), 'Offline wheel build failed: ' + component)
            added = set(wheels.iterdir()) - before
            require(len(added) == 1, 'Expected exactly one wheel per component.')
            artifact = next(iter(added))
            require(artifact.suffix == '.whl' and stat.S_ISREG(artifact.lstat().st_mode),
                    'Build produced a nonordinary artifact.')
            summary['artifacts'].append(wheel_identity(artifact, distribution, release['packages'][distribution]))
        require(check_sources(release) == source_inputs, 'Maintained component sources changed while building.')
        require(daily.regular_bytes(ROOT / 'requirements/build.lock', mode=0o644) == lock,
                'Build lock changed while building.')
        summary.update(status='PASS', source_unchanged=True)
    except BaseException as error:
        summary['primary'] = dict(type=type(error).__name__, message=str(error))
    finally:
        summary['signals'] = received
        for number, handler in previous.items():
            signal.signal(number, handler)
    target.write(output / 'build-result.json', summary)
    print(summary['status'] + ': ' + str(output / 'build-result.json'))
    return 0 if summary['status'] == 'PASS' else 1


def main(argv=None):
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
            'Run build_release.py with -I -B -S.')
    parser = argparse.ArgumentParser(allow_abbrev=False, description=__doc__)
    parser.add_argument('--build-python', required=True, type=Path)
    parser.add_argument('--output-root', required=True, type=Path)
    return build(parser.parse_args(argv))


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as error:
        print('SATGS build: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
