"""Package the current six-owner source and five offline replacement wheels."""

import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile


ROOT = Path(__file__).resolve().parents[1]
COMPONENTS = frozenset(('ground_station', 'sat_tracker', 'serialptu', 'pixhawk', 'meteor-api', 'stomp.py'))
REPLACEMENT_PACKAGES = {'satgs': 'satgs', 'ptu-control': 'ptu_control', 'serialptu': 'serialptu',
                        'meteor-api': 'meteor_api', 'stomp-py': 'stomp'}
TREES = ('components', 'support', 'launchers', 'tests', 'config', 'requirements', 'tools', 'docs', 'history')
ROOT_FILES = ('README.md', 'BUILDING.md', 'CONTRIBUTING.md', 'RELEASING.md', 'PROVENANCE.md',
              'REPOSITORY-RETENTION.md',
              'NOTICES.md', 'DELIVERY.md', 'release.json', 'provenance.json', 'component-source-map.json',
              'setup_update.sh', 'setup_guide.sh', 'run_pi_operator_checks.sh', '.gitignore')
EXCLUDED = frozenset(('.git', '__pycache__', '.venv', 'venv', 'envs', 'node_modules', '.ssh', '.aws',
                      '.pytest_cache', '.mypy_cache', '.ruff_cache', 'build', 'dist', 'review',
                      'validation', 'captures', 'evidence', 'wheelhouse'))
MAX_FILE = 32 * 1024 * 1024
MAX_PAYLOAD = 64 * 1024 * 1024
MAX_FILES = 2048


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def member_name(value):
    require(type(value) is str and value and '\\' not in value
            and all(32 <= ord(character) < 127 for character in value), 'Unsafe package member name.')
    path = PurePosixPath(value)
    require(not path.is_absolute() and all(part not in ('', '.', '..') for part in value.split('/')),
            'Unsafe package member path.')
    return value


def ordinary_directory(path):
    path = Path(path)
    require(path.is_absolute() and '..' not in path.parts, 'Use an explicit absolute path without traversal.')
    for parent in (path, *path.parents):
        require(stat.S_ISDIR(parent.lstat().st_mode), 'Package path ancestry must be ordinary directories.')
    return path


def read(path, observed):
    path = Path(path)
    ordinary_directory(path.parent)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(descriptor)
        require(stat.S_ISREG(before.st_mode) and before.st_size <= MAX_FILE,
                'Package input must be a bounded ordinary file.')
        pieces, remaining = [], before.st_size + 1
        while remaining:
            piece = os.read(descriptor, min(65536, remaining))
            if not piece:
                break
            pieces.append(piece)
            remaining -= len(piece)
        data = b''.join(pieces)
        identity = lambda item: (item.st_dev, item.st_ino, item.st_mode, item.st_size,
                                 item.st_mtime_ns, item.st_ctime_ns)
        require(len(data) == before.st_size and identity(before) == identity(os.fstat(descriptor))
                and identity(before) == identity(path.lstat()), 'Package input changed while reading.')
    finally:
        os.close(descriptor)
    mode = stat.S_IMODE(before.st_mode)
    require(mode in (0o444, 0o555, 0o600, 0o644, 0o664, 0o700, 0o755, 0o775),
            'Package input mode is outside the retained convention.')
    row = dict(bytes=len(data), mode=mode, sha256=digest(data))
    require(observed.setdefault(path, row) == row, 'Previously observed package input changed.')
    return data, mode


def files(folder):
    folder = ordinary_directory(folder)
    selected = []
    for index, path in enumerate(sorted(folder.rglob('*'))):
        relative = path.relative_to(folder)
        member_name(relative.as_posix())
        require(index < 8192 and len(selected) < MAX_FILES and len(relative.parts) <= 32,
                'Package source tree exceeds finite bounds.')
        info = path.lstat()
        require(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode),
                'Package source contains a link or special file.')
        require(not EXCLUDED.intersection(relative.parts)
                and not any(part.startswith('.venv') or part.endswith('.egg-info') for part in relative.parts)
                and path.name not in ('station.json', 'operator.json', '.env')
                and not path.name.startswith(('.env.', 'id_rsa', 'id_ed25519'))
                and path.suffix not in ('.pyc', '.log', '.key', '.pem', '.p12', '.pfx', '.whl', '.gz'),
                'Package source contains excluded private, build or execution content.')
        if stat.S_ISREG(info.st_mode):
            selected.append(path)
    return selected


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_build_sources(report, payload):
    actual = {component: {} for component in COMPONENTS}
    for name, (data, mode) in payload.items():
        parts = PurePosixPath(name).parts
        if parts[0] == 'components':
            require(len(parts) >= 3 and parts[1] in COMPONENTS, 'Unexpected source owner in package.')
            actual[parts[1]]['/'.join(parts[2:])] = dict(bytes=len(data), sha256=digest(data))
    require(all(actual.values()) and report.get('source_inputs') == actual,
            'Current component source differs from the explicit wheel-build result.')


def verify_replacement_members(distribution, details):
    require(distribution in REPLACEMENT_PACKAGES, 'Unreviewed replacement distribution.')
    package_name = REPLACEMENT_PACKAGES[distribution]
    metadata_prefix = distribution.replace('-', '_') + '-' + details['version'] + '.dist-info/'
    require(details['members'] and all(name.startswith((package_name + '/', metadata_prefix))
                and not name.endswith(('.so', '.dll', '.dylib', '.pyc', '.pth'))
                for name in details['members']), 'Replacement wheel contains native or unbound payload.')


def collect(wheels):
    wheels = ordinary_directory(wheels)
    updater = load(ROOT / 'support/release_update.py', '_satgs_package_release')
    release = updater.release_manifest()
    installer = load(ROOT / 'support/setup_operator_update.py', '_satgs_package_wheels')
    observed, payload = {}, {}
    report_raw, unused_mode = read(wheels.parent / 'build-result.json', observed)
    report = json.loads(report_raw, object_pairs_hook=updater.unique_object)
    require(report.get('schema') == 'satgs-source-build.v1' and report.get('status') == 'PASS'
            and report.get('release') == release['release'] and report.get('source_unchanged') is True,
            'Explicit wheel directory requires its successful portable build result.')
    artifacts = report.get('artifacts')
    require(type(artifacts) is list and len(artifacts) == 6
            and {row.get('name') for row in artifacts if type(row) is dict} == set(release['packages']),
            'Wheel-build artifact ownership differs from the six-component release.')
    artifact_map = {row['name']: row for row in artifacts}
    require({path.name for path in (ROOT / 'components').iterdir()} == COMPONENTS,
            'Maintained source must contain exactly the six component owners.')
    trees = {name: files(ROOT / name) for name in TREES}
    for path in [ROOT / name for name in ROOT_FILES] + [path for selected in trees.values() for path in selected]:
        relative = member_name(path.relative_to(ROOT).as_posix())
        require(relative not in payload, 'Duplicate package source member.')
        data, mode = read(path, observed)
        payload[relative] = data, 0o755 if path.suffix == '.sh' and mode & 0o111 else 0o644
    verify_build_sources(report, payload)
    for distribution, relative in release['replacement_wheels'].items():
        filename = PurePosixPath(member_name(relative)).name
        path = wheels / filename
        data, unused_mode = read(path, observed)
        details = installer.wheel_details(path, distribution, release['packages'][distribution])
        verify_replacement_members(distribution, details)
        row = artifact_map[distribution]
        require(details['tags'] == ['py3-none-any'] and row.get('filename') == filename
                and row.get('version') == details['version'] and row.get('bytes') == len(data)
                and row.get('sha256') == digest(data), 'Replacement wheel differs from its exact build record.')
        payload[relative] = data, 0o644
    contents = {name: dict(bytes=len(data), mode=mode, sha256=digest(data))
                for name, (data, mode) in sorted(payload.items())}
    payload['CONTENTS.json'] = encoded(dict(schema='satgs-release-contents.v1', release=release['release'],
        scope='All archive files except CONTENTS.json; no self-referential digest.', files=contents)), 0o644
    require(len(payload) <= MAX_FILES and sum(len(data) for data, mode in payload.values()) <= MAX_PAYLOAD,
            'Package payload exceeds finite bounds.')
    return release, payload, observed, trees


def unchanged(observed, trees):
    for folder, selected in trees.items():
        require(files(ROOT / folder) == selected, 'Source membership changed while packaging.')
    for path, expected in list(observed.items()):
        raw, mode = read(path, {})
        require(dict(bytes=len(raw), mode=mode, sha256=digest(raw)) == expected,
                'Source or wheel input changed while packaging.')


def archive_bytes(name, payload, epoch):
    stream = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=epoch) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for relative, (data, mode) in sorted(payload.items()):
                item = tarfile.TarInfo(member_name(name + '/' + relative))
                item.size, item.mode, item.mtime = len(data), mode, epoch
                item.uid = item.gid = 0
                item.uname = item.gname = ''
                archive.addfile(item, io.BytesIO(data))
    raw = stream.getvalue()
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members = archive.getmembers()
        require(len(members) == len(payload) == len({item.name for item in members}),
                'Written archive membership differs.')
        for item in members:
            require(item.name.startswith(name + '/'), 'Written archive root differs.')
            relative = item.name.removeprefix(name + '/')
            require(relative in payload, 'Written archive contains an unexpected member.')
            data, mode = payload[relative]
            require(item.isfile() and item.mode == mode and item.mtime == epoch
                    and item.uid == item.gid == 0 and item.uname == item.gname == ''
                    and set(item.pax_headers) <= {'path'} and item.pax_headers.get('path', item.name) == item.name
                    and archive.extractfile(item).read() == data, 'Written archive bytes/mode differ.')
    return raw


def write_new(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    path.chmod(0o644)


def transfer_readme(release, name):
    return ('# SATGS offline release ' + release['release'] + '\n\n'
        'Extract ' + name + '.tar.gz and open a Bash terminal in ' + name + '.\n'
        'Keep the retained r3 offline dependency bundle and all previous environments.\n'
        'This package contains six-owner maintained source, offline docs/checks and five replacement pure wheels.\n'
        'It reuses the existing 31-distribution platform manager closure; no Git, downloads or authentication is required on the Pi.\n\n'
        '```sh\n. ./setup_update.sh --accept-trusted-native\n'
        './run_pi_operator_checks.sh --accept-trusted-native && . ./launchers/setup_daily.sh --select ' + release['selection'] + '\n```\n\n'
        'Setup stages the jog correction separately and retains the existing daily selection and station.\n'
        'The second command explicitly selects ' + release['selection'] + ' only if acceptance returns PASS; failed checks leave the selection unchanged.\n'
        'Selection requires an idle managed station; no GUI opens automatically.\n'
        'Open SATGS from the application menu or run `satgs-operator-gui` in a desktop terminal after selection.\n'
        'Rollback selection is `. ./launchers/setup_daily.sh --select bench` under the same idle guard.\n'
        'Preserve failed candidates and printed reports/evidence. Never reset the station or overwrite an occupied environment.\n\n'
        'CONTENTS.json records file sizes, modes and automatic provenance hashes, excluding itself.\n'
        'The archive SHA sidecar is optional transfer provenance, not a substitute for functional acceptance.\n'
        'Packaging is not target acceptance or physical commissioning. No hardware, service, broker or database operation is authorized.\n'
        'Root docs/history and older tool references remain explicitly historical; current instructions are README.md and RELEASING.md.\n').encode()


def package(args):
    wheels = ordinary_directory(args.wheels)
    output = Path(args.output_root)
    ordinary_directory(output.parent)
    require(output.is_absolute() and '..' not in output.parts and not os.path.lexists(output),
            'Package output must be a new explicit absolute path; occupied output was retained.')
    require(all(output != root and output not in root.parents and root not in output.parents
                for root in (ROOT, wheels)), 'Package output overlaps source or wheel inputs.')
    parent = output.parent.stat()
    require(parent.st_uid == os.geteuid() and not parent.st_mode & 0o022,
            'Package output parent must be owned and not group/world writable.')
    release, payload, observed, trees = collect(wheels)
    output.mkdir(mode=0o700)
    result = dict(schema='satgs-release-package.v1', status='FAIL', release=release['release'])
    try:
        unchanged(observed, trees)
        name = 'satgs-' + release['release']
        raw = archive_bytes(name, payload, release['source_date_epoch'])
        archive = output / (name + '.tar.gz')
        write_new(archive, raw)
        unchanged(observed, trees)
        write_new(output / (archive.name + '.sha256'), (digest(raw) + '  ' + archive.name + '\n').encode())
        write_new(output / 'README.md', transfer_readme(release, name))
        result.update(status='PASS', archive=archive.name, bytes=len(raw), sha256=digest(raw), files=len(payload),
                      source_unchanged=True, network_requested=False, application_imported=False)
    except BaseException as error:
        result['primary'] = dict(type=type(error).__name__, message=str(error))
    write_new(output / 'package-result.json', encoded(result))
    print(json.dumps(result, sort_keys=True))
    return 0 if result['status'] == 'PASS' else 1


def main(argv=None):
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
            'Run package_release.py with Python -I -B -S.')
    parser = argparse.ArgumentParser(allow_abbrev=False, description=__doc__)
    parser.add_argument('--wheels', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    return package(parser.parse_args(argv))


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as error:
        print('SATGS package: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
