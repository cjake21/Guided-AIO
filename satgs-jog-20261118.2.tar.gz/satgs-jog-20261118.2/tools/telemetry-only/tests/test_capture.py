"""Offline structural tests only; no product-owner or hardware qualification."""

import io
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import capture_telemetry as capture


class MemorySource:
    def __init__(self, payload):
        self.stream = io.BytesIO(payload)
        self.requests = []

    def read(self, amount, timeout):
        self.requests.append((amount, timeout))
        return self.stream.read(amount)


class SyntheticDecoder:
    def feed(self, chunk):
        yield {"message_type": "SYNTHETIC", "qualification": "test-fixture-only"}

    def pending_bytes(self):
        return 7


class CaptureTests(unittest.TestCase):
    def run_capture(self, payload, **options):
        source = MemorySource(payload)
        output = io.StringIO()
        result = capture.capture(source, output, max_bytes=options.pop("max_bytes", 1024),
                                 max_seconds=options.pop("max_seconds", 10),
                                 clock=options.pop("clock", lambda: 1.0),
                                 utc_now=lambda: "fixture-utc", **options)
        rows = [json.loads(line) for line in output.getvalue().splitlines()]
        return source, rows, result

    def test_offline_bytes_roundtrip_and_eof(self):
        payload = bytes(range(256))
        source, rows, result = self.run_capture(payload)
        self.assertEqual(bytes.fromhex(rows[0]["data_hex"]), payload)
        self.assertEqual(result["input_bytes"], len(payload))
        self.assertEqual(result["termination"], "end-of-input")
        self.assertEqual(result["navigation_validity"], "not-evaluated")
        self.assertIsNone(result["pending_parser_bytes"])
        self.assertTrue(all(amount <= 1024 for amount, timeout in source.requests))
        self.assertTrue(all(0 < timeout <= 0.1 for amount, timeout in source.requests))

    def test_byte_budget_is_not_exceeded(self):
        _, rows, result = self.run_capture(b"abcdef", max_bytes=3)
        self.assertEqual(rows[0]["data_hex"], b"abc".hex())
        self.assertEqual(result["input_bytes"], 3)
        self.assertEqual(result["termination"], "byte-limit")

    def test_empty_input_does_not_assert_telemetry_presence(self):
        _, rows, result = self.run_capture(b"")
        self.assertEqual(rows, [])
        self.assertFalse(result["input_bytes_observed"])
        self.assertEqual(result["telemetry_presence"], "not-established")
        self.assertEqual(result["sensor_health"], "not-established")

    def test_deadline_equality_stops_before_read(self):
        times = iter((1.0, 2.0))
        source, rows, result = self.run_capture(b"abc", max_seconds=1, clock=lambda: next(times))
        self.assertEqual(source.requests, [])
        self.assertEqual(rows, [])
        self.assertEqual(result["termination"], "duration-limit")

    def test_late_returning_read_is_disclosed(self):
        times = iter((1.0, 1.0, 3.0, 3.0))
        _, rows, result = self.run_capture(b"abc", max_seconds=1, clock=lambda: next(times))
        self.assertTrue(rows[0]["read_returned_after_duration"])
        self.assertEqual(result["late_read_chunks"], 1)
        self.assertEqual(result["termination"], "duration-limit")

    def test_regressing_local_clock_rejects(self):
        times = iter((2.0, 1.0))
        with self.assertRaises(capture.CaptureError) as caught:
            self.run_capture(b"abc", clock=lambda: next(times))
        self.assertEqual(caught.exception.category, "local-clock-regressed")

    def test_invalid_budgets_reject(self):
        for value in (0, -1, True):
            with self.subTest(bytes=value), self.assertRaises(capture.CaptureError):
                self.run_capture(b"abc", max_bytes=value)
        for value in (0, -1, True, math.nan, math.inf):
            with self.subTest(seconds=value), self.assertRaises(capture.CaptureError):
                self.run_capture(b"abc", max_seconds=value)

    def test_oversized_source_read_rejects(self):
        class InvalidSource:
            def read(self, amount, timeout):
                return b"a" * (amount + 1)
        with self.assertRaises(capture.CaptureError) as caught:
            capture.capture(InvalidSource(), io.StringIO(), max_bytes=3, max_seconds=1, clock=lambda: 1)
        self.assertEqual(caught.exception.category, "invalid-source-read")

    def test_synthetic_decoder_is_separate_and_pending_bytes_are_reported(self):
        _, rows, result = self.run_capture(b"abc", decoder=SyntheticDecoder())
        self.assertEqual([row["record"] for row in rows], ["raw-bytes", "decoded-message"])
        self.assertEqual(result["decoded_messages"], 1)
        self.assertEqual(result["pending_parser_bytes"], 7)
        self.assertEqual(rows[1]["qualification"], "test-fixture-only")

    def test_nonfinite_values_are_marked_not_silently_normalized(self):
        output = io.StringIO()
        capture.emit(output, {"heading": math.nan, "zero": 0})
        row = json.loads(output.getvalue())
        self.assertEqual(row["heading"], {"nonfinite_number": "nan"})
        self.assertEqual(row["zero"], 0)

    def test_arbitrary_objects_are_not_represented(self):
        class NoRepr:
            def __repr__(self):
                raise AssertionError("repr must not run")
        with self.assertRaises(capture.CaptureError):
            capture.json_value(NoRepr())

    def test_transmit_sink_always_rejects(self):
        with self.assertRaises(capture.CaptureError) as caught:
            capture.DenyTransmit().write(b"anything")
        self.assertEqual(caught.exception.category, "transmit-disabled")

    def test_output_is_exclusive_and_private(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "capture.jsonl"
            with capture.open_output(path) as output:
                capture.emit(output, {"test": True})
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)
            original = path.read_bytes()
            with self.assertRaises(FileExistsError):
                capture.open_output(path)
            self.assertEqual(path.read_bytes(), original)

    def test_offline_input_symlink_and_nonregular_path_reject(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            actual = root / "input.bin"
            actual.write_bytes(b"abc")
            linked = root / "linked.bin"
            linked.symlink_to(actual)
            with self.assertRaises(OSError):
                capture.FileSource(linked)
            with self.assertRaises(capture.CaptureError):
                capture.FileSource(root)

    def test_serial_requires_opt_in_before_import_or_open(self):
        with self.assertRaises(capture.CaptureError) as caught:
            capture.SerialSource("/dev/not-a-target", 115200, False)
        self.assertEqual(caught.exception.category, "serial-open-not-acknowledged")

    def test_serial_rejects_nondevice_paths_before_import_or_open(self):
        with self.assertRaises(capture.CaptureError) as caught:
            capture.SerialSource("/tmp/not-a-device", 115200, True)
        self.assertEqual(caught.exception.category, "serial-path-must-be-explicit-device")


class ClosingSource(MemorySource):
    def __init__(self, read_error=None, close_error=None):
        super().__init__(b"abc")
        self.read_error = read_error
        self.close_error = close_error
        self.close_calls = 0

    def read(self, amount, timeout):
        chunk = super().read(amount, timeout)
        if not chunk and self.read_error is not None:
            raise self.read_error
        return chunk

    def close(self):
        self.close_calls += 1
        self.stream.close()
        if self.close_error is not None:
            raise self.close_error


class MainCaptureTests(unittest.TestCase):
    def run_main(self, source, *, decoder=None, source_error=None):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "capture.jsonl"
            argv = ["--input", str(Path(directory) / "fixture.bin"), "--output", str(path),
                    "--max-bytes", "1024", "--max-seconds", "10"]
            if decoder is not None:
                argv += ["--decode", "--dialect", "common", "--wire-version", "2"]
            with mock.patch.object(capture, "FileSource", return_value=source, side_effect=source_error), \
                    mock.patch.object(capture, "MavlinkDecoder", return_value=decoder):
                status = capture.main(argv)
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            rows = [json.loads(line) for line in path.read_text().splitlines()]
        return status, rows

    def assert_failed_capture(self, rows, category, *, completed=False, close_category=None):
        kinds = ["capture-header", "raw-bytes", "capture-failure"]
        if close_category is not None:
            kinds.append("input-close-failure")
        self.assertEqual([row["record"] for row in rows], kinds)
        self.assertEqual(bytes.fromhex(rows[1]["data_hex"]), b"abc")
        self.assertEqual(rows[2], {"record": "capture-failure", "category": category,
                                  "capture_loop_completed": completed})
        if close_category is not None:
            self.assertEqual(rows[3], {"record": "input-close-failure", "category": close_category,
                                      "capture_loop_completed": completed})

    def test_main_success_closes_once_and_reports_summary(self):
        source = ClosingSource()
        status, rows = self.run_main(source)
        self.assertEqual(status, 0)
        self.assertEqual(source.close_calls, 1)
        self.assertTrue(source.stream.closed)
        self.assertEqual([row["record"] for row in rows], ["capture-header", "raw-bytes", "capture-summary"])
        self.assertEqual(rows[2]["termination"], "end-of-input")
        self.assertEqual(rows[2]["input_bytes"], 3)
        self.assertTrue(rows[2]["capture_loop_completed"])

    def test_main_read_failure_precedes_close_failure(self):
        for error, category in ((capture.CaptureError("fixture-read-failed"), "fixture-read-failed"),
                                (OSError("fixture-read-failed"), "capture-or-close-failed")):
            for close_error, close_category in ((None, None), (OSError("fixture-close"), "input-close-failed"),
                                                (KeyboardInterrupt(), "interrupted")):
                with self.subTest(category=category, close_category=close_category):
                    source = ClosingSource(error, close_error)
                    status, rows = self.run_main(source)
                    self.assertEqual(status, 1)
                    self.assertEqual(source.close_calls, 1)
                    self.assertTrue(source.stream.closed)
                    self.assert_failed_capture(rows, category, close_category=close_category)

    def test_main_parser_failure_preserves_raw_bytes_and_close_failure(self):
        class RejectingDecoder:
            identity = {"qualification": "test-fixture-only"}

            def feed(self, chunk):
                raise capture.CaptureError("fixture-parse-failed")

        source = ClosingSource(close_error=OSError("fixture-close"))
        status, rows = self.run_main(source, decoder=RejectingDecoder())
        self.assertEqual(status, 1)
        self.assertEqual(source.close_calls, 1)
        self.assert_failed_capture(rows, "fixture-parse-failed", close_category="input-close-failed")

    def test_main_interrupt_precedes_close_failure(self):
        for close_error, close_category in ((None, None), (OSError("fixture-close"), "input-close-failed"),
                                            (KeyboardInterrupt(), "interrupted")):
            with self.subTest(close_category=close_category):
                source = ClosingSource(KeyboardInterrupt(), close_error)
                status, rows = self.run_main(source)
                self.assertEqual(status, 130)
                self.assertEqual(source.close_calls, 1)
                self.assert_failed_capture(rows, "interrupted", close_category=close_category)

    def test_main_close_only_failure_is_not_success(self):
        for error, category, expected in ((OSError("fixture-close"), "input-close-failed", 1),
                                          (KeyboardInterrupt(), "interrupted", 130)):
            with self.subTest(category=category):
                source = ClosingSource(close_error=error)
                status, rows = self.run_main(source)
                self.assertEqual(status, expected)
                self.assertEqual(source.close_calls, 1)
                self.assert_failed_capture(rows, category, completed=True, close_category=category)

    def test_main_source_constructor_failure_does_not_close_unowned_source(self):
        source = ClosingSource()
        try:
            status, rows = self.run_main(source, source_error=capture.CaptureError("fixture-open-failed"))
            self.assertEqual(status, 1)
            self.assertEqual(source.close_calls, 0)
            self.assertEqual([row["record"] for row in rows], ["capture-header", "capture-failure"])
            self.assertEqual(rows[1], {"record": "capture-failure", "category": "fixture-open-failed",
                                       "capture_loop_completed": False})
        finally:
            source.stream.close()

    def test_main_output_failure_remains_incomplete_and_closes_input(self):
        class FailingOutput(io.StringIO):
            def __init__(self, fail_write):
                super().__init__()
                self.fail_write = fail_write
                self.error = OSError("fixture-output-failed")
                self.close_calls = 0
                self.saved = ""

            def write(self, value):
                if self.fail_write and self.tell():
                    raise self.error
                return super().write(value)

            def close(self):
                self.close_calls += 1
                self.saved = self.getvalue()
                super().close()
                if not self.fail_write:
                    raise self.error

        for fail_write in (True, False):
            with self.subTest(fail_write=fail_write):
                source = ClosingSource(close_error=OSError("fixture-close") if fail_write else None)
                output = FailingOutput(fail_write)
                with mock.patch.object(capture, "FileSource", return_value=source), \
                        mock.patch.object(capture, "open_output", return_value=output), \
                        self.assertRaises(OSError) as caught:
                    capture.main(["--input", "fixture.bin", "--output", "fixture.jsonl",
                                  "--max-bytes", "1024", "--max-seconds", "10"])
                self.assertIs(caught.exception, output.error)
                self.assertEqual(source.close_calls, 1)
                self.assertEqual(output.close_calls, 1)
                self.assertTrue(output.closed)
                rows = [json.loads(line) for line in output.saved.splitlines()]
                self.assertEqual([row["record"] for row in rows],
                                 ["capture-header"] if fail_write else
                                 ["capture-header", "raw-bytes", "capture-summary"])


if __name__ == "__main__":
    unittest.main()
