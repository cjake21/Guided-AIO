"""Prospective genuine-parser tests; require separate dependency/execution admission."""

import io
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import capture_telemetry as capture


class BinarySource:
    def __init__(self, payload):
        self.stream = io.BytesIO(payload)

    def read(self, amount, timeout):
        return self.stream.read(amount)


class GenuineParserTests(unittest.TestCase):
    def frame(self, version):
        namespace = "v10" if version == "1" else "v20"
        module = capture.importlib.import_module("pymavlink.dialects." + namespace + ".common")
        encoder = module.MAVLink(capture.DenyTransmit(), srcSystem=17, srcComponent=23, use_native=False)
        message = module.MAVLink_heartbeat_message(0, 0, 0, 0, 0, 3)
        return message.pack(encoder)

    def test_genuine_v1_and_v2_frames_retain_raw_bytes_and_ids(self):
        for version in ("1", "2"):
            with self.subTest(version=version):
                frame = self.frame(version)
                decoder = capture.MavlinkDecoder("common", version)
                output = io.StringIO()
                summary = capture.capture(BinarySource(frame), output, max_bytes=1024,
                                          max_seconds=1, decoder=decoder, clock=lambda: 1,
                                          utc_now=lambda: "fixture-utc")
                rows = [json.loads(line) for line in output.getvalue().splitlines()]
                messages = [row for row in rows if row["record"] == "decoded-message"]
                self.assertEqual(len(messages), 1)
                self.assertEqual(messages[0]["message_type"], "HEARTBEAT")
                self.assertEqual(bytes.fromhex(messages[0]["raw_frame_hex"]), frame)
                self.assertEqual((messages[0]["source_system"], messages[0]["source_component"]), (17, 23))
                self.assertEqual(messages[0]["payload_length"], frame[1])
                self.assertEqual(summary["bad_data_messages"], 0)
                self.assertEqual(summary["pending_parser_bytes"], 0)
                self.assertEqual(summary["sensor_health"], "not-established")

    def test_partial_frame_retains_bytes_without_inventing_message(self):
        frame = self.frame("2")
        decoder = capture.MavlinkDecoder("common", "2")
        output = io.StringIO()
        summary = capture.capture(BinarySource(frame[:3]), output, max_bytes=1024,
                                  max_seconds=1, decoder=decoder, clock=lambda: 1)
        rows = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(bytes.fromhex(rows[0]["data_hex"]), frame[:3])
        self.assertEqual(summary["decoded_messages"], 0)
        self.assertGreater(summary["pending_parser_bytes"], 0)

    def test_corrupt_frame_is_unqualified_bad_data(self):
        frame = bytearray(self.frame("2"))
        frame[-1] ^= 1
        decoder = capture.MavlinkDecoder("common", "2")
        messages = list(decoder.feed(bytes(frame)))
        self.assertTrue(any(message["message_type"] == "BAD_DATA" for message in messages))
        self.assertTrue(all(message["qualification"] == "unqualified-parser-output" for message in messages))

    def test_genuine_parser_transmit_remains_disabled(self):
        decoder = capture.MavlinkDecoder("common", "2")
        with self.assertRaises(capture.CaptureError) as caught:
            decoder.parser.heartbeat_send(0, 0, 0, 0, 0, 3)
        self.assertEqual(caught.exception.category, "transmit-disabled")


if __name__ == "__main__":
    unittest.main()
