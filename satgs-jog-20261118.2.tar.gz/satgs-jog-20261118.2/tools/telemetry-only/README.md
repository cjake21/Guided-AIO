# Telemetry-only delivery source

Derived on 2026-10-08 from the prospective 2026-10-07 source. The delivery-local
cleanup correction and hardware-free validation are approved; all 23 structural
and four genuine-parser methods passed on Linux x86-64, CPython3.11.16, under
reviewed offline controls. The parser lane used the genuine common v1/v2 modules
and their Python CRC fallback, not native fastcrc. This is not
part of the original application's 528-method acceptance. No Pi, serial, broker,
network or firmware operation is authorized by these files. Field-location work,
Pixhawk comparison and target qualification remain separate.

## Contents and runtime requirements

- `capture_telemetry.py`: top-level standard-library imports only, offline raw
  binary file/stdin capture, optional genuine MAVLink decoding, and separately
  gated serial input. Output is local exclusive JSONL with mode0600.
- `tests/test_capture.py`: standard-library structural tests with synthetic
  in-memory bytes/clock/decoder interfaces. These are not original regression
  replacements or genuine parser, owner, native or hardware qualification.
  The original 16 methods are retained, with seven main-path cleanup regressions.
- `tests/test_pymavlink_offline.py`: distinct prospective genuine-parser tests
  using generated in-memory frames, including incomplete/corrupt input and
  rejection of attempted transmit. No serial or operational owner is constructed.
- `dependency-candidates.json`: deliberately unresolved target inventory, not a
  usable requirements lock. Target hashes/artifacts must be reviewed later.
- This README. Later add only separately approved genuine artifacts/notices,
  target-specific hash lock and transfer integrity manifest.

Raw file/stdin mode needs only an approved Python standard library. Serial
capture additionally needs target-reviewed pyserial. Optional decoding adds
pymavlink and its genuine dependency closure. Current host candidates are
pyserial3.5, pymavlink2.4.49, lxml6.1.0 and fastcrc0.3.4. These are not target
selections or evidence that ARM64 wheels exist or work. Do not copy host x86-64
environments or native wheels to the Pi. Target dependency selection and target
execution still require separate review.

G, PTU, serialptu, Meteor/stomp, broker credentials/configuration, services,
udev files, compiler/build environments and internal review evidence are not
needed for this raw test. The internal delivery destination is
`ssh://git@git.codev.mitre.org/~cjacobson/satgs-modular-suite.git`; its first push
remains separately gated. Raw captures can contain sensitive positions/source
details and are not approved for repository inclusion or external transfer.

## What capture means

Input files/stdin must be an unframed raw MAVLink binary stream, not timestamped
`.tlog`, JSON, protobuf `fused_msg` or CSV. JSONL preserves every read chunk as
hex plus its offset and host UTC/monotonic receipt time. Concatenating
`raw-bytes.data_hex` reconstructs captured input; its digest covers those bytes.
Optional parser records preserve actual message frame bytes, wire marker,
payload length, source system/component, sequence and unnormalized decoded
fields. Nonfinite decoded numbers are explicitly marked, not converted to zero.
Raw bytes remain authoritative for later examination of extension presence;
generated zero defaults are not field-presence evidence.

Both parser dialect and wire-version selections must be supplied explicitly.
There is no assumed source contract. Selecting a v1/v2 parser does not prove
that received frames match the requested version. The raw marker is retained;
firmware/dialect qualification and any mismatch policy remain separate.
MAVLink signing/source authentication is not established by parse success.

No yaw conversion, health/fix threshold, freshness/skew limit, baseline/IMU/PTU
offset, calibration or navigation observation is created. Per-component source
timestamps remain raw fields. Host receipt timestamps and byte-capture sessions
are not qualified acquisition times or source restart/session identities.
No-traffic, BAD_DATA and partial-frame outcomes remain explicit. Capture-loop
completion or exit0 is not sensor validity, installed acceptance, navigation
admission or physical readiness. Numeric capture budgets are resource limits
for the separately approved attempt, not deployment health thresholds.

Use an approved ordinary output directory with trustworthy ancestors. The
script refuses existing output paths, creates no parent directories and does
not delete partial results. A final capture-failure record is attempted on
read/parse/close failure. Disk/output-close or process termination can prevent
that final record; absence is incomplete evidence, never an implicit pass.
Regular-file reads, pipe readiness/read races, device operations and output
flush/close are not universally preemptible. An independently approved external
process timeout and owned-process cleanup remain required for actual execution.

The delivery-local `main` preserves the primary capture failure category and
status before attempting input close once. A primary interruption retains
status 130; other primary failures retain status 1. An input-close error or
interruption is recorded separately as `input-close-failure` and does not replace
the primary outcome. If only input close fails, status is nonzero, a
`capture-failure` records that the capture loop completed, and no successful
summary is emitted. Error messages and source paths are not copied into these
failure records. Partial output is retained. Output write/close failure can
still prevent final records or make an earlier summary incomplete, so neither
a summary alone nor a missing failure record proves successful termination.

Hardware-free test controls must be installed before discovery. They must deny
serial/mavutil imports, device access, network connections, child processes and
fallback reads from original checkouts or evidence. Permit only the selected
interpreter/package sources, this delivery tool and an owned temporary output
tree. Genuine-parser tests build frames in memory; the attempted heartbeat send
must stop at the rejecting sink. Source compilation and review do not substitute
for actual controlled test results.

## Why the existing manager is excluded

`PixhawkManager.__init__` opens serial, sends MAV_CMD_SET_MESSAGE_INTERVAL for
four message types and subscribes to broker ping commands. Its aggregate
overwrites raw/fused position provenance and omits component time/presence.
`main`, the service and `--nohw` are not receive-only replacements.

This script does not import `mavutil`, construct managers/Messenger, publish,
request rates, send heartbeat/parameters/commands, reset buffers or autoreconnect.
Its optional generated parser has a transmit sink that rejects writes. It reads
only the already available stream. Missing streams are not repaired by issuing
MAVLink commands. The transmit test is offline with that rejecting sink.

Serial opening is not effect-free. pyserial opens read/write device handles and
applies baud, timeout, exclusive access and modem-control settings. Requested
RTS/DTR states are false before open, but drivers/USB hardware can still glitch
lines, reset/reboot a source or conflict with an existing service. No guarantee
of hardware receive-only isolation follows. Never stop a service, change device
permissions, use sudo, force a busy port, alter firmware or stream settings, or
add reconnect/fallback commands without separate approval. Exact selected
device identity, ownership, baud, safety conditions and control-line effects
must be reviewed before serial execution. `--allow-serial-open` is only an
acknowledgment gate, not owner, managed or platform permission.

## Later sequence and one-line commands

All commands below are NOT RUN and NOT AUTHORIZED target execution. Uppercase
names represent values still requiring explicit selection; no example numeric
budget or source ID is a deployment policy. Run from the approved transferred
bundle only after approving repository/contents, target/interpreter/artifacts,
source/execution admission and each permitted output location.

1. Create a separate target venv with the selected interpreter. Do not reinstall
   or change accepted application environments.
2. Freeze genuine target artifacts and a hash-required lock. Optional parser
   and serial packages are selected only for the intended test. No fake hashes
   or `--no-deps` bypass is provided.
3. Independently admit/run structural offline tests, then genuine-parser tests
   if their dependency/native effects are admitted. Preserve exact command,
   interpreter/artifact/source identities, streams and failures.
4. Admit/run offline capture of an approved raw input or stdin pipe first.
5. Only with separate device/target approval, admit a bounded serial capture.
   Preserve zero-traffic, corrupt/missing/partial input and all failure evidence.

```bash
APPROVED_PYTHON -m venv .venv
.venv/bin/python -m pip install --no-index --find-links wheelhouse --require-hashes -r requirements-pi.lock
.venv/bin/python -m unittest discover -s tests -p test_capture.py -v
.venv/bin/python -m unittest discover -s tests -p test_pymavlink_offline.py -v
timeout APPROVED_OUTER_DURATION .venv/bin/python capture_telemetry.py --input APPROVED_RAW_FILE --output APPROVED_NEW_JSONL --max-bytes APPROVED_BYTE_BUDGET --max-seconds APPROVED_CAPTURE_DURATION
timeout APPROVED_OUTER_DURATION .venv/bin/python capture_telemetry.py --stdin --output APPROVED_NEW_JSONL --max-bytes APPROVED_BYTE_BUDGET --max-seconds APPROVED_CAPTURE_DURATION
timeout APPROVED_OUTER_DURATION .venv/bin/python capture_telemetry.py --serial-port APPROVED_DEVICE --allow-serial-open --baud APPROVED_BAUD --output APPROVED_NEW_JSONL --max-bytes APPROVED_BYTE_BUDGET --max-seconds APPROVED_CAPTURE_DURATION
```

The target lock/wheelhouse, selected interpreter and approved values do not
exist in this bundle. Optional decoding adds all three explicit options:
`--decode --dialect APPROVED_DIALECT --wire-version APPROVED_WIRE_VERSION`.
Supported candidate dialect names are `common` and `ardupilotmega`; neither is
implicitly selected. A different source contract requires review of that
parser choice before changing the file.

Before navigation feature work, qualify the actual firmware and dialect, heading
units/reference and validity indicators, component timestamps and clock/session
behavior, uncertainty and freshness policies, position datum and provenance,
and measured sensor/antenna/PTU geometry and offsets. Preserve raw field presence
and distinguish absent, invalid and stale observations from real zero values.
No measured coordinate, calibration, health threshold or source-session identity
is supplied by this tool. A successful raw capture can inform those decisions
but cannot supply missing qualification by assumption.
