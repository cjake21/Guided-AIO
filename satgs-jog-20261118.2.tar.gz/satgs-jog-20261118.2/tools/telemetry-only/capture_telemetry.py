"""Prospective raw telemetry capture, not a navigation-validity adapter."""

import argparse
import hashlib
import importlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import select
import stat
import sys
import time
from datetime import datetime, timezone


class CaptureError(Exception):
    def __init__(self, category):
        self.category = category
        super().__init__(category)


def positive_int(value):
    try:
        result = int(value)
    except (ValueError, TypeError):
        raise argparse.ArgumentTypeError("expected a positive integer") from None
    if result <= 0:
        raise argparse.ArgumentTypeError("expected a positive integer")
    return result


def positive_seconds(value):
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError):
        raise argparse.ArgumentTypeError("expected positive finite seconds") from None
    if not math.isfinite(result) or result <= 0:
        raise argparse.ArgumentTypeError("expected positive finite seconds")
    return result


def json_value(value):
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        return value if math.isfinite(value) else {"nonfinite_number": str(value)}
    if type(value) in (bytes, bytearray):
        return {"bytes_hex": value.hex()}
    if type(value) in (list, tuple):
        return [json_value(item) for item in value]
    if type(value) is dict and all(type(key) is str for key in value):
        return {key: json_value(item) for key, item in value.items()}
    raise CaptureError("unsupported-decoded-value")


def emit(output, record):
    output.write(json.dumps(json_value(record), sort_keys=True, allow_nan=False) + "\n")
    output.flush()


class DenyTransmit:
    def write(self, payload):
        raise CaptureError("transmit-disabled")


class MavlinkDecoder:
    def __init__(self, dialect, wire_version):
        if dialect not in ("common", "ardupilotmega") or wire_version not in ("1", "2"):
            raise CaptureError("unsupported-parser-selection")
        namespace = "v10" if wire_version == "1" else "v20"
        name = "pymavlink.dialects." + namespace + "." + dialect
        module = importlib.import_module(name)
        self.parser = module.MAVLink(DenyTransmit(), use_native=False)
        self.parser.robust_parsing = True
        self.identity = {
            "module": name,
            "pymavlink_version": importlib.metadata.version("pymavlink"),
            "selected_wire_version": wire_version,
            "selected_dialect": dialect,
            "source_qualification": "not-established",
        }

    def feed(self, chunk):
        for value in chunk:
            message = self.parser.parse_char(bytes((value,)))
            if message is None:
                continue
            raw = bytes(message.get_msgbuf())
            marker = raw[0] if raw else None
            yield {
                "message_type": message.get_type(),
                "source_system": message.get_srcSystem(),
                "source_component": message.get_srcComponent(),
                "sequence": message.get_seq(),
                "raw_frame_hex": raw.hex(),
                "wire_marker": marker,
                "payload_length": raw[1] if len(raw) >= 2 and marker in (0xFE, 0xFD) else None,
                "decoded_fields": message.to_dict(),
                "qualification": "unqualified-parser-output",
            }

    def pending_bytes(self):
        return max(0, len(self.parser.buf) - self.parser.buf_index)


class FileSource:
    def __init__(self, path):
        if not hasattr(os, "O_NOFOLLOW"):
            raise CaptureError("unsupported-file-platform")
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                raise CaptureError("offline-input-must-be-regular")
            self.stream = os.fdopen(descriptor, "rb")
        except BaseException:
            os.close(descriptor)
            raise

    def read(self, amount, timeout):
        return self.stream.read(amount)

    def close(self):
        self.stream.close()


class StdinSource:
    def __init__(self):
        self.descriptor = sys.stdin.fileno()
        mode = os.fstat(self.descriptor).st_mode
        if not (stat.S_ISREG(mode) or stat.S_ISFIFO(mode)):
            raise CaptureError("stdin-must-be-file-or-pipe")

    def read(self, amount, timeout):
        ready, _, _ = select.select([self.descriptor], [], [], timeout)
        return os.read(self.descriptor, amount) if ready else None

    def close(self):
        pass


class SerialSource:
    def __init__(self, port, baud, allow_open):
        if allow_open is not True:
            raise CaptureError("serial-open-not-acknowledged")
        path = Path(port)
        if not path.is_absolute() or ".." in path.parts or path.parts[1:2] != ("dev",):
            raise CaptureError("serial-path-must-be-explicit-device")
        serial = importlib.import_module("serial")
        self.connection = serial.Serial(
            port=None, baudrate=baud, timeout=0.1, xonxoff=False,
            rtscts=False, dsrdtr=False, exclusive=True,
        )
        self.connection.dtr = False
        self.connection.rts = False
        self.connection.port = str(path)
        try:
            self.connection.open()
        except BaseException:
            self.connection.close()
            raise

    def read(self, amount, timeout):
        self.connection.timeout = min(0.1, timeout)
        return self.connection.read(amount) or None

    def close(self):
        self.connection.close()


def checked_clock(clock, previous=None):
    value = clock()
    if type(value) not in (int, float) or not math.isfinite(value):
        raise CaptureError("invalid-local-clock")
    if previous is not None and value < previous:
        raise CaptureError("local-clock-regressed")
    return value


def capture(source, output, *, max_bytes, max_seconds, decoder=None,
            clock=time.monotonic, utc_now=lambda: datetime.now(timezone.utc).isoformat()):
    if type(max_bytes) is not int or max_bytes <= 0:
        raise CaptureError("invalid-byte-budget")
    if type(max_seconds) not in (int, float) or not math.isfinite(max_seconds) or max_seconds <= 0:
        raise CaptureError("invalid-duration-budget")
    started = checked_clock(clock)
    deadline = started + max_seconds
    if not math.isfinite(deadline):
        raise CaptureError("invalid-duration-budget")
    previous = started
    total = chunks = messages = bad_data = late_chunks = 0
    digest = hashlib.sha256()
    while True:
        now = checked_clock(clock, previous)
        previous = now
        if total >= max_bytes:
            termination = "byte-limit"
            break
        if now >= deadline:
            termination = "duration-limit"
            break
        requested = min(4096, max_bytes - total)
        chunk = source.read(requested, min(0.1, deadline - now))
        if chunk is None:
            continue
        if type(chunk) is not bytes or len(chunk) > requested:
            raise CaptureError("invalid-source-read")
        if not chunk:
            termination = "end-of-input"
            break
        received = checked_clock(clock, previous)
        previous = received
        late = received >= deadline
        late_chunks += int(late)
        timestamp = utc_now()
        emit(output, {
            "record": "raw-bytes", "offset": total, "data_hex": chunk.hex(),
            "received_monotonic": received, "received_utc": timestamp,
            "read_returned_after_duration": late,
            "qualification": "unqualified-byte-capture",
        })
        digest.update(chunk)
        total += len(chunk)
        chunks += 1
        if decoder is not None:
            for message in decoder.feed(chunk):
                emit(output, {
                    "record": "decoded-message", "received_monotonic": received,
                    "received_utc": timestamp, **message,
                })
                messages += 1
                bad_data += int(message["message_type"] == "BAD_DATA")
    return {
        "record": "capture-summary", "capture_loop_completed": True,
        "termination": termination, "input_bytes": total, "raw_chunks": chunks,
        "raw_bytes_sha256": digest.hexdigest(), "decoded_messages": messages,
        "bad_data_messages": bad_data, "late_read_chunks": late_chunks,
        "pending_parser_bytes": None if decoder is None else decoder.pending_bytes(),
        "input_bytes_observed": total > 0,
        "telemetry_presence": "not-established",
        "navigation_validity": "not-evaluated",
        "sensor_health": "not-established",
        "source_session": "not-established",
    }


def open_output(path):
    if not hasattr(os, "O_NOFOLLOW"):
        raise CaptureError("unsupported-file-platform")
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        return os.fdopen(descriptor, "w", encoding="utf-8", newline="\n")
    except BaseException:
        os.close(descriptor)
        raise


def argument_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--input", type=Path, help="unframed raw MAVLink binary regular file")
    source.add_argument("--stdin", action="store_true", help="raw binary file or pipe on stdin")
    source.add_argument("--serial-port", type=Path, help="separately approved explicit device path")
    parser.add_argument("--allow-serial-open", action="store_true",
                        help="acknowledge opening effects; does not grant owner/platform authority")
    parser.add_argument("--baud", type=positive_int)
    parser.add_argument("--output", type=Path, required=True, help="new exclusive JSONL output file")
    parser.add_argument("--max-bytes", type=positive_int, required=True)
    parser.add_argument("--max-seconds", type=positive_seconds, required=True)
    parser.add_argument("--decode", action="store_true", help="use an independently reviewed genuine parser")
    parser.add_argument("--dialect", choices=("common", "ardupilotmega"))
    parser.add_argument("--wire-version", choices=("1", "2"))
    return parser


def main(argv=None):
    parser = argument_parser()
    args = parser.parse_args(argv)
    if args.serial_port is not None and (not args.allow_serial_open or args.baud is None):
        parser.error("serial input requires --allow-serial-open and --baud")
    if args.serial_port is None and (args.allow_serial_open or args.baud is not None):
        parser.error("serial options require --serial-port")
    if args.decode != (args.dialect is not None and args.wire_version is not None):
        parser.error("--decode requires both --dialect and --wire-version; otherwise omit all three")
    if not args.decode and (args.dialect is not None or args.wire_version is not None):
        parser.error("parser selections require --decode")
    try:
        decoder = MavlinkDecoder(args.dialect, args.wire_version) if args.decode else None
        output = open_output(args.output)
    except Exception:
        print("capture initialization failed; no input opened", file=sys.stderr)
        return 1
    status = 0
    source = None
    summary = None
    failure = None
    close_failure = None
    with output:
        emit(output, {
            "record": "capture-header", "format": "prospective-raw-telemetry-jsonl.v1",
            "input_kind": "serial" if args.serial_port is not None else "stdin" if args.stdin else "file",
            "capture_budgets": {"max_bytes": args.max_bytes, "max_seconds": args.max_seconds},
            "budgets_are_navigation_thresholds": False,
            "parser": None if decoder is None else decoder.identity,
            "qualification": "unqualified-byte-capture",
            "serial_opening_is_not_effect_free": args.serial_port is not None,
        })
        try:
            if args.serial_port is not None:
                source = SerialSource(args.serial_port, args.baud, args.allow_serial_open)
            elif args.stdin:
                source = StdinSource()
            else:
                source = FileSource(args.input)
            summary = capture(source, output, max_bytes=args.max_bytes,
                              max_seconds=args.max_seconds, decoder=decoder)
        except KeyboardInterrupt:
            failure = {"record": "capture-failure", "category": "interrupted", "capture_loop_completed": False}
            status = 130
        except Exception as error:
            category = error.category if type(error) is CaptureError else "capture-or-close-failed"
            failure = {"record": "capture-failure", "category": category, "capture_loop_completed": False}
            status = 1
        finally:
            if source is not None:
                try:
                    source.close()
                except KeyboardInterrupt:
                    close_failure = {"record": "input-close-failure", "category": "interrupted",
                                     "capture_loop_completed": summary is not None}
                except Exception:
                    close_failure = {"record": "input-close-failure", "category": "input-close-failed",
                                     "capture_loop_completed": summary is not None}
                finally:
                    source = None
        if failure is None and close_failure is not None:
            status = 130 if close_failure["category"] == "interrupted" else 1
            failure = {**close_failure, "record": "capture-failure"}
        emit(output, failure if failure is not None else summary)
        if close_failure is not None:
            emit(output, close_failure)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
