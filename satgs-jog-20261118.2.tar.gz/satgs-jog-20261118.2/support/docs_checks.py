"""Installed-guide and worked-example checks within the retained effect guard."""

from contextlib import redirect_stderr, redirect_stdout
import hashlib
from html.parser import HTMLParser
import importlib
import io
import json
import os
from pathlib import Path
import re
import runpy
import stat
import sys

import launcher_checks


MAX_INPUT = 1024 * 1024
MAX_OUTPUT = 2 * 1024 * 1024
HEX_ID = re.compile(r'[0-9a-f]{64}')
CHAPTERS = ('operator-guide', 'configurations', 'component-handbook', 'installation',
            'daily-operation', 'station-location', 'ptu-operation', 'operator-tutorial',
            'results', 'legacy-comparison', 'updates-troubleshooting',
            'operator-cli-reference', 'maintainer-reference')
GUIDE_IMAGES = {'user-guide-setup.png', 'user-guide-ptu.png'}
GUIDE_SOURCES = {'docs/assets/native-setup-20261112.png',
                 'docs/assets/native-ptu-20261112.png'}
GUIDE_FILES = {'user-guide.html', 'user-guide.txt', 'user-guide.css'} | GUIDE_IMAGES
FORBIDDEN_IMPORTS = (
    'satgs.operator_core', 'satgs.deployment', 'satgs.deployment_cli', 'satgs.deployment_plan',
    'satgs.operator_activity', 'satgs.runtime_configuration', 'satgs.station_location',
    'satgs.operator_runtime', 'satgs.operator_bench', 'satgs.pass_runner', 'satgs.queue_manager',
    'tkinter', 'numpy', 'pandas', 'scipy', 'yaml', 'ephem', 'meteor_api', 'pixhawk',
    'ptu_control', 'serialptu', 'stomp', 'boxsdk', 'niquests',
)


def _require(condition, message):
    if not condition:
        raise RuntimeError(message)


def _read_json(path, limit=MAX_INPUT):
    path = Path(path)
    _require(not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
             and path.stat().st_size <= limit, 'JSON input is not a bounded ordinary file.')
    raw = path.read_bytes()
    _require(len(raw) <= limit, 'JSON input grew beyond its bound.')
    return json.loads(raw), raw


def _bound(path, binding):
    path = Path(path)
    digest = launcher_checks._sha(path)
    _require(binding['inputs'].get(str(path)) == digest, 'A bound installed or script input changed.')
    return digest


def _new_private(path, payload):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        with os.fdopen(descriptor, 'wb', closefd=False) as stream:
            stream.write(payload)
            stream.flush()
    finally:
        os.close(descriptor)


class _BoundedOutput(io.StringIO):
    def __init__(self, remaining):
        super().__init__()
        self.remaining = remaining

    def write(self, value):
        size = len(value.encode('utf-8'))
        _require(size <= self.remaining[0], 'Console output exceeds the aggregate 2 MiB bound.')
        self.remaining[0] -= size
        return super().write(value)


def _output_record(value):
    raw = value.encode('utf-8')
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), excerpt=value[:256])


def _console(binding, arguments, remaining):
    entry = Path(binding['application']) / 'bin/satgs-operator'
    _bound(entry, binding)
    output, errors = _BoundedOutput(remaining), _BoundedOutput(remaining)
    previous, code = sys.argv, 0
    try:
        sys.argv = [str(entry), *arguments]
        with redirect_stdout(output), redirect_stderr(errors):
            try:
                runpy.run_path(str(entry), run_name='__main__')
            except SystemExit as error:
                _require(error.code is None or type(error.code) is int, 'Console returned a nonnumeric exit.')
                code = error.code or 0
    finally:
        sys.argv = previous
    text, diagnostic = output.getvalue(), errors.getvalue()
    return code, text, diagnostic, dict(console=str(entry), arguments=arguments,
        cwd=str(Path.cwd()), exit=code, stdout=_output_record(text), stderr=_output_record(diagnostic))


class _GuideDocument(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.anchors, self.fragments, self.assets, self.optional_links = set(), set(), set(), set()
        self.csp = False

    def handle_starttag(self, tag, attributes):
        values = dict(attributes)
        _require(tag not in ('script', 'iframe', 'object', 'embed', 'form', 'base'),
                 'The offline guide contains active or externally rooted content.')
        _require(not any(name.startswith('on') or name in ('srcset', 'style') for name in values),
                 'The offline guide contains active attributes or inline styling.')
        if 'id' in values:
            _require(values['id'] not in self.anchors, 'The guide repeats an HTML anchor.')
            self.anchors.add(values['id'])
        if tag == 'meta' and values.get('http-equiv', '').lower() == 'content-security-policy':
            self.csp = values.get('content') == (
                "default-src 'none'; style-src 'self'; img-src 'self'; base-uri 'none'; form-action 'none'")
        for name in ('href', 'src'):
            if name not in values:
                continue
            target = values[name]
            _require(type(target) is str, 'The guide contains an empty resource reference.')
            if tag == 'a' and name == 'href' and target.startswith('#'):
                self.fragments.add(target[1:])
            elif tag == 'a' and name == 'href' and target.startswith('https://'):
                self.optional_links.add(target)
            else:
                _require((tag, name, target) == ('link', 'href', 'user-guide.css')
                         or (tag, name) == ('img', 'src') and target in GUIDE_IMAGES,
                    'The guide requires an unapproved local or remote asset.')
                self.assets.add(target)


def _no_station_imports():
    found = sorted(name for name in sys.modules if any(
        name == prefix or name.startswith(prefix + '.') for prefix in FORBIDDEN_IMPORTS))
    _require(not found, 'Documentation-only execution loaded station or optional modules: ' + ', '.join(found))


def check_installed_docs(binding, scratch):
    scratch = Path(scratch)
    launcher_checks._directory(scratch)
    site = Path(binding['application']) / 'lib/python3.11/site-packages'
    resources = site / 'satgs/data'
    version = binding['expected_distributions']['satgs']
    _no_station_imports()
    _require(not os.environ.get('DISPLAY') and not os.environ.get('WAYLAND_DISPLAY'),
             'The docs-only lane must retain its real headless environment.')
    manifest_path = resources / 'user-guide-manifest.json'
    manifest, _ = _read_json(manifest_path)
    _bound(manifest_path, binding)
    _require(set(manifest) == {'schema', 'application_version', 'sources', 'outputs'}
             and manifest['schema'] == 'satgs-offline-guide.v1'
             and manifest['application_version'] == version and set(manifest['outputs']) == GUIDE_FILES,
             'The installed guide manifest does not identify this release and its fixed resources.')
    sources = {'docs/' + name + '.md' for name in CHAPTERS} | GUIDE_SOURCES
    _require(set(manifest['sources']) == sources, 'The guide source manifest is incomplete.')
    for name, digest in manifest['sources'].items():
        _require(HEX_ID.fullmatch(digest) is not None
                 and binding['inputs'].get(str(Path(binding['source']) / name)) == digest,
                 'The packaged guide source identity differs from its admitted input.')
    output_hashes = {}
    for name, digest in manifest['outputs'].items():
        path = resources / name
        _require(not path.is_symlink() and path.stat().st_size <= MAX_OUTPUT
                 and HEX_ID.fullmatch(digest) is not None and _bound(path, binding) == digest,
                 'A packaged guide output is missing or differs from its manifest.')
        output_hashes[name] = digest
    terminal = (resources / 'user-guide.txt').read_text(encoding='utf-8')
    html = (resources / 'user-guide.html').read_text(encoding='utf-8')
    css = (resources / 'user-guide.css').read_text(encoding='utf-8')
    _require('Application version ' + version in terminal and 'Application version ' + version in html,
             'The installed terminal and HTML guides do not name the selected version.')
    _require('@import' not in css.lower() and 'url(' not in css.lower(), 'The guide stylesheet requires outside assets.')
    for name in GUIDE_IMAGES:
        _require((resources / name).read_bytes().startswith(b'\x89PNG\r\n\x1a\n'),
                 'A packaged guide screenshot is not a PNG.')
    document = _GuideDocument()
    document.feed(html)
    document.close()
    _require(document.csp and not document.fragments - document.anchors
             and set(CHAPTERS).issubset(document.anchors)
             and document.assets == {'user-guide.css'} | GUIDE_IMAGES,
             'Installed guide links, chapter anchors or local assets are incomplete.')
    missing = scratch / 'absent station with spaces'
    invalid = scratch / 'invalid station with spaces'
    _require(not missing.exists() and not missing.is_symlink() and not invalid.exists(),
             'Docs fixture paths must be newly absent scratch children.')
    invalid.mkdir(mode=0o700)
    station = invalid / 'station.json'
    _new_private(station, b'not a valid station document\n')
    station_hash = launcher_checks._sha(station)
    remaining, calls = [MAX_OUTPUT], []
    forms = (['docs'], ['--read-docs'], ['docs', '--text'], ['--format', 'json', 'docs', '--text'])
    for workspace in (missing, invalid):
        for form in forms:
            arguments = ['--workspace', str(workspace), *form]
            code, output, diagnostic, row = _console(binding, arguments, remaining)
            _require(code == 0, 'A real installed docs console form failed.')
            if '--format' in form:
                value = json.loads(output)
                _require(value.get('status') == 'PASS' and value['result']['mode'] == 'text'
                         and value['result']['text'] == terminal
                         and value['result']['path'] == str(resources / 'user-guide.txt') and not diagnostic,
                         'Real installed docs JSON does not contain the selected packaged terminal guide.')
            else:
                _require(output == terminal and ('--text' not in form or not diagnostic),
                         'Real installed docs did not emit its exact packaged terminal guide.')
            _require(not missing.exists() and launcher_checks._sha(station) == station_hash
                     and {path.name for path in invalid.iterdir()} == {'station.json'},
                     'Reading documentation changed or initialized a station.')
            _no_station_imports()
            calls.append(row)
    origins = {}
    for name in ('satgs', 'satgs._operator_contract', 'satgs.operator_presentation',
                 'satgs.operator_cli', 'satgs.operator_docs'):
        module = importlib.import_module(name)
        path = Path(module.__file__)
        _require(path.parent == site / 'satgs' and not path.is_symlink(), 'Docs imported outside the selected package.')
        origins[name] = dict(path=str(path), sha256=_bound(path, binding))
    _no_station_imports()
    return dict(status='PASS', scope='real-installed-headless-guide-with-source-guide-access-denied',
        candidate_version=version, installed_origins=origins, resources=output_hashes,
        manifest=dict(path=str(manifest_path), sha256=launcher_checks._sha(manifest_path)),
        internal_links=len(document.fragments), local_assets=sorted(document.assets),
        optional_external_references=sorted(document.optional_links), actual_installed_cli_calls=calls,
        output_bytes=MAX_OUTPUT - remaining[0], station_preserved=True, owner_modules_loaded=False,
        viewer_execution=False, subprocess_execution=False, execution='Real installed console source through runpy; no OS exec.')


def _field(document, path):
    _require(type(path) is str and re.fullmatch(r'[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+){0,15}', path),
             'An example assertion field is invalid.')
    value = document
    for part in path.split('.'):
        if type(value) is list:
            _require(part.isdigit() and int(part) < len(value), 'An example list field is absent.')
            value = value[int(part)]
        else:
            _require(type(value) is dict and part in value, 'An example result field is absent.')
            value = value[part]
    return value


def _substitute(value, substitutions):
    _require(type(value) is str and len(value) <= 4096, 'An example argument is invalid.')
    if value.startswith('$'):
        _require(value[1:] in substitutions, 'An example substitution is unresolved.')
        return substitutions[value[1:]]
    return value


def _optional_sha(path):
    return launcher_checks._sha(path) if path.exists() else None


def run_examples(binding, scratch):
    scratch = Path(scratch)
    launcher_checks._directory(scratch)
    home = scratch / 'home'
    preparation_path = scratch / 'launcher-preparation.json'
    preparation, _ = _read_json(preparation_path, 65536)
    protected = {str(path): launcher_checks._sha(path)
                 for path in (*launcher_checks._managed(home), preparation_path)}
    identities = launcher_checks._identities(binding)
    source = Path(binding['launcher_source']) / 'daily.py'
    directories = {str(path): launcher_checks._directory(path) for path in (scratch, home, home / 'satgs')}
    _require(preparation['status'] == 'PASS' and preparation['home'] == str(home)
             and preparation['identities'] == identities and preparation['directories'] == directories
             and preparation['source'] == dict(path=str(source), sha256=binding['inputs'][str(source)])
             and preparation['generated'] == {str(path): protected[str(path)] for path in launcher_checks._managed(home)},
             'Worked examples do not have the admitted launcher preparation.')
    dispatcher = launcher_checks._managed(home)[0]
    daily = launcher_checks._module(dispatcher, 'guide_examples_prepared_daily')
    version = binding['expected_distributions']['satgs']
    selection_path = home / '.config/satgs/operator.json'
    selection, _ = _read_json(selection_path, 4096)
    _require(daily.registered() == identities and selection == dict(schema=daily.SCHEMA,
             application=binding['application'], candidate_version=version, workspace=str(home / 'satgs/station'))
             and (home / 'satgs/station/station.json').is_file(),
             'Worked examples require the marked disposable default station fixture.')
    station_path = home / 'satgs/station/station.json'
    default_station_hash = launcher_checks._sha(station_path)
    script_path = Path(binding['tests']) / 'operator_guide_examples.json'
    script, raw = _read_json(script_path)
    script_hash = _bound(script_path, binding)
    _require(set(script) == {'schema', 'scope', 'substitutions', 'global_arguments', 'steps', 'custom_changes'}
             and script['schema'] == 'satgs-guide-examples.v1'
             and set(script['substitutions']) == {'WORKSPACE', 'TLE', 'REPORT', 'CUSTOM'}
             and script['global_arguments'] == ['--workspace', '$WORKSPACE', '--format', 'json']
             and type(script['steps']) is list and 24 <= len(script['steps']) <= 40,
             'The worked-example script is outside its reviewed finite sequence bound.')
    workspace = scratch / 'practice station'
    tle = scratch / 'NOAA 15 historical.csv'
    report = scratch / 'practice report.json'
    custom = scratch / 'custom-components.json'
    _require(all(not path.exists() and not path.is_symlink() for path in (workspace, tle, report, custom)),
             'Worked-example paths must be newly absent scratch children.')
    installed_tle = Path(binding['application']) / 'lib/python3.11/site-packages/satgs/data/operator_tle.csv'
    tle_hash = _bound(installed_tle, binding)
    _new_private(tle, installed_tle.read_bytes())
    _require(launcher_checks._sha(tle) == tle_hash, 'The local worked-example TLE copy differs from the installed resource.')
    omitted = {'orchestration.queue_manager', 'execution.pass_runner', 'pixhawk', 'pointing.pixhawk',
               'pointing.dual_gps', 'network.connectivity', 'rf.frontend', 'power.pdu_hpa',
               'recording.signal_hound', 'processing.msel_post_processing'}
    _require(script['custom_changes'] == dict.fromkeys(omitted, 'omit'),
             'The Custom example changed its reviewed limited-selection fixture.')
    _new_private(custom, (json.dumps(script['custom_changes'], sort_keys=True) + '\n').encode('utf-8'))
    custom_hash = launcher_checks._sha(custom)
    substitutions = dict(WORKSPACE=str(workspace), TLE=str(tle), REPORT=str(report), CUSTOM=str(custom))
    remaining, calls, names, report_value = [MAX_OUTPUT], [], set(), None
    commands = {'init', 'status', 'components-preview', 'apply', 'reload', 'location-preview',
                'cancel', 'plan', 'replay', 'report', 'export'}
    allowed = {'name', 'argv', 'exit', 'equals', 'capture', 'station_unchanged', 'tle_unchanged',
               'nonempty', 'different_from', 'output_mode', 'report_unchanged'}
    for step in script['steps']:
        _require(type(step) is dict and set(step) <= allowed and {'name', 'argv', 'exit'} <= set(step)
                 and type(step['name']) is str and step['name'] not in names
                 and type(step['argv']) is list and 0 < len(step['argv']) <= 40
                 and step['argv'][0] in commands and type(step['exit']) is int,
                 'An example step is outside the reviewed offline command scope.')
        names.add(step['name'])
        arguments = [_substitute(value, substitutions) for value in (*script['global_arguments'], *step['argv'])]
        before = dict(station=_optional_sha(workspace / 'station.json'), tle=launcher_checks._sha(tle),
                      report=_optional_sha(report))
        interpreter, plan, environment = daily.launch_plan('cli', arguments, selection_path)
        prefix = [str(Path(binding['application']) / 'bin/python'), '-I', '-B',
                  str(Path(binding['application']) / 'bin/satgs-operator')]
        _require(interpreter == prefix[0] and plan == prefix + arguments
                 and environment.get('STOMP_SKIP_HOSTNAME_SCAN') == '1'
                 and environment.get('PYTHONNOUSERSITE') == '1', 'An example launch plan left the selected application.')
        code, output, diagnostic, row = _console(binding, plan[4:], remaining)
        _require(code == step['exit'] and not diagnostic, 'A real installed example command returned an unexpected outcome.')
        document = json.loads(output)
        _require(document.get('status') == ('PASS' if code == 0 else 'FAIL'), 'An example JSON status contradicts its exit.')
        for field, expected in step.get('equals', {}).items():
            actual = _field(document, field)
            expected = _substitute(expected, substitutions) if type(expected) is str else expected
            _require(type(actual) is type(expected) and actual == expected,
                     'An example field differs from its explicit expected value: ' + step['name'] + ':' + field)
        for field in step.get('nonempty', []):
            _require(bool(_field(document, field)), 'An example expected nonempty output: ' + step['name'] + ':' + field)
        for field, previous in step.get('different_from', {}).items():
            _require(_field(document, field) != _substitute(previous, substitutions),
                     'An example expected changed planning identity: ' + step['name'] + ':' + field)
        for name, field in step.get('capture', {}).items():
            value = _field(document, field)
            _require(re.fullmatch(r'[A-Z][A-Z0-9_]{0,63}', name) and name not in substitutions
                     and type(value) is str and HEX_ID.fullmatch(value), 'An example capture is not a new exact identity.')
            substitutions[name] = value
        if step.get('station_unchanged'):
            _require(_optional_sha(workspace / 'station.json') == before['station'], 'A read-only example changed station bytes.')
        if step.get('tle_unchanged'):
            _require(launcher_checks._sha(tle) == before['tle'] == tle_hash, 'Planning changed its explicit local TLE input.')
        if step.get('report_unchanged'):
            _require(_optional_sha(report) == before['report'], 'A rejected export changed the retained report.')
        if 'output_mode' in step:
            _require(step['output_mode'] == '0600' and stat.S_ISREG(report.lstat().st_mode)
                     and stat.S_IMODE(report.stat().st_mode) == 0o600 and report.stat().st_uid == os.geteuid(),
                     'The exported report is not a new private owned ordinary file.')
            exported, _ = _read_json(report)
            _require(report_value is not None and exported == report_value, 'Exported report differs from the inspected report.')
        if step['argv'][0] == 'report':
            report_value = document['result']
        _require(launcher_checks._sha(station_path) == default_station_hash
                 and launcher_checks._sha(custom) == custom_hash
                 and all(launcher_checks._sha(path) == digest for path, digest in protected.items()),
                 'A worked example changed daily launchers, selection or the disposable default station.')
        row.update(name=step['name'], launcher_plan=plan, interpreter=interpreter,
                   launcher_environment_applied=False, expected_exit=step['exit'])
        calls.append(row)
    _require(launcher_checks._sha(tle) == tle_hash and report_value is not None, 'Worked-example input or report verification is incomplete.')
    return dict(status='PASS', schema=script['schema'], script=dict(path=str(script_path), bytes=len(raw), sha256=script_hash),
        steps=len(calls), actual_installed_cli_calls=calls, substitutions=substitutions,
        source_tle=dict(path=str(installed_tle), sha256=tle_hash), local_tle=dict(path=str(tle), sha256=tle_hash),
        report=dict(path=str(report), sha256=launcher_checks._sha(report), mode='0600'),
        custom_changes=dict(path=str(custom), sha256=custom_hash, scope='Component selection only; no owner or run readiness.'),
        protected=protected, daily_station_untouched=True, output_bytes=MAX_OUTPUT - remaining[0],
        execution='Real generated launch_plan and installed console runpy under the existing guard; no OS exec or environment application.',
        unsupported_scope='No legacy, service, broker, device, live owner or physical completion execution.')
