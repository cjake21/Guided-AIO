"""Disclosed primitive fixtures only; no owner, protobuf or encoder replacements."""
import csv
from datetime import datetime, timezone
import json
import math
import sys
from types import ModuleType
guard = None

NAMES = ('yaml', 'ephem', 'numpy', 'pandas', 'pytz', 'logging_tree',
         'niquests', 'scipy', 'scipy.interpolate', 'serial')
CALLS = []


def unexpected(*args, **kwargs):
    raise AssertionError('unsupported primitive fixture operation')


class Date(float):
    def __new__(cls, value=0):
        if isinstance(value, datetime):
            value = value.replace(tzinfo=value.tzinfo or timezone.utc).timestamp() / 86400
        return super().__new__(cls, value)

    def datetime(self):
        return datetime.fromtimestamp(float(self) * 86400, tz=timezone.utc).replace(tzinfo=None)


class Observer:
    def __init__(self):
        self.date = datetime.now(timezone.utc)

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, value):
        self._date = Date(value)

    def next_pass(self, body):
        raise ValueError('synthetic circumpolar fixture')


class Body:
    def compute(self, observer):
        self.az = (float(observer.date) % 1) * math.pi
        self.alt = math.pi / 3
        self.range = 1000.0
        self.range_velocity = 0.0


def readtle(name, line1, line2):
    CALLS.append('ephem.readtle')
    if not name or not line1.startswith('1 ') or not line2.startswith('2 '):
        raise ValueError('invalid synthetic TLE interface')
    return Body()


class Array(list):
    @property
    def shape(self):
        return len(self)


class Frame:
    def __init__(self, rows):
        self.rows = rows

    def set_index(self, column):
        self.column = column
        return self

    def to_dict(self, orientation):
        if orientation != 'index':
            unexpected()
        return {row[self.column]: {key: value for key, value in row.items() if key != self.column}
                for row in self.rows}


def read_csv(path):
    CALLS.append('pandas.read_csv')
    with open(path, newline='') as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        if 'norad_id' in row:
            row['norad_id'] = int(row['norad_id'])
    return Frame(rows)


def json_yaml(value):
    CALLS.append('yaml.safe_load-json-only')
    return json.load(value) if hasattr(value, 'read') else json.loads(value)


def dump(value, stream, **kwargs):
    CALLS.append('yaml.dump-json-only')
    json.dump(value, stream)


def zone(name):
    if name not in ('UTC', 'US/Eastern'):
        unexpected()
    return timezone.utc


def no_native_serial(*args, **kwargs):
    guard.deny('native serial construction without explicit recording fixture')


class SerialException(OSError):
    pass


def module(name, **attributes):
    result = ModuleType(name)
    result.__dict__.update(attributes)
    result.__fixture_source__ = __file__
    return result


def install(active_guard):
    global guard
    from candidate_guard import CandidateGuard
    if type(active_guard) is not CandidateGuard or active_guard.phase != 'runtime' or any(name in sys.modules for name in NAMES):
        raise RuntimeError('primitive fixture activation outside admitted clean owner lane')
    guard = active_guard
    modules = {
        'yaml': module('yaml', safe_load=json_yaml, dump=dump),
        'ephem': module('ephem', Observer=Observer, Date=Date, readtle=readtle, degree=math.pi / 180),
        'numpy': module('numpy', ndarray=Array, array=lambda values: Array(values),
                        zeros=lambda size: Array([0] * size), pi=math.pi, floor=math.floor,
                        nan=math.nan, argmax=lambda values: max(range(len(values)), key=values.__getitem__)),
        'pandas': module('pandas', read_csv=read_csv),
        'pytz': module('pytz', timezone=zone),
        'logging_tree': module('logging_tree', printout=unexpected),
        'niquests': module('niquests', get=unexpected, post=unexpected),
        'scipy': module('scipy', __path__=[]),
        'scipy.interpolate': module('scipy.interpolate', CubicSpline=unexpected, interp1d=unexpected),
        'serial': module('serial', Serial=no_native_serial, SerialException=SerialException),
    }
    if tuple(modules) != NAMES:
        raise RuntimeError('primitive fixture inventory drift')
    modules['scipy'].interpolate = modules['scipy.interpolate']
    sys.modules.update(modules)
    guard.PRIMITIVE_FIXTURES = {'names': list(NAMES), 'source': __file__,
                               'owner_replacements': [], 'protobuf_replacements': [],
                               'encoder_replacements': []}

    def cleanup():
        for name, fixture in modules.items():
            if sys.modules.get(name) is not fixture:
                raise RuntimeError('primitive module identity changed')
            del sys.modules[name]
        guard.PRIMITIVE_FIXTURES['calls'] = list(CALLS)
        guard.PRIMITIVE_FIXTURES['released'] = True
    return cleanup

