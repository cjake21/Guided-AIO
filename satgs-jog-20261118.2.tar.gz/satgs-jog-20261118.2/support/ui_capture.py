"""Fixed host-owned framebuffer captures for the native UI test checkpoints."""

import hashlib
import os
from pathlib import Path
import stat
import struct
import zlib


LABELS = ('setup', 'location', 'results', 'run', 'ptu')
MAX_BYTES = 8 * 1024 * 1024
SCREEN = (1280, 900)
_scratch = None
_enabled = False
_records = []


def configure(scratch, *, enabled):
    global _scratch, _enabled
    if _scratch is not None or type(enabled) is not bool:
        raise RuntimeError('UI capture must be configured once.')
    path = Path(scratch)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('UI capture requires the bound native scratch.')
    _scratch, _enabled = path, enabled


def _frame():
    path = _scratch / 'framebuffer/Xvfb_screen0'
    for parent in (path.parent, *path.parent.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Framebuffer ancestry is not ordinary.')
        if parent == _scratch:
            break
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(descriptor)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid()
                or stat.S_IMODE(before.st_mode) != 0o600 or not 100 <= before.st_size <= MAX_BYTES):
            raise RuntimeError('Framebuffer shape is outside the fixed host policy.')
        data = bytearray()
        while len(data) <= before.st_size:
            chunk = os.read(descriptor, min(65536, before.st_size + 1 - len(data)))
            if not chunk:
                break
            data.extend(chunk)
        after = os.fstat(descriptor)
        identity = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_uid,
                                  value.st_gid, value.st_size, value.st_ctime_ns)
        if len(data) != before.st_size or identity(before) != identity(after):
            raise RuntimeError('Framebuffer changed identity during capture.')
        return bytes(data)
    finally:
        os.close(descriptor)


def _png(frame, bounds):
    header = struct.unpack('!25I', frame[:100])
    (header_size, version, pixmap_format, depth, width, height, xoffset, byte_order,
     bitmap_unit, bitmap_order, bitmap_pad, bits_per_pixel, stride, visual,
     red, green, blue, bits_per_rgb, colormap_entries, colors, window_width,
     window_height, window_x, window_y, border) = header
    if (version != 7 or pixmap_format != 2 or depth != 24 or (width, height) != SCREEN
            or xoffset != 0 or byte_order not in (0, 1) or bits_per_pixel != 32
            or visual != 4 or (red, green, blue) != (0xff0000, 0xff00, 0xff)
            or not 100 <= header_size <= 4096 or not 0 <= colors <= 4096
            or stride != width * 4 or (window_width, window_height) != SCREEN):
        raise RuntimeError('Unsupported owned Xvfb framebuffer format.')
    offset = header_size + colors * 12
    if len(frame) != offset + stride * height:
        raise RuntimeError('Framebuffer length does not match its header.')
    left, top, crop_width, crop_height = bounds
    if (not all(type(value) is int for value in bounds) or min(left, top) < 0
            or crop_width <= 0 or crop_height <= 0 or left + crop_width > width
            or top + crop_height > height or crop_width * crop_height > width * height):
        raise RuntimeError('Actual UI rectangle leaves the owned framebuffer.')
    pixels, rows = memoryview(frame), bytearray()
    red_index, green_index, blue_index = (2, 1, 0) if byte_order == 0 else (1, 2, 3)
    for row in range(top, top + crop_height):
        start = offset + row * stride + left * 4
        source = pixels[start:start + crop_width * 4]
        rgb = bytearray(crop_width * 3)
        rgb[0::3], rgb[1::3], rgb[2::3] = source[red_index::4], source[green_index::4], source[blue_index::4]
        rows.append(0)
        rows.extend(rgb)

    def chunk(kind, data):
        return struct.pack('!I', len(data)) + kind + data + struct.pack('!I', zlib.crc32(kind + data) & 0xffffffff)

    result = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('!2I5B', crop_width, crop_height, 8, 2, 0, 0, 0))
              + chunk(b'IDAT', zlib.compress(rows, 6)) + chunk(b'IEND', b''))
    if len(result) > MAX_BYTES:
        raise RuntimeError('UI PNG exceeds its finite output limit.')
    return result


def capture(root, label):
    if _scratch is None or label not in LABELS or any(row['label'] == label for row in _records):
        raise RuntimeError('Unexpected or repeated UI capture checkpoint.')
    if not _enabled:
        row = dict(label=label, status='NOT CAPTURED', reason='No owned host framebuffer; widget assertions remain active.')
        _records.append(row)
        return row
    root.update_idletasks()
    root.update()
    if not root.winfo_ismapped():
        raise RuntimeError('Cannot capture an unmapped native UI.')
    bounds = (root.winfo_rootx(), root.winfo_rooty(), root.winfo_width(), root.winfo_height())
    first = _frame()
    for _ in range(3):
        second = _frame()
        if first == second:
            break
        first = second
    else:
        raise RuntimeError('Owned framebuffer did not settle within the capture budget.')
    data = _png(second, bounds)
    directory = _scratch / 'screenshots'
    if not _records:
        directory.mkdir(mode=0o700)
    path = directory / (label + '.png')
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    row = dict(label=label, status='CAPTURED', relative='screenshots/' + path.name,
               bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), rectangle=list(bounds),
               tk_scaling=float(root.tk.call('tk', 'scaling')), screen=list(SCREEN),
               source='Actual root pixels from this invocation\'s private Xvfb framebuffer')
    _records.append(row)
    return row


def finish():
    if _enabled and {row['label'] for row in _records} != set(LABELS):
        raise RuntimeError('The owned host UI test did not produce every fixed capture.')
    return dict(status='PASS' if _enabled else 'NOT CAPTURED', owned_host=_enabled,
                checkpoints=list(_records), expected_labels=list(LABELS), max_png_bytes=MAX_BYTES)
