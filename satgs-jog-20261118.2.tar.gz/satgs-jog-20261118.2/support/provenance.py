"""Diagnostic history is separate from current execution consistency."""

import hashlib
import os
from pathlib import Path
import stat


def identity(path):
    path = Path(path)
    link = path.lstat()
    target = path.stat()
    if not stat.S_ISREG(target.st_mode):
        raise RuntimeError('required input is not an ordinary file: ' + str(path))
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    return dict(link=[getattr(link, key) for key in fields],
                target=[getattr(target, key) for key in fields],
                symlink=os.readlink(path) if stat.S_ISLNK(link.st_mode) else None)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def warning(path, reason, expected=None, observed=None):
    return dict(path=str(path), reason=reason, expected=expected, observed=observed,
                blocking=False, role='provenance only; not functional acceptance')


def private_authority(path):
    selected = os.environ.get('XAUTHORITY')
    home = os.environ.get('HOME')
    candidates = [Path(selected)] if selected else []
    if home:
        candidates.append(Path(home) / '.Xauthority')
    for candidate in candidates:
        if Path(path).absolute() == candidate.absolute():
            return True
        try:
            if Path(path).samefile(candidate):
                return True
        except OSError:
            pass
    return False


def compare(path, expected):
    if private_authority(path):
        return [warning(path, 'private desktop authentication excluded from diagnostic hashing')]
    observed = digest(path)
    return [] if expected == observed else [warning(path, 'recorded digest differs', expected, observed)]


def current(binding):
    warnings = []
    for name, expected in binding['input_identities'].items():
        if identity(name) != expected:
            raise RuntimeError('required input replaced or modified during this attempt: ' + name)
    for name, expected in binding['inputs'].items():
        if expected is not None:
            warnings.extend(compare(name, expected))
    return warnings


def optional_checksums(root):
    root = Path(root)
    path = root / 'SHA256SUMS'
    if private_authority(path):
        return [warning(path, 'optional checksum inventory overlaps private desktop authentication; not read')]
    if not path.is_file() or any(item.is_symlink() for item in (path, *path.parents)):
        return [warning(path, 'optional checksum inventory absent')]
    warnings = []
    try:
        if path.stat().st_size > 1024 * 1024:
            return [warning(path, 'optional checksum inventory exceeds diagnostic limit')]
        with path.open('rb') as stream:
            raw = stream.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            return [warning(path, 'optional checksum inventory exceeds diagnostic limit')]
        seen = set()
        for line in raw.decode('ascii').splitlines():
            expected, name = line.split('  ', 1)
            candidate = Path(name)
            if (len(expected) != 64 or any(c not in '0123456789abcdef' for c in expected)
                    or candidate.is_absolute() or '..' in candidate.parts or name in seen):
                warnings.append(warning(path, 'optional checksum inventory has an invalid row'))
                continue
            seen.add(name)
            selected = root / candidate
            if (selected.is_file() and not any(item.is_symlink() for item in (selected, *selected.parents))
                    and root.resolve() in selected.resolve().parents):
                warnings.extend(compare(selected, expected))
            else:
                warnings.append(warning(selected, 'optional checksum entry is unavailable'))
    except (OSError, UnicodeError, ValueError) as error:
        warnings.append(warning(path, 'optional checksum inventory unreadable: ' + type(error).__name__))
    return warnings


def summary(warnings):
    unique = []
    for row in warnings:
        if row not in unique:
            unique.append(row)
    return dict(status='WARN' if unique else 'OBSERVED', warnings=unique[:32],
                warning_count=len(unique), additional_warnings=max(0, len(unique) - 32),
                historical_byte_identity='NOT ESTABLISHED by this functional run',
                policy='Digest differences and missing optional checksums do not change functional status or exit.')
