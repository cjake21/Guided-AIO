"""Fixed guarded candidate acceptance child. No service or hardware lane exists."""

import argparse
import ast
from contextlib import redirect_stdout
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import site
import sys
import tempfile
import traceback
import types
import unittest

HERE = Path(__file__).resolve().parent
LANES = {
    'docs': ('test_operator_docs',),
    'guide-content': ('test_operator_guide_content',),
    'presenter': ('test_operator_gui.HeadlessOperatorPresenterTests',),
    'core-cli': ('test_operator_core', 'test_operator_activity', 'test_operator_cli', 'test_operator_presentation'),
    'planning': ('test_operator_planning',),
    'regression': ('test_station_location', 'test_station_location_cli',
                   'test_runtime_configuration', 'test_pass_runner_capabilities', 'test_deployment_plan'),
    'runtime-integration': ('test_operator_runtime.SelectedOperatorPassTests',
                           'test_operator_runtime.OperatorRuntimeRequestTests', 'test_operator_runtime_binding'),
    'bench': ('test_ptu_bench', 'test_ptu_bench_transport', 'test_operator_bench_cli',
              'test_operator_bench_interface.HeadlessBenchInterfaceTests'),
    'owner-regression': ('test_ptu_client_lifecycle', 'test_ptu_manager_pointing', 'test_prepared_pointing', 'test_serial_acquisition'),
    'messenger-regression': ('test_messenger_lifecycle',),
    'lower-regression': ('test_bounded_protocol', 'test_bounded_transport'),
    'source-workflow': ('test_source_workflow',),
    'native-widgets': ('test_operator_gui.NativeOperatorWidgetTests',
                       'test_operator_bench_interface.NativeBenchInterfaceTests'),
}
EXCLUDED = frozenset((
    'test_actual_module_child_propagates_guard_and_indeterminate_exit',
    'test_actual_module_child_unsupported_owner_exit_is_three',
    'test_actual_module_child_invalid_input_exit_is_two',
))


WARNINGS = []


def load(path, name, expected=None):
    raw = path.read_bytes()
    if expected is not None and hashlib.sha256(raw).hexdigest() != expected:
        WARNINGS.append(dict(path=str(path), reason='recorded support digest differs', blocking=False))
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec', dont_inherit=True), vars(module))
    return module


def tests(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from tests(item)
        else:
            yield item


def cli_examples(scratch):
    from satgs.operator_cli import main
    root = scratch / 'documented-practice'
    examples = []
    def dispatch(arguments, expected=0):
        arguments = ['--workspace', str(root), '--format', 'json', *arguments]
        stream = io.StringIO()
        with redirect_stdout(stream):
            try:
                returned = main(arguments)
            except SystemExit as error:
                returned = error.code
        if returned != expected:
            raise AssertionError('documented CLI dispatch returned an unexpected exit')
        text = stream.getvalue()
        examples.append(dict(arguments=arguments, exit=returned, output=text))
        return json.loads(text) if text.lstrip().startswith('{') else None
    dispatch(['--help'])
    dispatch(['init'])
    dispatch(['status'])
    dispatch(['components-preview', '--profile', 'guided_arrow'])
    coordinates = ['--latitude-deg', '42.0', '--longitude-deg', '-71.0', '--altitude-m', '12.5',
                   '--altitude-reference', 'unspecified']
    pending = dispatch(['location-preview', *coordinates])['result']
    dispatch(['apply', '--preview', pending['preview_id'], '--confirm'])
    dispatch(['reload'])
    dispatch(['plan'])
    pending = dispatch(['location-preview', *coordinates])['result']
    dispatch(['cancel', '--preview', pending['preview_id']])
    dispatch(['report'])
    dispatch(['export', '--output', str(scratch / 'documented-report.json')])
    dispatch(['location-preview', '--latitude-deg', 'nan', '--longitude-deg', '0', '--altitude-m', '0',
              '--altitude-reference', 'unspecified'], expected=2)
    return dict(status='PASS', examples=examples, tests=len(examples), skipped=[], exclusions=[])


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--lane', choices=('controls', 'static', 'installed', 'docs-examples', 'launcher', *LANES), required=True)
    parser.add_argument('--scratch', type=Path, required=True)
    parser.add_argument('--launcher-followup', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.launcher_followup and args.lane != 'launcher':
        raise RuntimeError('Launcher follow-up is confined to its fixed lane.')
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise RuntimeError('use the fixed isolated no-site child startup')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    if resource.getrlimit(resource.RLIMIT_CORE) != (0, 0):
        raise RuntimeError('selected check child could not apply its process core-file limit')
    if sys.version_info[:3] not in ((3, 11, 16), (3, 11, 2)):
        raise RuntimeError('supported CPython profiles are host3.11.16 and Pi3.11.2')
    provenance = load(HERE / 'provenance.py', 'operator_provenance')
    target = load(HERE / 'pi_target.py', 'pi_target')
    binding = target.parse_json(target.read(args.binding, limit=32 * 1024 * 1024))
    if (binding.get('schema') != 'operator-candidate-acceptance.v2'
            or binding.get('hardware_enabled') is not False or binding.get('network_enabled') is not False
            or binding.get('services_enabled') is not False
            or set(binding['inputs']) != set(binding['input_identities'])):
        raise RuntimeError('invalid restricted acceptance binding')
    WARNINGS.extend(provenance.current(binding))
    application = Path(binding['application'])
    if Path(sys.executable) != Path(binding['interpreter']):
        raise RuntimeError('wrong candidate application interpreter')
    expected_path = [str(Path(binding['runtime']) / name) for name in
                     ('lib/python311.zip', 'lib/python3.11', 'lib/python3.11/lib-dynload')]
    if sys.path != expected_path or site.ENABLE_USER_SITE is not None:
        raise RuntimeError('application site initialized before protection')
    if binding['startup_tree'] is not None:
        if binding['runtime_profile'] != 'compatible-pi-cpython3112-semantic-startup' or sys.version_info[:3] != (3, 11, 2):
            raise RuntimeError('Pi runtime profile/version mismatch')
        target.target_facts()
        target.require(target.live_startup_policy(binding['startup_tree'], application) is True,
                       'target startup semantic/ownership policy is unsupported')
    elif binding['runtime_profile'] != 'compatible-host-cpython31116-no-startup-hooks' or sys.version_info[:3] != (3, 11, 16):
        raise RuntimeError('host runtime profile/version mismatch')
    if dict(os.environ) != binding['environments'][args.lane]:
        raise RuntimeError('child environment differs from admitted binding')
    package_site = target.startup_policy(application)
    for name in ('pi_guard', 'ctypes_initialization', 'behavior_guard', 'candidate_guard'):
        load(HERE / (name + '.py'), name)
    graphical = args.lane == 'native-widgets'
    if graphical and (binding.get('native_display') is None
                      or os.environ.get('DISPLAY') != binding['native_display']['display']):
        raise RuntimeError('native child requires the explicitly selected local display')
    guard_type = sys.modules['candidate_guard'].CandidateGuard
    admitted_inputs = binding['inputs']
    if args.lane == 'docs':
        excluded_roots = tuple(str(Path(binding['source']) / name) + '/' for name in ('src', 'docs'))
        admitted_inputs = {name: digest for name, digest in admitted_inputs.items()
                           if not name.startswith(excluded_roots)}
    guard = guard_type(admitted_inputs, set(binding['directories']), set(binding['native']),
                       Path(binding['runtime']) / 'lib/python3.11', package_site,
                       args.scratch, binding['public_utc'], binding['runtime_profile'],
                       binding['scipy_rpath_absence'], graphical=graphical,
                       numpy_metadata=binding['numpy_optional_metadata'])
    tempfile.tempdir = str(args.scratch)
    outcome = None
    desktop_control = None
    unit_cleanup = None
    if args.lane == 'owner-regression':
        os.environ['PTU_TEST_OUTPUT'] = str(args.scratch)
    try:
        guard.activate()
        negative_controls = guard.probes()
        startup = target.initialize_site(application, expected_path, [package_site], startup_tree=binding['startup_tree'])
        if args.lane == 'owner-regression':
            primitives = load(HERE / 'owner_unit_primitives.py', 'owner_unit_primitives')
            unit_cleanup = primitives.install(guard)
        sys.path.insert(0, binding['tests'])
        sys.path.append(binding['workflow_tests'])
        sys.path.extend(binding.get('component_tests', ()))
        if graphical:
            desktop = load(HERE / 'desktop_display.py', 'operator_desktop')
            guard.bind_desktop(desktop._loaded_native_origins)
            guard.bind_desktop_environment(desktop._restore_native_environment)
            desktop_control = desktop.install(binding['native_display'], guard=guard)
            capture = load(HERE / 'ui_capture.py', 'ui_capture')
            capture.configure(args.scratch, enabled=binding['native_display'].get('framebuffer_capture') is True)
        if args.lane not in ('controls', 'static', 'installed', 'docs', 'guide-content') and not binding.get('startup_diagnostic'):
            __import__('satgs.operator_core')
            guard.bind_readers()
        if args.lane == 'controls':
            outcome = dict(status='PASS', scope='effect controls before product discovery', tests=0,
                           executed_product_source=False)
        elif graphical and binding.get('startup_diagnostic'):
            root = desktop_control.tk.Tk()
            root.destroy()
            outcome = dict(status='BLOCKED', scope='single protected Tk startup diagnostic; not acceptance', tests=0,
                           native_test_methods_attempted=0)
        elif args.lane == 'static':
            sources = sorted(Path(binding['source']).rglob('*.py'))
            for path in sources:
                payload = path.read_bytes()
                compile(payload, str(path), 'exec', dont_inherit=True)
                ast.parse(payload, filename=str(path), feature_version=(3, 11))
            outcome = dict(status='PASS', scope='source-only-current-runtime-compile-and-Python3.11-grammar',
                           files=len(sources), executed_product_source=False)
        elif args.lane == 'installed':
            checker = load(HERE / 'installed_check.py', 'candidate_installed_check')
            outcome = checker.check(binding)
            WARNINGS.extend(outcome.pop('provenance_warnings', ()))
        elif args.lane == 'docs-examples':
            load(HERE / 'launcher_checks.py', 'launcher_checks')
            checks = load(HERE / 'docs_checks.py', 'guide_examples_checks')
            outcome = dict(status='PASS', tests=0, examples=checks.run_examples(binding, args.scratch))
        elif args.lane == 'launcher':
            checks = load(HERE / 'launcher_checks.py', 'launcher_checks_child')
            outcome = dict(status='PASS', tests=0, scope='guarded disposable actual CLI composition',
                           launcher_checks=checks.check(binding, args.scratch, followup=args.launcher_followup))
        else:
            selected, excluded = [], []
            for name in LANES[args.lane]:
                for case in tests(unittest.defaultTestLoader.loadTestsFromName(name)):
                    if args.lane == 'regression' and case.id().rsplit('.', 1)[-1] in EXCLUDED:
                        excluded.append(case.id())
                    else:
                        selected.append(case)
            if not selected:
                raise RuntimeError('required lane discovered no tests')
            if graphical and len(selected) != desktop.NATIVE_TESTS:
                raise RuntimeError('required native lane must discover every selected widget test')
            result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
            outcome = dict(status='FAIL' if not result.wasSuccessful() else 'BLOCKED' if result.skipped else 'PASS',
                           tests=result.testsRun, test_ids=[case.id() for case in selected],
                           failures=len(result.failures), errors=len(result.errors),
                           skipped=[dict(test=case.id(), reason=reason) for case, reason in result.skipped],
                           exclusions=excluded)
            if args.lane == 'docs' and outcome['status'] == 'PASS':
                load(HERE / 'launcher_checks.py', 'launcher_checks')
                checks = load(HERE / 'docs_checks.py', 'installed_guide_checks')
                outcome['installed_docs'] = checks.check_installed_docs(binding, args.scratch)
        if args.lane == 'presenter' and 'tkinter' in sys.modules:
            raise RuntimeError('headless presenter imported Tk')
        if args.lane == 'planning' and len(guard.ctypes_init.observations) != 1:
            raise RuntimeError('scientific lane did not exercise admitted real native initialization')
        if desktop_control is not None:
            outcome['ui_screenshots'] = capture.finish()
            if binding.get('startup_diagnostic'):
                outcome['startup_context'] = [app.startup_context() for app in desktop_control.apps]
            outcome['desktop_controls'] = desktop_control.finish()
            desktop_control = None
            if outcome['desktop_controls'].get('status') != 'PASS':
                raise RuntimeError('native desktop protection or cleanup did not pass; retained receipt describes the failure')
        outcome.update(native_test_lane_executed=graphical and outcome.get('tests', 0) > 0,
                       native_test_methods_attempted=outcome.get('tests', 0) if graphical else 0)
        if unit_cleanup is not None:
            unit_cleanup()
            unit_cleanup = None
            outcome['unit_primitives'] = guard.PRIMITIVE_FIXTURES
            outcome['derived_unit_environment'] = {'PTU_TEST_OUTPUT': str(args.scratch)}
        receipts = guard.finish_candidate()
        outcome.update(lane=args.lane, site=startup, negative_controls=negative_controls,
                       core_file_rlimit=list(resource.getrlimit(resource.RLIMIT_CORE)),
                       controls=receipts, runtime_denials=[], native_widgets_passed=graphical and outcome['status'] == 'PASS')
    except BaseException as error:
        traceback.print_exc()
        outcome = dict(outcome or {}, status='FAIL', lane=args.lane, runner_error=type(error).__name__,
                       error_message=''.join(c if c.isprintable() else ' ' for c in str(error))[:2000],
                       runtime_denials=[row for row in guard.denials if row['phase'] != 'negative'],
                       cache_absence=guard.cache_receipts(),
                       denial_diagnostics=guard.effect_diagnostics,
                       numpy_optional_metadata=dict(reads=guard.numpy_reads, limit=1,
                                                    observations=guard.numpy_receipts),
                       native_widgets_passed=False, guard_overflow=guard.overflow)
        if desktop_control is not None:
            outcome['desktop_partial'] = dict(denials=desktop_control.denials,
                observations=desktop_control.observations,
                initializations=[app.tk_initialization for app in desktop_control.apps],
                native_interpreters=len(desktop_control.apps), complete_receipt=False)
        if (graphical and desktop_control is None
                and type(error) is getattr(sys.modules.get('operator_desktop'), 'DesktopUnavailable', None)):
            try:
                receipts = guard.finish_candidate()
            except BaseException as control_error:
                traceback.print_exc()
                outcome.update(status='FAIL', control_error=type(control_error).__name__,
                    error_message='unsupported desktop also failed protection finalization; see retained traceback',
                    runtime_denials=[row for row in guard.denials if row['phase'] != 'negative'],
                    denial_diagnostics=guard.effect_diagnostics, guard_overflow=guard.overflow)
            else:
                outcome.update(status='BLOCKED', controls=receipts,
                    native_test_lane_executed=False, native_test_methods_attempted=0,
                    core_file_rlimit=list(resource.getrlimit(resource.RLIMIT_CORE)))
    finally:
        if unit_cleanup is not None:
            try:
                unit_cleanup()
                outcome['unit_primitives'] = guard.PRIMITIVE_FIXTURES
                outcome['derived_unit_environment'] = {'PTU_TEST_OUTPUT': str(args.scratch)}
            except BaseException as error:
                outcome.update(status='FAIL', unit_cleanup_error=type(error).__name__)
        if desktop_control is not None:
            if binding.get('startup_diagnostic') and 'startup_context' not in outcome:
                try:
                    outcome['startup_context'] = [app.startup_context() for app in desktop_control.apps]
                except BaseException as error:
                    outcome['startup_context'] = dict(status='FAIL', error_type=type(error).__name__)
            try:
                outcome['desktop_cleanup'] = desktop_control.finish()
                if outcome['desktop_cleanup'].get('status') != 'PASS':
                    outcome.update(status='FAIL', cleanup_error='DesktopCleanupFailure')
            except BaseException as error:
                outcome.update(status='FAIL', cleanup_error=type(error).__name__)
    outcome['provenance'] = provenance.summary(WARNINGS)
    outcome['provenance_warnings'] = outcome['provenance']['warnings']
    print('OPERATOR_LANE_RESULT ' + json.dumps(outcome, sort_keys=True, allow_nan=False), flush=True)
    return 0 if outcome['status'] == 'PASS' else 78 if outcome['status'] == 'BLOCKED' else 1


if __name__ == '__main__':
    try:
        returned = main()
    except BaseException as error:
        traceback.print_exc()
        print('OPERATOR_LANE_RESULT ' + json.dumps(dict(status='FAIL', runner_error=type(error).__name__,
              error_message=''.join(c if c.isprintable() else ' ' for c in str(error))[:2000],
              native_widgets_passed=False), sort_keys=True), flush=True)
        returned = 1
    raise SystemExit(returned)
