"""The retained FastPath protocol for one genuinely absent stdlib ZIP path."""

import errno
import importlib.metadata as metadata
import os
from pathlib import Path
import sys
import types
import zipfile


class MetadataZipAbsence:
    def __init__(self, guard, stdlib):
        self.guard = guard
        self.path = str(Path(stdlib).parent / 'python311.zip')
        self.chain = guard.directory_identity(str(Path(self.path).parent))
        self.functions = (metadata.FastPath.children, metadata.FastPath.zip_children,
                          zipfile.ZipFile.__init__, zipfile.CompleteDirs.make.__func__, zipfile.Path.__init__)
        self.codes = tuple(function.__code__ for function in self.functions)
        self.counts, self.negatives, self.pending = {'os.listdir': 0, 'open': 0}, [], None
        self.require(self.chain is not None and self.path in sys.path and self.missing(),
                     'exact stdlib metadata ZIP must genuinely be absent')
        self.require(all(code.co_filename in guard.files for code in self.codes), 'metadata functions lack bound source origins')

    @staticmethod
    def require(value, message):
        if not value:
            raise RuntimeError(message)

    def missing(self):
        if self.guard.directory_identity(str(Path(self.path).parent)) != self.chain:
            return False
        try:
            self.guard.real_lstat(self.path)
        except FileNotFoundError as error:
            return error.errno == errno.ENOENT and error.filename == self.path
        except OSError:
            pass
        return False

    def identity(self, frame, index):
        function = self.functions[index]
        return (frame is not None and frame.f_code is self.codes[index]
                and frame.f_globals is function.__globals__ and function.__code__ is self.codes[index])

    def eligible(self, event, args, caller):
        current = (metadata.FastPath.children, metadata.FastPath.zip_children,
                   zipfile.ZipFile.__init__, zipfile.CompleteDirs.make.__func__, zipfile.Path.__init__)
        if (current != self.functions or args[0] != self.path or sum(self.counts.values()) >= 4096 or not self.missing()):
            return False
        if event == 'os.listdir':
            frame = caller
        elif event == 'open':
            if args[1:] != ('r', os.O_CLOEXEC) or self.pending is None:
                return False
            frame = caller
            for index in (2, 3, 4, 1):
                if not self.identity(frame, index):
                    return False
                if index == 2 and (frame.f_locals.get('file') != self.path
                                   or frame.f_locals.get('mode') != 'r' or frame.f_locals.get('filemode') != 'rb'):
                    return False
                frame = frame.f_back
        else:
            return False
        if not self.identity(frame, 0):
            return False
        instance = frame.f_locals.get('self')
        return (type(instance) is metadata.FastPath and instance.root == self.path
                and (event != 'open' or instance is self.pending))

    def handle(self, event, args, caller):
        if not self.eligible(event, args, caller):
            return False
        changed = lambda **values: types.SimpleNamespace(**dict(
            {name: getattr(caller, name) for name in ('f_code', 'f_globals', 'f_locals', 'f_back')}, **values))
        for label, frame in (('copied-code', changed(f_code=caller.f_code.replace())),
                             ('copied-namespace', changed(f_globals=dict(caller.f_globals))), ('wrong-caller', None)):
            self.require(not self.eligible(event, args, frame), 'metadata absence caller negative failed')
            if event + ':' + label not in self.negatives:
                self.negatives.append(event + ':' + label)
        self.require(not self.eligible(event, ('/__satgs_guard_outside__', *args[1:]), caller), 'metadata outside path admitted')
        chain, count = self.chain, self.counts[event]
        try:
            self.chain = None
            self.require(not self.eligible(event, args, caller), 'metadata stale ancestor admitted')
        finally:
            self.chain = chain
        try:
            self.counts[event] = 4096
            self.require(not self.eligible(event, args, caller), 'metadata absence budget bypassed')
        finally:
            self.counts[event] = count
        if event == 'open':
            self.require(not self.eligible(event, (args[0], 'w', os.O_WRONLY), caller), 'metadata writing admitted')
            self.pending = None
            self.require(not self.eligible(event, args, caller), 'metadata open replay admitted')
        else:
            self.pending = caller.f_locals['self']
        self.counts[event] += 1
        for label in ('outside-path', 'stale-ancestor', 'budget', *(('wrong-flags', 'replay') if event == 'open' else ())):
            if event + ':' + label not in self.negatives:
                self.negatives.append(event + ':' + label)
        raise FileNotFoundError(errno.ENOENT, 'bound metadata zip absent without access', self.path)

    def receipt(self):
        self.require(self.missing(), 'bound stdlib metadata ZIP appeared or its ancestors changed')
        return dict(path=self.path, observed_absent=True, counts=self.counts, negative_controls=self.negatives,
                    policy='one verified absent stdlib ZIP; no ZIP or arbitrary missing-path access')
