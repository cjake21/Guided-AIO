"""Retained offline pip probe classifier with explicit runtime input paths.

Derived from the reviewed r3 build_install_guard_v3.py ProbeRules. Classified
operations remain denied; this module grants no network, process or FFI access.
"""

import ast
import dis
import hashlib
from pathlib import Path
import os
import socket
import sys
import types


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def call_offsets(code, node):
    selected = set()
    matching = False
    wanted = (node.lineno, node.end_lineno, node.col_offset, node.end_col_offset)
    for instruction in dis.get_instructions(code, show_caches=True):
        position = instruction.positions
        location = (position.lineno, position.end_lineno, position.col_offset, position.end_col_offset)
        if instruction.opname in (('IMPORT_NAME',) if isinstance(node, ast.Import) else ('PRECALL', 'CALL')):
            matching = location == wanted
        elif instruction.opname != 'CACHE':
            matching = False
        if matching:
            selected.add(instruction.offset)
    require(bool(selected), 'reviewed call offsets missing')
    return frozenset(selected)


class ProbeRules:
    def __init__(self, pip_members, stdlib_sources, stdlib, pip_wheel):
        self.bindings, self.source_hashes, self.counts = {}, {}, {}
        self.limits = {'ipv6-capability': 1, 'distro-list': 1, 'distro-release': 17,
                       'optional-lsb': 1, 'optional-uname': 1, 'optional-mime': 40,
                       'optional-rich-ctypes': 1}
        self.distro_files = frozenset('/etc/' + name for name in (
            'SuSE-release', 'altlinux-release', 'arch-release', 'base-release',
            'centos-release', 'fedora-release', 'gentoo-release', 'mageia-release',
            'mandrake-release', 'mandriva-release', 'mandrivalinux-release',
            'manjaro-release', 'oracle-release', 'redhat-release', 'rocky-release',
            'sl-release', 'slackware-version'))
        stdlib, pip_wheel = Path(stdlib), Path(pip_wheel)
        mime_tree = ast.parse(stdlib_sources[str(stdlib / 'mimetypes.py')])
        values = [node.value for node in mime_tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'knownfiles'
                          for target in node.targets)]
        require(len(values) == 1, 'MIME path assignment changed')
        self.mime_files = frozenset(ast.literal_eval(values[0]))
        require(all(type(path) is str and path.startswith(('/etc/', '/usr/local/'))
                    for path in self.mime_files), 'MIME path domain changed')
        definitions = (
            ('ipv6', 'pip/_vendor/urllib3/util/connection.py', '_has_ipv6', 'socket.socket(socket.AF_INET6)'),
            ('distro-list', 'pip/_vendor/distro/distro.py', 'LinuxDistribution._distro_release_info', 'os.listdir(self.etc_dir)'),
            ('distro-open', 'pip/_vendor/distro/distro.py', 'LinuxDistribution._parse_distro_release_file', "open(filepath, encoding='utf-8')"),
            ('distro-loop', 'pip/_vendor/distro/distro.py', 'LinuxDistribution._distro_release_info', 'self._parse_distro_release_file(filepath)'),
            ('lsb', 'pip/_vendor/distro/distro.py', 'LinuxDistribution._lsb_release_info', 'subprocess.check_output(cmd, stderr=subprocess.DEVNULL)'),
            ('uname', 'pip/_vendor/distro/distro.py', 'LinuxDistribution._uname_info', 'subprocess.check_output(cmd, stderr=subprocess.DEVNULL)'),
            ('file-mime', 'pip/_internal/operations/prepare.py', 'File.__post_init__', 'mimetypes.guess_type(self.path)'),
            ('mime-open', str(stdlib / 'mimetypes.py'), 'MimeTypes.read', "open(filename, encoding='utf-8')"),
            ('devnull-open', str(stdlib / 'subprocess.py'), 'Popen._get_devnull', 'os.open(os.devnull, os.O_RDWR)'),
            ('ctypes-open', str(stdlib / 'ctypes/__init__.py'), 'CDLL.__init__', '_dlopen(self._name, mode)'),
            ('ctypes-init', str(stdlib / 'ctypes/__init__.py'), '<module>', 'PyDLL(None)'),
            ('rich-ctypes', 'pip/_vendor/rich/_win32_console.py', '<module>', 'import ctypes'),
        )
        for key, source, qualname, expression in definitions:
            if source.startswith('/'):
                filename, data = source, stdlib_sources[source]
            else:
                filename, data = str(pip_wheel) + '/' + source, pip_members[source]
            self.source_hashes[filename] = digest(data)
            tree = ast.parse(data, filename=filename)
            scope = tree
            if qualname != '<module>':
                for part in qualname.split('.'):
                    candidates = [node for node in scope.body
                                  if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name == part]
                    require(len(candidates) == 1, 'reviewed scope not unique')
                    scope = candidates[0]
            calls = [node for node in ast.walk(scope) if isinstance(node, (ast.Call, ast.Import))
                     and ast.unparse(node) == expression]
            require(len(calls) == 1, 'reviewed call not unique')
            pending = [compile(data, filename, 'exec', dont_inherit=True)]
            codes = []
            while pending:
                code = pending.pop()
                if code.co_qualname == qualname:
                    codes.append(code)
                pending.extend(value for value in code.co_consts if isinstance(value, types.CodeType))
            require(len(codes) == 1, 'reviewed code not unique')
            self.bindings[key] = (filename, codes[0], call_offsets(codes[0], calls[0]))

    def frame(self, key, frames):
        filename, code, offsets = self.bindings[key]
        for frame in frames:
            module = sys.modules.get(frame.f_globals.get('__name__'))
            if (frame.f_code.co_filename == filename and frame.f_code == code
                    and frame.f_lasti in offsets and module is not None
                    and module.__dict__ is frame.f_globals
                    and frame.f_globals.get('__file__') == filename):
                return frame
        return None

    def classify(self, event, args, path, frames):
        category = None
        reading = event == 'open' and not args[2] & (
            os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
        if (event == 'ctypes.dlopen' and args == (None,) and sys.platform == 'linux'
                and all(self.frame(key, frames) is not None
                        for key in ('ctypes-open', 'ctypes-init', 'rich-ctypes'))):
            category = 'optional-rich-ctypes'
        elif (event == 'socket.__new__' and len(args) == 4
                and args[1:] == (socket.AF_INET6, socket.SOCK_STREAM, 0)
                and self.frame('ipv6', frames) is not None):
            category = 'ipv6-capability'
        elif event == 'os.listdir' and path == '/etc' and self.frame('distro-list', frames) is not None:
            category = 'distro-list'
        elif (reading and path in self.distro_files and self.frame('distro-open', frames) is not None
              and self.frame('distro-loop', frames) is not None):
            category = 'distro-release'
        elif (reading and path in self.mime_files and self.frame('mime-open', frames) is not None
              and self.frame('file-mime', frames) is not None):
            category = 'optional-mime'
        else:
            for key, command in (('lsb', ('lsb_release', '-a')), ('uname', ('uname', '-rs'))):
                caller = self.frame(key, frames)
                if caller is None or caller.f_locals.get('cmd') != command:
                    continue
                if (event == 'open' and path == '/dev/null'
                        and args[2] & os.O_ACCMODE == os.O_RDWR
                        and not args[2] & (os.O_CREAT | os.O_TRUNC | os.O_APPEND)
                        and self.frame('devnull-open', frames) is not None):
                    category = 'optional-' + key
        return self.bounded_category(category)

    def bounded_category(self, category):
        if category is not None:
            count = self.counts.get(category, 0) + 1
            self.counts[category] = count
            if count <= self.limits[category]:
                return category
        return None

    def check_count_limits(self):
        runtime_counts = self.counts
        self.counts = {}
        checked = {}
        try:
            for category, limit in self.limits.items():
                for unused in range(limit):
                    require(self.bounded_category(category) == category, 'classifier budget too small')
                require(self.bounded_category(category) is None, 'classifier budget exceeded')
                require(self.counts[category] == limit + 1, 'classifier count mismatch')
                checked[category] = dict(limit=limit, excess_rejected=True)
        finally:
            self.counts = runtime_counts
        return checked
