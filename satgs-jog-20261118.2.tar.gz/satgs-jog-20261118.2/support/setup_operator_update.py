"""Create a separate operator environment from the retained offline r3 wheels."""

import argparse
import configparser
import csv
from email.parser import BytesParser
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import runpy
import signal
import stat
import sys
import tarfile
import tempfile
import time
import types
import zipfile


HERE = Path(__file__).resolve().parent
OLD_VERSION = '0.0.1+operator.20261028.3'
NUMPY_PACKAGE_CACHE = 'numpy/distutils/__pycache__/conv_template.cpython-311.pyc'
NUMPY_CACHE_SOURCE = 'numpy/distutils/conv_template.py'
STAGES = ('create', 'install', 'check', 'metadata')
RETAINED_ROOTS = tuple(map(Path, (
    '/home/admin/satgs-operator-20261028-r3', '/home/admin/satgs-operator-20261028-r3-app-client',
    '/home/admin/satgs-operator-20261028-r3-practice', '/home/admin/satgs-operator-20261028-r3-acceptance',
    '/home/admin/satgs-pi-test/satgs-app-manager', '/home/admin/satgs-pi-test/satgs-installer-manager',
    '/home/admin/mavlink-test-venv',
    '/home/admin/satgs-operator-20261105-r4-app-client',
    '/home/admin/satgs-operator-20261105-r4-installer',
    '/home/admin/satgs-operator-20261110-r4-retry-app-client',
    '/home/admin/satgs-operator-20261110-r4-retry-installer',
    '/home/admin/satgs-runtime-20261110-app-manager',
    '/home/admin/satgs-runtime-20261110-installer',
    '/home/admin/satgs-runtime-20261110-setup',
    '/home/admin/satgs-runtime-20261110-acceptance',
    '/home/admin/Downloads/satgs-runtime-qpt130-20261110',
    '/home/admin/Downloads/satgs-daily-support-20261111',
    '/home/admin/satgs-native-ui-20261111-app-manager',
    '/home/admin/satgs-native-ui-20261111-installer',
    '/home/admin/satgs-native-ui-20261111-setup',
    '/home/admin/satgs-native-ui-20261111-acceptance',
    '/home/admin/Downloads/satgs-native-ui-20261111',
    '/home/admin/Downloads/satgs-native-ui-launcher-fix-20261111',
    '/home/admin/satgs-user-guide-20261112-app-manager',
    '/home/admin/satgs-user-guide-20261112-installer',
    '/home/admin/satgs-user-guide-20261112-setup',
    '/home/admin/satgs-user-guide-20261112-acceptance',
    '/home/admin/Downloads/satgs-user-guide-20261112',
    '/home/admin/satgs-handbook-20261112-app-manager',
    '/home/admin/satgs-handbook-20261112-installer',
    '/home/admin/satgs-handbook-20261112-setup',
    '/home/admin/satgs-handbook-20261112-acceptance',
    '/home/admin/Downloads/satgs-handbook-20261112',
    '/home/admin/satgs-ptu-20261117-app-manager',
    '/home/admin/satgs-ptu-20261117-installer',
    '/home/admin/satgs-ptu-20261117-setup',
    '/home/admin/satgs-ptu-20261117-acceptance',
    '/home/admin/Downloads/satgs-ptu-20261117',
    '/home/admin/satgs/station',
)))


def require(value, message):
    if not value:
        raise RuntimeError(message)


def load_support(name):
    path = HERE / (name + '.py')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(path.read_bytes(), str(path), 'exec', dont_inherit=True), vars(module))
    return module


guard_module = load_support('pi_guard')


def canonical(value):
    return re.sub(r'[-_.]+', '-', value).lower()


def member_path(value):
    require(type(value) is str and value and '\\' not in value
            and all(32 <= ord(char) < 127 for char in value), 'unsafe relative input name')
    path = PurePosixPath(value)
    require(not path.is_absolute() and all(part not in ('', '.', '..') for part in value.split('/')),
            'unsafe relative input path')
    return path


def safe_path(path):
    path = Path(os.path.abspath(path))
    for candidate in (path, *path.parents):
        require(not candidate.is_symlink(), 'symlink path is not permitted: ' + str(path))
    return path


def relative_input(root, name):
    return safe_path(root / member_path(name))


def read(path, limit=512 * 1024 * 1024):
    path = safe_path(path)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    with os.fdopen(descriptor, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, 'unbounded or nonordinary input')
        data = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
        keys = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        require(len(data) == before.st_size and all(getattr(before, key) == getattr(after, key) for key in keys),
                'input changed while reading')
    return data


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'duplicate JSON field')
        value[key] = item
    return value


def json_input(path):
    return json.loads(read(path, 32 * 1024 * 1024), object_pairs_hook=unique_object)


release_module = load_support('release_update')
RELEASE = release_module.release_manifest()
VERSION = RELEASE['application_version']
DEFAULT_BUNDLE = Path(RELEASE['paths']['previous_bundle'])
DEFAULT_APPLICATION = Path(RELEASE['paths']['application'])
DEFAULT_INSTALLER = Path(RELEASE['paths']['installer'])
DEFAULT_OUTPUT = Path(RELEASE['paths']['setup_output'])


def guide_resources(archive, files, version):
    manifest_name = 'satgs/data/user-guide-manifest.json'
    require(0 < files.get(manifest_name, 0) <= 65536, 'packaged handbook manifest missing or unbounded')
    guide = json.loads(archive.read(manifest_name).decode('utf-8'), object_pairs_hook=unique_object)
    require(type(guide) is dict and set(guide) == {'schema', 'application_version', 'sources', 'outputs'}
            and guide['schema'] == 'satgs-offline-guide.v1' and guide['application_version'] == version,
            'packaged handbook manifest version/schema differs')
    sources, outputs = guide['sources'], guide['outputs']
    require(type(sources) is dict and type(outputs) is dict, 'packaged handbook membership differs')
    chapters = {'docs/' + chapter + '.md' for chapter in release_module.CHAPTERS}
    screenshots = set(sources) - chapters
    require(chapters <= set(sources) and 1 <= len(screenshots) <= 8
            and all(re.fullmatch(r'docs/assets/[a-z0-9_-]+\.png', name) for name in screenshots),
            'packaged handbook source chapters/assets differ')
    core_outputs = {'user-guide.html', 'user-guide.txt', 'user-guide.css'}
    image_outputs = set(outputs) - core_outputs
    require(core_outputs <= set(outputs) and len(image_outputs) == len(screenshots)
            and all(re.fullmatch(r'user-guide-[a-z0-9_-]+\.png', name) for name in image_outputs),
            'packaged handbook output membership differs')
    require(all(type(digest) is str and re.fullmatch(r'[0-9a-f]{64}', digest)
                for records in (sources, outputs) for digest in records.values()),
            'packaged handbook manifest digest differs')
    expected = {'satgs/data/' + name for name in outputs} | {manifest_name}
    require({name for name in files if name.startswith('satgs/data/user-guide')} == expected
            and all(0 < files[name] <= 4 * 1024 * 1024 for name in expected),
            'packaged handbook resources are missing, additional or unbounded')
    payloads = {name: archive.read('satgs/data/' + name) for name in outputs}
    require(all(hashlib.sha256(raw).hexdigest() == outputs[name] for name, raw in payloads.items()),
            'packaged handbook payload digest differs')
    require({sources[name] for name in screenshots} == {outputs[name] for name in image_outputs}
            and all(payloads[name].startswith(b'\x89PNG\r\n\x1a\n') for name in image_outputs),
            'packaged handbook screenshot source/output identity differs')
    require(payloads['user-guide.html'].startswith(b'<!doctype html>')
            and ('<p>Application version ' + version + '</p>').encode() in payloads['user-guide.html']
            and ('Application version ' + version + '\n').encode() in payloads['user-guide.txt'][:256],
            'packaged handbook document version/header differs')


def wheel_details(path, name, version):
    path = safe_path(path)
    members, files, package_cache = set(), {}, []
    with zipfile.ZipFile(io.BytesIO(read(path))) as archive:
        rows = archive.infolist()
        require(1 <= len(rows) <= 16384 and sum(row.file_size for row in rows) <= 512 * 1024 * 1024,
                'wheel structure exceeds bounds')
        for row in rows:
            value = row.filename.rstrip('/')
            member_path(value)
            require(value not in members, 'duplicate wheel member')
            members.add(value)
            if not row.is_dir():
                files[value] = row.file_size
            mode = stat.S_IFMT(row.external_attr >> 16)
            require(mode in (0, stat.S_IFREG, stat.S_IFDIR) and not row.flag_bits & 1,
                    'nonordinary or encrypted wheel payload')
            require(not value.endswith('.pth') and Path(value).name not in (
                'sitecustomize.py', 'usercustomize.py'), 'wheel startup/cache content is not supported')
            if value.endswith('.pyc'):
                require(canonical(name) == 'numpy' and version == '2.2.6' and value == NUMPY_PACKAGE_CACHE
                        and mode == stat.S_IFREG and stat.S_IMODE(row.external_attr >> 16) == 0o644
                        and row.file_size == 14203, 'unreviewed package cache payload')
                package_cache.append(value)
        preserved_cache = []
        if package_cache:
            require(files.get(NUMPY_CACHE_SOURCE) == 9536, 'retained NumPy cache source sibling differs')
            with archive.open(NUMPY_PACKAGE_CACHE) as stream:
                header = stream.read(16)
            require(len(header) == 16 and header[:8] == b'\xa7\x0d\x0d\x0a\x00\x00\x00\x00'
                    and int.from_bytes(header[12:16], 'little') == files[NUMPY_CACHE_SOURCE],
                    'retained NumPy cache header/source shape differs')
            preserved_cache.append(dict(path=NUMPY_PACKAGE_CACHE, bytes=files[NUMPY_PACKAGE_CACHE],
                source=NUMPY_CACHE_SOURCE, source_bytes=files[NUMPY_CACHE_SOURCE], magic=header[:4].hex(),
                flags=0, source_timestamp=int.from_bytes(header[8:12], 'little'),
                role='opaque retained package data; no bytecode loading permission'))
        metadata_names = [value for value in members if value.endswith('.dist-info/METADATA')]
        require(len(metadata_names) == 1, 'ambiguous wheel metadata')
        prefix = metadata_names[0].removesuffix('METADATA')
        require('/' not in prefix.rstrip('/') and prefix.endswith('.dist-info/'), 'nested dist-info directory')
        distribution, recorded_version = prefix.removesuffix('.dist-info/').rsplit('-', 1)
        require(canonical(distribution) == canonical(name) and recorded_version == version,
                'dist-info directory identity differs')
        require({value.split('/')[0] for value in members if '.dist-info' in value.split('/')[0]} ==
                {prefix.rstrip('/')}, 'additional dist-info payload')
        record_name = prefix + 'RECORD'
        require(record_name in files and files[record_name] <= 4 * 1024 * 1024, 'wheel RECORD missing or unbounded')
        records = {}
        for row in csv.reader(io.StringIO(archive.read(record_name).decode('utf-8'))):
            require(len(row) == 3, 'invalid wheel RECORD row')
            member_path(row[0])
            require(row[0] not in records, 'duplicate wheel RECORD row')
            records[row[0]] = row[1:]
        require(set(records) == set(files), 'wheel RECORD file membership differs')
        for value, size in files.items():
            require(records[value][1] == ('' if value == record_name else str(size)), 'wheel RECORD byte size differs')
        metadata = BytesParser().parsebytes(archive.read(metadata_names[0]))
        names = metadata.get_all('Name', [])
        require(len(names) == 1 and canonical(names[0]) == canonical(name)
                and metadata.get_all('Version') == [version],
                'wheel name/version differs from its selected manifest record')
        wheel = BytesParser().parsebytes(archive.read(prefix + 'WHEEL'))
        scripts = {}
        if prefix + 'entry_points.txt' in members:
            parser = configparser.ConfigParser(interpolation=None, strict=True)
            parser.optionxform = str
            parser.read_string(archive.read(prefix + 'entry_points.txt').decode())
            scripts = dict(parser['console_scripts']) if parser.has_section('console_scripts') else {}
        if name == 'satgs':
            require(prefix == 'satgs-' + version + '.dist-info/', 'operator dist-info directory differs')
            require(path.name == 'satgs-' + version + '-py3-none-any.whl'
                    and wheel.get('Root-Is-Purelib') == 'true'
                    and wheel.get_all('Tag') == ['py3-none-any'], 'operator wheel identity/tag differs')
            require(all(value.startswith(('satgs/', prefix)) for value in members)
                    and not any(value.endswith(('.so', '.dll', '.dylib')) for value in members),
                    'unbound or native payload in pure operator wheel')
            require(scripts.get('satgs-operator') == 'satgs.operator_cli:main'
                    and scripts.get('satgs-operator-gui') == 'satgs.operator_gui:main', 'operator entry points missing')
            require(archive.read('satgs/_package_layout.py') == b'INSTALLED = True\n', 'installed layout marker differs')
            require(all(value in members for value in ('satgs/data/deployment_profiles.json',
                        'satgs/data/operator_tle.csv', 'satgs/operator_core.py', 'satgs/operator_gui.py',
                        'satgs/operator_cli.py')), 'operator resources/source missing')
            if version == VERSION:
                guide_resources(archive, files, version)
        modules = sorted({value.split('/')[0].removesuffix('.py') for value in members
                          if '.dist-info' not in value.split('/')[0] and '.data' not in value.split('/')[0]})
        return dict(path=str(path), name=canonical(name), version=version,
                    requires_python=metadata.get('Requires-Python'), requires_dist=metadata.get_all('Requires-Dist', []),
                    extras=metadata.get_all('Provides-Extra', []), scripts=scripts,
                    tags=wheel.get_all('Tag', []), modules=modules, members=sorted(members),
                    preserved_package_cache=preserved_cache)


def selected_wheels(bundle, wheel):
    manifest_path = bundle / 'manifest.json'
    manifest = json_input(manifest_path)
    require(manifest.get('schema_version') == 1 and manifest.get('runtime_counts', {}).get('manager') == 31,
            'unsupported retained bundle selection')
    require(manifest.get('source', {}).get('commit') == RELEASE['dependency_base']['source_commit'],
            'retained bundle declares a different source revision')
    installer = manifest['installer']
    require(installer['version'] == '26.2' and installer['wheel'] == 'installer/pip-26.2-py3-none-any.whl',
            'unreviewed installer identity')
    pip = wheel_details(relative_input(bundle, installer['wheel']), 'pip', '26.2')
    installer_lock = relative_input(bundle, installer['lock'])
    installer_rows = [line.split(' --hash=', 1)[0].strip() for line in read(installer_lock, 65536).decode('ascii').splitlines()
                      if line.strip() and not line.lstrip().startswith('#')]
    require(installer_rows == ['pip==26.2'], 'retained installer selection changed')
    lock = relative_input(bundle, manifest['locks']['manager'])
    selections = {}
    for line in read(lock, 1024 * 1024).decode('ascii').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        requirement = line.split(' --hash=', 1)[0]
        match = re.fullmatch(r'([A-Za-z0-9][A-Za-z0-9_.-]*)(\[([A-Za-z0-9_,.-]+)\])?==([A-Za-z0-9][A-Za-z0-9_.+!-]*)', requirement)
        require(match is not None, 'unsupported client requirement')
        name, unused, extras, version = match.groups()
        name = canonical(name)
        require(name not in selections, 'duplicate client distribution')
        require((extras or '') == ('pointing' if name == 'satgs' else
                'manager' if name in ('ptu-control', 'pixhawk') else ''), 'manager extras changed')
        selections[name] = version
    require(len(selections) == 31 and selections.get('satgs') == OLD_VERSION, 'retained manager closure differs')
    require(set(RELEASE['replacement_wheels']) <= selections.keys(),
            'retained manager closure lacks a required replacement owner')
    require(not {'pip', 'setuptools', 'build', 'wheel', 'grpcio-tools', 'protoc'} & selections.keys(),
            'installer/build distribution in client selection')
    runtime = {}
    for item in manifest['files']:
        if item.get('kind') == 'wheel' and str(item.get('path', '')).startswith('wheelhouse/'):
            name = canonical(item['name'])
            require(name not in runtime, 'duplicate runtime artifact')
            runtime[name] = item
    rows, original_inputs = [], []
    for name, version in selections.items():
        item = runtime.get(name)
        require(item is not None and item['version'] == version, 'selected artifact/version missing')
        original_path = relative_input(bundle, item['path'])
        original_inputs.append(str(original_path))
        details = wheel_details(original_path, item['name'], version)
        if name in RELEASE['replacement_wheels']:
            replacement_version = RELEASE['packages'][name]
            replacement_path = wheel if name == 'satgs' else wheel.parent / Path(RELEASE['replacement_wheels'][name]).name
            details = wheel_details(replacement_path, name, replacement_version)
            require(details['tags'] == ['py3-none-any'], 'replacement must be a pure wheel')
            if name == 'satgs':
                require(details['scripts'].get('satgs-bench-manager') == 'satgs.operator_bench_manager:main',
                        'foreground bench entry point missing')
        details['selected_extras'] = ['pointing', 'gui'] if name == 'satgs' else ['manager'] if name in ('ptu-control', 'pixhawk') else []
        rows.append(details)
    inputs = [str(manifest_path), str(lock), str(installer_lock), pip['path'], *original_inputs, *[row['path'] for row in rows]]
    return manifest, pip, rows, inputs


def reject_overlap(path, roots):
    require(all(path != root and path not in root.parents and root not in path.parents
                for root in (*roots, *RETAINED_ROOTS)), 'path overlaps a retained input or output')


def new_environment(path, roots):
    path = safe_path(path)
    reject_overlap(path, roots)
    require(not os.path.lexists(path) and path.parent.is_dir(), 'environment must be a new path beneath an existing parent')
    parent = path.parent.stat()
    require(parent.st_uid == os.getuid() and not parent.st_mode & 0o022, 'environment parent ownership/mode differs')
    return path


def create_environments(paths):
    import venv
    claims = {}
    for path in paths:
        os.mkdir(path, 0o700)
        info = path.lstat()
        require(stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o700
                and info.st_uid == os.getuid(), 'new environment claim differs')
        claims[path] = (info.st_dev, info.st_ino, info.st_mode, info.st_uid)
    for path in paths:
        info = path.lstat()
        require((info.st_dev, info.st_ino, info.st_mode, info.st_uid) == claims[path]
                and not os.listdir(path), 'claimed environment changed before creation')
        venv.EnvBuilder(with_pip=False, symlinks=False).create(path)
    return claims


def public_system_inputs():
    rows = []
    keys = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    for path in map(Path, ('/usr/lib/os-release', '/etc/debian_version', '/etc/os-release')):
        ancestors = []
        for parent in path.parents:
            info = parent.lstat()
            require(stat.S_ISDIR(info.st_mode) and not info.st_mode & 0o022,
                    'public OS metadata ancestor differs')
            ancestors.append([str(parent), info.st_dev, info.st_ino, info.st_mode])
        try:
            info = path.lstat()
        except FileNotFoundError:
            rows.append(dict(path=str(path), kind='absent', ancestors=ancestors))
            continue
        link = None
        if path == Path('/etc/os-release'):
            require(stat.S_ISLNK(info.st_mode), 'public os-release alias is not the reviewed symlink')
            link = os.readlink(path)
            require(link in ('../usr/lib/os-release', '/usr/lib/os-release')
                    and path.resolve(strict=False) == Path('/usr/lib/os-release'), 'public os-release alias differs')
        else:
            require(stat.S_ISREG(info.st_mode) and info.st_size <= 65536 and not info.st_mode & 0o022,
                    'public OS metadata is not a bounded ordinary file')
            read(path, 65536)
        rows.append(dict(path=str(path), kind='alias' if link else 'present', ancestors=ancestors,
                         identity=[getattr(info, key) for key in keys], link=link))
    return rows


class InstallerGuard(guard_module.CheckGuard):
    def __init__(self, files, directories, native, *, outputs, exact_writes, modules, pip,
                 read_roots=(), application=None, stdlib=None, create=False, rules=None):
        super().__init__(files, directories, native)
        self.outputs = tuple(Path(value).resolve() for value in outputs)
        self.exact_writes = frozenset(map(str, exact_writes))
        self.modules, self.pip, self.rules = frozenset(modules), pip, rules
        self.expected_denials = []
        self.runtime_open_denials = []
        self.diagnostic_failures = 0
        self.create = create
        self.virtual_imports = frozenset(self.pip['path'] + '/' + name for name in self.pip['members'])
        self.read_roots = tuple(Path(value).resolve() for value in read_roots)
        self.application = Path(application).resolve() if application is not None else None
        self.metadata_absence = (load_support('installer_metadata_absence').MetadataZipAbsence(self, stdlib)
                                 if stdlib is not None else None)

    def output_path(self, value, directory_fd=None):
        path = Path(self.path(value, directory_fd))
        return str(path) in self.exact_writes or any(path == root or root in path.parents for root in self.outputs)

    def read_path(self, value, directory_fd=None):
        path = Path(self.path(value, directory_fd))
        return any(path == root or root in path.parents for root in self.read_roots)

    def deny(self, event):
        if getattr(self.context, 'installer_recording', False):
            self.overflow = True
            raise PermissionError('installer diagnostic effect remains denied')
        active_event = getattr(self.context, 'installer_event', None)
        if self.phase == 'runtime' and active_event is not None:
            original, args = active_event
            frames, frame = [], sys._getframe(1)
            while frame is not None and len(frames) < 20:
                frames.append(frame)
                frame = frame.f_back
            if self.rules is not None and event == original:
                path = (getattr(self.context, 'installer_open_path', None) if event == 'open'
                        else self.path(args[0]) if event == 'os.listdir' else None)
                category = self.rules.classify(event, args, path, frames)
                if category is not None:
                    require(len(self.expected_denials) < 128, 'optional initialization denial limit')
                    row = dict(event=event, category=category, classification='expected-blocked', phase='runtime')
                    self.expected_denials.append(row)
                    print(json.dumps(dict(denied_effect=row), sort_keys=True), flush=True)
                    if category == 'optional-rich-ctypes':
                        # pip's eager optional import catches ImportError; the native load stays aborted.
                        raise ImportError('reviewed optional pip ctypes initialization remains denied')
                    raise PermissionError('reviewed optional pip initialization remains denied')
            if original == 'open':
                self.context.installer_recording = True
                try:
                    self.record_runtime_open(event, args, frames)
                except BaseException:
                    self.diagnostic_failures += 1
                finally:
                    self.context.installer_recording = False
        return super().deny(event)

    @staticmethod
    def diagnostic_text(value, limit):
        return dict(value=value[:limit], length=len(value), truncated=len(value) > limit)

    def record_runtime_open(self, event, args, frames):
        if len(self.runtime_open_denials) >= 128:
            return
        raw, flags = args[0], args[2]
        row = dict(event=event, phase='runtime', classification='unclassified-fatal', callers=[])
        if type(raw) is str:
            row['raw_path'] = self.diagnostic_text(raw, 4096)
        elif type(raw) is bytes:
            row['raw_path_bytes'] = dict(hex=raw[:4096].hex(), length=len(raw), truncated=len(raw) > 4096)
        elif type(raw) is int and 0 <= raw < 2 ** 63:
            row['raw_descriptor'] = raw
        else:
            row['raw_path_unavailable'] = True
        normalized = getattr(self.context, 'installer_open_path', None)
        row['normalized_path'] = self.diagnostic_text(normalized, 4096) if type(normalized) is str else None
        row['flags'] = flags if type(flags) is int and 0 <= flags < 2 ** 64 else None
        for frame in frames:
            code = frame.f_code
            if code.co_filename in (__file__, guard_module.__file__):
                continue
            row['callers'].append(dict(filename=self.diagnostic_text(code.co_filename, 4096),
                                       name=self.diagnostic_text(code.co_name, 256), line=frame.f_lineno))
            if len(row['callers']) == 8:
                break
        self.runtime_open_denials.append(row)
        print(json.dumps(dict(runtime_open_denial=row), sort_keys=True), flush=True)

    def audit(self, event, args):
        if getattr(self.context, 'installer_recording', False):
            if event == 'object.__getattr__':
                return
            self.overflow = True
            raise PermissionError('installer diagnostic effect remains denied')
        previous = getattr(self.context, 'installer_event', None)
        previous_path = getattr(self.context, 'installer_open_path', None)
        self.context.installer_event = (event, args)
        self.context.installer_open_path = None
        try:
            if self.metadata_absence is not None and event in ('os.listdir', 'open'):
                self.metadata_absence.handle(event, args, sys._getframe(1))
            if event == 'import' and str(args[0]).split('.')[0] in self.modules:
                self.deny('application-import')
            if (event == 'exec' and self.application is not None
                    and str(args[0].co_filename).startswith(str(self.application) + '/')):
                self.deny('application-exec')
            if event == 'open':
                pending = getattr(self.context, 'opening', None)
                directory_fd = pending[1] if pending and pending[0] == args[0] else None
                path = Path(self.path(args[0], directory_fd))
                self.context.installer_open_path = str(path)
                if (self.application is not None and self.application in path.parents and path.suffix == '.pyc'
                        and args[2] & os.O_ACCMODE != os.O_WRONLY):
                    self.deny('installed-cache-read')
                if self.output_path(args[0], directory_fd):
                    return
                writing = args[2] & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
                if not writing and self.read_path(args[0], directory_fd):
                    return
            if event in ('os.listdir', 'os.scandir') and (self.output_path(args[0]) or self.read_path(args[0])):
                return
            indexes = {'os.mkdir': 2, 'os.remove': 1, 'os.rmdir': 1, 'os.chmod': 2, 'os.utime': 3}
            if event in indexes and self.output_path(args[0], args[indexes[event]]):
                if event == 'os.chmod' and args[1] & ~0o777:
                    self.deny(event)
                return
            if event in ('os.rename', 'os.link') and all(self.output_path(args[index], args[index + 2]) for index in (0, 1)):
                return
            if event == 'os.symlink' and self.create and args[0] == 'lib' and args[2] in (-1, None):
                destination = Path(os.path.abspath(args[1]))
                if destination in {root / 'lib64' for root in self.outputs if root.name != 'tmp'}:
                    return
            if event == 'import' and len(args) > 1 and args[1] is not None:
                if str(args[1]) in self.virtual_imports:
                    return
            return super().audit(event, args)
        finally:
            self.context.installer_event = previous
            self.context.installer_open_path = previous_path

    def absent_import_cache(self, path, frame):
        if frame is not None and frame.f_code is InstallerGuard.audit.__code__ and frame.f_globals is globals():
            frame = frame.f_back
        return super().absent_import_cache(path, frame)

    def finish(self):
        super().finish()
        print(json.dumps(dict(optional_initialization_denials=self.expected_denials,
                             optional_initialization_counts=self.rules.counts if self.rules else {},
                             metadata_zip_absence=self.metadata_absence.receipt() if self.metadata_absence else None,
                             cache_absence=self.cache_receipts()), sort_keys=True), flush=True)


def child(plan_path, stage):
    target, provenance = load_support('pi_target'), load_support('provenance')
    plan = json_input(plan_path)
    provenance.current(dict(input_identities=plan['input_identities'], inputs={}))
    require(public_system_inputs() == plan['public_metadata'], 'bound public OS metadata changed')
    facts = plan['facts']
    app, installer = Path(plan['application']), Path(plan['installer'])
    target.check_facts(facts, None if stage == 'create' else app)
    expected_python = Path(facts['executable']) if stage == 'create' else app / 'bin/python'
    require(Path(sys.executable) == expected_python, 'setup child interpreter differs')
    records = Path(plan['attempt']) / stage
    tmp = installer / '.tmp' / stage
    environment = dict(target.ENV, TMPDIR=str(tmp), PIP_CONFIG_FILE=os.devnull)
    require(dict(os.environ) == environment, 'setup child environment differs')
    files, directories, native = set(plan['input_identities']), set(), set()
    tree = facts['stdlib']
    stdlib = Path(tree['root'])
    files.update(str(stdlib / name) for name in tree['files'])
    files.update(item['resolved'] for item in tree['links'].values())
    files.update(str(stdlib / name) for name in tree['links'] if name.endswith('.py'))
    directories.update(str(stdlib / name) for name in tree['directories'])
    native.update(str(stdlib / name) for name in tree['files'] if name.startswith('lib-dynload/') and name.endswith('.so'))
    native.update(item['resolved'] for name, item in tree['links'].items() if name.startswith('lib-dynload/') and name.endswith('.so'))
    files.add(str(Path(sys.base_prefix) / 'pyvenv.cfg'))
    files.add(str(plan_path))
    directories.update(str(Path(value).parent) for value in files)
    directories.update((str(records), str(app.parent), str(installer.parent)))
    files.update((facts['executable'], str(sys.executable)))
    files.update(row['path'] for row in plan['public_metadata'])
    rules = None
    if stage in ('install', 'check'):
        rules_module = load_support('installer_probe_rules')
        with zipfile.ZipFile(plan['pip']['path']) as archive:
            sources = {name: archive.read(name) for name in (
                'pip/_vendor/urllib3/util/connection.py', 'pip/_vendor/distro/distro.py',
                'pip/_internal/operations/prepare.py', 'pip/_vendor/rich/_win32_console.py')}
        standard = {str(stdlib / name): read(stdlib / name, 1024 * 1024)
                    for name in ('mimetypes.py', 'subprocess.py', 'ctypes/__init__.py')}
        rules = rules_module.ProbeRules(sources, standard, stdlib, plan['pip']['path'])
    outputs = (app, installer) if stage == 'create' else (app, tmp) if stage == 'install' else (tmp,)
    guard = InstallerGuard(files, directories, native, outputs=outputs,
        exact_writes=(records / 'requirements.txt', records / 'pip-report.json') if stage == 'install' else (),
        modules={name for row in plan['wheels'] for name in row['modules']}, pip=plan['pip'],
        read_roots=(app,), application=app, stdlib=stdlib, create=stage == 'create', rules=rules)
    guard.activate()
    negative_count = guard.probes()
    if rules is not None:
        print(json.dumps(dict(classifier_count_controls=rules.check_count_limits()), sort_keys=True), flush=True)
    if stage == 'create':
        claims = create_environments((installer, app))
        for name in STAGES:
            (installer / '.tmp' / name).mkdir(mode=0o700, parents=True, exist_ok=True)
        result = dict(created=[str(installer), str(app)], claims={str(path): list(value) for path, value in claims.items()},
                      pip_seeded=False)
    else:
        site_path = target.startup_policy(app)
        result = dict(site=target.initialize_site(app, facts['pre_site_path'], [site_path], facts['stdlib']))
        guard_module.CheckGuard.finish(guard)
        if stage in ('install', 'check'):
            sys.path.insert(0, plan['pip']['path'])
            argv = ['pip', '--isolated', '--disable-pip-version-check', '--no-cache-dir', '--no-input']
            if stage == 'check':
                argv.append('check')
            else:
                requirements = records / 'requirements.txt'
                with requirements.open('x') as stream:
                    for row in plan['wheels']:
                        extras = '[' + ','.join(row['selected_extras']) + ']' if row['selected_extras'] else ''
                        stream.write(row['name'] + extras + ' @ ' + Path(row['path']).as_uri() + '\n')
                argv.extend(('install', '--prefix', str(app), '--no-index', '--no-deps', '--only-binary=:all:',
                             '--no-compile', '--progress-bar=off', '--report', str(records / 'pip-report.json'),
                             '-r', str(requirements)))
            sys.argv = argv
            try:
                runpy.run_module('pip', run_name='__main__')
            except SystemExit as error:
                require(error.code in (None, 0), 'offline pip returned a failure')
            result.update(pip_exit=0)
        else:
            installed = list(importlib.metadata.distributions(path=[str(site_path)]))
            versions = {canonical(item.metadata['Name']): item.version for item in installed}
            require(len(installed) == len(versions) == len(plan['wheels']) and versions == {
                row['name']: row['version'] for row in plan['wheels']}, 'installed distribution metadata differs')
            require(not {'pip', 'setuptools', 'wheel', 'build', 'grpcio-tools'} & versions.keys(), 'installer/build package in application')
            for name in ('satgs-operator', 'satgs-operator-gui'):
                script = read(app / 'bin' / name, 65536).decode()
                require(script.splitlines()[0] == '#!' + str(app / 'bin/python'), 'entry-point interpreter differs')
            result.update(distributions=versions, application_imports=False)
    require(not any(name.split('.')[0] in guard.modules for name in sys.modules), 'application module imported during setup')
    guard.finish()
    print(json.dumps(dict(setup_child=dict(stage=stage, status='PASS', result=result,
                                          negative_controls=negative_count)), sort_keys=True), flush=True)


def report_text(summary):
    lines = ['SATGS side-by-side setup: ' + summary['status'], 'Application: ' + summary['application'],
             'Retained bundle: ' + summary['source']]
    lines.extend(name + ': ' + value['status'] for name, value in summary['phases'].items())
    lines.extend(('Primary: ' + json.dumps(summary['primary'], sort_keys=True),
                  'Cleanup: ' + json.dumps(summary['cleanup'], sort_keys=True),
                  'Packaging: ' + json.dumps(summary['packaging'], sort_keys=True),
                  'Provenance: ' + json.dumps(summary['provenance'], sort_keys=True),
                  'Existing application, workspaces and diagnostic environments were not selected for writes.',
                  'Partial new environments are retained. No overwrite, rollback or deletion was attempted.',
                  'This installs packages only. GUI/CLI acceptance and Pi Tcl observations remain separate.',
                  'Python API/audit controls trust the selected CPython/stdlib; they are not syscall isolation.'))
    return '\n'.join(lines) + '\n'


def package_attempt(recording, attempt):
    files, total = {}, 0
    root_names = {'binding.json', 'input-identities.json', 'phase-summary.json', 'provenance.json'}
    stage_names = {'attempt.json', 'result.json', 'stdout', 'stderr', 'requirements.txt', 'pip-report.json'}
    for path in sorted(attempt.rglob('*')):
        recording.ordinary(path)
        relative = path.relative_to(attempt)
        if path.is_dir():
            require(len(relative.parts) == 1 and relative.name in STAGES, 'unexpected setup evidence directory')
            continue
        require((len(relative.parts) == 1 and relative.name in root_names) or
                (len(relative.parts) == 2 and relative.parts[0] in STAGES and relative.name in stage_names),
                'unexpected setup evidence member')
        data = recording.read(path)
        total += len(data)
        require(total <= recording.MAX_EVIDENCE and len(files) < 64, 'setup evidence exceeds bounds')
        files[str(relative)] = data
    partial = attempt / 'evidence.partial.tar.gz'
    with partial.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as archive:
            for name, data in files.items():
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(data), 0o600, 0
                archive.addfile(item, io.BytesIO(data))
        stream.flush()
        os.fsync(stream.fileno())
    with tarfile.open(partial, 'r:gz') as archive:
        require(archive.getnames() == list(files), 'setup archive membership differs')
        for item in archive.getmembers():
            require(item.isfile() and archive.extractfile(item).read() == files[item.name], 'setup archive content differs')
    final = attempt / 'evidence.tar.gz'
    os.link(partial, final)
    partial.unlink()
    return dict(status='PASS', path=str(final), files=len(files), uncompressed_bytes=total,
                sha256=recording.digest(final), hashes_diagnostic_only=True)


def setup(args):
    recording, provenance, target = load_support('recording'), load_support('provenance'), load_support('pi_target')
    output = safe_path(args.output_root)
    protected = (safe_path(args.previous_bundle), safe_path(args.application), safe_path(args.installer),
                 HERE.parent, Path(sys.base_prefix).resolve())
    reject_overlap(output, protected)
    require(output.parent.is_dir() and output.parent.stat().st_uid == os.getuid()
            and not output.parent.stat().st_mode & 0o022, 'setup output parent ownership/mode differs')
    output.mkdir(mode=0o700, exist_ok=True)
    require(output.is_dir() and output.stat().st_uid == os.getuid()
            and stat.S_IMODE(output.stat().st_mode) == 0o700, 'setup output must be an owned private directory')
    attempt = Path(tempfile.mkdtemp(prefix='operator-setup-', dir=output))
    started = time.monotonic()
    summary = dict(schema='operator-side-by-side-setup.v1', status='FAIL', application=str(args.application),
                   source=str(args.previous_bundle), support=str(HERE), phases={name: dict(status='NOT RUN') for name in STAGES},
                   primary=None, cleanup=dict(status='NOT RUN'), capture_errors=[], signals=[],
                   packaging=dict(status='NOT RUN'), provenance={})
    interrupts = recording.Interrupts()
    previous = {number: signal.signal(number, interrupts.handler) for number in (signal.SIGINT, signal.SIGTERM)}
    observations = []
    stage = None
    try:
        bundle = safe_path(args.previous_bundle)
        wheel = safe_path(HERE.parent / RELEASE['replacement_wheels']['satgs'])
        facts = target.collect()
        roots = (bundle, HERE.parent, output, Path(facts['stdlib']['root']), Path(facts['executable']).parent)
        installer = new_environment(args.installer, roots)
        app = new_environment(args.application, (*roots, installer))
        require(all(output != root and root not in output.parents and output not in root.parents
                    for root in (bundle, app, installer, HERE.parent, Path(facts['stdlib']['root']))),
                'setup records overlap inputs or new environments')
        manifest, pip, wheels, inputs = selected_wheels(bundle, wheel)
        require({key: value for key, value in manifest['target'].items() if key not in ('glibc_min', 'absent_paths')} ==
                {key: value for key, value in facts['target'].items() if key != 'glibc'}, 'retained bundle target differs')
        require(manifest['target']['glibc_min'] == '2.26' and manifest['target']['absent_paths'] == [
            '/opt/_internal/cpython-3.11.10/lib/python3.11/site-packages/scipy_openblas32/lib'],
            'retained native prerequisite declaration differs')
        for value in manifest['target']['absent_paths']:
            require(not os.path.lexists(value), 'retained native-library absence condition no longer holds')
        inputs.extend(str(HERE / name) for name in ('setup_operator_update.py', 'installer_probe_rules.py', 'installer_metadata_absence.py',
                      'pi_target.py', 'pi_guard.py', 'recording.py', 'provenance.py', 'release_update.py'))
        inputs.extend((str(HERE.parent / 'release.json'), str(HERE.parent / 'launchers/daily.py')))
        identities = {value: provenance.identity(value) for value in inputs}
        plan = dict(schema='operator-side-by-side-binding.v1', application=str(app), installer=str(installer),
                    attempt=str(attempt), facts=facts, pip=pip, wheels=wheels, input_identities=identities,
                    public_metadata=public_system_inputs())
        recording.write_json(attempt / 'binding.json', plan)
        recording.write_json(attempt / 'input-identities.json', identities)
        for stage in STAGES:
            summary['phases'][stage] = dict(status='FAIL', reason='child has not completed')
            interpreter = facts['executable'] if stage == 'create' else str(app / 'bin/python')
            command = [interpreter, '-I', '-B', '-S', str(HERE / 'setup_operator_update.py'),
                       '--child', stage, '--binding', str(attempt / 'binding.json')]
            environment = dict(target.ENV, TMPDIR=str(installer / '.tmp' / stage), PIP_CONFIG_FILE=os.devnull)
            observed = target.supervise(command, attempt / stage, cwd=HERE, environment=environment,
                                        timeout=180, cap=4 * 1024 * 1024, terminate_grace=5)
            observations.append(observed)
            require(target.supervision_passed(observed), 'setup child or cleanup failed: ' + stage)
            receipts = [json.loads(line)['setup_child'] for line in read(attempt / stage / 'stdout', 4 * 1024 * 1024).decode().splitlines()
                        if line.startswith('{"setup_child":')]
            require(len(receipts) == 1 and receipts[0]['stage'] == stage and receipts[0]['status'] == 'PASS',
                    'setup child receipt missing or mismatched')
            summary['phases'][stage] = dict(status='PASS', child_exit=observed['final_exit'], result=receipts[0])
            provenance.current(dict(input_identities=identities, inputs={}))
            require(public_system_inputs() == plan['public_metadata'], 'bound public OS metadata changed')
        summary['status'] = 'PASS'
    except BaseException as error:
        summary['primary'] = dict(phase=stage, type=type(error).__name__, message=recording.error_text(error))
    finally:
        interrupts.finalizing = True
        summary['signals'] = list(interrupts.received)
        if summary['signals']:
            summary['status'] = 'FAIL'
        summary['duration_seconds'] = time.monotonic() - started
        summary['cleanup'] = dict(status=('PASS' if all(value.get('quiescent') is True and not value.get('cleanup_errors')
                                  for value in observations) else 'FAIL') if observations else 'NOT RUN', children=observations)
        summary['provenance'] = provenance.summary(provenance.optional_checksums(HERE.parent))
        summary['launcher'] = dict(observed_runner_exit=observations[-1].get('final_exit') if observations else None,
                                   exit_to_return=0 if summary['status'] == 'PASS' else 1)
        try:
            recording.write_json(attempt / 'phase-summary.json', summary)
            recording.write_json(attempt / 'provenance.json', summary['provenance'])
            summary['packaging'] = package_attempt(recording, attempt)
        except BaseException as error:
            summary['status'] = 'FAIL'
            summary['packaging'] = dict(status='FAIL', type=type(error).__name__, error=recording.error_text(error))
        summary['launcher']['exit_to_return'] = 0 if summary['status'] == 'PASS' else 1
        recording.report_text = report_text
        recorded = recording.finalize_records(attempt, summary, interrupts)
        for number, handler in previous.items():
            signal.signal(number, handler)
        print('report.txt: ' + str(attempt / 'report.txt'), flush=True)
        print('evidence.tar.gz: ' + str(attempt / 'evidence.tar.gz'), flush=True)
    return 0 if recorded and summary['status'] == 'PASS' else 1


def main(argv=None):
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
            'use setup_update.sh')
    parser = argparse.ArgumentParser(allow_abbrev=False, description=__doc__)
    parser.add_argument('--previous-bundle', type=Path, default=DEFAULT_BUNDLE)
    parser.add_argument('--application', type=Path, default=DEFAULT_APPLICATION)
    parser.add_argument('--installer', type=Path, default=DEFAULT_INSTALLER)
    parser.add_argument('--output-root', type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument('--child', choices=STAGES, help=argparse.SUPPRESS)
    parser.add_argument('--binding', type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    if args.child:
        child(args.binding, args.child)
        return 0
    return setup(args)


if __name__ == '__main__':
    raise SystemExit(main())
