"""Fixed finite owner for one bound Xvfb and one guarded native-widget child."""

import datetime
import errno
import os
from pathlib import Path
import selectors
import signal
import stat
import struct
import subprocess
import time


MANIFEST_SHA = 'c3325bd0310c2d80dd2f91ce72981b6114d2d0b1b6160cf4eaddb0bad49a1478'
SERVER_SHA = '8fd976ed7fb17d9318491cb4788e52f0f99676b00527802d143196ca3b7779ff'
SHELL_SHA = 'a59fc4da19d169c175b247bfaf4a21c2ee7c16c3ed2820daa807ab12affe98fc'
CAP = 1024 * 1024


def bind_resources(target, manifest_path):
    manifest = target.load_json(manifest_path, MANIFEST_SHA)
    target.require(manifest['server']['sha256'] == SERVER_SHA, 'wrong reviewed Xvfb')
    inputs = {str(manifest_path): MANIFEST_SHA}
    for group in manifest['namespaces'].values():
        target.require(not group['unresolved_sonames'] and not group['incompatible_versions'],
                       'incomplete native dependency closure')
        inputs.update({path: row['sha256'] for path, row in group['objects'].items()})
    for group in manifest['resources'].values():
        inputs.update({row['path']: row['sha256'] for row in group['files'] if 'path' in row})
    resource_links(target, manifest, inputs)
    shell = Path('/bin/sh')
    target.require(shell.is_symlink() and shell.resolve(strict=True) == Path('/usr/bin/bash'),
                   'unreviewed native shell target')
    inputs['/usr/bin/bash'] = SHELL_SHA
    for path, expected in inputs.items():
        target.require(target.sha(path) == expected, 'native input changed: ' + path)
    return manifest, inputs


def resource_links(target, manifest, inputs):
    observed = []
    for group in manifest['resources'].values():
        for row in group['files']:
            if 'path' in row:
                continue
            target.require(set(row) == {'relative_path', 'link', 'resolved', 'target_exists'}
                           and row['target_exists'] is True and row['resolved'] in inputs,
                           'unreviewed native resource link descriptor')
            path = Path(group['root']) / row['relative_path']
            target.ordinary(path.parent)
            info = path.lstat()
            target.require(stat.S_ISLNK(info.st_mode) and os.readlink(path) == row['link']
                           and str(path.resolve(strict=True)) == row['resolved'], 'native resource link changed')
            observed.append(dict(path=str(path), link=row['link'], resolved=row['resolved'],
                                 identity=[info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
                                           info.st_size, info.st_mtime_ns, info.st_ctime_ns]))
    target.require(len(observed) == 3, 'reviewed three XKB resource links required')
    return observed


def shell_binding(target):
    shell = Path('/bin/sh')
    target.require(shell.is_symlink() and shell.resolve(strict=True) == Path('/usr/bin/bash')
                   and target.sha('/usr/bin/bash') == SHELL_SHA, 'native shell binding changed')


def color_absence(target, manifest):
    path = Path(manifest['resources']['x11_data']['root']) / 'Xcms.txt'
    target.require(manifest['proposed_client_environment']['XCMSDB'] == str(path),
                   'unreviewed optional color-data path')
    target.ordinary(path.parent)
    rows = []
    for item in reversed(path.parents):
        info = item.lstat()
        target.require(stat.S_ISDIR(info.st_mode), 'nonordinary optional color-data ancestor')
        rows.append(dict(path=str(item), identity=[info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid]))
    try:
        path.lstat()
    except FileNotFoundError as error:
        target.require(error.errno == errno.ENOENT and error.filename == str(path),
                       'genuine optional color-data absence required')
    else:
        raise RuntimeError('optional color data appeared; separate resource review required')
    return dict(path=str(path), ancestors=rows, policy='exact ENOENT only; no file bytes or fallback implementation claim')


def prepare(target, manifest_path, private):
    private = target.ordinary(private)
    info = private.stat()
    target.require(info.st_uid == os.geteuid() and stat.S_IMODE(info.st_mode) == 0o700
                   and not list(private.iterdir()), 'fresh private native directory required')
    manifest, inputs = bind_resources(target, manifest_path)
    xkb = target.ordinary(manifest['xkb_output']['path'])
    info = xkb.stat()
    target.require(info.st_uid == os.geteuid() and stat.S_IMODE(info.st_mode) == 0o700
                   and os.access(xkb, os.W_OK | os.X_OK), 'private XKB output unavailable')
    display = str(10000 + int.from_bytes(os.urandom(2), 'big') % 20000)
    keymap = xkb / ('server-' + display + '.xkm')
    target.require(not os.path.lexists(keymap), 'selected private XKB output already exists')
    for name in ('home', 'tmp', 'application'):
        (private / name).mkdir(mode=0o700)
    authority = private / 'authority'
    field = lambda value: struct.pack('!H', len(value)) + value
    cookie = os.urandom(16)
    data = struct.pack('!H', 65535) + field(b'') + field(display.encode('ascii'))
    data += field(b'MIT-MAGIC-COOKIE-1') + field(cookie)
    descriptor = os.open(authority, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    client = dict(target.ENV, **manifest['proposed_client_environment'], DISPLAY=':' + display,
                  XAUTHORITY=str(authority), HOME=str(private / 'home'), TMPDIR=str(private / 'tmp'))
    server = dict(target.ENV, **manifest['proposed_server_environment'], HOME=str(private / 'home'),
                  TMPDIR=str(private / 'tmp'))
    return dict(manifest=manifest, inputs=inputs, private=private, display=display, authority=authority,
                resource_links=resource_links(target, manifest, inputs),
                color_data_absence=color_absence(target, manifest),
                authority_identity=target.identity(authority), keymap=keymap,
                child_scratch=private / 'application', client_environment=client, server_environment=server)


def endpoint_present(display):
    endpoint = ('@/tmp/.X11-unix/X' + display).encode('ascii')
    with open('/proc/net/unix', 'rb') as stream:
        return any(line.rstrip().split(maxsplit=7)[-1] == endpoint for line in stream)


def run(target, state, command, records, *, cwd, interrupts):
    """No wrapper process: this caller owns both actual child process groups."""
    records = target.ordinary(records)
    records.mkdir(mode=0o700)
    target.require('--lane' in command and command[command.index('--lane') + 1] == 'native-widgets'
                   and '--scratch' in command
                   and command[command.index('--scratch') + 1] == str(state['child_scratch']),
                   'fixed native guarded child required')
    for path, expected in state['inputs'].items():
        target.require(target.sha(path) == expected, 'native input changed before launch')
    shell_binding(target)
    target.require(resource_links(target, state['manifest'], state['inputs']) == state['resource_links'],
                   'native resource link identity changed before launch')
    target.require(color_absence(target, state['manifest']) == state['color_data_absence'],
                   'optional color-data absence changed before launch')
    target.require(not endpoint_present(state['display']), 'selected abstract display already exists')
    target.require(target.identity(state['authority']) == state['authority_identity'], 'private authority changed')
    ready_read, ready_write = os.pipe2(os.O_CLOEXEC | os.O_NONBLOCK)
    server_command = [state['manifest']['server']['path'], ':' + state['display'],
                      '-nolisten', 'tcp', '-nolisten', 'unix', '-listen', 'local', '-noreset',
                      '-screen', '0', '1280x900x24', '-auth', str(state['authority']),
                      '-displayfd', str(ready_write)]
    selector = selectors.DefaultSelector()
    processes, results, streams = {}, {}, {}
    owner = dict(schema='operator-fixed-native-owner.v1', status='FAIL', cleanup_errors=[],
                 display=':' + state['display'], server_listener_transport='abstract AF_UNIX only', readiness=None,
                 lock_policy='supported displayfd sets nolock before OsInit; global lock creation/removal bypassed',
                 authority='private0600 cookie contents excluded from records and archive',
                 readiness_timeout_seconds=15, child_timeout_seconds=120, stream_limit_bytes=CAP,
                 cleanup_budget_seconds_per_group=5, final_capture_budget_seconds=2,
                 trusted_native='exact bound Xvfb/shell/xkbcomp and Tk9/static Xlib/XCB under fixed owned display/private authority',
                 client_transport_limit='client native internals are trusted; no client no-TCP or syscall-isolation guarantee',
                 interruption_limit='handled SIGINT/SIGTERM only; SIGKILL or power loss cannot be finalized')
    owner['resource_links'] = state['resource_links']
    owner['color_data_absence'] = state['color_data_absence']

    def spawn(name, argv, environment, inherited=()):
        lane = records / name
        lane.mkdir(mode=0o700)
        row = dict(command=argv, cwd=str(cwd), environment=environment, cleanup_errors=[],
                   start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   timeout_seconds=135 if name == 'server' else 120, stream_limit_bytes=CAP)
        results[name] = row
        target.write(lane / 'attempt.json', row)
        process = subprocess.Popen(argv, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   start_new_session=True, close_fds=True, pass_fds=inherited)
        processes[name] = process
        row['owned_group'] = process.pid
        for label, pipe in (('stdout', process.stdout), ('stderr', process.stderr)):
            streams[name, label] = (lane / label).open('xb')
            selector.register(pipe, selectors.EVENT_READ, (name, label))
            row[label + '_bytes'] = 0

    started = time.monotonic()
    child_started = None
    ready = b''
    previous_finalizing = interrupts.finalizing
    interrupts.finalizing = True
    try:
        spawn('server', server_command, state['server_environment'], (ready_write,))
        os.close(ready_write)
        ready_write = None
        selector.register(ready_read, selectors.EVENT_READ, ('ready', None))
        while True:
            now = time.monotonic()
            if interrupts.received:
                owner['interrupted'] = True
                break
            if processes['server'].poll() is not None:
                results['server']['exit'] = processes['server'].returncode
                owner['unexpected_server_exit'] = True
                break
            if child_started is None and now - started >= 15:
                owner['readiness_timeout'] = True
                break
            if child_started is not None:
                if now - child_started >= 120:
                    results['child']['timeout'] = True
                    break
                if processes['child'].poll() is not None:
                    results['child']['exit'] = processes['child'].returncode
                    owner['child_finished'] = True
                    break
            stop = False
            for key, unused in selector.select(0.1):
                data = os.read(key.fileobj if isinstance(key.fileobj, int) else key.fileobj.fileno(), 65536)
                name, label = key.data
                if name == 'ready':
                    ready += data
                    if not data or b'\n' in ready:
                        selector.unregister(ready_read)
                        os.close(ready_read)
                        ready_read = None
                        target.require(ready == (state['display'] + '\n').encode('ascii'), 'wrong Xvfb readiness identity')
                        target.require(endpoint_present(state['display']), 'ready abstract display missing')
                        owner['readiness'] = dict(display=state['display'], seconds=now - started,
                                                  selected_abstract_endpoint=True)
                        spawn('child', command, state['client_environment'])
                        child_started = time.monotonic()
                    target.require(len(ready) <= 32, 'unbounded readiness output')
                    continue
                if not data:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                row = results[name]
                previous = row[label + '_bytes']
                row[label + '_bytes'] += len(data)
                streams[name, label].write(data[:max(0, CAP - previous)])
                if row[label + '_bytes'] > CAP:
                    row['output_limit'] = True
                    stop = True
            if stop:
                break
    except BaseException as error:
        owner['exception'] = type(error).__name__
    finally:
        for descriptor in (ready_read, ready_write):
            if descriptor is not None:
                try:
                    os.close(descriptor)
                except OSError as error:
                    owner['cleanup_errors'].append(type(error).__name__)
        for name in ('child', 'server'):
            process = processes.get(name)
            if process is None:
                continue
            row = results[name]
            row.setdefault('exit', process.poll())
            try:
                until = time.monotonic() + 5
                alive = target.group_alive(process.pid)
                if alive and process.poll() is not None:
                    row['residual_descendants'] = True
                if alive:
                    row['stop_requested'] = 'SIGTERM'
                    os.killpg(process.pid, signal.SIGTERM)
                settling = min(until, time.monotonic() + 2)
                while target.group_alive(process.pid) and time.monotonic() < settling:
                    process.poll()
                    time.sleep(0.01)
                if target.group_alive(process.pid):
                    row['forced_stop'] = True
                    os.killpg(process.pid, signal.SIGKILL)
                row['final_exit'] = process.wait(timeout=max(0, until - time.monotonic()))
                while target.group_alive(process.pid) and time.monotonic() < until:
                    time.sleep(0.01)
                row['quiescent'] = not target.group_alive(process.pid)
            except BaseException as error:
                row['cleanup_errors'].append(type(error).__name__)
        try:
            until = time.monotonic() + 2
            while selector.get_map() and time.monotonic() < until:
                for key, unused in selector.select(0.1):
                    if key.data[0] == 'ready':
                        selector.unregister(key.fileobj)
                        continue
                    data = os.read(key.fileobj.fileno(), 65536)
                    name, label = key.data
                    if not data:
                        selector.unregister(key.fileobj)
                        key.fileobj.close()
                        continue
                    previous = results[name][label + '_bytes']
                    results[name][label + '_bytes'] += len(data)
                    streams[name, label].write(data[:max(0, CAP - previous)])
                    if results[name][label + '_bytes'] > CAP:
                        results[name]['output_limit'] = True
        except BaseException as error:
            owner['cleanup_errors'].append('capture:' + type(error).__name__)
        try:
            remaining = list(selector.get_map().values())
        except BaseException as error:
            owner['cleanup_errors'].append('selector:' + type(error).__name__)
            remaining = []
        for key in remaining:
            name, unused = key.data
            if name in results:
                results[name]['capture_incomplete'] = True
            if not isinstance(key.fileobj, int):
                try:
                    key.fileobj.close()
                except BaseException as error:
                    owner['cleanup_errors'].append('pipe:' + type(error).__name__)
        try:
            selector.close()
        except BaseException as error:
            owner['cleanup_errors'].append('selector-close:' + type(error).__name__)
        for (name, label), stream in streams.items():
            try:
                stream.flush()
                os.fsync(stream.fileno())
                stream.close()
                results[name][label + '_sha256'] = target.sha(records / name / label)
            except BaseException as error:
                results[name]['cleanup_errors'].append(type(error).__name__)
        try:
            owner['endpoint_absent_after_cleanup'] = not endpoint_present(state['display'])
        except BaseException as error:
            owner['endpoint_absent_after_cleanup'] = False
            owner['cleanup_errors'].append(type(error).__name__)
        try:
            shell_binding(target)
            target.require(resource_links(target, state['manifest'], state['inputs']) == state['resource_links'],
                           'native resource link identity changed after launch')
            target.require(color_absence(target, state['manifest']) == state['color_data_absence'],
                           'optional color-data absence changed after launch')
            for path, expected in state['inputs'].items():
                target.require(target.sha(path) == expected, 'native input changed after launch')
            target.require(target.identity(state['authority']) == state['authority_identity'], 'private authority changed')
        except BaseException as error:
            owner['cleanup_errors'].append('input-check:' + type(error).__name__)
        try:
            if os.path.lexists(state['keymap']):
                info = target.ordinary(state['keymap']).stat()
                target.require(stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid()
                               and info.st_size <= CAP, 'unexpected owned XKB output')
                state['keymap'].unlink()
        except BaseException as error:
            owner['cleanup_errors'].append('keymap:' + type(error).__name__)
        try:
            state['authority'].unlink()
            owner['private_authority_removed'] = True
        except BaseException as error:
            owner['cleanup_errors'].append('authority:' + type(error).__name__)
        for name, row in results.items():
            if name == 'child':
                row['status'] = 'pass' if target.supervision_passed(row) else 'failed'
            else:
                row['status'] = 'resource-stopped' if (row.get('stop_requested') == 'SIGTERM'
                    and row.get('exit') is None and row.get('final_exit') in (0, -signal.SIGTERM)
                    and row.get('quiescent') is True and not owner.get('unexpected_server_exit')
                    and not any(row.get(key) for key in ('forced_stop', 'cleanup_errors', 'output_limit',
                                                        'residual_descendants', 'capture_incomplete'))) else 'failed'
            row['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            try:
                target.write(records / name / 'result.json', row)
            except BaseException as error:
                owner['cleanup_errors'].append(name + '-result:' + type(error).__name__)
        clean = all(row.get('quiescent') is True and not any(row.get(key) for key in
                    ('timeout', 'output_limit', 'exception', 'residual_descendants', 'cleanup_errors',
                     'forced_stop', 'capture_incomplete')) for row in results.values())
        owner['signals'] = list(interrupts.received)
        if owner['signals']:
            owner['interrupted'] = True
        resources_clean = (clean and owner.get('child_finished') and len(processes) == 2
                                   and results['server'].get('status') == 'resource-stopped'
                                   and not any(owner.get(key) for key in
                                               ('exception', 'interrupted', 'unexpected_server_exit', 'readiness_timeout', 'cleanup_errors'))
                                   and owner['endpoint_absent_after_cleanup'] and owner.get('private_authority_removed'))
        owner['resources_clean'] = bool(resources_clean)
        child_exit = results.get('child', {}).get('exit')
        child_final = results.get('child', {}).get('final_exit')
        owner['status'] = ('PASS' if child_exit == child_final == 0 else
                           'BLOCKED' if child_exit == child_final == 78 else 'FAIL') if resources_clean else 'FAIL'
        owner['children'] = results
        owner['duration_seconds'] = time.monotonic() - started
        try:
            target.write(records / 'owner-result.json', owner)
        finally:
            interrupts.finalizing = previous_finalizing
    return owner
