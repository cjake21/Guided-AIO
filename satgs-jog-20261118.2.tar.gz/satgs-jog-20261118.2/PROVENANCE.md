# Source and release provenance

This integration checkout preserves six separately owned components, their notices and upstream contribution paths. It does not manufacture missing owner Git history or make a blanket licensing claim.

The maintained normal source ancestor is `7e7ffdf26e4f5dabcf1574738e6c55af168132fb`. The accepted guide source was reconciled on its normal descendant `2c66a9a73ee13f57f9af440e5b7c24486dbf1403`, before handbook/PTU/update edits. That checkpoint contains 462 source/support files, including the accepted guide component content and retained baseline files. The earlier installed-baseline root `280fb4a8dc11efa35c190c27ebb147e5a2db689b` is historical, not today's application.

The earlier accepted guide application was `0.0.1+guide.20261112.1`, published artifact commit `9cb4042d78d1bcc57bc80739fd65bef97e1d2945`. The subsequent handbook source checkpoint is `ed77ba159463bf9b8a9017ff30a1ecb023dcd61f`, version `0.0.1+handbook.20261112.1`. The later support-only launcher correction was published at artifact commit `a14a1c584a1af1c394aa1b837de6c9fa2110e60c`; it did not change that application's source or wheels. Those historical software and target reports do not qualify the new PTU candidate.

The current release descriptor identifies `ptu-20261117.1`, pairing satgs, ptu_control and serialptu at `0.0.1+ptu.20261117.1`. It retains the existing r3 platform dependency base and declares no workspace migration. The final source publication record must bind the actual new Git checkpoint and archive without a self-referential invented hash. Until that record exists, the descriptor is candidate identity, not evidence of publication or target acceptance.

The original M-SEL comparison remains ground_station `dd4ebf15f98d66cd8e973c7bd83becebef243276` and its actual component pins, not a moving main branch or October delivery snapshot. The original serialptu GUI was inspected at `b9f9c7b03c3c519bd9bf10da1ba291c7c6e6f3d4`. Original continuous jog/soft-limit override/keepalive behavior is historical evidence, not the new bounded-step implementation.

`component-source-map.json`, `requirements/development-*`, `history/` and `DELIVERY.md` retain earlier provenance and test claims. They are historical records, not current file inventories or reusable hashes for newly built owner wheels. `provenance.json` identifies the current owner changes, accepted origins and selected handbook screenshots. Current acceptance binds actual source and installed inputs automatically in its disposable technical records. Raw captures and environments do not belong in product commits.

All current source edits are coordinated in this integration line. Ground station retains orchestration; sat tracker retains higher-level PTU control; serialptu retains low-level protocols; Pixhawk retains observation; Meteor and stomp retain messaging. Cole and Ian coordinate reviewed shared changes upstream. This is not permission to maintain unmanaged divergent owner copies.

The genuine protobuf modules were generated with protoc 33.6 for protobuf 6.33.6 and remain source/build inputs. The compiler is not an application dependency. Third-party/native artifact provenance is platform-specific and must be recorded with the actual selected closure.

Preserve [NOTICES.md](NOTICES.md), Meteor's license/data-rights exclusions and source headers, serialptu's Government/MITRE notice, and stomp's Apache-2.0 notice. Upstream author metadata does not imply approval of this integration candidate. There is no public mirror or external redistribution grant.

Host-tested, Pi-tested and physically commissioned are independent states. Source inspection, GUI screenshots and successful software checks do not establish equipment readiness, navigation, heading, broker delivery or physical stopping.
