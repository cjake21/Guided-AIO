# Contributing

Make changes in the reviewed SATGS integration source line and keep the six component ownership boundaries. Coordinate shared fixes with Cole and Ian and contribute them to the owning repositories. Do not edit unmanaged copies concurrently or create a separate Guided Arrow product.

The current normal-history candidate is `feature/operator-handbook-ptu`. Its publication establishes the long-lived `integration` source line at the same reviewed commit. Future changes use short-lived feature branches and reviewed integration. This adds a source line without replacing the server default or authorizing a protected merge.

Before implementation, inspect the current branch and working-tree status, read repository instructions, and produce an approved written plan with file scope, invariants, risks and validation. Preserve unrelated work. Use small reviewable changes for source reconciliation, PTU behavior, handbook content and update tooling. Do not commit directly to a shared branch.

Component changes belong to their owner:

- Ground station owns shared selection, persistent configuration, planning, orchestration and GUI/CLI presentation.
- Sat tracker owns higher-level PTU clients, managers, tracking and correlated outcomes.
- Serialptu owns protocol construction, quantization and serial driver behavior.
- Pixhawk owns navigation observation and handling.
- Meteor and the selected lower transport own shared messaging.

Reuse shared operations, Messenger, station/session ownership and existing effect-controlled acceptance. GUI callbacks must not introduce serial shortcuts, independent state engines or invented readiness. Keep comments sparse and use direct prose without em dashes.

Canonical operator prose is under `components/ground_station/docs/`. Update the existing offline compiler/content tests and release-matched examples together. Root `docs/` is retained historical material, not a second manual. Host screenshots must be labeled as host captures.

Keep credentials, workstation environments, station settings/results, captures, execution evidence and binaries outside Git. Preserve all notices and source provenance. Generated protobuf modules remain real checked-in inputs, not runtime-generated stubs.

Run the source, build and admitted installed checks in [BUILDING.md](BUILDING.md). Record what actually ran, including blocked coverage and failed attempts. Host tests, target tests and physical commissioning remain separate.

Git publication and review mutations require the user's explicit scoped authority. Never force-push, rewrite published history, move existing tags, delete refs, replace the default, change permissions or merge protected work as a routine development step. Use the actual internal server's review workflow; do not assume GitHub or Bitbucket Cloud facilities.

## Synchronizing an inactive checkout

First inspect local work and the requested ref with `tools/source_status.py`. After approval, fetch one explicit source ref using the reviewed authentication configuration:

```sh
export GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0
git -c core.fsmonitor=false -c core.hooksPath=/dev/null fetch origin refs/heads/feature/operator-handbook-ptu:refs/remotes/origin/feature/operator-handbook-ptu
python3.11 -I -B -S tools/source_status.py --ref refs/remotes/origin/feature/operator-handbook-ptu
git -c core.fsmonitor=false -c core.hooksPath=/dev/null merge --ff-only refs/remotes/origin/feature/operator-handbook-ptu
```

A dirty checkout, missing ref, authentication failure or non-fast-forward requires review. Do not reset another person's work. Fetch/merge changes source only; it never builds, installs, migrates, selects an application or updates a running GUI.
