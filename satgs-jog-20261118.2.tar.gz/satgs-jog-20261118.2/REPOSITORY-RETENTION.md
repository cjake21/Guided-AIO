# Repository source and retention decisions

The read-only internal Git observation on 2026-11-12 advertised the seventeen heads below, no tags and no usable HEAD/symbolic default. Do not infer that an occupied `main` is free, replace the server default or clone an implicit default. The maintained source candidate uses `feature/operator-handbook-ptu` explicitly and descends from the existing source line. Artifact-only histories are not merged into that line.

The current operator-reported Pi selection is `0.0.1+guide.20261112.1` at `/home/admin/satgs-user-guide-20261112-app-manager`, using `/home/admin/satgs/station`. This is a supplied selection record, not a direct Pi inspection. The passing guide result remains separate from the new handbook candidate. Its rollback chain retains native UI and runtime registrations. The offline installer still consumes the retained r3 platform bundle. None of those dependencies is migrated by publishing source.

Every row is a **retain-in-place** decision. No branch deletion, tag move, history rewrite, pruning, protected merge, default replacement or permission change is requested or performed. A missing consumer inventory is a reason to retain content, not evidence that it is unused.

| Ref, relative to `refs/heads/` | Observed complete tip | Classification and concrete reason | Action |
| --- | --- | --- | --- |
| `development/operator-20261028-r3` | `7e7ffdf26e4f5dabcf1574738e6c55af168132fb` | Existing normal source: child of installed-baseline root, source/build/provenance ancestor of this candidate | Retain source anchor |
| `delivery/installed-baseline-20261008` | `280fb4a8dc11efa35c190c27ebb147e5a2db689b` | Original approved source root and fixed installed-check application identity | Retain source/release anchor |
| `artifacts/user-guide-20261112` | `9cb4042d78d1bcc57bc80739fd65bef97e1d2945` | Published/fetch-verified guide download; current supplied daily selection and accepted Pi guide result | Retain current release/rollback route |
| `artifacts/native-ui-20261111` | `9bdd7bfa3ebb76d8c840d36baa3625c932aec77d` | Published/fetch-verified native UI download; retained `ui` registration and rollback environment | Retain rollback route |
| `artifacts/native-ui-launcher-fix-20261111` | `d36b5729c56d71b27682c68261a61f022d27c8ba` | Published/fetch-verified launcher migration support; predecessor dispatcher remains an exact supported upgrade input | Retain migration/support route |
| `artifacts/runtime-qpt130-20261110` | `3e38c889b6322ebabac49fbf804545b2d3ffed8f` | Published/fetch-verified runtime download; retained runtime registration and serial-owner wheel/context lineage | Retain rollback/dependency route |
| `artifacts/operator-20261028-r3` | `49d7a656c1c7797cf8cb27b3530888abe4c2d6c2` | Offline r3 platform dependency bundle still required by the update installer | Retain active dependency route |
| `artifacts/daily-housekeeping-20261111` | `10e684291fe848b613537fa197a65827fd2b0013` | Housekeeping support/history; complete current consumer and unique-content checks not established | Retain unresolved support hold |
| `artifacts/operator-checks-20261105-v4` | `e580a764955c6530cc227d29fdd680f93e64de33` | Earlier acceptance route; historical failure/results and remaining consumers are not safe-deletion evidence | Retain unresolved support hold |
| `artifacts/operator-r4-checks-20261110` | `b371b8201cdf59010a1a6637b265f3df2a57000a` | Prior R4 acceptance route; current callers/unique material not fully inventoried | Retain unresolved support hold |
| `artifacts/operator-r4-installer-20261110` | `9e55a0508a28888ca86cc6ce478953dfa7d44140` | Earlier installer route; retain recovery/download history until replacement users are identified | Retain unresolved installer hold |
| `artifacts/operator-ui-20261105-r4` | `a310209e5cea3dee44069e544e0424194bffa50b` | Prior UI download; no complete proof that its independent artifact history is redundant | Retain unresolved artifact hold |
| `artifacts/pi-arm64-280fb4a8-20261008` | `58636e333a16068fb8afc035ead352db4deb402c` | Original ARM64 offline preparation route and installed-baseline dependency history | Retain historical dependency route |
| `artifacts/pi-installed-check-20261014` | `fdbb2a184335ed46f9a0ccb665525ea3e694e68e` | Earlier fixed installed-check support; unique history/consumer checks incomplete | Retain unresolved support hold |
| `artifacts/pi-installed-check-one-run-20261014` | `68f9a4194ad1d036346c5ce32e725e0163ae1aed` | Historical one-command support route; retain rather than infer safe removal from its name | Retain unresolved support hold |
| `artifacts/pi-installed-check-offline-20261014-v2` | `6ae9285d4f8f9e9b6064f3c9a65bb1ef31a9fa16` | Historical offline support, including preserved failed startup attempts; callers not migrated here | Retain unresolved support hold |
| `artifacts/pi-installed-check-offline-20261015-v3` | `160b3b1d953e5dee9f3ea70fe615d52f3a213d64` | Historical corrected startup support and accepted installed-check lineage | Retain historical support route |

The four recent download classifications above also use the actual publication receipts and verified archive identities, not their branch names alone. The normal source ancestry is verified separately from these artifact histories. Complete reachability/unique-commit inventories for the unresolved rows have **not** been fabricated. No potentially large binary history was fetched merely to imitate a cleanup check.

## Metadata and administration still requiring an assigned interface

A normal-TLS, read-only anonymous request to this repository's Bitbucket Server REST metadata endpoint returned HTTP 401. No credential/cookie was supplied or exposed, and no authentication bypass was attempted. SSH Git reference access works, but does not establish REST permission, the configured server default, open review state, branch policies, CI jobs or an artifact-registry service. Those metadata remain unavailable through the checked route, not absent.

Before any destructive/admin action, an authorized repository owner must supply or expose the actual default, open reviews, CI/consumer references and unique-content inventory. Then prepare one exact action set with current tips, verified durable preservation, restoration commands and conflict handling. There is currently **no safe deletion set** and no need to pause handbook/PTU development for one.

Candidate publication adds one long-lived `integration` source line and the reviewed `feature/operator-handbook-ptu` branch at the same normal descendant, with an immutable versioned candidate tag. This does not replace the server's configured default, whose metadata remains unavailable. Future changes use short-lived feature branches and reviewed fast-forward integration. Recommend review controls and immutable tags, but do not change protection settings under this task. The exact candidate commit and publication result belong in the release handoff, not an assumed moving-ref identity.

## Future binary distribution

Ask the organization for an assigned internal release-artifact or package location with retention and access rules. No such registry was observed or provisioned here. Until one is assigned, preserve every current browser download. A single maintained internal offline-release channel with immutable versioned downloads is preferable to another dated artifact branch for each small correction; it must not import binary history into source or overwrite old downloads. Field/Pi users continue the browser/offline route without Git authentication.

Branch-list decluttering and reclaiming Git objects are different operations. Tags or backups retain reachable content; deleting a visible branch alone does not prove safe storage reduction.
