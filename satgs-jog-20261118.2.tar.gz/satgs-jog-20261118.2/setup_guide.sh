#!/bin/bash

if [ -z "${BASH_VERSION:-}" ]; then
    printf '%s\n' 'Use a Bash terminal: . ./setup_guide.sh --accept-trusted-native' >&2
    return 2 2>/dev/null || exit 2
fi
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    printf '%s\n' 'Use: . ./setup_guide.sh --accept-trusted-native' >&2
    exit 2
fi
if [ "$#" -ne 1 ] || [ "$1" != '--accept-trusted-native' ]; then
    printf '%s\n' 'Use: . ./setup_guide.sh --accept-trusted-native' >&2
    return 2
fi
if declare -F satgs_guide_setup >/dev/null; then
    printf '%s\n' 'Existing setup function was preserved; setup not run.' >&2
    return 2
fi

satgs_guide_setup() {
    local satgs_guide_dir satgs_guide_status
    satgs_guide_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || return
    printf '%s\n' 'Setup uses the reviewed CPython/stdlib/native-runtime trust boundary, not syscall isolation.'
    /usr/bin/python3.11 -I -B -S "$satgs_guide_dir/support/setup_operator_update.py"
    satgs_guide_status=$?
    if [ "$satgs_guide_status" -ne 0 ]; then
        printf '%s\n' 'Setup failed; daily launcher preparation and selection were not run. Keep the printed reports.' >&2
        return "$satgs_guide_status"
    fi
    . "$satgs_guide_dir/launchers/setup_daily.sh"
    satgs_guide_status=$?
    if [ "$satgs_guide_status" -ne 0 ]; then
        printf '%s\n' 'Launcher preparation failed; the guide candidate was not selected. Keep the setup reports.' >&2
        return "$satgs_guide_status"
    fi
    printf '%s\n' 'Guide candidate installed; existing daily selection retained. No GUI was opened.' \
        'Run the consolidated checks before explicitly selecting guide.'
}

if satgs_guide_setup "$@"; then
    unset -f satgs_guide_setup
    return 0
else
    unset -f satgs_guide_setup
    return 1
fi
