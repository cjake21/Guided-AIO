"""Prepare shared SATGS launchers and explicitly select a reviewed installation."""

import argparse
import ast
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import secrets
import stat
import sys


SCHEMA = 'satgs-daily-selection.v1'
VERSIONS = {'runtime': '0.0.1+runtime.20261110.1', 'ui': '0.0.1+ui.20261111.1',
            'guide': '0.0.1+guide.20261112.1', 'handbook': '0.0.1+handbook.20261112.1'}
DEFAULT_IDENTITIES = {
    'runtime': {'application': '/home/admin/satgs-runtime-20261110-app-manager',
                'candidate_version': VERSIONS['runtime']},
    'ui': {'application': '/home/admin/satgs-native-ui-20261111-app-manager',
           'candidate_version': VERSIONS['ui']},
    'guide': {'application': '/home/admin/satgs-user-guide-20261112-app-manager',
              'candidate_version': VERSIONS['guide']},
    'handbook': {'application': '/home/admin/satgs-handbook-20261112-app-manager',
                 'candidate_version': VERSIONS['handbook']},
}
BOUND_IDENTITIES = None
LEGACY_SOURCE_SHA256 = 'cfb0ef9f9326556916500da18358d50e71481077ebb73e9a17a39204f3f94aaf'
PREVIOUS_UI_SOURCE_SHA256 = '9375e11b05a8ac75594e661532f07c2038311bd3c1696cfbf92297f704e1ae36'
PREVIOUS_GUIDE_SOURCE_SHA256 = 'f27afb1b239b112fdb9c8d8b750c37c4b887db99585bcce2c2bee7250a69a596'
ACTIVITY_SOURCE_SHA256 = '96be5b9b49f7f3573307edb94c2d2f2d848841695c69b5caebdb037be5a7c4cc'
DIRECTORY_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
FILE_FLAGS = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC


def ordinary_directory(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('Use an absolute directory without parent traversal.')
    for component in (path, *path.parents):
        if not stat.S_ISDIR(component.lstat().st_mode):
            raise ValueError('A selected directory or parent is unsuitable.')
    return path


def _identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
            info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def regular_bytes(path, limit=65536, *, mode=None):
    ordinary_directory(Path(path).parent)
    descriptor = os.open(path, FILE_FLAGS)
    try:
        before = os.fstat(descriptor)
        if (not stat.S_ISREG(before.st_mode) or before.st_size > limit
                or before.st_uid != os.geteuid() or before.st_nlink != 1):
            raise ValueError('An owned bounded ordinary file is required.')
        if mode is not None:
            actual = stat.S_IMODE(before.st_mode)
            if actual & ~mode or not actual & stat.S_IRUSR or (mode & stat.S_IXUSR and not actual & stat.S_IXUSR):
                raise ValueError('A managed file has unsuitable permissions.')
        data = os.read(descriptor, limit + 1)
        if (len(data) != before.st_size or len(data) > limit
                or _identity(before) != _identity(os.fstat(descriptor))
                or _identity(before) != _identity(Path(path).lstat())):
            raise ValueError('A file changed during inspection.')
        return data
    finally:
        os.close(descriptor)


def registered(profile=None):
    selected = profile if profile is not None else BOUND_IDENTITIES or DEFAULT_IDENTITIES
    if not isinstance(selected, dict) or set(selected) != set(VERSIONS):
        raise ValueError('The registered application identities are invalid.')
    result = {}
    for name, version in VERSIONS.items():
        row = selected[name]
        if not isinstance(row, dict) or set(row) != {'application', 'candidate_version'} or row['candidate_version'] != version:
            raise ValueError('The registered application identity is invalid.')
        if not isinstance(row['application'], (str, Path)):
            raise ValueError('The registered application directory is invalid.')
        application = Path(row['application'])
        if not application.is_absolute() or '..' in application.parts:
            raise ValueError('The registered application directory is invalid.')
        result[name] = dict(application=str(application), candidate_version=version)
    if len({row['application'] for row in result.values()}) != len(result):
        raise ValueError('The reviewed installations must remain separate.')
    return result


def check_application(identity, *, entries=True):
    application = ordinary_directory(identity['application'])
    if entries:
        ordinary_directory(application / 'bin')
        for name in ('python', 'satgs-operator', 'satgs-operator-gui'):
            entry = application / 'bin' / name
            info = entry.lstat()
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid()
                    or stat.S_IMODE(info.st_mode) & 0o022 or not os.access(entry, os.X_OK)):
                raise ValueError('A reviewed application entry point is unavailable.')
    metadata = application / 'lib/python3.11/site-packages' / ('satgs-' + identity['candidate_version'] + '.dist-info/METADATA')
    headers = regular_bytes(metadata, 256 * 1024).decode('utf-8').split('\n\n', 1)[0].splitlines()
    names = [line[6:] for line in headers if line.startswith('Name: ')]
    versions = [line[9:] for line in headers if line.startswith('Version: ')]
    if names != ['satgs'] or versions != [identity['candidate_version']]:
        raise ValueError('Installed application metadata does not match the reviewed selection.')
    return application


def _paths(home):
    return {
        'dispatcher': home / '.local/share/satgs-launchers/handbook-20261112/daily.py',
        'selection': home / '.config/satgs/operator.json',
        'cli': home / '.local/bin/satgs-operator',
        'gui': home / '.local/bin/satgs-operator-gui',
        'menu': home / '.local/share/applications/satgs-runtime-20261110.desktop',
    }


def _quote(value):
    return "'" + str(value).replace("'", "'\\''") + "'"


def _wrapper(dispatcher, settings, mode):
    return ('#!/bin/sh\nset -eu\nexec /usr/bin/python3 -I -B -S ' + _quote(dispatcher)
            + ' --selected ' + mode + ' --settings ' + _quote(settings) + ' "$@"\n').encode()


def _menu(home):
    executable = str(home / '.local/bin/satgs-operator-gui')
    executable = executable.replace('\\', '\\\\').replace('"', '\\"').replace('`', '\\`').replace('$', '\\$').replace('%', '%%')
    return ('[Desktop Entry]\nType=Application\nName=SATGS\n'
            'Comment=Open the selected SATGS station\nExec="' + executable + '"\n'
            'Terminal=false\nCategories=Science;\nStartupNotify=false\n').encode()


def _dispatcher(profile):
    lines = regular_bytes(Path(__file__)).decode('utf-8').splitlines(keepends=True)
    positions = [index for index, line in enumerate(lines) if line.startswith('BOUND_IDENTITIES = ')]
    if len(positions) != 1:
        raise ValueError('The reviewed dispatcher binding location is unavailable.')
    lines[positions[0]] = 'BOUND_IDENTITIES = ' + repr(profile) + '\n'
    return ''.join(lines).encode()


def _previous_dispatcher(path, profile, names, expected_sha256):
    data = regular_bytes(path, mode=0o600)
    lines = data.decode('utf-8').splitlines(keepends=True)
    positions = [index for index, line in enumerate(lines) if line.startswith('BOUND_IDENTITIES = ')]
    if len(positions) != 1:
        raise ValueError('The previous managed dispatcher binding is not the reviewed managed version.')
    position = positions[0]
    try:
        binding = ast.literal_eval(lines[position].split(' = ', 1)[1])
    except (SyntaxError, ValueError, TypeError, RecursionError):
        raise ValueError('The previous managed dispatcher binding is invalid.') from None
    expected = {name: profile[name] for name in names}
    if binding != expected or lines[position] != 'BOUND_IDENTITIES = ' + repr(expected) + '\n':
        raise ValueError('The previous managed dispatcher identities do not match the reviewed installations.')
    lines[position] = 'BOUND_IDENTITIES = None\n'
    if hashlib.sha256(''.join(lines).encode()).hexdigest() != expected_sha256:
        raise ValueError('The previous managed dispatcher is not the reviewed managed version.')
    return data


def _decode_selection(raw, profile):
    value = json.loads(raw, object_pairs_hook=_unique_object)
    if (not isinstance(value, dict) or set(value) != {'schema', 'application', 'workspace', 'candidate_version'}
            or value['schema'] != SCHEMA or not isinstance(value['workspace'], str)):
        raise ValueError('The shared selection is invalid; it was not replaced.')
    workspace = Path(value['workspace'])
    if not workspace.is_absolute() or '..' in workspace.parts:
        raise ValueError('The shared workspace selection is invalid.')
    if not any(all(value[key] == identity[key] for key in ('application', 'candidate_version'))
               for identity in profile.values()):
        raise ValueError('The shared selection does not identify a registered installation.')
    return value


def _selection(path, profile):
    return _decode_selection(regular_bytes(path, 4096, mode=0o600), profile)


def _check_parents(path, home):
    for parent in Path(path).parents:
        if parent == home.parent:
            break
        if parent.exists() or parent.is_symlink():
            ordinary_directory(parent)
            info = parent.lstat()
            if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o022:
                raise ValueError('A managed directory has unsuitable ownership or permissions.')


def _parent(path, *, create=False):
    descriptor = os.open('/', DIRECTORY_FLAGS)
    try:
        for component in Path(path).parent.parts[1:]:
            try:
                child = os.open(component, DIRECTORY_FLAGS, dir_fd=descriptor)
            except FileNotFoundError:
                if not create:
                    raise
                try:
                    os.mkdir(component, mode=0o700, dir_fd=descriptor)
                except FileExistsError:
                    pass
                child = os.open(component, DIRECTORY_FLAGS, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _new(path, data, mode):
    parent = _parent(path, create=True)
    try:
        descriptor = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                             mode, dir_fd=parent)
        try:
            with os.fdopen(descriptor, 'wb', closefd=False) as stream:
                stream.write(data)
                stream.flush()
                os.fsync(descriptor)
        finally:
            os.close(descriptor)
        os.fsync(parent)
    finally:
        os.close(parent)


def _change(path, old, new, mode):
    if old == new:
        return
    if old is None:
        _new(path, new, mode)
        return
    if regular_bytes(path, mode=mode) != old:
        raise ValueError('A managed file changed; the previous selection was retained.')
    temporary = path.with_name('.satgs-new-' + secrets.token_hex(8))
    _new(temporary, new, mode)
    parent = _parent(path)
    try:
        if regular_bytes(path, mode=mode) != old:
            raise ValueError('A managed file changed; staged bytes were retained for review.')
        os.replace(temporary.name, path.name, src_dir_fd=parent, dst_dir_fd=parent)
        os.fsync(parent)
    finally:
        os.close(parent)


@contextmanager
def _lock(home):
    path = home / '.config/satgs/.daily-selection.lock'
    _new(path, b'owned launcher selection\n', 0o600)
    expected = path.lstat()
    try:
        yield
    finally:
        try:
            if _identity(path.lstat()) == _identity(expected):
                parent = _parent(path)
                try:
                    os.unlink(path.name, dir_fd=parent)
                finally:
                    os.close(parent)
        except FileNotFoundError:
            pass


def _backup(home, files):
    if not files:
        return None
    destination = home / '.local/share/satgs-launchers/backups' / ('handbook-20261112-' + secrets.token_hex(8))
    parent = _parent(destination, create=True)
    try:
        os.mkdir(destination.name, mode=0o700, dir_fd=parent)
    finally:
        os.close(parent)
    mapping = {}
    for name, (path, data, mode) in files.items():
        saved = destination / name
        _new(saved, data, 0o600)
        if regular_bytes(saved) != data:
            raise OSError('Launcher backup could not be verified; selection was not changed.')
        mapping[name] = dict(original=str(path), mode=stat.S_IMODE(path.lstat().st_mode),
                             sha256=hashlib.sha256(data).hexdigest())
    _new(destination / 'mapping.json', (json.dumps(mapping, sort_keys=True) + '\n').encode(), 0o600)
    return str(destination)


def _managed(home, profile):
    paths = _paths(home)
    wanted = {'dispatcher': (_dispatcher(profile), 0o600),
              'cli': (_wrapper(paths['dispatcher'], paths['selection'], 'cli'), 0o700),
              'gui': (_wrapper(paths['dispatcher'], paths['selection'], 'gui'), 0o700),
              'menu': (_menu(home), 0o644)}
    return paths, wanted


def prepare(home, *, identities=None):
    home = ordinary_directory(home)
    profile = registered(identities)
    paths, wanted = _managed(home, profile)
    for path in paths.values():
        _check_parents(path, home)
    _check_parents(home / '.local/share/satgs-launchers/backups/claim', home)
    previous = {}
    legacy = home / '.local/share/satgs-launchers/runtime-20261110/daily.py'
    previous_ui = home / '.local/share/satgs-launchers/ui-20261111/daily.py'
    previous_guide = home / '.local/share/satgs-launchers/guide-20261112/daily.py'
    uses_legacy = False
    uses_previous_ui = False
    uses_previous_guide = False
    for name, (data, mode) in wanted.items():
        try:
            current = regular_bytes(paths[name], mode=mode)
        except FileNotFoundError:
            current = None
        allowed = [data]
        if name in ('cli', 'gui'):
            allowed.append(_wrapper(legacy, paths['selection'], name))
            uses_legacy = uses_legacy or current == allowed[-1]
            allowed.append(_wrapper(previous_ui, paths['selection'], name))
            uses_previous_ui = uses_previous_ui or current == allowed[-1]
            allowed.append(_wrapper(previous_guide, paths['selection'], name))
            uses_previous_guide = uses_previous_guide or current == allowed[-1]
        if current is not None and current not in allowed:
            raise ValueError('An existing user launcher differs; nothing was replaced.')
        previous[name] = current
    if uses_legacy and hashlib.sha256(regular_bytes(legacy, mode=0o600)).hexdigest() != LEGACY_SOURCE_SHA256:
        raise ValueError('The previous dispatcher is not the reviewed managed version.')
    previous_ui_bytes = (_previous_dispatcher(previous_ui, profile, ('runtime', 'ui'), PREVIOUS_UI_SOURCE_SHA256)
                         if uses_previous_ui else None)
    previous_guide_bytes = (_previous_dispatcher(previous_guide, profile, ('runtime', 'ui', 'guide'),
                                                PREVIOUS_GUIDE_SOURCE_SHA256)
                            if uses_previous_guide else None)
    try:
        selection_bytes = regular_bytes(paths['selection'], 4096, mode=0o600)
        selection = _decode_selection(selection_bytes, profile)
    except FileNotFoundError:
        selection = dict(schema=SCHEMA, **profile['runtime'], workspace=str(home / 'satgs/station'))
        selection_bytes = None
    check_application({key: selection[key] for key in ('application', 'candidate_version')})
    desired_selection = (json.dumps(selection, sort_keys=True) + '\n').encode()
    with _lock(home):
        if previous_ui_bytes is not None and regular_bytes(previous_ui, mode=0o600) != previous_ui_bytes:
            raise ValueError('The previous managed dispatcher changed before preparation.')
        if previous_guide_bytes is not None and regular_bytes(previous_guide, mode=0o600) != previous_guide_bytes:
            raise ValueError('The previous guide dispatcher changed before preparation.')
        for name, old in previous.items():
            if old is not None and regular_bytes(paths[name], mode=wanted[name][1]) != old:
                raise ValueError('A managed launcher changed before preparation.')
        if selection_bytes is not None and regular_bytes(paths['selection'], 4096, mode=0o600) != selection_bytes:
            raise ValueError('The shared selection changed before preparation.')
        changing = any(old is not None and old != wanted[name][0] for name, old in previous.items())
        changes = ({name: (paths[name], old, wanted[name][1]) for name, old in previous.items()
                    if old is not None} if changing else {})
        if changes and selection_bytes is not None:
            changes['selection'] = (paths['selection'], selection_bytes, 0o600)
        backup = _backup(home, changes)
        for name, (data, mode) in wanted.items():
            _change(paths[name], previous[name], data, mode)
        if selection_bytes is None:
            _new(paths['selection'], desired_selection, 0o600)
        elif regular_bytes(paths['selection'], 4096, mode=0o600) != selection_bytes:
            raise ValueError('The shared selection changed during preparation; its bytes were retained.')
    return dict(status='PASS', workspace=selection['workspace'], application=selection['application'],
                selected_version=selection['candidate_version'], backup=backup,
                workspace_modified=False, application_launched=False)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Selection or station JSON contains duplicate fields.')
        result[key] = value
    return result


@contextmanager
def _idle_station(selection, profile):
    application = check_application(profile['handbook'], entries=False)
    package = application / 'lib/python3.11/site-packages/satgs'
    if regular_bytes(package / '_package_layout.py', mode=0o644) != b'INSTALLED = True\n':
        raise ValueError('The passive station guard must come from the installed handbook package.')
    path = package / 'operator_activity.py'
    raw = regular_bytes(path, 256 * 1024, mode=0o644)
    if hashlib.sha256(raw).hexdigest() != ACTIVITY_SOURCE_SHA256:
        raise ValueError('The installed passive station guard differs from the reviewed release.')
    namespace = dict(__file__=str(path), __name__='_satgs_selection_activity')
    exec(compile(raw, str(path), 'exec', dont_inherit=True), namespace)
    workspace = ordinary_directory(selection['workspace'])
    station_path = workspace / 'station.json'
    station = regular_bytes(station_path, 1024 * 1024, mode=0o600)
    settings = json.loads(station, object_pairs_hook=_unique_object)
    if not isinstance(settings, dict) or namespace['validate_marker'](station_path, settings) is None:
        raise ValueError('Selection requires a managed station marker; legacy unmarked work cannot be proven idle.')
    with namespace['StationLease'](workspace):
        if regular_bytes(station_path, 1024 * 1024, mode=0o600) != station:
            raise ValueError('Station settings changed before idle selection; the previous selection was retained.')
        yield


def select(home, target, *, identities=None):
    home = ordinary_directory(home)
    profile = registered(identities)
    if target not in profile:
        raise ValueError('Select runtime, ui, guide or handbook explicitly.')
    paths, wanted = _managed(home, profile)
    for path in paths.values():
        _check_parents(path, home)
    _check_parents(home / '.local/share/satgs-launchers/backups/claim', home)
    for name, (data, mode) in wanted.items():
        if regular_bytes(paths[name], mode=mode) != data:
            raise ValueError('Complete reviewed launcher preparation is required before selection.')
    check_application(profile[target])
    with _lock(home):
        for name, (data, mode) in wanted.items():
            if regular_bytes(paths[name], mode=mode) != data:
                raise ValueError('Managed launchers changed before selection; the previous choice was retained.')
        old = regular_bytes(paths['selection'], 4096, mode=0o600)
        selection = _decode_selection(old, profile)
        with _idle_station(selection, profile):
            updated = dict(selection, **profile[target])
            new = (json.dumps(updated, sort_keys=True) + '\n').encode()
            backup = None
            if updated != selection:
                backup = _backup(home, {'selection': (paths['selection'], old, 0o600)})
                _change(paths['selection'], old, new, 0o600)
    return dict(status='PASS', workspace=selection['workspace'], application=updated['application'],
                selected_version=updated['candidate_version'], backup=backup,
                workspace_modified=False, application_launched=False)


def _first_command(arguments):
    index = 0
    while index < len(arguments):
        value = arguments[index]
        if value == '--format':
            index += 2
        elif value.startswith('--format='):
            index += 1
        else:
            return value
    return None


def launch_plan(mode, arguments, selection_path):
    profile = registered()
    selection = _selection(selection_path, profile)
    supplied, forwarded, overrides = list(arguments), [], []
    index = 0
    while index < len(supplied):
        value = supplied[index]
        if value == '--workspace':
            if index + 1 == len(supplied):
                raise ValueError('--workspace requires a path.')
            overrides.append(supplied[index + 1])
            index += 2
        elif value.startswith('--workspace='):
            overrides.append(value.split('=', 1)[1])
            index += 1
        else:
            forwarded.append(value)
            index += 1
    if len(overrides) > 1 or (overrides and not overrides[0]):
        raise ValueError('Select one explicit workspace.')
    workspace = Path(os.path.abspath(overrides[0])) if overrides else Path(selection['workspace'])
    help_requested = any(value in ('--help', '-h') for value in forwarded)
    command = _first_command(forwarded)
    docs_requested = mode == 'cli' and command in ('docs', '--read-docs')
    if not help_requested and not docs_requested:
        if mode == 'cli' and overrides and command == 'init':
            try:
                workspace.lstat()
            except FileNotFoundError:
                ordinary_directory(workspace.parent)
            else:
                ordinary_directory(workspace)
        else:
            ordinary_directory(workspace)
    if mode not in ('cli', 'gui') or (mode == 'gui' and forwarded
                                    and not all(value in ('--help', '-h') for value in forwarded)):
        raise ValueError('Unsupported GUI arguments; use --workspace or --help.')
    application = check_application(selection)
    entry = application / 'bin' / ('satgs-operator-gui' if mode == 'gui' else 'satgs-operator')
    environment = {key: os.environ[key] for key in
                   ('HOME', 'USER', 'LOGNAME', 'DISPLAY', 'WAYLAND_DISPLAY', 'XAUTHORITY', 'XDG_SESSION_TYPE',
                    'XDG_RUNTIME_DIR', 'DBUS_SESSION_BUS_ADDRESS', 'XDG_CURRENT_DESKTOP',
                    'XDG_SESSION_DESKTOP', 'DESKTOP_SESSION', 'SSH_CONNECTION', 'SSH_CLIENT', 'SSH_TTY',
                    'LANG', 'LC_ALL', 'TZ') if key in os.environ}
    environment.update(PATH='/usr/bin:/bin', PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
                       STOMP_SKIP_HOSTNAME_SCAN='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    interpreter = str(application / 'bin/python')
    command = [interpreter, '-I', '-B', str(entry), '--workspace', str(workspace), *forwarded]
    return interpreter, command, environment


def launch(mode, arguments, selection_path):
    os.execve(*launch_plan(mode, arguments, selection_path))


def main(arguments=None):
    supplied = list(sys.argv[1:] if arguments is None else arguments)
    if supplied[:1] == ['--selected']:
        if len(supplied) < 4 or supplied[1] not in ('cli', 'gui') or supplied[2] != '--settings':
            raise ValueError('Unsupported launcher selection.')
        return launch(supplied[1], supplied[4:], Path(supplied[3]))
    parser = argparse.ArgumentParser(allow_abbrev=False, description='Prepare SATGS launchers without changing station data.')
    parser.add_argument('--select', choices=tuple(VERSIONS), help='Explicitly select an already installed and reviewed version.')
    args = parser.parse_args(supplied)
    home = Path.home()
    if args.select is not None and _paths(home)['dispatcher'].exists():
        result = select(home, args.select)
    else:
        result = prepare(home)
        if args.select is not None:
            result = select(home, args.select)
    print('Selected: ' + next(name for name, version in VERSIONS.items() if result['selected_version'] == version))
    print('Selection only: the GUI was not opened.')
    print('CLI: satgs-operator --help; satgs-operator status')
    print('GUI: SATGS in the application menu')
    print('GUI terminal alternative: satgs-operator-gui (desktop session required).')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print('SATGS: Selection cancelled; retained files were not removed.', file=sys.stderr)
        raise SystemExit(130)
    except (OSError, ValueError, UnicodeError) as error:
        message = str(error) if isinstance(error, ValueError) else 'Required launcher files are unavailable; selection was not completed.'
        print('SATGS: ' + message, file=sys.stderr)
        raise SystemExit(1)
