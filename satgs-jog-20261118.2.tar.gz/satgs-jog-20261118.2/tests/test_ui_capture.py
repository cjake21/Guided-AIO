import importlib.util
from pathlib import Path
import struct
import unittest
import zlib


SOURCE = Path(__file__).resolve().parents[1] / 'support/ui_capture.py'
SPEC = importlib.util.spec_from_file_location('capture_converter_fixture', SOURCE)
capture = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(capture)


def frame(byte_order=0):
    header = [100, 7, 2, 24, 1280, 900, 0, byte_order, 32, 0, 32, 32, 5120,
              4, 0xff0000, 0xff00, 0xff, 8, 256, 0, 1280, 900, 0, 0, 0]
    data = bytearray(struct.pack('!25I', *header))
    data.extend(bytes(5120 * 900))
    return data


def pixels(png):
    if png[:8] != b'\x89PNG\r\n\x1a\n':
        raise AssertionError('Missing PNG signature')
    offset, compressed, dimensions = 8, bytearray(), None
    while offset < len(png):
        size = struct.unpack('!I', png[offset:offset + 4])[0]
        kind, payload = png[offset + 4:offset + 8], png[offset + 8:offset + 8 + size]
        crc = struct.unpack('!I', png[offset + 8 + size:offset + 12 + size])[0]
        if crc != zlib.crc32(kind + payload) & 0xffffffff:
            raise AssertionError('PNG checksum differs')
        if kind == b'IHDR':
            dimensions = struct.unpack('!2I5B', payload)
        if kind == b'IDAT':
            compressed.extend(payload)
        offset += size + 12
    return dimensions, zlib.decompress(compressed)


class FramebufferConverterTests(unittest.TestCase):
    def test_little_endian_actual_rectangle_has_exact_rgb_pixels(self):
        data = frame()
        offset = 100 + 20 * 5120 + 10 * 4
        data[offset:offset + 8] = b'\x33\x22\x11\x00\xcc\xbb\xaa\x00'
        dimensions, raw = pixels(capture._png(data, (10, 20, 2, 1)))
        self.assertEqual(dimensions, (2, 1, 8, 2, 0, 0, 0))
        self.assertEqual(raw, b'\x00\x11\x22\x33\xaa\xbb\xcc')

    def test_big_endian_actual_rectangle_has_exact_rgb_pixels(self):
        data = frame(1)
        offset = 100 + 7 * 5120 + 9 * 4
        data[offset:offset + 4] = b'\x00\x12\x34\x56'
        dimensions, raw = pixels(capture._png(data, (9, 7, 1, 1)))
        self.assertEqual(dimensions, (1, 1, 8, 2, 0, 0, 0))
        self.assertEqual(raw, b'\x00\x12\x34\x56')

    def test_unsupported_format_and_inconsistent_length_fail_closed(self):
        data = frame()
        for index, value in ((1, 6), (2, 1), (3, 16), (4, 640), (7, 2), (11, 24),
                             (12, 5124), (13, 3), (14, 0xff), (19, 4097)):
            with self.subTest(field=index):
                changed = bytearray(data)
                changed[index * 4:index * 4 + 4] = struct.pack('!I', value)
                with self.assertRaises(RuntimeError):
                    capture._png(changed, (0, 0, 1, 1))
        for changed in (data[:-1], data + b'\x00'):
            with self.assertRaises(RuntimeError):
                capture._png(changed, (0, 0, 1, 1))

    def test_outside_empty_and_noninteger_rectangles_fail_closed(self):
        data = frame()
        for bounds in ((-1, 0, 1, 1), (0, -1, 1, 1), (0, 0, 0, 1), (0, 0, 1, 0),
                       (1279, 0, 2, 1), (0, 899, 1, 2), (0, 0, 1.0, 1), (False, 0, 1, 1)):
            with self.subTest(bounds=bounds), self.assertRaises(RuntimeError):
                capture._png(data, bounds)
