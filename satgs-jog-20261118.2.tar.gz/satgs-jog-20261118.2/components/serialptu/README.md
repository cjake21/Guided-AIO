# Python library for MOOG Pan & Tilt Unit

This repository provides a python interface for controlling a MOOG pan and tilt unit. 
It includes a GUI that can be used to interface and control the unit.

# Supported Protocols & Hardware

- QPT130 (non-High Resolution model) with protocol PTCR20 and baud rate 9600
- QPT200, QPT500 with protocol PTCR96 and baud rate 57600

Other baud rates may work, but this worked for us.

TODO: List of commands implemented for each, list of command TODOs

# Installation
This is installed automatically as part of the MSEL ground station software suite.  
It can also be installed standalone if low-level, direct control over the PTU is desired or for testing.

## Standalone Setup
1. Clone and install this package

```
git clone ssh://git@git.codev.mitre.org/satgs/serialptu.git
cd serialptu
python3 -m venv .env
source .env/bin/activate
 
python3 -m pip install --upgrade pip
python3 pip install -e .
```
2. Connect to the PTU, typically via USB-to-serial. Consult MSEL personnel for power+data cabling guidelines.

3. If you plan on using the GUI, you may need to install `tkinter` via apt:

```
sudo apt update
sudo apt install python3-tk
```

# Usage

A keepalive mechanism is built in, ensuring the connection remains alive until the calling process closes the serial connection or the process terminates.

## PTU GUI

Once installed, a quick way to test connectivity is to use the GUI provided in the top level of this project.

```
# Ensure your virtual env from Step 1 is activated

cd serialptu
python3 ptu_gui.py
```

NOTE: It will fail to start if no USB devices are plugged into the host.  

Connect to the PTU by specifying the port and baud rate via the top-left panel.  

TODO: Attach screenshots of the GUI, quick walkthrough  

## Via Python

Check out the [ptu_test.py](https://git.codev.mitre.org/projects/SATGS/repos/serialptu/browse/ptu_test.py) file for example usage.

Generally, you will set the baud rate and specify the serial port when you create the PTU object.  
Commands can then be issued by accessing the PTU object methods.  

The methods available for use depend on the protocol and PTU model.  
Contact MSEL personnel and/or refer to the manufacturer documentation for a full list of commands supported by your model.


## Prepared pointing (additive strict mode)

Standalone construction and legacy command bytes are unchanged. A trusted manager
may instead construct `PTU(protocol, port, ..., pointing=True)`. This path is inert:
it neither opens the port nor starts KeepAlive. Legacy methods, including raw
send, jog, reset, status-listener activation and ordinary `open()`, are disabled
before any encoder mutation. Strict mode is not a replacement qualification of
the native keepalive or the physical target.

A strict manager factory first checks the read-only `pointing_available`
observation. It is true only for a fresh supported strict instance, and does not
reserve or bind it. The caller must transfer that fresh driver exclusively to
one factory. Successful factory return transfers cleanup ownership; rejected
admission must not close a driver already owned elsewhere. Two concurrent
factories sharing one caller-owned driver violate this ownership precondition.

The strict sequence is:

1. Read the immutable `pointing_context` tuple
   `(protocol_name, units_per_degree, ptu_id)` and compare it with trusted policy.
   Supported contexts are PTCR20/10/None and PTCR96/100/0.
2. Call `bind_pointing(binding, deadline=D, cancel=E)` once with an exact
   32-byte binding digest. Retain the returned opaque handle. The digest identifies
   trusted manager policy; it is not authentication or permission to weaken policy.
3. Call `open_bounded(deadline=D, cancel=E)`. Port-open is not position/readiness
   evidence. Obtain an explicit `get_status_bounded(handle, deadline=D, cancel=E)`
   observation before relying on coordinates. Its real status encoder is accepted
   only when the remembered jog state is zero and the complete command is
   nonmoving.
4. Call `prepare_move_to(handle, pan, tilt, deadline=D, cancel=E)`. This invokes
   the actual encoder once. The immutable record exposes `packet`, `pan_units`,
   `tilt_units`, `units_per_degree` and `generation`. Counts are decoded from
   the final checksummed, escaped packet, not independently rounded.
5. Within `with driver.pointing_guard(handle, deadline=D, cancel=E):`, the
   manager checks that exact endpoint against its frozen world-frame policy and
   calls `submit_prepared_move(handle, record, deadline=D, cancel=E)`.
   The driver requires the same controls and writes the identical bytes once.
   It does not implement calibration, no-go geometry or trajectory clearance.

Both status and move return `(True, parsed_response)`, using the original
protocol parser. A matching command response is an observation, not proof of
physical arrival. The legacy protocol has no request identity, so it cannot
prove that an otherwise matching acknowledgement is fresh.

All strict waits use the supplied absolute monotonic deadline and exact
`threading.Event`. Do not clear that Event while the invocation is active.
No new worker, retry, resend or timeout budget is created. The protocol object,
encoding settings and serial port/line settings are retained and seal-checked;
nonblocking reads are required. Changed context or explicit
`invalidate_pointing(handle, deadline=D, cancel=E)` terminally invalidates
prepared work on this instance. A shutdown request can be latched before the
lock is available, but only successful locked invalidation advances generation
and authorizes a context change. A guarded submission already past its final
check can finish its native write before that invalidation completes. Timeout
or cancellation while waiting is not completed invalidation. The manager must
complete invalidation before changing its own calibration or policy. Changing
and restoring private protocol/native attributes outside this supported
protocol is not a tracked configuration history. Opaque handles/records prevent accidental
cross-owner use; they are not isolation from hostile Python code in-process.

`PointingError` in `serialptu.ptu` provides a fixed `primary` and a
`submission` disposition: `none`, `partial`, `complete` or `unknown`,
plus `written` when an exact byte count was observed. A complete write followed
by cancellation, timeout or a bad response is not success. Such exchange
failures invalidate further strict writes without compensating motion.

Strict `close(deadline=D)` first gates future work and passively closes the
owned serial interface. It never resets, parks, stops or joins a worker.
An already-expired deadline can still permit immediate passive release, but
reports `close-deadline`, not timely success. Lock/native-close failures retain
release debt, and a later close may finish it. Native open/write/read/close
behavior, heartbeat requirements and actual hardware remain separately
unqualified: software pre/post checks do not make a native call preemptible.

The additive bench primitives `observe_bounded(handle, deadline=D, cancel=E)`
and `stop_bounded(handle, deadline=D, cancel=E)` retain the same sealed owner.
They permit checked nonmoving observation or a separately validated zero-JOG
stop packet after an uncertain exchange, but never restore movement admission.
Changed context or closing ownership still rejects. The stop packet sets only
bit `0x02`, with zero velocities and no override/reset bits. This encoding is
not unit-specific proof of physical stopping. The PTU manager keeps operational
motion disabled until that contract is established.

Bench observation refuses known buffered replies. Stop still submits its one
packet when old replies are buffered, but reports the response as uncertain
instead of consuming an old reply as confirmation. Raw three-byte status fields
are retained without inventing destination-versus-measured bit semantics.
Late replies remain indistinguishable on this wire protocol, so these primitives
do not establish physical arrival or fresh measured position by themselves.

## Selected bench acquisition

The shared bench owner can supply frozen `SerialSettings` and
`SerialDeviceIdentity` from `serialptu.acquisition` to
`PTU(..., pointing=True, serial_settings=settings, device_identity=identity,
serial_capability="readback")`. All framing, flow and RTS/DTR values are explicit.
Construction stages them on a closed native interface. The allocated QPT130
candidate uses the source-derived 9600/8N1, disabled flow control, asserted RTS
and asserted DTR settings. Those are not measured cable or electrical facts.

`bind_readback(binding, deadline=D, cancel=E)` returns an observation-only handle.
It cannot prepare or submit movement, Stop, jog or reset. A separately admitted
manual owner selects `serial_capability="manual"` and calls `bind_manual` instead.
That handle uses the existing prepared-move guard, final packet and zero-JOG Stop
operations. Neither explicit bench capability accepts `bind_pointing`; the
ordinary tracking owner cannot reuse a bench driver. Existing strict construction
without the explicit acquisition profile retains its pointing contract.

`readback_context` exposes the frozen protocol, settings and identity for either
bench capability, and `serial_capability` identifies the admitted binding kind.
Opening checks the selected by-id path and its USB identity without enumerating
ports, pins the native open to the verified canonical device, and checks the
opened descriptor and selected identity again. A mismatch fails without a
fallback port or command. Failed acquisition can retain an opened interface for
the owner's passive `close(deadline=D)` cleanup.

Maintained PTU construction requests pyserial's advisory exclusive lock, so
cooperating GUI, CLI, manager and tracking owners refuse another maintained
writer. Selected bench opening also applies Linux `TIOCEXCL` to prevent later
opens. Neither mechanism establishes absence of an already-open noncooperating
reader, and neither removes or stops one. The operator must establish exclusive
physical control before connecting. Native open/close, RTS/DTR transitions and
the operating system's hangup behavior remain physically unqualified; passive
release is not a physical Stop.

`last_exchange` is an immutable `ExchangeReceipt` or `None`. Each strict exchange
attempt records a nonrepeating uint64 sequence, operation, exact request, up to
64 response bytes, response truncation, monotonic start/end, fixed error category,
submission disposition and an observed write count when available. It also
retains malformed or partial replies on failure. Callers compare sequences before
and after an operation so an earlier receipt is never relabeled as a new result.
The owner saves receipts after each operation, including Move, Stop and follow-up
status; the driver does not start a recorder or create files. Receipt timing is
software timing, not physical sampling freshness or synchronized UTC evidence.
