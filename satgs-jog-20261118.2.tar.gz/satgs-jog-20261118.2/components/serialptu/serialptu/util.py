###############################################################################
# Description:  Utilities for the quickset module
# Developer(s): Collin Hockey <chockey@mitre.org>
#
# Date:         Created 2014/8/22
###############################################################################
# NOTICE
#
# This software was produced for the U.S. Government
# under Contract No. W15P7T-13-C-A802, and is
# subject to the Rights in Noncommercial Computer Software
# and Noncommercial Computer Software Documentation Clause
# (DFARS) 252.227-7014 (JUN 1995)
#
# (C) 2014 The MITRE Corporation
###############################################################################

import threading
import time

POINTING_OFFSETS = [(0, 0)]

GPS2UNIX_OFFSET = 315964800 # unixtime = gps time + offset
LEAP_SECONDS = 18


def gpst_to_utc(gpst_week, gpst_tow):
    """
    Converts GPS week and Time of Week into UTC
    """
    return GPS2UNIX_OFFSET + gpst_week * 604800 + gpst_tow - LEAP_SECONDS


def azel_to_pantilt(az, el):
    """
    Convert azimuth, elevation to PTU coordinates
    """
    pan = az
    tilt = 90 - el

    return [pan, tilt]

def pantilt_to_azel(pan, tilt):
    """
    convert PTU coordinates to azimuth, elevation
    """
    az = pan
    el = 90 - tilt
    return (az, el)

class BufferedSerial(object):
    def __init__(self, ser, eop=b'\n', max_readsize=1024, *, open_on_init=True):
        self._ser = ser
        self._eop = eop
        self._readsize = max_readsize
        self._buffer = b""

        if open_on_init:
            self._ser.open()

    def set_eop(self, eop):
        """
        Set the byte or sequence of bytes that marks the end of a packet
        """
        self._eop = eop

    def read_packet(self, timeout = None):
        """Read a packet (ending with eop) with a timeout

        Returns the whole packet, including the eop byte.

        Returns None if an ending character is not found before the timeout.
        """
        end_idx = self._buffer.find(self._eop)
        if end_idx > 0:
            return self._slice_packet(self, end_idx)

        start = time.time()
        while not timeout or time.time() < start + timeout:
            self._buffer += self._ser.read(self._readsize)
            end_idx = self._buffer.find(self._eop)
            if end_idx > 0:
                return self._slice_packet(end_idx)

        return None

    def read(self):
        """
        Read as much data is immediately available
        """
        self._buffer += self._ser.read(self._readsize).decode()
        data = self._buffer
        self._buffer = ""
        return data

    def write(self, data):
        """
        Write data to the serial port. This is blocking.
        """
        if isinstance(data,str):
            data = bytes(data, 'utf-8')
        self._ser.write(data)

    def write_bytes_exact(self, data):
        if type(data) is not bytes:
            raise TypeError("strict-bytes")
        return self._ser.write(data)

    def _slice_packet(self, end_idx):
        data = self._buffer[:end_idx+1]
        self._buffer = self._buffer[end_idx+1:]
        return data

    def open(self):
        """
        Open the serial port for reading/writing
        """
        if not self._ser.isOpen():
            self._ser.open()

    def close(self):
        """
        Close the serial port.
        """
        if self._ser.isOpen():
            self._ser.close()

    def isOpen(self):
        """
        Check to see if the serial port is open
        """
        return self._ser.isOpen()


class Signal(object):
    """
    A simple class for handling events
    """
    def __init__(self):
        self._handlers = []
        self._lock = threading.Lock()

    def connect(self, handler):
        """
        Connect a handler. It should be callable with the number of arguments
        you intend to use for the fire function
        """
        with self._lock:
            if handler not in self._handlers:
                self._handlers.append(handler)

    def disconnect(self, handler):
        """
        Disconnect a previously attached handler
        """
        with self._lock:
            if handler in self._handlers:
                self._handlers.remove(handler)

    def fire(self, *args, **kwargs):
        """
        Fire an event, args will be forwarded to all handlers
        """
        with self._lock:
            for handler in self._handlers:
                handler(*args, **kwargs)

