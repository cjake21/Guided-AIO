class PtuError(Exception):
    """Base class for PTU Control Errors"""
    pass

class TimeoutError(PtuError):
    """Raised when waiting for a response from the PTU times out

    Attributes:
        message -- message that was waiting on a response
    """
    def __init__(self, message):
        self.message = message

class CorruptedMessageError(PtuError):
    """Raised when a message is received, but there is some problem reading it.
    Attributes:
        reason -- Reason the message was rejected
    """
    def __init__(self, reason):
        self.reason = reason

class ConnectionFailedError(PtuError):
    """Raised when connecting to the PTU fails"""
    pass


class NotConnectedError(PtuError):
    """Raised when the PTU is commanded to do something, but is not connected"""
    pass
