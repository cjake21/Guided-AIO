"""Explicit acquisition inputs for a selected Linux serial adapter."""

from dataclasses import dataclass
import os
from pathlib import Path
import re
import stat
from typing import Optional


class AcquisitionError(RuntimeError):
    pass


@dataclass(frozen=True)
class SerialSettings:
    port: str
    baudrate: int
    bytesize: int
    parity: str
    stopbits: float
    xonxoff: bool
    rtscts: bool
    dsrdtr: bool
    rts: bool
    dtr: bool

    def __post_init__(self):
        if (type(self.port) is not str or not self.port.isascii()
                or not self.port.isprintable() or len(self.port) > 256
                or Path(self.port).parent != Path('/dev/serial/by-id')
                or Path(self.port).name in ('', '.', '..')
                or type(self.baudrate) is not int or not 0 < self.baudrate <= 1000000
                or type(self.bytesize) is not int or self.bytesize not in (5, 6, 7, 8)
                or type(self.parity) is not str or self.parity not in ('N', 'E', 'O', 'M', 'S')
                or type(self.stopbits) not in (int, float) or self.stopbits not in (1, 1.5, 2)
                or any(type(value) is not bool for value in
                       (self.xonxoff, self.rtscts, self.dsrdtr, self.rts, self.dtr))):
            raise AcquisitionError('serial-settings')

    def apply(self, native):
        if native.isOpen():
            raise AcquisitionError('serial-open')
        for name in ('port', 'baudrate', 'bytesize', 'parity', 'stopbits',
                     'xonxoff', 'rtscts', 'dsrdtr', 'rts', 'dtr'):
            setattr(native, name, getattr(self, name))
        native.timeout = 0
        native.inter_byte_timeout = None
        native.rs485_mode = None
        native.exclusive = True


@dataclass(frozen=True)
class SerialDeviceIdentity:
    vendor_id: str
    product_id: str
    serial_number: str
    interface_number: str
    driver: str

    def __post_init__(self):
        for name, pattern in (('vendor_id', r'[0-9a-f]{4}'),
                              ('product_id', r'[0-9a-f]{4}'),
                              ('interface_number', r'[0-9a-f]{2}'),
                              ('serial_number', r'[A-Za-z0-9_.-]{1,128}'),
                              ('driver', r'[A-Za-z0-9_-]{1,64}')):
            value = getattr(self, name)
            if type(value) is not str or re.fullmatch(pattern, value) is None:
                raise AcquisitionError('device-identity')


@dataclass(frozen=True)
class ReadbackContext:
    protocol: str
    units_per_degree: int
    protocol_address: Optional[int]
    serial_settings: SerialSettings
    device_identity: SerialDeviceIdentity


@dataclass(frozen=True)
class _DeviceSnapshot:
    target: str
    device: int
    inode: int
    character_device: int


def _attribute(path):
    with path.open('rb') as stream:
        value = stream.read(129)
    if len(value) > 128:
        raise AcquisitionError('device-identity')
    return value.decode('ascii').strip()


def verify_selected_device(settings, identity):
    if type(settings) is not SerialSettings or type(identity) is not SerialDeviceIdentity:
        raise AcquisitionError('device-identity')
    try:
        selected = Path(settings.port)
        target = selected.resolve(strict=True)
        if target.parent != Path('/dev') or not target.name.startswith('ttyUSB'):
            raise AcquisitionError('device-identity')
        current = target.stat()
        if not stat.S_ISCHR(current.st_mode):
            raise AcquisitionError('device-identity')
        node = (Path('/sys/dev/char') / '{}:{}'.format(
            os.major(current.st_rdev), os.minor(current.st_rdev)) / 'device').resolve(strict=True)
        usb = interface = None
        for unused in range(12):
            if Path('/sys') not in node.parents:
                raise AcquisitionError('device-identity')
            if (node / 'bInterfaceNumber').is_file():
                interface = (_attribute(node / 'bInterfaceNumber'),
                             (node / 'driver').resolve(strict=True).name)
            if (node / 'idVendor').is_file():
                usb = tuple(_attribute(node / name) for name in ('idVendor', 'idProduct', 'serial'))
            if usb is not None and interface is not None:
                break
            node = node.parent
        if usb is None or interface is None or SerialDeviceIdentity(*usb, *interface) != identity:
            raise AcquisitionError('device-identity')
        if selected.resolve(strict=True) != target or target.stat() != current:
            raise AcquisitionError('device-identity')
        return _DeviceSnapshot(str(target), current.st_dev, current.st_ino, current.st_rdev)
    except AcquisitionError:
        raise
    except (OSError, ValueError, RuntimeError, UnicodeError):
        raise AcquisitionError('device-identity') from None


def claim_selected_device(native, settings, identity, snapshot):
    try:
        import fcntl
        import termios

        current = os.fstat(native.fileno())
        if (not stat.S_ISCHR(current.st_mode)
                or (current.st_dev, current.st_ino, current.st_rdev)
                != (snapshot.device, snapshot.inode, snapshot.character_device)):
            raise AcquisitionError('device-identity')
        fcntl.ioctl(native.fileno(), termios.TIOCEXCL)
        if verify_selected_device(settings, identity) != snapshot:
            raise AcquisitionError('device-identity')
    except AcquisitionError:
        raise
    except (OSError, ValueError, AttributeError, ImportError):
        raise AcquisitionError('device-ownership') from None
