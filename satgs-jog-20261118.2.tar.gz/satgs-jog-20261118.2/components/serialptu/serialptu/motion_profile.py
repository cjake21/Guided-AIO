################################################################################
# Description: PTU Motion profiles and interfaces
#
# Developer(s): Collin Hockey <chockey@mitre.org>
#               Monica Kolb <mkolb@mitre.org>
#
################################################################################
# NOTICE
#
# This software was produced for the U.S. Government
# under Contract No. W15P7T-13-C-A802, and is
# subject to the Rights in Noncommercial Computer Software
# and Noncommercial Computer Software Documentation Clause
# (DFARS) 252.227-7014 (JUN 1995)
#
# (C) 2014 The MITRE Corporation
###############################################################################

import collections
import functools
from serialptu import util
import time
import threading
# --------------------------------------
# MIN EDITS
# --------------------------------------
import numpy as np
from scipy.interpolate import interp1d
# --------------------------------------
# /MIN EDITS
# --------------------------------------


class MotionProfile(object):
    """
    Base class and interface documentation for all motion profiles. Implementing
    classes should override any methods they provide.
    """
    @classmethod
    def get_profiles(cls):
        return { type.__name__ : type for type in MotionProfile.__subclasses__() }

    @classmethod
    def get_profile_list(cls):
        return list(cls.get_profiles().keys())

    @classmethod
    def create(cls, profile, *args, **kwargs):
        profiles = cls.get_profiles()
        if not profile in profiles:
            raise ValueError("Invalid motion profile selected: {}".format(profile))

        return profiles[profile](*args, **kwargs)

    ProfileOps = collections.namedtuple('ProfileOps', ['get_position', 'set_speed', 'move_to'])

    def __init__(self):
        self._callback = None
        self._stop = threading.Event()
        self._lock = threading.Lock()

        self._Kp_pan = 0.3
        self._Kp_tilt = 0.1
        self._Ki = 0
        self._Kd = 0

    def convert_parameters(self, params):
        """Convert parameters to the correct types

        Converts based on the information returned by get_parameters. Raises
        ValueError if something cannot be converted properly

        params: A dictionary of the parameters
        """
        converted = {}
        for name, type, default in self.get_parameters():
            if name not in params:
                if type == 'float' or type == 'string':
                    converted[name] = default
                elif type == 'enum':
                    converted[name] = default[0]

            if type == 'float':
                converted[name] = float(params[name])
            elif type == 'string':
                converted[name] = str(params[name])
            elif type == 'enum':
                if params[name] in default:
                    converted[name] = params[name]
                else:
                    raise ValueError("Invalid selection for {}: {}".format(name, params[name]))

        return converted

    def register_data_callback(self, callback_func):
        self._callback = callback_func

    def new_error_data(self, data):
        if self._callback:
            self._callback(data)


    def get_parameters(self):
        """Return the list of parameters required

        Returns the parameter names needed to execute this motion profile. It
        should be a list of tuples, the first element of each being the name
        of the parameter, the second being a string of the type the argument
        should be, and the third being a reasonable default or list of
        possibilities.

        Types:

        ------------------------------------
        | Type   | Third tuple value       |
        -----------------------------------|
        | float  | Default value           |
        -----------------------------------|
        | string | Default value           |
        -----------------------------------|
        | enum   | List of possible values |
        ------------------------------------
        """
        return []

    @property
    def Kp(self):
        with self._lock:
            return self._Kp

    @property
    def Ki(self):
        with self._lock:
            return self._Ki

    @property
    def Kd(self):
        with self._lock:
            return self._Kd

    def set_pid_params(self, Kp_p, Kp_t, Ki, Kd):
        with self._lock:
            self._Kp_pan = Kp_p
            self._Kp_tilt = Kp_t
            self._Ki = Ki
            self._Kd = Kd

    def execute(self, ptu, **options):
        """Execute the motion profile.

        ptu: The PTU to execute the profile on
        kwargs: List of parameters. These should match those returned by
                get_parameters"""
        self._stop.clear()

        options = self.convert_parameters(options)

        thread = threading.Thread(
            target=functools.partial(self._do_execute, ptu, **options)
        )

        thread.start()

    """
    -------------------------------
    TODO
    -------------------------------
        - how to adjust PID for two equations (az_pos and el_pos) -- I edited so that _calc_expected returns 2 functions 
    """
    def _do_execute(self, ptu, **options):
        # print("starting _do_execute")
        try:
            i = 0
            ops = self._get_profile_ops(ptu, **options)

            # set starting point (0 = beginning of point file)
            start_point = 0
            tt = start_point + self.points['time'][0]

            pan, tilt = self._calc_expected(**options) # these are functions, take unix time in sec as input
            pan_start = float(pan(tt))
            tilt_start = float(tilt(tt))
            self._move_to(ptu, pan_start, tilt_start, ops) # move to first track location

            total_err_pan = 0
            total_err_tilt = 0
            last_err_pan = 0
            last_err_tilt = 0

            # FOR ARBITRARY START TIME
            #start_time = time.time()
            # / FOR ARBITRARY START TIME

            while not self._stop.isSet():
                with self._lock:
                    Kp_pan = self._Kp_pan
                    Kp_tilt = self._Kp_tilt
                    Ki = self._Ki
                    Kd = self._Kd

                status = ptu.get_status()

                #FOR ARBITRARY START TIME
                # tt = time.time() - start_time + start_point
                # t = tt + self.points['time'][0]
                # print("at time t={}: ".format(t))
                #/ FOR ARBITRARY START TIME

                t = time.time() # comment out if ARBITRARY START TIME
                pos = ops.get_position(status)
                current_pan, current_tilt = pos[0], pos[1]
                # current_az, current_el = util.pantilt_to_azel(current_pan, current_tilt)
                #print("actual position: (pan, tilt)=({}, {}) --> (az, el)=({}, {})".format(current_pan, current_tilt, current_az, current_el))

                # get expected position as pan, tilt
                exp_pos_pan = round(float(pan(t)),2)
                exp_pos_tilt = round(float(tilt(t)),2)

                # true slope
                epsilon = 0.001
                pan_slope_true = -1
                tilt_slope_true = -1

                # get true slope of expected path
                if t - epsilon > self.points['time'][0]: # to avoid indexing error
                    if float(pan(t + epsilon) - pan(t - epsilon)) >= 0:
                        pan_slope_true = 1
                        # if round((time.time() - start_time)) % 2 == 0:
                        #     print("true pan slope: +")
                    #else:
                        # print("true pan slope: -")
                    if float(tilt(t + epsilon) - tilt(t - epsilon)) >= 0:
                        tilt_slope_true = 1
                        # if round((time.time() - start_time)) % 2 == 0:
                        #     print("true pan slope: -")
                    #else:
                        # print("true tilt slope: -")

                # calculate positional error for pan and tilt
                pos_err_pan        = exp_pos_pan - current_pan
                #if round((time.time() - start_time)) % 10 == 0:
                print("pan: expected[{}] - actual[{}] = {}".format(round(exp_pos_pan,4), current_pan, round(pos_err_pan,4)))
                pos_err_tilt        = exp_pos_tilt - current_tilt
                #if round((time.time() - start_time)) % 10 == 0:
                print("tilt: expected[{}] - actual[{}] = {}\n".format(round(exp_pos_tilt,4), current_tilt, round(pos_err_tilt,4)))

                if i % 20 == 0:
                    with open('output_1.txt', 'a+') as fp:
                        fp.write('{}, {}, {}\n'.format(time.time(), current_pan, current_tilt))
                i += 1

                # prohibit back and forth motion during overshoots
                if np.sign(pan_slope_true) != np.sign(pos_err_pan):
                    pos_err_pan = 0
                    # print("pan overshoot, speed set to 0")
                if np.sign(tilt_slope_true) != np.sign(pos_err_tilt):
                    pos_err_tilt = 0
                    # print("tilt overshoot, speed set to 0")

                # ramp up kp if positional error is getting too high
                if abs(pos_err_pan) > 0.12:
                    Kp_pan = 0.7
                if abs(pos_err_tilt) > 0.1:
                    Kp_tilt = 0.5

                # if abs(pos_err_pan) <= 0.01:
                #     pos_err_pan = 0
                #     #print("pan positional error negligible, set to 0.")
                # if abs(pos_err_tilt) <= 0.01:
                #     pos_err_tilt = 0
                #     #print("tilt positional error negligible, set to 0.")

                # add to total error
                total_err_pan     += pos_err_pan
                total_err_tilt    += pos_err_tilt

                # change in error -- not currently in use (kd = 0)
                delta_pos_err_pan  = last_err_pan - pos_err_pan
                delta_pos_err_tilt = last_err_tilt - pos_err_tilt

                #PID
                speed_pan = (Kp_pan * abs(pos_err_pan) + Ki*total_err_pan + Kd*delta_pos_err_pan)*pan_slope_true
                speed_tilt = (Kp_tilt * abs(pos_err_tilt) + Ki*total_err_tilt + Kd*delta_pos_err_tilt)*tilt_slope_true
                # if round((time.time() - start_time)) % 2 == 0:
                #     print("pan speed: {}, tilt speed: {} \n".format(speed_pan, speed_tilt))

                last_err_pan = pos_err_pan
                last_err_tilt = pos_err_tilt

                ops.set_speed(speed_pan, speed_tilt)

                self.new_error_data({
                    'exp_pos_pan' : exp_pos_pan,
                    'exp_pos_tilt' : exp_pos_tilt,
                    'pos_err_pan' : pos_err_pan,
                    'pos_err_tilt' : pos_err_tilt,
                    'delta_pos_err_pan' : delta_pos_err_pan,
                    'delta_pos_err_tilt' : delta_pos_err_tilt,
                    'total_err_pan' : total_err_pan,
                    'total_err_tilt' : total_err_tilt
                })

                time.sleep(.01)
        finally:
            # print("running the `finally` statement")
            ptu.move_to(0,90)
            ptu.jog(0, 0)
            ptu.close()




    def stop(self):
        """Stop the currently executing motion profile"""
        self._stop.set()

    # --------------------------------------
    # MIN EDITS
    # --------------------------------------
    # changed ineqs from 0.25 to 1,
    # changed first time.sleep from 0.5 to 1

    def _move_to(self, ptu, pos_az, pos_el, ops):
        ops.move_to(pos_az, pos_el)

        status = ptu.get_status()
        while abs(ops.get_position(status)[0] - pos_az) > 0.2 or abs(ops.get_position(status)[1] - pos_el) > 0.2:
            status = ptu.get_status()
            time.sleep(0.5)

        time.sleep(2)
    # --------------------------------------
    # /MIN EDITS
    # --------------------------------------


# --------------------------------------
# MIN EDITS
# --------------------------------------

# class Sinusoid(MotionProfile):
#     TIME_DELTA = 0.1
#     MAX_PAN = 8.0
#     MAX_TILT = 4.5
#
#     def __init__(self):
#         super(Sinusoid, self).__init__()
#
#     def get_parameters(self):
#         return [
#             ("period", 'float', 25.0),
#             ("magnitude", 'float', 10.0),
#             ("axis", 'enum', ['Tilt', 'Pan'])
#         ]
#
#
#     def _get_profile_ops(self, ptu, **options):
#         if options['axis'] == 'Pan':
#             set_speed = lambda speed: ptu.jog(speed / self.MAX_PAN, 0)
#             move_to   = lambda pos: ptu.move_to(pos, 999.9)
#             get_position = lambda status: status[1]['pan']
#         else:
#             set_speed = lambda speed: ptu.jog(0, speed / self.MAX_TILT)
#             move_to = lambda pos: ptu.move_to(999.9, pos)
#             get_position = lambda status: status[1]['tilt']
#
#         return MotionProfile.ProfileOps(set_speed=set_speed, get_position=get_position, move_to=move_to)
#
#
#     def _calc_expected(self, time, **options):
#         pos = options['magnitude'] * math.cos(2 * math.pi * time / options['period'])
#         return pos

class TrackingCurve(MotionProfile):
    TIME_DELTA = 0.1
    MAX_PAN = 8.0
    MAX_TILT = 4.5

    def __init__(self, points):
        super(TrackingCurve, self).__init__()
        self.points = points

    """
    -------------------------------
    TODO
    -------------------------------
        - how to fill in ptu.jog() --> how set_speed gets filled out
        - how does lambda status work 
        - what should get_parameters return
        - also what should MAX_PAN and MAX_TILT be to give them full range of motion (up to soft limits) 
        
    """
    def get_parameters(self):
        return []

    def _get_profile_ops(self, ptu, **options):
        set_speed = lambda speed_az, speed_el: ptu.jog(speed_az, speed_el)
        move_to = lambda az_pos, el_pos: ptu.move_to(az_pos, el_pos)
        get_position = lambda status: [status[1]['pan'], status[1]['tilt']]

        return MotionProfile.ProfileOps(set_speed=set_speed, get_position=get_position, move_to=move_to)

    def _calc_expected(self, **options):
        t = np.linspace(self.points['time'][0], self.points['time'][-1], len(self.points['time']))
        pans, tilts = util.azel_to_pantilt(self.points['az'], self.points['el'])
        pan_pos = interp1d(t, pans)
        tilt_pos = interp1d(t, tilts)
        return pan_pos, tilt_pos

    # def _calc_expected(self, tt, **options):
    #     tt = tt + self.points['time'][0] + 0.1
    #     t = np.linspace(self.points['time'][0], self.points['time'][-1], len(self.points['time']))
    #     az_pos = interp1d(t, self.points['az'])
    #     el_pos = interp1d(t, self.points['el'])
    #     # print("at time t={}".format(tt))
    #     # print("expected position az:{}, el:{}".format(az_pos(tt), el_pos(tt)))
    #     a = float(az_pos(tt))
    #     e = float(el_pos(tt))
    #
    #     epsilon = 0.001
    #     az_slope_sign = -1
    #     el_slope_sign = 1
    #
    #     if float(az_pos(tt+epsilon) - az_pos(tt-epsilon)) > 0:
    #         az_slope_sign = 1
    #     if float(el_pos(tt+epsilon) - el_pos(tt-epsilon)) < 0:
    #         el_slope_sign = -1
    #
    #     return a, e, az_slope_sign, el_slope_sign

# --------------------------------------
# /MIN EDITS
# --------------------------------------