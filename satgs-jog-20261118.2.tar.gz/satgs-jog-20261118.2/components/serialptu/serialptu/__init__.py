from serialptu.ptu import PTU
from serialptu.protocol import Protocol
from serialptu import proto_impl

import inspect

# Get the list is protocols, these are classes which inherit from
protocols = dict([member for member in inspect.getmembers(proto_impl)
                  if inspect.isclass(member[1]) and
                     member[1] != Protocol and
                     issubclass(member[1], Protocol)])

def make_ptu(protocol, port, baud=57600, logger=None, rate=0.3):
    if protocol not in protocols:
        raise ValueError("{} is not a valid protocol. Options are: {}".format(
            str(protocol), ", ".join(protocols.keys())))

    return PTU(protocols[protocol](), port, baud, logger=logger, rate=rate)

def get_protocols():
    return list(protocols.keys())
