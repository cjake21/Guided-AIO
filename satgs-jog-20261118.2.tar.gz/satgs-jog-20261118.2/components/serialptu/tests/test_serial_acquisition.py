"""Selected-adapter acquisition without opening a device."""

from dataclasses import FrozenInstanceError, replace
import io
from pathlib import Path
import stat
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from serialptu.acquisition import (AcquisitionError, SerialDeviceIdentity, SerialSettings,
                                   _DeviceSnapshot, _attribute, claim_selected_device,
                                   verify_selected_device)


def settings():
    return SerialSettings('/dev/serial/by-id/usb-recording-only', 9600, 8, 'N', 1,
                          False, False, False, True, True)


def identity():
    return SerialDeviceIdentity('067b', '23a3', 'recording-only', '00', 'pl2303')


class SerialAcquisitionTests(unittest.TestCase):
    def test_explicit_settings_and_identity_are_validated_and_immutable(self):
        for field, value in (('port', '/dev/ttyACM0'), ('port', '/dev/serial/by-id/../ttyUSB0'),
                             ('baudrate', True), ('bytesize', 9), ('parity', 'n'),
                             ('stopbits', float('nan')), ('rts', 1), ('dtr', None)):
            with self.subTest(field=field, value=value), self.assertRaises(AcquisitionError):
                replace(settings(), **{field: value})
        for field, value in (('vendor_id', '67b'), ('product_id', '23A3'),
                             ('serial_number', '../other'), ('interface_number', '0'),
                             ('driver', 'pl2303\n')):
            with self.subTest(field=field, value=value), self.assertRaises(AcquisitionError):
                replace(identity(), **{field: value})
        with self.assertRaises(FrozenInstanceError):
            settings().rts = False
        with self.assertRaises(FrozenInstanceError):
            identity().serial_number = 'other'

    def test_control_lines_are_applied_only_while_closed(self):
        native = SimpleNamespace(isOpen=lambda: False)
        selected = settings()
        selected.apply(native)
        for field in selected.__dataclass_fields__:
            self.assertEqual(getattr(native, field), getattr(selected, field))
        self.assertEqual(native.timeout, 0)
        self.assertIsNone(native.inter_byte_timeout)
        self.assertIsNone(native.rs485_mode)
        self.assertIs(native.exclusive, True)
        native.isOpen = lambda: True
        with self.assertRaises(AcquisitionError):
            replace(selected, rts=False).apply(native)
        self.assertIs(native.rts, True)

    def fixture(self, *, serial_number='recording-only', target='/dev/ttyUSB0', mode=stat.S_IFCHR):
        selected = settings()
        leaf = Path('/sys/devices/usb1/1-1/1-1:1.0/ttyUSB0')
        interface = leaf.parent
        usb = interface.parent
        attributes = {interface / 'bInterfaceNumber': '00', usb / 'idVendor': '067b',
                      usb / 'idProduct': '23a3', usb / 'serial': serial_number}
        resolutions = {Path(selected.port): Path(target),
                       Path('/sys/dev/char/188:0/device'): leaf,
                       interface / 'driver': Path('/sys/bus/usb/drivers/pl2303')}
        native_stat = SimpleNamespace(st_mode=mode, st_dev=7, st_ino=13, st_rdev=188 * 256)

        def resolve(path, strict=False):
            self.assertIs(strict, True)
            self.assertIn(path, resolutions)
            return resolutions[path]

        def native_status(path):
            self.assertEqual(path, Path(target))
            return native_stat

        contexts = (patch.object(Path, 'resolve', resolve), patch.object(Path, 'stat', native_status),
                    patch.object(Path, 'is_file', lambda path: path in attributes),
                    patch('serialptu.acquisition._attribute', side_effect=lambda path: attributes[path]))
        for context in contexts:
            context.start()
            self.addCleanup(context.stop)
        return selected, native_stat, resolutions

    def test_only_selected_path_and_its_usb_ancestry_are_examined(self):
        selected, native_stat, resolutions = self.fixture()
        actual = verify_selected_device(selected, identity())
        self.assertEqual(actual, _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256))

    def test_identity_mismatch_does_not_select_a_different_port(self):
        selected, native_stat, resolutions = self.fixture(serial_number='another-unit')
        with self.assertRaisesRegex(AcquisitionError, '^device-identity$'):
            verify_selected_device(selected, identity())

    def test_acm_target_is_rejected_before_usb_reads(self):
        selected, native_stat, resolutions = self.fixture(target='/dev/ttyACM0')
        with self.assertRaisesRegex(AcquisitionError, '^device-identity$'):
            verify_selected_device(selected, identity())

    def test_regular_file_target_is_rejected(self):
        selected, native_stat, resolutions = self.fixture(mode=stat.S_IFREG)
        with self.assertRaisesRegex(AcquisitionError, '^device-identity$'):
            verify_selected_device(selected, identity())

    def test_selected_symlink_change_during_verification_is_rejected(self):
        selected, native_stat, resolutions = self.fixture()
        original_attribute = lambda path: {
            'bInterfaceNumber': '00', 'idVendor': '067b', 'idProduct': '23a3',
            'serial': 'recording-only'}[path.name]

        def changed_attribute(path):
            resolutions[Path(selected.port)] = Path('/dev/ttyUSB1')
            return original_attribute(path)

        with patch('serialptu.acquisition._attribute', side_effect=changed_attribute):
            with self.assertRaisesRegex(AcquisitionError, '^device-identity$'):
                verify_selected_device(selected, identity())

    def test_identity_attribute_reads_are_bounded(self):
        for value in (b'x' * 129, b'\xff'):
            with patch.object(Path, 'open', return_value=io.BytesIO(value)):
                with self.assertRaises((AcquisitionError, UnicodeError)):
                    _attribute(Path('recording-only'))
        with patch.object(Path, 'open', return_value=io.BytesIO(b'067b\n')):
            self.assertEqual(_attribute(Path('recording-only')), '067b')

    def test_claim_checks_open_descriptor_then_latches_kernel_exclusion_and_rechecks_identity(self):
        import termios

        snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
        native_stat = SimpleNamespace(st_mode=stat.S_IFCHR, st_dev=7, st_ino=13, st_rdev=188 * 256)
        native = SimpleNamespace(fileno=lambda: 91)
        with patch('serialptu.acquisition.os.fstat', return_value=native_stat) as fstat, \
                patch('fcntl.ioctl') as ioctl, \
                patch('serialptu.acquisition.verify_selected_device', return_value=snapshot) as verify:
            claim_selected_device(native, settings(), identity(), snapshot)
        fstat.assert_called_once_with(91)
        ioctl.assert_called_once_with(91, termios.TIOCEXCL)
        verify.assert_called_once_with(settings(), identity())

    def test_mismatching_open_descriptor_never_claims_a_different_device(self):
        snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
        native_stat = SimpleNamespace(st_mode=stat.S_IFCHR, st_dev=7, st_ino=99, st_rdev=188 * 256)
        with patch('serialptu.acquisition.os.fstat', return_value=native_stat), patch('fcntl.ioctl') as ioctl:
            with self.assertRaisesRegex(AcquisitionError, '^device-identity$'):
                claim_selected_device(SimpleNamespace(fileno=lambda: 91), settings(), identity(), snapshot)
        ioctl.assert_not_called()

    def test_kernel_claim_or_post_open_identity_failure_is_not_success(self):
        snapshot = _DeviceSnapshot('/dev/ttyUSB0', 7, 13, 188 * 256)
        native_stat = SimpleNamespace(st_mode=stat.S_IFCHR, st_dev=7, st_ino=13, st_rdev=188 * 256)
        for claim_failure in (True, False):
            with self.subTest(claim_failure=claim_failure), \
                    patch('serialptu.acquisition.os.fstat', return_value=native_stat), \
                    patch('fcntl.ioctl', side_effect=OSError('fixture') if claim_failure else None), \
                    patch('serialptu.acquisition.verify_selected_device',
                          return_value=replace(snapshot, inode=99)):
                with self.assertRaises(AcquisitionError):
                    claim_selected_device(SimpleNamespace(fileno=lambda: 91), settings(), identity(), snapshot)
