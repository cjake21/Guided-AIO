"""Read-once inputs for the explicitly selected direct-pointing operation."""

from __future__ import annotations

import csv
from dataclasses import dataclass, field, replace
from datetime import datetime
import hashlib
import io
import ipaddress
import json
import math
from pathlib import Path
import re
from types import MappingProxyType
from typing import Any, Mapping

from satgs.deployment import load_manifest
from satgs.deployment_cli import CliInputError, read_json_document, read_regular_bytes
from satgs.deployment_plan import (
    Configuration, InputError, build_catalog, parse_configuration,
    validate_selection_contract,
)
from satgs.station_location import (
    BOUND_LOCATION_KEY, LocationError, SOURCE_KEY, location_from_settings,
    require_runtime_location, runtime_location_from_settings,
)


class RuntimeConfigurationError(ValueError):
    """An explicit runtime request failed admission before resource acquisition."""


@dataclass(frozen=True, slots=True)
class RuntimeBinding:
    instance_id: str
    component: str
    provider: str
    manager_id: int
    paired_with: str


@dataclass(frozen=True, slots=True)
class TleRecord:
    norad_id: int
    name: str
    tle: str
    date: str

    def to_dict(self) -> dict[str, str]:
        return {"name": self.name, "tle": self.tle, "date": self.date}


@dataclass(frozen=True, slots=True)
class RuntimeContext:
    configuration: Configuration = field(repr=False)
    configuration_sha256: str
    binding_sha256: str
    station_sha256: str
    tle_sha256: str
    ptu: RuntimeBinding
    pixhawk: RuntimeBinding
    tle: TleRecord
    duration: float
    elevation: float
    station: Mapping[str, Any] = field(repr=False)
    raw_documents: tuple[bytes, ...] = field(repr=False)
    no_go_data: Mapping[str, Any] | None = field(default=None, repr=False)
    no_go_sha256: str | None = None
    operation: str = field(default="pointing", init=False)

    def station_settings(self) -> dict[str, Any]:
        """Give an owner its own selected-only copy, never mutable input paths."""
        return _thaw(self.station)


def _freeze(value):
    if type(value) is dict:
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if type(value) is list:
        return tuple(_freeze(item) for item in value)
    return value


def _thaw(value):
    if isinstance(value, Mapping):
        return {key: _thaw(item) for key, item in value.items()}
    if type(value) is tuple:
        return [_thaw(item) for item in value]
    return value


def snapshot_runtime_context(base_context, *, station_settings, station_revision,
                             request_id, duration=None, station_document=None):
    """Bind an admitted owner selection to an exact managed station snapshot."""
    if not isinstance(base_context, RuntimeContext) or not isinstance(station_settings, Mapping):
        _fail("Runtime snapshot requires admitted inputs and explicit station settings.")
    for value in (station_revision, request_id):
        if type(value) is not str or re.fullmatch(r"[0-9a-f]{64}", value) is None:
            _fail("Runtime snapshot identities must be exact SHA-256 values.")
    try:
        selected = _thaw(station_settings)
        if station_document is None:
            station_document = (json.dumps(selected, sort_keys=True, indent=2,
                ensure_ascii=True, allow_nan=False) + "\n").encode("utf-8")
        if (type(station_document) is not bytes or len(station_document) > 1024 * 1024
                or hashlib.sha256(station_document).hexdigest() != station_revision
                or _parse_station_yaml(station_document, allow_inline_ca=True) != selected):
            _fail("Runtime station document does not match the confirmed revision and settings.")
    except (TypeError, ValueError, OverflowError, RecursionError):
        _fail("Runtime station document does not match the confirmed revision and settings.")
    marker = selected.get("satgs_operator_workspace")
    metadata = selected.get("operator")
    if (type(marker) is not dict or set(marker) != {"schema_version", "id", "root"}
            or type(marker["schema_version"]) is not int or marker["schema_version"] != 1
            or type(marker["id"]) is not str or re.fullmatch(r"[0-9a-f]{32}", marker["id"]) is None
            or type(marker["root"]) is not str or not Path(marker["root"]).is_absolute()
            or type(metadata) is not dict or type(metadata.get("generation")) is not int
            or not 0 < metadata["generation"] < 2 ** 63):
        _fail("Runtime snapshot requires an explicit managed station identity and revision.")
    try:
        location = location_from_settings(selected)
    except LocationError as error:
        _fail(str(error))
    merged = base_context.station_settings()
    merged.update(ground_station_lat=location.latitude_deg,
                  ground_station_lon=location.longitude_deg,
                  ground_station_altm=location.altitude_m,
                  ground_station_location_source=location.source)
    merged["satgs_operator_workspace"] = marker
    merged["operator"] = metadata
    merged[BOUND_LOCATION_KEY] = dict(source=location.source, station_id=marker["id"],
        revision=metadata["generation"], latitude_deg=location.latitude_deg,
        longitude_deg=location.longitude_deg, altitude_m=location.altitude_m,
        altitude_reference=metadata.get("altitude_reference"), coordinate_units="degrees-metres")
    try:
        context = merged["positioners"][0]["pointing_context"]
        context["configuration_generation"] = metadata["generation"]
        context["run_id"] = request_id
        require_runtime_location(merged, bound=True)
    except (LocationError, KeyError, IndexError, TypeError):
        _fail("Runtime station location cannot bind the selected owner policy.")
    selected_duration = base_context.duration if duration is None else _finite(duration, "Pointing duration")
    if selected_duration <= 0:
        _fail("Pointing requires positive duration.")
    documents = list(base_context.raw_documents)
    if len(documents) < 4:
        _fail("Runtime snapshot lacks the admitted source documents.")
    documents[2] = station_document
    return replace(base_context, station_sha256=station_revision, duration=selected_duration,
                   station=_freeze(merged), raw_documents=tuple(documents))


def _fail(message):
    raise RuntimeConfigurationError(message)


def _finite(value, description):
    try:
        valid = type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        valid = False
    if not valid:
        _fail(f"{description} must be a finite number.")
    return float(value)


def _positive_id(value):
    if type(value) is not int or value <= 0:
        _fail("Manager and NORAD IDs must be positive nonboolean integers.")
    return value


def _fields(value, expected):
    if type(value) is not dict or set(value) != set(expected):
        _fail("Runtime binding has missing or unsupported fields.")


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            _fail("Station mappings must not contain duplicate keys.")
        result[key] = value
    return result


def _inline_ca(value):
    if (type(value) is not str or not value or len(value) > 65536
            or any(not (32 <= ord(char) <= 126 or char in "\r\n\t") for char in value)):
        _fail("Station inline CA data exceeds supported limits.")
    return value


def _station_structure(value, *, allow_inline_ca=False):
    pending = [(value, 0, False)]
    count = 0
    while pending:
        item, depth, inline_ca = pending.pop()
        count += 1
        if count > 8192 or depth > 32:
            _fail("Station input exceeds supported structure limits.")
        if type(item) is dict:
            if depth >= 32 or len(item) > 128 or any(
                type(key) is not str or len(key) > 80 for key in item
            ):
                _fail("Station mapping exceeds supported structure limits.")
            pending.extend((key, depth + 1, False) for key in item)
            pending.extend((child, depth + 1, allow_inline_ca is True and depth == 0 and key == "amq_ca_pem")
                           for key, child in item.items())
        elif type(item) is list:
            if depth >= 32 or len(item) > 1024:
                _fail("Station list exceeds supported structure limits.")
            pending.extend((child, depth + 1, False) for child in item)
        elif type(item) is str:
            if inline_ca:
                _inline_ca(item)
            elif len(item) > 4096 or not item.isprintable():
                _fail("Station text exceeds supported limits.")
        elif type(item) is float:
            if not math.isfinite(item):
                _fail("Station numbers must be finite.")
        elif item is not None and type(item) not in (int, bool):
            _fail("Station input contains unsupported values.")


def _parse_station_yaml(payload, *, allow_inline_ca=False):
    try:
        text = payload.decode("utf-8")
        if text.lstrip().startswith("{"):
            value = json.loads(text, object_pairs_hook=_unique_pairs,
                               parse_constant=lambda _: _fail("Station numbers must be finite."))
        else:
            try:
                import yaml
            except ImportError:
                _fail("PyYAML is required for non-JSON station YAML; no input was admitted.")

            class StationLoader(yaml.SafeLoader):
                nodes = 0
                depth = 0

                def compose_node(self, parent, index):
                    if self.check_event(yaml.AliasEvent):
                        _fail("Station YAML aliases are unsupported.")
                    self.nodes += 1
                    self.depth += 1
                    if self.nodes > 8192 or self.depth > 32:
                        _fail("Station YAML exceeds supported structure limits.")
                    try:
                        return super().compose_node(parent, index)
                    finally:
                        self.depth -= 1

                def construct_mapping(self, node, deep=False):
                    result = {}
                    for key_node, value_node in node.value:
                        key = self.construct_object(key_node, deep=deep)
                        if type(key) is not str or key in result:
                            _fail("Station YAML requires unique string mapping keys.")
                        result[key] = self.construct_object(value_node, deep=deep)
                    return result

            try:
                value = yaml.load(text, Loader=StationLoader)
            except yaml.YAMLError:
                _fail("Station YAML could not be decoded safely.")
        _station_structure(value, allow_inline_ca=allow_inline_ca)
        if type(value) is not dict:
            _fail("Station YAML must contain a mapping.")
        return value
    except (UnicodeError, ValueError, RecursionError) as error:
        if isinstance(error, RuntimeConfigurationError):
            raise
        _fail("Station input could not be decoded safely.")


def _bindings(document, configuration, digest):
    _fields(document, {"schema_version", "configuration_id", "configuration_revision",
                       "configuration_sha256", "target", "bindings"})
    if type(document["schema_version"]) is not int or document["schema_version"] != 1:
        _fail("Runtime binding schema_version must be 1.")
    expected = (configuration["id"], configuration["revision"], digest, configuration["target"])
    actual = tuple(document[key] for key in (
        "configuration_id", "configuration_revision", "configuration_sha256", "target"))
    if type(document["configuration_revision"]) is not int or actual != expected:
        _fail("Runtime binding does not identify the admitted configuration bytes and target.")
    rows = document["bindings"]
    if type(rows) is not list or len(rows) != 2:
        _fail("Pointing requires exactly one explicitly bound PTU/Pixhawk pair.")
    instances = {item["id"]: item for item in configuration["instances"]}
    bound = {}
    for row in rows:
        _fields(row, {"instance_id", "component", "provider", "manager_id", "paired_with"})
        if any(type(row[key]) is not str for key in (
            "instance_id", "component", "provider", "paired_with"
        )):
            _fail("Binding identities must be strings.")
        identity = row["instance_id"]
        if identity not in instances or identity in bound:
            _fail("Runtime binding names an unknown or duplicate instance.")
        instance = instances[identity]
        if (row["component"], row["provider"]) != (instance["component"], instance["provider"]):
            _fail("Runtime binding component or provider conflicts with installation intent.")
        _positive_id(row["manager_id"])
        if row["manager_id"] > 2 ** 31 - 1:
            _fail("Selected manager identifiers must fit the owner protocol.")
        bound[identity] = RuntimeBinding(**row)
    ptu = [item for item in bound.values() if item.component == "qpt130"]
    pixhawk = [item for item in bound.values() if item.component == "pixhawk_dual_gps"]
    if len(ptu) != 1 or len(pixhawk) != 1:
        _fail("Pointing requires a QPT PTU and dual-GPS Pixhawk pair.")
    ptu, pixhawk = ptu[0], pixhawk[0]
    if ptu.paired_with != pixhawk.instance_id or pixhawk.paired_with != ptu.instance_id:
        _fail("Runtime pair bindings must be reciprocal.")
    selections = {item["component"]: item for item in configuration["selections"]}
    required = {
        "ground_station", "meteor-api", "sat_tracker", "serialptu", "pixhawk",
        "broker.activemq", "time.ntp",
        "execution.pass_runner", "orbit.pass_finder", "pointing.ptu",
        "pointing.qpt130", "pointing.pixhawk", "pointing.dual_gps",
    }
    if any(identity not in selections or selections[identity]["mode"] not in ("install", "reuse")
           for identity in required):
        _fail("Pointing requires complete local software, PTU and dual-GPS installation selections.")
    for capability, identity in (
        ("pointing.ptu", ptu.instance_id), ("pointing.qpt130", ptu.instance_id),
        ("pointing.pixhawk", pixhawk.instance_id), ("pointing.dual_gps", pixhawk.instance_id),
    ):
        if identity not in selections[capability]["instance_ids"]:
            _fail("Bound pair is not selected for all required pointing capabilities.")
    return ptu, pixhawk


def _expanded_path(value, home):
    if type(value) is not str or not value:
        _fail("Station paths must be nonempty strings.")
    if value == "~" or value.startswith("~/"):
        value = home + value[1:]
    if "~" in value:
        _fail("Station paths contain unsupported home expansion.")
    return str(Path(value))


def _transport_text(value, characters, size, *, ascii_only=False, empty=False):
    if (type(value) is not str or len(value) > characters or (not empty and not value)
            or (value and not value.isprintable()) or (ascii_only and not value.isascii())):
        _fail("Station transport text exceeds supported limits.")
    try:
        encoded = value.encode("utf-8")
    except UnicodeError:
        encoded = None
    if encoded is None or len(encoded) > size:
        _fail("Station transport text exceeds supported limits.")
    return value


def _transport_settings(station):
    dial = _transport_text(station.get("amq_dial_address"), 45, 45, ascii_only=True)
    identity = _transport_text(station.get("amq_tls_server_name"), 253, 253, ascii_only=True)
    address = None
    try:
        address = ipaddress.ip_address(dial)
    except ValueError:
        pass
    if address is None or "%" in dial or str(address) != dial:
        _fail("Station dial address must be canonical numeric IP data.")
    certificate_name = None
    try:
        certificate_name = ipaddress.ip_address(identity)
    except ValueError:
        pass
    if certificate_name is not None:
        valid_identity = "%" not in identity and str(certificate_name) == identity
    else:
        valid_identity = all(0 < len(label) <= 63 and label[0] != "-" and label[-1] != "-"
                             and all(char.isalnum() or char == "-" for char in label)
                             for label in identity.split("."))
    if not valid_identity:
        _fail("Station TLS identity is invalid.")
    ca = _inline_ca(station.get("amq_ca_pem"))
    username = _transport_text(station.get("amq_username"), 1024, 4096)
    password = _transport_text(station.get("amq_password"), 1024, 4096)
    host = station.get("amq_stomp_host")
    if host is not None:
        _transport_text(host, 255, 255, ascii_only=True, empty=True)
    # Fixed accept-version, heart-beat, login and passcode header overhead.
    header_bytes = 51 + len(username.encode("utf-8")) + len(password.encode("utf-8"))
    if host is not None:
        header_bytes += 6 + len(host.encode("ascii"))
    if header_bytes > 8192:
        _fail("Station CONNECT headers exceed supported limits.")
    return {"amq_dial_address": dial, "amq_tls_server_name": identity,
            "amq_ca_pem": ca, "amq_stomp_host": host}


def _station_settings(station, ptu, pixhawk):
    if "amq_transport" in station or "bench_transport" in station:
        _fail("Bench transport selection is unsupported for operational pointing.")
    for key in ("home_directory", "logging_dir", "amq_server", "amq_username", "amq_password"):
        if type(station.get(key)) is not str or not station[key]:
            _fail("Required station paths and transport settings must be nonempty strings.")
    if (type(station.get("amq_port")) is not int or not 1 <= station["amq_port"] <= 65535
            or station.get("amq_use_ssl") is not True):
        _fail("Station transport port or TLS setting is invalid.")
    transport = _transport_settings(station)
    try:
        location = location_from_settings(station)
    except LocationError as error:
        _fail(str(error))
    selected = {}
    for key, binding, peer, association in (
        ("positioners", ptu, pixhawk, "pix_id"),
        ("pixhawk_sensors", pixhawk, ptu, "ptu_id"),
    ):
        rows = station.get(key)
        if type(rows) is not list or not rows:
            _fail("Station settings lack the required device associations.")
        by_id = {}
        for row in rows:
            if type(row) is not dict:
                _fail("Station device records must be mappings.")
            identity = _positive_id(row.get("id"))
            if identity in by_id:
                _fail("Station device manager IDs must be unique within each family.")
            by_id[identity] = row
        row = by_id.get(binding.manager_id)
        if row is None or type(row.get(association)) is not int or row[association] != peer.manager_id:
            _fail("Station device associations do not match the reciprocal runtime pair.")
        selected[key] = [dict(row)]
    if selected["positioners"][0].get("type") != "QPT-130":
        _fail("Selected station positioner type does not match QPT-130 installation intent.")
    if selected["positioners"][0].get("allow_pointing_errors", False) is not False:
        _fail("Pointing error injection is unsupported for explicit pointing.")
    keys = (
        "home_directory", "logging_dir", "amq_server", "amq_port", "amq_username",
        "amq_password", "amq_use_ssl", "ground_station_lat", "ground_station_lon",
        "ground_station_altm",
    )
    result = {key: station[key] for key in keys}
    if SOURCE_KEY in station:
        result[SOURCE_KEY] = location.source
    if BOUND_LOCATION_KEY in station:
        try:
            result[BOUND_LOCATION_KEY] = dict(runtime_location_from_settings(station))
        except LocationError as error:
            _fail(str(error))
    result.update(transport)
    result["file_prefix_source"] = station.get("file_prefix_source", "default")
    if result["file_prefix_source"] not in ("default", "job"):
        _fail("Station file prefix source is unsupported.")
    result["logging_dir"] = _expanded_path(result["logging_dir"], result["home_directory"])
    for key in ("home_directory", "logging_dir"):
        path = Path(result[key])
        if (not path.is_absolute() or path == Path("/") or ".." in path.parts
                or "~" in str(path) or path.parts[1] in ("dev", "proc", "sys")):
            _fail("Station directories must be absolute non-root paths outside device and observation roots.")
    result.update(selected)
    return result


def _read_tle(payload, sat_id):
    try:
        reader = csv.DictReader(io.StringIO(payload.decode("utf-8"), newline=""), strict=True)
        headers = reader.fieldnames
        if (headers is None or len(headers) != len(set(headers))
                or not {"norad_id", "name", "tle", "date"} <= set(headers)):
            _fail("Local TLE CSV requires unique NORAD, name, TLE and date fields.")
        matches = []
        for row in reader:
            if None in row or any(value is None for value in row.values()):
                _fail("Local TLE CSV has an invalid row shape.")
            identity = row["norad_id"]
            if re.fullmatch(r"[0-9]+", identity) is None or int(identity) <= 0:
                _fail("Local TLE CSV contains an invalid NORAD identifier.")
            if int(identity) == sat_id:
                matches.append(row)
        if len(matches) != 1:
            _fail("Selected NORAD identifier must identify exactly one local TLE row.")
        row = matches[0]
        pieces = row["tle"].split(",")
        if (len(pieces) != 3 or not row["name"] or row["name"] != pieces[0]
                or any(not item.isprintable() for item in pieces)):
            _fail("Selected TLE must contain its name and two printable element lines.")
        for number, line in enumerate(pieces[1:], 1):
            if (len(line) != 69 or not line.startswith(f"{number} ")
                    or not line[2:7].strip().isdecimal() or int(line[2:7]) != sat_id
                    or not line[-1].isdigit()):
                _fail("Selected TLE element lines have invalid NORAD or line structure.")
            checksum = sum(int(char) if char.isdigit() else 1 if char == "-" else 0
                           for char in line[:-1]) % 10
            if checksum != int(line[-1]):
                _fail("Selected TLE checksum is invalid.")
        datetime.strptime(row["date"], "%Y-%m-%d %H:%M:%S UTC")
        return TleRecord(sat_id, row["name"], row["tle"], row["date"])
    except (UnicodeError, ValueError, csv.Error, OverflowError) as error:
        if isinstance(error, RuntimeConfigurationError):
            raise
        _fail("Selected local TLE could not be decoded safely.")


def load_runtime_configuration(deployment_config, runtime_bindings, station_config, sat_file,
                               *, sat_id, duration, elevation):
    duration = _finite(duration, "Pointing duration")
    elevation = _finite(elevation, "Pointing elevation mask")
    if duration <= 0 or not 0 <= elevation < 90:
        _fail("Pointing requires positive duration and an elevation mask in [0, 90).")
    _positive_id(sat_id)
    try:
        raw_configuration, document = read_json_document(deployment_config)
        catalog = build_catalog(load_manifest())
        configuration = parse_configuration(document, catalog)
        config = configuration.to_dict()
        if config["preset"] == "full_msel":
            _fail("Explicit modular Full M-SEL is unsupported in R1; legacy invocation is separate.")
        if validate_selection_contract(configuration, catalog):
            _fail("Deployment configuration violates the shared selection contract.")
        digest = hashlib.sha256(raw_configuration).hexdigest()
        raw_bindings, bindings = read_json_document(runtime_bindings)
        ptu, pixhawk = _bindings(bindings, config, digest)
        raw_station = read_regular_bytes(station_config)
        station = _station_settings(_parse_station_yaml(raw_station, allow_inline_ca=True), ptu, pixhawk)
        no_go_data = None
        raw_no_go = None
        no_go_path = station["positioners"][0].get("no_go_config")
        if no_go_path is not None:
            raw_no_go = read_regular_bytes(_expanded_path(no_go_path, station["home_directory"]))
            no_go_data = _parse_station_yaml(raw_no_go)
            if set(no_go_data) != {"nogozones"} or type(no_go_data["nogozones"]) is not list:
                _fail("Selected no-go input has an unsupported shape.")
            if len(no_go_data["nogozones"]) != 1:
                _fail("Selected no-go input must use the owner's single-zone format.")
            zone = no_go_data["nogozones"][0]
            _fields(zone, {"az_min", "az_max", "el_min", "el_max"})
            values = {key: _finite(value, "No-go coordinate") for key, value in zone.items()}
            if values["az_min"] >= values["az_max"] or values["el_min"] >= values["el_max"]:
                _fail("Selected no-go coordinate intervals must be increasing.")
            station["positioners"][0]["no_go_config"] = None
        raw_tle = read_regular_bytes(_expanded_path(str(sat_file), station["home_directory"]))
        tle = _read_tle(raw_tle, sat_id)
        raw_documents = (raw_configuration, raw_bindings, raw_station, raw_tle)
        if raw_no_go is not None:
            raw_documents += (raw_no_go,)
        return RuntimeContext(
            configuration, digest, hashlib.sha256(raw_bindings).hexdigest(),
            hashlib.sha256(raw_station).hexdigest(), hashlib.sha256(raw_tle).hexdigest(),
            ptu, pixhawk, tle, duration, elevation, _freeze(station), raw_documents,
            _freeze(no_go_data), hashlib.sha256(raw_no_go).hexdigest() if raw_no_go else None,
        )
    except (CliInputError, InputError):
        _fail("Explicit runtime input failed safe admission or shared configuration validation.")


def resolve_runtime_request(*, operation=None, deployment_config=None, runtime_bindings=None,
                            station_config=None, sat_file=None, sat_id=None, duration=0,
                            elevation=15, conflicts=()):
    if operation is None and deployment_config is None and runtime_bindings is None:
        return None
    if operation != "pointing":
        _fail("Modular inputs require the explicit supported operation: pointing.")
    if any(value is None for value in (deployment_config, runtime_bindings, station_config, sat_file)):
        _fail("Explicit pointing requires deployment, binding, station and local TLE inputs.")
    if conflicts:
        _fail("Explicit pointing conflicts with RF, recording, calibration, errors or device omission.")
    return load_runtime_configuration(
        deployment_config, runtime_bindings, station_config, sat_file,
        sat_id=sat_id, duration=duration, elevation=elevation,
    )
