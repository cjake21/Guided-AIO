from __future__ import annotations

import logging
import argparse
import time
import signal
import yaml
from pathlib import Path
import pandas as pd
import ephem
from ephem import degree as deg2rad
from datetime import datetime, timezone, timedelta
import shutil
from copy import copy
import csv
import numbers
import numpy as np
import subprocess
import threading
import re
import sys
import math
from typing import Union, List, Tuple
from meteor_api.messenger import Messenger

from satgs.utils import find_passes, PassInfo, check_meteor_services, determine_file_prefix, determine_filename, AzElTrajectory, tle_from_dict
from satgs.constants import DEFAULTS, time_format_print, time_format_tzone
from satgs.runtime_configuration import RuntimeContext, RuntimeConfigurationError, resolve_runtime_request


_POINTING_CONTRACT = "satgs.pointing.v1"
_MESSENGER_CONTRACT = "satgs.pointing.v2"
# Populated only by a separately reviewed owner-release integration, never a CLI option.
_REVIEWED_OWNER_RELEASES = {}
_RESOURCE_WAIT_SECONDS = 3.0
_PRIME_LOOKAHEAD = timedelta(seconds=60)


def _failure_category(code, category=None):
    categories = {
        3: ("owner-prerequisite",), 4: ("acquisition",),
        5: ("execution-failure", "prime-timeout", "drop-dead"),
        6: ("logging", "owned-logging", "truth-logging"),
        7: ("cleanup",), 130: ("cancelled",),
    }.get(code, ("execution-failure",))
    return category if type(category) is str and category in categories else categories[0]


from satgs.station_location import LocationError, require_runtime_location
from satgs.operator_activity import ActivityError, acquire_runner_activity


class RuntimeFailure(Exception):
    def __init__(self, code, message, *, category=None, manager_outcome=None, manager_local_failure=None):
        super().__init__(message)
        self.code = code
        self.category = _failure_category(code, category)
        self.manager_outcome = manager_outcome
        self.manager_local_failure = manager_local_failure


def _pointing_owner_types():
    try:
        from ptu_control.ptu_client import PtuClient
        from pixhawk.pixhawk_subscriber import PixhawkSubscriber
    except ImportError:
        raise RuntimeFailure(3, "Pointing owner packages are not installed.") from None
    owners = (Messenger, PtuClient, PixhawkSubscriber)
    requirements = (
        ("meteor-api", _MESSENGER_CONTRACT,
         ("prepare_transport", "open_bounded", "close", "strict_instance_compatible")),
        ("sat_tracker", _POINTING_CONTRACT,
         ("open_pointing", "close", "check_connection", "load_tle", "prime", "validateCoordinates",
          "enable_scheduled_tracking", "track", "complete_tracking", "tracking_outcome", "tracking_failure")),
        ("pixhawk", _POINTING_CONTRACT,
         ("open_pointing", "close", "check_connection", "start_logging")),
    )
    for owner, (name, contract, methods) in zip(owners, requirements):
        revision = getattr(owner, "SOURCE_REVISION", None)
        if (getattr(owner, "CONTRACT_REVISION", None) != contract
                or not isinstance(revision, str)
                or revision not in _REVIEWED_OWNER_RELEASES.get(name, ())
                or any(not callable(getattr(owner, method, None)) for method in methods)):
            raise RuntimeFailure(3, "Pointing owner contracts and release integration are not qualified.")
    return owners

# Dont expand user here since these may get called by systemd
default_cfg = Path('~/ground_station/config/config.yaml')
default_sat_db = Path('~/ground_station/config/sat_db.csv')


class PassRunner:
    '''
    Executes a satellite pass This class is responsible for:
        - PTU Steering (via PtuClient/PtuManager classes)
        - Pixhawk logging for dish positions (via PixhawkSubscriber/PixhawkManager classes)
        - RF Front End control via DSI devices (via FrontEndClient/FrontEndManager classes)
        - Control of warning lights/ HPA (via PduClient/PduManager classes)
        - Initializing the IQ logger, if configured to do so (via SignalHoundClient/SignalHoundManager classes)
        - Initializing the trace logger (channel power logging), if configured to do so 
            (via SigHoundSweptAnalyzerClient/SigHoundSweptAnalyzerManager class)
    Ends once the satellite pass completes, control-c detected, or a we pass the satellite set time 
    of the closest pass (below 0 deg elevation)
    '''
    def __init__(self, config_file, sat_file, sat_id, *args,
                 runtime_context=None, messenger=None, cancel_event=None,
                 manage_signals=True, progress=None, selected_pass=None, **kwargs):
        self.runtime_context = runtime_context
        if cancel_event is not None and type(cancel_event) is not threading.Event:
            raise RuntimeConfigurationError("Cancellation must be a lifecycle Event.")
        if type(manage_signals) is not bool or (progress is not None and not callable(progress)):
            raise RuntimeConfigurationError("Invalid runner supervision controls.")
        if runtime_context is None and (cancel_event is not None or progress is not None or selected_pass is not None):
            raise RuntimeConfigurationError("Operator supervision requires explicit pointing.")
        self.cancel_event = threading.Event() if cancel_event is None else cancel_event
        self._manage_signals = manage_signals
        self._progress = progress
        self._progress_state = None
        self._selected_pass = selected_pass
        self.sat_pos_thread_signal = threading.Event()
        self._resources = []
        self.cleanup_errors = []
        self._worker_error = None
        self._logging_failed = threading.Event()
        self.primary_failure = None
        self._closed = False
        self._motion_started = False
        self.physical_state = "unobserved"
        self.manager_outcome = None
        self.manager_local_failure = None
        self._truth_thread = None
        self._truth_stream = None
        self._log_level = kwargs.pop("log_level", logging.INFO)
        try:
            if runtime_context is not None:
                if args or not isinstance(runtime_context, RuntimeContext):
                    raise RuntimeConfigurationError("Invalid explicit runtime context.")
                incompatible = ("uplink_id", "ulfc", "downlink_id", "dlfc", "down_fs",
                                "error_profile", "gain_db")
                allowed = set(incompatible) | {"tx_id_file", "duration", "elv_mask", "file_prefix",
                    "nodate", "noid", "nopdu", "noptu", "nopixhawk", "nofrontend",
                    "record_iq", "record_trace", "work_modem_tx_source", "calibrate"}
                if (sat_id != runtime_context.tle.norad_id
                        or set(kwargs) - allowed
                        or ("duration" in kwargs and kwargs["duration"] != runtime_context.duration)
                        or ("elv_mask" in kwargs and kwargs["elv_mask"] != runtime_context.elevation)
                        or any(kwargs.get(key) is not None for key in incompatible)
                        or any(kwargs.get(key) for key in ("record_iq", "record_trace", "noptu", "nopixhawk", "calibrate"))
                        or kwargs.get("work_modem_tx_source", True) is not True):
                    raise RuntimeConfigurationError("Pointing arguments conflict with the admitted operation.")
                self._acquire_operator_activity(config_file, runtime_context=runtime_context)
                self._initialize_pointing(runtime_context, messenger=messenger, **kwargs)
            else:
                if messenger is not None:
                    raise RuntimeConfigurationError("Borrowed transport is supported only by explicit pointing.")
                self._initialize_legacy(config_file, sat_file, sat_id, *args, **kwargs)
        except BaseException as error:
            self._release_resources()
            if isinstance(error, RuntimeFailure):
                error.cleanup_errors = tuple(self.cleanup_errors)
            if self.cleanup_errors:
                print(f"Resource release failed after initialization failure ({len(self.cleanup_errors)}); "
                      f"cleanup_categories={','.join(self.cleanup_errors)}; "
                      f"logging_failure={self.logging_failure or 'none'}; "
                      "physical state is unverified.", file=sys.stderr)
            raise

    def _own(self, name, release):
        self._resources.append((name, release))

    def _acquire_operator_activity(self, config_file, *, runtime_context=None):
        try:
            if runtime_context is None:
                settings = self.config
                expected = None
            else:
                from satgs.runtime_configuration import _parse_station_yaml
                settings = _parse_station_yaml(runtime_context.raw_documents[2], allow_inline_ca=True)
                expected = runtime_context.station_sha256
            lease = acquire_runner_activity(config_file, settings, expected_sha256=expected)
        except (ActivityError, ValueError) as error:
            raise RuntimeConfigurationError(str(error)) from error
        if lease is not None:
            self._own("operator-station-lease", lease.release)

    def _deadline(self):
        return time.monotonic() + _RESOURCE_WAIT_SECONDS

    def _release_resources(self):
        if self._closed:
            return
        self._closed = True
        while self._resources:
            name, release = self._resources.pop()
            try:
                release()
            except BaseException:
                self.cleanup_errors.append(name)

    def _acquire_output(self):
        self._check_running()
        if self.log_dir.is_symlink() or any(parent.is_symlink() for parent in self.log_dir.parents):
            raise RuntimeFailure(6, "Output paths must not contain symlinks.")
        try:
            self.log_dir.mkdir(parents=True, exist_ok=False, mode=0o700)
        except FileExistsError:
            raise RuntimeFailure(6, "Output leaf already exists; previous results were preserved.") from None
        except OSError:
            raise RuntimeFailure(6, "Output directory could not be created.") from None
        logger = logging.getLogger()
        previous_level = logger.level
        self._own("logger-state", lambda: logger.setLevel(previous_level)
                  if logger.level == logging.DEBUG else None)
        logger.setLevel(logging.DEBUG)
        console = logging.StreamHandler()
        self._own_handler(logger, console, "console-handler")
        console.setLevel(self._log_level)
        logger.addHandler(console)
        for name, level in ((self.logname, logging.DEBUG), ("warnings", logging.WARNING)):
            self._check_running()
            try:
                handler = logging.FileHandler(self.log_dir / (name + ".log"), mode="x")
            except OSError:
                raise RuntimeFailure(6, "Owned log file could not be opened.") from None
            self._own_handler(logger, handler, "log-handler", owns_stream=True)
            handler.setLevel(level)
            handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
            logger.addHandler(handler)

    @property
    def logging_failure(self):
        return "owned-logging" if self._logging_failed.is_set() else None

    def _own_handler(self, logger, handler, name, *, owns_stream=False):
        self._own(name, lambda: self._close_handler(logger, handler, owns_stream=owns_stream))
        original_emit = handler.emit

        def emit(record):
            try:
                original_emit(record)
            except Exception:
                self._logging_failed.set()

        handler.handleError = lambda record: self._logging_failed.set()
        handler.emit = emit

    def _close_handler(self, logger, handler, *, owns_stream=False):
        logger.removeHandler(handler)
        failed = False
        handler.acquire()
        try:
            stream = handler.stream if owns_stream else None
            try:
                handler.flush()
            except Exception:
                failed = True
                self._logging_failed.set()
            try:
                handler.close()
            except Exception:
                failed = True
                self._logging_failed.set()
            if stream is not None and not stream.closed:
                try:
                    stream.close()
                except Exception:
                    failed = True
                    self._logging_failed.set()
        finally:
            handler.release()
        if failed:
            raise RuntimeFailure(6, "Owned log finalization failed.", category="owned-logging")

    def _install_signals(self):
        if not getattr(self, "_manage_signals", True) or threading.current_thread() is not threading.main_thread():
            return
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous = signal.getsignal(signum)
            handler = self._sigHandler
            signal.signal(signum, handler)
            self._own("signal-handler", lambda s=signum, p=previous, h=handler:
                      signal.signal(s, p) if signal.getsignal(s) == h else None)

    def _new_observer(self):
        observer = ephem.Observer()
        observer.lat = self.config['ground_station_lat'] * deg2rad
        observer.lon = self.config['ground_station_lon'] * deg2rad
        observer.elevation = self.config['ground_station_altm']
        return observer

    def _resolve_operator_pass(self, selected):
        if (type(selected) is not dict or type(selected.get("opportunity_index")) is not int
                or not 1 <= selected["opportunity_index"] <= 256
                or type(selected.get("index")) is not int
                or type(selected.get("norad_id")) is not int or selected["norad_id"] != self.satid
                or type(selected.get("circumpolar")) is not bool
                or type(selected.get("planning_start_utc")) is not str
                or len(selected["planning_start_utc"]) > 80):
            raise ValueError("Invalid selected pass identity.")
        span = selected.get("planning_span_days")
        if type(span) not in (int, float) or not math.isfinite(span) or not 1 / 24 <= span <= 7:
            raise ValueError("Invalid selected planning span.")
        start = datetime.fromisoformat(selected["planning_start_utc"])
        if start.tzinfo is None:
            raise ValueError("Selected planning start requires UTC.")
        start = start.astimezone(timezone.utc)
        if start.isoformat() != selected["planning_start_utc"]:
            raise ValueError("Selected planning start must be canonical UTC.")
        observer = copy(self.ground_station)
        observer.date = start
        passes = find_passes(self.satid, self.tle_db, observer, self.el_mask,
                             time_window_hrs=float(span) * 24)
        index = selected["opportunity_index"]
        if len(passes) > 256 or index > len(passes):
            raise ValueError("Selected pass is unavailable in the confirmed planning span.")
        resolved = passes[index - 1]
        expected = dict(index=index, norad_id=self.satid,
            rise_utc=None if resolved.is_circumpolar else resolved.sat_rise_time.isoformat(),
            set_utc=None if resolved.is_circumpolar else resolved.sat_set_time.isoformat(),
            rising_azimuth_deg=float(resolved.rising_az),
            setting_azimuth_deg=float(resolved.setting_az),
            maximum_elevation_deg=float(resolved.max_elv), circumpolar=bool(resolved.is_circumpolar))
        for name in ("rising_azimuth_deg", "setting_azimuth_deg", "maximum_elevation_deg"):
            value = selected.get(name)
            if type(value) not in (int, float) or not math.isfinite(value):
                raise ValueError("Selected pass coordinates are invalid.")
        if any(selected.get(name) != value for name, value in expected.items()):
            raise ValueError("Selected pass no longer matches the confirmed calculation.")
        return resolved, resolved.get_trajectory(observer, 1)

    def _initialize_pointing(self, context, *, messenger=None, **options):
        self.config = context.station
        try:
            require_runtime_location(self.config, bound=True)
        except LocationError as error:
            raise RuntimeConfigurationError(str(error)) from error
        self.satid = context.tle.norad_id
        self.duration = context.duration
        self.el_mask = context.elevation
        self.tle_db = {self.satid: {"tle": context.tle.tle, "name": context.tle.name,
                                  "date": context.tle.date}}
        self.nofrontend = True
        self.nopixhawk = self.noptu = self.has_pdu = False
        self.record_iq = self.record_trace = self.add_errors = False
        self.has_uplink = self.has_downlink = False
        try:
            self.ground_station = self._new_observer()
            self.iss = ephem.readtle(*context.tle.tle.split(','))
            nearest_pass, trajectory = (self._find_closest_pass() if self._selected_pass is None
                                        else self._resolve_operator_pass(self._selected_pass))
            if not math.isfinite(nearest_pass.max_elv) or not self.el_mask <= nearest_pass.max_elv <= 90:
                raise ValueError()
            now = datetime.now(timezone.utc)
            self.absolute_end_time = self._pointing_end_time(nearest_pass, trajectory, now)
            self.current_pass_info = nearest_pass
            self.current_pass_trajectory = trajectory
        except Exception:
            raise RuntimeConfigurationError("Local astronomy inputs do not resolve a supported bounded pass.") from None
        messenger_type, ptu_type, pixhawk_type = _pointing_owner_types()
        try:
            from ptu_control.pointing import PointingPolicy
            policy = PointingPolicy.from_settings(self.config, context.ptu.manager_id,
                                                 self.el_mask, context.no_go_data)
            policy.validate_tle(context.tle.tle)
        except Exception:
            self._check_running()
            raise RuntimeConfigurationError("Selected PTU run policy does not match the admitted inputs.") from None
        if messenger is not None and not isinstance(messenger, messenger_type):
            raise RuntimeConfigurationError("Borrowed transport does not implement the reviewed owner contract.")
        self.file_prefix = options.get("file_prefix", DEFAULTS.file_prefix)
        if not isinstance(self.file_prefix, str) or re.fullmatch(r"[A-Za-z0-9_-]+", self.file_prefix) is None:
            raise RuntimeConfigurationError("Invalid output prefix.")
        clean_name = re.sub(r'\W+', '', context.tle.name.replace(' ', '_'))
        if options.get("nodate", False):
            self.logname = self.file_prefix if options.get("noid", False) else f"{self.file_prefix}_{self.satid}"
        else:
            self.logname = f"{self.file_prefix}_{self.satid}_{now.strftime('%m_%d_%y_%H_%M_%S')}"
        self.parent_folder = f"{now.strftime('%m-%d-%y')}/{self.satid}_{clean_name}"
        output_root = self.config['logging_dir'].replace('~', self.config['home_directory'])
        self.log_dir = Path(output_root) / self.parent_folder / self.logname
        self._check_running()
        prepared = None
        if messenger is None:
            try:
                prepared = messenger_type.prepare_transport(settings=self.config, cancel=self.cancel_event)
            except Exception:
                self._check_running()
                raise RuntimeFailure(4, "Transport preparation failed; physical readiness is unverified.") from None
        else:
            try:
                compatible = messenger.strict_instance_compatible(settings=self.config) is True
            except Exception:
                self._check_running()
                raise RuntimeConfigurationError("Borrowed transport is incompatible with admitted settings.") from None
            self._check_running()
            if not compatible:
                raise RuntimeConfigurationError("Borrowed transport is incompatible with admitted settings.")
        self._check_running()
        try:
            self.absolute_end_time = self._pointing_end_time(nearest_pass, trajectory, datetime.now(timezone.utc))
        except Exception:
            self._check_running()
            raise RuntimeConfigurationError("Local astronomy inputs no longer resolve a supported bounded pass.") from None
        self._check_running()
        self._acquire_output()
        self._install_signals()
        self._start_truth_worker()
        self._check_running()
        try:
            if messenger is None:
                messenger = messenger_type.open_bounded(settings=self.config,
                    deadline=self._deadline(), cancel=self.cancel_event, prepared=prepared)
                self._own("messenger", lambda: messenger.close(deadline=self._deadline()))
            self._check_running()
            self.ptu_client = ptu_type.open_pointing(messenger=messenger, settings=self.config,
                ptu_id=context.ptu.manager_id, elevation_mask=self.el_mask, log_dir=self.log_dir,
                no_go_data=context.no_go_data, deadline=self._deadline(), cancel=self.cancel_event)
            self._own("ptu-client", lambda: self.ptu_client.close(deadline=self._deadline()))
            self._check_running()
            self.pixhawk = pixhawk_type.open_pointing(messenger=messenger, settings=self.config,
                pix_id=context.pixhawk.manager_id, log_dir=self.log_dir,
                deadline=self._deadline(), cancel=self.cancel_event)
            self._own("pixhawk-client", lambda: self.pixhawk.close(deadline=self._deadline()))
            self.ptu_client.enable_scheduled_tracking(deadline=self._deadline(), cancel=self.cancel_event)
            for client in (self.ptu_client, self.pixhawk):
                self._check_running()
                if client.check_connection(deadline=self._deadline(), cancel=self.cancel_event) is not True:
                    raise RuntimeFailure(4, "Selected owner did not establish bounded connectivity.")
        except RuntimeFailure as error:
            if hasattr(self, 'ptu_client'):
                self._observe_manager_outcome()
            error.manager_outcome = self.manager_outcome
            error.manager_local_failure = self.manager_local_failure
            raise
        except Exception:
            if hasattr(self, 'ptu_client'):
                self._observe_manager_outcome()
            if self.cancel_event.is_set():
                raise RuntimeFailure(130, "Cancellation requested; physical state remains unverified.",
                    manager_outcome=self.manager_outcome,
                    manager_local_failure=self.manager_local_failure) from None
            raise RuntimeFailure(4, "Selected resource acquisition failed; physical readiness is unverified.",
                                 manager_outcome=self.manager_outcome,
                                 manager_local_failure=self.manager_local_failure) from None

    def _pointing_end_time(self, pass_info, trajectory, now):
        if pass_info.is_circumpolar:
            return now + timedelta(seconds=self.duration, minutes=3)
        start = max(now, pass_info.sat_rise_time)
        if pass_info.sat_set_time <= start or self.duration > (pass_info.sat_set_time - start).total_seconds():
            raise ValueError()
        if not self._has_priming_opportunity(pass_info, trajectory, now):
            raise ValueError()
        return pass_info.sat_set_time + timedelta(minutes=3)

    def _has_priming_opportunity(self, pass_info, trajectory, now):
        prediction_time = now + _PRIME_LOOKAHEAD
        if prediction_time > pass_info.sat_set_time:
            return False
        _, elevation = self.get_sat_pos(prediction_time)
        if self.el_mask <= elevation <= 180 - self.el_mask:
            return True
        # Retain future/early-rising entry through waiting, including the exact boundary above.
        return any(
            prediction_time < trajectory.t_ref + timedelta(seconds=float(offset)) <= pass_info.sat_set_time
            and self.el_mask <= elevation <= 180 - self.el_mask
            for offset, elevation in zip(trajectory.t_steps, trajectory.el)
        )

    def _start_truth_worker(self):
        self._check_running()
        self._truth_observer = self._new_observer()
        self._truth_body = ephem.readtle(*self.tle_db[self.satid]['tle'].split(','))
        try:
            self._truth_stream = open(self.log_dir / "sat_truth_pos.csv", "x", newline="")
            self._own("truth-file", self._close_truth_file)
            self.sat_pos_writer = csv.writer(self._truth_stream)
            self.sat_pos_writer.writerow(['utc_time', 'azimuth', 'elevation'])
            self._truth_stream.flush()
            self._truth_thread = threading.Thread(target=self.create_sat_pos_writer,
                args=(self.sat_pos_thread_signal, self.log_dir), name="satgs-truth")
            self._own("truth-thread", self._stop_truth_worker)
            self._truth_thread.start()
        except Exception:
            raise RuntimeFailure(6, "Truth logging could not start.") from None

    def _stop_truth_worker(self):
        self.sat_pos_thread_signal.set()
        if self._truth_thread.ident is not None:
            self._truth_thread.join(_RESOURCE_WAIT_SECONDS)
        if self._truth_thread.is_alive():
            raise RuntimeFailure(7, "Truth worker did not stop within the release bound.")

    def _close_truth_file(self):
        if self._truth_thread is not None and self._truth_thread.is_alive():
            raise RuntimeFailure(7, "Truth file retained for an unjoined worker.")
        self._truth_stream.close()

    def _check_running(self):
        state = getattr(self, "state", "admitting")
        if getattr(self, "_progress", None) is not None and state != self._progress_state:
            self._progress_state = state
            self._progress({"state": state, "physical_state": self.physical_state,
                            "local_cancellation_requested": self.cancel_event.is_set()})
        if self.cancel_event.is_set():
            raise RuntimeFailure(130, "Cancellation requested; physical state remains unverified.")
        if self._worker_error is not None:
            raise RuntimeFailure(6, "Truth logging failed.", category="truth-logging")
        if self._logging_failed.is_set():
            raise RuntimeFailure(6, "Owned logging failed.", category="owned-logging")

    def _ptu_command(self, method, *args):
        self._check_running()
        if self.runtime_context is None:
            return getattr(self.ptu_client, method)(*args)
        if method == "prime":
            self._motion_started = True
            self.physical_state = "indeterminate"
        try:
            result = getattr(self.ptu_client, method)(*args, deadline=self._deadline(), cancel=self.cancel_event)
        except Exception:
            self._observe_manager_outcome()
            self._check_running()
            raise
        self._observe_manager_outcome()
        if result is False:
            raise RuntimeFailure(5, "Selected PTU command was not accepted.")
        return result

    def _observe_manager_outcome(self):
        if self.runtime_context is None:
            return
        self.manager_outcome = self.ptu_client.tracking_outcome()
        self.manager_local_failure = self.ptu_client.tracking_failure()

    def _check_manager_outcome(self):
        if self.runtime_context is None:
            return
        self._observe_manager_outcome()
        self._check_running()
        if self.manager_local_failure is not None or (
                self.manager_outcome is not None and self.manager_outcome.category != "ok"):
            raise RuntimeFailure(5, "Selected manager operation failed; physical state is unverified.")

    def _initialize_legacy(self, config_file:Path, sat_file:Path, sat_id:int,
                 tx_id_file:Path=None, 
                 uplink_id:str=None, ulfc:float=None, 
                 downlink_id:str=None, dlfc:float=None, down_fs:float=None, 
                 gain_db:float=DEFAULTS.default_gain,
                 elv_mask:float=DEFAULTS.elev_mask, 
                 duration:float=0,
                 file_prefix:str=DEFAULTS.file_prefix,
                 error_profile:Union[Path, str]=None,
                 nodate:bool=False, noid:bool=False, 
                 nopdu:bool=False, noptu:bool=False,
                 nopixhawk:bool=False, nofrontend:bool=False,                  
                 record_iq:bool=False, record_trace:bool=True,
                 work_modem_tx_source:bool=True,
                 ):
        """Constructor

        Args:
            config_file (Path): Yaml Config File
            sat_file (Path): CSV File containing satellite TLEs
            sat_id (int): Satellite ID 
            tx_id_file (Path, optional): CSV file containing emission ID details. Defaults to None.
            uplink_id (str, optional): Uplink ID. Defaults to None.
            ulfc (float, optional): (MHz) Uplink Freq is no ID is specified. If both none assume no uplink. Defaults to None.
            downlink_id (str, optional): Downlink ID. Defaults to None.
            dl_fc (float, optional): (MHz) Downlink Fc. Defaults to None.
            down_fs (float, optional): (MSPS) Downlink Sampling rate. Defaults to None.
            gain_db (float, optional): Ettus gain. Defaults to 60.
            elv_mask (float, optional): Elevation mask. Defaults to DEFAULTS.elev_mask.
            duration (float, optional): Duration. Defaults to 0.
            file_prefix (str, optional): Prefix prepended to the log files, usually a pass-id. Default set in constants file
            error_profile(str or Path, optional), path to file that specifies az/el pointing errors to add to the pass
                Defaults to None,
            nodate (bool, optional): If true, date is excluded from logname. Defaults to False.
            noid (bool, optional): If true, sat ID is excluded from logname. Defaults to False.
            nopdu (bool, optional): If true, does not include CyberPowerPDU/ HPA in execution pipeline. Defaults to False.
            noptu (bool, optional): If true, does not include the pan tilt unit in execution pipeline. Defaults to False.
            nopixhawk (bool, optional): If true, does not include the pixhawk in execution pipeline. Defaults to False.
            nofrontend (bool, optional): If true, does not include RF Front end in execution pipeline. Defaults to False.
            record_iq (bool, optional): If true, INcludes IQ recorder in execution pipeline. Defaults to False.            
            record_trace (bool, optional): If true, INcludes trace/Channel power logger in execution pipeline. Defaults to True.            
            work_modem_tx_source(bool, optional). If False, TX source is SIP. Defaults to TRUE (AKA TX SOURCE is Work Modem)
        """
        # Load config File
        with open(config_file) as f:
            self.config = yaml.safe_load(f)        
        try:
            require_runtime_location(self.config)
        except LocationError as error:
            raise RuntimeConfigurationError(str(error)) from error
        self._acquire_operator_activity(config_file)

        self.park_est_time = DEFAULTS.park_dur_est

        if '~' in str(config_file):
            config_file = Path(str(config_file).replace('~', self.config['home_directory']))   
        self.config_file = config_file
        
        if '~' in str(sat_file):
            sat_file = Path(str(sat_file).replace('~', self.config['home_directory']))            
        self.sat_file = sat_file      
        tle_df = pd.read_csv(sat_file)
        self.tle_db = tle_df.set_index('norad_id').to_dict("index")
        
        if '~' in str(tx_id_file):
            tx_id_file = Path(str(tx_id_file).replace('~', self.config['home_directory']))            
        self.tx_id_file = tx_id_file
        
        em_id_df = pd.read_csv(tx_id_file)
        self.em_id_db = em_id_df.set_index('txid').to_dict("index")
        self.satid = sat_id
        self.uplink_id_in = uplink_id
        self.uplink_fc_in = ulfc
        self.downlink_id_in = downlink_id
        self.downlink_fc_in = dlfc
        self.downlink_bw_in = down_fs
        if gain_db is None:
            self.gain = DEFAULTS.default_gain
        else:
            self.gain = gain_db
        self.duration = duration
        self.file_prefix = file_prefix
        self.el_mask = elv_mask
        self.noid = noid
        self.nodate = nodate
        self.record_iq = record_iq
        self.record_trace = record_trace
        self.nofrontend = nofrontend
        self.nopixhawk = nopixhawk
        self.noptu = noptu
        self.has_pdu = not nopdu
        self.work_modem_tx_source = work_modem_tx_source

        self.add_errors = False
        if error_profile is not None:
            self.add_errors = True
       
        self.logname, self.parent_folder = determine_filename(self.file_prefix, self.satid, self.sat_file, self.nodate, self.noid)
        self.log_dir = Path(self.config['logging_dir']) / '{}/{}'.format(self.parent_folder, self.logname)
      
        if '~' in str(self.log_dir):
            self.log_dir = Path(str(self.log_dir).replace('~', self.config['home_directory']))            
        
        self._acquire_output()
        if self.add_errors:
            logging.warning("Pass being executed with pointing error profile")
                            
        self.credentials = {"username": self.config["amq_username"], 
                            "password": self.config["amq_password"]}

        # Validate frequency scheme  
        if (self.downlink_id_in is None) and (self.downlink_fc_in==0):
            self.has_downlink = False
        else:
            self.has_downlink = True
        
        if (self.uplink_id_in is None) and (self.uplink_fc_in==0):
            self.has_uplink = False
        else:
            self.has_uplink = True  
              
        downlink_params, uplink_fc = self._recorder_freq_planning()          
        self.downlink_rf_fc = downlink_params[0]
        self.downlink_bw = downlink_params[1]
        self.ettus_bw = downlink_params[2] # Dont think this is relevent anymore... can probably delete
        self.uplink_fc = uplink_fc
                   
        # Set up ground station observer & TLE object
        self.ground_station = ephem.Observer()
        self.ground_station.lat = self.config['ground_station_lat'] * deg2rad
        self.ground_station.lon = self.config['ground_station_lon'] * deg2rad
        self.ground_station.elevation = self.config['ground_station_altm']
        tle_str = self.tle_db[self.satid]['tle']
        tle_list = tle_str.split(',')
        self.iss = ephem.readtle(tle_list[0], tle_list[1], tle_list[2])

        # Create the sat position writer
        self._start_truth_worker()

        # Connect component HW            
        # DSI Front end instruments
        self._initialize_frontend()               
        # Pixhawk
        self._initialize_pixhawk()
        # Cyber Power PDU Outlet switch
        self._initialize_pdu()                
        # PTU Sat Tracker
        self._initialize_ptu()  
        
        # Need to this after initialize RF Front End to ensure loggers are recording 
        # correct IF frequency on the downlink
        if self.record_iq:
            if self.iq_logger_link_side=='uplink':
                self.iq_recorder_fc = uplink_fc
                self.iq_recorder_bw = DEFAULTS.uplink_trace_bw
                self.iq_recorder_ref_lev = DEFAULTS.uplink_ref_level_dbm
            else:
                self.iq_recorder_fc = self.downlink_if_fc
                self.iq_recorder_bw = downlink_params[1]
                self.iq_recorder_ref_lev = DEFAULTS.downlink_ref_level_dbm                
        if self.record_trace:
            if self.trace_logger_link_side=='uplink':
                self.trace_logger_fc = uplink_fc
                self.trace_logger_trace_bw = DEFAULTS.uplink_trace_bw
                self.trace_logger_ch_bw = DEFAULTS.uplink_ch_bw                
                self.trace_logger_ref_lev = DEFAULTS.uplink_ref_level_dbm
            elif self.trace_logger_link_side=='downlink':
                self.trace_logger_fc = self.downlink_if_fc
                if self.downlink_bw>0:
                    self.trace_logger_trace_bw = downlink_params[1]*2
                    self.trace_logger_ch_bw = downlink_params[1]                    
                else:
                    self.trace_logger_trace_bw = DEFAULTS.uplink_trace_bw
                    self.trace_logger_ch_bw = DEFAULTS.uplink_ch_bw
                self.trace_logger_ref_lev = DEFAULTS.downlink_ref_level_dbm
        if self.record_trace:
            logging.warning(f"Trace logger recording {self.trace_logger_link_side}")
        if self.record_iq:
            logging.warning(f"IQ logger recording {self.iq_logger_link_side}")
        if self.has_downlink:
            logging.warning(f"Downlink RF Fc {self.downlink_rf_fc:0.2f} BW: {self.downlink_bw:0.2f} IF Fc {self.downlink_if_fc}")
        else:
            logging.warning(f"No Downlink")
        if self.has_uplink:
            logging.warning(f"Uplink RF Fc {self.uplink_fc:0.2f}")
        else:
            logging.warning(f"No Uplink")            

        test_run_details = {}
        test_run_details['positioners'] = []
        from ptu_control.utils import PtuID
        for ptu_id in self.ptu_client.ptu_ids:
            test_run_details['positioners'].append(self.ptu_client.ptu_dict[ptu_id])
            ptu_details = PtuID.from_dict(self.ptu_client.ptu_dict[ptu_id])
            if ptu_details.no_go_config is not None:
                dest_file = self.log_dir / "no_go_zone_ptu_id_{}.yaml".format(ptu_id)
                source_yaml = ptu_details.no_go_config
                if '~' in str(source_yaml):
                    source_yaml = Path(str(source_yaml).replace('~', self.config['home_directory']))                          
                    self.ptu_client.ptu_dict[ptu_id]['no_go_config']=str(source_yaml)
                shutil.copy(source_yaml, dest_file)

        test_run_details['real_time'] = True
        test_run_details['pass_ref_time'] = datetime.now(timezone.utc).strftime(time_format_tzone)
        test_run_details['iq_logger_link_side'] = self.config['iq_logger_link_side']
        test_run_details['trace_logger_link_side'] = self.trace_logger_link_side #self.config['trace_logger_link_side']
        test_run_details['channel_power'] = self.config['channel_power']
        with open(self.log_dir / 'test_details.yaml', 'w') as file:
            yaml.dump(test_run_details, file, sort_keys=False)          

        cal_ptu = False
        nearest_pass, pass_trajectory = self._find_closest_pass()        
        if nearest_pass.is_circumpolar:
            self.absolute_end_time = (
                datetime.now(timezone.utc) 
                + timedelta(seconds=duration) 
                + timedelta(minutes=3))
            cal_ptu = True            
        else:
            self.absolute_end_time = nearest_pass.sat_set_time + timedelta(minutes=3)
            rise_idx = np.where(pass_trajectory.el > self.el_mask)[0][0]
            rise_time = pass_trajectory.t_ref + timedelta(seconds=float(pass_trajectory.t_steps[rise_idx]))
            if (rise_time - timedelta(seconds=DEFAULTS.prime_dur_est+DEFAULTS.ptu_cal_dur_est))> datetime.now(timezone.utc):
                cal_ptu = True     
        self.current_pass_info = nearest_pass
        self.current_pass_trajectory = pass_trajectory
        self.current_pass_zenith_time = pass_trajectory.t_ref + timedelta(seconds = float(pass_trajectory.t_steps[np.argmax(pass_trajectory.el)]))
        # IQ recorder
        self._initialize_iq_recorder()
        self._initialize_trace_logger()
        
        logging.warning("Satellite Pass info \n{}".format(nearest_pass.get_str()))
        logging.warning("Drop dead end time [Loc.]: {}".format(self.absolute_end_time.astimezone().strftime(time_format_print)))
        if cal_ptu:
            logging.warning("Calibrating PTU ... Takes up to 1 min")
            self.ptu_client.calibrate_ptu()
        else:
            logging.warning("Insufficient time before SV rises to cal PTU. Just Starting.")
        self.ptu_client.start_logging()
        
        self.exit_attempts = 0
        self._install_signals()

        logging.info("Ground Station Initialization Completed Successfully! ... ")

    def create_sat_pos_writer(self, signal: threading.Event,
                              parent_log_dir: Path) -> None:
        """
        Non-blocking sat_truth_pos.csv writer
        Describes the current position of the sat in reference to the configured ground station
        Writes twice per second until shutdown

        """
        try:
            while not signal.is_set():
                utc_now = datetime.now(timezone.utc)
                self._truth_observer.date = utc_now
                self._truth_body.compute(self._truth_observer)
                self.sat_pos_writer.writerow([utc_now.isoformat(),
                    self._truth_body.az * 180 / np.pi, self._truth_body.alt * 180 / np.pi])
                self._truth_stream.flush()
                signal.wait(0.5)
        except BaseException:
            self._worker_error = "truth-writer"
            signal.set()

        
    def _initialize_frontend(self):
        if (not self.nofrontend):
            from dsi.front_end_client import FrontEndClient
            from telnetlib3.sync import TelnetConnection
            logging.warning("Connecting to RF Front End....")
            try:
                front_end_messenger = Messenger(self.config['amq_server'], self.config['amq_port'], 
                                                self.credentials, use_ssl=self.config['amq_use_ssl'], 
                                                reconnect_attempts_max=3)
            except:
                logging.error("Could not connect active MQ server....")
            
            self.front_end = FrontEndClient(front_end_messenger,log_file=self.log_dir/'frontend_log.csv')              
            
            if not self.work_modem_tx_source and self.has_uplink is True:
                # Detected -sip-src flag (modem_tx_source is false)
                logging.info(f"Configuring SIP as TX Source with IF Fc: 1000 MHZ ...")
                try:
                    with TelnetConnection("192.168.0.79", 5025, connect_timeout=5) as conn:
                        conn.write("OUTP?\r\n")
                        reply = conn.readline()
                        logging.info("Signal Generator - Initial RF State: {} ... (0/OFF, 1/ON)".format(reply.strip('\n')))
                        if reply.strip("\n") == "1":
                            logging.info("Turning off the Signal Generator RF... ")
                            conn.write("OUTP OFF\r\n")
                        conn.write(f"FREQ 1000 MHZ\r\n")
                        conn.write("FREQ?\r\n")
                        reply = conn.readline()
                        logging.info("Signal Generator - New Frequency Setting: {}".format(reply.strip('\n')))
                        conn.write("OUTP ON\r\n")
                        conn.write("OUTP?\r\n")
                        reply = conn.readline()
                        logging.info("Signal Generator - Final RF State: {} ... (0/OFF, 1/ON)".format(reply.strip('\n')))
                        if reply.strip("\n") == "0":
                            logging.warning("Signal generator reported RF state is OFF. Tone might not be present ... Proceeding anyway")
                except OSError as e:
                    logging.error(f"Telnet target unreachable: {e} Is the SIP TX Source reachable? ... Unable to configure the SIP TX source")
                except ConnectionError as e:
                    logging.error(f"Connection error: {e} Is the SIP TX Source reachable? ... Unable to configure the SIP TX source")
                except TimeoutError as e:
                    logging.error(f"Connection timeout: {e} Check your connection to the SIP TX source ... Unable to configure the SIP TX source")
            else:
                # Not an uplink or work_modem_tx_source is true, ensure sig generator is off
                logging.info(f"Verifying SIP TX Source is turned off ...")
                try:
                    with TelnetConnection("192.168.0.79", 5025, connect_timeout=5) as conn:
                        conn.write("OUTP OFF\r\n")
                        conn.write("OUTP?\r\n")
                        reply = conn.readline()
                        if reply.strip("\n") != "0":
                            logging.warning("Signal generator reported RF state is not OFF. Tone might be present ... Proceeding anyway")
                except OSError as e:
                    logging.error(f"Telnet target unreachable: {e} Is the SIP TX Source reachable? ... Unable to configure the SIP TX source")
                except ConnectionError as e:
                    logging.error(f"Connection error: {e} Is the SIP TX Source reachable? ... Unable to configure the SIP TX source")
                except TimeoutError as e:
                    logging.error(f"Connection timeout: {e} Check your connection to the SIP TX source ... Unable to configure the SIP TX source")

            if self.front_end.check_connection():
                logging.warning("RF Front End Client Ready")                
            else:
                logging.error("RF Front end client didn't get response from manager, dsi_frontend.service may not be running or crashed")
            logging.info("Disabling RF paths until Antenna is Primed")
            self.front_end.disconnect_tx()
            # Not doing this until the antenna is primed to avoid accidental cell tower blasting. 
            self.front_end.configure_rx(frequency=self.downlink_rf_fc)       
            rx_config = self.front_end.request_rx_status()
            self.downlink_if_fc = self.downlink_rf_fc
            if rx_config is not None:
                # This is the IF from the front end
                self.downlink_if_fc = rx_config.if_out
                
            self.front_end.disconnect_rx()
            if self.has_uplink:
                self.front_end.configure_tx(frequency=self.uplink_fc, work_modem_tx_source=self.work_modem_tx_source)
        else:
            self.downlink_if_fc = self.downlink_rf_fc
            logging.warning("Running without Front End")
                    
    def _initialize_pixhawk(self):
        if (not self.nopixhawk):
            from pixhawk.pixhawk_subscriber import PixhawkSubscriber
            logging.warning("Connecting to Pixhawk for Dish Logging....")            
            try:                
                pixhawk_messenger = Messenger(self.config['amq_server'], self.config['amq_port'], 
                                              self.credentials, use_ssl=self.config['amq_use_ssl'], 
                                              reconnect_attempts_max=3)
            except:
                logging.error("Could not connect active MQ server....")
                
            self.pixhawk = PixhawkSubscriber(pixhawk_messenger, config=self.config_file, pix_id=0,
                                             filename= self.log_dir/'pixhawk_log.csv' , standalone=False)    
            if self.pixhawk.check_connection():
                logging.warning("Pixhawk Client Ready")                
            else:
                logging.error("Didn't get response from all of Pixhawk Managers... Check Log, may be connection issues")       
                               
            # Setup this logger to log to specific file at debug level
            pixhawk_logger = logging.getLogger("pixhawk.pixhawk_subscriber")
            previous_state = (pixhawk_logger.level, pixhawk_logger.propagate)
            self._own("pixhawk-logger-state", lambda:
                      (pixhawk_logger.setLevel(previous_state[0]) if pixhawk_logger.level == logging.DEBUG else None,
                       setattr(pixhawk_logger, "propagate", previous_state[1]) if not pixhawk_logger.propagate else None))
            pixhawk_logger.propagate=False
            # get root logger and existing file handler
            root_logger = logging.getLogger()
            root_file_handler = [handler for handler in root_logger.handlers if isinstance(handler,logging.FileHandler)]
            pixhawk_logger.setLevel(logging.DEBUG)
            formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s') 
            if len(root_file_handler)>0:
                file_handler = logging.FileHandler(Path(root_file_handler[0].stream.name).parent / 'pixhawk_client.log', 'w+')
                self._own_handler(pixhawk_logger, file_handler, "pixhawk-log-handler", owns_stream=True)
                file_handler.setLevel(logging.DEBUG)  
                file_handler.setFormatter(formatter)          
                pixhawk_logger.addHandler(file_handler)  
                logging.info("Stopped propagating pixhawk log- now logging to separate file")        
        else:
            logging.warning("Running without Pixhawk")
            
    def _initialize_ptu(self):
        from ptu_control.ptu_client import PtuClient
        try:
            ptu_messenger = Messenger(self.config['amq_server'], self.config['amq_port'], 
                                      self.credentials, use_ssl=self.config['amq_use_ssl'], 
                                      reconnect_attempts_max=3)
        except:
            logging.error("Could not connect active MQ server....")        
        
        if (self.noptu):
            self.ptu_client = PtuClient(
                ptu_messenger,config=self.config_file, ptu_id=0, 
                elevation_mask=self.el_mask, test_mode= True,
                cmd_log_file=self.log_dir / "ptu_cmds.csv",
                status_log_file= self.log_dir / "ptu_status.csv")
            
            logging.warning("PTU Client Ready: Running in test mode. No interaction with the manager/HW")                                           
        else: 
            self.ptu_client = PtuClient(
                ptu_messenger, config=self.config_file, ptu_id=0,
                elevation_mask=self.el_mask,
                cmd_log_file=self.log_dir / "ptu_cmds.csv",
                status_log_file= self.log_dir / "ptu_status.csv")
            
            if self.ptu_client.check_connection():
                logging.warning("PTU Client Ready")                
            else:
                logging.error("Didn't get response from all of PTU Managers... Check Log, may be connection issues")       
    
    def _initialize_pdu(self):
        if (self.has_pdu):
            from cyberpowerpdu.pdu_client import PduClient
            logging.warning("Connecting to CyberPower PDU for HPA/ Warning light control....")                        
            try:
                pdu_messenger = Messenger(self.config['amq_server'], self.config['amq_port'], self.credentials, 
                                          use_ssl=self.config['amq_use_ssl'], 
                                          reconnect_attempts_max=3)
            except:
                logging.error("Could not connect active MQ server....")
            self.pdu_switch = PduClient(pdu_messenger, log_file=self.log_dir/'hpa_log.csv')
            if self.pdu_switch.check_connection():
                logging.warning("Power Strip Client Ready")                
            else:
                logging.error("Power Strip client didn't get response from manager, cyberpowerPDU.service may not be running or crashed")       
    
    def _initialize_iq_recorder(self):
        if (self.record_iq):
            from signal_hound_control.sh_client import SignalHoundClient
            logging.warning("Connecting Signal Hound Client -- IQ Recorder")                        
            sh_messenger_iq = Messenger(self.config['amq_server'], self.config['amq_port'], self.credentials, 
                                          use_ssl=self.config['amq_use_ssl'], 
                                          reconnect_attempts_max=3)
            self.iq_rec_client = SignalHoundClient(sh_messenger_iq)
            
            # The RF freq is just used for the IQ engine meta data
            if self.iq_logger_link_side=='uplink':
                iq_recorder_rf_fc = self.uplink_fc
            elif self.iq_logger_link_side=='downlink':
                iq_recorder_rf_fc = self.downlink_rf_fc
            else:
                iq_recorder_rf_fc = self.iq_recorder_fc                
                 
            self.iq_rec_client.configure_record(
                bw_mhz = self.iq_recorder_bw, fc_mhz=self.iq_recorder_fc, ref_level_dbm=self.iq_recorder_ref_lev, 
                filename=str(self.log_dir/"satcapture.sigmf-data"),
                max_duration= int(self.duration+60), fc_rf_mhz=iq_recorder_rf_fc)
            logging.warning("Signal Hound -- IQ Recorder Ready to Record")
            
    def _initialize_trace_logger(self):
        if (self.record_trace):
            from signal_hound_control.sh_sa_client import SigHoundSweptAnalyzerClient
            logging.warning("Connecting Signal Hound Client -- Trace Logger")                        
            sh_messenger_trace = Messenger(self.config['amq_server'], self.config['amq_port'], self.credentials, 
                                          use_ssl=self.config['amq_use_ssl'], 
                                          reconnect_attempts_max=3)
            self.trace_logger_client = SigHoundSweptAnalyzerClient(
                sh_messenger_trace, config=self.config_file, 
                log_file=self.log_dir/'channel_power.csv', standalone=False)              
                 
            self.trace_logger_client.configure(
                fc_mhz=self.trace_logger_fc, bw_mhz=self.trace_logger_trace_bw,
                ch_bw_mhz=self.trace_logger_ch_bw, ref_level_dbm=self.trace_logger_ref_lev,
                trace_log_name=Path('{}/{}'.format(self.parent_folder, self.logname)) / 'trace_data.csv',
                duration=int(self.duration+60))
                                               
            logging.warning("Signal Hound -- Trace Logger Ready to Record")            
        
    def _find_closest_pass(self, hrs_past:float = 12, hrs_future:float=6)->tuple[PassInfo,AzElTrajectory]:
        utc_now = datetime.now(timezone.utc)
        temp_observer = copy(self.ground_station)
        temp_observer.date = utc_now - timedelta(hours=hrs_past)
        
        upcoming_passes = find_passes(self.satid, self.tle_db, temp_observer, 
                                      self.el_mask, time_window_hrs=(hrs_past+hrs_future+1))
        if not upcoming_passes:
            raise RuntimeConfigurationError("No supported local pass is available.")
        
        # sat_name = self.tle_db[self.satid]['name']
        # Check if circumpolar:
        if upcoming_passes[0].is_circumpolar:
            if self.runtime_context is None:
                logging.info("Satellite is Geostationary, Running for specified duration {:.1f}".format(self.duration))
            pass_info = upcoming_passes[0]
        else: 
            # Check that current start time roughly lines up with satellite pass
            matching_pass = [sat_pass 
                             for sat_pass in upcoming_passes 
                             if ((utc_now>=sat_pass.sat_rise_time) and (utc_now<sat_pass.sat_set_time)) ]
            if len(matching_pass)>0:
                if self.runtime_context is None:
                    logging.info("Attention: Starting after satellite has risen")
                pass_info = matching_pass[0]              
            else:
                start_deltas = [(sat_pass.sat_rise_time-utc_now).total_seconds() 
                                for sat_pass in upcoming_passes 
                                if (sat_pass.sat_rise_time-utc_now).total_seconds()>0]
                next_passes = [sat_pass for sat_pass in upcoming_passes 
                               if (sat_pass.sat_rise_time-utc_now).total_seconds()>0]
                if not start_deltas:
                    raise RuntimeConfigurationError("No future local pass is available.")
                next_pass_delta = min(start_deltas)
                pass_info = next_passes[start_deltas.index(next_pass_delta)]                
                next_pass_time = next_passes[start_deltas.index(next_pass_delta)].sat_rise_time
                if self.runtime_context is None:
                    logging.info("Satellite does not cross horizon until {}, or {:.1f} min from now".format(next_pass_time.strftime(time_format_print), next_pass_delta/60))
                if next_pass_delta>60*60*2:
                    if self.runtime_context is None:
                        logging.error("Error satellite does not cross horizon until {:.2f} hrs from now. Exiting. Pass_runner should be called closer to satellite rise time".format(next_pass_delta/3600))
                    raise RuntimeConfigurationError("The next local pass is outside the supported start window.")
        pass_trajectory = pass_info.get_trajectory(temp_observer, 1)
        return pass_info, pass_trajectory          
        
    def _recorder_freq_planning(self):
        '''
        Validates tx id, and frequency and sample rate
        '''        
        if self.downlink_id_in is not None:
            if self.downlink_id_in not in self.em_id_db.keys():
                logging.error("Downlink designator {} not found in Emission ID dB".format(self.downlink_id_in))
                
            sig_params = self.em_id_db[self.downlink_id_in]
            downlink_fc = float(sig_params['fc_mhz'])
            downlink_bw = float(sig_params['bw_mhz'])#CHAND DLBW      
        else:
            if (self.downlink_fc_in is None):
                logging.error('No Downlink')
            downlink_fc = self.downlink_fc_in
            downlink_bw = self.downlink_bw_in
        
        # Ettus BW planning: Irrelevent NOw            
        ettus_bw = int(downlink_bw*2)
        if ettus_bw > 40e6:
            ettus_bw = int(40e6)
        elif ettus_bw < 20e6:
            ettus_bw = int(20e6)
            
        downlink_params = (downlink_fc, downlink_bw, ettus_bw)
        
        if self.uplink_id_in is not None:
            if self.uplink_id_in not in self.em_id_db.keys():
                logging.error("Uplink designator {} not found in Emission ID dB".format(self.uplink_id_in))
                
            sig_params = self.em_id_db[self.uplink_id_in]
            uplink_fc = float(sig_params['fc_mhz'])
        else:
            if (self.uplink_fc_in is None):
                logging.warning('No Uplink')
            uplink_fc = self.uplink_fc_in

        # Configure IQ Recorder for uplink or downlink freq selection
        if (self.config["iq_logger_link_side"] in ["uplink", "u", "up"]) and self.record_iq:
            if self.has_uplink:
                logging.warning("IQ recorder will record uplink")
                self.iq_logger_link_side = 'uplink'
            elif not self.has_uplink:
                logging.warning("link does not have uplink. Will NOT record IQ")                
                self.record_iq = False                                
        elif (self.config["iq_logger_link_side"] in ["downlink", "d", "down"]) and self.record_iq:
            if self.has_downlink and (downlink_bw>0):
                logging.warning("IQ recorder will record downlink")
                self.iq_logger_link_side = 'downlink'
            elif self.has_downlink and (downlink_bw==0):
                logging.warning("Recording downlink IQ requires an -dlbw arg so as to not do meaningless RF capture. Recorder will be disbaled")
                self.iq_logger_link_side = 'downlink'
                self.record_iq = False                                                                             
            elif not self.has_downlink:
                logging.warning("Link does not have Downlink. Will NOT record IQ")                                
                self.record_iq = False                             
        elif self.config["iq_logger_link_side"] is None and self.record_iq:
            logging.warning("IQ recorder disabled, it will record nothing")            
            self.iq_logger_link_side = 'na'
            self.record_iq = False            
        elif not self.record_iq:
            self.iq_logger_link_side = 'na'                       
            logging.warning("IQ recorder disabled, it will record nothing")            
        else:
            logging.error(f"{self.config['iq_logger_link_side']} unrecognized input for field 'iq_logger_link_side', IQ recorder will be disabled for this pass")
            self.iq_logger_link_side = 'na'
            self.record_iq = False
            
        # Configure Trace/ Channel Power Logger for uplink or downlink freq selection
        if (self.config["trace_logger_link_side"] in ["uplink", "u", "up"]) and self.record_trace:
            if self.has_uplink:
                logging.warning("Trace Logger will record uplink")
                self.trace_logger_link_side = 'uplink'
                subprocess.run(["rf_loopback", "-tx"])
            elif (not self.has_uplink) and self.has_downlink:
                logging.warning("Link does not have Uplink, but does have downlink. Trace Logger will record downlink instead")
                self.trace_logger_link_side = 'downlink'
                subprocess.run(["rf_loopback", "-rx"])
            else:
                logging.warning("Link does not have Uplink. Will not record Trace/Chan Power")                                                
                self.record_trace = False                
        elif (self.config["trace_logger_link_side"] in ["downlink", "d", "down"]) and self.record_trace:
            if self.has_downlink:
                logging.warning("Trace Logger record downlink")
                self.trace_logger_link_side = 'downlink'
            elif not self.has_downlink:
                logging.warning("Link does not have Downlink. Will not record Trace/Chan Power")                                                                
                self.record_trace = False             
        elif self.config["trace_logger_link_side"] is None and self.record_trace:
            logging.warning("Trace Logger will record nothing")
            self.trace_logger_link_side = 'na'
            self.record_trace = False     
        elif not self.record_trace:
            logging.warning("Trace Logger disabled, it will record nothing")
            self.trace_logger_link_side = 'na'
        else:
            logging.error(f"{self.config['iq_logger_link_side']} unrecognized input for field 'iq_logger_link_side', Trace Logger will be disabled for this pass")
            self.trace_logger_link_side = 'na'
            self.record_trace = False            
                        
        if self.satid not in self.tle_db.keys():
            logging.error("Sat ID {} not found in TLE dB".format(self.satid))            
            
        return downlink_params, uplink_fc
    
    def _sigHandler(self, signum, frame):
        self.cancel_event.set()
        
    def terminate_pass(self):
        if self.runtime_context is not None:
            self.physical_state = "indeterminate" if self._motion_started else "unobserved"
            return
        if (self.record_iq):
            self.iq_rec_client.stop()
        if (self.record_trace):
            self.trace_logger_client.abort()
        if (self.has_pdu):
            from cyberpowerpdu.utils import OutletState
            logging.info("Turning off Warning Lights & HPA")
            self.pdu_switch.set_warning_lights(OutletState.OFF, check_outcome=True)
            self.pdu_switch.set_hpa(OutletState.OFF, check_outcome=True)
        if (not self.nofrontend):
            logging.info("Disabling RF Paths")
            self.front_end.disconnect_rx()
            self.front_end.disconnect_tx()
        if not self.nofrontend:
            from telnetlib3.sync import TelnetConnection
            try:
                logging.info("Attempting to turn off the SIP TX Source ...")
                with TelnetConnection("192.168.0.79", 5025, connect_timeout=5) as conn:
                    conn.write("OUTP?\r\n")
                    reply = conn.readline()
                    logging.info("Signal Generator - Initial RF State: {} ... (0/OFF, 1/ON)".format(reply.strip('\n')))
                    if reply.strip("\n") == "1":
                        logging.info("Turning off the Signal Generator RF... ")
                        conn.write("OUTP OFF\r\n")
                        conn.write("OUTP?\r\n")
                        reply = conn.readline()
                        logging.info("Signal Generator - Final RF State: {} ... (0/OFF, 1/ON)".format(reply.strip('\n')))
                    else:
                        logging.info("SIP TX Source is off already ...")
            except OSError as e:
                logging.error(f"Telnet target unreachable: {e} Is the SIP TX Source reachable? ... Unable to shutdown SIP TX source")
            except ConnectionError as e:
                logging.error(f"Connection error: {e} Is the SIP TX Source reachable? ... Unable to shutdown the SIP TX source")
            except TimeoutError as e:
                logging.error(f"Connection timeout: {e} Check your connection to the SIP TX source ... Unable to shutdown the SIP TX source")
        self.ptu_client.park_ptu()

    def shutdown(self):
        if self.runtime_context is not None:
            self._release_resources()
            return
        if getattr(self, '_legacy_shutdown_done', False):
            return
        self._legacy_shutdown_done = True
        if self.exit_attempts > 5:
            logging.error("Multiple exit attempts have been attempted.... Quitting")
            exit()

        self.exit_attempts = self.exit_attempts + 1 

        # Signal sat_pos_thread to exit cleanly
        self.sat_pos_thread_signal.set()

        if (hasattr(self, 'pixhawk')):
            logging.info("Closing Pixhawk")
            self.pixhawk.clean_exit()

        if (hasattr(self, 'iq_rec_client')):
            logging.info("Closing Signal Hound Client -- IQ Recorder")   
            self.iq_rec_client.stop()
            if self.log_dir.exists():
                logging.warning("IQ File saved to {}".format(self.log_dir))
            else:
                logging.warning("{} is empty. Did not make recording... meteor issue.".format(self.log_dir)) 
                
        if (hasattr(self, 'trace_logger_client')):
            logging.info("Stopping Signal Hound Client -- Trace Logger")
            self.trace_logger_client.abort(timeout=0)
            self.trace_logger_client.clean_exit()
            
        if (hasattr(self, 'front_end')):
            logging.info("Closing front end log")
            self.front_end.shutdown()                
            
        if (self.has_pdu):
            logging.info("Closing PDU Client")         
            self.pdu_switch.shutdown()                             
            
        if (hasattr(self, 'ptu_client')):
            logging.info("Closing PTU Client")                        
            self.ptu_client.clean_exit()

        with open(self.log_dir / "tle.txt", "w+") as file:
            curr_tle = tle_from_dict(self.tle_db[self.satid])
            file.write('{},{}'.format(self.tle_db[self.satid]['tle'], self.tle_db[self.satid]['date']))

        if (hasattr(self, 'ptu_client')):
            logging.warning("Final Park Status {}".format(self.ptu_client.parked()))        


    def get_sat_pos(self, time:datetime)-> tuple:
        """
        Given the ground station (observer) lat, long, alt, determine where
        the sat of interest is. Returns a tuple for azimuth, elevation of the sat/object
        """
        self.ground_station.date = (time)
        self.iss.compute(self.ground_station)
        azimuth = self.iss.az*180/np.pi
        elevation = self.iss.alt*180/np.pi
        return (azimuth, elevation)   


    def get_status_str(self, sat_az=None, sat_el=None, 
                       display_sat:bool=True,
                       display_pix:bool=True,
                       display_ptu:bool=True) -> str:
        if self.runtime_context is not None:
            return (f"Selected PTU {self.runtime_context.ptu.manager_id}; "
                    f"Pixhawk {self.runtime_context.pixhawk.manager_id}; "
                    "navigation health and physical completion unverified")
        
        if sat_az is None:
            display_sat = False
        if self.nopixhawk:
            display_pix=False
        if self.noptu:
            display_ptu=False
        info_str = ""
        if display_sat:
            sat_str         = "{:<8}: Az: {:5.1f} El: {:3.1f}\n".format('Sat.',sat_az, sat_el)        
            info_str += sat_str 
        if display_pix:
            pix_strs = {}
            for pix_id in self.pixhawk.pix_ids:
                gps_yaw = (self.pixhawk.pix_status[pix_id].gpsYaw/100)
                if np.floor(gps_yaw)==655:
                    # If 655, RTK heading is not valid... pixhawk heading basically garbage
                    # bad RTK could be poor GPS SNR, poor surveying of antenna locations.... 
                    fused_hdg = np.nan
                else:
                    fused_hdg = (self.pixhawk.pix_status[pix_id].hdg/100)%360                    
                pix_strs[pix_id]     = "{:<8}  Az: {:6.1f} El: {:4.1f} | GPS STATUS {}\n".format(
                    "PX ID:{}".format(pix_id ),
                    fused_hdg, self.pixhawk.pix_status[pix_id].pitch*180/np.pi, 
                    self.pixhawk.pix_status[pix_id].gpsStatus 
                )
                pix_ptu_id = self.pixhawk.pix_dict[pix_id]["ptu_id"]
                if not (pix_ptu_id in self.ptu_client.ptu_ids):
                    info_str += pix_strs[pix_id]
                        
        if display_ptu:
            for ptu_id in self.ptu_client.ptu_ids:
                ptu_str     = "{:<8}  Az: {:6.1f} El: {:4.1f} || P: {:6.1f} T: {:5.1f}".format(
                    self.ptu_client.ptu_dict[ptu_id]['name'],
                    self.ptu_client.ptu_status[ptu_id].azimuth % 360, self.ptu_client.ptu_status[ptu_id].elevation, 
                    self.ptu_client.ptu_status[ptu_id].pan, self.ptu_client.ptu_status[ptu_id].tilt)
                if self.ptu_client.ptu_status[ptu_id].command is not None :
                    ptu_str += " || CMD Az: {:6.1f} El: {:4.1f} || {}\n".format(self.ptu_client.ptu_status[ptu_id].command.azimuth, self.ptu_client.ptu_status[ptu_id].command.elevation, self.ptu_client.ptu_status[ptu_id].state)
                else:
                    ptu_str += " || {}\n".format(self.ptu_client.ptu_status[ptu_id].state)
                ptu_pix_id = self.ptu_client.ptu_dict[ptu_id]["pix_id"]
                if display_pix and (ptu_pix_id in self.pixhawk.pix_ids):
                    ptu_str += pix_strs[ptu_pix_id]

                info_str += ptu_str                
                                
        return info_str

    def wait_until_primed(self, timeout=30):
        wait_start = time.monotonic()
        while True:
            self._check_running()
            self._check_manager_outcome()
            primed = self.ptu_client.ptu_is_primed
            if self.runtime_context is not None:
                expected = self.runtime_context.ptu.manager_id
                if set(primed) != {expected}:
                    raise RuntimeFailure(5, "Pointing readiness does not match the selected instance.")
            if primed and all(value is True for value in primed.values()):
                break
            if time.monotonic() - wait_start >= timeout:
                raise RuntimeFailure(5, "PTU prime timed out; execution was not enabled.", category="prime-timeout")
            self.cancel_event.wait(min(1, max(0, timeout)))
        self._check_running()
        if (not self.nofrontend):
            logging.info("Enabling RF Paths")
            self._check_running()
            self.front_end.configure_rx(frequency=self.downlink_rf_fc)
            if self.has_uplink:
                self._check_running()
                self.front_end.configure_tx(frequency=self.uplink_fc, work_modem_tx_source=self.work_modem_tx_source) 
        if (self.has_pdu) and (self.has_uplink):
            from cyberpowerpdu.utils import OutletState
            logging.info("Turning on HPA")                                            
            self._check_running()
            self.pdu_switch.set_hpa(OutletState.ON, check_outcome=True)       
        if self.add_errors:
            self._check_running()
            self.ptu_client.send_pointing_error_profile()                    


    def main(self):
        if self._closed or getattr(self, '_execution_started', False):
            return 8 if self.physical_state == "indeterminate" else 5
        self._execution_started = True
        code = 0
        try:
            self._check_running()
            self._run_pass_loop()
            self._check_running()
            if self.runtime_context is not None and self._motion_started:
                code = 8
        except RuntimeFailure as error:
            code = error.code
            self.primary_failure = _failure_category(code, error.category)
        except Exception:
            code = 5
            self.primary_failure = "execution-failure"
        finally:
            if self.runtime_context is not None:
                self.shutdown()
                self._observe_manager_outcome()
            else:
                try:
                    self.shutdown()
                except Exception:
                    self.cleanup_errors.append("legacy-client-release")
                self._release_resources()
        if code in (0, 8) and self._worker_error is not None:
            code = 6
            self.primary_failure = "truth-logging"
        if code in (0, 8) and self._logging_failed.is_set():
            code = 6
            self.primary_failure = "owned-logging"
        if code in (0, 8) and self.cleanup_errors:
            code = 7
            self.primary_failure = "cleanup"
        if self.runtime_context is not None:
            outcome = self.manager_outcome
            print(f"Manager software_state={outcome.state if outcome else 'unobserved'}; "
                  f"category={outcome.category if outcome else 'unobserved'}; "
                  f"operation={outcome.operation if outcome else 0}; "
                  f"sequence={outcome.sequence if outcome else 0}; "
                  f"submitted={outcome.submitted if outcome else 0}; "
                  f"total_submitted={outcome.total_submitted if outcome else 0}; "
                  f"possible_submission={outcome.possible_submission if outcome else False}; "
                  f"exchange_submission={outcome.submission if outcome else 'none'}; "
                  f"local_failure={self.manager_local_failure or 'none'}")
            print(f"Pointing result={code}; physical_state={self.physical_state}; "
                  f"cleanup_errors={len(self.cleanup_errors)}; worker_error={self._worker_error is not None}; "
                  f"primary_failure={self.primary_failure or 'none'}; "
                  f"logging_failure={self.logging_failure or 'none'}; "
                  f"cleanup_categories={','.join(self.cleanup_errors) or 'none'}")
        return code

    def _run_pass_loop(self):
        '''
        Main loop for tracking satellites. Runs at about 1 Hz

        Predicts the satellite location one minute from now. If it's valid, primes the PTU by pointing it in that direction.
        Once primed, tracks the satellite until the pass is over.

        Parks the PTU when the pass is over.
        
        State Machine 
        
        Start:
            - If SV below -> Wait
            - SV above -> go to Track
        Wait:
            - if sv in t+1 min below -> wait
            - if sv in t+ 1 min above -> Prime
        Prime: 
            - if sv below -> Primed
            - if SV above -> track
        Track:
            - if sv above -> Point
            - sv below -> End parked
        Parked
        '''
        self.state = "start"
        if self.has_pdu:
            from cyberpowerpdu.utils import OutletState
        utc_now = datetime.now(timezone.utc)
        toggled_hpa_zenith_off = False
        toggled_hpa_zenith_on = False
        while self.state != "end":
            self._check_running()
            self._check_manager_outcome()
            utc_now = datetime.now(timezone.utc)
            
            if utc_now > self.absolute_end_time:
                raise RuntimeFailure(5, "Pass exceeded its resolved end window; physical state is unverified.", category="drop-dead")

            if self.state == "start":
                # Parked. Try to prime
                logging.warning("Starting Pass Procedure")    
                self._ptu_command("load_tle", self.tle_db[self.satid]['tle'])
                
                # Start Logging Pixhawk Data
                if (not self.nopixhawk):
                    self._check_running()
                    if self.runtime_context is None:
                        self.pixhawk.start_logging()
                    else:
                        self.pixhawk.start_logging(deadline=self._deadline(), cancel=self.cancel_event)
                    
                # Turn on warning lights before HPA
                if (self.has_pdu) and (self.has_uplink):
                    logging.warning("Turning on Warning Lights")
                    self._check_running()
                    self.pdu_switch.set_warning_lights(OutletState.ON, check_outcome=True)                    

                # Check Satellite Position 1min from now, if above elv mask... prime dishes and paths   
                azimuth, elevation = self.get_sat_pos(utc_now + _PRIME_LOOKAHEAD)
                if (elevation >= self.el_mask if self.runtime_context is not None
                        else self.ptu_client.validateCoordinates(azimuth, elevation)):
                    info_str = self.get_status_str()                    
                    logging.warning("Priming Satellite Dish, Start -> Primed \n{}".format(info_str))   
                    self._ptu_command("prime", azimuth, elevation)
                    self.wait_until_primed()                                                                                                                                
                    self.state = "primed"                    
                else:
                    self.state = "waiting"     
                    info_str = self.get_status_str()                                                                           
                    logging.info("Waiting for Satellite to rise above horizon, Start -> Waiting \n{}".format(info_str))                    
                
            elif self.state == "waiting":
                future_az, future_el = self.get_sat_pos(utc_now + _PRIME_LOOKAHEAD)
                if (future_el >= self.el_mask if self.runtime_context is not None
                        else self.ptu_client.validateCoordinates(future_az, future_el)):
                    logging.warning("Satellite Rising in 1 min. Priming Satellite Dish, Waiting -> Primed") 
                    self._ptu_command("prime", future_az, future_el)
                    self.wait_until_primed()                                                                 
                    self.state = "primed"                    
                else:
                    self.state = "waiting"      
                    info_str = self.get_status_str()                                  
                    logging.info("Waiting for Satellite (+1m {:.1f} az {:.1f} el) to rise above horizon ({:.1f}), Waiting -> Waiting \n{}".format(future_az, future_el, self.ptu_client.elevation_mask, info_str))    
                    time.sleep(1)               
                
            elif self.state == "primed":
                azimuth, elevation = self.get_sat_pos( utc_now ) 
                if (elevation >= self.el_mask if self.runtime_context is not None
                        else self.ptu_client.validateCoordinates(azimuth, elevation)):
                    logging.warning("Pass Started, Primed -> Tracking")
                    self.state = "tracking"
                    if (self.record_iq):
                        self._check_running()
                        self.iq_rec_client.start()
                    if (self.record_trace):
                        self._check_running()
                        self.trace_logger_client.start(duration=int(self.duration+60), ch_bw_mhz=self.trace_logger_ch_bw)                      
                    self.recording_start_time = datetime.now(timezone.utc)
                    
                else:
                    info_str = self.get_status_str()                                  
                    logging.info("Primed, waiting for Satellite ({:.1f} az {:.2f} el) to rise above horizon ({:.1f}), Primed -> Primed \n{}".format(azimuth, elevation, self.ptu_client.elevation_mask, info_str))                    
                    self.state = "primed"
                    time.sleep(1)           
                
            elif self.state == "tracking":
                if self.runtime_context is not None:
                    if (utc_now - self.recording_start_time).total_seconds() >= self.duration:
                        self._ptu_command("complete_tracking")
                        self.terminate_pass()
                        self.state = "parking"
                    else:
                        outcome = self._ptu_command("track")
                        if outcome.state == "complete":
                            self.terminate_pass()
                            self.state = "parking"
                        else:
                            self.cancel_event.wait(DEFAULTS.tracking_update_rate)
                    continue
                sat_az, sat_el = self.get_sat_pos( utc_now )      
                if (self.ptu_client.validateCoordinates(sat_az, sat_el)) & \
                    ( (utc_now - self.recording_start_time).total_seconds() < self.duration ):                                        
                    # actual_az, actual_el = self.ptu_client.ptuMoveTo(command_az, command_el)                    
                    status_str = self.get_status_str(sat_az, sat_el)
                    logging.info("Tracking Sat ID {} \n{}".format(self.satid, status_str))                    
                    # if (self.current_pass_info.max_elv>30) and (not self.current_pass_info.is_circumpolar) and (self.has_pdu) and (not self.no_uplink):
                    #     if (utc_now>self.current_pass_zenith_time-timedelta(seconds=30)) and (not toggled_hpa_zenith_off):
                    #         logging.warning("Within 30 seconds of zenith... Toggling HPA OFF")
                    #         self.pdu_switch.set_hpa(OutletState.OFF, check_outcome=True)  
                    #         toggled_hpa_zenith_off  =True
                    #     if (utc_now>self.current_pass_zenith_time+timedelta(seconds=30)) and (not toggled_hpa_zenith_on):
                    #         logging.warning("30 seconds after Zenith... Toggling HPA Back ON")
                    #         self.pdu_switch.set_hpa(OutletState.ON, check_outcome=True)                              
                    #         toggled_hpa_zenith_on  =True                                                            
                    time.sleep(DEFAULTS.tracking_update_rate)
                elif not (self.ptu_client.validateCoordinates(sat_az, sat_el)):                
                    logging.warning("Pass over, SV passed below horizon. Tracking -> Ending")
                    self.state = "parking"
                    self.terminate_pass()
                elif ( (utc_now - self.recording_start_time).total_seconds() >= self.duration ):
                    logging.warning("Pass duration exceeded, Tracking -> Ending")
                    self.terminate_pass()                              
                    self.state = "parking"
                
            elif self.state == "parking":
                logging.warning("Software pass ending; physical completion is not established")
                logging.warning("Pass over. Stopping Logs")
                
                self.shutdown()                    
                self.state = "finished"
            
            elif self.state == "finished":                
                self.state="end"
                

def main(argv=None):
    parser = argparse.ArgumentParser(allow_abbrev=False, description = 'Logger for METEOR and the PixHawk for the Cubesat Mission')
    parser.add_argument('-config', default = 'config/config.yaml', type=str, 
                        help = 'Config File, default: config/config.yaml')   
    parser.add_argument('-sf', '--satfile', default = str(default_sat_db), 
                        type=str, help = 'Path to YAML file containing satellite info, default: {}'.format(str(default_sat_db)))
    parser.add_argument('-tf', '--txidfile', default = '~/ground_station/config/signal_ids_db.csv', 
                        type=str, help = 'Path to csv file with signal id designators, default: ~/ground_station/config/signal_ids_db.csv')
        
    parser.add_argument('-id', '--satid', default = 32501, type=int, help ='Satellite ID')  
    parser.add_argument('-ulid', '--uplink-id', required = False, type=str, help ='Uplink Emission ID')          
    parser.add_argument('-ulfc', type = float, required = False, 
                        help = ('(MHz) Uplink Center Frequency') )    
    
    parser.add_argument('-dlid', '--downlink-id', required = False, type=str, help ='Downlink Emission ID')          
    parser.add_argument('-dlfc', type = float, required = False, 
                        help = ('(MHz) Downlink Center Frequency .,'\
                            'only required if no emission id is specified') )
    parser.add_argument('-dlfs', type = float, required = False, 
                        help = ('(Msps) Sample Rate,'\
                            'only required if running meteor and no downlink ID is provided. Sample rate not guaranteed and E320 may adjust it.') )
    parser.add_argument('-g', '--gain', type = float, required = False, default=None, 
                        help = 'dB, Ettus Gain, defaults to 60.. ')            
    
    parser.add_argument('-elmask', default = DEFAULTS.elev_mask, type=int, 
                        help = 'Elevation Mask (degrees), default 20 degrees') 
    parser.add_argument('-d','--duration', default = 0, type = float, required = False, 
                        help = 'Duration of Recording. 0 = infinite')
    parser.add_argument('--error-profile', type = str, required = False, 
                        help = '', 
                        default = None)
    parser.add_argument('-pass-id', type = int, required=False, default=-1, help="Give Pass ID label to a scheduled job")
    parser.add_argument('-sip-src', action = 'store_true', default = False,
                        help="If specified, TX Source will be from the SIP not work Modem, defualts to False (Uses Work modem as Default Source)")
    parser.add_argument('-nd','--nodate', action = 'store_true', default = False,
                        help="If specified, there will be no date append to the log name") # Dont add date to file names
    parser.add_argument('-nid','--noid', action = 'store_true', default = False, 
                        help="If specified, there will be no sat id append to the log name") 
    
    parser.add_argument("-l","--log", default="info", help=("Provide logging level. "
        "Example --log debug or -l i', default='warning'"))     
    parser.add_argument('-rec-iq', action = 'store_true', default = False, help= "flag for running with IQ Recorder HW, Defaults to False")
    parser.add_argument('-npx','--nopixhawk', action = 'store_true', default = False, help= "flag for running with no pixhawk HW, useful for testing")
    parser.add_argument('-nfe','--nofrontend', action = 'store_true', default = False, help= "flag for running with no DSI instruments, useful for testing")
    parser.add_argument('-nptu','--noptu', action = 'store_true', default = False, help= "flag for running with no PTU HW, useful for testing")
    parser.add_argument('-npdu','--nopdu', action = 'store_true', default = False, help= "flag for running with no PDU HW, useful for testing")

    parser.add_argument('--operation', choices=('pointing',))
    parser.add_argument('--deployment-config')
    parser.add_argument('--runtime-bindings')
    arguments = list(sys.argv[1:] if argv is None else argv)
    for option in ('--operation', '--deployment-config', '--runtime-bindings'):
        if sum(value.split('=', 1)[0] == option for value in arguments) > 1:
            print("Each explicit runtime option must occur once.", file=sys.stderr)
            return 2
    args = parser.parse_args(arguments)
    phase = 2
    try:
        conflicts = [name for name, value in (
            ('uplink-id', args.uplink_id), ('ulfc', args.ulfc),
            ('downlink-id', args.downlink_id), ('dlfc', args.dlfc),
            ('dlfs', args.dlfs), ('gain', args.gain), ('error-profile', args.error_profile),
        ) if value is not None]
        conflicts.extend(name for name, value in (
            ('record-iq', args.rec_iq), ('sip-source', args.sip_src),
            ('noptu', args.noptu), ('nopixhawk', args.nopixhawk),
        ) if value)
        if args.log not in {'critical', 'c', 'error', 'e', 'warning', 'warn', 'w', 'info', 'i', 'debug', 'd'}:
            raise RuntimeConfigurationError("Unsupported logging level.")
        context = resolve_runtime_request(operation=args.operation,
            deployment_config=args.deployment_config, runtime_bindings=args.runtime_bindings,
            station_config=args.config, sat_file=args.satfile, sat_id=args.satid,
            duration=args.duration, elevation=args.elmask, conflicts=conflicts)
        if context is None:
            with open(args.config) as stream:
                settings = yaml.safe_load(stream)
        else:
            settings = context.station
        file_prefix = (DEFAULTS.file_prefix if context is not None and args.pass_id == -1
                       else determine_file_prefix(args.pass_id, settings["file_prefix_source"]))
        log_level = {'critical': 50, 'c': 50, 'error': 40, 'e': 40,
                     'warning': 30, 'warn': 30, 'w': 30, 'info': 20, 'i': 20,
                     'debug': 10, 'd': 10}[args.log]
        phase = 4
        tracker = PassRunner(config_file=args.config, sat_file=args.satfile,
            tx_id_file=args.txidfile, sat_id=args.satid,
            uplink_id=args.uplink_id, ulfc=args.ulfc,
            downlink_id=args.downlink_id, dlfc=args.dlfc, down_fs=args.dlfs,
            gain_db=args.gain, file_prefix=file_prefix,
            elv_mask=args.elmask, duration=args.duration, error_profile=args.error_profile,
            nodate=args.nodate, noid=args.noid, record_iq=args.rec_iq,
            nopixhawk=args.nopixhawk, noptu=args.noptu,
            nofrontend=args.nofrontend, nopdu=args.nopdu,
            work_modem_tx_source=not args.sip_src, runtime_context=context, log_level=log_level)
        return tracker.main()
    except RuntimeConfigurationError:
        print("Runtime inputs are invalid or unsupported; no fallback was selected.", file=sys.stderr)
        return 2
    except RuntimeFailure as error:
        if error.manager_outcome is not None:
            outcome = error.manager_outcome
            print(f"Manager acquisition_category={outcome.category}; operation={outcome.operation}; "
                  f"sequence={outcome.sequence}; total_submitted={outcome.total_submitted}; "
                  f"possible_submission={outcome.possible_submission}; "
                  f"local_failure={error.manager_local_failure or 'none'}", file=sys.stderr)
        print(f"Runtime failure: {_failure_category(error.code, error.category)}; "
              "physical state is unverified.", file=sys.stderr)
        return error.code
    except Exception:
        print("Runtime preflight or acquisition failed; physical state is unverified.", file=sys.stderr)
        return phase


if __name__ == '__main__':
    raise SystemExit(main())
