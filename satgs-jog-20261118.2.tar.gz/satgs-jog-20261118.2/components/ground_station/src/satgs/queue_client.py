import sys
import csv
import time
import signal
import subprocess
import ephem
import yaml
import pandas as pd
import argparse
import logging
from pathlib import Path
from typing import Union
from ephem import degree as deg2rad
from datetime import datetime, timedelta, timezone

from meteor_api.messenger import Messenger
from satgs.constants import Topics, time_format_print, DEFAULTS, time_format_tzone
from satgs.utils import (Job, 
                         JobRequest, 
                         PassInfo, 
                         update_tle_db, 
                         TLE, 
                         tle_from_str,
                         find_passes,
                         pb_to_job_request,
                         queue_pb_to_queue,
                         find_closest_pass)
from satgs import jobs_msg_pb2

logger = logging.getLogger(__name__)
default_cfg = Path('~/ground_station/config/config.yaml').expanduser()


class QueueClient:
    def __init__(self, 
                 messenger:Messenger, 
                 sat_file:Path, 
                 tx_id_file:Path,
                 config_file:Path, 
                 use_local_tzone:bool=False,
                 skip_db_update:bool=False) -> None:
        
        self.messenger = messenger
        self.config_file = config_file

        # Load config File
        with open(config_file) as f:
            self.config = yaml.safe_load(f)           
        self.sat_file = sat_file
        self.tx_id_file = tx_id_file
        
        self.use_local_tzone = use_local_tzone
        
        self.ground_station = ephem.Observer()
        self.ground_station.date = datetime.now(timezone.utc)        
        self.ground_station.lat = self.config['ground_station_lat'] * deg2rad
        self.ground_station.lon = self.config['ground_station_lon'] * deg2rad
        self.ground_station.elevation = self.config['ground_station_altm']        

        tle_df = pd.read_csv(sat_file) 
        em_id_df = pd.read_csv(tx_id_file)
        self.em_id_db = em_id_df.set_index('txid').to_dict("index")    
                   
        if not skip_db_update:
            self.tle_db = tle_df.set_index('norad_id').to_dict("index")
            logger.info("Checking TLEs, updating if necessary")            
            self.tle_db, db_updated = update_tle_db(self.tle_db)
            if db_updated:
                updated_df = pd.DataFrame(self.tle_db).transpose().reset_index().rename(columns={'index':'norad_id'})
                updated_df.to_csv(sat_file, index=False)
            logger.info("TLEs up to date")            

        self.job_queue = []
        
        self.messenger.subscribe(Topics.QUEUE_STATUS, self.queue_status_cb, "")
        self.messenger.subscribe(Topics.PONG_RESPONSE, self.pongCmdCb, "")
        self.messenger.subscribe(Topics.JOB_REPLY_MSG, self.job_reply_cb, "")
                
        self.qm_state = ""
        logger.info("Client setup complete")
        
    def check_connection(self, timeout:int=5)->bool:
        """Sends a ping to the manager service/python process. Returns True if 
        it gets a response, False otherwise. Waits 5 seconds for response

        Args:
            timeout (int, optional):  Defaults to 5.

        Returns:
            bool: True is gets response from manager service/ python process
        """        
        logging.info("Pinging HW Manager, will wait {} seconds for response".format(timeout))      
        self.publish_wrapper(Topics.PING_CMD, jobs_msg_pb2.PingCmd(ping=True))
        self.got_pong = False
        start_time = time.time()
        while not self.got_pong:
            if time.time()-start_time>timeout:
                logging.warning("Did not get response in alloted time. Could be issue with activemq, or sat_tracker.service on server side")
                return False
            if self.no_hw_mode:
                logging.info("Client ready. Running in no HW mode")                
                return True       
        return True
    
    def pongCmdCb(self, msg:str, id:int):
        """Call back for when Pong is received from manager service/ python process
        """             
        pong_msg = jobs_msg_pb2.QueuePong()
        pong_msg.ParseFromString(msg)         
        logging.info("Pong Received from host {}".format(pong_msg.host_info))  
        self.got_pong = True   
        
    def job_reply_cb(self, msg:str, id:int):
        logger.info("Job reply received!")
        job_reply_msg = jobs_msg_pb2.AddJobReplyMsg()
        job_reply_msg.ParseFromString(msg)
        if not job_reply_msg.success:
            logger.error("ERROR: {}".format(job_reply_msg. msg))
            sat_tle = tle_from_str(job_reply_msg.tle_str)
            self.tle_db.update(sat_tle.to_dict())
            updated_df = pd.DataFrame(self.tle_db).transpose().reset_index().rename(columns={'index':'norad_id'})
            updated_df.to_csv(self.sat_file, index=False)            
            logger.info("Updated local TLE dB")
            # Only setting here, because if job is succesful it replies with a queue 
            # response which will set this bool to TRUE
            # Maybe we re-assess this later
            self.got_queue_response=True

                    
    def add_pass(self, 
                 sat_id: int, 
                 job_start: Union[datetime, int]= 0, 
                 pass_number:int=-1,
                 downlink_id:str='', 
                 dl_fc_mhz:float=0, 
                 dl_bw_mhz:float=0,
                 uplink_id:str='', 
                 ul_fc_mhz:float=0,                
                 duration:int=0, 
                 priority:bool=False,
                 apply_error_profile:bool=False,
                 work_modem_tx_source:bool=True,
                 elv_mask:float=DEFAULTS.elev_mask, 
                 span_days:float=None,
                 pass_id:int=-1,
                )->None:
        
        # Need to do multiple checks on the import args before we send the 
        # request to the manager... This makes keeping track of jobs easier later
        if sat_id not in self.tle_db.keys():
            logger.error("Error sat id {} not found in TLE dB".format(sat_id))
            return        
        if (job_start==0) and (pass_number<0):
            logger.error("Input Arg Error, must specify EITHER a upcoming pass number or explicit start time")
            return
        if (job_start!=0) and (pass_number>=0):
            logger.error("Input Arg Error, Can't specify a pass number and an explicit start time. Needs to be one or the other")
            return
        pass_has_downlink = False
        pass_has_uplink = False
        if (downlink_id!='') or (dl_fc_mhz!=0):
            pass_has_downlink = True
        if (uplink_id!='') or (ul_fc_mhz!=0):
            pass_has_uplink = True
        if (not pass_has_downlink) and (not pass_has_uplink):
            logger.error("Input Arg Error, Pass needs to have an Downlink OR Uplink")
            return                   
        # if (downlink_id=='') and (dl_fc_mhz==0 ):
        #     logger.error("Input Arg Error, Need to specify Downlink ID or Fc ")
        #     return            
        if (downlink_id!='') and (dl_fc_mhz!=0 ):
            logger.error("Input Arg Error, Have to input Downlink ID OR Fc, can't do both")
            return
        
        if (uplink_id!='') and (ul_fc_mhz!=0):
            logger.error("Input Arg Error, Have to input Downlink ID OR Fc, can't do both")
            return        
        
        if span_days is None:
            span_days = DEFAULTS.pass_finder_span
        
        if pass_id != -1:
            if not isinstance(pass_id, int):
                logging.error("Input Arg Error, Pass-id must be of type int, received a: {type(pass_id)}")

        upcoming_passes = find_passes(sat_id, self.tle_db, self.ground_station, 
                                      elv_mask, span_days*24)
        sat_name = self.tle_db[sat_id]['name']
        # Check if circumpolar:
        if upcoming_passes[0].is_circumpolar:
            if duration==0:
                logger.error("Error, Satellite is Geostationary, need to specify a duration")
                return 
            if (pass_number>=0) and (job_start==0):
                logger.warning("Warning, User specified an upcoming pass number " \
                    "but Satellite is geostationary. You Should explicitly set "\
                    "a start time. Setting Start time to 60 seconds from now")
                job_start = datetime.now(timezone.utc) + timedelta(seconds=60)            
            pass_info = upcoming_passes[0]
        # Provided an explicit Job Start time
        elif (job_start!=0): 
            # Check that explicit start time roughly lines up with satellite pass
            matching_pass = [sat_pass 
                             for sat_pass in upcoming_passes 
                             if ((job_start>=sat_pass.sat_rise_time) and (job_start<sat_pass.sat_set_time)) ]
            if len(matching_pass)>0:
                logger.warning("Attention: Jobs starts after satellite rises")
                if duration==0:
                    duration = (matching_pass[0].sat_set_time - job_start).total_seconds()
                    logger.info("Setting Pass duration to {:.1f} seconds".format(duration))
                pass_info = matching_pass[0]              
            else:
                start_deltas = [(sat_pass.sat_rise_time-job_start).total_seconds() 
                                for sat_pass in upcoming_passes 
                                if (sat_pass.sat_rise_time-job_start).total_seconds()>0]
                next_passes = [sat_pass for sat_pass in upcoming_passes 
                               if (sat_pass.sat_rise_time-job_start).total_seconds()>0]
                next_pass_delta = min(start_deltas)
                pass_info = next_passes[start_deltas.index(next_pass_delta)]                
                next_pass_time = next_passes[start_deltas.index(next_pass_delta)].sat_rise_time
                logger.warning("Warning Next pass does not start until {}, {:.0f} min after job start".format(next_pass_time.strftime(time_format_print), next_pass_delta/60))
                if next_pass_delta>3600:
                    logger.error("Error: Job start cannot be greater than 1 hr from the rise of the satellite")
                    return                   
                if duration==0:
                    duration = (next_passes[start_deltas.index(next_pass_delta)].sat_set_time -next_passes[start_deltas.index(next_pass_delta)].sat_rise_time).total_seconds()                    
        elif(pass_number>0): 
            # Get the info of the next nth pass
            if pass_number>len(upcoming_passes):
                logger.error("Invalid pass number. Only {} passes in the next {} days. User requested the {} 'th' pass".format(len(upcoming_passes), span_days, pass_number))
                return
            pass_info = upcoming_passes[pass_number-1]  
        elif pass_number==0:
            logger.info("Pass number = 0. Checking if SV in view")
            if duration==0:
                logger.error("For SVs currently in view (n=0), we require specifying a duration, if SV drops before this, pass will be stopped")
                return            
            ref_time = datetime.now(timezone.utc)
            pass_info = find_closest_pass(sat_id, self.ground_station, self.tle_db, elv_mask,
                            ref_time,hrs_past=6,hrs_future=6)
            if (ref_time>pass_info.sat_rise_time) and (ref_time+timedelta(seconds=60)<pass_info.sat_set_time):
                job_start = datetime.now(timezone.utc) + timedelta(seconds=60)                                           
            else:
                logger.error("Satellite is not in view. Exiting.... ")
                return                                    
        else:
            print("I missed a condition")
        
        sat_tle = TLE(name = self.tle_db[sat_id]["name"], 
                      tle_str = self.tle_db[sat_id]["tle"],
                      t_ref = datetime.strptime(self.tle_db[sat_id]["date"],time_format_tzone).replace(tzinfo=timezone.utc)
        )
        request = JobRequest(sat_id, 
                             sat_name, 
                             pass_number, 
                             job_start, 
                             downlink_id, 
                             dl_fc_mhz, 
                             dl_bw_mhz, 
                             uplink_id, 
                             ul_fc_mhz,
                             duration, 
                             priority, 
                             elv_mask,
                             pass_info,
                             sat_tle, 
                             apply_error_profile,
                             work_modem_tx_source,
                             pass_id
                            )
        job_request_msg = request.to_pb()
        logger.info("Adding Job: \n{}".format(request.get_str()))  
        self.got_queue_response=False
        self.publish_wrapper(Topics.ADD_JOB_CMD,
                            jobs_msg_pb2.AddJobCmdMsg(job_request=job_request_msg))
        self.wait_for_response()

    def wait_for_response(self, timeout=15):
        start_time = time.time()
        while not self.got_queue_response:
            if (time.time()-start_time)>timeout:
                logger.error("Did not get response in alloted time, check network, may not be connected to server")
                break   
                 
    def publish_wrapper(self, topic, msg):
        '''
        Catches exceptions from publish. Useful if the remote AMQ server restarts (or something like that). The Messenger object handles reconnecting.
        '''
        try:
            self.messenger.publish(topic, msg)
        except Exception as e:
            logging.info("Exception when sending message to Orin's ActiveMQ Broker.", exc_info = e)                     
                                
    def request_queue(self)->None:
        self.got_queue_response=False
        logger.info("Requesting Queue")
        self.publish_wrapper(Topics.GET_QUEUE_CMD,jobs_msg_pb2.GetQueueCmdMsg(get_queue=True) )        
        self.wait_for_response()

            
    def remove_job(self, job_id:int)->None:
        self.got_queue_response=False
        logger.info("Requesting to remove Job ID {}".format(job_id))
        self.publish_wrapper(Topics.DELETE_JOB_CMD, jobs_msg_pb2.DeleteJobCmdMsg(job_id=job_id))
        self.wait_for_response()
    
    def clear_queue(self)->None:
        self.got_queue_response=False
        logger.info("Requesting to clear queue")
        self.publish_wrapper(Topics.CLEAR_QUEUE_CMD, jobs_msg_pb2.ClearQueueCmdMsg(clear_all=True))
        self.wait_for_response()    
    
    def queue_status_cb(self, msg, id)-> None:
        logger.debug("Queue Update Received!")
        queue_status_msg = jobs_msg_pb2.QueueStatus()
        queue_status_msg.ParseFromString(msg)
        logger.info("Queue Update Received from {}!".format(queue_status_msg.hostname))
        
        # logger.info(queue_status_msg)
        self.job_queue = queue_pb_to_queue(queue_status_msg)
                
        pass_list = []
        for job_info in self.job_queue:
            pass_list.append(job_info.get_str(self.use_local_tzone))
        logger.info('Current Queue:\n' + '\n'.join(pass_list))
        self.got_queue_response=True

def setupClient(args, skip_db_update:bool=False):
    
    # format logger
    root_logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    logger.setLevel(logging.INFO)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)

    # Load config File
    with open(args.config) as f:
        config = yaml.safe_load(f)          
    sat_fpath = Path(config['sat_db_file']).expanduser()
    tx_id_fpath = Path(config['emission_id_db_file']).expanduser()
    
    credentials = {
                "username": config["amq_username"], 
                "password": config["amq_password"]}    
    messenger = Messenger(config['amq_server'], config['amq_port'], credentials, use_ssl=config['amq_use_ssl'])   
     
    if hasattr(args, "local"):
        use_local_tzone = args.local
    else:
        use_local_tzone = False        
        
    client = QueueClient(messenger=messenger, 
                         sat_file=sat_fpath, 
                         tx_id_file=tx_id_fpath, 
                         config_file=args.config,
                         use_local_tzone=use_local_tzone, 
                         skip_db_update=skip_db_update)
    return client      

#### Script Entry Points
def addJob():
    description = """
    Function for adding satellite passes to the Queue Manager, an application 
    that manages and schedules the execution of satellite passes. Passes are 
    scheduled by specifying when/ which pass to run, and which RF Frequency/ 
    Signal to process. If a duration is not specified, the duration will be 
    determined by the rise and set time of the satellite. Geostationary satellites
    require an explicit duration be specified. \n
    Passes can be scheduled two ways: 

        
    """
    parser = argparse.ArgumentParser(description = description, 
                                     formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('-sid','--svid', type=int, required=True,
                        help = 'Satellite NORAD ID')
    parser.add_argument('-e', '--elevationmask', type=float, required=False, default=DEFAULTS.elev_mask,
                        help = ' (deg) Elevation mask, default is {:.1f} degrees'.format(DEFAULTS.elev_mask))           
    parser.add_argument('-n','--passnumber', type=int, required=False, default=-1,
                        help = 'Nth pass number')    
    parser.add_argument('-t','--starttime', type=str, required=False, default='', 
                        help = 'date string yyyy-mm-dd-HH:MM:SS, Start time of the job.' )
    parser.add_argument('-dlid', '--downlink-id', type=str, required=False, default='',
                        help = 'string, the Emission ID of the downlink signal.')
    parser.add_argument('-dlfc', type=float, required=False, default=0,
                        help= 'float (MHz), Downlink RF Center frequency')
    parser.add_argument('-dlbw', type=float, required=False, default=0,
                        help= 'float (MHz), Downlink signal BW')
    parser.add_argument('-ulid', '--uplink-id', type=str, required=False, default='',
                        help = 'string, the Emission ID of the uplink signal.')
    parser.add_argument('-ulfc', type=float, required=False, default=0,
                        help= 'float (MHz), Uplink RF Center frequency')    
    parser.add_argument('-sip-src', action = 'store_true', default = False,
                        help="Flag. If specified TX Source will be from the SIP not work Modem, defualts to False (Uses Work modem as Default Source)") 
    parser.add_argument('-pass-id', type=int, required=False, default=-1, 
                        help= 'Pass-id assigned to a job')
    parser.add_argument('-d', '--duration', type=float, required=False, default=0,
                        help= 'float (seconds), Duration of the pass' )
    parser.add_argument('--span', type=float, required=False, default=None,
                        help= '(days), Number of days to look for passes over, defaults to value in the config.yaml file.' )    
    parser.add_argument('-p','--priority', action='store_true',
                        help= 'Priority flag')
    parser.add_argument('--apply-errors', action='store_true',
                        help= 'If flag specified, applies an error profile')    
    parser.add_argument('--local', action='store_true',
                        help= 'Priority flag')
    
    # Defaults                  
    parser.add_argument('-config', default = str(default_cfg), type=str, help = 'Config File')  
    args = parser.parse_args() 
      
    client = setupClient(args)
    
    # Input arg check.    
    if (args.starttime=='') and (args.passnumber<0):
        logger.error("Input Arg Error, must specify EITHER a upcoming pass number or a explicit start time")
        return
    if (args.starttime!='') and (args.passnumber>=0):
        logger.error("Input Arg Error, Can't specify a pass number and an explicit start time. Needs to be one or the other")
        return
    pass_has_downlink = False
    pass_has_uplink = False
    if (args.downlink_id!='') or (args.dlfc!=0):
        pass_has_downlink = True
    if (args.uplink_id!='') or (args.ulfc!=0):
        pass_has_uplink = True
    if (not pass_has_downlink) and (not pass_has_uplink):
        logger.error("Input Arg Error, Pass needs to have an Downlink OR Uplink")
        return             
    # if (args.downlink_id=='') and (args.dlfc==0 ):
    #     logger.error("Input Arg Error, Need to specify Downlink ID or Downlink Fc pair")
    #     return
                
    if (args.downlink_id!='') and (args.dlfc!=0 ):
        logger.error("Input Arg Error, Have to input Downlink ID OR Fc, can't input both. ")
        return   
             
    if (args.uplink_id!='') and (args.ulfc!=0 ):
        logger.error("Input Arg Error, Have to input Uplink ID OR Fc, can't do both. Uplinks are optional")
        return        

    if (args.starttime==''):
        job_start = 0
    else:
        job_start = datetime.strptime(args.starttime, '%Y-%m-%d-%H:%M:%S').replace(tzinfo=timezone.utc)

    client.add_pass(args.svid, 
                    job_start, 
                    args.passnumber, 
                    downlink_id=args.downlink_id, 
                    dl_fc_mhz=args.dlfc, 
                    dl_bw_mhz=args.dlbw,
                    uplink_id=args.uplink_id, 
                    ul_fc_mhz=args.ulfc,
                    duration=args.duration, 
                    priority=args.priority, 
                    apply_error_profile=args.apply_errors, 
                    elv_mask=args.elevationmask, 
                    span_days=args.span,
                    work_modem_tx_source=(not args.sip_src),
                    pass_id=args.pass_id)

def removeJob():
    description = """
    Function for removing satellite passes from the Queue Manager, an application 
    that manages and schedules the execution of satellite passes. Passes are 
    removed by specifying the specific job ID.         
    """
    parser = argparse.ArgumentParser(description = description)    
    parser.add_argument('-id','--jobid', type=int, required=True,
                        help = 'Job ID to remove')     

    # Defaults                  
    parser.add_argument('-config', default = str(default_cfg), type=str, help = 'Config File')  
    args = parser.parse_args() 
      
    client = setupClient(args,skip_db_update=True)    
    client.remove_job(args.jobid)
    
def clearQueue():
    description = """
    Function for all scheduled passes from the Queue Manager, an application 
    that manages and schedules the execution of satellite passes. No inputs are
    needed. 
    """
    parser = argparse.ArgumentParser(description = description)   
    # Defaults                  
    parser.add_argument('-config', default = str(default_cfg), type=str, help = 'Config File')   
    args = parser.parse_args() 
      
    client = setupClient(args, skip_db_update=True)
    client.clear_queue()

def requestQueue():
    description = """
    Function for retrieving the queue from the queue manager, an application 
    that manages and schedules the execution of satellite passes. No inputs are
    needed. 
    """   
    parser = argparse.ArgumentParser(description = description)   
    
    # Defaults                  
    parser.add_argument('-config', default = str(default_cfg), type=str, help = 'Config File')       
    parser.add_argument('--local', action='store_true',
                        help= 'Priority flag')         
    args = parser.parse_args() 
      
    client = setupClient(args, skip_db_update=True)   
    return client.request_queue()   

def addSchedule():
    description = """
    Function for adding a batch of jobs all at once, i.e., call add_pass over a 
    list of passes from csv file. Useful after using pass_finder --to_csv 
    """   
    parser = argparse.ArgumentParser(description = description)   
    
    parser.add_argument('-config', default = str(default_cfg), type=str, 
                        help = 'Config file')       
    parser.add_argument('--continue-id', action='store_true',
                        help = "Optional. Increment pass id from last pass id in the queue")
    parser.add_argument('--start-id', type=int, 
                        help = "Optional. Start schedule from given start id, non-inclusive")

    args = parser.parse_args()

    client = setupClient(args)
    client.request_queue()

    if args.continue_id and args.start_id:
        print("Mutually exclusive args: --continue-id or --start-id. ... Exiting")
        sys.exit(-1)
    elif args.continue_id:
        print("--continue-id: Reading queue to gather last pass-id ...")
        if not client.job_queue:
            print("WARNING: Job queue empty, starting from pass-id 0 ...")
            next_id = 0
        else:
            if client.job_queue[-1].pass_id == -1:
                print("WARNING: Last job in queue didn't have a pass-id, starting from pass-id 0 ...")
                next_id = 0
            else:
                next_id = client.job_queue[-1].pass_id + 1
    elif args.start_id:
        next_id = args.start_id
    else:
        print("Not assigning any pass-ids ... Parsing latest schedule file in configured Run Sheet dir ...")
        next_id = None
    
    if next_id is None:
        pass
    else:
        print(f"Starting from pass-id: {next_id} ... Parsing latest schedule file in configured Run Sheet dir ...")

    try:
        run_sheet_dir = Path(client.config["run_sheet_dir"]).expanduser()
    except KeyError as e:
        print("Key error: 'run_sheet_dir' is not defined in the ground station config file ... Exiting")
        sys.exit(-2)
    
    # Absolute path and filename
    latest_run_sheet = max((f for f in run_sheet_dir.iterdir() if f.is_file()), 
                           key=lambda el: el.stat().st_mtime,
                           default=None
                          )

    print(f"Using file: ({latest_run_sheet}) to populate the queue ...")
    
    cur_time = datetime.now(timezone.utc)
    
    with open(latest_run_sheet, mode="r",  newline="") as rs:
        reader = csv.DictReader(rs)

        for row in reader:
            next_id += 1
            print("Adding pass for: Pass ID {} - Sat ID {} - Rise Time {} - Max El {}".format(next_id, row["sat_id"], row["sat_rise_time"], row["max_elevation"]))
            
            # General format:
            # add_pass -sid <sat_id> [-n <nth_pass> | -t <start_time>] [sip-src] [ [dl_opts] | [ul_opts] ]
            
            pass_id = next_id
            sat_id = row["sat_id"]
            start_time = row["sat_rise_time"]
            
            # This is how to use strptime to create a timezone-aware object
            # Without .replace(), strptime parses the UTC string, but still creates a timezone-naive object
            start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)
            
            if start_time < cur_time:
                print(f"WARNING: Detected an old pass. \n Current time: {cur_time} \n Pass time: {start_time} \n Skipping ...")
                continue
            
            start_time = start_time - timedelta(seconds=135)
            
            tx_source_options = ["work_modem", "sig_gen"]
            tx_source = row["tx_source"]
            
            if tx_source not in tx_source_options:
                print(f"WARNING: Received unknown TX Source for pass-id {pass_id}: {str(tx_source)} ... Can't program schedule")
                print(f"{tx_source_options=}")
                raise ValueError(tx_source)
            elif tx_source == "work_modem":
                use_work_modem = True
                try:
                    ul_fc_mhz = float(row["ul_fc_mhz"])
                except ValueError as e:
                    print(f"{row['ul_fc_mhz']=}")
                    print(f"ERROR: WORK MODEM UPLINK Fc: Unable to read cell contents into a float: ul_fc_mhz -> {row['ul_fc_mhz']} ... Cant program schedule")
                    sys.exit(-1)
            else: 
                use_work_modem = False  # Passes -sip-src flag
                ul_modcod = row["ul_modcod"]
                if ul_modcod != "TONE":
                    print(f"WARNING: Detected a tone test for pass-id {pass_id} with a modcod string {ul_modcod=} instead of TONE ...")
                try:
                    ul_fc_mhz = float(row["ul_fc_mhz"])
                except ValueError as e:
                    print(f"{row['ul_fc_mhz']=}")
                    print(f"ERROR: SIG GEN UPLINK Fc: Unable to read cell contents into a float: ul_fc_mhz -> {row['ul_fc_mhz']} ... Cant program schedule")
                    sys.exit(-1)
            
            try:
                dl_fc_mhz = float(row["dl_fc_mhz"])
                dl_bw_mhz = float(row["dl_bw_mhz"])
            except ValueError as e:
                print(f"{row['dl_fc_mhz']=}")
                print(f"{row['dl_bw_mhz']=}")
                print(f"ERROR: DOWNLINK Fc & BW: Unable to read cell contents into a float: dl_fc_mhz, dl_bw_mhz -> {row['dl_fc_mhz']}, {row['dl_bw_mhz']} ... Cant program schedule")
                sys.exit(-1)
            
            # TODO: add a comment field in the PB for the modcod or something
            # TODO: we're not validating FPGA image
            # TODO: we're not vlaidating the tx_source + Fc combo

            client.add_pass(int(sat_id),
                            job_start=start_time,
                            dl_fc_mhz=float(dl_fc_mhz),
                            dl_bw_mhz=float(dl_bw_mhz),
                            ul_fc_mhz=float(ul_fc_mhz),
                            work_modem_tx_source=use_work_modem,
                            span_days=7,
                            pass_id=pass_id
                           )


def main():
    parser = argparse.ArgumentParser(description = 'Example showing how to use client')
    parser.add_argument('-config', default = str(default_cfg), type=str, help = 'Config File')    
    args = parser.parse_args() 
    
    client = setupClient(args)    
    # Load config File
    with open(args.config) as f:
        config = yaml.safe_load(f)      
    # Test 1 
    client.clear_queue() 

    em_id_df = pd.read_csv(Path(config['emission_id_db_file']).expanduser())
    em_id_db = em_id_df.set_index('txid').to_dict("index")     
    em_ids = ["fc1000_b5M_test",
            "fc2510M_b6M_DL4", 
            "fc4950M_b6M_DL5", 
            "fc5060M_b6M_DL6",] 

    for kk, em_id in enumerate(em_ids):
        client.add_pass(28626, datetime.now(timezone.utc)+timedelta(seconds=30*(kk+1)), tx_id=em_id, duration=15)         
        
    client.request_queue()

if __name__ == '__main__':
    main() 
    

    
        
