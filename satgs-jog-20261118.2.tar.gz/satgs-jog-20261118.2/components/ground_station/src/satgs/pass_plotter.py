
import ephem
from ephem import Observer
from ephem import degree as deg2rad
import numpy as np
from satgs.utils import find_passes, PassInfo, AzElTrajectory
from satgs.constants import GNSS_SATS, DEFAULTS, time_format_print, time_format_short
from pathlib import Path
import yaml
import pandas as pd
from datetime import datetime, timezone, timedelta
import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import argparse
from copy import copy
import logging
from satgs.pass_finder import PassFinder
from collections import OrderedDict

logger = logging.getLogger(__name__)


def plot_passes(observer:Observer, 
                passes:list[PassInfo],
                pass_numbers:list)->dict:
    t0 = datetime.now(timezone.utc)
    temp_observer = copy(observer)
    temp_observer.date = t0
    
    fig, ax_sky = plt.subplots(subplot_kw={'projection': 'polar'})        
    for kk, pass_info in enumerate(passes):
        if pass_info.is_circumpolar or pass_info.is_neverup:
            continue
        az_el_traj = pass_info.get_trajectory(observer=temp_observer)
        az_unwrapped = np.unwrap(az_el_traj.az*np.pi/180)*180/np.pi
        ax_sky.plot(az_el_traj.az*np.pi/180, (90-az_el_traj.el)*np.pi/180, 
                    label = 'Pass {}: {}'.format(
                        pass_numbers[kk], pass_info.sat_rise_time.strftime(time_format_short)), 
                    linewidth=4, alpha=0.5) 
       
    ax_sky.grid(True)
    ax_sky.set_rmax(np.pi/2)
    ax_sky.set_rmin(0)    
    rtick_locs = np.arange(10,100,10)
    rtick_labels = ['{:d}'.format(90-int(r)) for r in rtick_locs]
    ax_sky.set_rgrids(rtick_locs*np.pi/180, rtick_labels, fontsize=10)
    ax_sky.set_theta_zero_location("N")
    ax_sky.set_theta_direction(-1)
    ax_sky.set_title("Passes For ({} {}) \nStarting {}".format(pass_info.sat_id, pass_info.sat_tle.name, t0.strftime(time_format_print)), loc='left')
    ax_sky.legend(loc='lower left')
    plt.tight_layout()
    plt.show()
    
def main():    
    parser = argparse.ArgumentParser(description = 'Plots specific satellite passes')

    parser.add_argument('sid', type = int,  
                        help = 'Satellite ID')  
    parser.add_argument('-n', nargs="*", 
                        type=int, required=True, 
                        help='List of upcoming pass numbers i.e. -n 1 2 3 6')        
    parser.add_argument('-d', type=float, required=False, 
                        default=DEFAULTS.pass_finder_span,
                        help='Duration (days) to retrieve passes for. Defaults to {} days'.format(DEFAULTS.pass_finder_span))      
    args = parser.parse_args()

    # format logger
    root_logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    logger.setLevel(logging.INFO)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)

    config_file = Path('~/ground_station/config/config.yaml').expanduser()
    sat_file = Path('~/ground_station/config/sat_db.csv').expanduser()

    pass_finder = PassFinder(sat_file, config_file, time_window_days=args.d)

    tle_df = pd.read_csv(sat_file)
    tle_dict = tle_df.set_index('norad_id').to_dict("index")
    
    upcoming_passes = pass_finder.find_passes(args.sid)
    if (len(upcoming_passes)+1) < max(args.n):
        logger.error("Requested Pass {}, but current forecast only includes {} passes, run again and increase duration -d")
    selected_passes = [upcoming_passes[i] for i in args.n]    
    plot_passes(pass_finder.ground_station, 
                selected_passes, 
                args.n)
        

if __name__ == '__main__':
    main()
