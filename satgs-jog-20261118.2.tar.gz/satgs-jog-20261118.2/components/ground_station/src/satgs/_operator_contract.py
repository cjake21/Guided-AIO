"""Pure values shared by operator adapters and managed-workspace operations."""


ALTITUDE_REFERENCES = ("unspecified", "mean_sea_level")


class OperatorError(ValueError):
    def __init__(self, message, code="invalid", exit_code=2):
        super().__init__(message)
        self.code = code
        self.exit_code = exit_code
