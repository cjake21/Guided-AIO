import os
import sys
import yaml
import json
import logging
import time
import signal
import ephem
import subprocess
import re
import glob
from pathlib import Path
from datetime import datetime, timedelta, timezone
import threading
import argparse
import socket
from ephem import degree as deg2rad

from meteor_api.messenger import Messenger
from satgs import jobs_msg_pb2
from satgs.constants import Topics, DEFAULTS
from satgs.constants import time_format_print, time_format_short, time_format_tzone
from satgs.utils import Job, JobRequest, PassInfo, update_tle_db, scrape_url, tleTimeoutException, TLE, tle_from_str
from satgs.utils import find_passes, pb_to_job_request, determine_filename, determine_file_prefix

import pandas as pd
import numpy as np
from typing import Union, List
import logging_tree


logger = logging.getLogger(__name__)

class QueueManager:
    """
    Class for managing the satellite job queue. This class interfaces with an 
    active MQ message broker. Satellite passes can be added via this message 
    broker and the Manager class will maintain the queue order, re-publish the 
    queue status to the message broker and handle calls to pass_runner.py which
    executes a satellite pass. 
    
    Execution of satellite pass includes steering of dish, configuring the TX/RX
    front ends, logging of the pixhawk IMU measurements and (optionally RF 
    recordings with METEOR)
    
    """
    def __init__(self, 
                 messenger:Messenger, 
                 sat_file: Path, 
                 tx_id_file: Path,
                 config_file: Path, 
                 test_mode: bool=False,
                 pass_finder_span: float=None
                 )-> None:
        """Constructor

        Args:
            messenger (Messenger): Active MQ messenger
            sat_file (Path): .csv file containing the satellite TLEs
            tx_id_file (Path): .csv file containing the Emission ID details
            config_file (Path): .yaml file containing the setup configuration
            test_mode (bool, optional): Defaults to False. Optional flag for 
                testing in which pass_runner will run in no HW mode. 
            pass_finder_span (float, optional): Time span in days to look for 
                passes over, default set in constants file. 
        """
        self.messenger = messenger
        self.config_file = config_file
        self.test_mode = test_mode
        self.fqdn = socket.getfqdn()
        
        # Load config File
        with open(config_file) as f:
            self.config = yaml.safe_load(f)      
        if pass_finder_span is None:
            self.pass_finder_span = DEFAULTS.pass_finder_span
        self.existing_host = ""
        already_running = self.check_running_elsewhere()
        if already_running:
            logger.error("ground_station.service already running on {}. Can't run multiple instances. Exiting.".format(self.existing_host))
            print("ground_station.service already running on {}. Can't run multiple instances. Exiting.".format(self.existing_host))            
            self.running = False            
            return 
                 
        self.box_connectivity = self.config["box_connectivity"]
        self.sat_file = sat_file
        self.tx_id_file = tx_id_file
        
        self.ground_station = ephem.Observer()
        self.ground_station.date = datetime.now(timezone.utc)        
        self.ground_station.lat = self.config['ground_station_lat'] * deg2rad
        self.ground_station.lon = self.config['ground_station_lon'] * deg2rad
        self.ground_station.elevation = self.config['ground_station_altm']        

        tle_df = pd.read_csv(sat_file)
        tx_df = pd.read_csv(tx_id_file)
        
        self.tle_db = tle_df.set_index('norad_id').to_dict("index")

        logger.info("Updating TLE database")
        
        self.tle_db, db_updated = update_tle_db(self.tle_db)
        if db_updated:
            logger.info("TLE database updated")
            
            updated_df = pd.DataFrame(self.tle_db).transpose().reset_index().rename(columns={'index':'norad_id'})
            updated_df.to_csv(sat_file, index=False)
        else:
            logger.info("TLE database up to date, nothing to update")
            
        self.start_time_buffer = 10
        self.start_to_rise_buffer = 60*2
        self.min_job_gap_time = 20   
                        
        self.job_queue = []        
        self.tle_refresh_time = datetime.now(timezone.utc) + timedelta(days=DEFAULTS.tle_validity)
        self.running = True
        
        self.messenger.subscribe(Topics.ADD_JOB_CMD, self.addJobCb, "")
        self.messenger.subscribe(Topics.DELETE_JOB_CMD, self.deleteJobCb, "")
        self.messenger.subscribe(Topics.GET_QUEUE_CMD, self.queueRequestCb, "")
        self.messenger.subscribe(Topics.CLEAR_QUEUE_CMD, self.clearQueueCb, "")
        self.messenger.subscribe(Topics.PING_CMD, self.pingCmdCb, "")
        
        self.gs_state = "idle_empty"
        self.gs_status_msg = "Queue Status: {}, Queue Empty, Waiting for Jobs".format(self.gs_state)
        
        # add handlers for clean exit 
        signal.signal(signal.SIGINT, self.sigHandler)
        signal.signal(signal.SIGTERM, self.sigHandler)
    
        self.running = True   
        logger.info(self.gs_status_msg)                     
        
    def sigHandler(self, signum, frame):
        """Event handler for control-c/ shutdown

        Args:
            signum (_type_): _description_
            frame (_type_): _description_
        """
        logger.info('CNTL-C Detected, Shutting Down...')
        self.cleanExit()

    def cleanExit(self):
        """
        Stop running
        """
        self.running = False
        logger.info('Clean Shut Down')   
        
    def check_running_elsewhere(self, timeout:int=5):
        """Sends a ping to the manager service/python process. Returns True if 
        it gets a response, False otherwise. Waits 5 seconds for response

        Args:
            timeout (int, optional):  Defaults to 5.

        Returns:
            bool: True is gets response from manager service/ python process
        """     
        self.messenger.subscribe(Topics.PONG_RESPONSE, self.pongCmdCb, "")           
        logger.info('Checking if queue manager is already running on AMQ')
        logger.info("Pinging HW Manager, will wait {} seconds for response".format(timeout))      
        self.publishWrapper(Topics.PING_CMD, jobs_msg_pb2.QueuePing(ping=True))
        self.got_pong = False
        start_time = time.time()
        while not self.got_pong:
            if time.time()-start_time>timeout:
                logging.warning("No response ==> Queue manager is not already running. Good to run.... ")
                self.messenger.cancelSubscribe(Topics.PONG_RESPONSE, self.pongCmdCb, "")                           
                return False
        logging.warning("Queue manager is already running. Exiting.... ")
        self.messenger.cancelSubscribe(Topics.PONG_RESPONSE, self.pongCmdCb, "")                                               
        return True        

    def pongCmdCb(self, msg:str, id:int):
        """Call back for when Pong is received from manager service/ python process
        """             
        pong_msg = jobs_msg_pb2.QueuePong()
        pong_msg.ParseFromString(msg)         
        logging.info("Pong Received from host {}".format(pong_msg.host_info))      
        self.got_pong = True   
        self.existing_host = pong_msg.host_info
        
    def pingCmdCb(self, msg:str, id:int):
        """Call back for when Ping is received
        """             
        logging.info("Ping Received.")      
        logging.info("Sending Pong Response")
        self.publishWrapper(Topics.PONG_RESPONSE, jobs_msg_pb2.QueuePong(host_info=self.fqdn))              
        
    def addJobCb(self, msg:str, id:int) ->None:
        """Call back function for when "addJob" message is received from message 
        broker. 

        Args:
            msg (str): serialized protobuf message. 
            id (int): 
        """
        job_req = pb_to_job_request(msg)
        logger.info("Add job command received for sat id {}".format(job_req.sat_id))
        self.addJob(job_req)
    
    def queueRequestCb(self, msg:str, id:int)->None:
        """Call back function for when "queueRequest" message is received from 
        the message broker. 

        Args:
            msg (str): serialized protobuf message. 
            id (int): 
        """
        self.publishQueue()
    
    def publishQueue(self)->None:
        """Publishes the current queue to the message broker. 
        """
    
        pass_list = []
        for job_info in self.job_queue:
            pass_list.append('  ' + job_info.get_str())
        logger.info('Current Queue:\n' + '\n'.join(pass_list))        
        logger.info(self.gs_status_msg)

        queue_msg = jobs_msg_pb2.QueueStatus()
        queue_msg.jobs.extend([job.to_pb() for job in self.job_queue])
        queue_msg.hostname = self.fqdn
        time.sleep(0.1)
        logger.info("Publishing Queue")
        self.publishWrapper(Topics.QUEUE_STATUS, queue_msg)  

    
    def clearQueueCb(self, msg:str, id:int)->None:
        """Call back function for when "clearQueue" message is received from the 
        message broker. 

        Args:
            msg (str): serialized protobuf message. 
            id (int): 
        """
        logger.warning("Clear Queue Cmd Received")
        self.gs_state="idle_empty"   
        self.gs_status_msg = "Queue Status: {}, Waiting for next job to run".format(self.gs_state)             
        self.job_queue = []
        self.publishQueue()
            
    def deleteJobCb(self, msg:str, id:int)->None:
        """Call back function for when "deleteJob" message is received from the 
        message broker. 

        Args:
            msg (str): serialized protobuf message. 
            id (int): 
        """
        delete_cmd_msg = jobs_msg_pb2.DeleteJobCmdMsg()
        delete_cmd_msg.ParseFromString(msg)
        logger.info("Delete Job Cmd Received for job ID {}".format(delete_cmd_msg.job_id))
        self.deleteJob(delete_cmd_msg.job_id)
        self.printQueue()
    
    def publishWrapper(self, topic, msg):
        """Wrapper for publishing messages. 

        Args:
            topic (_type_): _description_
            msg (_type_): _description_
        """
        try:
            self.messenger.publish(topic, msg)
        except Exception as e:
            logging.info("Exception when sending message to Orin's ActiveMQ Broker.", exc_info = e)         
    
    def getQueue(self) -> List[Job]:
        """Returns the current job queue. 

        Returns:
            List[Job]: _description_
        """
        return self.job_queue

    def printQueue(self) -> None:
        """Prints the current job queue. 
        """
        pass_list = []
        for job_info in self.job_queue:
            pass_list.append(job_info.get_str())
        print('\n'.join(pass_list))
        
    def export_refresh_tle_db(self):
        logger.info("re-writing TLE db")
        
        updated_df = pd.DataFrame(self.tle_db).transpose().reset_index().rename(columns={'index':'norad_id'})
        updated_df.to_csv(self.sat_file, index=False)  
                  
        tle_df = pd.read_csv(self.sat_file)
        
        self.tle_db = tle_df.set_index('norad_id').to_dict("index")

        logger.info("Updated local copy of TLE database")
    
    def addJob(self, job_request:JobRequest):
        """Adds the requested satellite job to the queue. 

        Args:
            job_request (JobRequest): _description_
        """
        # add an ID
        if len(self.job_queue)==0:
            next_id = 1
        else:
            current_queue_ids = [job.job_id for job in self.job_queue]
            next_id = max(current_queue_ids) + 1
            
        self.ground_station.date = datetime.now(timezone.utc)
        
        job_tle = job_request.sat_tle
        
        # Check that TLE is in dB
        if job_request.sat_id not in self.tle_db.keys():
            logger.error("Error sat id not found in TLE dB, updating TLE dB. Adding to db")        
            self.tle_db.update(job_tle.to_dict())
            self.export_refresh_tle_db()
            # self.
        else:
            # Compare times
            db_time = datetime.strptime(self.tle_db[job_request.sat_id]["date"], time_format_tzone).replace(tzinfo=timezone.utc)
            if job_request.sat_tle.t_ref > db_time:
                logger.warning("Incoming request has more up to date TLE.... Updating our entry for {} ID {}".format(self.tle_db[job_request.sat_id]['name'], job_request.sat_id))
                self.tle_db.update(job_tle.to_dict())
                self.export_refresh_tle_db()
            elif job_request.sat_tle.t_ref < db_time:
                incoming_tle = job_request.sat_tle.tle_str
                local_tle = self.tle_db[job_request.sat_id]["tle"]
                if incoming_tle != local_tle:
                    logger.error("TLE in incoming request is out of date... Cannot add to queue and will respond to client with updated TLE")
                    add_reply_msg = jobs_msg_pb2.AddJobReplyMsg()
                    add_reply_msg.success = False
                    add_reply_msg.msg = "TLE is out of date, getting updated copy from manager"
                    db_time = datetime.strptime(self.tle_db[job_request.sat_id]["date"], time_format_tzone).replace(tzinfo=timezone.utc)
                    tle_return = ",".join([self.tle_db[job_request.sat_id]['tle'], db_time.strftime(time_format_tzone)])
                    add_reply_msg.tle_str = tle_return
                    logger.info("Publishing reply to job request ")
                    self.publishWrapper(Topics.JOB_REPLY_MSG, add_reply_msg)                      
                    return   
                else:
                    logger.info("It's an older TLE but it checks out... (Incoming TLE time tag is old but TLE params are the same)")

                  
        upcoming_passes = find_passes(job_request.sat_id, self.tle_db, 
                                      self.ground_station, job_request.elv_mask,
                                      time_window_hrs=self.pass_finder_span*24)
        # Check if circumpolar:
        if upcoming_passes[0].is_circumpolar:
            if job_request.duration==0:
                logger.warning("Requested Satellite is geostationary and duration was unspecified, setting duration to 30 sec")
                duration = 30
            else:
                duration = job_request.duration
            if job_request.job_start==0:
                print("Requested Satellite is geostationary and no start time specified, this should have be caught on client request side")
                logger.warning("Requested Satellite is geostationary and no start time specified, this should have be caught on client request side")
                pass_start = datetime.now(timezone.utc)+timedelta(seconds=90)
            else:
                pass_start = job_request.job_start
            job_start = pass_start
            job_item = Job(job_request.sat_id, job_id=next_id, 
                        pass_info=upcoming_passes[0],
                        job_start_time = job_start,
                        duration = duration,
                        priority = job_request.priority,
                        dl_id= job_request.dl_id,
                        dl_fc_mhz = job_request.dl_fc_mhz,
                        dl_bw_mhz = job_request.dl_bw_mhz,
                        ul_id= job_request.ul_id,
                        ul_fc_mhz = job_request.ul_fc_mhz,
                        apply_error_profile=job_request.apply_error_profile,
                        work_modem_tx_source=job_request.work_modem_tx_source,
                        pass_id=job_request.pass_id
                        )               

        elif job_request.pass_number <= 0:
            # Find corresponding Pass
            matching_pass = [sat_pass 
                             for sat_pass in upcoming_passes 
                             if ((job_request.job_start>=sat_pass.sat_rise_time) and (job_request.job_start<sat_pass.sat_set_time)) ]
            if len(matching_pass)>0:
                pass_info = matching_pass[0]

            else:
                start_deltas = [(sat_pass.sat_rise_time-job_request.job_start).total_seconds() for sat_pass in upcoming_passes if (sat_pass.sat_rise_time-job_request.job_start).total_seconds()>0]
                next_passes = [sat_pass for sat_pass in upcoming_passes if (sat_pass.sat_rise_time-job_request.job_start).total_seconds()>0]
                next_pass_delta = min(start_deltas)
                # next_pass_time = next_passes[start_deltas.index(next_pass_delta)].sat_rise_time
                pass_info = next_passes[start_deltas.index(next_pass_delta)]             
  
            job_item = Job(job_request.sat_id, job_id=next_id, 
                        pass_info=pass_info,
                        job_start_time = job_request.job_start,
                        duration = job_request.duration,
                        priority = job_request.priority,
                        dl_id= job_request.dl_id,
                        dl_fc_mhz = job_request.dl_fc_mhz,
                        dl_bw_mhz = job_request.dl_bw_mhz,
                        ul_id= job_request.ul_id,
                        ul_fc_mhz = job_request.ul_fc_mhz,
                        apply_error_profile=job_request.apply_error_profile,
                        work_modem_tx_source=job_request.work_modem_tx_source,
                        pass_id=job_request.pass_id
                        )            
        elif job_request.pass_number>0:
            if job_request.pass_number>len(upcoming_passes):
                logger.error("Invalid pass number. Only {} passes in the next {} days. Job Specified the {} 'th' pass".format(len(upcoming_passes), self.pass_finder_span, job_request.pass_number))
                self.publishQueue()            
                return
            pass_info = upcoming_passes[job_request.pass_number-1]
        
            job_start = pass_info.sat_rise_time - timedelta(seconds=self.start_to_rise_buffer)
            duration  = int((pass_info.sat_set_time - pass_info.sat_rise_time).total_seconds())
            job_item = Job(job_request.sat_id, job_id=next_id, 
                        pass_info=pass_info,                           
                        job_start_time = job_start,
                        duration = duration,
                        priority = job_request.priority,
                        dl_id= job_request.dl_id,
                        dl_fc_mhz = job_request.dl_fc_mhz,
                        dl_bw_mhz = job_request.dl_bw_mhz,
                        ul_id= job_request.ul_id,
                        ul_fc_mhz = job_request.ul_fc_mhz,
                        apply_error_profile=job_request.apply_error_profile,
                        work_modem_tx_source=job_request.work_modem_tx_source,
                        pass_id=job_request.pass_id
                        )   
            
        else:            
            add_reply_msg = jobs_msg_pb2.AddJobReplyMsg()
            add_reply_msg.success = False
            add_reply_msg.msg = "Invalid Job Request.... "
            logger.info("Publishing reply to job request ")
            self.publishWrapper(Topics.JOB_REPLY_MSG, add_reply_msg)
            
            logger.info("Invalid Job Request.... ") 
            self.publishQueue()            
            return
        
        add_reply_msg = jobs_msg_pb2.AddJobReplyMsg()
        add_reply_msg.success = True
        logger.info("Publishing reply to job request ")
        self.publishWrapper(Topics.JOB_REPLY_MSG, add_reply_msg)        
               
        self.job_queue.append(job_item)
        self.reorderQueue()
        self.publishQueue()
                
    def reorderQueue(self):
        """_summary_
        """
        
        # Re sort Sort Jobs
        self.job_queue = sorted(self.job_queue, key=lambda job: job.job_start_time)        
        
        for kk in np.arange(len(self.job_queue)):
            if (kk == len(self.job_queue)-1) | (len(self.job_queue)==1):
                break
                # Break if last job, or there is only one. Dont need to re-order anything
            if self.job_queue[kk] == self.job_queue[kk+1]:
                logger.warning("Attempted to add identical job, Job ID {} matches Job ID {}, popping ID {}".format(
                    self.job_queue[kk+1].job_id, self.job_queue[kk].job_id, self.job_queue[kk+1].job_id))
                self.job_queue.pop(kk+1)
                self.reorderQueue()
                break                
                
            self.job_queue[kk].job_start_time
            if self.job_queue[kk].pass_info.sat_rise_time==0: # Geo Sat
                job_end_time = self.job_queue[kk].job_start_time + timedelta(seconds=self.job_queue[kk].duration) + timedelta(seconds=self.min_job_gap_time)
            else:
                job_end_time = self.job_queue[kk].pass_info.sat_rise_time + timedelta(seconds=self.job_queue[kk].duration) + timedelta(seconds=self.min_job_gap_time)
            
            next_job_start_time = self.job_queue[kk+1].job_start_time
            next_priority = self.job_queue[kk+1].priority
            
            if next_job_start_time<job_end_time:
                print("Job ID {} and ID {} Overlap... Adjusting times.".format(self.job_queue[kk].job_id, self.job_queue[kk+1].job_id))
                # Check options:
                overlap = (job_end_time - next_job_start_time).total_seconds()
                if overlap < 60:
                    next_job_start_time = job_end_time + timedelta(seconds=overlap)
                    pass
                elif next_priority:
                    self.job_queue[kk].duration = self.job_queue[kk].duration - timedelta(seconds=overlap-self.min_job_gap_time).total_seconds()
                    if self.job_queue[kk].duration<0:
                        logger.warning("Jobs completely overlapping, cannot de-conflict, removing Job Id {}".format(self.job_queue[kk].job_id))                    
                        logger.warning("Popping Job and reordering Queue")
                        self.job_queue.pop(kk)
                        self.reorderQueue()
                        break
                else:
                    self.job_queue[kk+1].job_start_time = self.job_queue[kk+1].job_start_time + timedelta(seconds=overlap)
                    self.job_queue[kk+1].duration = (self.job_queue[kk+1].pass_info.sat_set_time - max(self.job_queue[kk+1].job_start_time, self.job_queue[kk+1].pass_info.sat_rise_time )).total_seconds()
                    if self.job_queue[kk+1].duration<0:
                        logger.warning("Jobs completely overlapping, cannot de-conflict, removing Job Id {}".format(self.job_queue[kk+1].job_id))
                        logger.warning("Popping Job and reordering Queue")
                        self.job_queue.pop(kk+1)
                        self.reorderQueue()
                        break      
                    
    def refresh_tles(self):
        update_count = 0
        if not self.job_queue:
            logger.info("Queue is empty, no TLEs to update")
            self.tle_refresh_time = datetime.now(timezone.utc) + timedelta(days=DEFAULTS.tle_validity)
        else:
        
            norad_ids = [job.sat_id for job in self.job_queue]
            unique_ids = list(set(norad_ids))
            
            for sat_id in unique_ids:
                try:
                    tle_info = scrape_url(sat_id)
                except tleTimeoutException:
                    logging.error("Cannot reach Celestrak, request for Norad ID {} timed out".format(sat_id))
                    continue
                new_tle = TLE(tle_str=','.join(tle_info), name=tle_info[0], 
                              t_ref=datetime.now(timezone.utc))
                if new_tle.tle_str == self.tle_db[sat_id]['tle']:
                    logging.info("Fetched TLE for {} is identical to existing one. No need to update. ")
                    continue
                update_count = update_count + 1
                logging.info("New TLE for {}, {} jobs that use this TLE.".format(sat_id, norad_ids.count(sat_id)))
                logging.warning("Code to re-update job start times from new TLEs is not implemented")
                self.tle_db.update(new_tle.to_dict())
                self.export_refresh_tle_db()
            self.tle_refresh_time = datetime.now(timezone.utc) + timedelta(days=DEFAULTS.tle_validity)
                
            """TODO: For now i am just skipping the part of actually updating the queue 
            based on the new TLE. I have no idea how much the actual rise and set times 
            change for TLE that are X date old. May need to come back to this in the future
            """
        logger.info("TLE Refresh complete, {:d} TLEs updated. Next update scheduled for {}".format(update_count, self.tle_refresh_time.strftime(time_format_tzone)))
        
        if len(self.job_queue)==0:
            self.gs_state = "idle_empty"
            self.gs_status_msg = "Queue Status: {}, Queue Empty Waiting for Jobs".format(self.gs_state)
        else:
            self.gs_state = "idle_waiting"
            self.gs_status_msg = "Queue Status: {}, Waiting to run next job".format(self.gs_state)
        logger.info(self.gs_status_msg)        
        
                    
    def deleteJob(self, job_id:int):
        """_summary_

        Args:
            job_id (int): _description_
        """
        job_ids = [job.job_id for job in self.job_queue]
        if job_id in job_ids:
            if len(job_ids)==1:
                self.gs_state='idle_empty' # Set to empty before popping to prevent error in main thread. 
            self.job_queue.pop(job_ids.index(job_id))
            logger.info("Removed Job ID {} from the queue".format(job_id))
            logger.debug("Re-ordering Queue")
            self.reorderQueue()
        else:
            logger.warning("Job ID {} is not in the queue".format(job_id))                                                                     
        self.publishQueue()


    def post_analyze_thread(self,  
                            latest_run: str, 
                            logname: str) -> None:
        """
        If box_connectivity config is set to true, upload MSEL pass results directory contents to Box for team-wide visibility
        """

        latest_pass_dir = Path(latest_run)
        
        if DEFAULTS.file_prefix in logname:  # either sat_capture_63231_<date>_<time> or <pass_id>_63231_<date>_<time>
            dir_name = logname
        else:
            dir_name, _, _ = logname.partition("_") # Should be just the pass_id
        
        # Check if 3rd party created the results folder on Box already
        # If yes, then use as the dest folder
        # If no, create our own

        d = [
            "box_sync",
            "--list-ids",
            "--log-level",
            "INFO",
        ]

        d_proc = subprocess.run(d, capture_output=True, check=True)
        d_out_dict = json.loads(d_proc.stdout)

        logger.debug(f"Discovery process returned: {d_proc.stdout}, {d_out_dict}")

        # Search for this pass in d_out_dict
        found = any(dir_name in v for v in d_out_dict.values() )
        
        if found:
            existing_dir_id = next((k for k, v in d_out_dict.items() if v == dir_name), None)
            logger.info(f"Found this pass directory on Box already: {existing_dir_id} -> {dir_name} ... Uploading")

            upload_cmd = [
                "box_sync",
                "-box-folder-id",
                str(existing_dir_id),
                "-local-folder",
                str(latest_pass_dir),
                "-operation",
                "upload",
                "--max-file-size",
                "100MB",
                "--log-level",
                "INFO",
                "--force",
            ]

            upload_proc = subprocess.run(upload_cmd, capture_output=True, text=True, check=False)
            if upload_proc.returncode != 0:
                logger.error(f"box-api-sync upload failed (rc={upload_proc.returncode}). Output:\n{(upload_proc.stdout or '')}\n{(upload_proc.stderr or '')}")
            else:
                logger.info("Uploaded successfully ...")
        else:
            logger.info(f"No existing pass result dir on Box for {latest_pass_dir} ... Creating a new dir with name: {dir_name}")

            # Invoke box_api_sync with --create-new-folder <dir_name>
            create_cmd = [
                "box_sync",
                "--create-folder",
                str(dir_name),
                "--log-level",
                "INFO",
            ]

            create_proc = subprocess.run(create_cmd, capture_output=True, text=True, check=True)
            new_folder_id = (create_proc.stdout or "").strip()
            
            # If folder id was created successfully, upload the latest pass directory to Box
            if new_folder_id != "" and new_folder_id != None:
                logger.info(f"Successfully parsed new folder id: {dir_name} -> {new_folder_id} ... Uploading")
                upload_cmd = [
                        "box_sync",
                        "-box-folder-id",
                        str(new_folder_id),
                        "-local-folder",
                        str(latest_pass_dir),
                        "-operation",
                        "upload",
                        "--max-file-size",
                        "100MB",
                        "--log-level",
                        "INFO",
                        "--force",
                ]

                upload_proc = subprocess.run(upload_cmd, capture_output=True, text=True, check=False)
                if upload_proc.returncode != 0:
                    logger.error(f"Upload failed (rc={upload_proc.returncode}). Output:\n{(upload_proc.stdout or '')}\n{(upload_proc.stderr or '')}")
                else:
                    logger.info("Uploaded successfully ...")
            else:
                logger.error(f"Failed to parse folder id from output (rc={create_proc.returncode}). Output:\n{create_proc.stdout}")
        
        # In all cases, update the state
        self.gs_state = "finished"


    def analyze_thread(self, job:JobRequest)->None:
        """Kick off thread to make quick look from IQ recording.
        Not Implemented

        Args:
            job (JobRequest): _description_
        """
        logger.info("Post processing Job {}, Satellite {}. Check Log!".format(job.job_id, job.sat_id))
        
        try:
            file_prefix = determine_file_prefix(job.pass_id, self.config["file_prefix_source"])
            logname, date_sat_dir = determine_filename(file_prefix, job.sat_id, self.sat_file,
                            date = self.job_start_ref.astimezone(timezone.utc) )
            full_log_dir = Path(self.config['logging_dir']).expanduser() / date_sat_dir
            logger.info("Running for latest folder in {}".format(full_log_dir))
            # Find latest
            latest_run = max(glob.glob(os.path.join(str(full_log_dir), '*/')), key=os.path.getmtime)
            # Run as subprocess to avoid getting multiple copies of root logger 
            cmd_arr = ["quick_look", str(Path(latest_run)),
                       "-config", self.config_file, 
                       "-email"
                       ] 
            logger.info("Executing: \n{}".format(" ".join(cmd_arr)))    
            status = subprocess.run(cmd_arr, check=True)#, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            logger.info(status)                           
        except Exception as e:
            logger.error("ERROR post processing {}, Satellite {}. Check Log!".format(job.job_id, job.sat_id))
            logger.error(e)
            import traceback
            logger.error(traceback.print_exc())
        if self.box_connectivity and job.sat_id == 63231:
            logger.info(f"Syncing with Box: Job {job.job_id}, Satellite {job.sat_id}, Pass ID {job.pass_id}")
            try:
                post_analysis_thread = threading.Thread(target=self.post_analyze_thread, args=(latest_run, logname))
                post_analysis_thread.start()
            except Exception as e:
                logging.error(f"Failed to start post_analyze_thread. Error: {e}")
                self.gs_state = "finished"
                self.gs_status_msg = "Queue Status: {}, Completed Job ID {}".format(self.gs_state, job.job_id)
                logger.info(self.gs_status_msg)
        else:
            self.gs_state = "finished"
            self.gs_status_msg = "Queue Status: {}, Completed Job ID {}".format(self.gs_state, job.job_id)
            logger.info(self.gs_status_msg)


    def job_thread(self, job:Job)->None:
        """Function for executing a pass. This function executes the pass by 
        running in subprocess call. This function should be invoked as a 
        separate thread. 

        Args:
            job (Job): Job to be executed. 
        """
        
        if self.test_mode:
            test_opts = ["--noptu", "--nopixhawk", "--nopdu", "--nofrontend"]
        else:
            test_opts = []
            
        self.job_start_ref = datetime.now()
        sat_id = job.sat_id
        if job.dl_id == "":
            downlink_opts = ["-dlfc", "{}".format(job.dl_fc_mhz),
                           "-dlfs", "{}".format(job.dl_bw_mhz)
                           ]           
        else:
            downlink_opts = ["-dlid", "{}".format(job.dl_id),
                           ] 
        logger.info("Enabling IQ recorder for all passes now, disabled in pass_runner.py when appropriate... ")
        test_opts.append("-rec-iq")              
        uplink_opts = []       
        if job.ul_id == "":
            uplink_opts = ["-ulfc", "{}".format(job.ul_fc_mhz),
                           ]
        else:
            uplink_opts = ["-ulid", "{}".format(job.ul_id),
                           ]
        if not job.work_modem_tx_source:
            uplink_opts.append('-sip-src')
        err_profile_opts = []
        if job.apply_error_profile:
            # Hard coded temp path
            err_profile_file = Path("~/ground_station/error_profile1.csv".replace('~',self.config['home_directory']) )
            err_profile_opts = ["--error-profile", str(err_profile_file)]
        else:
            err_profile_opts = []                                  
        try:
            cmd_arr = ["run_pass", 
                       "-config", self.config_file, 
                       "-id", "{}".format(sat_id), 
                       "--duration", "{}".format(job.duration),
                       "-pass-id", "{}".format(job.pass_id)
                       ] + downlink_opts + uplink_opts + test_opts + err_profile_opts
            logger.info("Executing: \n{}".format(" ".join(cmd_arr)))
            status = subprocess.run(cmd_arr, check=True)#, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            logger.info(status)            
        except:
            logger.error("ERROR Run Pass failed for {}, Satellite {}. Check Log!".format(job.job_id, job.sat_id))
        logger.info("Completed Pass, Job ID {}".format(job.job_id))
        self.gs_state = "post_processing"
        self.gs_status_msg = "Queue Status: {}, Completed Job ID {}".format(self.gs_state, job.job_id)
        logger.info(self.gs_status_msg)
        try:   
            analysis_thread = threading.Thread(target=self.analyze_thread, args=(job,))
            analysis_thread.start()
        except Exception as e:
            logger.info(f"Unable to start analysis thread. User can try running post_run_tools manually ... Error: {e}")
            self.gs_state = "finished"
            self.gs_status_msg = "Queue Status: {}, Completed Job ID {}".format(self.gs_state, job.job_id)
            logger.info(self.gs_status_msg)


    def run(self):
        """Run the queue manager.
        This function runs a state machine with the following states:
        1.) idle_empty:
            The job queue is empty, so it just sits and waits for new jobs to added
        2.) idle_waiting: 
            Jobs are in the queue but they have not started yet. Code just waits
            until the jobs starts and simultaneously listens for commands. 
        3.) running:
            A pass is being executed. Passes are run in separate threads. 
        4.) finished:
            The pass is over, depending on the queue status we either go back to 
            idle_empty or idle_waiting (if there are still jobs in the queue)
        5.) post_processing:
            Immediate state after pass completion. Begin analyzing pass results:
            Generate quick look report & sync with remote results store
        6.) updating_tles:
            After a job, if TLEs are stale, TLE database will be refreshed
        """
        
        # Core state machine
        while self.running:
            if self.gs_state=="idle_empty":
                if len(self.job_queue)>0:
                    self.gs_state = "idle_waiting"
                    self.gs_status_msg = "Queue Status: {}, Waiting for next job to run".format(self.gs_state)
                    logger.info(self.gs_status_msg)    
                    self.tle_refresh_time = datetime.now(timezone.utc) + timedelta(days=DEFAULTS.tle_validity)        
                else:
                    time.sleep(1)     
                               
            elif self.gs_state=="idle_waiting":
                next_job = self.job_queue[0]
                time_now = datetime.now(timezone.utc)   
                if time_now > (next_job.job_start_time - timedelta(seconds=self.start_time_buffer)):
                    try:
                        logger.info("Starting Job ID {}, Sat ID {}, Start time: {}, Duration: {}".format(
                            next_job.job_id, next_job.sat_id, next_job.job_start_time.strftime(time_format_print),
                            next_job.duration
                        ))
                        self.gs_state = "running"
                        self.gs_status_msg = "Queue Status: {}, executing Job ID {}".format(self.gs_state, next_job.job_id)
                        logger.info(self.gs_status_msg)                            
                        job_thread = threading.Thread(target=self.job_thread, args=(next_job,))
                        job_thread.start()
                    except Exception as e:
                        logger.error(f"Unable to start job_thread. Error: {e}") 
                elif time_now > self.tle_refresh_time:
                    logger.info("Refreshing TLEs...")
                    self.gs_state = "updating_tles"
                    self.gs_status_msg = "Queue Status: {}".format(self.gs_state)
                    logger.info(self.gs_status_msg)                     
                elif len(self.job_queue)==0:
                    self.gs_state = "idle_empty"
                    self.gs_status_msg = "Queue Status: {}, Queue Empty Waiting for new jobs".format(self.gs_state)
                    logger.info(self.gs_status_msg)
                else:
                    time.sleep(1)  
                     
            elif self.gs_state == "running":
                time.sleep(1)  
                
            elif self.gs_state == "post_processing": 
                time.sleep(1)  
                
            elif self.gs_state == "updating_tles":
                self.refresh_tles()
                
            elif self.gs_state == "finished":
                if self.gs_state != "idle_empty":
                    # Make sure queue didn't get cleared before popping last job. 
                    self.job_queue.pop(0)
                if len(self.job_queue)==0:
                    self.gs_state = "idle_empty"
                    self.gs_status_msg = "Queue Status: {}, Queue Empty Waiting for Jobs".format(self.gs_state)
                else:
                    self.gs_state = "idle_waiting"
                    self.gs_status_msg = "Queue Status: {}, Waiting to run next job".format(self.gs_state)
                logger.info(self.gs_status_msg)
                    
                    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = 'Logger for METEOR and the PixHawk for the Cubesat Mission')
    parser.add_argument('-config', default = 'config/config.yaml', type=str, 
                        help = 'Config File')    
    parser.add_argument('-sf', '--satfile', default = 'config/sat_db.csv', 
                        type=str, help = 'Path to YAML file containing satellite info')
    parser.add_argument('-tf', '--txidfile', default = 'config/signal_ids_db.csv', 
                        type=str, help = 'Path to config file with transmission id designators')
    parser.add_argument('--testmode', action = 'store_true', default = False,
                        help = 'If true, runs in test mode. Defaults to false')    
    parser.add_argument('-logdir', type=str, default='/opt/ground_station/logs/')
    args = parser.parse_args() 
      
    root_logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    logger.setLevel(logging.INFO)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)
    
    log_dir = Path(args.logdir)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)  
          
    file_handler = logging.FileHandler(log_dir/'queue_manager.log', 'w+')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG) # Log DEBUG level to file.        
    logger.addHandler(file_handler)        

    # Load config File
    with open(args.config) as f:
        config = yaml.safe_load(f)             
    credentials = {
                "username": config["amq_username"], 
                "password": config["amq_password"]}    
    messenger = Messenger(config['amq_server'], config['amq_port'], credentials, 
                          use_ssl=config['amq_use_ssl'])

    manager = QueueManager(messenger=messenger, sat_file=args.satfile, 
                 tx_id_file=args.txidfile, config_file=args.config,
                 test_mode=args.testmode)

    manager.run() 
    

