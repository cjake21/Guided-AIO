from dataclasses import dataclass
from datetime import timezone, tzinfo
import pytz
from enum import Enum, auto

time_format_print = "%m-%d-%Y %H:%M:%S"
time_format_short = "%m-%d %H:%M:%S"
time_format_files = "%m-%d-%Y-%H-%M-%S"
time_format_tzone = "%Y-%m-%d %H:%M:%S %Z"

# TODO: Deprecate usage of pytz

class DEFAULTS:
    """
    elev_mask = 15 (degrees)
    pass_finder_span = 7 (days) -- Number of days pass_finder uses
    tle_validity = 2 (days)
    local_tzone = pytz.timezone("US/Eastern") -- Users local time
    file_prefix = "sat_capture" (string) -- Prefix given to pass log filename & pass result dirname
    uplink_trace_bw = 10
    uplink_ch_bw = uplink_trace_bw
    uplink_ref_level_dbm = 10 (dbm)
    downlink_ref_level_dbm = -30 (dbm)
    tracking_update_rate = 1 (seconds)
    default_gain = 40
    prime_dur_est = 60 (seconds)
    ptu_cal_dur_est = 60 (seconds)
    park_dur_est = 60 (seconds)
    """
    elev_mask:float = 15
    pass_finder_span:float = 7
    tle_validity:float = 0.5
    local_tzone:tzinfo = pytz.timezone("US/Eastern")
    file_prefix:str = "sat_capture"
    uplink_trace_bw:int = 10
    uplink_ch_bw:int = uplink_trace_bw
    uplink_ref_level_dbm:int = 10
    downlink_ref_level_dbm:int = -30
    tracking_update_rate:int = 1
    default_gain:int = 40
    prime_dur_est:int = 60
    ptu_cal_dur_est:int = 60
    park_dur_est:int = 60


class Topics:
    JOB_MSG = "/topic/JOB_MSG"
    JOBID_MSG = "/topic/JOBID_MSG"
    QUEUE_STATUS = "/topic/QUEUE_STATUS"
    QUEUE_MANAGER_STATUS = "/topic/QUEUE_MANAGER_STATUS"
    
    JOB_REPLY_MSG = "/topic/QUEUE_MANAGER_STATUS"
    ADD_JOB_CMD = "/topic/ADD_JOB_CMD"
    DELETE_JOB_CMD = "/topic/DELETE_JOB_CMD"
    CLEAR_QUEUE_CMD = "/topic/CLEAR_QUEUE_CMD"
    GET_QUEUE_CMD = "/topic/GET_QUEUE_CMD"
    
    PING_CMD = "/topic/QUEUE_PING"
    PONG_RESPONSE = "/topic/QUEUE_PONG"
    
    RESMAN_JOBSTART = "/topic/RESMAN_JOBSTART"
    RESMAN_JOBEND = "/topic/RESMAN_JOBEND"

class GNSS_SYS(Enum):
    GPS=auto()
    GLO=auto()
    GAL=auto()
    BED=auto()
    WAAS=auto()
    
    
@dataclass
class GNSS_SAT:
    norad_id:int
    system:GNSS_SYS
    name:str
    glo_chan:int=0
    

GPS_SATS = [
    GNSS_SAT(39741, GNSS_SYS.GPS, "NAVSTAR 70 (USA 251)"),
    GNSS_SAT(24876, GNSS_SYS.GPS, "NAVSTAR 43 (USA 132)"),
    GNSS_SAT(26360, GNSS_SYS.GPS, "NAVSTAR 47 (USA 150)"),
    GNSS_SAT(28190, GNSS_SYS.GPS, "NAVSTAR 54 (USA 177)"),
    GNSS_SAT(29486, GNSS_SYS.GPS, "NAVSTAR 58 (USA 190)"),
    GNSS_SAT(38833, GNSS_SYS.GPS, "NAVSTAR 67 (USA 239)"),
    GNSS_SAT(40294, GNSS_SYS.GPS, "NAVSTAR 72 (USA 258)"),
    GNSS_SAT(44506, GNSS_SYS.GPS, "NAVSTAR 78 (USA 293)"),
]    
 
GAL_SATS = [
    GNSS_SAT(37846, GNSS_SYS.GAL, "GSAT0101 (GALILEO-PFM)"),
    GNSS_SAT(37847, GNSS_SYS.GAL, "GSAT0102 (GALILEO-FM2)"),
    GNSS_SAT(40129, GNSS_SYS.GAL, "GSAT0202 (GALILEO 6)"),
    GNSS_SAT(40545, GNSS_SYS.GAL, "GSAT0204 (GALILEO 8)"),
    GNSS_SAT(41550, GNSS_SYS.GAL, "GSAT0210 (GALILEO 13)"),    
]


GLO_SATS = [
    GNSS_SAT(39620, GNSS_SYS.GLO, "COSMOS 2492 [GLONASS-M]"),
    GNSS_SAT(36111, GNSS_SYS.GLO, "COSMOS 2456 [GLONASS-M]"),
    GNSS_SAT(39155, GNSS_SYS.GLO, "COSMOS 2485 [GLONASS-M]"),
    GNSS_SAT(37867, GNSS_SYS.GLO, "COSMOS 2476 [GLONASS-M]"),
    GNSS_SAT(43508, GNSS_SYS.GLO, "COSMOS 2527 [GLONASS-M]"),
    GNSS_SAT(36112, GNSS_SYS.GLO, "COSMOS 2457 [GLONASS-M]"),
    GNSS_SAT(37868, GNSS_SYS.GLO, "COSMOS 2477 [GLONASS-M]"),
    GNSS_SAT(40315, GNSS_SYS.GLO, "COSMOS 2501 [GLONASS-K]"),    
    GNSS_SAT(44850, GNSS_SYS.GLO, "COSMOS 2544 [GLONASS-M]"),    
    
]

BED_SATS = [
    GNSS_SAT(58655, GNSS_SYS.BED, "BEIDOU 3 M26"),    
    GNSS_SAT(44793, GNSS_SYS.BED, "BEIDOU 3M21"),    
    GNSS_SAT(44542, GNSS_SYS.BED, "BEIDOU 3M23"),    
    GNSS_SAT(43706, GNSS_SYS.BED, "BEIDOU 3M17"),    
    GNSS_SAT(43648, GNSS_SYS.BED, "BEIDOU 3M16"),    
    GNSS_SAT(43647, GNSS_SYS.BED, "BEIDOU 3M15"),    
    GNSS_SAT(43208, GNSS_SYS.BED, "BEIDOU 3M6"),    
    GNSS_SAT(43207, GNSS_SYS.BED, "BEIDOU 3M5"),    
    GNSS_SAT(43001, GNSS_SYS.BED, "BEIDOU-3 M1"),    
    
]

SBAS_SATS = []

GNSS_SATS = GPS_SATS + GAL_SATS + GLO_SATS + BED_SATS

SBAND_RADAR_SATS = [
    38771, #metop B
    43689, #METOP C   
    46984, #SENTINEL 6
    #32382, #rADSAT 2
]
LBAND_WEATHER_SATS = [
    25338, #NOAA 15
    28654, #NOAA 18
    33591, #NOAA 19
    38771, #metop B
    43689, #METOP C
    57490, #FENGYUN 3F
    56232, #FENGYUN 3g
    44387, #METEOR m2 2
    57166, #METEOR M2 3
    59051,  #METEOR M2-4 
]

