"""Local pass calculations bound to an immutable operator station snapshot."""

from datetime import datetime, timezone
import hashlib
import math
from pathlib import Path

from satgs.deployment_cli import read_regular_bytes
from satgs.operator_core import OperatorError
from satgs.runtime_configuration import RuntimeConfigurationError, _read_tle
from satgs.station_location import location_from_settings


REPLAY_START = '2025-05-16T03:00:00Z'
REPLAY_NORAD = 25338


def _finite(value, minimum, maximum, name):
    if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise OperatorError(f'{name} is outside the supported finite range.')
    return float(value)


def plan_workspace(workspace, *, start_time=REPLAY_START, norad_id=REPLAY_NORAD,
                   span_days=1, elevation_deg=20, tle_file=None):
    if type(norad_id) is not int or not 1 <= norad_id <= 2 ** 31 - 1:
        raise OperatorError('NORAD identity must be a positive bounded integer.')
    span = _finite(span_days, 1 / 24, 7, 'Planning span in days')
    elevation = _finite(elevation_deg, 0, 90, 'Elevation mask in degrees')
    try:
        start = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        if start.tzinfo is None:
            raise ValueError()
        start = start.astimezone(timezone.utc)
    except (AttributeError, TypeError, ValueError):
        raise OperatorError('Planning start must include an explicit UTC offset.') from None
    revision, settings = workspace.snapshot()
    location = location_from_settings(settings)
    path = Path(tle_file) if tle_file is not None else Path(__file__).parent / 'data/operator_tle.csv'
    raw = read_regular_bytes(str(path), input_kind='Local TLE')
    try:
        row = _read_tle(raw, norad_id).to_dict()
    except RuntimeConfigurationError:
        raise OperatorError('Local TLE input is malformed, missing, or ambiguous.') from None
    try:
        import ephem
        from satgs.utils import find_passes
        observer = ephem.Observer()
        observer.lat, observer.lon = str(location.latitude_deg), str(location.longitude_deg)
        observer.elevation, observer.date = location.altitude_m, start
        results = find_passes(norad_id, {norad_id: row}, observer,
                             elv_mask=elevation, time_window_hrs=span * 24)
        opportunities = []
        for index, result in enumerate(results):
            if index >= 256:
                raise OperatorError('Pass calculation exceeded its finite result bound.')
            opportunities.append(dict(index=index + 1, norad_id=norad_id,
                rise_utc=None if result.is_circumpolar else result.sat_rise_time.isoformat(),
                set_utc=None if result.is_circumpolar else result.sat_set_time.isoformat(),
                rising_azimuth_deg=float(result.rising_az), setting_azimuth_deg=float(result.setting_az),
                maximum_elevation_deg=float(result.max_elv), circumpolar=bool(result.is_circumpolar)))
        if any(not math.isfinite(value) for item in opportunities for value in item.values()
               if type(value) is float):
            raise ValueError()
    except ImportError:
        raise OperatorError('The selected installation lacks the existing scientific planning dependencies.',
                            code='dependency_unavailable', exit_code=3) from None
    except OperatorError:
        raise
    except Exception:
        raise OperatorError('The existing local pass calculation could not complete.',
                            code='planning_failed', exit_code=4) from None
    return workspace.record_plan(dict(
        station_revision=revision, location=location.to_dict(),
        altitude_reference=settings.get('operator', {}).get('altitude_reference', 'unspecified'),
        start_utc=start.isoformat(), span_days=span, elevation_mask_deg=elevation,
        norad_id=norad_id, tle_sha256=hashlib.sha256(raw).hexdigest(),
        source='bundled_historical_replay' if tle_file is None else 'operator_selected_local_tle',
        tle_reference_time=row['date'], refresh_performed=False,
        opportunities=opportunities, planning_only=True, execution_enabled=False,
        warnings=['Historical/local TLE data are not evidence of current orbit freshness.',
                  'Altitude reference is operator-declared or unspecified; no conversion or survey is established.',
                  'Owner location binding, physical pointing and navigation remain unqualified.']))
