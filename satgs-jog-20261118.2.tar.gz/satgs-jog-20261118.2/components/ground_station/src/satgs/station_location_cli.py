"""Prepare a new station artifact without changing active owners or input files."""

import argparse
from contextlib import ExitStack
import hashlib
import json
import os
import sys

from satgs.deployment_cli import CliInputError, MAX_INPUT_BYTES, read_regular_bytes
from satgs.runtime_configuration import RuntimeConfigurationError, _parse_station_yaml
from satgs.station_location import LocationError, prepare_manual_location


class LocationArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise LocationError("Unsupported station-location arguments; use --help.")


def _parser():
    parser = LocationArgumentParser(
        prog="python -m satgs.station_location_cli", allow_abbrev=False,
        description="Prepare explicit manual coordinates for subsequent plans and owner reinitialization.",
    )
    parser.add_argument("--station", required=True, metavar="PATH")
    parser.add_argument("--output", required=True, metavar="NEW_PATH")
    parser.add_argument("--expected-revision", required=True, metavar="SHA256")
    parser.add_argument("--latitude-deg", required=True, type=float)
    parser.add_argument("--longitude-deg", required=True, type=float)
    parser.add_argument("--altitude-m", required=True, type=float)
    parser.add_argument("--source", default="manual")
    return parser


def _reject_repeated_options(arguments):
    seen = set()
    for argument in arguments:
        option = argument.partition("=")[0]
        if option.startswith("--"):
            if option in seen:
                raise LocationError("Each station-location option may be supplied only once.")
            seen.add(option)


def _write_new_artifact(path, payload):
    if path == "-":
        raise LocationError("Provide a new regular output file; standard output is unsupported.")
    supported = (os.open in os.supports_dir_fd and all(hasattr(os, name) for name in (
        "O_PATH", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC"
    )))
    if not supported:
        raise LocationError("This platform does not support safe station output access.")
    created = False
    try:
        parts = os.path.abspath(path).strip("/").split("/")
        if parts[0] in ("dev", "proc", "sys") or not parts[-1]:
            raise LocationError("Station output must be outside device and observation roots.")
        directory_flags = os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        with ExitStack() as descriptors:
            directory = os.open("/", directory_flags)
            descriptors.callback(os.close, directory)
            for component in parts[:-1]:
                directory = os.open(component, directory_flags, dir_fd=directory)
                descriptors.callback(os.close, directory)
            descriptor = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL
                                 | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
            created = True
            descriptors.callback(os.close, descriptor)
            with os.fdopen(descriptor, "wb", closefd=False) as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(descriptor)
    except (OSError, ValueError):
        if created:
            raise LocationError("Station artifact could not be completed; an incomplete output may remain.") from None
        raise LocationError("Station output must be a new file in an existing directory without symlinks.") from None


def _run(arguments):
    raw = read_regular_bytes(arguments.station, input_kind="Station")
    settings = _parse_station_yaml(raw, allow_inline_ca=True)
    revision = hashlib.sha256(raw).hexdigest()
    prepared = prepare_manual_location(
        settings, latitude_deg=arguments.latitude_deg, longitude_deg=arguments.longitude_deg,
        altitude_m=arguments.altitude_m, source=arguments.source,
        expected_revision=arguments.expected_revision, current_revision=revision,
    )
    payload = (json.dumps(prepared.settings(), sort_keys=True, indent=2,
                          ensure_ascii=True, allow_nan=False) + "\n").encode("utf-8")
    if len(payload) > MAX_INPUT_BYTES:
        raise LocationError("Prepared station artifact exceeds the supported byte limit.")
    _parse_station_yaml(payload, allow_inline_ca=True)
    _write_new_artifact(arguments.output, payload)
    return {"location": prepared.location.to_dict(), "changed": prepared.changed,
            "station_revision": hashlib.sha256(payload).hexdigest(),
            "artifact_created": True, "active_run_changed": False,
            "owner_state": "not_checked",
            "planning_revalidation_required": prepared.changed,
            "owner_reinitialization_required": prepared.changed}


def main(argv=None):
    arguments = list(sys.argv[1:] if argv is None else argv)
    try:
        _reject_repeated_options(arguments)
        result = _run(_parser().parse_args(arguments))
    except (LocationError, CliInputError, RuntimeConfigurationError) as error:
        print(json.dumps({"error": {"code": "invalid_location", "message": str(error)}},
                         sort_keys=True))
        return 2
    except (OSError, ValueError, TypeError, RecursionError):
        print(json.dumps({"error": {"code": "invalid_location",
                                    "message": "Station location could not be prepared safely."}},
                         sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
