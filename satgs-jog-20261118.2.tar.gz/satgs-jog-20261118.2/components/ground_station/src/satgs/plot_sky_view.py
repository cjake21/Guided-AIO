
import ephem
from ephem import Observer
from ephem import degree as deg2rad
import numpy as np
from satgs.utils import find_passes, PassInfo, AzElTrajectory
from satgs.constants import GNSS_SATS, DEFAULTS
from pathlib import Path
import yaml
import pandas as pd
from datetime import datetime, timezone, timedelta
import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import argparse
from copy import copy
import logging
from satgs.pass_finder import PassFinder
from collections import OrderedDict

logger = logging.getLogger(__name__)


def plot_sky_view(observer:Observer, 
                  tle_dict:dict, t0:datetime=None, 
                  show_geo:bool=True, 
                  show_gnss:bool=True,
                  show_leo:bool=True, 
                  show_meo:bool=False)->dict:
    in_view_sats = {}
    if t0 is None:
        t0 = datetime.now(timezone.utc)
    temp_observer = copy(observer)
    fig, ax_sky = plt.subplots(subplot_kw={'projection': 'polar'})
    gnss_ids = [sat.norad_id for sat in GNSS_SATS]
    for sat_id in tle_dict.keys():
        temp_observer.date = t0 
                   
        if sat_id in gnss_ids:
            is_gnss =True
            if not show_gnss:
                continue
        else:
            is_gnss=False
        
        tle_parts = tle_dict[sat_id]['tle'].split(',')
        sat_ephem = ephem.readtle(tle_parts[0], tle_parts[1], tle_parts[2])
        sat_ephem.compute(temp_observer)
        
        is_geo=False
        try:
            temp_observer.next_pass(sat_ephem)
        except:
            is_geo=True           
            if not show_geo:
                continue
        az_deg = np.zeros(2)
        el_deg = np.zeros(2)        
                
        az_deg[0] = sat_ephem.az*180/np.pi
        el_deg[0] = sat_ephem.alt*180/np.pi                      
        if np.any(el_deg>0):
            is_leo = False
            is_meo = False
            if (float(sat_ephem.range)/1e3) <3e3:
                is_leo = True
                if not show_leo:
                    continue
            elif (not is_geo):
                is_meo=True
                    
            if is_leo:
                t_delta = timedelta(minutes=1)
            if is_gnss:
                t_delta = timedelta(minutes=30)                
            else:
                t_delta = timedelta(minutes=60)
                
            temp_observer.date = t0+t_delta
            sat_ephem.compute(temp_observer)
            az_deg[1] = sat_ephem.az*180/np.pi
            el_deg[1] = sat_ephem.alt*180/np.pi            
            if (is_gnss and not show_gnss):
                continue
            
            if (is_gnss and show_gnss) or (is_leo and show_leo) or (is_geo and show_geo) or (is_meo and show_meo):
                ax_sky.plot(az_deg*np.pi/180, (90-el_deg)*np.pi/180, 
                            label = 'ID: {}, {} '.format(sat_id, tle_dict[sat_id]['name']),
                            marker='x', linewidth=4) # Plot Series   
                if is_gnss:
                    gnss_sat = [sat for sat in GNSS_SATS if sat.norad_id==sat_id]
                    annotation = '{} ({})'.format(str(gnss_sat[0].system.name), sat_id)
                else:                  
                    annotation = tle_dict[sat_id]['name']
                ax_sky.annotate(annotation, xy=(az_deg[0]*np.pi/180, (90-el_deg[0])*np.pi/180))
                in_view_sats[sat_id] = {'el':float(el_deg[0]),'az':float(az_deg[0])}
    
    ax_sky.grid(True)
    ax_sky.set_rmax(95*np.pi/180)
    ax_sky.set_rmin(0)    
    rtick_locs = np.arange(10,100,10)
    rtick_labels = ['{:d}'.format(90-int(r)) for r in rtick_locs]
    ax_sky.set_rgrids(rtick_locs*np.pi/180, rtick_labels, fontsize=10)
    ax_sky.set_theta_zero_location("N")
    ax_sky.set_theta_direction(-1)
    ax_sky.set_title("Sky View", loc='left')
    plt.show()
    return OrderedDict

def main():    
    parser = argparse.ArgumentParser(description = 'Plots orbits of satellite currently in view')

    parser.add_argument('-geo', action='store_true', 
                        help="If input, plots GEOs")   
    parser.add_argument('-gnss', action='store_true', 
                        help="If input, plots GNSS/ MEO Satellites")     
    parser.add_argument('-leo', action='store_true', 
                        help="If input, plots LEO satellites (anything less than < 1000 km)")       
    parser.add_argument('-meo', action='store_true', 
                        help="If input, plots MEO satellites (anything less than > 1000 km)")     
    args = parser.parse_args()

    # format logger
    root_logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    logger.setLevel(logging.INFO)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)

    config_file = Path('~/ground_station/config/config.yaml').expanduser()
    sat_file = Path('~/ground_station/config/sat_db.csv').expanduser()

    pass_finder = PassFinder(sat_file, config_file)

    tle_df = pd.read_csv(sat_file)
    tle_dict = tle_df.set_index('norad_id').to_dict("index")
    in_view_sats = plot_sky_view(pass_finder.ground_station, tle_dict, 
                                        show_geo=args.geo, 
                                        show_gnss=args.gnss,
                                        show_leo=args.leo)
        

if __name__ == '__main__':
    main()
