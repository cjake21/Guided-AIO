from __future__ import annotations

import argparse
from contextlib import ExitStack
import json
import os
import stat
import sys

from satgs.deployment import DeploymentError, load_manifest
from satgs.deployment_plan import (
    InputError,
    build_catalog,
    compare_release,
    expand_preset,
    parse_configuration,
    parse_inventory,
    parse_requirements,
    plan_configuration,
    render_human,
    render_json,
    validate_document_structure,
)


MAX_INPUT_BYTES = 1_048_576
MAX_INPUT_DEPTH = 32
MAX_INPUT_NODES = 8192
_DIR_FD_SUPPORTED = (
    {os.open, os.stat} <= os.supports_dir_fd and os.stat in os.supports_follow_symlinks
)


class CliInputError(Exception):
    pass


class PlanningArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise CliInputError("Unsupported arguments. Use --help for supported planning commands.")


def _parser():
    parser = PlanningArgumentParser(
        prog="python -m satgs.deployment_cli",
        description="Inspect deployment inputs and produce plans without applying changes.",
        allow_abbrev=False,
    )
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("catalog", "validate", "plan", "compare"):
        command = commands.add_parser(name, allow_abbrev=False)
        command.add_argument("--format", choices=("human", "json"), default="human")
        if name == "catalog":
            continue
        if name == "plan":
            selection = command.add_mutually_exclusive_group(required=True)
            selection.add_argument("--preset", choices=("guided_arrow", "full_msel"))
            selection.add_argument("--config", metavar="PATH")
        else:
            command.add_argument("--config", required=True, metavar="PATH")
        command.add_argument("--inventory", metavar="PATH")
        command.add_argument("--requirements", required=name == "compare", metavar="PATH")
    return parser


def _reject_repeated_options(arguments):
    options = {"--config", "--preset", "--inventory", "--requirements", "--format"}
    seen = set()
    for argument in arguments:
        option = argument.partition("=")[0]
        if option in options:
            if option in seen:
                raise CliInputError("Each input or output option may be supplied only once.")
            seen.add(option)


def _check_depth(payload):
    depth = 0
    quoted = False
    escaped = False
    for character in payload:
        if quoted:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                quoted = False
        elif character == '"':
            quoted = True
        elif character in "[{":
            depth += 1
            if depth > MAX_INPUT_DEPTH:
                raise CliInputError("JSON nesting exceeds the supported limit.")
        elif character in "]}":
            depth -= 1


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise CliInputError("JSON object keys must be unique.")
        result[key] = value
    return result


def _reject_constant(value):
    raise CliInputError("JSON must not contain non-finite constants.")


def read_regular_bytes(path, *, input_kind="Input"):
    """Read one bounded regular file without following symlink components."""
    if path == "-":
        raise CliInputError(f"Provide an explicit {input_kind} file; standard input is unsupported.")
    try:
        parts = os.path.abspath(path).strip("/").split("/")
        if parts[0] in ("dev", "proc", "sys"):
            raise CliInputError(f"Device and system observation paths are unsupported {input_kind} inputs.")
        if not _DIR_FD_SUPPORTED or not all(
            hasattr(os, flag) for flag in ("O_PATH", "O_DIRECTORY", "O_NOFOLLOW", "O_NONBLOCK", "O_CLOEXEC")
        ):
            raise CliInputError(f"This platform does not support safe {input_kind} file access.")
        directory_flags = os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        with ExitStack() as descriptors:
            directory = os.open("/", directory_flags)
            descriptors.callback(os.close, directory)
            for component in parts[:-1]:
                directory = os.open(component, directory_flags, dir_fd=directory)
                descriptors.callback(os.close, directory)
            before = os.stat(parts[-1], dir_fd=directory, follow_symlinks=False)
            if not stat.S_ISREG(before.st_mode):
                raise CliInputError(f"{input_kind} input must be a regular file, not a link or device.")
            if before.st_size > MAX_INPUT_BYTES:
                raise CliInputError(f"{input_kind} input exceeds the supported byte limit.")
            descriptor = os.open(
                parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                dir_fd=directory,
            )
            descriptors.callback(os.close, descriptor)
            opened = os.fstat(descriptor)
            if not stat.S_ISREG(opened.st_mode):
                raise CliInputError(f"{input_kind} input must be a regular file, not a link or device.")
            if (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino):
                raise CliInputError(f"{input_kind} input changed while opening; supply a stable file.")
            if opened.st_size > MAX_INPUT_BYTES:
                raise CliInputError(f"{input_kind} input exceeds the supported byte limit.")
            with os.fdopen(descriptor, "rb", closefd=False) as stream:
                payload = stream.read(MAX_INPUT_BYTES + 1)
    except (OSError, ValueError, RuntimeError):
        raise CliInputError(f"{input_kind} input could not be read safely; use a stable path without symlink components.") from None
    if len(payload) > MAX_INPUT_BYTES:
        raise CliInputError(f"{input_kind} input exceeds the supported byte limit.")
    return payload


def read_json_document(path):
    """Return the exact admitted bytes and their bounded decoded JSON value."""
    payload = read_regular_bytes(path, input_kind="JSON")
    try:
        document = payload.decode("utf-8")
        _check_depth(document)
        data = json.loads(
            document,
            object_pairs_hook=_unique_object,
            parse_constant=_reject_constant,
        )
    except (UnicodeError, ValueError, RecursionError):
        raise CliInputError("JSON input must contain a valid UTF-8 JSON document.") from None
    try:
        validate_document_structure(data)
    except InputError:
        raise CliInputError("JSON structure exceeds the supported limits.") from None
    return payload, data


def _read_json(path):
    return read_json_document(path)[1]


def _run(arguments):
    catalog = build_catalog(load_manifest())
    if arguments.command == "catalog":
        return catalog, 0
    if arguments.command == "plan" and arguments.preset is not None:
        configuration = expand_preset(catalog, arguments.preset)
    else:
        configuration = parse_configuration(_read_json(arguments.config), catalog)
    inventory = (
        parse_inventory(_read_json(arguments.inventory), catalog)
        if arguments.inventory is not None
        else None
    )
    requirements = (
        parse_requirements(_read_json(arguments.requirements), catalog)
        if arguments.requirements is not None
        else None
    )
    if arguments.command == "compare":
        result = compare_release(configuration, catalog, requirements, inventory=inventory)
    else:
        result = plan_configuration(configuration, catalog, inventory=inventory, requirements=requirements)
    return result, 3 if result.blocked else 0


def _error_format(arguments):
    for index, value in enumerate(arguments):
        if value == "--format=json":
            return "json"
        if value == "--format" and index + 1 < len(arguments) and arguments[index + 1] == "json":
            return "json"
    return "human"


def main(argv=None):
    arguments = list(sys.argv[1:] if argv is None else argv)
    output_format = _error_format(arguments)
    try:
        _reject_repeated_options(arguments)
        parsed = _parser().parse_args(arguments)
        output_format = parsed.format
        record, status = _run(parsed)
    except CliInputError as error:
        message = str(error)
    except (InputError, DeploymentError):
        message = "Deployment inputs are invalid or unsupported; check the documented schemas."
    else:
        print(render_json(record) if output_format == "json" else render_human(record))
        return status
    if output_format == "json":
        print(json.dumps({"error": {"code": "invalid_input", "message": message}}, sort_keys=True))
    else:
        print(f"Invalid input: {message}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
