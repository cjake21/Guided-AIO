import csv
import sys
import ephem
import yaml
import pytz
import argparse
import logging
from copy import deepcopy
import pandas as pd
from pathlib import Path
from tqdm import tqdm
from uuid import uuid4
from typing import List
from ephem import degree as deg2rad
from datetime import datetime, timedelta, timezone

from satgs.constants import (DEFAULTS, 
                             time_format_tzone, 
                             GNSS_SATS, 
                             time_format_files,
                             SBAND_RADAR_SATS,
                             LBAND_WEATHER_SATS)
from satgs.utils import (PassInfo, 
                         update_tle_db,
                         find_passes,
                         add_new_tle,
                         del_tle)
from satgs.queue_client import setupClient


default_cfg = Path('~/ground_station/config/config.yaml').expanduser()
default_sat_db = Path('~/ground_station/config/sat_db.csv').expanduser()


class PassFinder():
    """Class for finding and printing out satellite pass information.
     
    This class looks up pass for satellites in "sat_file". Passes will be 
    based on a ground observer as specified in the "config_file". It will 
    look for passes between the start_time -> (start_time + duration[days]). 
    It will only consider passes above the elevation mask. 
    
    By default all passes are printed in UTC time
    """
    def __init__(self, sat_file:Path, 
                 config_file:Path,
                 start_time:datetime=None,                                   
                 time_window_days=DEFAULTS.pass_finder_span, 
                 el_mask_deg=DEFAULTS.elev_mask, 
                 include_gnss:bool=False,
                 use_local_tzone:bool=False,
                 norad_ids:list=None,
                 lband_noaa_mask:bool=False,
                 sband_radar_mask:bool=False,
                 at_locale:str=None,
                 send_to_csv:bool=False,
                 station_settings=None):
        """
        Args:
            sat_file (Path): Path to csv file with satellite TLEs
            config_file (Path): Path to YAML file that contains config 
                information
            start_time (datetime, optional): Start time of the time window to
                look over            
            time_window_days (float, optional): (days) Time window to look for 
                passes over. Default set in ground station constants file
            el_mask_deg (int, optional): Elevation mask. Default set in 
                ground station constants file
            include_gnss (bool, optional): If set, will find passes for GNSS 
                satellites. Default is False
            use_local_tzone (float, optional): If true, times will be printed in 
                local time, default behavior is to print in UTC.  
            norad_ids (list, optional): List of norad IDs to print pass info for. 
                If none are specified, prints info for all satellites in sat_db
                Defaults to None (aka print all satellites).
            lband_noaa_mask (bool, optional): If true, only passes for Lband weather 
                satellites will be calculated. Default is False
            sband_radar_mask (bool, optional): If true, only passes for Sband radar 
                satellites will be calculate. Default is False
            at_locale (str, optional): If given, runs pass_finder at some other locale.
                Locales set in ground station config file, default is the current 
                ground station location
            send_to_csv (bool, optional): If true, generated passes will be stored
                in a well-defined CSV file, file dest set in ground station config
        """
        self.sat_file = sat_file
        tle_df = pd.read_csv(sat_file)
        
        self.tle_db = tle_df.set_index('norad_id').to_dict("index")
        logging.info("Checking TLEs, updating if necessary")
        
        if norad_ids is not None:
            self.norad_ids = norad_ids            
            tle_subset = {norad_id: self.tle_db[norad_id] for norad_id in self.norad_ids}
            tle_subset, db_updated = update_tle_db(tle_subset, DEFAULTS.tle_validity)
            self.tle_db.update(tle_subset)
        else:
            self.norad_ids = list(self.tle_db.keys())            
            self.tle_db, db_updated = update_tle_db(self.tle_db, DEFAULTS.tle_validity)            
        if db_updated:
            updated_df = pd.DataFrame(self.tle_db).transpose().reset_index().rename(columns={'index':'norad_id'})
            updated_df.to_csv(sat_file, index=False)    
        logging.info("TLEs up to date")            
                    
        self.include_gnss = include_gnss
        self.gnss_ids = [sat.norad_id for sat in GNSS_SATS]
         
        if sband_radar_mask:
            self.norad_ids = SBAND_RADAR_SATS
        if lband_noaa_mask:
            self.norad_ids = LBAND_WEATHER_SATS 
            
        if station_settings is None:
            with open(config_file) as f:
                self.config = yaml.safe_load(f)
        else:
            self.config = deepcopy(dict(station_settings))
        
        if at_locale is None:
            self.latitude=self.config['ground_station_lat'] * deg2rad
            self.longitude=self.config['ground_station_lon'] * deg2rad
            self.altitude=self.config['ground_station_altm']
        else: # User supplied a different locale
            try:
                self.latitude = self.config["pass_finder_locales"][f"{at_locale}"].get("lat") * deg2rad
                self.longitude = self.config["pass_finder_locales"][f"{at_locale}"].get("long") * deg2rad
                self.altitude = self.config["pass_finder_locales"][f"{at_locale}"].get("alt")
            except KeyError as e:
                logging.error(f"KeyError: user supplied --at arg not set in config ... Exiting")
                sys.exit(-2)

        #if lat_deg is not None:
        #    self.latitude=lat_deg
        #else:
        #    self.latitude=self.config['ground_station_lat'] * deg2rad
        #    
        #if lon_deg is not None:
        #    self.longitude=lon_deg
        #else:
        #    self.longitude=self.config['ground_station_lon'] * deg2rad
        #    
        #if alt_m is not None:
        #    self.altitude=alt_m
        #else:
        #    self.altitude=self.config['ground_station_altm']   
            
        self.use_local_tzone = use_local_tzone
        if self.use_local_tzone:
            self.tzone = DEFAULTS.local_tzone
        else:
            self.tzone = pytz.timezone("UTC")
          
        self.window_dur_hrs = time_window_days *24
        if start_time is None:
            self.start_time = datetime.now(timezone.utc)
        else:
            self.start_time = start_time
        # self.start_time_local = self.start_time + datetime.timedelta(hours=self.utc2local)

        self.end_time = self.start_time + timedelta(hours=self.window_dur_hrs)
        # self.end_time_local =  self.end_time + datetime.timedelta(hours=self.utc2local)        
        # print(self.window_dur_hrs)     

        # degrees above the horizon to mask
        self.el_mask = el_mask_deg

        # set ground station object location and read updated TLE
        self.ground_station = ephem.Observer()
        self.ground_station.lat = self.latitude
        self.ground_station.lon = self.longitude
        self.ground_station.elevation = self.altitude        
        self.ground_station.date = self.start_time

        self.observations = {}
        self.observations_nonzero = {}
        self.satellite_passes = {}
    
    def find_passes(self, sat_id: int)->List[PassInfo]:
        """Find upcoming passes. 

        Args:
            sat_id (int): Satellite Norad ID

        Returns:
            List[PassInfo]: List of upcoming satellite passes
        """
        pass_list = \
            find_passes(sat_id, self.tle_db, self.ground_station, 
                        self.el_mask, self.window_dur_hrs)
        return pass_list

    def run_sat_passes(self):
        """ Calculates all upcoming passes for all satellites. 

        Args: None
        
        Returns: 
            list of satellite passes
        """   

        print("Computing Satellite Passes")
        all_passes = []
        with tqdm(self.norad_ids) as pbar:
            pbar.set_description(f"{'':>6} | {'':>12} | {'':>5} ")
            for sat_id in pbar:
                if (sat_id in self.gnss_ids) and (not self.include_gnss):
                    continue
                pass_list  = self.find_passes(sat_id)
                if len(pass_list)>0:
                    self.satellite_passes[sat_id] = pass_list
                    all_passes.extend(pass_list)
        return all_passes
    

    def generate_csv_file(self) -> Path:
        """ Uses pass_finders CLAs to send output to a CSV file instead of printing to console.
        This generated CSV file location is defined in the config.yaml file: run_sheet_dir

        Args: None

        Returns:
            Path: Path to the generated run sheet.
        """

        directory_path = Path(self.config["run_sheet_dir"]).expanduser()
        directory_path.mkdir(parents=True, exist_ok=True)

        tzone = DEFAULTS.local_tzone if self.use_local_tzone else timezone.utc
        run_tag = self.start_time.astimezone(tzone).strftime(time_format_files)
        tz_tag = "local" if self.use_local_tzone else "utc"
        short_id = uuid4().hex[:8]

        file_path = directory_path / f"passes_{tz_tag}_{run_tag}{short_id}.csv"

        columns = ["pass_id",
                   "pass_number", 
                   "sat_id", 
                   "sat_rise_time", 
                   "sat_set_time", 
                   "pass_duration", 
                   "max_elevation", 
                   "sat_name", 
                   "pass_state",
                   "fpga_image",
                   "tx_source",
                   "dl_fc_mhz",
                   "dl_bw_mhz",
                   "dl_modcod",
                   "ul_fc_mhz",
                   "ul_modcod",
                   "comment",
                   "elevation_mask", 
                   "rising_azimuth", 
                   "setting_azimuth"]

        with open(file_path, "w", newline="", encoding="utf-8") as f:

            writer = csv.DictWriter(f, fieldnames=columns)
            writer.writeheader()
            all_passes = []
            
            for sat_id, passes in self.satellite_passes.items():
                sat_name = self.tle_db[sat_id]['name']

                for index, p in enumerate(passes, start=1):
                    
                    if p.is_circumpolar:
                        # For circumpolar, times/duration aren’t applicable, fill only what matters
                        row = {
                            "pass_id": -1,
                            "pass_number": index,
                            "sat_id": sat_id,
                            "sat_rise_time": "",
                            "sat_set_time": "",
                            "pass_duration": "",
                            "max_elevation": round(p.max_elv),
                            "sat_name": sat_name,
                            "pass_state": "SCHEDULED_PENDING",
                            "fpga_image": "",
                            "tx_source": "",
                            "dl_fc_mhz": "",
                            "dl_bw_mhz": "",
                            "dl_modcod": "",
                            "ul_fc_mhz": "",
                            "ul_modcod": "",
                            "comment": "",
                            "elevation_mask": round(p.horizon),
                            "rising_azimuth": round(p.rising_az),
                            "setting_azimuth": round(p.setting_az),
                            "_rise_dt": None,
                            "_is_circ": True

                        }
                    else:
                        #Non-circumpolar: include times and duration
                        tzone = DEFAULTS.local_tzone if self.use_local_tzone else pytz.timezone("UTC")
                        rise_str = p.sat_rise_time.astimezone(tzone).strftime(time_format_tzone)
                        set_str = p.sat_set_time.astimezone(tzone).strftime(time_format_tzone)
                        dur_min = round((p.sat_set_time - p.sat_rise_time).total_seconds() / 60.0, 2)

                        row = {
                            "pass_id": -1,
                            "pass_number": index,
                            "sat_id": sat_id,
                            "sat_rise_time": rise_str,
                            "sat_set_time": set_str,
                            "pass_duration": dur_min,
                            "max_elevation": round(p.max_elv),
                            "sat_name": sat_name,
                            "pass_state": "SCHEDULED_PENDING",
                            "fpga_image": "",
                            "tx_source": "",
                            "dl_fc_mhz": "",
                            "dl_bw_mhz": "",
                            "dl_modcod": "",
                            "ul_fc_mhz": "",
                            "ul_modcod": "",
                            "comment": "",
                            "elevation_mask": round(p.horizon),
                            "rising_azimuth": round(p.rising_az),
                            "setting_azimuth": round(p.setting_az),
                            "_rise_dt": p.sat_rise_time,
                            "_is_circ": False
                            
                        }

                    all_passes.append(row)

            #sort 
            all_passes.sort(key=lambda r: (r["_is_circ"], r["_rise_dt"] if r["_rise_dt"] is not None else datetime.max.replace(tzinfo=timezone.utc)))
            for row in all_passes:
                row.pop("_rise_dt", None)
                row.pop("_is_circ", None)
                writer.writerow(row)
        
        print(f"All passes have been successfully written and stored in ({file_path})")
        return file_path


    def summary(self):
        """ Print summary of satellite passes to the console

        Args: None

        Returns: None
        """        

        print("\n\n             --- Summary ---")       
        print(f"{len(self.satellite_passes)} of {len(self.tle_db)} satellites will pass between")
        print("{} and {} hours".format(
            self.start_time.strftime(time_format_tzone), 
            self.end_time.strftime(time_format_tzone)))
        print("{} and {} hours".format(
            self.start_time.astimezone(DEFAULTS.local_tzone).strftime(time_format_tzone), 
            self.end_time.astimezone(self.tzone).strftime(time_format_tzone)))        
        print("\nSat ID | First Obser. | Max El")
        print("-------+--------------+--------")
        all_passes = []
        for sat_id in self.satellite_passes:
            sat_name = self.tle_db[sat_id]['name']
            passes = self.satellite_passes[sat_id]
            num_passes = len(passes)
            sat_info_str = f"Sat ID {sat_id} {sat_name}: {num_passes:d} Passes\n"
            for pass_info in passes:
                sat_info_str = (f"{sat_info_str} {pass_info.get_str(self.use_local_tzone)}\n" )
                if not pass_info.is_circumpolar:
                    all_passes.append(pass_info)
            print(sat_info_str)

        print()
        print("Current Time ") 
        print(self.start_time.astimezone(self.tzone).strftime(time_format_tzone))
        print("Passes in Order")        
        print("-------+--------------+--------")   
        all_passes.sort(key=lambda pass_inf: pass_inf.sat_rise_time)     
        for pass_info in all_passes:
            sat_name = self.tle_db[pass_info.sat_id]['name']
            sat_info_str = f"Sat ID {pass_info.sat_id} {sat_name}: "            
            print(f"{sat_info_str:<{30}} {pass_info.get_str(self.use_local_tzone)}")
            # print("{:<20} {}".format(sat_info_str, pass_info.get_str())) 

def add_sat_to_db():
    parser = argparse.ArgumentParser(description = 'Add new Satellite TLE to the dB CSV')
    parser.add_argument('id', type=int, help="Sat ID")
    parser.add_argument('-sf', '--satfile', default = '~/ground_station/config/sat_db.csv',                         
                        type=str, help = 'Path to YAML file containing satellite info, default: ~/ground_station/config/sat_db.csv')

    args = parser.parse_args()
    sat_file = Path(args.satfile).expanduser() 
     
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)
    
    tle_df = pd.read_csv(sat_file)
    
    tle_db = tle_df.set_index('norad_id').to_dict("index")
    new_tle_db, db_updated = add_new_tle(args.id, tle_db)
    if db_updated:
        updated_df = pd.DataFrame(new_tle_db).transpose().reset_index().rename(columns={'index':'norad_id'})
        updated_df.to_csv(sat_file, index=False)      
        
def del_sat_from_db():
    parser = argparse.ArgumentParser(description = 'Remove TLE from satellite dB CSV')
    parser.add_argument('id', type=int, help="Sat ID")
    parser.add_argument('-sf', '--satfile', default = '~/ground_station/config/sat_db.csv',                         
                        type=str, help = 'Path to YAML file containing satellite info, default: ~/ground_station/config/sat_db.csv')

    args = parser.parse_args()
    sat_file = Path(args.satfile).expanduser() 
     
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)
    
    tle_df = pd.read_csv(sat_file)
    
    tle_db = tle_df.set_index('norad_id').to_dict("index")
    new_tle_db, db_updated = del_tle(args.id, tle_db)
    if db_updated:
        updated_df = pd.DataFrame(new_tle_db).transpose().reset_index().rename(columns={'index':'norad_id'})
        updated_df.to_csv(sat_file, index=False)                        

def main():        
    parser = argparse.ArgumentParser(description = 'Satellite Pass Finder')
    parser.add_argument('-config', default = str(default_cfg), type=str, 
                        help = 'Config File. Defaults to {}'.format(str(default_cfg)))    
    parser.add_argument('-sf', '--satfile', default = str(default_sat_db), 
                        type=str, help = 'Path to YAML file containing satellite info, default:{}'.format(str(default_sat_db)))
    parser.add_argument('--duration', '-d', default = DEFAULTS.pass_finder_span,
                        type= float, help = 'Time span to look over (days), defaults to {:.1f} days'.format(DEFAULTS.pass_finder_span))    
    parser.add_argument('--elmask', '-e', default = DEFAULTS.elev_mask,
                        type= float, help = 'Elevation mask (degrees, float), defaults to {:.1f} deg'.format(DEFAULTS.elev_mask))  
    parser.add_argument('--sids', nargs="*", 
                        type=int, default=None, 
                        help='list of NORAD IDs to print pass info pass e.g) --sids 63231 42960 44387. If none are specified, prints info for all satellites in the sat_db file ')       
    parser.add_argument('--gnss', action='store_true', 
                        help="If true, passes for GNSS satellites will be calculated. By default these are excluded.") 
    parser.add_argument('--sband-radar', action='store_true', 
                        help="If true, only calculate passes for satellites with S band radar signals")         
    parser.add_argument('--lband-weather', action='store_true', 
                        help="If true, only calculate passes for weather sats with L band downlinks")        
    parser.add_argument('--local', action='store_true', 
                        help="If true, console will print out times in local (Eastern) time. Default behavior is in UTC")   
    parser.add_argument('--at', default=None, 
                        help="Find passes over given locale, specified in config. Default is ground station locale")
    parser.add_argument('--to_csv', action='store_true', 
                        help="If true, the generated passes will be stored in a well-defined CSV file stored in /logs/runsheets ")   
    
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)    
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)
    args = parser.parse_args()
    
    all_pass_finder = PassFinder(
        args.satfile, 
        args.config, 
        time_window_days=args.duration,
        el_mask_deg=args.elmask, 
        include_gnss=args.gnss, 
        use_local_tzone = args.local,
        norad_ids=args.sids, 
        lband_noaa_mask=args.lband_weather, 
        sband_radar_mask=args.sband_radar,
        at_locale=args.at,
        send_to_csv=args.to_csv)
    
    satellite_passes = all_pass_finder.run_sat_passes()
    
    if args.to_csv:
        all_pass_finder.generate_csv_file()
    else:
        all_pass_finder.summary()


if __name__ == "__main__":
    main()


        
