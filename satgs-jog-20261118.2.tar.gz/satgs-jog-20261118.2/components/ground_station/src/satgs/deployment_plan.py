"""Pure, selection-only deployment planning over the validated preset records."""

from dataclasses import asdict, dataclass
import json
import re
from typing import Any

from satgs.deployment import ComponentInstance, DeploymentManifest


class InputError(ValueError):
    """An input does not satisfy the supported planning contract."""


@dataclass(frozen=True, slots=True)
class _Document:
    _json: str

    def to_dict(self) -> dict[str, Any]:
        return json.loads(self._json)


class Configuration(_Document):
    __slots__ = ()


class Inventory(_Document):
    __slots__ = ()


class ReleaseRequirements(_Document):
    __slots__ = ()


class PlanResult(_Document):
    __slots__ = ()

    @property
    def blocked(self) -> bool:
        return self.to_dict()["blocked"]


@dataclass(frozen=True, slots=True)
class Catalog:
    manifest: DeploymentManifest

    def to_dict(self) -> dict[str, Any]:
        components = _components(self)
        return _plain({
            "schema_version": 1,
            "planning_only": True,
            "apply_supported": False,
            "profiles": [asdict(p) for p in self.manifest.profiles],
            "components": [components[key] for key in sorted(components)],
        })


def _plain(value: Any) -> Any:
    return json.loads(json.dumps(value, sort_keys=True, ensure_ascii=True))


def _record(cls: type[_Document], value: dict[str, Any]) -> Any:
    return cls(json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")))


def build_catalog(manifest: DeploymentManifest) -> Catalog:
    """Project records already validated by deployment.load_manifest; perform no I/O."""
    if not isinstance(manifest, DeploymentManifest):
        raise InputError("catalog requires a validated DeploymentManifest")
    return Catalog(manifest)


def _components(catalog: Catalog) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for profile in catalog.manifest.profiles:
        for package in profile.packages:
            result.setdefault(package.id, {
                "id": package.id, "kind": "software", "providers": ["repository"],
                "external_providers": [],
            })
        for capability in profile.capabilities:
            kind = ("hardware" if capability.provider.endswith("hardware") else
                    "system" if capability.provider == "system" else "capability")
            entry = result.setdefault(capability.id, {
                "id": capability.id, "kind": kind, "providers": [],
                "external_providers": [],
            })
            if capability.applicability == "included" and capability.supported:
                entry["providers"].append(capability.provider)
                entry["kind"] = kind
            elif capability.applicability == "external":
                entry["external_providers"].append(capability.provider)
    for entry in result.values():
        entry["providers"] = sorted(set(entry["providers"]))
        entry["external_providers"] = sorted(set(entry["external_providers"]))
    return result


def _profile(catalog: Catalog, identity: str) -> Any:
    for profile in catalog.manifest.profiles:
        if profile.id == identity:
            return profile
    raise InputError("preset must name a built-in profile")


def validate_document_structure(value: Any) -> None:
    """Count containers, keys and values; allow at most 32 nested containers."""
    stack = [(value, 0)]
    nodes = 0
    while stack:
        item, depth = stack.pop()
        nodes += 1
        if depth > 32 or nodes > 8192 or (isinstance(item, (dict, list)) and depth >= 32):
            raise InputError("input exceeds structure limits (depth 32, nodes 8192)")
        if isinstance(item, dict):
            if len(item) > 64 or any(type(k) is not str or len(k) > 80 for k in item):
                raise InputError("input object exceeds field limits")
            stack.extend((key, depth + 1) for key in item)
            stack.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, list):
            if len(item) > 1024:
                raise InputError("input list exceeds 1024 entries")
            stack.extend((child, depth + 1) for child in item)
        elif isinstance(item, str):
            if len(item) > 256 or not item.isprintable():
                raise InputError("input text must be printable and at most 256 characters")
        elif item is not None and type(item) not in (int, bool):
            raise InputError("input contains an unsupported value type")


def _object(value: Any, required: set[str], optional: set[str] = frozenset()) -> dict:
    if type(value) is not dict or not required <= value.keys() or value.keys() - required - optional:
        raise InputError("record has missing required fields or unknown fields")
    return value


def _id(value: Any) -> str:
    if type(value) is not str or re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,79}", value) is None:
        raise InputError("identifiers must be 1-80 lowercase letters, digits, dots, underscores or hyphens")
    return value


def _optional_id(value: Any) -> str | None:
    return None if value is None else _id(value)


def _integer(value: Any) -> int:
    if type(value) is not int or not 1 <= value <= 1_000_000_000:
        raise InputError("schema and revision values must be positive bounded integers")
    return value


def _schema(value: Any) -> None:
    if _integer(value) != 1:
        raise InputError("unsupported document schema_version; expected 1")


def _list(value: Any) -> list:
    if type(value) is not list:
        raise InputError("expected a JSON array")
    return value


def _ids(value: Any) -> list[str]:
    values = [_id(item) for item in _list(value)]
    if len(set(values)) != len(values):
        raise InputError("duplicate identifier in array")
    return sorted(values)


def _unique(items: list[dict], key: str) -> list[dict]:
    if len({item[key] for item in items}) != len(items):
        raise InputError("duplicate record identifier")
    return sorted(items, key=lambda item: item[key])


def _target(value: Any) -> dict:
    value = _object(value, {"id", "environment"})
    return {"id": _id(value["id"]), "environment": _id(value["environment"])}


def _instance_contract(catalog: Catalog) -> tuple[set[tuple[str, str]], dict[str, set[str]]]:
    allowed: set[tuple[str, str]] = set()
    ownership: dict[str, set[str]] = {}
    for profile in catalog.manifest.profiles:
        instances = {item.id: item for item in profile.instances}
        allowed.update((item.component, item.provider) for item in profile.instances)
        for cap in profile.capabilities:
            for identity in cap.instance_ids:
                ownership.setdefault(cap.id, set()).add(instances[identity].component)
    return allowed, ownership


def parse_configuration(data: dict, catalog: Catalog) -> Configuration:
    validate_document_structure(data)
    return _parse_configuration(data, catalog)


def _parse_configuration(data: dict, catalog: Catalog) -> Configuration:
    data = _object(data, {"schema_version", "id", "revision", "target", "selections"},
                   {"preset", "release_id", "host_roles", "instances"})
    _schema(data["schema_version"])
    preset = _optional_id(data.get("preset"))
    if preset is not None:
        _profile(catalog, preset)
    roles = _ids(data.get("host_roles", []))
    known_roles = {role for p in catalog.manifest.profiles for role in p.host_roles}
    if not set(roles) <= known_roles:
        raise InputError("unknown host role")
    allowed, ownership = _instance_contract(catalog)
    instances = []
    for raw in _list(data.get("instances", [])):
        item = _object(raw, {"id", "component", "provider"})
        instance = ComponentInstance(*(_id(item[key]) for key in ("id", "component", "provider")))
        if (instance.component, instance.provider) not in allowed:
            raise InputError("unsupported instance component/provider contract")
        instances.append(asdict(instance))
    instances = _unique(instances, "id")
    by_instance = {item["id"]: item for item in instances}
    components = _components(catalog)
    selections = []
    referenced = set()
    for raw in _list(data["selections"]):
        item = _object(raw, {"component", "mode", "provider"}, {"instance_ids"})
        identity = _id(item["component"])
        if identity not in components:
            raise InputError("selection names an unknown catalog component")
        mode = item["mode"]
        if mode not in ("install", "reuse", "external", "omit"):
            raise InputError("mode must be install, reuse, external or omit")
        provider = _id(item["provider"])
        spec = components[identity]
        providers = spec["external_providers"] if mode == "external" else spec["providers"]
        if mode == "omit":
            providers = providers + spec["external_providers"]
        if provider not in providers:
            raise InputError("unsupported provider for component mode")
        instance_ids = _ids(item.get("instance_ids", []))
        for instance_id in instance_ids:
            if instance_id not in by_instance:
                raise InputError("selection refers to an unknown instance")
            if by_instance[instance_id]["component"] not in ownership.get(identity, set()):
                raise InputError("instance identity is inconsistent with selected component")
            if spec["kind"] == "hardware" and by_instance[instance_id]["provider"] != provider:
                raise InputError("instance provider does not match hardware selection")
        referenced.update(instance_ids)
        selections.append({"component": identity, "mode": mode, "provider": provider,
                           "instance_ids": instance_ids})
    if set(by_instance) - referenced:
        raise InputError("instance is not referenced by an explicit selection")
    return _record(Configuration, {
        "schema_version": 1, "id": _id(data["id"]), "revision": _integer(data["revision"]),
        "preset": preset, "release_id": _optional_id(data.get("release_id")),
        "target": _target(data["target"]), "host_roles": roles, "instances": instances,
        "selections": _unique(selections, "component"),
    })


def expand_preset(catalog: Catalog, preset: str) -> Configuration:
    profile = _profile(catalog, preset)
    selections = [{"component": package.id, "mode": "install", "provider": "repository"}
                  for package in profile.packages]
    selections.extend({"component": cap.id,
                       "mode": "external" if cap.applicability == "external" else "install",
                       "provider": cap.provider, "instance_ids": list(cap.instance_ids)}
                      for cap in profile.capabilities)
    return parse_configuration({
        "schema_version": 1, "id": preset, "revision": 1, "preset": preset,
        "target": {"id": "unspecified", "environment": "unknown"},
        "host_roles": list(profile.host_roles),
        "instances": [asdict(instance) for instance in profile.instances],
        "selections": selections,
    }, catalog)


def parse_inventory(data: dict, catalog: Catalog) -> Inventory:
    validate_document_structure(data)
    return _parse_inventory(data, catalog)


def _parse_inventory(data: dict, catalog: Catalog) -> Inventory:
    data = _object(data, {"schema_version", "id", "target", "entries"})
    _schema(data["schema_version"])
    components = _components(catalog)
    entries = []
    for raw in _list(data["entries"]):
        item = _object(raw, {"component", "provider", "presence"},
                       {"instance_ids", "release_id", "revision", "compatibility", "fresh",
                        "source", "runtime_state"})
        identity = _id(item["component"])
        provider = _id(item["provider"])
        if identity not in components or provider not in components[identity]["providers"]:
            raise InputError("inventory component/provider is not supported by the catalog")
        if item["presence"] not in ("present", "absent", "unknown"):
            raise InputError("inventory presence must be present, absent or unknown")
        if type(item.get("fresh", False)) is not bool:
            raise InputError("inventory fresh must be a boolean assertion")
        runtime = item.get("runtime_state", "unknown")
        if runtime not in ("unknown", "connected", "disconnected"):
            raise InputError("unsupported inventory runtime_state")
        entries.append({"component": identity, "provider": provider,
                        "instance_ids": _ids(item.get("instance_ids", [])),
                        "presence": item["presence"], "fresh": item.get("fresh", False),
                        "source": _optional_id(item.get("source")), "runtime_state": runtime,
                        **{key: _optional_id(item.get(key))
                           for key in ("release_id", "revision", "compatibility")}})
    return _record(Inventory, {"schema_version": 1, "id": _id(data["id"]),
                              "target": _target(data["target"]),
                              "entries": _unique(entries, "component")})


def parse_requirements(data: dict, catalog: Catalog) -> ReleaseRequirements:
    validate_document_structure(data)
    return _parse_requirements(data, catalog)


def _parse_requirements(data: dict, catalog: Catalog) -> ReleaseRequirements:
    data = _object(data, {"schema_version", "release_id", "configuration_schema", "environment", "components"},
                   {"removed_components"})
    _schema(data["schema_version"])
    known = _components(catalog)
    components = []
    for raw in _list(data["components"]):
        item = _object(raw, {"component", "kind", "requires", "source"}, {"revision", "compatibility"})
        identity = _id(item["component"])
        kind = item["kind"]
        if kind not in ("software", "system", "capability", "hardware"):
            raise InputError("unsupported release component kind")
        if identity in known and kind != known[identity]["kind"]:
            raise InputError("release component kind conflicts with the existing catalog")
        components.append({"component": identity, "kind": kind, "requires": _ids(item["requires"]),
                           "source": _id(item["source"]),
                           "revision": _optional_id(item.get("revision")),
                           "compatibility": _optional_id(item.get("compatibility"))})
    components = _unique(components, "component")
    removed = _ids(data.get("removed_components", []))
    ids = set(known) | {item["component"] for item in components}
    if set(removed) - ids or set(removed) & {item["component"] for item in components}:
        raise InputError("removed component references are unknown or contradictory")
    if any(set(item["requires"]) - ids for item in components):
        raise InputError("release prerequisite refers to an unresolved component")
    return _record(ReleaseRequirements, {
        "schema_version": 1, "release_id": _id(data["release_id"]),
        "configuration_schema": _integer(data["configuration_schema"]),
        "environment": _id(data["environment"]), "components": components,
        "removed_components": removed,
    })


# These are selection prerequisites, not a Python dependency lock. Runtime-only
# import cycles and owner/target qualification remain explicit gaps below.
_PREREQUISITES = (
    ("ground_station", "meteor-api", "python-declaration", "ground_station/pyproject.toml:8"),
    ("sat_tracker", "serialptu", "source-import", "sat_tracker/src/ptu_control/ptu_manager.py:17-19"),
    ("sat_tracker", "meteor-api", "source-import", "sat_tracker/src/ptu_control/ptu_manager.py:17-19"),
    ("sat_tracker", "ground_station", "source-import", "sat_tracker/src/ptu_control/ptu_manager.py:31-32"),
    ("pixhawk", "meteor-api", "source-import", "pixhawk/src/pixhawk/pixhawk_manager.py:9"),
    ("pixhawk", "ground_station", "source-import", "pixhawk/src/pixhawk/pixhawk_manager.py:18"),
    ("pointing.ptu", "sat_tracker", "service-program", "ground_station/etc/systemd/ptu.service"),
    ("pointing.pixhawk", "pixhawk", "service-program", "ground_station/etc/systemd/pixhawk.service"),
    ("orchestration.queue_manager", "ground_station", "service-program", "ground_station/etc/systemd/ground_station.service:9"),
    ("orchestration.queue_manager", "recording.signal_hound", "required-operation", "ground_station/src/satgs/queue_manager.py:739-740"),
    ("orchestration.queue_manager", "processing.msel_post_processing", "required-operation", "ground_station/src/satgs/queue_manager.py:773-779"),
    ("execution.pass_runner", "ground_station", "module-owner", "ground_station/src/satgs/pass_runner.py"),
    ("orbit.pass_finder", "ground_station", "module-owner", "ground_station/src/satgs/pass_finder.py"),
    ("pointing.qpt130", "pointing.ptu", "managed-hardware", "sat_tracker/src/ptu_control/ptu_manager.py:1018-1054"),
    ("pointing.dual_gps", "pointing.pixhawk", "managed-hardware", "pixhawk/src/pixhawk/pixhawk_manager.py:87-90"),
    ("rf.frontend", "dsi_instruments", "service-program", "ground_station/etc/systemd/frontend.service:7"),
    ("rf.frontend", "dsi_instruments", "source-import", "ground_station/src/satgs/pass_runner.py:PassRunner._initialize_frontend"),
    ("power.pdu_hpa", "cyberpowerpdu", "service-program", "ground_station/etc/systemd/cyberpower_pdu.service:7"),
    ("power.pdu_hpa", "cyberpowerpdu", "source-import", "ground_station/src/satgs/pass_runner.py:PassRunner._initialize_pdu"),
    ("recording.signal_hound", "signal_hound", "service-program", "ground_station/etc/systemd/sh_iq_logger.service:8"),
    ("recording.signal_hound", "signal_hound", "source-import", "ground_station/src/satgs/pass_runner.py:PassRunner._initialize_iq_recorder"),
    ("recording.signal_hound", "signal_hound", "source-import", "ground_station/src/satgs/pass_runner.py:PassRunner._initialize_trace_logger"),
    ("recording.signal_hound", "signal_hound_native_wrapper", "source-import", "signal_hound/src/signal_hound_control/sh_manager.py:20"),
    ("processing.msel_post_processing", "msel_post_processing", "module-owner", "msel_post_processing/pyproject.toml:53-57"),
    ("dsi_instruments", "meteor-api", "source-import", "dsi_instruments/src/dsi/front_end_manager.py:17"),
    ("cyberpowerpdu", "meteor-api", "source-import", "cyberpowerpdu/src/cyberpowerpdu/pdu_manager.py:8"),
    ("signal_hound", "meteor-api", "source-import", "signal_hound/src/signal_hound_control/sh_manager.py:18"),
    ("signal_hound", "ground_station", "source-import", "signal_hound/src/signal_hound_control/sh_manager.py:19"),
    ("msel_post_processing", "ground_station", "source-import", "msel_post_processing/src/post_processing/quick_look.py:24-27"),
    ("msel_post_processing", "sat_tracker", "source-import", "msel_post_processing/src/post_processing/quick_look.py:24-27"),
    ("pointing.ptu", "broker.activemq", "operational-service", "sat_tracker/src/ptu_control/ptu_client.py:476"),
    ("pointing.pixhawk", "broker.activemq", "operational-service", "pixhawk/src/pixhawk/pixhawk_manager.py:350"),
    ("orchestration.queue_manager", "broker.activemq", "operational-service", "ground_station/src/satgs/queue_manager.py:900"),
    ("rf.frontend", "broker.activemq", "operational-service", "dsi_instruments/src/dsi/front_end_manager.py:374"),
    ("power.pdu_hpa", "broker.activemq", "operational-service", "cyberpowerpdu/src/cyberpowerpdu/pdu_manager.py:278"),
    ("recording.signal_hound", "broker.activemq", "operational-service", "signal_hound/src/signal_hound_control/sh_manager.py:561"),
)


def _diagnostic(code: str, message: str, component: str | None = None,
                severity: str = "error") -> dict:
    return {"code": code, "severity": severity, "component": component, "message": message}


def _preset_checks(config: dict, catalog: Catalog) -> list[dict]:
    if config["preset"] is None:
        return []
    profile = _profile(catalog, config["preset"])
    expected = expand_preset(catalog, profile.id).to_dict()
    selections = {item["component"]: item for item in config["selections"]}
    required = {item.id for item in profile.packages}
    required.update(cap.id for cap in profile.capabilities if cap.required_by_default)
    diagnostics = []
    expected_ids = {item["component"] for item in expected["selections"]}
    for identity in sorted(expected_ids - selections.keys()):
        diagnostics.append(_diagnostic("preset_scope", "Expanded preset records must stay explicit; use omit where permitted or choose Custom.", identity))
    for identity, item in selections.items():
        if identity not in expected_ids and item["mode"] != "omit":
            diagnostics.append(_diagnostic("preset_scope", "Additional selections require a Custom configuration, not a changed canonical preset.", identity))
    for item in expected["selections"]:
        actual = selections.get(item["component"])
        if item["component"] in required and (actual is None or actual["mode"] not in ("install", "reuse") or
                                              actual["provider"] != item["provider"] or
                                              actual["instance_ids"] != item["instance_ids"]):
            diagnostics.append(_diagnostic("preset_requirement", "Required preset selection changed; supply a Custom configuration instead.", item["component"]))
        elif actual is not None and actual["mode"] != "omit" and actual["provider"] != item["provider"]:
            diagnostics.append(_diagnostic("preset_provider", "Selection no longer matches this preset's provider contract.", item["component"]))
    if config["host_roles"] != expected["host_roles"] or config["instances"] != expected["instances"]:
        diagnostics.append(_diagnostic("preset_identity", "Preset roles and stable device instances must remain canonical; use Custom for different intent."))
    return diagnostics


def _cycle_nodes(graph: dict[str, set[str]]) -> list[str]:
    remaining = {key: set(value) for key, value in graph.items()}
    while remaining:
        leaves = {key for key, edges in remaining.items() if not edges & remaining.keys()}
        if not leaves:
            return sorted(remaining)
        remaining = {key: edges for key, edges in remaining.items() if key not in leaves}
    return []


def _managed_hardware_checks(selections: dict[str, dict]) -> list[dict]:
    diagnostics = []
    for parent, dependency, relation, _source in _PREREQUISITES:
        if relation != "managed-hardware" or parent not in selections or dependency not in selections:
            continue
        hardware, owner = selections[parent], selections[dependency]
        if hardware["mode"] in ("install", "reuse") and owner["instance_ids"] != hardware["instance_ids"]:
            diagnostics.append(_diagnostic("instance_conflict", "Managed hardware and its selected control/observer capability refer to different instances.", dependency))
    return diagnostics


def validate_selection_contract(configuration: Configuration, catalog: Catalog) -> list[dict]:
    """Validate selection identity, without claiming installation or runtime authority."""
    config = _parse_configuration(configuration.to_dict(), catalog).to_dict()
    components = _components(catalog)
    diagnostics = _preset_checks(config, catalog)
    for item in config["selections"]:
        if (config["preset"] is None and components[item["component"]]["kind"] == "hardware"
                and item["mode"] in ("install", "reuse") and not item["instance_ids"]):
            diagnostics.append(_diagnostic("hardware_identity", "Custom hardware requires explicit stable instance identifiers.", item["component"]))
    diagnostics.extend(_managed_hardware_checks({item["component"]: item for item in config["selections"]}))
    return diagnostics


def plan_configuration(configuration: Configuration, catalog: Catalog,
                       inventory: Inventory | None = None,
                       requirements: ReleaseRequirements | None = None) -> PlanResult:
    # Revalidate record semantics without charging schema defaults to raw-input budgets.
    config = _parse_configuration(configuration.to_dict(), catalog).to_dict()
    evidence = _parse_inventory(inventory.to_dict(), catalog).to_dict() if inventory is not None else None
    release = _parse_requirements(requirements.to_dict(), catalog).to_dict() if requirements is not None else None
    components = _components(catalog)
    required = {item["component"]: item for item in release["components"]} if release else {}
    diagnostics = validate_selection_contract(configuration, catalog)
    diagnostics.extend([
        _diagnostic("closure_incomplete", "Python dependencies, native/build artifacts and publisher trust are not resolved or verified.", severity="warning"),
        _diagnostic("runtime_cycles", "Source package cycles ground_station <-> sat_tracker and ground_station <-> pixhawk remain unresolved; owner contracts and target runtime integration remain unverified.", severity="warning"),
        _diagnostic("commissioning_required", "Broker readiness, synchronized time, architecture compatibility and physical commissioning are unverified.", severity="warning"),
    ])
    if release:
        if release["configuration_schema"] != config["schema_version"]:
            diagnostics.append(_diagnostic("schema_migration_required", "Candidate requires an unsupported configuration schema migration."))
        if release["environment"] != config["target"]["environment"] or release["environment"] == "unknown":
            diagnostics.append(_diagnostic("environment_mismatch", "Candidate environment does not establish compatibility with the explicit target."))
        for identity, item in required.items():
            components.setdefault(identity, {"id": identity, "kind": item["kind"],
                                             "providers": ["repository"] if item["kind"] == "software" else [],
                                             "external_providers": []})
    selections = {item["component"]: dict(item) for item in config["selections"]}
    explicit = set(selections)
    preset_packages = ({package.id for package in _profile(catalog, config["preset"]).packages}
                       if config["preset"] else None)
    reasons: dict[str, list[dict]] = {}
    edges = list(_PREREQUISITES)
    for identity, item in required.items():
        edges.extend((identity, dependency, "supplied-release", item["source"]) for dependency in item["requires"])
    edges = sorted(set(edges))
    graph: dict[str, set[str]] = {}
    pending = sorted(identity for identity, item in selections.items() if item["mode"] in ("install", "reuse"))
    visited = set()
    while pending:
        identity = pending.pop(0)
        if identity in visited:
            continue
        visited.add(identity)
        graph.setdefault(identity, set())
        for parent, dependency, relation, source in edges:
            if parent != identity:
                continue
            reason = {"required_by": parent, "relationship": relation, "source": source}
            if reason not in reasons.setdefault(dependency, []):
                reasons[dependency].append(reason)
            if dependency not in components:
                diagnostics.append(_diagnostic("unresolved_prerequisite", "Prerequisite is absent from the supplied catalog.", dependency))
                continue
            if dependency not in selections:
                spec = components[dependency]
                if (preset_packages is not None and spec["kind"] == "software"
                        and dependency not in preset_packages):
                    diagnostics.append(_diagnostic("preset_prerequisite", "Required software is excluded by this canonical preset; its intended configuration conflicts with current implementation requirements.", dependency))
                    continue
                if spec["kind"] == "hardware" or len(spec["providers"]) != 1:
                    diagnostics.append(_diagnostic("configuration_decision", "Required hardware or provider needs an explicit configuration decision.", dependency))
                    continue
                selections[dependency] = {"component": dependency, "mode": "install",
                                          "provider": spec["providers"][0],
                                          "instance_ids": list(selections[parent]["instance_ids"]) if relation == "managed-hardware" else []}
            selected = selections[dependency]
            if config["preset"]:
                profile = _profile(catalog, config["preset"])
                variant = next((cap for cap in profile.capabilities if cap.id == dependency), None)
                if variant and (variant.provider != selected["provider"] or not variant.supported):
                    diagnostics.append(_diagnostic("preset_prerequisite", "This preset does not support the required local capability/provider; external responsibility is not a connector.", dependency))
            if selected["mode"] in ("omit", "external"):
                diagnostics.append(_diagnostic("prerequisite_conflict", "Required prerequisite is explicitly omitted or only an unsupported external responsibility.", dependency))
            else:
                graph[identity].add(dependency)
                pending.append(dependency)
        pending.sort()
    diagnostics.extend(_managed_hardware_checks(selections))
    for identity in _cycle_nodes(graph):
        diagnostics.append(_diagnostic("dependency_cycle", "Selected prerequisite graph contains or depends on an unsupported cycle.", identity))
    entries = {item["component"]: item for item in evidence["entries"]} if evidence else {}
    outcomes = []
    for identity in sorted(selections):
        selection = selections[identity]
        mode = selection["mode"]
        entry = entries.get(identity)
        applicable = bool(entry and evidence["target"] == config["target"] and
                          config["target"]["id"] != "unspecified" and
                          config["target"]["environment"] != "unknown" and entry["fresh"] and entry["source"] and
                          entry["provider"] == selection["provider"] and entry["instance_ids"] == selection["instance_ids"])
        presence = entry["presence"] if applicable else "unknown"
        outcome = {"omit": "omitted", "external": "external_responsibility",
                   "install": "proposed_install", "reuse": "conflict"}[mode]
        if mode == "external":
            diagnostics.append(_diagnostic("external_not_connector", "Sponsor responsibility is declared; no supported connector or readiness is established.", identity, "warning"))
        if mode != "omit" and release and identity in release["removed_components"]:
            diagnostics.append(_diagnostic("removed_component", "Candidate removes a selected or required component; explicit migration is required.", identity))
        if mode in ("install", "reuse"):
            requirement = required.get(identity)
            if release and (requirement is None or not requirement["revision"] or not requirement["compatibility"]):
                diagnostics.append(_diagnostic("compatibility_unknown", "Candidate must supply revision and compatibility requirements for each selected or derived component.", identity))
            if mode == "reuse":
                compatible = bool(applicable and presence == "present" and release and requirement and
                                  release["configuration_schema"] == config["schema_version"] and
                                  release["environment"] == config["target"]["environment"] and
                                  requirement["revision"] and requirement["compatibility"] and
                                  entry["release_id"] == release["release_id"] and
                                  entry["revision"] == requirement["revision"] and
                                  entry["compatibility"] == requirement["compatibility"])
                if compatible:
                    outcome = "proposed_reuse"
                else:
                    diagnostics.append(_diagnostic("reuse_unproven", "Reuse requires fresh supplied evidence matching target, provider, instances, candidate release, revision and compatibility.", identity))
            elif components[identity]["kind"] == "hardware":
                outcome = "commissioning_required"
            elif presence == "present":
                outcome = "conflict"
                diagnostics.append(_diagnostic("existing_installation", "Supplied evidence reports an existing installation; explicitly choose compatible reuse or resolve intent.", identity))
            if presence == "unknown":
                diagnostics.append(_diagnostic("inventory_unknown", "Presence is unknown; no discovery or successful verification is implied.", identity, "warning"))
        outcomes.append({**selection, "derived": identity not in explicit,
                         "reasons": sorted(reasons.get(identity, []), key=lambda reason: (reason["required_by"], reason["relationship"], reason["source"])),
                         "presence": presence, "runtime_state": entry["runtime_state"] if applicable else "unknown",
                         "outcome": outcome})
    diagnostics = sorted({json.dumps(item, sort_keys=True): item for item in diagnostics}.values(),
                         key=lambda item: (item["severity"], item["code"], item["component"] or "", item["message"]))
    return _record(PlanResult, {
        "schema_version": 1, "operation": "plan", "planning_only": True,
        "apply_supported": False, "complete": False,
        "blocked": any(item["severity"] == "error" for item in diagnostics),
        "configuration": config, "candidate_release_id": release["release_id"] if release else None,
        "inventory_id": evidence["id"] if evidence else None,
        "preset_definition": asdict(_profile(catalog, config["preset"])) if config["preset"] else None,
        "derived_requirements": [{"component": identity, "reasons": sorted(items, key=lambda reason: (reason["required_by"], reason["relationship"], reason["source"]))}
                                 for identity, items in sorted(reasons.items())],
        "outcomes": outcomes, "diagnostics": diagnostics,
    })


def compare_release(configuration: Configuration, catalog: Catalog,
                    requirements: ReleaseRequirements,
                    inventory: Inventory | None = None) -> PlanResult:
    result = plan_configuration(configuration, catalog, inventory, requirements).to_dict()
    candidate = _parse_requirements(requirements.to_dict(), catalog).to_dict()
    selected = {item["component"] for item in result["configuration"]["selections"] if item["mode"] in ("install", "reuse")}
    considered = {item["component"] for item in result["outcomes"] if item["mode"] in ("install", "reuse")}
    needed = {item["component"] for item in result["derived_requirements"]}
    entries = {item["component"]: item for item in candidate["components"]}
    changes = []
    for identity in sorted(considered):
        changes.append({"component": identity, "kind": "selected_requirement" if identity in selected else "required_software",
                        "detail": entries.get(identity)})
    for identity in sorted(needed - considered):
        kind = "required_hardware" if entries.get(identity, {}).get("kind") == "hardware" else "requirement_decision"
        changes.append({"component": identity, "kind": kind, "detail": entries.get(identity)})
    result.update({"operation": "compare", "changes": changes,
                   "unselected_optional": sorted(set(entries) - considered - needed)})
    return _record(PlanResult, result)


def render_json(record: Catalog | _Document) -> str:
    return json.dumps(record.to_dict(), sort_keys=True, ensure_ascii=True, indent=2)


def render_human(record: Catalog | _Document) -> str:
    data = record.to_dict()
    lines = ["SATGS planning only. Apply is unsupported; this is not an executable installation plan."]
    if "outcomes" not in data:
        lines.append(render_json(record))
        return "\n".join(lines)
    config = data["configuration"]
    lines.append(f"Configuration: {config['id']} revision {config['revision']} (preset: {config['preset'] or 'Custom'})")
    lines.append(f"Schema: {config['schema_version']}; target: {config['target']['id']} / {config['target']['environment']}; current release: {config['release_id'] or 'unknown'}")
    lines.append("Host roles: " + (", ".join(config["host_roles"]) or "unspecified"))
    for instance in config["instances"]:
        lines.append(f"Instance: {instance['id']} / {instance['component']} / {instance['provider']}")
    lines.append(f"Candidate: {data['candidate_release_id'] or 'unknown'}; inventory: {data['inventory_id'] or 'unknown'}")
    lines.append(f"Blocked: {data['blocked']}; complete: False")
    reason_lines = {
        item["component"]: [f"  required by {reason['required_by']}: {reason['relationship']} [{reason['source']}]"
                            for reason in item["reasons"]]
        for item in data["derived_requirements"]
    }
    for item in data["outcomes"]:
        origin = "derived" if item["derived"] else "explicit"
        lines.append(f"{item['component']}: {item['outcome']} ({origin}, mode {item['mode']}, provider {item['provider']}, presence {item['presence']}, runtime {item['runtime_state']})")
        if item["instance_ids"]:
            lines.append("  instances: " + ", ".join(item["instance_ids"]))
        lines.extend(reason_lines.pop(item["component"], []))
    for identity, explanations in sorted(reason_lines.items()):
        lines.append(f"{identity}: required (no selected outcome)")
        lines.extend(explanations)
    for item in data["diagnostics"]:
        lines.append(f"{item['severity']}: {item['code']} {item['component'] or ''}: {item['message']}")
    if data.get("unselected_optional"):
        lines.append("Unselected optional candidates: " + ", ".join(data["unselected_optional"]))
    for change in data.get("changes", []):
        lines.append("Candidate requirement: " + json.dumps(change, sort_keys=True, ensure_ascii=True))
    return "\n".join(lines)
