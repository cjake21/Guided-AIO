import logging
import time
import signal
import yaml
from pathlib import Path
from datetime import datetime, timezone, timedelta
import shutil
import csv
import re
import numbers
from meteor_api.messenger import Messenger
from dsi.front_end_client import FrontEndClient
from pixhawk.pixhawk_subscriber import PixhawkSubscriber
import pixhawk.pixhawk_subscriber
from ptu_control.ptu_client import PtuClient
from cyberpowerpdu.pdu_client import PduClient
from cyberpowerpdu.utils import OutletState
import numpy as np
from satgs.utils import find_passes, PassInfo, check_meteor_services, determine_filename, AzElTrajectory
from satgs.constants import DEFAULTS, time_format_print, time_format_short

EL_RATE = 3 #deg/sec
DEFAULT_CFG = Path('~/ground_station/config/config.yaml').expanduser()

class ArbitraryPassRunner:
    '''
    '''
    def __init__(self, config_file:Path, trajectory:AzElTrajectory,
                logname:str, log_dir:Path, 
                el_mask:float=DEFAULTS.elev_mask, 
                use_ref_time:bool=False, 
                pass_info:PassInfo=None,
                noptu:bool=False, 
                nopixhawk:bool=False,
                nopdu:bool=False):
        """Constructor

        Args:

        """
        self.config_file = config_file
        # Load config File
        with open(config_file) as f:
            self.config = yaml.safe_load(f)        
        
        self.park_est_time = 45        
        self.el_mask = el_mask
        self.use_ref_time = use_ref_time
        self.nopixhawk = nopixhawk
        self.noptu = noptu
        self.nopdu = nopdu
        
        self.trajectory = trajectory
        self.logname = logname 
        self.log_dir = log_dir 
      
        if '~' in str(self.log_dir):
            self.log_dir = Path(str(self.log_dir).replace('~', self.config['home_directory']))            
            # Since pass_runner may be exectuted by systemd, expanduser() evaluates to /root, which we dont want. 
        logging.info("Log Directory: {}".format(self.log_dir))    
        
        if not self.log_dir.exists():
            logging.debug("Directory does not exsist, creating it")
            for parent in reversed(self.log_dir.parents):
                parent.mkdir(mode=0o775, exist_ok=True)            
            
        self.sat_log = open(self.log_dir / "sat_truth_pos.csv", 'w+')
        self.csv_writer = csv.writer(self.sat_log, delimiter=',')
        self.csv_writer.writerow(['utc_time', 'azimuth', 'elevation'])
        if pass_info is not None:
            with open(self.log_dir / "tle.txt", "w+") as file:
                file.write(pass_info.sat_tle.tle_str)
        
        self.credentials = {"username": self.config["amq_username"], 
                            "password": self.config["amq_password"]}
        
        # Connect component HW                           
        # Pixhawk
        if (not self.nopixhawk):
            logging.info("Connecting to Pixhawk for Dish Logging....")            
            try:                
                pixhawk_messenger = Messenger(
                    self.config['amq_server'], self.config['amq_port'], 
                    self.credentials, use_ssl=self.config['amq_use_ssl'], 
                    reconnect_attempts_max=5)
            except:
                logging.error("Could not connect active MQ server....")
                
            self.pixhawk = PixhawkSubscriber(pixhawk_messenger, config = self.config_file, filename= self.log_dir/'pixhawk_log.csv', standalone=False)    
            if self.pixhawk.check_connection():
                logging.info("Pixhawk Client Ready")                
            else:
                logging.info("Pixhawk client didnt get response from manager, pixhawk_pub.service may not be running or crashed")       
                               
            # Setup this logger to log to specific file at debug level
            pixhawk_logger = logging.getLogger(pixhawk.pixhawk_subscriber.__name__) #logging.getLogger("dsi_instruments")
            pixhawk_logger.propagate=False
            # get root logger and exisiting file hanler
            root_logger = logging.getLogger()
            root_file_handler = [handler for handler in root_logger.handlers if isinstance(handler,logging.FileHandler)]
            pixhawk_logger.setLevel(logging.DEBUG)
            formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s') 
            if len(root_file_handler)>0:
                file_handler = logging.FileHandler(Path(root_file_handler[0].stream.name).parent / 'pixhawk_client.log', 'w+')
                file_handler.setLevel(logging.DEBUG)  
                file_handler.setFormatter(formatter)          
                pixhawk_logger.addHandler(file_handler)  
                logging.info("Stopped propagating pixhawk log- now logging to separate file")
            # dont propagate to this logger though. 
            
        # Cyber Power PDU Outet switch
        if (not self.nopdu):
            logging.info("Connecting to CyberPower PDU for HPA/ Warning light control....")                        
            try:
                pdu_messenger = Messenger(self.config['amq_server'], self.config['amq_port'], self.credentials, use_ssl=self.config['amq_use_ssl'], reconnect_attempts_max=5)
            except:
                logging.error("Could not connect active MQ server....")
            self.pdu_switch = PduClient(pdu_messenger)
            if self.pdu_switch.check_connection():
                logging.info("Power Strip Client Ready")                
            else:
                logging.info("Power Strip client didn't get response from manager, cyberpowerPDU.service may not be running or crashed")           
     
        # PTU Sat Tracker
        try:
            ptu_messenger = Messenger(self.config['amq_server'], self.config['amq_port'], self.credentials, use_ssl=self.config['amq_use_ssl'], reconnect_attempts_max=5)
        except:
            logging.error("Could not connect active MQ server....")        
        
        if (self.noptu):
            nogo_config = Path(self.config['home_directory']) / 'ground_station/lib/sat_tracker/nogozones.yaml'            
            self.ptu_client = PtuClient(
                ptu_messenger,config=self.config_file,
                elevation_mask=self.el_mask, test_mode= True,
                cmd_log_file=self.log_dir / "ptu_cmds.csv",
                status_log_file= self.log_dir / "ptu_status.csv",
                )
            shutil.copy(nogo_config, self.log_dir)
            
            logging.info("PTU Client Ready: Running in test mode. No interaction with the manager/HW")                                           
        else: 
            nogo_config = Path(self.config['home_directory']) / 'ground_station/lib/sat_tracker/nogozones.yaml'
            self.ptu_client = PtuClient(
                ptu_messenger, config=self.config_file,
                elevation_mask=self.el_mask,
                cmd_log_file=self.log_dir / "ptu_cmds.csv",
                status_log_file= self.log_dir / "ptu_status.csv",
            )
            shutil.copy(nogo_config, self.log_dir)
            
            if self.ptu_client.check_connection():
                logging.info("PTU Client Ready")                
            else:
                logging.info("PTU client didnt get response from manager")                                                        
        logging.info("Configuration Complete")        
        
        signal.signal(signal.SIGINT, self._sigHandler)
        signal.signal(signal.SIGTERM, self._sigHandler)               
           
    def _sigHandler(self, signum, frame):
        '''
        Handles cntrl+C
        '''
        logging.warning("Exiting")
        self.cleanExit()
        exit()
        
    def cleanExit(self):
        '''
        Clean exit, closes connections and log files
        '''
        logging.info("Closing {}".format(self.sat_log.name))        
        self.sat_log.close()
        if (hasattr(self, 'pixhawk')):
            logging.info("Closing Pixhawk")
            self.pixhawk.clean_exit()                                                   
        if (hasattr(self, 'ptu_client')):
            logging.info("Closing PTU Client")                        
            self.ptu_client.clean_exit()
        if (hasattr(self, 'ptu_client')):
            start = time.time()
            logging.warning("Final Park Status {}".format(self.ptu_client.parked()))
        if (not self.nopdu):
            logging.info("Turning Off Warning Lights")         
            self.pdu_switch.set_warning_lights(OutletState.OFF, check_outcome=True)                
            self.pdu_switch.shutdown()      
            
    def get_status_str(self, sat_az=None, sat_el=None, 
                       display_sat:bool=True,
                       display_pix:bool=True,
                       display_ptu:bool=True) -> str:
        
        if sat_az is None:
            display_sat = False
        if self.nopixhawk:
            display_pix=False
        if self.noptu:
            display_ptu=False
        info_str = ""
        if display_sat:
            sat_str         = "{:<8}: A: {:5.1f} E: {:3.1f}\n".format('Sat.',sat_az, sat_el)        
            info_str += sat_str 
        if display_pix:
            pix_strs = {}
            for pix_id in self.pixhawk.pix_ids:
                pix_strs[pix_id]     = "{:<8}  A: {:5.1f} E: {:3.1f} | GPS STATUS {}\n".format(
                    "PX ID:{}".format(pix_id ),
                    (self.pixhawk.pix_status[pix_id].hdg/100) % 360, self.pixhawk.pix_status[pix_id].pitch*180/np.pi, 
                    self.pixhawk.pix_status[pix_id].gpsStatus 
                )
                pix_ptu_id = self.pixhawk.pix_dict[pix_id]["ptu_id"]
                if not (pix_ptu_id in self.ptu_client.ptu_ids):
                    info_str += pix_strs[pix_id]
                        
        if display_ptu:
            for ptu_id in self.ptu_client.ptu_ids:
                ptu_str     = "{:<8}  A: {:5.1f} E: {:3.1f} | P: {:5.1f} T: {:3.1f}|| CMD A: {:5.1f} E: {:3.1f}\n".format(
                    self.ptu_client.ptu_dict[ptu_id]['name'],
                    self.ptu_client.ptu_status[ptu_id].azimuth % 360, self.ptu_client.ptu_status[ptu_id].elevation, 
                    self.ptu_client.ptu_status[ptu_id].pan, self.ptu_client.ptu_status[ptu_id].tilt, 
                    self.ptu_client.ptu_status[ptu_id].command.azimuth, self.ptu_client.ptu_status[ptu_id].command.elevation, 
                )
                ptu_pix_id = self.ptu_client.ptu_dict[ptu_id]["pix_id"]
                if display_pix and (ptu_pix_id in self.pixhawk.pix_ids):
                    ptu_str += pix_strs[ptu_pix_id]
                
                info_str += ptu_str           
                                
        return info_str                           
    
    def run(self):
        
        el_mask_duration = self.el_mask/EL_RATE
        el_mask_move_start = 0
        waiting_for_mask = False
        rise_mask_met = False
        set_mask_met =False
        logging.info("Turning on Warning Light")
        if not self.nopixhawk:
            self.pixhawk.start_logging()
        # self.pdu_switch.set_warning_lights(OutletState.ON, check_outcome=True)          

        rise_rate_avg = np.convolve(np.diff(self.trajectory.el), np.ones(4)/4)[:-2]
        rise_fall_dir = (rise_rate_avg>=0)
        err_vec = np.abs(self.trajectory.el-self.el_mask)
        err_idx_map = np.arange(err_vec.size)
        closest_idx = np.argmin(err_vec[(rise_fall_dir) & (err_vec<2)])
        el_idx = err_idx_map[(rise_fall_dir) & (err_vec<2)][closest_idx]
        el_time = self.trajectory.t_ref + timedelta(seconds=float(self.trajectory.t_steps[el_idx]))        

        logging.info("Priming, Trajectory above min elevation at {}".format(el_time.strftime(time_format_print)))
        self.ptu_client.ptu_move_to(self.trajectory.az[el_idx], self.trajectory.el[el_idx]) 
        state="Primed"
        for idx, t_step in enumerate(self.trajectory.t_steps[:-1]):
            
            exec_time = self.trajectory.t_ref + timedelta(seconds=t_step)
            utc_now = datetime.now(timezone.utc)        
            logging.info('Next Step at {}'.format(exec_time.astimezone(DEFAULTS.local_tzone).strftime(time_format_short)))
            while (utc_now < exec_time):
                time.sleep(0.1)                
                utc_now = datetime.now(timezone.utc)                        
            if (exec_time >= el_time):
                state="Tracking"
                actual_az, actual_el = self.ptu_client.ptuMoveTo(self.trajectory.az[idx], self.trajectory.el[idx])   
            elif (exec_time < el_time):
                state="Primed"                
                logging.info("Step below elevation mask, skipping")                
        
            status_str = self.get_status_str(self.trajectory.az[idx], self.trajectory.el[idx])
            logging.info("Dish Active. {}: \n{}".format(state, status_str))
            
            self._log_sat_pos(utc_now, self.trajectory.az[idx], self.trajectory.el[idx])
            if idx == self.trajectory.t_steps.size-1:
                continue
            
            # dt = self.trajectory.t_steps[idx+1] - self.trajectory.t_steps[idx]
            # time.sleep(dt)
            
        self.ptu_client.park_ptu()
        # actual_az, actual_el = self.ptu_client.ptuMoveTo(0, 0)                
        self.cleanExit()
    def _log_sat_pos(self, time:datetime, azimuth:float, elevation:float):
        self.csv_writer.writerow([time.isoformat(), azimuth, elevation])

def main():
    
    with open(DEFAULT_CFG) as f:
        config = yaml.safe_load(f)       
    el_mask = 23.5
    run_name = 'ptu_test'
    no_ptu = False
    no_pixhawk = True
    dt = 3  
    duration = 60*2    
    num_steps = int(duration/dt)
    az_range = np.array((201.5,200.2))#np.arange(203,215,0.5)
    el_range = np.array((38.7, 39)) #np.arange(31,35,0.5)
    
    el_vector=np.zeros(az_range.size*el_range.size) 
    az_vector=np.zeros(az_range.size*el_range.size)     
    vec_idx = 0
    for el_idx, el_value in enumerate(el_range):
        for az_idx, az_value in enumerate(az_range):
            el_vector[vec_idx] = el_value
            if el_idx%2==1: #reverse
                az_vector[vec_idx] = az_range[(az_range.size-1)-az_idx]
            else:
                az_vector[vec_idx] = az_range[az_idx]
            vec_idx = vec_idx+1  
    t_per_az_cut = 60*3
    dt = t_per_az_cut / az_range.size
    num_steps = el_vector.size
    
    trajectory = AzElTrajectory(
        t_steps=np.concatenate((np.array((0,)), 10+np.arange(0, num_steps*dt, dt))) , 
        t_ref=datetime.now(timezone.utc),
        az = np.concatenate((np.zeros(1), az_vector)), 
        el = np.concatenate((np.ones(1)*el_vector[0], el_vector)), 
    )    
    
    geo_az = 0
    geo_el = 45
    trajectory = AzElTrajectory(
        t_steps=np.concatenate((np.array((0,)), 10+np.arange(0, num_steps*dt, dt))) , 
        t_ref=datetime.now(timezone.utc),
        az = np.concatenate((np.zeros(1), np.ones(num_steps)*geo_az)), 
        el = np.concatenate((np.ones(1)*geo_el, np.ones(num_steps)*geo_el)), 
    )

    
    log = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s',datefmt='%b %d %H:%M:%S')
    log.setLevel(logging.DEBUG)


    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)
    log.addHandler(console_handler)

    now = datetime.today()
    logname = f"{run_name}" #_{now.year}-{now.month}-{now.day}_{now.hour}{now.minute}"
    parent_folder = '{}/{}'.format(now.strftime('%m-%d-%Y'),run_name)                
    log_dir = Path(config['logging_dir']) / '{}/{}'.format(parent_folder, logname)        
    if '~' in str(log_dir):
        log_dir = Path(str(log_dir).replace('~', config['home_directory']))                
    if not log_dir.exists():
        log_dir.mkdir(parents=True, mode=0o775) 
    

    file_handler = logging.FileHandler('{}/{}.log'.format(log_dir, logname), 'w+')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)        
    log.addHandler(file_handler)
    
    logging.info("Logging to: {}".format('{}/{}.log'.format(log_dir, logname)))

    
    # Print Arguments 
    try:              
        runner = ArbitraryPassRunner(config_file=DEFAULT_CFG, trajectory=trajectory,
                                logname=logname, log_dir=log_dir, el_mask=el_mask,
                                noptu=no_ptu, nopixhawk=no_pixhawk)
                            
        runner.run()
    except Exception as e:
        logging.error(e, stack_info=True, exc_info=True)
        raise ValueError('Pass Runner failed, check logs') # Raise error to bring attention in the queue manager subprocess


if __name__ == '__main__':
    main()
