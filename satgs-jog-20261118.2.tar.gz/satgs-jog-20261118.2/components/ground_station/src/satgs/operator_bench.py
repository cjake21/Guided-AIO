"""Shared explicit mechanical commands through the selected PTU owner."""

from contextlib import contextmanager
from collections import deque
from fractions import Fraction
import json
import math
import os
from pathlib import Path
import secrets
import threading
import time
from uuid import uuid4

from satgs.deployment_cli import (
    CliInputError, _check_depth, _reject_constant, _unique_object, read_regular_bytes,
)
from satgs.operator_core import OperatorError, _bytes, _metadata_identity, _write_new
from satgs.operator_activity import StationLease
from satgs.runtime_configuration import _freeze, _inline_ca, _station_structure, _thaw


# Exact setup admission follows review of the allocated unit's stop/feedback contract.
_COMMISSIONED_BENCH_CONFIGURATIONS = frozenset()
_UNSELECTED = object()
JOG_LEASE_SECONDS = .75
JOG_REFRESH_SECONDS = .3


def _mechanical_context(*, exchange_timeout, feedback_max_age, max_change_degrees, no_go_rectangle):
    if max_change_degrees is None and no_go_rectangle is not _UNSELECTED:
        raise OperatorError("No-go policy is selected only with an explicit manual maximum change.")
    if max_change_degrees is not None and no_go_rectangle is _UNSELECTED:
        raise OperatorError("Manual setup requires a mechanical no-go rectangle or explicit unconfigured selection.")
    context = dict(schema="ptu-readback-context.v1", session_id=secrets.token_hex(32),
        equipment_label="Pelican QPT130", model="QPT130", protocol="PTCR20", protocol_address=None,
        serial_settings=dict(
            port="/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller_EBCUb14C705-if00-port0",
            baudrate=9600, bytesize=8, parity="N", stopbits=1, xonxoff=False, rtscts=False,
            dsrdtr=False, rts=True, dtr=True),
        device_identity=dict(vendor_id="067b", product_id="23a3", serial_number="EBCUb14C705",
                             interface_number="00", driver="pl2303"),
        observation_max_age_seconds=feedback_max_age, exchange_timeout_seconds=exchange_timeout)
    key = "readback_context"
    if max_change_degrees is not None:
        key = "manual_context"
        context.update(schema="ptu-manual-context.v1", frame="mechanical-pan-tilt-degrees.v1",
            pan_min=-215, pan_max=215, tilt_min=-90, tilt_max=0,
            max_change_degrees=max_change_degrees, no_go_rectangle=no_go_rectangle)
    return key, context


def configure_local_serial_bench(output, *, manager_id=1, exchange_timeout=1, feedback_max_age=5,
                                  max_change_degrees=None, no_go_rectangle=_UNSELECTED):
    """Select one local mechanical owner without opening equipment or messaging."""
    output = Path(os.path.abspath(os.fspath(output)))
    if output.suffix != ".json":
        raise OperatorError("Choose a new JSON file in an existing configuration directory.")
    if output.exists() or output.is_symlink():
        raise OperatorError("The bench JSON already exists; it was not replaced.", "conflict", 3)
    key, context = _mechanical_context(exchange_timeout=exchange_timeout, feedback_max_age=feedback_max_age,
        max_change_degrees=max_change_degrees, no_go_rectangle=no_go_rectangle)
    document = dict(station=dict(bench_transport="local-serial", **{key: context}), ptu_id=manager_id)
    _admit(document)
    _write_new(output, _bytes(document))
    return dict(configuration=str(output), mode="query-only" if max_change_degrees is None else "manual",
        manager_id=manager_id, transport="local-serial", broker_started=False, device_opened=False,
        message="Local serial configuration created. Select it in PTU and explicitly Connect after preflight.")


def saved_bench_configuration(workspace):
    unused, settings = workspace._read()
    document = settings["operator"].get("local_ptu")
    if document is not None:
        admitted = _admit(document)
        if admitted.get("bench_transport") != "local-serial":
            raise OperatorError("Saved PTU selection is not local serial.", "bench_input", 3)
    return document


def save_local_bench(workspace, configuration_file=None):
    """Save one explicit local selection through the station's existing transaction."""
    document = None
    if configuration_file is not None:
        unused, document = read_bench_configuration(configuration_file)
        if _admit(document).get("bench_transport") != "local-serial":
            raise OperatorError("Only local serial configuration can be saved here.", "bench_input", 3)
    return _save_local_bench_document(workspace, document)


def _save_local_bench_document(workspace, document):
    with StationLease(workspace.root):
        original, settings = workspace._read()
        previous = settings["operator"].get("local_ptu")
        if document is None:
            if previous is not None:
                document = previous
            else:
                key, context = _mechanical_context(exchange_timeout=1, feedback_max_age=5,
                    max_change_degrees=360, no_go_rectangle=None)
                document = dict(station=dict(bench_transport="local-serial", **{key: context}), ptu_id=1)
        if _admit(document).get("bench_transport") != "local-serial":
            raise OperatorError("Saved PTU selection is not local serial.", "bench_input", 3)
        changed = document != previous
        warning = None
        if changed:
            settings["operator"]["local_ptu"] = document
            settings["operator"]["generation"] += 1
            unused, warning = workspace._replace(original, settings)
    return dict(category="ok", saved=True, changed=changed, transport="local-serial",
                device_opened=False, configuration_file_required=False, warning=warning,
                message="Local QPT130 connection saved. Connect remains explicit. Jog retains device soft limits; "
                        "software endpoint/no-go checks apply only to numeric moves.")


def configure_loopback_bench(output, *, manager_id=1, exchange_timeout=1, feedback_max_age=5,
                             max_change_degrees=None, no_go_rectangle=_UNSELECTED):
    """Allocate a private local broker identity and an explicit mechanical session, offline."""
    from meteor_api.messenger import Messenger
    output = Path(os.path.abspath(os.fspath(output)))
    broker = output.with_name(output.stem + ".broker.xml")
    if output.suffix != ".json" or output == broker:
        raise OperatorError("Choose a new JSON file in an existing configuration directory.")
    if any(path.exists() or path.is_symlink() for path in (output, broker)):
        raise OperatorError("The bench JSON or matching broker file already exists; neither was replaced.", "conflict", 3)
    key, context = _mechanical_context(exchange_timeout=exchange_timeout, feedback_max_age=feedback_max_age,
        max_change_degrees=max_change_degrees, no_go_rectangle=no_go_rectangle)
    password = secrets.token_hex(32)
    station = dict(amq_transport="loopback-plaintext-bench", amq_use_ssl=False,
                   amq_dial_address="127.0.0.1", amq_port=61613,
                   amq_username="satgs-bench", amq_password=password, **{key: context})
    document = dict(station=station, ptu_id=manager_id)
    settings = _admit(document)
    Messenger.prepare_bench_loopback_transport(settings, threading.Event())
    broker_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
 http://activemq.apache.org/schema/core http://activemq.apache.org/schema/core/activemq-core.xsd">
 <broker xmlns="http://activemq.apache.org/schema/core" brokerName="satgs-isolated-bench"
  persistent="false" useJmx="false" schedulerSupport="false" advisorySupport="false">
  <plugins><simpleAuthenticationPlugin anonymousAccessAllowed="false"><users>
   <authenticationUser username="satgs-bench" password="PASSWORD" groups="satgs-bench"/>
  </users></simpleAuthenticationPlugin></plugins>
  <transportConnectors><transportConnector name="local-bench-stomp"
   uri="stomp://127.0.0.1:61613"/></transportConnectors>
 </broker>
</beans>
'''.replace("PASSWORD", password).encode("ascii")
    _write_new(broker, broker_xml)
    try:
        _write_new(output, _bytes(document))
    except OperatorError:
        raise OperatorError("Broker configuration retained at " + str(broker) +
            "; bench JSON was not completed. Do not start this broker. Inspect the retained files and use a new output name.",
            "setup_partial", 4) from None
    return dict(configuration=str(output), broker_configuration=str(broker),
        mode="query-only" if max_change_degrees is None else "manual", manager_id=manager_id,
        transport="loopback-plaintext-bench", broker_started=False, device_opened=False,
        message="Private bench configuration created. Broker and foreground manager startup remain explicit.")


def _open_transport(settings, deadline, cancel):
    if "bench_transport" in settings:
        raise OperatorError("Local serial sessions do not use a broker transport.", "bench_not_admitted", 3)
    from meteor_api.messenger import Messenger
    if settings.get("amq_transport") == "loopback-plaintext-bench":
        if not ({"readback_context", "manual_context"} & settings.keys()):
            raise OperatorError("Plaintext transport is restricted to the local mechanical bench.",
                                "bench_not_admitted", 3)
        prepared = Messenger.prepare_bench_loopback_transport(settings=settings, cancel=cancel)
        return Messenger.open_bench_loopback_bounded(settings=settings, deadline=deadline,
                                                     cancel=cancel, prepared=prepared)
    prepared = Messenger.prepare_transport(settings=settings, cancel=cancel)
    return Messenger.open_bounded(settings=settings, deadline=deadline, cancel=cancel, prepared=prepared)


@contextmanager
def _transport_acquisition_cancel(cancel, deadline):
    transport_cancel = threading.Event()
    complete = threading.Event()
    publication = threading.Lock()

    def relay():
        while time.monotonic() < deadline:
            with publication:
                if complete.is_set():
                    return
                if cancel.is_set():
                    transport_cancel.set()
                    return
            complete.wait(.005)

    if cancel.is_set():
        transport_cancel.set()
    worker = threading.Thread(target=relay, name="operator-bench-acquisition-cancel", daemon=False)
    worker.start()
    try:
        yield transport_cancel
    finally:
        # Active owner cancellation must leave Messenger alive for passive unsubscription.
        with publication:
            complete.set()
        worker.join(.1)
        if worker.is_alive():
            raise OperatorError("Bench acquisition cancellation relay did not release.", "cleanup", 7)


def read_bench_configuration(path):
    """Read bounded JSON with the station's exact inline-CA data exception."""
    payload = read_regular_bytes(path, input_kind="bench JSON")
    try:
        text = payload.decode("utf-8")
        _check_depth(text)
        document = json.loads(text, object_pairs_hook=_unique_object, parse_constant=_reject_constant)
        structure = document
        if (type(document) is dict and type(document.get("station")) is dict
                and "amq_ca_pem" in document["station"]):
            _inline_ca(document["station"]["amq_ca_pem"])
            structure = dict(document)
            structure["station"] = dict(document["station"], amq_ca_pem="")
        # The replacement preserves every node and depth without exempting nested CA names.
        _station_structure(structure)
    except (UnicodeError, ValueError, RecursionError):
        raise CliInputError("Bench JSON must be valid UTF-8 data within the station structure limits.") from None
    return payload, document


def _admit(settings):
    from ptu_control.bench import BenchContext, ManualContext, ReadbackContext
    from ptu_control.pointing import PointingPolicy
    import hashlib
    mechanical = (type(settings) is dict and type(settings.get("station")) is dict
                  and bool({"readback_context", "manual_context"} & settings["station"].keys()))
    keys = {"station", "ptu_id"} if mechanical else {"station", "ptu_id", "elevation_mask", "no_go_data"}
    if type(settings) is not dict or set(settings) != keys or type(settings.get("station")) is not dict:
        raise OperatorError("Bench configuration requires an explicit selected owner and policy.")
    station = _freeze(settings["station"])
    local = station.get("bench_transport") == "local-serial"
    if "bench_transport" in station:
        context_keys = {"readback_context", "manual_context"} & station.keys()
        if not local or not mechanical or len(context_keys) != 1 or set(station) != {"bench_transport", *context_keys}:
            raise OperatorError("Select local serial with exactly one mechanical context and no broker settings.",
                                "bench_not_admitted", 3)
    try:
        if mechanical:
            context_type = ManualContext if "manual_context" in station else ReadbackContext
            context = context_type.from_settings(station, settings["ptu_id"])
        else:
            policy = PointingPolicy.from_settings(station, settings["ptu_id"], settings["elevation_mask"],
                                                 _freeze(settings["no_go_data"]))
            context = BenchContext.from_settings(station, policy)
    except Exception:
        raise OperatorError("Bench policy, identities or limits are invalid.", "bench_input", 3) from None
    if mechanical:
        inherited = dict(baudrate=9600, bytesize=8, parity="N", stopbits=1,
                         xonxoff=False, rtscts=False, dsrdtr=False, rts=True, dtr=True)
        plaintext = station.get("amq_transport") == "loopback-plaintext-bench"
        transport_valid = local or (station.get("amq_use_ssl") is False and
                           "amq_ca_pem" not in station and "amq_tls_server_name" not in station
                           if plaintext else station.get("amq_use_ssl") is True and
                           "amq_transport" not in station)
        if ((not local and station.get("amq_dial_address") != "127.0.0.1") or not transport_valid
                or any(context.serial_settings[key] != value for key, value in inherited.items())):
            raise OperatorError("This QPT130 bench requires an explicit isolated local transport and inherited PTCR20 serial settings.",
                                "bench_not_admitted", 3)
        return station
    record = {"binding": context.binding.hex(), "dial": station.get("amq_dial_address"),
              "tls_identity": station.get("amq_tls_server_name"), "port": station.get("amq_port")}
    identity = hashlib.sha256(_bytes(record)).hexdigest()
    if context.mode != "operational" or identity not in _COMMISSIONED_BENCH_CONFIGURATIONS:
        raise OperatorError("This unit's current-position and Stop contract is not admitted for live control.",
                            "bench_not_admitted", 3)
    return station


class BenchSession:
    def __init__(self, workspace, configuration_file=None):
        try:
            if configuration_file is None:
                document = saved_bench_configuration(workspace)
                if document is None:
                    raise OperatorError("Select Save local QPT130 once, or provide a configuration file.", "bench_input", 3)
            else:
                unused, document = read_bench_configuration(configuration_file)
            self.settings = _admit(document)
        except OperatorError:
            raise
        except Exception:
            raise OperatorError("Bench configuration could not be read.", "bench_input", 3) from None
        self.workspace = workspace
        self._configuration_file = configuration_file
        self.document = document
        self.query_only = "readback_context" in self.settings
        self._transport_kind = self.settings.get("bench_transport", self.settings.get("amq_transport", "tls-broker"))
        context_key = ("readback_context" if self.query_only else
                       "manual_context" if "manual_context" in self.settings else "bench_context")
        self._context = self.settings[context_key]
        self._release_identity = _metadata_identity()
        self._mode = ("query-only" if self.query_only else "manual" if context_key == "manual_context"
                      else self._context["mode"])
        self.cancel = threading.Event()
        self.client = self.transport = None
        self._closed = False
        self._preview_sequence = None
        self._preview_generation = 0
        self._preview_lock = threading.RLock()
        self._regular = threading.Lock()
        self._manual_generation = 0
        self._manual_step = None
        self._manual_cancel = threading.Event()
        self._motion_blocked = "Query-only session. Movement and Stop are unavailable." if self.query_only else None
        self._observation = None
        self._observation_started = None
        self._observation_error = None
        self._next_poll = 0
        self._lease = None
        self._jog_lock = threading.RLock()
        self._jog_worker = None
        self._jog_next_token = 0
        self._jog_token = None
        self._jog_direction = None
        self._jog_state = "idle"
        self._jog_error = None
        self._jog_expiry = 0
        self._jog_cancel = threading.Event()
        self._jog_results = deque(maxlen=16)
        self._jog_stop_result = None
        self._jog_completion = None
        self._jog_barriers = 0
        self._jog_closing = False

    @property
    def released(self):
        return self.client is None and self.transport is None and self._lease is None

    def _deadline(self):
        return time.monotonic() + self._context["exchange_timeout_seconds"]

    def disarm_manual(self):
        with self._preview_lock:
            self._manual_cancel.set()
            self._manual_step = None
            self._manual_generation += 1

    def readback_snapshot(self):
        with self._jog_lock:
            jog = dict(token=self._jog_token, direction=self._jog_direction,
                       state=self._jog_state, error=self._jog_error)
            jog_idle = (self._jog_worker is None or not self._jog_worker.is_alive()) and not self._jog_barriers
        with self._preview_lock:
            context = self._context
            freshness = "disconnected" if self._closed or self.client is None else "unknown"
            age = None
            if self._observation is not None and freshness != "disconnected":
                age = max(0, time.monotonic() - self._observation_started)
                freshness = ("unavailable" if self._observation_error else "fresh"
                    if age <= context["observation_max_age_seconds"] else "stale")
            elif self._observation_error and freshness != "disconnected":
                freshness = "unavailable"
            return {"freshness": freshness, "observation": dict(self._observation) if self._observation else None,
                    "age_upper_bound_seconds": age, "error": self._observation_error,
                    "manual_enabled": self._manual_step is not None, "step_degrees": self._manual_step,
                    "manual_generation": self._manual_generation, "motion_blocked": self._motion_blocked,
                    "mode": self._mode, "transport": self._transport_kind,
                    "jog": jog, "jog_allowed": self._transport_kind == "local-serial" and not self.query_only
                        and self._mode == "manual" and not self._motion_blocked and freshness == "fresh"
                        and jog["state"] == "idle" and jog_idle and not self._jog_closing and not self.cancel.is_set(),
                    "stop_allowed": not self.query_only,
                    "poll_due": jog["token"] is None and time.monotonic() >= self._next_poll,
                    "poll_interval_seconds": max(context["exchange_timeout_seconds"],
                                                  context["observation_max_age_seconds"] / 2)}

    def start_jog(self, direction):
        if direction not in ("left", "right", "up", "down"):
            raise OperatorError("Choose left, right, up or down.", "invalid_jog", 3)
        if not self._regular.acquire(False):
            raise OperatorError("A PTU operation is active; Stop remains available.", "busy", 3)
        try:
            with self._jog_lock:
                if not self.readback_snapshot()["jog_allowed"] or self._closed or self.client is None:
                    raise OperatorError("Jog requires a connected local manual session and fresh feedback.", "jog_unavailable", 3)
                self.disarm_manual()
                with self._preview_lock:
                    self._preview_sequence = None
                    self._preview_generation += 1
                self._jog_next_token += 1
                token = self._jog_next_token
                self._jog_token, self._jog_direction = token, direction
                self._jog_expiry = time.monotonic() + JOG_LEASE_SECONDS
                self._jog_cancel = threading.Event()
                self._jog_state, self._jog_error, self._jog_stop_result = "starting", None, None
                self._jog_completion = {}
                worker = threading.Thread(target=self._run_jog,
                                          args=(token, direction, self._jog_cancel, self._jog_completion),
                                          name="operator-ptu-jog", daemon=False)
                self._jog_worker = worker
                try:
                    worker.start()
                except BaseException:
                    self._jog_token = None
                    self._jog_state = "idle"
                    self._jog_worker = None
                    raise
            return dict(category="ok", jog_token=token, state="requested", physical_state="indeterminate")
        except BaseException:
            self._regular.release()
            raise

    def renew_jog(self, token):
        with self._jog_lock:
            if type(token) is not int or token != self._jog_token or self._jog_cancel.is_set():
                return False
            if (self.cancel.is_set() or self._closed or time.monotonic() >= self._jog_expiry
                    or self._jog_state not in ("starting", "active")):
                self._jog_cancel.set()
                return False
            self._jog_expiry = time.monotonic() + JOG_LEASE_SECONDS
            return True

    def end_jog(self, token):
        with self._jog_lock:
            if type(token) is not int or token != self._jog_token:
                return False
            self._jog_state = "stopping"
            self._jog_cancel.set()
            return True

    def drain_jog_results(self):
        with self._jog_lock:
            rows = list(self._jog_results)
            self._jog_results.clear()
            return rows

    def _finish_jog(self):
        with self._jog_lock:
            worker, token = self._jog_worker, self._jog_token
            completion = self._jog_completion
            if token is not None:
                self.end_jog(token)
        if worker is not None and worker is not threading.current_thread():
            worker.join(JOG_LEASE_SECONDS + self._context["exchange_timeout_seconds"] + .25)
            if worker.is_alive():
                raise OperatorError("Jog worker and Stop have not released. Retain the session.", "cleanup", 7)
        with self._jog_lock:
            return completion.get("stop") if token is not None and completion is not None else None

    def _run_jog(self, token, direction, cancel, completion):
        pan, tilt = {"left": (-1, 0), "right": (1, 0), "up": (0, 1), "down": (0, -1)}[direction]
        attempt, started = uuid4().hex, time.monotonic()
        record = dict(schema="satgs-bench-operation.v1", attempt_id=attempt, operation="jog",
            jog_token=token, jog_direction=direction, motion_contract="device-soft-limits-jog.v1",
            software_endpoint_limits_enforced=False, no_go_enforced=False, device_soft_limits_retained=True,
            physical_state="indeterminate", submission="none", category="ok", jog_exchange_count=0,
            started_recorded=False, result_recorded=False,
            jog_acknowledged_count=0, jog_uncertain_count=0, started_monotonic=started,
            wall_clock_quality="unconfirmed", transport=self._transport_kind, ptu_id=self.document["ptu_id"],
            release_identity=self._release_identity, selected_context=_thaw(self._context))
        attempted = False
        stop = None
        try:
            _write_new(self.workspace.root / f"bench-{attempt}-started.json", _bytes(record))
            record["started_recorded"] = True
            while not cancel.is_set() and not self.cancel.is_set():
                with self._jog_lock:
                    deadline = min(self._jog_expiry, self._deadline())
                    if token != self._jog_token or time.monotonic() >= deadline:
                        record["jog_end_reason"] = "renewal_expired"
                        break
                exchange_started = time.monotonic()
                attempted = True
                record["jog_exchange_count"] += 1
                result = self.client.jog(pan, tilt, deadline=deadline, cancel=cancel).as_record()
                record["last_exchange"] = result
                submission = result.get("submission", "unknown")
                if submission != "none":
                    record["submission"] = submission if record["submission"] == "none" else "multiple"
                record["jog_acknowledged_count"] += int(result.get("category") == "ok")
                record["jog_uncertain_count"] += int(result.get("category") != "ok" and submission != "none")
                self._remember_readback(result, exchange_started)
                if result.get("category") != "ok":
                    if not (result.get("category") == "cancelled" and submission == "none" and cancel.is_set()):
                        record["category"] = result.get("category", "exchange_failed")
                    break
                if self.readback_snapshot()["freshness"] != "fresh":
                    record["category"] = "invalid_readback"
                    break
                with self._jog_lock:
                    if not cancel.is_set():
                        self._jog_state = "active"
                cancel.wait(JOG_REFRESH_SECONDS)
            record.setdefault("jog_end_reason", "cancelled" if self.cancel.is_set() else "released")
        except Exception as error:
            category = getattr(error, "code", getattr(error, "primary", "exchange_failed"))
            submission = getattr(error, "submission", "unknown")
            if not (category == "cancelled" and submission == "none" and cancel.is_set()):
                record["category"] = category
            else:
                record["jog_end_reason"] = "released"
            if attempted and record["jog_acknowledged_count"] + record["jog_uncertain_count"] < record["jog_exchange_count"]:
                record["last_exchange"] = dict(operation="jog", category=category,
                    submission=submission, physical_state="indeterminate")
                if submission != "none":
                    record["jog_uncertain_count"] += 1
                    record["submission"] = "unknown" if record["submission"] == "none" else "multiple"
        finally:
            with self._jog_lock:
                self._jog_state = "stopping"
            if attempted:
                try:
                    stop = self._perform("stop", pan=None, tilt=None, step_degrees=None,
                                         direction=None, manual_generation=None, persist=True)
                    record["stop_category"] = stop["category"]
                    record["stop_submission"] = stop.get("submission", "unknown")
                    if stop["category"] != "ok" or stop.get("partial"):
                        record["category"] = "stop_failed"
                except Exception:
                    record["category"] = "stop_failed"
                    record["stop_category"] = "unrecorded_failure"
            record.update(finished_monotonic=time.monotonic(), result_recorded=True,
                          elapsed_seconds=time.monotonic() - started)
            try:
                _write_new(self.workspace.root / f"bench-{attempt}-result.json", _bytes(record))
            except Exception:
                record.update(category="recording_failed", result_recorded=False, partial=True)
            with self._jog_lock:
                failed = record["category"] != "ok"
                self._jog_state = "failed" if failed else "idle"
                self._jog_error = record["category"] if failed else None
                self._jog_stop_result = stop
                completion["stop"] = stop
                completion["record"] = record
                self._jog_token = None
                self._jog_direction = None
                if stop is not None:
                    self._jog_results.append(stop)
                self._jog_results.append(record)
                if failed:
                    with self._preview_lock:
                        self._motion_blocked = "Jog or Stop did not complete cleanly. Inspect the session before reconnecting."
            self._regular.release()

    def _remember_readback(self, record, started):
        with self._preview_lock:
            context = self._context
            self._next_poll = time.monotonic() + max(
                context["exchange_timeout_seconds"], context["observation_max_age_seconds"] / 2)
            if record.get("state") == "stop_failed":
                self._motion_blocked = "Required Stop failed. Motion remains blocked pending owner review."
                self.disarm_manual()
            if record.get("category") == "ok" and record.get("has_observation"):
                scale = 10 if self.client.protocol == "PTCR20" else 100
                if (record.get("units_per_degree") != scale
                        or any(type(record.get(key)) not in (int, float) or not math.isfinite(record[key])
                               for key in ("pan", "tilt"))
                        or record.get("binding") != self.client._bench.binding.hex()
                        or record.get("manager_id") != self.document["ptu_id"]
                        or record.get("mode") != self._mode
                        or not record.get("observed_at") or not record.get("observation_sequence")):
                    self._observation_error = "invalid_readback"
                    self.disarm_manual()
                    return
                previous = self._observation
                if previous is None or record["observation_sequence"] > previous["observation_sequence"]:
                    self._observation = {key: record[key] for key in ("pan", "tilt", "observed_at",
                        "observation_sequence", "position_reference", "status_bytes", "binding", "manager_id", "mode",
                        "units_per_degree")}
                    self._observation_started = started
                    self._observation_error = None
                else:
                    self._observation_error = "out_of_order_readback"
                    self.disarm_manual()
            elif record.get("category") == "ok" and record.get("operation") != "disconnect":
                self._observation_error = "missing_readback"
                self.disarm_manual()
            elif record.get("category") != "ok":
                self._observation_error = record.get("category", "unknown")
                self.disarm_manual()

    def _require_readback(self):
        snapshot = self.readback_snapshot()
        if snapshot["motion_blocked"]:
            raise OperatorError(snapshot["motion_blocked"], "motion_blocked", 3)
        if snapshot["freshness"] != "fresh":
            raise OperatorError("Request fresh current-position readback before manual control.", "readback_required", 3)
        return snapshot

    def _enable_manual(self, step, generation):
        with self._preview_lock:
            observation = self._require_readback()["observation"]
            if (type(step) not in (int, float) or not math.isfinite(step)
                    or not 1 / observation["units_per_degree"] <= step <= self._context["max_change_degrees"]):
                raise OperatorError("Step must be finite, at least one protocol unit and within the configured maximum change.",
                                    "invalid_step", 3)
            if generation is not None and generation != self._manual_generation:
                raise OperatorError("Manual control was disarmed before enable completed.", "cancelled", 3)
            self.disarm_manual()
            self._manual_cancel = threading.Event()
            self._manual_step = step
        return {"category": "ok", "submission": "none", "manual_enabled": True, "step_degrees": step}

    def _step(self, direction, record, deadline):
        directions = {"left": (-1, 0), "right": (1, 0), "up": (0, 1), "down": (0, -1)}
        if type(direction) is not str or direction not in directions:
            raise OperatorError("Choose left, right, up or down.", "invalid_step", 3)
        with self._preview_lock:
            self._require_readback()
            if self._manual_step is None:
                raise OperatorError("Explicitly enable manual steps first.", "manual_required", 3)
            increment, generation, cancel = self._manual_step, self._manual_generation, self._manual_cancel
        record.update(step_direction=direction, step_degrees=increment, steps=[])
        arguments = {"deadline": deadline, "cancel": cancel}

        def request(phase, operation):
            record["step_phase"] = phase
            started = time.monotonic()
            try:
                result = operation().as_record()
            except Exception as error:
                result = {"category": getattr(error, "primary", "exchange-failed"),
                          "submission": "unknown" if phase == "move" else "none",
                          "physical_state": "indeterminate"}
                record["steps"].append(dict(result, phase=phase))
                if phase == "move":
                    with self._preview_lock:
                        self._motion_blocked = "Manual Move outcome is unresolved. Motion remains blocked."
                self._remember_readback(result, started)
                return result
            child = dict(result, phase=phase)
            invalid = [key for key, value in child.items() if type(value) is float and not math.isfinite(value)]
            if invalid:
                for key in invalid:
                    child[key] = None
                child["rejected_nonfinite_fields"] = invalid
            record["steps"].append(child)
            self._remember_readback(result, started)
            return result

        start = request("status", lambda: self.client.status(**arguments))
        if start["category"] != "ok":
            return start
        self._require_readback()
        pan, tilt = start["pan"], start["tilt"]
        dx, dy = directions[direction]
        if self._mode == "manual":
            target_pan = float(Fraction(str(pan)) + dx * Fraction(str(increment)))
            target_tilt = float(Fraction(str(tilt)) + dy * Fraction(str(increment)))
        else:
            target_pan, target_tilt = pan + dx * increment, tilt + dy * increment
        preview = request("preview", lambda: self.client.preview(target_pan, target_tilt, **arguments))
        if preview["category"] != "ok":
            return preview
        if (not preview.get("has_observation") or (preview["pan"], preview["tilt"], preview["status_bytes"])
                != (pan, tilt, start["status_bytes"])):
            raise OperatorError("Position changed while preparing the relative step.", "context_changed", 3)
        if (preview["encoded_pan_units"] / preview["units_per_degree"],
                preview["encoded_tilt_units"] / preview["units_per_degree"]) == (pan, tilt):
            raise OperatorError("The requested step rounds to no movement.", "invalid_step", 3)
        with self._preview_lock:
            self._require_readback()
            if generation != self._manual_generation or cancel.is_set():
                raise OperatorError("Manual step was disarmed before submission.", "cancelled", 3)
        result = request("move", lambda: self.client.move(preview["preview_sequence"], **arguments))
        if result["category"] != "ok" and result.get("submission") != "none":
            with self._preview_lock:
                self._motion_blocked = "Manual Move outcome is unresolved. Motion remains blocked."
        return result

    def connect(self):
        if self._closed or self.client is not None:
            raise OperatorError("Bench session is already connected or closed.", "conflict", 3)
        started = time.monotonic()
        connection_requested = False
        try:
            self._lease = StationLease(self.workspace.root).acquire()
            if self._transport_kind == "local-serial":
                try:
                    from ptu_control.bench_local import LocalBenchClient
                    self.client = LocalBenchClient.open(settings=self.settings, ptu_id=self.document["ptu_id"],
                                                         deadline=self._deadline(), cancel=self.cancel)
                except ImportError:
                    raise OperatorError("Install the matched local PTU owner and serial prerequisites.",
                                        "owner_version", 3) from None
            else:
                from ptu_control.ptu_client import PtuClient
                acquisition_deadline = self._deadline()
                with _transport_acquisition_cancel(self.cancel, acquisition_deadline) as transport_cancel:
                    self.transport = _open_transport(self.settings, acquisition_deadline, transport_cancel)
                self.client = PtuClient.open_bench(messenger=self.transport, settings=self.settings,
                    ptu_id=self.document["ptu_id"], elevation_mask=self.document.get("elevation_mask"),
                    log_dir=self.workspace.root, no_go_data=_freeze(self.document.get("no_go_data")),
                    deadline=self._deadline(), cancel=self.cancel)
            connection_requested = True
            return self.perform("connect")
        except BaseException as error:
            cleanup = True
            try:
                self.close()
            except Exception:
                cleanup = False
            attempt = uuid4().hex
            finished = time.monotonic()
            category = getattr(error, "code", getattr(error, "primary", "connection_failed"))
            allowed = {"busy", "deadline", "cancelled", "disconnected", "unsupported", "policy_mismatch",
                       "acquisition", "connection_failed", "cleanup", "io", "conflict", "owner_version"}
            record = dict(schema="satgs-bench-operation.v1", attempt_id=attempt, operation="connect",
                category=category if category in allowed else "connection_failed",
                physical_state="indeterminate" if connection_requested else "unobserved",
                submission="unknown" if connection_requested else "none",
                started_monotonic=started, finished_monotonic=finished,
                elapsed_seconds=finished - started, wall_clock_quality="unconfirmed", ptu_id=self.document["ptu_id"],
                query_only=self.query_only, transport=self._transport_kind, release_identity=self._release_identity,
                cleanup_complete=cleanup, partial=not cleanup)
            if self._mode in ("manual", "query-only"):
                record["selected_context"] = _thaw(self._context)
            try:
                _write_new(self.workspace.root / f"bench-{attempt}-started.json", _bytes(record))
                _write_new(self.workspace.root / f"bench-{attempt}-result.json", _bytes(record))
            except Exception:
                error.add_note("Connection failure record could not be completely saved.")
            if not cleanup:
                error.add_note("Passive connection cleanup remains incomplete.")
            raise

    def perform(self, operation, *, pan=None, tilt=None, step_degrees=None, direction=None,
                manual_generation=None, persist=True):
        barrier = operation in ("stop", "disconnect", "disarm")
        if barrier:
            with self._jog_lock:
                self._jog_barriers += 1
        try:
            if barrier:
                stopped = self._finish_jog()
                if operation == "stop" and stopped is not None:
                    return stopped
            return self._perform_command(operation, pan=pan, tilt=tilt, step_degrees=step_degrees,
                                         direction=direction, manual_generation=manual_generation, persist=persist)
        finally:
            if barrier:
                with self._jog_lock:
                    self._jog_barriers -= 1

    def _perform_command(self, operation, *, pan, tilt, step_degrees, direction, manual_generation, persist):
        cleanup_retry = operation == "disconnect" and self._closed and not self.released
        if not cleanup_retry and (self._closed or self.client is None):
            raise OperatorError("Connect the selected bench session first.", "not_connected", 3)
        if operation not in ("connect", "status", "preview", "move", "stop", "disconnect", "manual", "disarm", "step"):
            raise OperatorError("Unsupported bench operation.")
        if not persist and operation != "status":
            raise OperatorError("Only automatic readback may omit operation recording.")
        regular = operation not in ("stop", "disarm")
        if regular and not self._regular.acquire(False):
            raise OperatorError("A PTU operation is active; Stop remains available.", "busy", 3)
        try:
            return self._perform(operation, pan=pan, tilt=tilt, step_degrees=step_degrees,
                                 direction=direction, manual_generation=manual_generation, persist=persist)
        finally:
            if regular:
                self._regular.release()

    def _perform(self, operation, *, pan, tilt, step_degrees, direction, manual_generation, persist):
        requested_at = time.monotonic()
        attempt = uuid4().hex
        record = {"schema": "satgs-bench-operation.v1", "attempt_id": attempt,
                  "operation": operation, "physical_state": "indeterminate",
                  "started_monotonic": requested_at, "wall_clock_quality": "unconfirmed",
                  "ptu_id": self.document["ptu_id"], "query_only": self.query_only,
                  "transport": self._transport_kind}
        if self._mode in ("manual", "query-only"):
            record["selected_context"] = _thaw(self._context)
        record["release_identity"] = self._release_identity
        if operation == "preview":
            record["requested_pan"] = pan if type(pan) in (int, float) and math.isfinite(pan) else None
            record["requested_tilt"] = tilt if type(tilt) in (int, float) and math.isfinite(tilt) else None
        if operation in ("manual", "step"):
            record["step_degrees"] = (step_degrees if type(step_degrees) in (int, float)
                                      and math.isfinite(step_degrees) else self._manual_step)
            record["step_direction"] = direction if direction in ("left", "right", "up", "down") else None
        deferred = operation in ("stop", "disconnect")
        started = dict(record, recording_deferred=deferred)
        if not deferred and persist:
            _write_new(self.workspace.root / f"bench-{attempt}-started.json", _bytes(started))
        with self._preview_lock:
            sequence = self._preview_sequence
            if operation in ("preview", "move", "stop", "disconnect", "step", "disarm", "manual"):
                self._preview_generation += 1
                self._preview_sequence = None
            generation = self._preview_generation
        if operation in ("preview", "move", "stop", "disconnect", "disarm"):
            self.disarm_manual()
        try:
            arguments = {"deadline": self._deadline(),
                         "cancel": threading.Event() if operation == "stop" else self.cancel}
            if self.query_only and operation not in ("connect", "status", "disconnect", "disarm"):
                raise OperatorError("Query-only sessions allow Connect, Status and Disconnect.", "unsupported", 3)
            if operation in ("preview", "move") and self.readback_snapshot()["motion_blocked"]:
                raise OperatorError(self.readback_snapshot()["motion_blocked"], "motion_blocked", 3)
            if operation == "manual":
                result = self._enable_manual(step_degrees, manual_generation)
            elif operation == "disarm":
                result = {"category": "ok", "submission": "none", "manual_enabled": False}
            elif operation == "step":
                result = self._step(direction, record, arguments["deadline"])
            elif operation == "preview":
                result = self.client.preview(pan, tilt, **arguments)
            elif operation == "move":
                if sequence is None:
                    raise OperatorError("Preview a target before Move.", "preview_required", 3)
                result = self.client.move(sequence, **arguments)
            elif operation == "disconnect" and self._closed:
                result = {"category": "ok", "submission": "none", "physical_state": "indeterminate",
                          "passive_cleanup_retry": True}
            else:
                result = getattr(self.client, operation)(**arguments)
            record.update(result if type(result) is dict else result.as_record())
            record["operation_code"] = record["operation"]
            record["operation"] = operation
            with self._preview_lock:
                if operation == "preview" and record["category"] == "ok" and generation == self._preview_generation:
                    self._preview_sequence = record["preview_sequence"]
        except OperatorError as error:
            record.update(category=error.code, message=str(error), submission="none")
        except Exception as error:
            with self._preview_lock:
                self._preview_sequence = None
            record.update(category=getattr(error, "primary", "exchange-failed"),
                          submission="unknown", possible_motion=operation in ("move", "stop"))
        if operation == "stop" and not self.query_only and record.get("category") != "ok":
            with self._preview_lock:
                self._motion_blocked = "Required Stop failed. Motion remains blocked pending owner review."
        if operation == "move" and record.get("category") != "ok" and record.get("submission") != "none":
            with self._preview_lock:
                self._motion_blocked = "Move outcome is unresolved. Motion remains blocked."
        if operation in ("manual", "step") and record.get("category") != "ok":
            self.disarm_manual()
        if operation not in ("manual", "disarm", "step"):
            self._remember_readback(record, requested_at)
        record["finished_monotonic"] = time.monotonic()
        record["elapsed_seconds"] = record["finished_monotonic"] - requested_at
        if not persist:
            record["automatic_readback"] = True
            return record
        if operation == "disconnect":
            try:
                self.close()
                record["cleanup_complete"] = True
            except OperatorError:
                record.update(cleanup_complete=False, cleanup_error="passive_cleanup_incomplete")
        record.update(started_recorded=True, result_recorded=False, recorded=False,
                      partial=record.get("cleanup_complete") is False)
        record["recording_errors"] = []
        if record["partial"]:
            record["message"] = "PTU passive cleanup is incomplete. Inspect the retained session."
        if deferred:
            try:
                _write_new(self.workspace.root / f"bench-{attempt}-started.json", _bytes(started))
            except (OperatorError, OSError):
                record.update(started_recorded=False, partial=True)
                record["recording_errors"].append("started")
                record["message"] = "PTU command was attempted; its start record could not be saved."
        try:
            record.update(result_recorded=True, recorded=record["started_recorded"])
            _write_new(self.workspace.root / f"bench-{attempt}-result.json", _bytes(record))
        except (OperatorError, OSError):
            record.update(result_recorded=False, recorded=False, partial=True)
            record["recording_errors"].append("result")
            record["message"] = "PTU command was attempted; its result could not be saved."
        return record

    def close(self):
        if self._closed and self.released:
            return
        with self._jog_lock:
            self._jog_closing = True
        self._finish_jog()
        self._closed = True
        self.disarm_manual()
        self.cancel.set()
        errors = []
        for name in ("client", "transport"):
            if name == "transport" and self.client is not None:
                continue
            owner = getattr(self, name)
            if owner is not None:
                try:
                    owner.close(deadline=self._deadline())
                    setattr(self, name, None)
                except Exception:
                    errors.append(name)
        if self._lease is not None and self.client is None and self.transport is None:
            try:
                self._lease.release()
                self._lease = None
            except Exception:
                errors.append("station-lease")
        if errors:
            raise OperatorError("Bench passive cleanup incomplete: " + ", ".join(errors), "cleanup", 7)


def interactive_bench(workspace, configuration_file, *, input_stream, output_stream):
    configuration_file = Path(configuration_file) if configuration_file is not None else None
    state = {"session": BenchSession(workspace, configuration_file), "regular": None, "stop": None,
             "requested": 0, "completed": 0, "failed": 0, "rejected": 0, "partial": 0,
             "cleanup_failed": False}
    output_lock = threading.Lock()
    state_lock = threading.Lock()
    closing = threading.Event()
    interrupted = False
    cleanup = []

    def emit(record):
        with output_lock:
            print(json.dumps(record, sort_keys=True), file=output_stream, flush=True)

    def finish(record, *, rejected=False):
        with state_lock:
            state["completed"] += 1
            state["failed"] += int(rejected or record.get("category") != "ok" or bool(record.get("partial")))
            state["rejected"] += int(rejected)
            state["partial"] += int(bool(record.get("partial")))
            if record.get("category") == "cleanup" or record.get("cleanup_complete") is False:
                state["cleanup_failed"] = True
        emit(record)

    def execute(operation, values):
        try:
            with state_lock:
                session = state["session"]
            if operation == "connect":
                if session._closed:
                    if not session.released:
                        raise OperatorError("Release the previous session's cleanup debt first.", "cleanup", 7)
                    session = BenchSession(workspace, configuration_file)
                    with state_lock:
                        state["session"] = session
                if closing.is_set():
                    session.cancel.set()
                    raise OperatorError("Local PTU connection cancelled.", "cancelled", 130)
                result = session.connect()
            elif operation == "jog":
                duration = values["seconds"]
                token = session.start_jog(values["direction"])["jog_token"]
                finish_at = time.monotonic() + duration
                try:
                    while not closing.is_set() and time.monotonic() < finish_at and session.renew_jog(token):
                        closing.wait(min(.1, max(0, finish_at - time.monotonic())))
                finally:
                    session.end_jog(token)
                    session._finish_jog()
                records = session.drain_jog_results()
                result = records[-1] if records else dict(operation="jog", category="missing_result",
                                                         physical_state="indeterminate")
            else:
                result = session.perform(operation, **values)
        except (OperatorError, ValueError) as error:
            result = {"status": "FAIL", "operation": operation, "category": getattr(error, "code", "invalid"),
                      "message": str(error), "physical_state": "indeterminate"}
        except Exception:
            result = {"status": "FAIL", "operation": operation, "category": "exchange-failed",
                      "message": "PTU operation failed. Inspect its saved result.", "physical_state": "indeterminate"}
        finish(result)

    try:
        for line in input_stream:
            words = line.split()
            if not words:
                continue
            if words == ["quit"]:
                break
            with state_lock:
                state["requested"] += 1
            try:
                if words == ["connect"]:
                    operation, values = "connect", {}
                elif len(words) == 3 and words[0] == "preview":
                    operation, values = "preview", {"pan": float(words[1]), "tilt": float(words[2])}
                elif len(words) == 2 and words[0] == "manual":
                    operation, values = "manual", {"step_degrees": float(words[1])}
                elif len(words) == 2 and words[0] == "step":
                    operation, values = "step", {"direction": words[1]}
                elif len(words) == 3 and words[0] == "jog":
                    seconds = float(words[2])
                    if not math.isfinite(seconds) or not 0 < seconds <= 3600:
                        raise OperatorError("Jog duration must be finite and between zero and 3600 seconds.", "invalid_jog", 3)
                    operation, values = "jog", {"direction": words[1], "seconds": seconds}
                elif words == ["disarm"]:
                    execute("disarm", {})
                    continue
                elif len(words) == 1 and words[0] in ("status", "move", "stop", "disconnect"):
                    operation, values = words[0], {}
                else:
                    raise OperatorError("Use connect, status, preview PAN TILT, move, manual STEP_DEGREES, "
                                        "step DIRECTION, jog DIRECTION SECONDS, disarm, stop, disconnect or quit.")
                if operation == "stop":
                    state["session"].disarm_manual()
                slot = "stop" if operation == "stop" else "regular"
                with state_lock:
                    previous = state[slot]
                    stopping = state["stop"]
                    if ((previous is not None and previous.is_alive())
                            or slot == "regular" and stopping is not None and stopping.is_alive()):
                        raise OperatorError("A PTU operation is active; Stop remains available.", "busy", 3)
                    worker = threading.Thread(target=execute, args=(operation, values),
                                              name="operator-cli-ptu-" + slot, daemon=False)
                    state[slot] = worker
                worker.start()
            except (OperatorError, ValueError) as error:
                finish({"status": "FAIL", "category": getattr(error, "code", "invalid"),
                        "message": str(error)}, rejected=True)
    except KeyboardInterrupt:
        interrupted = True
    finally:
        closing.set()
        with state_lock:
            session = state["session"]
            workers = (state["regular"], state["stop"])
        session.cancel.set()
        deadline = session._deadline()
        for worker in workers:
            if worker is not None and worker.ident is not None:
                try:
                    worker.join(max(0, deadline - time.monotonic()))
                except KeyboardInterrupt:
                    interrupted = True
        with state_lock:
            session = state["session"]
        try:
            session.close()
        except KeyboardInterrupt:
            interrupted = True
            cleanup.append("session")
        except Exception:
            cleanup.append("session")
        if any(worker is not None and worker.is_alive() for worker in workers):
            cleanup.append("command-worker")
    with state_lock:
        counts = {name: state[name] for name in ("requested", "completed", "failed", "rejected", "partial")}
        cleanup_failed = bool(cleanup or state["cleanup_failed"])
    exit_code = 130 if interrupted else 7 if cleanup_failed else 4 if counts["failed"] else 0
    category = ("cancelled" if interrupted else "cleanup_incomplete" if cleanup_failed else
                "operation_failed" if counts["failed"] else "closed")
    return {"session": "cleanup_incomplete" if cleanup else "closed", "category": category,
            "exit_code": exit_code, "operations": counts, "cleanup": cleanup,
            "physical_state": "unverified"}
