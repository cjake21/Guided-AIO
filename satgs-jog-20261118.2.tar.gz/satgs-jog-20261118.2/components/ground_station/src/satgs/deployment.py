from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
from collections.abc import Mapping, Sequence
from typing import Any


SCHEMA_VERSION = 1
REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
if __package__:
    from ._package_layout import INSTALLED
else:
    from _package_layout import INSTALLED
if not INSTALLED:
    DEFAULT_MANIFEST_PATH = REPOSITORY_ROOT / "config" / "deployment_profiles.json"
else:
    DEFAULT_MANIFEST_PATH = Path(__file__).parent / "data" / "deployment_profiles.json"

_PROFILE_ORDER = ("full_msel", "guided_arrow")
_PROFILE_IDS = frozenset(_PROFILE_ORDER)
_IDENTIFIER_PATTERN = re.compile(r"^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$")
_INSTANCE_PATTERN = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
_APPLICABILITY_VALUES = frozenset({"included", "external", "excluded"})
_INSTALL_MODES = frozenset({"editable", "standard"})
_PROVIDERS = frozenset(
    {"guided_arrow_hardware", "satgs", "sponsor", "station_hardware", "system"}
)

_INSTALL_TARGETS = {
    "meteor-api": ("lib/meteor-api", "editable"),
    "ground_station": (".", "editable"),
    "msel_post_processing": ("lib/msel_post_processing", "editable"),
    "cyberpowerpdu": ("lib/cyberpowerpdu", "editable"),
    "dsi_instruments": ("lib/dsi_instruments", "editable"),
    "pixhawk": ("lib/pixhawk", "editable"),
    "sat_tracker": ("lib/sat_tracker", "editable"),
    "serialptu": ("lib/sat_tracker/lib/serialptu", "editable"),
    "signal_hound": ("lib/signal_hound", "editable"),
    "signal_hound_native_wrapper": ("lib/signal_hound/lib", "standard"),
}

_PROFILE_PACKAGE_IDS = {
    "full_msel": (
        "meteor-api",
        "ground_station",
        "msel_post_processing",
        "cyberpowerpdu",
        "dsi_instruments",
        "pixhawk",
        "sat_tracker",
        "serialptu",
        "signal_hound",
        "signal_hound_native_wrapper",
    ),
    "guided_arrow": (
        "meteor-api",
        "ground_station",
        "sat_tracker",
        "serialptu",
        "pixhawk",
    ),
}

_MAX_MANIFEST_BYTES = 1_048_576

_PROFILE_METADATA = {
    "full_msel": ("Full M-SEL", True),
    "guided_arrow": ("Guided Arrow AIO", False),
}

_PROFILE_HOST_ROLES = {
    "full_msel": ("controller", "pointing_controller", "rf_controller"),
    "guided_arrow": ("controller", "ptu", "pointing_observer"),
}

_PROFILE_INSTANCES = {
    "full_msel": (),
    "guided_arrow": (
        ("ptu-1", "qpt130", "guided_arrow_hardware"),
        ("pixhawk-1", "pixhawk_dual_gps", "guided_arrow_hardware"),
    ),
}

_PROFILE_SERVICES = {
    "full_msel": (
        ("broker.activemq", "activemq.service", "system", ("controller",)),
        ("power.pdu_hpa", "cyberpower_pdu.service", "satgs", ("controller",)),
        ("rf.frontend", "frontend.service", "satgs", ("rf_controller",)),
        ("pointing.ptu", "ptu.service", "satgs", ("pointing_controller",)),
        (
            "pointing.pixhawk",
            "pixhawk.service",
            "satgs",
            ("pointing_controller",),
        ),
        ("rf.loopback", "rf_loopback.service", "satgs", ("controller",)),
        (
            "recording.signal_hound_iq",
            "sh_iq_logger.service",
            "satgs",
            ("controller",),
        ),
        (
            "recording.signal_hound_trace",
            "sh_trace_logger.service",
            "satgs",
            ("controller",),
        ),
        (
            "orchestration.queue_manager",
            "ground_station.service",
            "satgs",
            ("controller",),
        ),
    ),
    "guided_arrow": (
        ("broker.activemq", "activemq.service", "system", ("controller",)),
        ("pointing.ptu", "ptu.service", "satgs", ("ptu",)),
        (
            "pointing.pixhawk",
            "pixhawk.service",
            "satgs",
            ("pointing_observer",),
        ),
        (
            "orchestration.queue_manager",
            "ground_station.service",
            "satgs",
            ("controller",),
        ),
    ),
}

_PROFILE_CAPABILITIES = {
    "full_msel": (
        ("broker.activemq", "system", "included", True, True, ()),
        ("orchestration.queue_manager", "satgs", "included", True, True, ()),
        ("execution.pass_runner", "satgs", "included", True, True, ()),
        ("orbit.pass_finder", "satgs", "included", True, True, ()),
        ("pointing.ptu", "satgs", "included", False, True, ()),
        (
            "pointing.qpt130",
            "station_hardware",
            "included",
            False,
            True,
            (),
        ),
        ("pointing.pixhawk", "satgs", "included", False, True, ()),
        (
            "pointing.dual_gps",
            "station_hardware",
            "included",
            False,
            True,
            (),
        ),
        ("time.ntp", "system", "included", True, True, ()),
        ("rf.frontend", "satgs", "included", False, True, ()),
        ("power.pdu_hpa", "satgs", "included", False, True, ()),
        ("recording.signal_hound", "satgs", "included", False, True, ()),
        (
            "processing.msel_post_processing",
            "satgs",
            "included",
            False,
            True,
            (),
        ),
    ),
    "guided_arrow": (
        ("broker.activemq", "system", "included", True, True, ()),
        ("orchestration.queue_manager", "satgs", "included", True, True, ()),
        ("execution.pass_runner", "satgs", "included", True, True, ()),
        ("orbit.pass_finder", "satgs", "included", True, True, ()),
        ("pointing.ptu", "satgs", "included", True, True, ("ptu-1",)),
        (
            "pointing.qpt130",
            "guided_arrow_hardware",
            "included",
            True,
            True,
            ("ptu-1",),
        ),
        (
            "pointing.pixhawk",
            "satgs",
            "included",
            True,
            True,
            ("pixhawk-1",),
        ),
        (
            "pointing.dual_gps",
            "guided_arrow_hardware",
            "included",
            True,
            True,
            ("pixhawk-1",),
        ),
        ("time.ntp", "system", "included", True, True, ()),
        ("network.connectivity", "sponsor", "external", False, False, ()),
        ("rf.frontend", "sponsor", "external", False, False, ()),
        ("power.pdu_hpa", "sponsor", "external", False, False, ()),
        ("recording.signal_hound", "sponsor", "external", False, False, ()),
        (
            "processing.msel_post_processing",
            "sponsor",
            "external",
            False,
            False,
            (),
        ),
    ),
}

class DeploymentError(Exception):
    pass


class ManifestError(DeploymentError):
    pass


class UnknownProfileError(DeploymentError):
    pass


class ApplyUnsupportedError(DeploymentError):
    pass


@dataclass(frozen=True, slots=True)
class ComponentInstance:
    id: str
    component: str
    provider: str


@dataclass(frozen=True, slots=True)
class InstallStep:
    id: str
    path: str
    install_mode: str


@dataclass(frozen=True, slots=True)
class PlannedService:
    id: str
    unit: str
    provider: str
    host_roles: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Capability:
    id: str
    provider: str
    applicability: str
    required_by_default: bool
    supported: bool
    instance_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DeploymentProfile:
    id: str
    display_name: str
    apply_supported: bool
    host_roles: tuple[str, ...]
    instances: tuple[ComponentInstance, ...]
    packages: tuple[InstallStep, ...]
    services: tuple[PlannedService, ...]
    capabilities: tuple[Capability, ...]


@dataclass(frozen=True, slots=True)
class DeploymentManifest:
    schema_version: int
    profiles: tuple[DeploymentProfile, ...]


def _object_without_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ManifestError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise ManifestError(f"non-finite JSON number {value!r} is not allowed")


def _expect_object(value: Any, context: str) -> Mapping[str, Any]:
    if type(value) is not dict:
        raise ManifestError(f"{context} must be an object")
    return value


def _expect_list(value: Any, context: str) -> list[Any]:
    if type(value) is not list:
        raise ManifestError(f"{context} must be a list")
    return value


def _expect_fields(
    value: Mapping[str, Any], expected: frozenset[str], context: str
) -> None:
    actual = frozenset(value)
    missing = sorted(expected - actual)
    unknown = sorted(actual - expected)
    if missing:
        names = ", ".join(repr(name) for name in missing)
        raise ManifestError(f"{context} is missing fields: {names}")
    if unknown:
        names = ", ".join(repr(name) for name in unknown)
        raise ManifestError(f"{context} has unknown fields: {names}")


def _expect_string(value: Any, context: str) -> str:
    if type(value) is not str or not value:
        raise ManifestError(f"{context} must be a non-empty string")
    if any(
        ord(character) < 0x20 or 0x7F <= ord(character) <= 0x9F
        for character in value
    ):
        raise ManifestError(f"{context} contains a control character")
    return value


def _expect_boolean(value: Any, context: str) -> bool:
    if type(value) is not bool:
        raise ManifestError(f"{context} must be a boolean")
    return value


def _expect_identifier(value: Any, context: str) -> str:
    identifier = _expect_string(value, context)
    if not _IDENTIFIER_PATTERN.fullmatch(identifier):
        raise ManifestError(f"{context} is not a valid stable identifier: {identifier!r}")
    return identifier


def _expect_provider(value: Any, context: str) -> str:
    provider = _expect_identifier(value, context)
    if provider not in _PROVIDERS:
        raise ManifestError(
            f"{context} must be one of: {', '.join(sorted(_PROVIDERS))}"
        )
    return provider


def _expect_instance_identifier(value: Any, context: str) -> str:
    identifier = _expect_string(value, context)
    if not _INSTANCE_PATTERN.fullmatch(identifier):
        raise ManifestError(f"{context} is not a valid instance identifier: {identifier!r}")
    return identifier


def _unique_strings(
    value: Any,
    context: str,
    *,
    instance_identifiers: bool = False,
) -> tuple[str, ...]:
    entries = _expect_list(value, context)
    result: list[str] = []
    seen: set[str] = set()
    for index, entry in enumerate(entries):
        entry_context = f"{context}[{index}]"
        if instance_identifiers:
            identifier = _expect_instance_identifier(entry, entry_context)
        else:
            identifier = _expect_identifier(entry, entry_context)
        if identifier in seen:
            raise ManifestError(f"{context} contains duplicate identifier {identifier!r}")
        seen.add(identifier)
        result.append(identifier)
    return tuple(result)


def _parse_instances(value: Any, context: str) -> tuple[ComponentInstance, ...]:
    entries = _expect_list(value, context)
    result: list[ComponentInstance] = []
    seen: set[str] = set()
    expected = frozenset({"id", "component", "provider"})
    for index, entry in enumerate(entries):
        entry_context = f"{context}[{index}]"
        item = _expect_object(entry, entry_context)
        _expect_fields(item, expected, entry_context)
        instance_id = _expect_instance_identifier(item["id"], f"{entry_context}.id")
        if instance_id in seen:
            raise ManifestError(f"{context} contains duplicate identifier {instance_id!r}")
        seen.add(instance_id)
        result.append(
            ComponentInstance(
                id=instance_id,
                component=_expect_identifier(
                    item["component"], f"{entry_context}.component"
                ),
                provider=_expect_provider(item["provider"], f"{entry_context}.provider"),
            )
        )
    return tuple(result)


def _parse_packages(value: Any, context: str) -> tuple[InstallStep, ...]:
    entries = _expect_list(value, context)
    if not entries:
        raise ManifestError(f"{context} must not be empty")
    result: list[InstallStep] = []
    seen: set[str] = set()
    expected = frozenset({"id", "path", "install_mode"})
    for index, entry in enumerate(entries):
        entry_context = f"{context}[{index}]"
        item = _expect_object(entry, entry_context)
        _expect_fields(item, expected, entry_context)
        package_id = _expect_identifier(item["id"], f"{entry_context}.id")
        if package_id in seen:
            raise ManifestError(f"{context} contains duplicate identifier {package_id!r}")
        seen.add(package_id)
        path = _expect_string(item["path"], f"{entry_context}.path")
        path_value = PurePosixPath(path)
        if path_value.is_absolute() or ".." in path_value.parts or "\\" in path:
            raise ManifestError(f"{entry_context}.path must be repository-relative")
        install_mode = _expect_string(
            item["install_mode"], f"{entry_context}.install_mode"
        )
        if install_mode not in _INSTALL_MODES:
            raise ManifestError(
                f"{entry_context}.install_mode must be one of: "
                f"{', '.join(sorted(_INSTALL_MODES))}"
            )
        expected_target = _INSTALL_TARGETS.get(package_id)
        if expected_target is None:
            raise ManifestError(f"{entry_context}.id is not an approved install target")
        if (path, install_mode) != expected_target:
            raise ManifestError(
                f"{entry_context} does not match the approved target for {package_id!r}"
            )
        result.append(
            InstallStep(id=package_id, path=path, install_mode=install_mode)
        )
    return tuple(result)


def _parse_services(
    value: Any, context: str, profile_roles: frozenset[str]
) -> tuple[PlannedService, ...]:
    entries = _expect_list(value, context)
    result: list[PlannedService] = []
    seen: set[str] = set()
    expected = frozenset({"id", "unit", "provider", "host_roles"})
    for index, entry in enumerate(entries):
        entry_context = f"{context}[{index}]"
        item = _expect_object(entry, entry_context)
        _expect_fields(item, expected, entry_context)
        service_id = _expect_identifier(item["id"], f"{entry_context}.id")
        if service_id in seen:
            raise ManifestError(f"{context} contains duplicate identifier {service_id!r}")
        seen.add(service_id)
        unit = _expect_string(item["unit"], f"{entry_context}.unit")
        host_roles = _unique_strings(item["host_roles"], f"{entry_context}.host_roles")
        if not host_roles:
            raise ManifestError(f"{entry_context}.host_roles must not be empty")
        unknown_roles = sorted(set(host_roles) - profile_roles)
        if unknown_roles:
            raise ManifestError(
                f"{entry_context}.host_roles reference unknown roles: "
                f"{', '.join(unknown_roles)}"
            )
        result.append(
            PlannedService(
                id=service_id,
                unit=unit,
                provider=_expect_provider(
                    item["provider"], f"{entry_context}.provider"
                ),
                host_roles=host_roles,
            )
        )
    return tuple(result)


def _parse_capabilities(
    value: Any, context: str, instance_ids: frozenset[str]
) -> tuple[Capability, ...]:
    entries = _expect_list(value, context)
    if not entries:
        raise ManifestError(f"{context} must not be empty")
    result: list[Capability] = []
    seen: set[str] = set()
    expected = frozenset(
        {
            "id",
            "provider",
            "applicability",
            "required_by_default",
            "supported",
            "instance_ids",
        }
    )
    for index, entry in enumerate(entries):
        entry_context = f"{context}[{index}]"
        item = _expect_object(entry, entry_context)
        _expect_fields(item, expected, entry_context)
        capability_id = _expect_identifier(item["id"], f"{entry_context}.id")
        if capability_id in seen:
            raise ManifestError(f"{context} contains duplicate identifier {capability_id!r}")
        seen.add(capability_id)
        applicability = _expect_string(
            item["applicability"], f"{entry_context}.applicability"
        )
        if applicability not in _APPLICABILITY_VALUES:
            raise ManifestError(
                f"{entry_context}.applicability must be one of: "
                f"{', '.join(sorted(_APPLICABILITY_VALUES))}"
            )
        required_by_default = _expect_boolean(
            item["required_by_default"], f"{entry_context}.required_by_default"
        )
        supported = _expect_boolean(item["supported"], f"{entry_context}.supported")
        provider = _expect_provider(item["provider"], f"{entry_context}.provider")
        capability_instances = _unique_strings(
            item["instance_ids"],
            f"{entry_context}.instance_ids",
            instance_identifiers=True,
        )
        unknown_instances = sorted(set(capability_instances) - instance_ids)
        if unknown_instances:
            raise ManifestError(
                f"{entry_context}.instance_ids reference unknown instances: "
                f"{', '.join(unknown_instances)}"
            )
        if applicability == "included" and not supported:
            raise ManifestError(
                f"{entry_context} capability {capability_id!r} is contradictory: "
                "included capabilities must be supported"
            )
        if provider == "sponsor" and applicability == "included":
            raise ManifestError(
                f"{entry_context} capability {capability_id!r} is contradictory: "
                "a sponsor-provided capability cannot be locally included"
            )
        if applicability == "external" and provider != "sponsor":
            raise ManifestError(
                f"{entry_context} capability {capability_id!r} is contradictory: "
                "an external capability must use the sponsor provider"
            )
        if required_by_default and (not supported or applicability != "included"):
            raise ManifestError(
                f"{entry_context} capability {capability_id!r} is contradictory: "
                "a default requirement must be included and supported"
            )
        if applicability != "included" and capability_instances:
            raise ManifestError(
                f"{entry_context} capability {capability_id!r} is contradictory: "
                "external or excluded capabilities cannot declare local instances"
            )
        result.append(
            Capability(
                id=capability_id,
                provider=provider,
                applicability=applicability,
                required_by_default=required_by_default,
                supported=supported,
                instance_ids=capability_instances,
            )
        )
    return tuple(result)


def _validate_ordered_records(
    profile_id: str,
    record_name: str,
    fields: tuple[str, ...],
    actual: tuple[tuple[Any, ...], ...],
    expected: tuple[tuple[Any, ...], ...],
) -> None:
    actual_ids = tuple(record[0] for record in actual)
    expected_ids = tuple(record[0] for record in expected)
    if actual_ids != expected_ids:
        raise ManifestError(
            f"profile {profile_id!r} {record_name} identifiers and order "
            "must match the canonical built-in contract"
        )

    for actual_record, expected_record in zip(actual, expected):
        for field, actual_value, expected_value in zip(
            fields, actual_record[1:], expected_record[1:]
        ):
            if actual_value != expected_value:
                raise ManifestError(
                    f"profile {profile_id!r} {record_name} "
                    f"{actual_record[0]!r} field {field!r} must match "
                    "the canonical built-in contract"
                )


def _validate_profile_contract(profile: DeploymentProfile) -> None:
    expected_package_ids = _PROFILE_PACKAGE_IDS.get(profile.id)
    if expected_package_ids is None:
        return

    expected_display_name, expected_apply_supported = _PROFILE_METADATA[
        profile.id
    ]
    if profile.display_name != expected_display_name:
        raise ManifestError(
            f"profile {profile.id!r} display_name must match "
            "the canonical built-in contract"
        )
    if profile.apply_supported is not expected_apply_supported:
        raise ManifestError(
            f"profile {profile.id!r} apply_supported must match "
            "the canonical built-in contract"
        )

    package_ids = tuple(step.id for step in profile.packages)
    if package_ids != expected_package_ids:
        raise ManifestError(
            f"profile {profile.id!r} package plan must match the canonical built-in contract"
        )

    if profile.host_roles != _PROFILE_HOST_ROLES[profile.id]:
        raise ManifestError(
            f"profile {profile.id!r} host roles must match the canonical built-in contract"
        )

    instances = tuple(
        (instance.id, instance.component, instance.provider)
        for instance in profile.instances
    )
    _validate_ordered_records(
        profile.id,
        "instance",
        ("component", "provider"),
        instances,
        _PROFILE_INSTANCES[profile.id],
    )

    services = tuple(
        (service.id, service.unit, service.provider, service.host_roles)
        for service in profile.services
    )
    _validate_ordered_records(
        profile.id,
        "service",
        ("unit", "provider", "host_roles"),
        services,
        _PROFILE_SERVICES[profile.id],
    )

    capabilities = tuple(
        (
            capability.id,
            capability.provider,
            capability.applicability,
            capability.required_by_default,
            capability.supported,
            capability.instance_ids,
        )
        for capability in profile.capabilities
    )
    _validate_ordered_records(
        profile.id,
        "capability",
        (
            "provider",
            "applicability",
            "required_by_default",
            "supported",
            "instance_ids",
        ),
        capabilities,
        _PROFILE_CAPABILITIES[profile.id],
    )


def _parse_profile(value: Any, index: int) -> DeploymentProfile:
    context = f"profiles[{index}]"
    item = _expect_object(value, context)
    expected = frozenset(
        {
            "id",
            "display_name",
            "apply_supported",
            "host_roles",
            "instances",
            "packages",
            "services",
            "capabilities",
        }
    )
    _expect_fields(item, expected, context)
    profile_id = _expect_identifier(item["id"], f"{context}.id")
    context = f"profile {profile_id!r}"
    host_roles = _unique_strings(item["host_roles"], f"{context}.host_roles")
    if not host_roles:
        raise ManifestError(f"{context}.host_roles must not be empty")
    instances = _parse_instances(item["instances"], f"{context}.instances")
    instance_ids = frozenset(instance.id for instance in instances)
    profile = DeploymentProfile(
        id=profile_id,
        display_name=_expect_string(item["display_name"], f"{context}.display_name"),
        apply_supported=_expect_boolean(
            item["apply_supported"], f"{context}.apply_supported"
        ),
        host_roles=host_roles,
        instances=instances,
        packages=_parse_packages(item["packages"], f"{context}.packages"),
        services=_parse_services(
            item["services"], f"{context}.services", frozenset(host_roles)
        ),
        capabilities=_parse_capabilities(
            item["capabilities"], f"{context}.capabilities", instance_ids
        ),
    )
    _validate_profile_contract(profile)
    return profile


def _read_manifest_text(manifest_path: Path) -> str:
    path_label = repr(str(manifest_path))
    try:
        manifest_status = manifest_path.lstat()
        if stat.S_ISLNK(manifest_status.st_mode):
            raise ManifestError(
                f"deployment manifest {path_label} must be a regular file; "
                "symbolic links are not allowed"
            )
        if not stat.S_ISREG(manifest_status.st_mode):
            raise ManifestError(
                f"deployment manifest {path_label} must be a regular file"
            )

        guarded_flags = (
            getattr(os, "O_CLOEXEC", 0)
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_NONBLOCK", 0)
        )
        with open(
            manifest_path,
            "rb",
            opener=lambda path, flags: os.open(path, flags | guarded_flags),
        ) as manifest_file:
            opened_status = os.fstat(manifest_file.fileno())
            if not stat.S_ISREG(opened_status.st_mode):
                raise ManifestError(
                    f"deployment manifest {path_label} must be a regular file"
                )
            if (opened_status.st_dev, opened_status.st_ino) != (
                manifest_status.st_dev,
                manifest_status.st_ino,
            ):
                raise ManifestError(
                    f"deployment manifest {path_label} changed while being opened"
                )
            payload = manifest_file.read(_MAX_MANIFEST_BYTES + 1)
    except ManifestError:
        raise
    except (OSError, UnicodeError) as error:
        if isinstance(error, OSError):
            reason = error.strerror or type(error).__name__
        else:
            reason = type(error).__name__
        raise ManifestError(
            f"cannot read deployment manifest {path_label}: {reason}"
        ) from error

    if len(payload) > _MAX_MANIFEST_BYTES:
        raise ManifestError(
            f"deployment manifest {path_label} exceeds "
            f"{_MAX_MANIFEST_BYTES} bytes"
        )

    try:
        return payload.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ManifestError(
            f"cannot read deployment manifest {path_label}: "
            f"invalid UTF-8 at byte {error.start}"
        ) from error


def load_manifest(path: Path | str | None = None) -> DeploymentManifest:
    manifest_path = Path(path) if path is not None else DEFAULT_MANIFEST_PATH
    path_label = repr(str(manifest_path))
    text = _read_manifest_text(manifest_path)
    try:
        raw = json.loads(
            text,
            object_pairs_hook=_object_without_duplicate_keys,
            parse_constant=_reject_json_constant,
        )
    except json.JSONDecodeError as error:
        raise ManifestError(
            f"invalid JSON in deployment manifest {path_label}: "
            f"line {error.lineno}, column {error.colno}"
        ) from error
    except (RecursionError, ValueError) as error:
        raise ManifestError(
            f"invalid JSON in deployment manifest {path_label}: "
            "value or nesting limit exceeded"
        ) from error

    root = _expect_object(raw, "manifest")
    _expect_fields(root, frozenset({"schema_version", "profiles"}), "manifest")
    schema_version = root["schema_version"]
    if type(schema_version) is not int:
        raise ManifestError("manifest.schema_version must be an integer")
    if schema_version != SCHEMA_VERSION:
        raise ManifestError(
            f"unsupported schema_version {schema_version!r}; expected {SCHEMA_VERSION}"
        )

    profile_entries = _expect_list(root["profiles"], "manifest.profiles")
    profiles: list[DeploymentProfile] = []
    seen: set[str] = set()
    for index, entry in enumerate(profile_entries):
        profile = _parse_profile(entry, index)
        if profile.id in seen:
            raise ManifestError(
                f"manifest.profiles contains duplicate identifier {profile.id!r}"
            )
        seen.add(profile.id)
        profiles.append(profile)

    if seen != _PROFILE_IDS:
        missing = sorted(_PROFILE_IDS - seen)
        unexpected = sorted(seen - _PROFILE_IDS)
        details: list[str] = []
        if missing:
            details.append(f"missing {', '.join(missing)}")
        if unexpected:
            details.append(f"unexpected {', '.join(unexpected)}")
        raise ManifestError(
            "manifest profile identifiers must be exactly full_msel and guided_arrow: "
            + "; ".join(details)
        )

    profile_ids = tuple(profile.id for profile in profiles)
    if profile_ids != _PROFILE_ORDER:
        raise ManifestError(
            "manifest profile identifiers and order must be exactly: "
            + ", ".join(_PROFILE_ORDER)
        )

    profiles_by_id = {profile.id: profile for profile in profiles}
    if not profiles_by_id["full_msel"].apply_supported:
        raise ManifestError("full_msel must retain apply support during compatibility")
    if profiles_by_id["guided_arrow"].apply_supported:
        raise ManifestError("guided_arrow apply support is not enabled in Slice 1")
    return DeploymentManifest(schema_version=schema_version, profiles=tuple(profiles))


def resolve_profile(
    profile_id: str, manifest_path: Path | str | None = None
) -> DeploymentProfile:
    manifest = load_manifest(manifest_path)
    for profile in manifest.profiles:
        if profile.id == profile_id:
            return profile
    available = ", ".join(profile.id for profile in manifest.profiles)
    raise UnknownProfileError(
        f"unknown deployment profile {profile_id!r}; expected one of: {available}"
    )


def ensure_apply_supported(profile: DeploymentProfile) -> None:
    if profile.apply_supported:
        return
    raise ApplyUnsupportedError(
        f"{profile.display_name} apply is not enabled in Slice 1. "
        f"Re-run the installer with '--profile {profile.id} --dry-run' to view the "
        "deployment plan. Apply support requires a later approved slice."
    )


def render_plan(profile: DeploymentProfile) -> str:
    lines = [
        f"Resolved profile: {profile.id}",
        f"Display name: {profile.display_name}",
        f"Apply support: {'enabled' if profile.apply_supported else 'not enabled in Slice 1'}",
        "Host roles:",
    ]
    lines.extend(
        f"  {index:02d}. {role}" for index, role in enumerate(profile.host_roles, 1)
    )
    lines.append("Package plan:")
    lines.extend(
        f"  {index:02d}. {step.id} | {step.install_mode} | {step.path}"
        for index, step in enumerate(profile.packages, 1)
    )
    lines.append("Planned services (not installed or started):")
    lines.extend(
        f"  {index:02d}. {service.id} | {service.unit} | "
        f"provider={service.provider} | host_roles={','.join(service.host_roles)}"
        for index, service in enumerate(profile.services, 1)
    )
    lines.append("Capabilities (static installation intent only):")
    for index, capability in enumerate(profile.capabilities, 1):
        instances = ",".join(capability.instance_ids) or "none"
        lines.append(
            f"  {index:02d}. {capability.id} | provider={capability.provider} | "
            f"applicability={capability.applicability} | "
            f"supported={str(capability.supported).lower()} | "
            f"required_by_default={str(capability.required_by_default).lower()} | "
            f"instances={instances}"
        )
    return "\n".join(lines) + "\n"


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Resolve SATGS deployment profiles")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("validate-profile", "plan", "check-apply"):
        command_parser = subparsers.add_parser(command)
        command_parser.add_argument("--profile", required=True)
        command_parser.add_argument(
            "--manifest", type=Path, default=DEFAULT_MANIFEST_PATH
        )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        profile = resolve_profile(args.profile, args.manifest)
        if args.command == "plan":
            sys.stdout.write(render_plan(profile))
        elif args.command == "check-apply":
            ensure_apply_supported(profile)
    except ApplyUnsupportedError as error:
        print(f"deployment error: {error}", file=sys.stderr)
        return 3
    except DeploymentError as error:
        print(f"deployment error: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
