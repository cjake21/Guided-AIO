"""Cooperative station leases for explicitly managed operator workspaces."""

from contextlib import ExitStack
import fcntl
import hashlib
import os
from pathlib import Path
import re
import stat

MARKER = "satgs_operator_workspace"


class ActivityError(ValueError):
    def __init__(self, message, *, code="conflict"):
        super().__init__(message)
        self.code = code


def workspace_path(root):
    path = Path(os.path.abspath(os.fspath(root)))
    if path == Path("/") or path.parts[1] in ("dev", "proc", "sys"):
        raise ActivityError("Use an explicit private scratch workspace.", code="invalid")
    return path


def open_workspace(root):
    path = workspace_path(root)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    descriptor = None
    try:
        with ExitStack() as parents:
            directory = os.open("/", flags)
            parents.callback(os.close, directory)
            for component in path.parts[1:]:
                directory = os.open(component, flags, dir_fd=directory)
                parents.callback(os.close, directory)
            info = os.fstat(directory)
            if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700:
                raise ActivityError("Managed workspace must be an owned 0700 directory.", code="invalid")
            descriptor = os.dup(directory)
        return descriptor
    except (OSError, ValueError):
        if descriptor is not None:
            os.close(descriptor)
        raise ActivityError("Managed workspace cannot be opened safely.", code="invalid") from None


def validate_marker(station_path, settings):
    marker = settings.get(MARKER)
    if marker is None:
        return None
    path = workspace_path(Path(station_path).parent)
    if (Path(os.path.abspath(os.fspath(station_path))) != path / "station.json"
            or type(marker) is not dict
            or set(marker) != {"schema_version", "id", "root"}
            or type(marker["schema_version"]) is not int or marker["schema_version"] != 1
            or type(marker["id"]) is not str
            or re.fullmatch(r"[0-9a-f]{32}", marker["id"]) is None
            or marker["root"] != str(path)):
        raise ActivityError("Managed station marker, identity and path do not match.", code="invalid")
    descriptor = open_workspace(path)
    os.close(descriptor)
    return marker


class StationLease:
    def __init__(self, root):
        self.root = workspace_path(root)
        self.descriptor = None

    def acquire(self):
        directory = open_workspace(self.root)
        descriptor = None
        try:
            flags = os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
            descriptor = os.open(".activity.lock", flags, 0o600, dir_fd=directory)
            opened = os.fstat(descriptor)
            current = os.stat(".activity.lock", dir_fd=directory, follow_symlinks=False)
            if (not stat.S_ISREG(opened.st_mode) or opened.st_nlink != 1
                    or opened.st_uid != os.geteuid() or stat.S_IMODE(opened.st_mode) != 0o600
                    or (opened.st_dev, opened.st_ino) != (current.st_dev, current.st_ino)):
                raise ActivityError("Station lease must be a stable private ordinary file.", code="invalid")
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ActivityError("Station has active work or another save; retry after it finishes.", code="active_work") from None
            current = os.stat(".activity.lock", dir_fd=directory, follow_symlinks=False)
            if (opened.st_dev, opened.st_ino) != (current.st_dev, current.st_ino):
                raise ActivityError("Station lease changed during admission; inspect before retrying.")
            self.descriptor = descriptor
            descriptor = None
            return self
        except OSError:
            raise ActivityError("Station lease could not be acquired safely.", code="io") from None
        finally:
            if descriptor is not None:
                os.close(descriptor)
            os.close(directory)

    def release(self):
        descriptor, self.descriptor = self.descriptor, None
        if descriptor is not None:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
            finally:
                os.close(descriptor)

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *arguments):
        self.release()


def acquire_runner_activity(station_path, settings, *, expected_sha256=None):
    """Unmarked legacy stations keep their existing admission behavior."""
    from satgs.deployment_cli import CliInputError, read_regular_bytes
    from satgs.runtime_configuration import RuntimeConfigurationError, _parse_station_yaml

    marker = validate_marker(station_path, settings)
    if marker is None:
        return None
    lease = StationLease(Path(station_path).parent).acquire()
    try:
        raw = read_regular_bytes(str(station_path), input_kind="Managed station")
        current = _parse_station_yaml(raw, allow_inline_ca=True)
        current_marker = validate_marker(station_path, current)
        if current_marker != marker:
            raise ActivityError("Managed station identity changed before the run was admitted.")
        if expected_sha256 is not None:
            if hashlib.sha256(raw).hexdigest() != expected_sha256:
                raise ActivityError("Managed station changed after runtime admission; reload before running.")
        elif current != settings:
            raise ActivityError("Managed station changed while loading; reload before running.")
        return lease
    except (CliInputError, RuntimeConfigurationError):
        lease.release()
        raise ActivityError("Managed runtime station could not be admitted safely.", code="invalid") from None
    except BaseException:
        lease.release()
        raise
