"""Open the selected installed release's guide without station dependencies."""

import os
from pathlib import Path
import subprocess

from satgs._operator_contract import OperatorError


_GUIDE_DIRECTORY = Path(__file__).resolve().parent / "data"
_VIEWER = Path("/usr/bin/xdg-open")
_VIEWER_TIMEOUT_SECONDS = 5
_VIEWER_ENVIRONMENT = (
    "HOME", "USER", "LOGNAME", "DISPLAY", "WAYLAND_DISPLAY", "XAUTHORITY",
    "XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS", "XDG_CURRENT_DESKTOP",
    "XDG_SESSION_DESKTOP", "XDG_SESSION_TYPE", "DESKTOP_SESSION",
    "LANG", "LC_ALL", "LC_CTYPE",
)


def _packaged_file(name):
    path = _GUIDE_DIRECTORY / name
    if path.is_symlink() or not path.is_file():
        raise OSError("Bundled guide resource is unavailable.")
    return path


def dispatch_docs(*, text=False):
    try:
        text_path = _packaged_file("user-guide.txt")
        content = text_path.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        raise OperatorError("The bundled user guide is unavailable. Repair this application installation.",
                            "docs_unavailable", 4) from None
    result = {"mode": "text", "reason": "text_requested", "message": "", "text": content,
              "path": str(text_path)}
    if text:
        return result
    if any(os.environ.get(name) for name in ("SSH_CONNECTION", "SSH_CLIENT", "SSH_TTY")):
        return dict(result, reason="ssh_session", message="SSH session: showing the bundled user guide as text.")
    if not any(os.environ.get(name) for name in ("DISPLAY", "WAYLAND_DISPLAY")):
        return dict(result, reason="no_display", message="No desktop display: showing the bundled user guide as text.")
    try:
        guide = _packaged_file("user-guide.html")
    except OSError:
        return dict(result, reason="html_unavailable",
                    message="The bundled HTML guide is unavailable. Showing the text guide.")
    result["path"] = str(guide)
    environment = {name: os.environ[name] for name in _VIEWER_ENVIRONMENT if name in os.environ}
    environment["PATH"] = "/usr/bin:/bin"
    try:
        process = subprocess.run([str(_VIEWER), str(guide)], shell=False,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            env=environment, timeout=_VIEWER_TIMEOUT_SECONDS, check=False)
    except subprocess.TimeoutExpired:
        return dict(result, reason="viewer_timeout",
                    message="Document viewer dispatch timed out. Showing the text guide.")
    except FileNotFoundError:
        return dict(result, reason="viewer_unavailable",
                    message="The desktop document viewer is unavailable. Showing the text guide.")
    except OSError:
        return dict(result, reason="viewer_failed",
                    message="Document viewer dispatch failed. Showing the text guide.")
    if process.returncode != 0:
        return dict(result, reason="viewer_failed",
                    message="Document viewer dispatch failed. Showing the text guide.")
    return dict(result, mode="viewer_dispatched", reason="viewer_dispatched",
                message="User guide sent to the default document viewer. Window visibility is not confirmed.")
