"""Frozen operator requests consumed by the existing pass runner."""

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import stat
import threading
from uuid import uuid4

from satgs.deployment_cli import read_regular_bytes
from satgs.operator_core import OperatorError, _bytes, _digest, _identity, _write_new
from satgs.operator_activity import ActivityError, open_workspace
from satgs.runtime_configuration import (
    RuntimeConfigurationError, load_runtime_configuration, snapshot_runtime_context,
)


@dataclass(frozen=True, slots=True)
class RunRequest:
    identity: str
    station_revision: str
    plan_id: str
    opportunity: int
    mode: str
    _document: bytes = field(repr=False)
    context: object = field(repr=False)

    def to_dict(self):
        return json.loads(self._document)


def prepare_run(workspace, *, plan_id, deployment_config, runtime_bindings,
                station_config, tle_file, duration, opportunity=1, mode="operational"):
    if mode not in ("operational", "rehearsal"):
        raise OperatorError("Unsupported execution mode.")
    plan_id = _identity(plan_id, "Plan")
    revision, settings = workspace.snapshot()
    plan = workspace._artifact(f"plan-{plan_id}.json")
    content = {key: value for key, value in plan.items() if key != "plan_id"}
    if plan.get("plan_id") != plan_id or _digest(_bytes(content)) != plan_id:
        raise OperatorError("Plan record is inconsistent.", "artifact", 4)
    if plan.get("station_revision") != revision:
        raise OperatorError("Station changed after planning; calculate a new plan.", "stale_revision", 3)
    choices = plan.get("opportunities")
    if (type(opportunity) is not int or type(choices) is not list
            or not 1 <= opportunity <= len(choices)):
        raise OperatorError("Select an existing pass opportunity.")
    selected = choices[opportunity - 1]
    if type(duration) not in (int, float) or not math.isfinite(duration) or duration <= 0:
        raise OperatorError("Run duration must be positive finite seconds.")
    if not selected.get("circumpolar"):
        try:
            rise = datetime.fromisoformat(selected["rise_utc"])
            end = datetime.fromisoformat(selected["set_utc"])
            if rise.tzinfo is None or end.tzinfo is None or duration > (end - rise).total_seconds():
                raise ValueError()
        except (ValueError, TypeError, KeyError):
            raise OperatorError("Duration does not fit the selected pass.") from None
    paths = {name: str(Path(value).absolute()) for name, value in (
        ("deployment_config", deployment_config), ("runtime_bindings", runtime_bindings),
        ("station_config", station_config), ("tle_file", tle_file))}
    try:
        base = load_runtime_configuration(paths["deployment_config"], paths["runtime_bindings"],
            paths["station_config"], paths["tle_file"], sat_id=plan["norad_id"],
            duration=float(duration), elevation=plan["elevation_mask_deg"])
        if base.configuration.to_dict() != settings["operator"]["selection"]:
            raise OperatorError("Runtime configuration differs from the saved selection.", "configuration_mismatch", 3)
        if base.tle_sha256 != plan["tle_sha256"]:
            raise OperatorError("Local TLE differs from the confirmed plan.", "tle_changed", 3)
        document = dict(schema="satgs-operator-run-request.v1", station_revision=revision,
            station_id=settings["satgs_operator_workspace"]["id"],
            configuration_revision=settings["operator"]["generation"], plan_id=plan_id,
            opportunity=opportunity, pass_window=selected, duration_seconds=float(duration),
            planning_start_utc=plan["start_utc"], planning_span_days=plan["span_days"],
            configuration_sha256=base.configuration_sha256, binding_sha256=base.binding_sha256,
            owner_settings_sha256=base.station_sha256, tle_sha256=base.tle_sha256,
            no_go_sha256=base.no_go_sha256, ptu_manager_id=base.ptu.manager_id,
            pixhawk_manager_id=base.pixhawk.manager_id, mode=mode,
            location=plan["location"], altitude_reference=plan["altitude_reference"],
            coordinate_units="degrees-metres", inputs=paths)
        identity = _digest(_bytes(document))
        context = snapshot_runtime_context(base, station_settings=settings,
            station_revision=revision, request_id=identity, station_document=workspace._read()[0])
    except (RuntimeConfigurationError, KeyError) as error:
        raise OperatorError("Runtime inputs failed admission before acquisition.", "runtime_input", 3) from None
    return RunRequest(identity, revision, plan_id, opportunity, mode,
                      _bytes({**document, "request_id": identity}), context)


def preview_run(workspace, **arguments):
    request = prepare_run(workspace, **arguments)
    path = workspace.root / f"run-request-{request.identity}.json"
    if path.exists():
        if read_regular_bytes(str(path)) != request._document:
            raise OperatorError("Run preview names different inputs.", "conflict", 3)
    else:
        _write_new(path, request._document)
    return public_request(request)


def public_request(request):
    return {key: value for key, value in request.to_dict().items() if key != "inputs"}


def _load_request(workspace, request_id):
    _identity(request_id, "Run")
    saved = workspace._artifact(f"run-request-{request_id}.json")
    if saved.get("request_id") != request_id or saved.get("schema") != "satgs-operator-run-request.v1":
        raise OperatorError("Run preview is invalid.", "artifact", 4)
    try:
        request = prepare_run(workspace, plan_id=saved["plan_id"], duration=saved["duration_seconds"],
            opportunity=saved["opportunity"], mode=saved["mode"], **saved["inputs"])
    except (KeyError, TypeError):
        raise OperatorError("Run preview is incomplete.", "artifact", 4) from None
    if request.to_dict() != saved:
        raise OperatorError("Run inputs changed; review a new request.", "stale_request", 3)
    return request


def run_status(workspace, request_id):
    _identity(request_id, "Run")
    for suffix in ("result", "progress", "started"):
        name = f"run-{request_id}-{suffix}.json"
        if (workspace.root / name).exists():
            return {**workspace._artifact(name), "observation_is_recorded": True,
                    "liveness": "not_established_from_record"}
    raise OperatorError("Run has not started.", "not_started", 3)


def _save_progress(workspace, request_id, record):
    directory = open_workspace(workspace.root)
    name = f"run-{request_id}-progress.json"
    temporary = f".run-{request_id}-{uuid4().hex}.pending"
    try:
        try:
            current = os.stat(name, dir_fd=directory, follow_symlinks=False)
        except FileNotFoundError:
            current = None
        if current is not None and (not stat.S_ISREG(current.st_mode) or current.st_nlink != 1
                or current.st_uid != os.geteuid() or stat.S_IMODE(current.st_mode) != 0o600):
            raise OperatorError("Progress record is not a private ordinary file.", "io", 4)
        _write_new(workspace.root / temporary, _bytes(record))
        os.replace(temporary, name, src_dir_fd=directory, dst_dir_fd=directory)
        os.fsync(directory)
    except OSError:
        raise OperatorError("Run progress could not be saved.", "io", 4) from None
    finally:
        os.close(directory)


def cancel_run(workspace, request_id):
    state = run_status(workspace, request_id)
    if state.get("finished"):
        return state
    path = workspace.root / f"run-{request_id}-cancel.json"
    record = {"request_id": request_id, "local_cancellation_requested": True,
              "remote_cancellation_established": False, "physical_stop_established": False}
    if not path.exists():
        try:
            _write_new(path, _bytes(record))
        except OperatorError:
            if not path.exists():
                raise
    return record


def execute_run(workspace, request_id, *, confirm=False, cancel=None, progress=None):
    if confirm is not True:
        raise OperatorError("Run requires explicit confirmation after preview.")
    request = _load_request(workspace, request_id)
    result_path = workspace.root / f"run-{request_id}-result.json"
    if result_path.exists():
        return workspace._artifact(result_path.name)
    stop = threading.Event() if cancel is None else cancel
    if type(stop) is not threading.Event:
        raise OperatorError("Run cancellation must use a lifecycle Event.")
    started = {**public_request(request), "finished": False, "state": "admitting",
               "physical_state": "unobserved", "attempt_id": uuid4().hex,
               "observed_at": datetime.now(timezone.utc).isoformat(), "clock_synchronization": "unconfirmed"}
    _write_new(workspace.root / f"run-{request_id}-started.json", _bytes(started))
    # The runner, not the interface, acquires and retains the station lease.
    runner = None
    primary = None
    acquisition_outcome = None
    acquisition_cleanup = ()
    runtime_failure_type = ()
    bridge_done = threading.Event()
    cancel_path = workspace.root / f"run-{request_id}-cancel.json"
    def observe_cancel():
        while not bridge_done.is_set():
            try:
                if cancel_path.exists():
                    record = workspace._artifact(cancel_path.name)
                    if record.get("request_id") != request_id or record.get("local_cancellation_requested") is not True:
                        raise ValueError()
                    stop.set()
                    return
            except Exception:
                stop.set()
                return
            bridge_done.wait(0.05)
    bridge = threading.Thread(target=observe_cancel, name="operator-local-cancellation", daemon=False)
    code = 3
    result = {**public_request(request), "finished": True, "physical_state": "unobserved"}
    save_errors = []
    def publish(record):
        document = {"request_id": request_id, "mode": request.mode, "finished": False, **record,
                    "observed_at": datetime.now(timezone.utc).isoformat(), "clock_synchronization": "unconfirmed"}
        try:
            _save_progress(workspace, request_id, document)
        except OperatorError:
            save_errors.append("progress")
            stop.set()
            raise
        if progress is not None:
            progress(dict(document))
    try:
        if cancel_path.exists():
            stop.set()
        bridge.start()
        try:
            from satgs.pass_runner import PassRunner, RuntimeFailure
            runtime_failure_type = RuntimeFailure
            publish(dict(started))
            window = {**request.to_dict()["pass_window"],
                      "planning_start_utc": request.to_dict()["planning_start_utc"],
                      "planning_span_days": request.to_dict()["planning_span_days"],
                      "opportunity_index": request.opportunity}
            runner = PassRunner(workspace.station_path, None, request.context.tle.norad_id,
                runtime_context=request.context, cancel_event=stop,
                manage_signals=threading.current_thread() is threading.main_thread(), progress=publish,
                selected_pass=window)
            code = runner.main()
            primary = runner.primary_failure
        except runtime_failure_type as error:
            code, primary = error.code, error.category
            acquisition_outcome = error.manager_outcome
            acquisition_cleanup = getattr(error, "cleanup_errors", ())
        except OperatorError:
            code, primary = 6, "result-save"
        except ImportError:
            code, primary = 3, "owner-prerequisite"
        except KeyboardInterrupt:
            stop.set()
            code, primary = 130, "cancelled"
        except RuntimeConfigurationError:
            code, primary = (130, "cancelled") if stop.is_set() else (3, "runtime_input")
        except Exception:
            code, primary = (130, "cancelled") if stop.is_set() else (5, "execution-failure")
        result.update(exit_code=code, primary=primary, state="cancelled" if code == 130 else "finished",
            observed_at=datetime.now(timezone.utc).isoformat(), clock_synchronization="unconfirmed",
            local_cancellation_requested=stop.is_set(), remote_cancellation_established=False,
            physical_stop_established=False, physical_state=getattr(runner, "physical_state", "unobserved"),
            cleanup_categories=list(getattr(runner, "cleanup_errors", acquisition_cleanup)))
        result["save_errors"] = list(save_errors)
        if save_errors:
            result.update(exit_code=6, primary="result-save")
        outcome = getattr(runner, "manager_outcome", acquisition_outcome)
        result["manager_outcome"] = None if outcome is None else {
            key: getattr(outcome, key) for key in ("state", "category", "operation", "sequence",
                "submitted", "total_submitted", "possible_submission", "submission")}
        result["software_completed"] = bool(code in (0, 8) and outcome is not None and outcome.state == "complete")
    finally:
        bridge_done.set()
        if bridge.ident is not None:
            bridge.join()
        if runner is not None:
            runner._release_resources()
    try:
        _save_progress(workspace, request_id, {**result, "finished": True,
                       "result_recorded": False, "partial": True})
    except (OperatorError, ActivityError):
        save_errors.append("final-progress")
    try:
        result.update(result_recorded=True, partial=bool(save_errors), save_errors=list(save_errors))
        _write_new(result_path, _bytes(result))
    except OperatorError:
        result.update(result_recorded=False, partial=True)
    if progress is not None:
        progress(dict(result))
    return result
