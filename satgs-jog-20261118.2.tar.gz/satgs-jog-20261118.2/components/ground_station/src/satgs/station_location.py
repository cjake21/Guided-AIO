"""Manual station-location selection without changing admitted runs or owners."""

from dataclasses import dataclass, field
import hashlib
import json
import math
import re
from types import MappingProxyType
from typing import Any, Mapping


SOURCE_KEY = "ground_station_location_source"
BOUND_LOCATION_KEY = "station_location"


class LocationError(ValueError):
    pass


def _source(value):
    if type(value) is not str or value not in ("configured", "manual"):
        raise LocationError("Station location source is unsupported; live GPS is unavailable.")
    return value


def _number(value, description):
    try:
        valid = type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        valid = False
    if not valid:
        raise LocationError(f"{description} must be a finite nonboolean number.")
    return 0.0 if value == 0 else float(value)


@dataclass(frozen=True, slots=True)
class Location:
    source: str
    latitude_deg: float
    longitude_deg: float
    altitude_m: float
    identity: str = field(init=False)

    def __post_init__(self):
        _source(self.source)
        latitude = _number(self.latitude_deg, "Latitude")
        longitude = _number(self.longitude_deg, "Longitude")
        altitude = _number(self.altitude_m, "Altitude")
        if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
            raise LocationError("Station coordinates are outside geographic bounds.")
        for name, value in (("latitude_deg", latitude), ("longitude_deg", longitude),
                            ("altitude_m", altitude)):
            object.__setattr__(self, name, value)
        record = {"source": self.source, "latitude_deg": latitude,
                  "longitude_deg": longitude, "altitude_m": altitude}
        payload = json.dumps(record, sort_keys=True, separators=(",", ":"),
                             allow_nan=False).encode("ascii")
        object.__setattr__(self, "identity", hashlib.sha256(payload).hexdigest())

    def to_dict(self) -> dict[str, Any]:
        return {"source": self.source, "latitude_deg": self.latitude_deg,
                "longitude_deg": self.longitude_deg, "altitude_m": self.altitude_m,
                "identity": self.identity}


def location_from_settings(settings: Mapping[str, Any]) -> Location:
    if not isinstance(settings, Mapping):
        raise LocationError("Station settings must be a mapping.")
    return Location(settings.get(SOURCE_KEY, "configured"),
                    settings.get("ground_station_lat"),
                    settings.get("ground_station_lon"),
                    settings.get("ground_station_altm"))


def runtime_location_from_settings(settings: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(settings, Mapping):
        raise LocationError("Station settings must be a mapping.")
    record = settings.get(BOUND_LOCATION_KEY)
    fields = {"source", "station_id", "revision", "latitude_deg", "longitude_deg",
              "altitude_m", "altitude_reference", "coordinate_units"}
    if not isinstance(record, Mapping) or set(record) != fields:
        raise LocationError("Runtime location requires an explicit complete owner binding.")
    for name in ("station_id", "altitude_reference"):
        value = record[name]
        if (type(value) is not str or not value or len(value) > 128
                or any(not 32 <= ord(character) <= 126 for character in value)):
            raise LocationError("Runtime location identity or reference is invalid.")
    if (type(record["revision"]) is not int or not 0 < record["revision"] < 2 ** 63
            or record["coordinate_units"] != "degrees-metres"):
        raise LocationError("Runtime location revision or units are invalid.")
    location = Location(record["source"], record["latitude_deg"], record["longitude_deg"],
                        record["altitude_m"])
    if location != location_from_settings(settings):
        raise LocationError("Runtime location does not match the selected station coordinates.")
    marker = settings.get("satgs_operator_workspace")
    metadata = settings.get("operator")
    if marker is not None and (not isinstance(marker, Mapping) or marker.get("id") != record["station_id"]):
        raise LocationError("Runtime location does not match the selected station identity.")
    if metadata is not None and (not isinstance(metadata, Mapping)
            or type(metadata.get("generation")) is not int
            or metadata.get("generation") != record["revision"]
            or metadata.get("altitude_reference") != record["altitude_reference"]):
        raise LocationError("Runtime location does not match the selected station revision and reference.")
    return MappingProxyType(dict(record))


def require_runtime_location(settings: Mapping[str, Any], *, bound=False) -> None:
    if not isinstance(settings, Mapping):
        raise LocationError("Station settings must be a mapping.")
    source = _source(settings.get(SOURCE_KEY, "configured"))
    if source == "configured" and BOUND_LOCATION_KEY not in settings:
        return
    if source == "manual" and bound is not True:
        raise LocationError("Manual location is planning-only until downstream owner reinitialization is established.")
    location = runtime_location_from_settings(settings)
    if source == "manual" and location["altitude_reference"] != "mean_sea_level":
        raise LocationError("Manual runtime location requires a declared mean-sea-level altitude reference.")
    positioners = settings.get("positioners")
    if (type(positioners) not in (list, tuple) or len(positioners) != 1
            or not isinstance(positioners[0], Mapping)
            or not isinstance(positioners[0].get("pointing_context"), Mapping)
            or type(positioners[0]["pointing_context"].get("configuration_generation")) is not int
            or positioners[0]["pointing_context"].get("configuration_generation") != location["revision"]):
        raise LocationError("Runtime location revision does not match the selected owner policy.")


def _freeze(value):
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if type(value) in (list, tuple):
        return tuple(_freeze(item) for item in value)
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float and math.isfinite(value):
        return value
    raise LocationError("Station settings contain unsupported values.")


def _thaw(value):
    if isinstance(value, Mapping):
        return {key: _thaw(item) for key, item in value.items()}
    if type(value) is tuple:
        return [_thaw(item) for item in value]
    return value


@dataclass(frozen=True, slots=True)
class PreparedLocation:
    location: Location
    changed: bool
    _settings: Mapping[str, Any] = field(repr=False)

    def settings(self) -> dict[str, Any]:
        return _thaw(self._settings)


def prepare_manual_location(settings: Mapping[str, Any], *, latitude_deg,
                            longitude_deg, altitude_m, expected_revision,
                            current_revision, source="manual") -> PreparedLocation:
    if type(source) is not str or source != "manual":
        raise LocationError("Only explicit manual selection is supported; live GPS is unavailable.")
    for revision in (expected_revision, current_revision):
        if type(revision) is not str or re.fullmatch(r"[0-9a-f]{64}", revision) is None:
            raise LocationError("Station revision must be an exact SHA-256 identity.")
    if expected_revision != current_revision:
        raise LocationError("Station configuration changed; reload before selecting a location.")
    location = Location(source, latitude_deg, longitude_deg, altitude_m)
    if not isinstance(settings, Mapping):
        raise LocationError("Station settings must be a mapping.")
    _source(settings.get(SOURCE_KEY, "configured"))
    previous = None if all(settings.get(key) is None for key in (
        "ground_station_lat", "ground_station_lon", "ground_station_altm"
    )) else location_from_settings(settings)
    updated = _thaw(_freeze(settings))
    updated.update(ground_station_lat=location.latitude_deg,
                   ground_station_lon=location.longitude_deg,
                   ground_station_altm=location.altitude_m,
                   ground_station_location_source=location.source)
    return PreparedLocation(location, previous is None or location.identity != previous.identity,
                            _freeze(updated))
