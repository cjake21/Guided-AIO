import yaml
import pytz
import copy
import re
import os
import logging
import ephem
import subprocess
import numpy as np
import pandas as pd
import logging_tree
from ephem import Observer, degree as deg2rad
from pathlib import Path
from datetime import datetime, timedelta, timezone
from itertools import compress
from scipy.interpolate import CubicSpline
from dataclasses import dataclass, field
from typing import Union, List, Tuple

from satgs import jobs_msg_pb2
from satgs.constants import Topics, DEFAULTS, time_format_print, time_format_short, time_format_tzone


@dataclass
class AzElTrajectory:
    t_steps: np.ndarray
    t_ref: datetime
    az: np.ndarray
    el: np.ndarray  
    range_m: np.ndarray=None
    range_rate: np.ndarray=None
    def add_errors(self, t_ax, az_error, el_error, min_el=None):
        az_spline = CubicSpline(t_ax, az_error, extrapolate=False)
        el_spline = CubicSpline(t_ax, el_error, extrapolate=False)
        az_err = az_spline(self.t_steps)
        az_err[np.isnan(az_err)] = 0
        el_err = el_spline(self.t_steps)
        el_err[np.isnan(el_err)] = 0        
        return AzElTrajectory(self.t_steps, self.t_ref, 
                              self.az + az_err,
                              self.el + el_err)
        
        
@dataclass
class TLE:
    tle_str: str    
    name: str = None
    t_ref:datetime = None
    norad_id:int = None
    tle_epoch:datetime = None
    
    def __post_init__(self):
        if self.norad_id is None:
            tle_parts = self.tle_str.split(',')
            self.norad_id = int(tle_parts[1][2:7])           
        if self.tle_epoch is None:
            tle_parts = self.tle_str.split(',')
            epoch_year_day = tle_parts[1][18:23]
            epoch_frac = float(tle_parts[1][23:31])
            self.tle_epoch = (datetime.strptime(epoch_year_day, '%y%j') + timedelta(days=epoch_frac)).replace(tzinfo=timezone.utc)
        if self.t_ref is None:
            self.t_ref = self.tle_epoch
        if self.name is None:
            tle_parts = self.tle_str.split(',')
            self.name = tle_parts[0]            
            
         
    def to_str(self):
        return ",".join([self.tle_str, self.t_ref.strftime(time_format_tzone)])
    def to_dict(self):
        return {self.norad_id: {
                "name": self.name,
                "tle":self.tle_str, 
                "date":self.t_ref.strftime(time_format_tzone),
                "epoch":self.tle_epoch.strftime(time_format_tzone)}
                }

    def get_trajectory(self, observer:Observer, dt:float = 1, t_steps:np.array=None)->AzElTrajectory:
        pass
        
def tle_from_dict(tle_dict:dict)-> TLE:
    if tle_dict['date'] is not None:
        t_ref = datetime.strptime(tle_dict['date'],time_format_tzone).replace(tzinfo=timezone.utc)
    tle_str = tle_dict['tle']
    tle_elem = tle_str.split(',')
    norad_id = int(tle_elem[1][2:7])
    return TLE(name=tle_dict['name'], tle_str=tle_dict['tle'], 
                t_ref=t_ref, norad_id = norad_id)
    
def tle_from_str(tle_str:str)->TLE:
    """Generates TLE object from tle str with extra comma separated datetime 
    added on. Datetime should be formatted as "%Y-%m-%d %H:%M:%S %Z"

    Args:
        tle_str (str): _description_

    Returns:
        tle: _description_
    """
    if tle_str=='':
        return None
    else:
        tle_parts = tle_str.split(',')
        return TLE(name = tle_parts[0], 
                   tle_str=",".join(tle_parts[0:3]), 
                   t_ref = datetime.strptime(tle_parts[-1], time_format_tzone).replace(tzinfo=timezone.utc),
                   norad_id=int(tle_parts[1][2:7]))
        
        
        
@dataclass
class PassInfo:
    sat_id: int
    sat_rise_time: Union[datetime,int] = 0
    sat_set_time: Union[datetime,int] = 0
    rising_az: float = 0
    setting_az: float = 0
    max_elv:float = 0
    horizon: float = DEFAULTS.elev_mask
    is_circumpolar:bool = False
    is_neverup:bool = False
    sat_tle: Union[TLE,None]=None
    def get_str(self, use_local_tzone:bool=False)->str:           
        if use_local_tzone:
            tzone = DEFAULTS.local_tzone
        else:
            tzone = pytz.timezone("UTC")            
            
        if self.is_circumpolar :
            return "Geostationary: Elv {:.0f} Az {:.0f} ".format(
                    self.max_elv,
                    self.rising_az,
                )                        
        else:
            return "Rise, {}, -> ,{}, (dur:, {:05.2f}, min) Rise {:03.0f} az ({:02.0f} el) -> Max Elv, {:02.0f}, -> Set {:03.0f} az".format(
                    self.sat_rise_time.astimezone(tzone).strftime(time_format_tzone), 
                    self.sat_set_time.astimezone(tzone).strftime(time_format_short), 
                    (self.sat_set_time - self.sat_rise_time).total_seconds()/60, 
                    self.rising_az,
                    self.horizon,
                    self.max_elv,
                    self.setting_az,
                ) 
    def get_trajectory(self, observer:Observer, dt:float = 1, t_steps:np.array=None)->AzElTrajectory:
        temp_observer = copy.copy(observer)
        tle_parts = self.sat_tle.tle_str.split(',')
        sat_ephem = ephem.readtle(tle_parts[0], tle_parts[1], tle_parts[2])        
        if self.is_circumpolar:
            sat_ephem.compute(temp_observer)
            return AzElTrajectory(np.zeros(1), datetime.now(timezone.utc), 
                                  np.array((self.rising_az,)), 
                                   np.array((self.max_elv,)),
                                   sat_ephem.range,
                                   sat_ephem.range_velocity) 
        elif self.is_neverup:
            return None
        else:
            temp_observer = copy.copy(observer)
            tle_parts = self.sat_tle.tle_str.split(',')
            sat_ephem = ephem.readtle(tle_parts[0], tle_parts[1], tle_parts[2])
            duration = round((self.sat_set_time - self.sat_rise_time).total_seconds())
            if t_steps is None:
                t_steps  = np.arange(0, duration, dt)
            az_deg = np.zeros(t_steps.shape)
            el_deg = np.zeros(t_steps.shape)
            range_m = np.zeros(t_steps.shape)
            range_rate = np.zeros(t_steps.shape)            
            t_ref = self.sat_rise_time
            for idx, t_step in enumerate(t_steps):
                temp_observer.date = self.sat_rise_time+timedelta(seconds=float(t_step))
                sat_ephem.compute(temp_observer)
                az_deg[idx] = sat_ephem.az*180/np.pi
                el_deg[idx] = sat_ephem.alt*180/np.pi
                range_m[idx] = sat_ephem.range 
                range_rate[idx] = sat_ephem.range_velocity  
                
            return  AzElTrajectory(t_steps, t_ref, az_deg, el_deg, range_m, range_rate)    

@dataclass
class JobRequest:
    
    sat_id: int
    sat_name: str = ''
    pass_number: int = -1
    job_start: Union[datetime,int] = 0
   
    dl_id: str = ''
    dl_fc_mhz:float = 0
    dl_bw_mhz:float = 0
    
    ul_id: str = ''
    ul_fc_mhz:float=0
    
    duration:float=0    
    priority:bool=False
    elv_mask:float=DEFAULTS.elev_mask
    
    pass_info:PassInfo=None
    sat_tle: Union[TLE,None]=None  
    
    apply_error_profile:bool=False
    work_modem_tx_source:bool=True
    pass_id: int = -1

    def to_pb(self):
        if self.job_start == 0:
            job_start = ''
        else:
            job_start=self.job_start.strftime(time_format_print)
        if self.sat_tle is None:
            sat_tle_str = ''
        else:
            sat_tle_str = self.sat_tle.to_str()            
        return jobs_msg_pb2.JobRequest(sat_id=self.sat_id, sat_name=self.sat_name,
                                pass_num=self.pass_number, job_start=job_start,
                                elv_mask=self.elv_mask, duration=self.duration, 
                                dl_id = self.dl_id, dl_fc_mhz=self.dl_fc_mhz, dl_bw_mhz=self.dl_bw_mhz,
                                ul_id = self.ul_id, ul_fc_mhz=self.ul_fc_mhz,
                                priority=self.priority,
                                tle_str = sat_tle_str,
                                apply_error_profile = self.apply_error_profile,
                                work_modem_tx_source = self.work_modem_tx_source,
                                pass_id = self.pass_id
                                )

    def get_str(self, use_local_tzone:bool=False)->str:
        if use_local_tzone:
            tzone = DEFAULTS.local_tzone
        else:
            tzone = pytz.timezone("UTC")           
        
        if self.pass_number>=0:
            start_str = "Pass Number {}".format(self.pass_number)
        else:
            start_str = "Job Start: {}".format(self.job_start.astimezone(tzone).strftime(time_format_tzone))            
        
        if self.pass_id != -1:
            pass_id = "Pass ID: {}".format(str(self.pass_id))
        else:
            pass_id = "No Pass ID"

        if self.dl_id!='':
            dn_link_str = "D.L. Id {}".format(self.dl_id)
        else:
            dn_link_str = "D.L. Fc= {:.3f} MHz, BW= {:.1f} MHz".format(self.dl_fc_mhz, self.dl_bw_mhz)
        
        if self.work_modem_tx_source:
            tx_src_str = f'TX Source: Work Modem'
        else:
            tx_src_str = f'TX Source: SIP'
            
        if self.ul_id=='' and self.ul_fc_mhz==0:
            up_link_str = "No Uplink"            
        elif self.ul_id!='':
            up_link_str = "UpLink Id {}, {}".format(self.ul_id, tx_src_str)
        else:
            up_link_str = "UpLink Fc= {:.3f} MHz. {}".format(self.ul_fc_mhz, tx_src_str)
            
        if self.pass_info is None:
            pass_info_str = ''
        else:
            pass_info_str = self.pass_info.get_str()

        return "  Job Request for {}, ID: {} {} {} \n  Elv Mask {} Dur. {:05.2f} min, Priority={}, Errors Applied = {}\n  {}\n  {}\n  Pass Info: {}".format(
            self.sat_name, self.sat_id, pass_id, 
            start_str, 
            self.elv_mask, self.duration/60, self.priority, self.apply_error_profile,
            dn_link_str, up_link_str, pass_info_str)


def pb_to_job_request(msg:str)->JobRequest:
    cmd_msg = jobs_msg_pb2.AddJobCmdMsg()
    cmd_msg.ParseFromString(msg) 
    
    if cmd_msg.job_request.job_start=='':
        job_start = -1
    else:
        job_start = datetime.strptime(cmd_msg.job_request.job_start, time_format_print).replace(tzinfo=timezone.utc)

    sat_tle = tle_from_str(cmd_msg.job_request.tle_str)

    return JobRequest(cmd_msg.job_request.sat_id, cmd_msg.job_request.sat_name,                      
            cmd_msg.job_request.pass_num, job_start,
            cmd_msg.job_request.dl_id, cmd_msg.job_request.dl_fc_mhz, cmd_msg.job_request.dl_bw_mhz, 
            cmd_msg.job_request.ul_id, cmd_msg.job_request.ul_fc_mhz,            
            cmd_msg.job_request.duration,cmd_msg.job_request.priority, cmd_msg.job_request.elv_mask,
            sat_tle=sat_tle, apply_error_profile=cmd_msg.job_request.apply_error_profile,
            work_modem_tx_source=cmd_msg.job_request.work_modem_tx_source,
            pass_id=cmd_msg.job_request.pass_id)        
    
@dataclass
class Job:
    sat_id: int
    job_id: int = field(compare = False)
    
    pass_info: PassInfo
    job_start_time: Union[datetime,int] = 0
    duration:int = 0
    
    dl_id: str = ''
    dl_fc_mhz:float = 0
    dl_bw_mhz:float = 0    
    
    ul_id: str = ''
    ul_fc_mhz:float=0    
    
    priority:bool=False
    sat_tle: Union[TLE,None]=None
    apply_error_profile:bool=None
    work_modem_tx_source:bool = True
    pass_id:int = -1

    def to_pb(self):
        if self.sat_tle is None:
            sat_tle_str = ''
        else:
            sat_tle_str = self.sat_tle.to_str()
            
        if self.pass_info.is_circumpolar:
            return jobs_msg_pb2.JobDetails(
                sat_id=self.sat_id, job_id=self.job_id, duration=self.duration,
                sat_rise_time='', 
                sat_set_time='', 
                job_start_time=self.job_start_time.strftime(time_format_print),
                dl_id = self.dl_id, dl_fc_mhz=self.dl_fc_mhz, dl_bw_mhz=self.dl_bw_mhz, 
                ul_id = self.ul_id, ul_fc_mhz=self.ul_fc_mhz,                
                priority=self.priority,
                tle_str = sat_tle_str, apply_error_profile=self.apply_error_profile,
                work_modem_tx_source = self.work_modem_tx_source,
                pass_id=self.pass_id)
        else:
            return jobs_msg_pb2.JobDetails(
                sat_id=self.sat_id, job_id=self.job_id, duration=self.duration,
                sat_rise_time=self.pass_info.sat_rise_time.strftime(time_format_print), 
                sat_set_time=self.pass_info.sat_set_time.strftime(time_format_print), 
                job_start_time=self.job_start_time.strftime(time_format_print),
                dl_id = self.dl_id, dl_fc_mhz=self.dl_fc_mhz, dl_bw_mhz=self.dl_bw_mhz, 
                ul_id = self.ul_id, ul_fc_mhz=self.ul_fc_mhz,                       
                priority=self.priority,
                tle_str = sat_tle_str, apply_error_profile=self.apply_error_profile,
                work_modem_tx_source = self.work_modem_tx_source,
                pass_id = self.pass_id)
                
    def get_str(self, use_local_tzone:bool=False)->str:
        if use_local_tzone:
            tzone = DEFAULTS.local_tzone
        else:
            tzone = pytz.timezone("UTC")   
                    
        if self.dl_id!='':
            dn_link_str = '\n    D.L ID: {}'.format(self.dl_id)
        else:
            dn_link_str = '\n    D.L Fc {:.3f} MHz, BW {:.1f} MHz'.format(self.dl_fc_mhz, self.dl_bw_mhz)

        if self.work_modem_tx_source:
            tx_src_str = f'TX Source: Work Modem'
        else:
            tx_src_str = f'TX Source: SIP'
            
        if self.ul_id=='' and self.ul_fc_mhz==0:
            up_link_str = '\n    No Uplink'
        elif self.ul_id!='':
            up_link_str = '\n    Uplink ID: {}, {}'.format(self.ul_id, tx_src_str)
        else:
            up_link_str = '\n    Uplink Fc {:.3f} MHz, {}'.format(self.ul_fc_mhz, tx_src_str)
        if self.apply_error_profile:
            err_str = '\n    Error Profile will be applied'
        else:
            err_str = ''
        
        if self.pass_id != -1:
            pass_id = 'Pass ID: {}'.format(str(self.pass_id))
        else:
            pass_id = 'No Pass ID'

        if self.pass_info is None:
            return "Job ID {:03}, Sat ID {}, {}, Dur. {:05.2f} min Job Start: {} -> {}, {}, {}, {}".format(
                    self.job_id, self.sat_id, pass_id, self.duration/60, 
                    self.job_start_time.astimezone(tzone).strftime(time_format_tzone), 
                    (self.job_start_time+timedelta(seconds=self.duration)).astimezone(tzone).strftime(time_format_short),
                    dn_link_str, up_link_str, err_str
                )                        
        else:
            return "Job ID {:03}, Sat ID {}, {}, Dur {:05.2f} min. Job Start [L]: {} -> {}, Max Elv {:02.0f} Rise {:03.0f} -> Set {:03.0f} {}, {}, {}".format(
                    self.job_id, self.sat_id, pass_id, self.duration/60,
                    self.job_start_time.astimezone(tzone).strftime(time_format_tzone), 
                    (self.job_start_time+timedelta(seconds=self.duration)).astimezone(tzone).strftime(time_format_short),
                    self.pass_info.max_elv, self.pass_info.rising_az, self.pass_info.setting_az, dn_link_str, up_link_str, err_str
                )

class tleTimeoutException(Exception):
    pass
class TleFormatError(Exception):
    pass
class TleNotFound(Exception):
    pass

def to_julian_day(date_time:datetime):
    return pd.Timestamp(date_time).to_julian_date()

def fetch_tle(sat_id: int, epoch_start:datetime=None, epoch_end:datetime=None):
    import niquests as requests

    url = 'https://satchecker.cps.iau.org/tools/get-tle-data/'
    if epoch_start==None and epoch_end==None:
        url = 'https://satchecker.cps.iau.org/tools/get-nearest-tle/'
        params = {'id': f'{sat_id:d}',
                'id_type': 'catalog',
                'epoch': f'{to_julian_day(datetime.now(timezone.utc))}'
                }     
    elif epoch_start!=None and epoch_end!=None:
        start = to_julian_day(epoch_start)
        end = to_julian_day(epoch_end)
        params = {'id': f'{sat_id:d}',
                'id_type': 'catalog',
                'start_date_jd': '{}'.format(start),
                'end_date_jd': '{}'.format(end)
                }
    elif (epoch_start!=None and epoch_end==None):
        url = 'https://satchecker.cps.iau.org/tools/get-tle-data/'
        start = to_julian_day(epoch_start)        
        params = {'id': f'{sat_id:d}',
                'start_date_jd': '{}'.format(start),
                'id_type': 'catalog',
                } 
    elif (epoch_start==None and epoch_end!=None):
        url = 'https://satchecker.cps.iau.org/tools/get-tle-data/'
        end = to_julian_day(epoch_end)        
        params = {'id': f'{sat_id:d}',
                'end_date_jd': '{}'.format(end),
                'id_type': 'catalog',
                }                       
    try:       
        r = requests.get(url, params=params, timeout=5)    
    except Exception as e:
        print(e)
        raise tleTimeoutException
    return r
    
def scrape_url(sat_id: int)->list:
    """Fetch TLE from celestrak in format TLE

    Args:
        sat_id (int): 

    Raises:
        tleTimeoutException: 

    Returns:
        list: [Name, Line 1, Line 2]
    """
    import niquests as requests

    # Format of this should be "TLE" defined by Celestrak here:
    # https://www.celestrak.org/NORAD/documentation/gp-data-formats.php
    link = f"https://celestrak.org/NORAD/elements/gp.php?CATNR={sat_id}&FORMAT=TLE"
    logging.info("Fetching TLE for sat id {} from: \n{}".format(sat_id, link))

    # access NORAD website and scrape TLE
    try:
        re = requests.get(link, timeout=5)
    except:
        raise tleTimeoutException
        
    try:
        tle_list = re.text.split("\r\n")

        if tle_list[0] == "No GP data found":
            raise TleNotFound("Norad ID {}".format(sat_id))            
        else:
            # compensate for the last empty item in list after split command executes
            if tle_list[-1] == "":
                tle_list.pop()

            # remove trailing characters
            tle_list[0] = tle_list[0].rstrip()
    except:
        raise TleFormatError("Error parsing TLE response: request returned status code: {}".format(re.status_code))        

    return tle_list

def add_new_tle(sat_id:int, tle_db:dict):
    """Add new Satellite to TLE dB structure

    Args:
        sat_id (int): 
        tle_db (dict): 

    Returns:
        (tle_db, updated): Updated = True if new TLE fetched
    """
    logging.info("Adding Satellite ID {}".format(sat_id))
    if sat_id in tle_db:
        logging.error("Satellite already in dB")
        return tle_db, False
    else:
        try:
            tle_info = scrape_url(sat_id)
            tle_db[sat_id]={
                'name': tle_info[0],
                'tle': ','.join(tle_info),
                'date': datetime.now(timezone.utc).strftime(time_format_tzone), 
                'txids':None
            }
            logging.info("Got TLE for Sat ID {}, {}".format(sat_id, tle_info[0]))
            print(sat_id in tle_db)
            
            return tle_db, True
        except tleTimeoutException:
            logging.error("Cannot reach Celestrak, request for Norad ID {} timed out".format(sat_id))
            return None, False
        except TleFormatError as e:
            logging.error("Norad ID {} Bad HTML {}".format(sat_id, str(e)))
            return None, False
        except TleNotFound as e:
            logging.error("TLE Not Found: {}".format(str(e)))
        except Exception as e:
            logging.error(f"Some other error: {e}")
            return None, False
        
def del_tle(sat_id:int, tle_db:dict):
    """Delete Satellite from TLE dB structure

    Args:
        sat_id (int): 
        tle_db (dict): 

    Returns:
        (tle_db, updated): Updated = True if new TLE deleted
    """
    logging.info("Deleting Satellite ID {}".format(sat_id))
    if sat_id not in tle_db:
        logging.error("Satellite not in dB... exiting. ")
        return None, False
    else:
        try:
            tle_db.pop(sat_id, None)

            logging.info("Deleted TLE {}".format(sat_id))
            
            return tle_db, True
        except Exception as e:
            logging.ERROR(e)
            return None, False        
        
def update_tle_db(tle_db:dict, day_validity:float=DEFAULTS.tle_validity)->Tuple[dict, bool]:
    db_updated = False
    invalid_ids = [] # List of ones to delete later... if not found
    for norad_id in tle_db:
        if pd.isnull(tle_db[norad_id]['date']):
            try:
                tle_info = scrape_url(norad_id)
            except tleTimeoutException:
                logging.error("Cannot reach Celestrak, request for Norad ID {} timed out".format(norad_id))
                continue
            except TleFormatError as e:
                logging.error("Norad ID {} Bad HTML {}".format(norad_id, str(e)))            
                continue
            except TleNotFound as e:
                logging.error("TLE Not Found Keeping Old One: {}".format(str(e)))     
                        
            tle_db.update( 
                          TLE(tle_str=','.join(tle_info), name=tle_info[0], 
                              t_ref=datetime.now(timezone.utc).strftime(time_format_tzone)).to_dict() 
                          )              
            db_updated = True
        else:
            curr_tle = tle_from_dict(tle_db[norad_id])
            if (datetime.now(timezone.utc) - curr_tle.t_ref).total_seconds()/(3600*24) > day_validity:
                try:
                    tle_info = scrape_url(norad_id)
                except tleTimeoutException:
                    logging.error("Cannot reach Celestrak, request for Norad ID {} timed out".format(norad_id))
                    continue
                except TleFormatError as e:
                    logging.error("Norad ID {} Bad HTML {}".format(norad_id, str(e)))
                    continue                                
                tle_db.update( 
                            TLE(tle_str=','.join(tle_info), name=tle_info[0], 
                                t_ref=datetime.now(timezone.utc)).to_dict() 
                            )              
                db_updated = True            
            else:
                pass                
    return tle_db, db_updated           
    
def find_passes(sat_id: int, tle_dict: dict, observer:Observer, 
                elv_mask:float=DEFAULTS.elev_mask, 
                time_window_hrs:float = DEFAULTS.pass_finder_span*24)->List[PassInfo]:
        """ Find all upcoming passes for a given satellite
        """
        
        pass_list          = []
        if sat_id not in tle_dict.keys():
            logging.error("Error sat id not found in TLE dB")
            return []
        tle_str = tle_dict[sat_id]['tle']
        tle_list = tle_str.split(',')
        sat_orbital_params = ephem.readtle(tle_list[0], tle_list[1], tle_list[2])
        sat_tle = TLE(name = tle_dict[sat_id]['name'],
                      tle_str= tle_dict[sat_id]['tle'], 
                      t_ref= datetime.strptime(tle_dict[sat_id]["date"],time_format_tzone).replace(tzinfo=timezone.utc) )        
        temp_observer = copy.copy(observer)
        
        # loop over and find each next pass until we've exceeded the window we're looking at
        while ((temp_observer.date - observer.date)*24*3600)/3600 < time_window_hrs:
            # Some unexplained buggy behavior with next pass. Sometimes it raises an error, other time returns none. 
            sat_orbital_params.compute(temp_observer)
            
            try:
                # IMPORTANT: TIMES FROM THIS ARE UTC
                pass_info = temp_observer.next_pass(sat_orbital_params)
            except ValueError as e: 
                sat_orbital_params.compute(temp_observer)
                azimuth = (sat_orbital_params.az) * 180/np.pi
                elevation = (sat_orbital_params.alt) * 180/np.pi       
                pass_list.append(
                    PassInfo(sat_id, 0, 0, azimuth, azimuth, elevation, elv_mask, is_circumpolar=True, sat_tle=sat_tle)
                    )
                break

            if pass_info[3] is not None:
                if ((pass_info[3]* 180/np.pi) > elv_mask) & \
                   (pass_info[0] < ephem.Date(ephem.Date(observer.date) + ephem.Date(time_window_hrs/24))):
                    
                    pass_list.append(
                        PassInfo(sat_id, 
                                 sat_rise_time=pass_info[0].datetime().replace(tzinfo=timezone.utc), 
                                 sat_set_time=pass_info[4].datetime().replace(tzinfo=timezone.utc), 
                                 rising_az=pass_info[1] * 180/np.pi, 
                                 setting_az=pass_info[5] * 180/np.pi, 
                                 max_elv=pass_info[3] * 180/np.pi,  
                                 horizon=elv_mask,
                                 sat_tle=sat_tle)
                        )
            # Pass info syntax
            # (0) Rise time, (1) Rise azimuth, (2) Maximum altitude time, (3) Maximum altitude, (4) Set time, (5) Set azimuth
            if pass_info[3] is None: # Not sure what case this catches?
                temp_observer.date = ephem.Date(temp_observer.date + ((time_window_hrs+1)/24))# Update observer with pass set time and find next pass
            else:
                temp_observer.date = pass_info[-2] # Update observer with pass set time and find next pass       
                
        return pass_list    
    
def get_sat_pass(sat_id:int, pass_number:int, tle_dict:dict, observer:Observer)->PassInfo:
    pass_list = find_passes(sat_id, tle_dict, observer)
    return pass_list[pass_number]       

def find_closest_pass(sat_id:int, ground_station:Observer, tle_dict:dict, 
                      el_mask:float=DEFAULTS.elev_mask,
                      utc_ref:datetime=None, hrs_past:float = 12, hrs_future:float=6)->PassInfo:
        if utc_ref is None:
            utc_now = datetime.now(timezone.utc)
        else:
            utc_now=utc_ref
            
        temp_observer = copy.copy(ground_station)
        window_utc_start = utc_now - timedelta(hours=hrs_past)
        window_utc_end = utc_now + timedelta(hours=hrs_future)
        temp_observer.date = utc_now - timedelta(hours=hrs_past)
        
        upcoming_passes = find_passes(sat_id, tle_dict, temp_observer, 
                                      el_mask, time_window_hrs=(hrs_past+hrs_future+1))
        if len(upcoming_passes)==0:
            return None
        # Check if circumpolar:
        if upcoming_passes[0].is_circumpolar:
            pass_info = upcoming_passes[0]
        # Check that current start time roughly lines up with satellite pass
        else:
            # Note: Odd bug observed 8-21 with MSEL TLE where some passes were being returned as GEOs
            # No idea why this is happening, but adding a temp filter here to remove geo passes. But this
            # should never happen anyways....
            is_geo = [sat_pass.is_circumpolar for sat_pass in upcoming_passes]
            if any(is_geo):
                logging.error("Weird bug where non GEO satellite returning GEO Pass object. Could be bug with PyEphem. Removing GEO pass and continuing")
                is_not_geo = [not x for x in is_geo]
                upcoming_passes = list(compress(upcoming_passes, is_not_geo))
            # Ref Time is during a pass.
            matching_pass = [sat_pass 
                             for sat_pass in upcoming_passes 
                             if ((utc_now>=sat_pass.sat_rise_time) and (utc_now<sat_pass.sat_set_time)) ]
            if len(matching_pass)>0:
                pass_info = matching_pass[0]              
            #Find the next closest pass that may before or after the ref time
            else:
                start_deltas = [(sat_pass.sat_rise_time-utc_now).total_seconds() 
                                for sat_pass in upcoming_passes 
                                if (sat_pass.sat_rise_time-utc_now).total_seconds()>0]
                next_passes = [sat_pass for sat_pass in upcoming_passes 
                               if (sat_pass.sat_rise_time-utc_now).total_seconds()>0]
                next_pass_delta = min(start_deltas) # Seconds
                pass_info = next_passes[start_deltas.index(next_pass_delta)]                
        return pass_info    

def queue_pb_to_queue(queue_status_msg)->List[Job]:
    new_queue = []
    for job_pb in queue_status_msg.jobs:
        new_queue.append(
            Job(job_pb.sat_id, job_id=job_pb.job_id, pass_info=None,
                job_start_time=datetime.strptime(job_pb.job_start_time, time_format_print).replace(tzinfo=timezone.utc),
                duration=job_pb.duration,
                dl_id=job_pb.dl_id, dl_fc_mhz=job_pb.dl_fc_mhz, dl_bw_mhz=job_pb.dl_bw_mhz,
                ul_id=job_pb.ul_id, ul_fc_mhz=job_pb.ul_fc_mhz, 
                priority=job_pb.priority,
                sat_tle=tle_from_str(job_pb.tle_str),
                apply_error_profile=job_pb.apply_error_profile,
                work_modem_tx_source=job_pb.work_modem_tx_source,
                pass_id=job_pb.pass_id
                ))    
    return new_queue


def determine_file_prefix(pass_id: int, 
                          file_prefix_source: str) -> str:
    """
    Determines how to prefix the pass result log filename and result dirname
    Depends on user configuration on "file_prefix_source" in GS config file (default path: ~/ground_station/config/config.yaml)

    Returns:
    
        prefix (str) :  The string to be prepended on each pass result log filename 

    """
    if not isinstance(file_prefix_source,  str):  # User supplied unusable value
        logging.error(f"Received unexpected type for config 'file_prefix_source': {type(file_prefix_source)}, expected: str ... Using default file_prefix")
        return DEFAULTS.file_prefix
    elif file_prefix_source == "job":
        if pass_id == -1:                         # Config set to "job" but user didnt specify pass-id
            logging.debug(f"User didnt specify pass_id: {pass_id=} ... Using default")
            return DEFAULTS.file_prefix
        else:
            return str(pass_id)
    elif file_prefix_source == "default":
        return DEFAULTS.file_prefix
    else:
        logging.warning(f"Received unexpected input for config: {file_prefix_source=} ... Using default file_prefix")
        return DEFAULTS.file_prefix


def determine_filename(file, satid:int, sat_file:Path, 
                       nodate:bool=False, noid:bool=False,
                       date:datetime=None)->tuple:
    '''
    Appends the current date/time the recording was made to the filename
    '''
    
    tle_df = pd.read_csv(sat_file)
    tle_db = tle_df.set_index('norad_id').to_dict("index")        
    sat_name = tle_db[satid]['name']
    clean_name = re.sub(r'\W+', '', sat_name.replace(' ', '_'))
    # Determine filename:
    if date is None:
        # date = datetime.today()
        date = datetime.now(timezone.utc)
    filePrefix = file
    if nodate:
        if noid:
            file = f"{filePrefix}"
        else:
            file = f"{filePrefix}_{satid}"
    else:
        file = "{}_{}_{}".format(filePrefix, satid, date.strftime('%m_%d_%y_%H_%M_%S'))
        # file = f"{filePrefix}_{satid}_{date.year}-{date.month}-{date.day}_{date.hour}{date.minute}"        
        # file = f"{filePrefix}_{satid}_{date.year}-{date.month}-{date.day}_{date.hour}{date.minute}"
    directory = '{}/{}_{}'.format(date.strftime('%m-%d-%y'),satid, clean_name)
    # logging.warning("Output filename: {}, Output Directory {}".format(file,directory))
    return file, directory

def check_meteor_services():
    
    # Check if meteor is running
    e320_status = os.system('systemctl is-active meteor-e320-standalone.service')
    if e320_status != 0:
        logging.warning('meteor-e320-standalone.service is not running, this may result in a bad recording')
    else:
        logging.info('meteor-e320-standalone.service is running and active')

    native_status = os.system('systemctl is-active meteor-native.service')
    if native_status != 0:
        logging.warning('meteor-native.service is not running, this may result in a bad recording')
    else:
        logging.info('meteor-native.service is running and active')

    web_status = os.system('systemctl is-active meteor-web.service')
    if web_status != 0:
        logging.warning('meteor-web.service is not running')
    else:
        logging.info('meteor-web.service is running and active')  
        
def make_scurve(angle_delta:float, rate_dps:float, update_rate:float):
    t_ax = np.arange(0, 4*(angle_delta/rate_dps)+update_rate, update_rate)
    ang_err=np.zeros(t_ax.shape)
    for a in np.arange(4):
        idx = (t_ax >= (a)*(angle_delta/rate_dps)) & (t_ax <= (a+1)*(angle_delta/rate_dps))
        if a==0:
            ang_err[idx] = rate_dps*t_ax[idx]
        elif a==1 or a==2:
            ang_err[idx] = -rate_dps*t_ax[idx] + angle_delta*2        
        elif a==3:
            ang_err[idx] = rate_dps*t_ax[idx] - angle_delta*4
    ang_err = np.flip(ang_err) 
    return t_ax,ang_err

def make_az_el_scurves(az_angle_delta:float, el_angle_delta:float, 
                       rate_dps:float, update_rate:float, pad_time:float,
                       rotation_rate_dps:float=0,
                       total_duration:float=None, file_out:Union[Path,str]=None ):
    """_summary_

    Args:
        az_angle_delta (_type_): _description_
        el_angle_delta (_type_): _description_
        rate_dps (_type_): _description_
        update_rate (_type_): _description_
        pad_time (_type_): _description_

    Returns:
        _type_: _description_
    """
    
    t_ax_az, az_scurve = make_scurve(az_angle_delta,rate_dps, update_rate )
    t_ax_el, el_scurve = make_scurve(el_angle_delta,rate_dps, update_rate)
    az_ramp_time = (4*(az_angle_delta/rate_dps))
    el_ramp_time = (4*(el_angle_delta/rate_dps))
    
    segment_duration = az_ramp_time + el_ramp_time + pad_time
    if total_duration is None:
        total_duration = segment_duration
    t_ax_segment =np.arange(0, segment_duration+update_rate,update_rate)
    az_err_segment = np.zeros(t_ax_segment.shape)
    el_err_segment = np.zeros(t_ax_segment.shape)
    az_err_segment[(t_ax_segment>=pad_time) & (t_ax_segment<=(pad_time+az_ramp_time))] = az_scurve
    el_err_segment[(t_ax_segment>=(pad_time+az_ramp_time)) & (t_ax_segment<=(pad_time+az_ramp_time+el_ramp_time))] = el_scurve
    
    num_reps = total_duration/segment_duration
    t_ax_full = np.arange(0, np.ceil(num_reps)*(segment_duration+update_rate),update_rate)
 
    az_err_pad = np.tile(az_err_segment,int(np.ceil(num_reps)))
    el_err_pad = np.tile(el_err_segment,int(np.ceil(num_reps)))

    if rotation_rate_dps!=0:
        rot = rotation_rate_dps*t_ax_full
        az_err_rot = az_err_pad*np.cos(rot*np.pi/180) - el_err_pad*np.sin(rot*np.pi/180)
        el_err_rot = az_err_pad*np.sin(rot*np.pi/180) + el_err_pad*np.cos(rot*np.pi/180)
        az_err_pad = az_err_rot
        el_err_pad = el_err_rot
        
    t_ax = t_ax_full[t_ax_full<total_duration]
    az_err = az_err_pad[t_ax_full<total_duration]
    el_err = el_err_pad[t_ax_full<total_duration]
    
    if file_out is not None:
        dict_out = {
            't_ax':t_ax,
            'az_error':az_err,
            'el_error':el_err,
        }
        df = pd.DataFrame(dict_out)
        df.to_csv(file_out, float_format='%.3f')
    # with open(file_out, "w") as file:
    #     yaml.dump(dict_out, file)       
    
    return t_ax, az_err, el_err        

def get_sat_pos(timestamp:datetime, observer:Observer, satellite)->tuple:
    observer.date = (timestamp)
    satellite.compute(observer)
    azimuth = observer.az*180/np.pi
    elevation = observer.alt*180/np.pi
    return (azimuth, elevation)   

