# 8. Plan and perform supported runs

Calculate an opportunity before preparing a run. An opportunity describes a
satellite's visibility for a particular site, orbit input, time span and elevation
mask. It is not a queue submission or proof that equipment can execute it.

Results uses Start (UTC ISO 8601), NORAD ID, Span (days), Minimum elevation (deg)
and Local TLE CSV. UTC time needs an explicit offset. Span is one hour through
seven days, elevation 0 through 90 degrees, and at most 256 opportunities are
retained. A circumpolar opportunity can omit rise/set times. Empty results mean
no opportunity was found for these inputs.

Use current approved local orbit data for current operational planning. Native
planning validates the selected identity/CSV/TLE/checksums but does not fetch or
refresh it. The default and the exercise below are explicitly historical NOAA 15
data, not a demonstration of current orbit freshness.

## Practice without hardware

This tutorial extends the earlier operator practice workflow with the current
window labels and daily launchers. It uses a new private directory, synthetic
site coordinates and a historical NOAA 15 TLE. It never uses the daily station
as a disposable fixture. None of the steps below starts a service or opens a
device.

## Inspect the existing station first

From any normal working directory:

```sh
satgs-operator status
satgs-operator --format json status
```

Home > Reload (Ctrl+R) is the matching native action. These commands inspect the
already selected workspace. They do not initialize or repair it. If the daily
selection or workspace is unavailable, retain the diagnostic and read
`satgs-operator docs --text`; do not issue `init` against the daily path.

## Create a private practice workspace

Use Bash and the daily `satgs-operator` command already selected by reviewed
setup. The following creates a unique parent directory under `/tmp`; it changes
only the task-specific variables shown. Keep the printed path for reopening.

```sh
satgs_practice_root=$(mktemp -d /tmp/satgs-guide-practice.XXXXXXXX) || exit 1
satgs_practice_station="$satgs_practice_root/practice station"
printf 'Practice directory: %s\n' "$satgs_practice_root"
satgs-operator --workspace "$satgs_practice_station" init
satgs-operator --workspace "$satgs_practice_station" status
satgs-operator-gui --workspace "$satgs_practice_station" &
```

The new station starts at generation 1 with no selection and no location.
Unknown observations and unqualified calibration/heading are expected. The
space in `practice station` is deliberate; retain the quotes around its path.
The final `&` leaves the graphical window running while this terminal accepts
the paired CLI examples. Close that window normally when the exercise is done.
The daily selection still points to the original saved workspace. The explicit
`--workspace` changes this invocation only. Keep this terminal open for the
remaining examples, or set the two task-specific variables to the exact printed
paths in another terminal.

The examples below use `34.0` degrees north, `-118.0` degrees east and `100.0`
metres, later changing longitude to `-117.0`. These are synthetic practice values
chosen for a repeatable calculation, not a surveyed site or Cole's location.
Mean-sea-level reference is explicitly declared for the exercise; no conversion
is performed.

## Select Guided Arrow and retain returned identities

In Setup choose `guided_arrow` and QPT130, then Preview. Review shows the previous
and proposed selection. Click Save, then Reload to see the saved intent. To
perform the same change through the CLI instead, use this sequence once:

```sh
satgs_component_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json components-preview --profile guided_arrow) || exit 1
satgs_component_id=$(printf '%s' "$satgs_component_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_component_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_component_id" --confirm
satgs-operator --workspace "$satgs_practice_station" reload
```

Review the printed JSON before the apply line. `preview_id` is the actual value
returned by your operation, not a fixed token to copy from this guide. Human
output intentionally omits internal IDs, so use `--format json` before the
command when a later command needs an identity. Stop if preview or JSON parsing
fails. The GUI and CLI alternatives are the same workflow; do not mistake doing
both for a necessary second save.

## Cancel a location preview

In Location enter latitude `34`, longitude `-118`, altitude `100`, and
`mean_sea_level`. Click Preview, inspect Review, then Cancel (Esc). Home > Reload
must still show no effective location. Equivalent CLI:

```sh
satgs_location_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json location-preview --latitude-deg 34 --longitude-deg -118 --altitude-m 100 --altitude-reference mean_sea_level) || exit 1
satgs_location_id=$(printf '%s' "$satgs_location_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_location_preview"
satgs-operator --workspace "$satgs_practice_station" cancel --preview "$satgs_location_id"
satgs-operator --workspace "$satgs_practice_station" status
```

Cancelling preserves saved coordinates and generation. It retains a cancellation
artifact, so it is not a promise of zero filesystem writes. Repeating cancel is
idempotent. Applying that cancelled preview must return conflict, exit 3.

## Save and reopen the manual position

Preview the values again. The previous cancelled identity is not reusable.
Review the new proposal, then Save. Through the CLI:

```sh
satgs_location_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json location-preview --latitude-deg 34 --longitude-deg -118 --altitude-m 100 --altitude-reference mean_sea_level) || exit 1
satgs_location_id=$(printf '%s' "$satgs_location_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_location_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_location_id" --confirm
satgs-operator --workspace "$satgs_practice_station" reload
```

After the one component save and this location save, generation is 3 if you have
made no other changes. Status reports manual latitude `34.0`, longitude `-118.0`,
altitude `100.0` and declared reference `mean_sea_level` in JSON. The everyday
view may omit technical identity fields. GPS stays unavailable, installation
unknown and heading/calibration unqualified.

Close the window normally and run the same quoted GUI command from the first
section again, or use Home > Open station... and choose this practice directory.
Reload must retain the manual selection. Opening another workspace in a window
does not retarget the saved daily launcher selection.

## Plan from an explicitly local historical TLE

Create a local CSV with the same explicit historical data used by the bundled
example. The shell redirects only into your new private practice directory. It
does not require the application's Python interpreter, discover an old
installation or fetch a TLE:

```sh
satgs_practice_tle="$satgs_practice_root/NOAA 15 historical.csv"
printf '%s\n' 'norad_id,name,tle,date' '25338,NOAA 15,"NOAA 15,1 25338U 98030A   25135.84934273  .00000229  00000+0  11192-3 0  9996,2 25338  98.5367 161.5741 0011424  74.5549 285.6893 14.26965248404873",2025-05-16 02:51:09 UTC' > "$satgs_practice_tle"
satgs-operator --workspace "$satgs_practice_station" --format json plan --start 2025-05-16T03:00:00Z --norad-id 25338 --span-days 1 --elevation-deg 20 --tle-file "$satgs_practice_tle"
```

The resulting file has this header and one quoted TLE record. If entering it in
a text editor instead, preserve both lines and save it at the exact
`satgs_practice_tle` path. Do not replace a real station's satellite catalog.

```csv
norad_id,name,tle,date
25338,NOAA 15,"NOAA 15,1 25338U 98030A   25135.84934273  .00000229  00000+0  11192-3 0  9996,2 25338  98.5367 161.5741 0011424  74.5549 285.6893 14.26965248404873",2025-05-16 02:51:09 UTC
```

Then run the `plan` line. In the GUI, set Results fields to the same start,
NORAD ID `25338`, span `1`, elevation `20` and full local CSV path, then Calculate.
The expected result has `source: operator_selected_local_tle`,
`refresh_performed: false`, `execution_enabled: false`, and opportunities from
the real orbit calculation. The exact plan ID depends on your workspace identity
and revision. No fixed ID in a document can replace it. Keep the historical date
visible: this exercise does not demonstrate current orbit freshness.

## Compare planning inputs after relocation

In Location change longitude from `-118` to `-117`, leaving latitude `34`,
altitude `100` and reference unchanged. Preview and Save. CLI equivalent:

```sh
satgs_relocation_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json location-preview --latitude-deg 34 --longitude-deg -117 --altitude-m 100 --altitude-reference mean_sea_level) || exit 1
satgs_relocation_id=$(printf '%s' "$satgs_relocation_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_relocation_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_relocation_id" --confirm
satgs-operator --workspace "$satgs_practice_station" --format json status
satgs-operator --workspace "$satgs_practice_station" --format json plan --start 2025-05-16T03:00:00Z --norad-id 25338 --span-days 1 --elevation-deg 20 --tle-file "$satgs_practice_tle"
```

The earlier plan is marked `revalidation_required: true`. The new plan has a
different station revision and longitude. TLE bytes and calculation time/span/
mask are unchanged. Compare those inputs before comparing opportunity times.
This is a relocation of the planning site, not an antenna alignment command.

## Inspect independent observation states

The optional synthetic status exercise is explicit and local:

```sh
satgs-operator --workspace "$satgs_practice_station" replay --state critical
satgs-operator --workspace "$satgs_practice_station" --format json status
```

Home > Reload shows `critical` system health alongside `transport_pass` and
unqualified heading. JSON identifies `synthetic_replay`, fixed fixture time and
`live_hardware_observed: false`. The saved manual position does not change.
`replay --state unknown` restores unknown replay dimensions; it does not undo the
component or location saves.

## Rehearsal and unavailable live controls

The public Run form can freeze and review an input-bound request, but ordinary
owner admission remains closed. There is no copy-and-run live or rehearsal
`run-start` command that this guide can supply without the separately reviewed
controlled owners and exact inputs. Do not construct broker, serial or device
identities from the practice coordinates.

The release's consolidated acceptance uses disposable stations and controlled
owner/transport boundaries for the changed software checks. It does not initialize
the daily station. Its report identifies which runtime, PTU, GUI and preservation
scenarios actually ran and where their artifacts were retained. This is software
evidence, not a production broker/serial run or physical qualification. The
retained earlier daily-support rehearsal targets its older runtime application;
do not attribute its PASS to this release.

For a started controlled run, Run > Cancel run and `run-cancel --run-id` request
local cancellation. Before starting, `run-status`/`run-cancel` return not_started,
not successful cancellation. Keep software completion, command submission,
manager outcome and physical state separate. PTU Connect/Move/Stop remain gated
for live use; no tutorial step enables them.

## Review a run request

After Calculate, choose the desired Plan on Run. Supply Configuration JSON,
Runtime bindings JSON, Owner settings, the matching Local TLE CSV, Duration
(seconds), Opportunity (1-based) and Execution mode. These are exact reviewed
inputs supplied by the deployment/owner, not files the form invents. Duration
must fit the chosen opportunity. Review run freezes them with the saved manual
position/reference and station revision.

Inspect the reviewed request. Start run is a separate confirmation. Changing
station settings or any bound input requires a new request. The CLI grammar in
the [reference](operator-cli-reference.md#runtime-request-review-and-execution)
uses the actual saved plan and returned request identity; no fixed example ID
can replace either. Ordinary owner admission remains closed even for `rehearsal`.

For an admitted controlled run, keep the returned request identity, read its
progress and final result, then use Results > Report and Export... for a station
snapshot. Retain the separate `run-request-...`, `run-...-progress.json` and
`run-...-result.json` files as described in [Results](results.md). Export does
not bundle them. The controlled acceptance's failed/partial scenarios exercise
these distinctions without opening equipment.

## Cancel or recover without losing the result

Run > Cancel run requests local cancellation of a started run. In a synchronous
CLI run, use another terminal with the same workspace and actual request ID for
run-status/run-cancel. An unfinished disk record is not proof of a live process.
Repeated execution of a finished request returns its retained result rather than
silently repeating motion.

On failure, keep request/progress/result and runner logs. Read primary failure,
manager/submission outcome, software completion, physical state and save/cleanup
details together. Physical indeterminate (exit 8) is not success; local
cancellation (exit 130) is not remote Stop. Do not retry uncertain motion merely
because a result save failed. Use the owner recovery procedure.

## Inspect and export results

```sh
satgs-operator --workspace "$satgs_practice_station" report
satgs-operator --workspace "$satgs_practice_station" --format json report
satgs-operator --workspace "$satgs_practice_station" export --output "$satgs_practice_root/practice report.json"
```

Results > Report and Export... are the equivalent GUI actions. Inspect the
position/reference, retained plans, replay provenance and operation results in
the JSON. Export must create a private new file. Repeating the exact export
returns exit 4 and leaves the existing bytes intact. Choose another filename if
you need another snapshot. Keep the practice directory and report; no deletion
or cleanup is part of this tutorial.

## Deliberate negative checks

These checks belong only to this new practice workspace. Invalid latitude `nan`
must return exit 2 without changing saved coordinates. Applying a valid preview
without `--confirm` must return exit 2. Applying a cancelled or stale preview
must return exit 3. A preview made before the relocation becomes stale. Do not
weaken these restrictions to make a script proceed.

The complete argument grammar and outcome meanings are in the
[CLI reference](operator-cli-reference.md). The
[original-workflow comparison](legacy-comparison.md) explains why a local
planning exercise does not replace queued RF tracking or legacy result storage.
