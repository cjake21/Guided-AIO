# 2. Choose a configuration

Choose a configuration from the work you need to perform and the services your
site actually provides. A profile records those choices. It does not discover
equipment, install packages, start managers or prove readiness.

On Setup, choose Profile and PTU model, then Preview. Review shows the previous
and proposed selection. Save confirms that particular preview. Cancel (Esc)
leaves the saved station unchanged. After another interface saves, use Home >
Reload (Ctrl+R) before making a new change.

## Full M-SEL

Choose `full_msel` when describing an existing full RF station or preparing its
complete legacy software deployment. It keeps the ten-package installation set,
queue manager, pass runner, orbit calculation, ActiveMQ and synchronized time.
PTU, navigation, RF, power, recording and processing capabilities appear as
explicit choices, even where they are optional in the profile definition.

The preset initially selects all its listed packages and capabilities locally.
An optional capability may be omitted where its actual task dependencies permit
it. All ten profile packages remain required to retain the canonical preset.
A smaller package set or another provider requires Custom. The native candidate's
six-owner wheel set is not a fresh complete Full M-SEL installation.

Full M-SEL preserves the wider shared product's historical PTU model contracts,
including QPT-200 and QPT-500. The current native `pelican-qpt130` case still
accepts only QPT130. Do not use that case to select another bench unit or infer
its protocol from a PTU2/PTU4 equipment label.

Full M-SEL does not declare stable optional hardware instances. Converting it to
Custom can therefore display a missing-hardware-identity diagnostic with Save
disabled. Keep the unapplied draft and supply reviewed complete identities, or
start Custom from Guided Arrow's declared instances. Do not invent identifiers
to remove the diagnostic.

## Guided Arrow AIO

Choose `guided_arrow` to describe the canonical portable foundation. It selects
ground_station, meteor-api, sat_tracker, serialptu and pixhawk. Its required
capabilities are ActiveMQ, queue orchestration, pass execution, orbit planning,
PTU control, QPT130 hardware, Pixhawk observation, dual GPS and synchronized time.
The canonical instances are `ptu-1` and `pixhawk-1`.

RF front end, HPA power, Signal Hound recording, post-processing and network
connectivity are sponsor-provided external responsibilities. They are not
implemented external connectors. A sponsor must assign the actual service,
owner, configuration and verification procedure before a dependent task can run.
Guided Arrow does not mean only a PTU connected to a laptop.

There is a current deployment gap: the retained queue implementation requires
local recording and post-processing operations, while this profile excludes
their local packages and marks those capabilities external. The shared planner
reports that conflict. Guided Arrow configuration can be previewed and saved,
but there is no supported Guided Arrow installer apply or complete operational
queue recipe. Local planning remains useful independently of that queue.

## Custom

Choose `custom` for a deliberately narrower or differently assigned station.
Custom begins with the saved selection, or Guided Arrow when none is saved.
Each displayed component retains its canonical identity. Change its Mode and
Provider, then Preview and review the shared validator's result.

Custom does not make every combination valid. Selected local hardware needs
stable instances consistent with its manager/observer. Required dependencies
must be available. Changing a provider to `sponsor` does not create a remote
connector. The planner can report missing dependencies, unsupported cycles,
unknown inventory and unproved reuse after configuration intent has been saved.

For a PTU-only bench, use Custom and identify the PTU software, manager, driver,
broker and physical unit explicitly. Keep unrelated queue, GPS and RF
responsibilities omitted where appropriate. This is a limited bench scope,
not a complete Guided Arrow system or authorization for live movement.

## What the modes mean

![Current native Setup page showing Guided Arrow QPT130 and canonical component choices](assets/native-setup-20261112.png)

Actual handbook-release host capture on CPython 3.11.16/x86-64 and Tcl/Tk 9,
using an owned private Xvfb display. It shows the Guided Arrow/QPT130 component
chooser, not a Pi installation or connected equipment.

| Mode | Meaning | What to do next |
| --- | --- | --- |
| `install` | Propose a local component. For hardware, provisioning and commissioning are still required. | Use the matching reviewed installation route and owner runbook. |
| `reuse` | Propose an existing component with supplied compatible evidence. | Match target, provider, instances, release, revision and compatibility. Package presence alone is insufficient. |
| `external` | Assign a catalog-supported sponsor responsibility outside the local installation. | Obtain the sponsor's real service and interface agreement. No connector is created. |
| `omit` | Exclude the component from this intent. | Check dependent tasks. This does not uninstall software or turn off equipment. |

Configuration and inventory are separate documents. Unknown inventory does not
prove absence. Reuse requires fresh supplied evidence for the exact target; it
is not an optimization inferred from a familiar package name.

## Match the configuration to the job

| Scenario | Needed for its useful supported task | Configuration choice and limitation |
| --- | --- | --- |
| Offline local planning | Native application, scientific libraries, manual site, local TLE CSV | Any saved profile intent or no selection is sufficient for numerical planning. No broker, PTU or GPS is required. |
| Portable QPT130 AIO foundation | Guided Arrow packages, QPT130, Pixhawk/dual GPS, broker and time roles | Canonical Guided Arrow intent is supported; operational deployment/queue gaps remain explicit. |
| Field station with sponsor services | Local selected owners plus assigned sponsor network/RF/power/recording/processing | External intent is supported, not an operational connector. Review each dependent task before deployment. |
| Existing full RF station | Complete legacy owner tree, configured managers, broker, time, receivers, processing and optional storage | Full M-SEL preserves legacy paths. The native window does not replace all RF or queue controls. |
| PTU-only controlled bench | Custom selection, exact bench binding and controlled owner adapter | Limited manual-control software exercise. Live commissioning remains separate. |

## Save a Full M-SEL selection in a practice station

Use the private station created in [Practice without hardware](operator-tutorial.md#create-a-private-practice-workspace).
The following obtains the real preview identity rather than using a fixed ID:

```sh
satgs_full_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json components-preview --profile full_msel) || exit 1
satgs_full_id=$(printf '%s' "$satgs_full_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_full_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_full_id" --confirm
satgs-operator --workspace "$satgs_practice_station" reload
```

Review the printed selection before the apply line. The matching window actions
are Setup > full_msel > Preview, then Review > Save. Nothing is installed.
Read the [component handbook](component-handbook.md) to identify retained old
capabilities, and [Installation](installation.md) for the actual preparation step.

## Make a limited Custom bench selection

Run this additional selection exercise after the main practice tutorial, or in
a fresh practice station. It changes configuration generation, so do not insert
it into the middle of the tutorial's numbered-generation checks.

First save a fresh Guided Arrow selection using the tutorial's component-preview
sequence. In Setup switch to Custom. Omit queue execution, Pixhawk/dual GPS and
external RF/power/recording/processing/network responsibilities for this limited
bench intent. Keep the declared PTU instance, control software, broker/time and
local orbit/planning software. Preview, inspect Review, Save and Reload.

The equivalent CLI creates one explicit changes file in the private practice
parent, obtains the returned preview identity and applies only that preview:

```sh
satgs_custom_changes="$satgs_practice_root/custom-components.json"
printf '%s\n' '{"orchestration.queue_manager":"omit","execution.pass_runner":"omit","pixhawk":"omit","pointing.pixhawk":"omit","pointing.dual_gps":"omit","network.connectivity":"omit","rf.frontend":"omit","power.pdu_hpa":"omit","recording.signal_hound":"omit","processing.msel_post_processing":"omit"}' > "$satgs_custom_changes"
satgs_custom_preview=$(satgs-operator --workspace "$satgs_practice_station" --format json components-preview --profile custom --changes "$satgs_custom_changes") || exit 1
satgs_custom_id=$(printf '%s' "$satgs_custom_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])') || exit 1
printf '%s\n' "$satgs_custom_preview"
satgs-operator --workspace "$satgs_practice_station" apply --preview "$satgs_custom_id" --confirm
satgs-operator --workspace "$satgs_practice_station" reload
```

Review before applying. The result is `preset: null` with explicit canonical
selection modes. The retained `pixhawk-1` instance stays explicitly referenced
by omitted selections; no new device identity is invented. This proves useful
limited configuration behavior, not a new live owner recipe or complete Guided
Arrow deployment. To describe sponsor services instead, keep Guided's external
responsibilities and obtain their actual assigned service contracts.

As a deliberate negative comparison, choose Full M-SEL and save it, then change
to Custom without adding identities. The shared validator rejects its optional
local hardware's missing stable instances. The GUI keeps the unapplied draft
and disables Save; CLI returns invalid input, exit 2. Restore Guided before the
valid Custom exercise rather than inventing hardware IDs.
