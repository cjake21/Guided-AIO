# 3. Component handbook

Setup shows canonical software packages and capabilities, not a discovered
hardware inventory. This chapter covers all 24 entries in the shared catalog.
A package contains code; a capability describes a job or resource that uses
that code. Selecting both does not install a duplicate program.

Each subsection identifies its owner, useful task, connections, provisioning,
settings and a meaningful check. Full and Guided below mean `full_msel` and
`guided_arrow`. The common [mode rules](configurations.md#what-the-modes-mean)
apply throughout. Custom may omit a component only when the dependent task is
also removed or has a supported alternative.

## Software packages

### ground_station

The shared station application is owned by ground_station and installed as
`satgs`. Both profiles require it. It owns saved station settings, deployment
selection, numerical planning, the native window/CLI, queue orchestration and
the pass runner. Manual site coordinates and a local two-line element (TLE)
catalog produce revision-bound plans; previews, receipts and reports are JSON
files in the selected workspace.

Use the reviewed [offline application route](installation.md#install-the-native-release-offline)
for this release. Scientific libraries are base dependencies. `satgs[pointing]`
adds PTU/Pixhawk clients, while `plotting`, `frontend`, `full` and `box` select
their documented optional Python libraries. These extras do not install servers.

Verify `satgs-operator docs --text` before initializing anything, then inspect
`satgs-operator status` for the intended saved station. If planning reports a
missing scientific dependency, repair the inactive candidate rather than the
accepted environment. Omitting this package removes the native workflow; it
cannot be replaced by a dashboard connection.

### meteor-api

The shared application messaging library is owned by meteor-api and distributed
as `meteor_api==2.2.0`. Both profiles require it. Its Messenger carries commands
and observations between station clients, PTU/Pixhawk managers and other service
owners using protocol-buffer messages. It is a Python client library, not an
ActiveMQ installation.

The native offline setup includes the reviewed Messenger and amended lower
transport. The optional `zmq` extra supplies NumPy/ZeroMQ for the separate
METEOR paths; installing it does not switch the station's transport. Preserve the
reviewed combination rather than replacing the amended source with a package
having only the same public version number.

Operational settings include the assigned broker address/port, TLS certificate
identity and trust, STOMP host where required, and private credentials. Keep
those inputs outside source and reports. Check the actual selected transport
and owner outcome under the assigned service runbook. A successful import or
message receipt is not equipment readiness. Local docs/planning remain usable
without contacting Messenger; owner commands do not.

### sat_tracker

The PTU application owner is sat_tracker, distributed as `ptu_control`. It owns
the PTU client, manager and tracking logic. Both profiles require the package;
the control capability and hardware have their own entries below. The client
uses a positive application manager ID to address a configured positioner over
Messenger. The manager, not a GUI callback, owns the serial driver.

The release pairs `ptu_control==0.0.1+ptu.20261117.1` with the same `satgs` and
`serialptu` version. Client installation is separate from `ptu_control[manager]`, which adds
the reviewed serialptu and SciPy dependencies for a local manager. An externally
supplied manager does not make those local dependencies mandatory.

Use [PTU preparation](installation.md#prepare-a-ptu-owner) and the
[PTU session procedure](ptu-operation.md). Settings must identify the application
manager, hardware instance, model/protocol and reviewed policy. Check correlated
Status evidence from that exact owner. If absent or mismatched, keep movement
unavailable and repair the binding. Local planning still works. Session outcomes
and run PTU logs are distinct from physical arrival evidence.

### serialptu

The serialptu repository owns the low-level driver and PTCR20/PTCR96 protocol
construction. Both profiles list it for local pointing ownership. It turns an
admitted prepared move into the final encoded endpoint and receives protocol
responses. It does not choose the station, make a pass plan or authorize motion.

This release supplies `serialptu==0.0.1+ptu.20261117.1` through the
reviewed offline manager closure. Its dependencies include pyserial, NumPy and
SciPy. Do not run the original standalone GUI beside a manager that already owns
the same port. Hardware provisioning also requires the correct serial adapter,
cabling, permissions and physical supply, not another Python package.

The exact wire address is a protocol identity, not the PTU application's manager
ID. Device labels do not establish baud, resolution, limits or Stop support.
Verify the reviewed setup and actual position/Stop response contract before live
use. Missing driver/native dependencies prevent local manager acquisition but
need not prevent offline planning. Preserve driver diagnostics and correlated
outcomes with the session/run evidence.

### pixhawk

The pixhawk owner provides navigation observation. Its Python package is
`pixhawk==0.0.1`. Both profiles require the package. A manager receives MAVLink
observations from the assigned Cube/Pixhawk connection and publishes them through
Messenger; subscribers select configured sensor IDs and can log observations.

The subscriber package is in the offline release. A local manager additionally
selects `pixhawk[manager]`, bringing pyserial, pymavlink and NumPy. Settings map a
positive Pixhawk application ID to its PTU and assigned host serial connection.
The actual manager option is `--pix-id`; the old README's `--ptu-id` wording is
not its parser contract.

Check source identity, message time, fix, health and freshness independently.
The Cube's USB connection to the host is not a GPS receiver's UART connection
to the Cube. Hardware/firmware changes are outside application installation.
Missing observations leave GPS unknown/unavailable; manual site planning remains
usable. Use GPS stays disabled until the complete position-selection contract
is admitted. Run observation CSVs and synthetic native status are different data.

### msel_post_processing

The msel_post_processing owner supplies `satgs-post-processing`, including
`quick_look`, telemetry/capture parsers and result management. Full requires its
package; Guided excludes the local package and declares the processing
capability external. It consumes completed legacy pass directories and produces
analysis outputs, rather than consuming the native Export JSON as a recording.

Provision this owner through the complete reviewed Full M-SEL tree and its
dependency set, not by assuming the six-owner native update contains it. Its
retained package metadata includes plotting/report libraries and Box tooling.
Optional email needs separately supplied protected SMTP settings. Do not copy
an existing credential file into a release bundle.

Use [legacy processing/storage preparation](installation.md#prepare-legacy-processing-and-storage).
Verify the selected input directory and parser/quick-look result under that
deployment's runbook. Missing processing must remain a queue/deployment
diagnostic, not be concealed as a completed pass. Retain source captures, failed
analysis and generated reports together so analysis can be repeated.

### cyberpowerpdu

The cyberpowerpdu owner provides the PDU client and manager used to control
assigned high-power-amplifier (HPA) outlets. Full requires the package; Guided
omits its local package and assigns the power capability to the sponsor. It
exchanges outlet commands/status through Messenger and produces power-control
logs in the legacy pass output.

The native update does not provision a PDU or include a complete Full M-SEL
installation. Use the owner source/dependency route in the full station and
its assigned network/outlet runbook. Host settings, PDU identity, outlet-to-load
mapping and private access inputs must be supplied by that owner.

Before a separately authorized powered run, confirm the mapping and reported
state without confusing a command acknowledgement with the load's physical
condition. If unavailable, dependent HPA/RF tasks cannot claim readiness; local
planning still works. Omit capability intent only when the planned operation
does not depend on it. Do not switch outlets as a software installation check.

### dsi_instruments

The dsi_instruments owner contains RF front-end and loopback managers/clients.
Full requires the package; Guided excludes it locally and assigns RF front-end
responsibility externally. A front-end client submits configuration and observes
status over Messenger; the manager controls assigned instruments and switches.

Provision it in the complete reviewed full station. The owner runbook includes
instrument naming and port assignment; those identities must match the real
deployment. Telnet/native/device requirements are separate from installing the
ground_station `frontend` extra. That extra does not install DSI hardware or
start its manager.

Before RF operation, the responsible operator checks selected routes, frequency
and power constraints using the actual instrument procedure. Unavailable or
unidentified equipment blocks the dependent RF task. Do not replace it with
an invented sponsor endpoint. Local station configuration/planning remains
usable. Keep front-end CSVs, loopback diagnostics and capture configuration with
the associated legacy pass directory.

### signal_hound

The signal_hound owner provides receiver managers/clients for IQ capture, trace
logging and channel-power observations. Full requires its package. Guided
excludes the local package and declares recording external. The RF receiver and
its driver are separate resources from a JSON report exporter.

A usable local deployment requires the complete owner source, compatible native
wrapper/vendor library and assigned receiver model/serial/connection. The
six-owner native release is not such an installation. Use the full station's
maintained receiver runbook. A complete newly qualified receiver installation
recipe is not supplied by the native candidate; obtain it before commissioning
a new receiver rather than treating old service filenames as proof of support.

A useful verification establishes actual selected receiver status and the
intended capture parameters under the RF procedure. Missing native support
prevents recording and can block the retained queue's required path. Capture
files, metadata, trace CSVs and failed/partial recordings remain in the legacy
logging tree. Native Export does not collect or upload them.

### signal_hound_native_wrapper

This canonical package identifies the separately installed native wrapper at
`signal_hound/lib`, owned by the signal_hound component. Full installs it using
the original standard, non-editable step; Guided has no local selection for it.
It supports the Python recording owner and its vendor/native library calls.

Build/install it only with that owner's compatible architecture and vendor
runtime. A Python import on one host does not qualify the Pi's native library,
USB device permissions or receiver model. Use the same bounded receiver runbook
as [signal_hound](component-handbook.md#signal-hound), retaining native build
and device prerequisites as explicit checks.

Without it, the local recording owner cannot be considered complete. Preserve
the exact loader/compatibility diagnostic and repair an inactive candidate;
do not copy an arbitrary shared library into an accepted environment. Its useful
outputs are recording functionality and diagnostics through the parent owner,
not a separate operator report store.

## Capabilities, services and hardware

### broker.activemq

ActiveMQ is the message-broker server. Both profiles require this system
capability. Managers and clients connect through Messenger/STOMP; installing
meteor-api or stomp.py does not install the server. The server can be assigned
to another controller, but its readiness, trust and identities still need a real
deployment agreement.

Use [broker preparation](installation.md#prepare-messaging-and-time) with the
service administrator. It covers the assigned broker release/Java runtime,
service account, TLS listener/trust, private authentication and service health.
The retained unit is `activemq.service`. Do not expose a production endpoint or
credential in the station guide or source.

Verify service health and the exact admitted transport/owner contract separately.
A transport check alone does not prove navigation or pointing readiness. If the
broker is unavailable, owner and legacy queue operations fail; offline docs,
manual configuration and local numerical planning do not need it. Retain server
logs with the service owner and client outcomes with the affected run.

### orchestration.queue_manager

This ground_station capability manages the legacy broker job queue and launches
pass subprocesses. Both profiles require it canonically. Its unit is
`ground_station.service`; settings include station/site, satellite and signal
catalogs, logging paths, broker and processing/storage choices.

Install it only as part of a complete prepared legacy deployment. The manager's
current required recording/post-processing path conflicts with Guided's external
boundary, as explained in [Configurations](configurations.md#guided-arrow-aio).
Native profile Save is not queue-manager startup.

Queue inspection uses the legacy queue client, not native `status` or
`run-status`. A removed pending job is not proof that an executing child stopped.
If prerequisites are missing, keep the queue unavailable and use supported local
planning instead. Retain `queue_manager.log`, submitted job identities and
associated pass directories. The original log phrase Completed Pass is not
reliable success evidence after a child failure.

### execution.pass_runner

The ground_station pass runner performs the pass procedure using selected
clients and managers. Both profiles require the capability. It consumes station,
satellite and RF/runtime inputs, predicts or validates its window, coordinates
owners and records logs/results.

Its code is in `satgs`, but production readiness additionally requires admitted
owners, matching input identities, synchronized time, policy and physical setup.
The native Run page freezes a plan, configuration, runtime bindings, owner
settings, local TLE and duration before separate confirmation. This release
does not provide ordinary live admission.

Use [run review](operator-tutorial.md#review-a-run-request) for the supported part
and the release's controlled acceptance for software rehearsal. Do not improvise
legacy `--nohw` flags as an isolated sandbox. Failure, cleanup, submitted commands
and physical state are retained separately. Local cancellation is not physical
Stop. Keep native request/progress/result files and the runner's own logging
directory, including partial files.

### orbit.pass_finder

The ground_station orbit calculator predicts visibility opportunities from a
site, TLEs, times and an elevation mask. Both profiles require this capability,
but local native calculation does not require the rest of their operational
services. Scientific dependencies are included with the reviewed `satgs` base.

Use Results > Calculate or the complete [planning exercise](operator-tutorial.md).
Supply a saved manual site and a bounded ordinary local CSV. Native planning
does not fetch or refresh TLEs; the original `pass_finder` path may do so and has
different defaults. A TLE CSV called a database is not a persistent history
database service.

Check NORAD identity, TLE source/epoch, UTC start, days and degree mask before
interpreting opportunities. Empty opportunities mean none were found for those
inputs. The full plan is automatically retained as `plan-<id>.json`; Report
includes a summary. Invalid inputs or missing dependencies produce an error,
not a zero-position or fabricated successful pass.

### pointing.ptu

PTU control is the sat_tracker client/manager capability backed by serialptu.
It is optional in Full and required in Guided, using Guided's `ptu-1` instance.
A Custom local owner must refer to the same stable hardware instance as the
selected unit. Clients use Messenger; one manager owns the serial port.

Prepare the reviewed [PTU owner](installation.md#prepare-a-ptu-owner), then follow
[PTU operation](ptu-operation.md). Application manager ID, serial wire address,
protocol and physical model are independent settings. The manager supplies
actual reported position and command outcomes; the GUI must not manufacture
current angles from requested targets.

Selected QPT130/PTCR20 manual and query-only sessions use validated private
configuration and the isolated local TLS broker. Satellite pointing admission
remains closed; this selected manual route does not commission the hardware.

If ownership, position, Stop or policy evidence is unavailable, movement stays
unavailable. Offline planning and saved coordinates still work. Directional
steps and numeric moves share the same bounded owner path and endpoint checks.
Disconnect releases local ownership but does not establish physical Stop.
Preserve session diagnostics and PTU command/status CSVs with their run.

### pointing.qpt130

This is physical QPT130 pan/tilt hardware, not a Python package. It is optional
in Full with `station_hardware` responsibility and required in Guided as
`guided_arrow_hardware`, instance `ptu-1`. Its selected control capability must
refer to that same instance.

Provision the allocated unit, matching supply, mounts, cable/adapter and reviewed
settings through the equipment owner. This portable case's supply supports
QPT130 only. A package installation cannot determine whether a particular unit
is high-resolution, its protocol/baud/wire address, mechanical limits or Stop
behavior. PTU2/PTU4 labels do not answer those questions.

A useful check establishes the exact unit and admitted current-position/Stop
contract before motion, then the separately approved commissioning procedure.
No physical commissioning is performed by this PTU update. Without the
unit, local planning and controlled software tests remain possible, but they
must not be described as live QPT130 movement. Keep allocated-unit settings and
qualification records outside ordinary operator source history.

### pointing.pixhawk

This observation capability is owned by pixhawk. Full makes it optional; Guided
requires it for `pixhawk-1`. It connects the assigned host-side Cube/Pixhawk
serial source to Messenger and publishes selected MAVLink observations. A
subscriber is not a local manager and does not open the USB device itself.

Provision the local manager extra and assigned service only when the deployment
owns that connection. Its source ID, positive application sensor ID, PTU mapping,
serial source and message settings must agree. The retained `pixhawk.service`
is a template, not a new automatic service installer.

Verify observation source, valid fix, time, freshness and system health
independently. A 3D fix does not qualify dual-GPS heading or select a station
position. Missing observation leaves those dimensions unknown/unavailable while
manual-site planning remains usable. Native synthetic replay is clearly separate
from live observations. Keep actual subscriber logs with the legacy/run output.

### pointing.dual_gps

This is the physical dual-GPS observation assembly, not a second host USB
manager. Full makes it optional under station hardware; Guided requires
`pixhawk-1` under Guided Arrow hardware. Both receivers' observations are handled
by the Pixhawk capability using its stable instance mapping.

The receivers' UART connections and their firmware/configuration belong to the
navigation equipment procedure. Installing pymavlink or connecting Cube USB
does not configure those receiver UARTs or establish moving-baseline heading.
No Cube/receiver changes are part of this software update.

Useful evidence includes selected receiver identities, independent fix/health,
source times, coordinate/altitude reference, heading reference and alignment.
If any required evidence is unavailable, do not substitute magnetometer yaw or
invent a final observation. Manual position remains a separate planning source.
Retain navigation configuration/qualification and actual telemetry records; a
synthetic native GPS display is not a receiver commissioning record.

### time.ntp

Synchronized time is a system capability required by both profiles for scheduling
and timestamp interpretation. It is not a Python dependency. The host/service
administrator assigns the time source and configures the supported system time
client, such as the retained Chrony route.

Use [messaging and time preparation](installation.md#prepare-messaging-and-time).
Inspect `chronyc sources` and `timedatectl` on an authorized deployment to verify
the selected source and synchronization, not merely that a package exists.
No particular internal server is embedded in this guide.

Unknown synchronization prevents a claim that operational scheduling or freshness
is qualified. Offline historical examples remain explicitly historical; their
fixed timestamps do not measure the host's clock. Preserve system time/service
diagnostics with operational evidence when timing matters. Changing an application
profile neither starts NTP nor changes the host's time source.

### network.connectivity

This Guided-only entry assigns network connectivity to the sponsor. The catalog
provides an external provider, not a local installable connector. Full has no
separate canonical entry for it, although its services still need their assigned
network connections. Custom cannot turn this ID into a fabricated local driver.

The sponsor supplies access, routing, approved name/address and trust resources,
firewall policy and any private authentication. Agree which hosts may reach
which assigned services before provisioning them. Do not copy development keys
to the Pi or disable certificate/host verification to make access work.

Verify only the authorized service route with its owner. Broker transport,
repository access and optional storage connectivity are different checks. Loss
of network can leave local docs, saved settings and local numerical planning
usable while remote owner operations fail. Retain useful bounded diagnostics
without credentials or production payloads.

### rf.frontend

The RF front-end capability is owned by dsi_instruments and uses its manager,
client and assigned instruments. Full includes it as optional local SATGS
responsibility; Guided marks it external sponsor responsibility. Its unit is
`frontend.service`. Its settings select instruments, assigned ports/names and
RF routing/parameters.

Use [RF and power preparation](installation.md#prepare-rf-power-and-recording)
with the responsible RF operator. Local installation requires dsi_instruments
and broker support. An external Guided selection does not provide a supported
remote connector or automatically validate sponsor RF equipment.

Check actual configuration/status using the station's RF runbook before a
dependent run. Omission/unavailability removes those RF operations, not local
orbit calculations. Do not infer a safe RF path from a component checkbox.
Retain front-end configuration/status logs and any loopback diagnostics with
the legacy run and capture files.

### power.pdu_hpa

This capability controls assigned PDU/HPA power through cyberpowerpdu. Full
includes it optionally; Guided assigns it externally. The retained local unit
is `cyberpower_pdu.service`. It depends on the PDU package and broker, plus
the real PDU/network identity and outlet-to-load mapping.

Provision it under [RF and power preparation](installation.md#prepare-rf-power-and-recording),
not as a consequence of selecting QPT130. The portable PTU supply and a remotely
controlled HPA outlet are different resources. Private PDU access settings are
supplied by the equipment owner, never copied from an example into source.

A useful pre-operation check confirms selected device/mapping and actual reported
state without energizing a load merely to prove installation. If missing, the
dependent power/RF task remains unavailable. Keep PDU/HPA logs and command
outcomes with the pass. A reported command acceptance is not evidence that the
physical load reached the requested condition.

### recording.signal_hound

Signal Hound recording uses the signal_hound Python owner, native wrapper and
assigned receiver. Full includes this capability optionally; Guided marks it
external. Local service records distinguish IQ logging (`sh_iq_logger.service`)
from swept trace/channel-power logging (`sh_trace_logger.service`). They are
not two extra canonical components.

Provision the actual software/native/hardware combination through the full
station receiver runbook. Set approved receiver identity, frequency/sample or
trace parameters, output directory and storage capacity. The native report
exporter has none of those roles. A sponsor selection is not an implemented
capture service connector.

Verify receiver status and intended capture setup under the separately authorized
RF procedure. Missing native support blocks recording and the retained queue's
required operation. Keep SigMF data/metadata, channel power, trace CSVs and
partial capture files together. Empty or truncated capture is not repaired by
a successful JSON report export.

### processing.msel_post_processing

This capability applies the msel_post_processing owner's analysis to legacy pass
directories. Full includes it optionally; Guided assigns it externally. The
retained queue invokes `quick_look` and related processing after its child pass
path; this real dependency is why external selection alone cannot satisfy the
current Guided queue.

Use [processing/storage preparation](installation.md#prepare-legacy-processing-and-storage).
Provide compatible parser/report dependencies, the correct input tree and chosen
output/retention policy. Optional email or Box requires separate private settings
and assigned resources. Installing the native handbook does not provision them.

Verify the processing result against the selected capture and retain failures
without replacing raw data. Native Report/Export is a different inspection
workflow and cannot serve as a raw pass-directory input. If processing is omitted,
do not label analysis complete or silently discard its queue diagnostic. Keep
raw inputs, generated reports and processing logs for repeatability.

## Dependencies not represented by extra catalog rows

The reviewed lower `stomp.py` transport is a Python client dependency of
meteor-api, not another broker. Its amended bounded transport contract must be
preserved even though its version remains 8.1.0. The optional Meteor ZeroMQ
extra serves different application paths and does not replace shared Messenger.

Python, Tk/Tcl, scientific/native libraries, pyserial, pymavlink, protobuf
runtime and build-only protobuf compiler are prerequisites of selected owners.
They are not extra invented component IDs. See the exact [package selection](installation.md#software-roles-and-package-selection).
The original browser front/backend are separately owned optional applications;
neither native Help nor Export starts them or proves database persistence.
