# 1. Purpose and architecture

SATGS helps an operator configure a satellite ground station, calculate when a
satellite is visible, and review station and run results. The native SATGS
window and `satgs-operator` terminal command work on the same saved station.
Choose the interface that fits the task: the window for routine work, the
command line for repeatable inputs, complete identifiers and an SSH session.
The optional browser dashboard is a separate application.

## Choose your starting point

- New operators: read [Choose a configuration](configurations.md),
   [Install and prepare](installation.md), then [Daily operation](daily-operation.md).
- Existing M-SEL operators: start with the [migration walkthroughs](legacy-comparison.md),
   then use the [component handbook](component-handbook.md) to locate familiar owners.
- Field operators: compare the portable and sponsor-provided scenarios in
   [Configurations](configurations.md#match-the-configuration-to-the-job).
- Maintainers: read [Updates and troubleshooting](updates-troubleshooting.md),
   the [CLI reference and glossary](operator-cli-reference.md), and the
   [technical appendix](maintainer-reference.md).

The linked contents at the beginning of the installed guide covers twelve
chapters and the appendix. [Practice without hardware](operator-tutorial.md)
provides complete paired window/CLI exercises in a separate station directory.

## From a distributed station to one modular product

The original M-SEL station is a collection of cooperating programs. A controller
runs the pass queue and the ActiveMQ message broker. Pointing programs manage
the pan/tilt unit (PTU) and collect Pixhawk navigation observations. Other
controllers may manage the radio-frequency (RF) front end, power equipment and
Signal Hound receivers. These programs exchange messages rather than requiring
all equipment to be attached to the operator's computer.

The QPT130 all-in-one (AIO) case brings selected equipment together in a portable
box. Its power-supply applicability is QPT130 only. That physical consolidation
does not by itself make the software modular. Software modularity means choosing
the required software and services, preserving their ownership, recording their
identities and connecting only supported combinations. The same ground_station
product serves Full M-SEL, Guided Arrow and Custom configurations; Guided Arrow
is not a separate application fork.

| Owner | Responsibility | What it does not replace |
| --- | --- | --- |
| ground_station | Shared selection, station settings, orbit planning and pass orchestration | The low-level PTU driver or service provisioning |
| sat_tracker / ptu_control | PTU client, manager and higher-level tracking | Serial protocol construction |
| serialptu | Serial driver, protocol messages and encoded endpoint checks | Station planning or GUI state |
| pixhawk | Navigation observation and handling | Survey, antenna alignment or an admitted station-position selector |
| meteor-api / Messenger | Shared application messaging | The ActiveMQ server |
| selected lower transport | Verified transport below Messenger | Application command authorization |

The [component handbook](component-handbook.md) covers all canonical software,
hardware and capability entries, including the RF and processing owners.

## What this release can do

The shared native workflow saves component intent and manual station coordinates,
reviews changes before applying them, reloads saved settings, calculates local
satellite opportunities, and writes a private JSON report. A changed station
revision marks older plans for revalidation. The window's Home, Setup, Location,
Review and Results pages use these same operations as the CLI.

Run adds input-bound request review and software execution through the existing
pass runner. PTU adds explicit sessions and numeric targets; the directional
controls are described in the [PTU chapter](ptu-operation.md). Their software
paths can be exercised with controlled owners. Ordinary live owner admission
remains closed. Read the [run procedure](operator-tutorial.md#review-a-run-request)
before using those pages.

| Task | Available here | Further requirement |
| --- | --- | --- |
| Save component intent and manual coordinates | Shared GUI/CLI operations | A private initialized station |
| Calculate local passes | Existing numerical orbit calculation | Scientific dependencies, saved position and explicit local orbit data |
| Read and export a report | Local JSON inspection and new-file export | A suitable private output directory |
| Exercise a controlled run or PTU session | Shared owner path under supplied controlled acceptance | Its actual release-matched fixtures and report |
| Execute live pointing, select live GPS, qualify heading/Stop | Not admitted by this release | Reviewed device, owner, position, Stop, alignment and commissioning contracts |
| Operate the full RF queue, post-process or synchronize Box results | Retained legacy deployment paths | Complete separately prepared Full M-SEL deployment |
| Browse database history from the native application | No native implementation | A separately specified storage workflow |

Host software tests, Pi software checks and physical commissioning are different
results. The accepted preceding guide passed its supplied Pi acceptance. That
does not establish a Pi or physical PASS for this changed handbook/PTU release.
Release-specific evidence is described in the [appendix](maintainer-reference.md).

## Understand installation, configuration and observation

Installation answers which software is present. Configuration records what the
station should use. Observation records what a source actually reported and
when. Saving a profile answers the configuration question. The next step is to
prepare its software and assigned services using [Installation](installation.md),
not to assume that Save installed or connected them.

Station settings survive closing the application because they live in the
workspace, not in the window. Selection of the daily application lives separately
from the station. Changing the release does not choose a new telemetry source;
opening a practice workspace does not change the saved daily selection.

Coordinates establish a planning site, not the antenna's north reference,
mechanical calibration or clear motion trajectory. A received message establishes
receipt, not a valid GPS fix or healthy equipment. Home therefore keeps
connection, message receipt, fix, freshness, system health, transport check,
calibration, heading, installation and configuration distinct.

Continue with [Choose a configuration](configurations.md), or open the
[daily quickstart](daily-operation.md#daily-quickstart) if your accepted application
is already installed.
