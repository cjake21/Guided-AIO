# 9. Save, find and reuse results

Closing the application does not discard saved station settings or completed
artifacts. They are already in the workspace. Export creates a portable report
snapshot; it is not the action that first saves the station, plan or run.

## Find what was saved automatically

Use the workspace printed by JSON status or selected in Home. Open that same
directory through Home > Open station... to resume station work. Keep the entire
private directory when preserving its operation history.

| File in the workspace | Content and when it appears |
| --- | --- |
| `station.json` | Current component selection, manual position/reference, generation, replay choice and last saved operation |
| `preview-<preview_id>.json` | Reviewed previous/proposed configuration, expected revision and affected-plan summaries; retained at Preview |
| `receipt-<preview_id>.json` | Apply outcome, saved revision, change and partial/durability details |
| `cancel-<preview_id>.json` | Configuration-preview cancellation result |
| `plan-<plan_id>.json` | Complete local planning inputs and opportunities, automatically retained after Calculate |
| `run-request-<request_id>.json` | Frozen reviewed run inputs and their identities |
| `run-<request_id>-started.json` | Started/admitting record; does not by itself establish a live process |
| `run-<request_id>-progress.json` | Latest recorded run progress, replaced by the owned runner |
| `run-<request_id>-cancel.json` | Local cancellation request, not proof of remote cancellation or Stop |
| `run-<request_id>-result.json` | Finished outcome, submission/manager evidence, physical state, cleanup and save details when recorded |
| `bench-<attempt_id>-started.json` | Explicit PTU operation attempt; Stop and disconnect may record it after attempting the operation |
| `bench-<attempt_id>-result.json` | PTU outcome, correlated Status/Preview/Move step phases, submission, cleanup and recording details |

The angle-bracket portions above describe actual generated identities, not literal
filenames to create. Previews, plans and requests have separate identities.
Do not substitute a legacy numeric queue job ID for one of them.

For a PTU session, keep both bench files and inspect `category`, `submission`,
`physical_state`, `steps`, `partial`, `recording_errors` and `result_recorded`.
`exchanges` retains up to three ordered request/response receipts per owner
operation, including exact bounded hexadecimal bytes, write disposition and
owner-process monotonic timing. Stop acknowledgement and subsequent status
failure remain separate. `selected_context` retains the chosen serial identity,
settings and manual restrictions, without broker credentials or CA data.
A failed later phase does not erase earlier recorded phases. A recording failure
does not prove that no command was submitted. Automatic background Status keeps
only the bounded current-session readback; it does not write a new pair of files
on every poll. Explicit Status and directional operations retain their records.

## View a plan or run again

Results > Report and `satgs-operator report` inspect the current station and its
retained plan summaries and configuration-operation results. It also includes
bounded bench attempt/results, including incomplete attempts and failed
exchanges, in `bench_results`. The report marks
plans needing revalidation after a station change. The complete opportunity list
and original inputs live in the corresponding `plan-<plan_id>.json` file.

The native application has no general saved-run browser or import-and-replay
button. For a run, retain its actual `request_id` returned by Review run and use
`run-status --run-id` with that identity. It reads the finished result first,
then progress or started state. A record explicitly says liveness is not
established from disk. Before a run starts, the result is `not_started`, not a
successful run or cancellation.

Read `exit_code`, `primary`, `manager_outcome`, `software_completed`, submission
fields, `physical_state`, `cleanup_categories`, `save_errors`, `result_recorded`
and `partial` together. A software-complete outcome can still have indeterminate
physical state. A missing result file can coexist with useful retained progress
and logs. Keep these records before considering recovery or another request.

## Export a report to a new file

In Results, click Report to inspect the report. Click Export..., choose an
existing private directory and a new filename, then retain the printed result.
The paired tutorial CLI is:

```sh
satgs-operator --workspace "$satgs_practice_station" report
satgs-operator --workspace "$satgs_practice_station" --format json report
satgs-operator --workspace "$satgs_practice_station" export --output "$satgs_practice_root/practice report.json"
```

The [practice tutorial](operator-tutorial.md) creates these variables. Export
creates a private file and refuses any existing output. Repeating the same path
returns exit 4 without replacing it. Choose a different filename for another
snapshot. Export does not create a new parent directory, accept `-` as stdout,
insert a database row or upload to Box.

## What the report actually contains

The exported object is an operator workspace inspection. It includes station
identity/revision, generation, configuration/deployment-plan diagnostics,
manual/effective/measured position, independent status/source dimensions,
installed identity, plan summaries and receipt/cancellation operation results.
The selected PTU records are included with credential-free context and exchange
receipts. This is not a complete workspace backup.

This small schema illustration shows selected fields, not a captured live run:

```json
{
  "schema_version": 1,
  "report_kind": "operator_workspace_inspection",
  "planning_only": true,
  "owner_state": "not_checked",
  "live_checks_started": false,
  "capabilities": {
    "install": false,
    "activate": false,
    "hardware_control": false,
    "manual_location": true,
    "local_planning": true,
    "report_export": true
  }
}
```

CLI JSON wraps the result in its status/result envelope; the exported file is the
report itself. Export does not bundle full plan documents, run requests/progress/
results, RF captures or supporting logs. Preserve those separately. A displayed
report cannot be treated as a full station backup or successful run record.

## Keep failed and partial results

If apply reports a receipt failure, inspect the real saved station before
retrying. If a run reports execution, cleanup or persistence failure, keep the
request, started/progress/result records that exist and the runner's output
directory. `partial: true` is useful evidence, not a reason to delete it.

An indeterminate run must not be labeled successful because its software
completed. Local Cancel run requests cancellation only. It does not establish
remote Stop, physical stopping or safe restart. Follow the specific owner/unit
recovery procedure before another equipment request.

The tutorial's overwrite rejection is a repeatable harmless failure example.
The release's controlled run acceptance supplies separate execution/partial
outcome examples without contacting equipment. Check that report's actual
scenario and artifacts; source review is not an executed run.

## Preserve supporting logs and legacy data

The pass runner also uses its configured `logging_dir`, separate from native
workspace JSON. Depending on the selected legacy operation, it retains truth
positions (`sat_truth_pos.csv`), `test_details.yaml`, `tle.txt`, program/warnings
logs, PTU command/status CSVs, Pixhawk observations, front-end and HPA logs,
SigMF captures, channel power and trace files. Post-processing adds its own
analysis/report outputs. Native Report/Export does not collect this directory.

Queue, broker and manager services have their own logs. Keep the relevant bounded
diagnostics and exact input configuration privately with the run, excluding
credentials when sharing. Technical acceptance archives describe tests and
installation checks; they are neither RF captures nor routine workspace reports.

## Back up or transfer selected data

Wait until the relevant managed activity is idle before copying a workspace or
logging tree for a consistent snapshot. Retain the source data and copy into a
new private destination. Include the workspace, complete plan/run artifacts,
required local TLE/configuration inputs, supporting logs and any legacy captures
needed for the intended reuse. Review private settings before sharing.

Use the organization's approved local-media or authenticated transfer route.
This release adds no upload destination or automatic cloud synchronization.
Confirm the destination files and permissions before relying on the copy; a
single exported report is insufficient for a full restore.

The managed station marker binds its original absolute workspace path. A byte
copy at another path is an archive, not automatically a new reopenable station.
The native application has no workspace import/relocation tool. Do not edit its
marker to bypass admission. For another working site create a new workspace and
deliberately save its settings. Restore an archived station only through a
reviewed compatible recovery to its original path, preserving any current/failed
data instead of overwriting it blindly.

Optional legacy Box requires its package, private authentication, assigned
destination and configured workflow. The pinned queue's automatic synchronization
is conditional and narrower than all results. Database history has no native
workflow. See [Installation](installation.md#prepare-legacy-processing-and-storage)
and [Updates](updates-troubleshooting.md) before changing data or application versions.
