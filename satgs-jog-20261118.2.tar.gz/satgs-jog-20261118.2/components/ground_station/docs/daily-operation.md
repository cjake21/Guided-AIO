# 5. Start and use the GUI or CLI

## Daily quickstart

On your normal local or remote desktop, open the application menu and choose
SATGS. The terminal equivalent is:

```sh
satgs-operator-gui
```

No virtual-environment activation or versioned application path is needed.
Inspect the selected station before changing it:

```sh
satgs-operator status
satgs-operator docs
```

The daily wrappers use the saved release and workspace. The usual daily station
is `/home/admin/satgs/station`. A missing station is an error, not an instruction
to initialize or replace it. Leave a working accepted selection alone until a
reviewed update is ready. [Updates](updates-troubleshooting.md) explains separate
installation, acceptance and explicit selection.

The preceding guide release is the retained rollback choice. This handbook uses
its own `handbook` selection after acceptance. Selection changes which installed
application the wrappers use. It does not open a window, choose a hardware unit,
select a profile or select live/replay observations.

## Use a desktop, remote desktop or SSH

A remote desktop attached to your normal graphical login can use the menu and
window like a local desktop. An SSH-only session should use the CLI and:

```sh
satgs-operator docs --text
```

Do not force `DISPLAY=:0` or borrow another desktop session's permissions. A
forwarded or inherited display variable does not establish a usable desktop.
The documentation dispatcher uses terminal fallback in SSH/headless sessions.

Sourced setup updates PATH in that terminal only. Shell profiles and global PATH
are unchanged. If a new terminal cannot find the commands, use the installed
wrappers directly:

```sh
~/.local/bin/satgs-operator status
~/.local/bin/satgs-operator-gui
```

## Choose the station workspace

A workspace is the private directory containing saved station settings and
artifacts. Home > Open station... opens an existing workspace in this window.
Home > New station... creates a new one; it refuses an existing directory rather
than resetting it. Use a separate workspace for another site or practice task.

An explicit path changes only the current invocation:

```sh
satgs-operator --workspace "$satgs_practice_station" status
satgs-operator-gui --workspace "$satgs_practice_station"
```

The variable is created by the [practice tutorial](operator-tutorial.md).
Keep quotes around paths containing spaces. Opening another workspace does not
retarget the saved daily launcher selection. Direct developer package entry
points have different defaults, described in the [CLI reference](operator-cli-reference.md).

## Find the right page

| Page | Use it for | Saved or observed result |
| --- | --- | --- |
| Home | Inspect the station, open/create a workspace and Reload (Ctrl+R) | Saved settings and separately reported status dimensions |
| Setup | Choose Profile, QPT130 model and Custom modes/providers; Preview | Proposed component intent, not installation |
| Location | Enter decimal-degree site coordinates and altitude/reference; Preview | A proposed manual planning position |
| Review | Inspect previous/proposed values, then Save or Cancel (Esc) | A receipt or cancellation artifact |
| Results | Enter local TLE/start/NORAD/span/elevation; Calculate, Report, Export... | Retained plans and a new report file |
| Run | Provide explicit input files; Review run, Start run, Cancel run | Reviewed request and separate progress/result artifacts |
| PTU | Open a deliberate owner session; inspect reported position and request bounded moves | Session outcomes, not inferred physical arrival |

Help > User Guide opens this installed release's offline guide without discarding
drafts or changing the selected tab. The same content is available through
`satgs-operator docs`, `satgs-operator --read-docs` and `docs --text`. Docs work
before station initialization and with missing or invalid station configuration.
A viewer-dispatch success means the local viewer was invoked, not that a human
saw a rendered window. Unavailable/failed viewers fall back to readable text.

## Interpret status before acting

| Display | Meaning and useful next step |
| --- | --- |
| Selection: No data / `unconfigured` | No saved canonical selection. Choose and review intent on Setup when needed. |
| No location set. | Enter a deliberate manual position on Location before planning. |
| `unknown` | No admitted evidence establishes that dimension. Check its assigned source or validation record. |
| `selected_local` | Component intent is saved; installation and readiness remain separate. |
| `unqualified` heading/calibration | Coordinates and message receipt do not establish antenna alignment. Use the separate qualification procedure. |
| `critical` with `transport_pass` | Health and transport can disagree. Inspect both rather than treating received messages as health. |
| `fresh_replay` | A fixed synthetic observation, not a current live timestamp. |

Generation counts saved configuration changes, not messages or installations.
New stations start at generation 1. JSON status retains identities, source times
and diagnostics that everyday human output omits. After another GUI/CLI saves,
Reload before editing. If a preview conflicts, reload and create a fresh preview;
there is no force-save override.

Continue with [Station location](station-location.md) or the
[hardware-free practice workflow](operator-tutorial.md).
