import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from satgs import operator_core as core
from satgs.operator_activity import StationLease
from satgs.station_location import prepare_manual_location


class OperatorCoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name) / "practice"
        self.workspace = core.initialize_workspace(self.root)

    def location(self, **options):
        values = dict(latitude_deg=42, longitude_deg=-71, altitude_m=12.5,
                      altitude_reference="unspecified")
        values.update(options)
        return self.workspace.preview_location(**values)

    def test_new_workspace_is_private_unconfigured_and_has_no_inferred_observations(self):
        status = self.workspace.inspect()
        self.assertEqual(self.root.stat().st_mode & 0o777, 0o700)
        self.assertEqual(self.workspace.station_path.stat().st_mode & 0o777, 0o600)
        self.assertIsNone(status["location"])
        self.assertEqual(status["status"]["configuration"], "unconfigured")
        self.assertIsNone(status["measured_gps"]["coordinates"])
        self.assertFalse(status["gps_selection"]["enabled"])
        self.assertEqual(len(status["gps_selection"]["unmet_requirements"]), 4)
        self.assertFalse(status["capabilities"]["install"])
        self.assertFalse(status["capabilities"]["activate"])
        self.assertFalse((self.root / ".activity.lock").exists())
        with self.assertRaises(core.OperatorError):
            core.initialize_workspace(self.root)

    def test_preview_cancel_and_shared_validator(self):
        before = self.workspace.station_path.read_bytes()
        with patch.object(core, "prepare_manual_location", wraps=prepare_manual_location) as operation:
            preview = self.location()
        operation.assert_called_once()
        self.assertIsNone(preview["previous"])
        self.assertEqual(preview["proposed"]["altitude_reference"], "unspecified")
        self.assertFalse(preview["proposed"]["altitude_qualified"])
        self.assertEqual(self.workspace.station_path.read_bytes(), before)
        self.assertEqual(self.location()["preview_id"], preview["preview_id"])
        self.workspace.cancel(preview["preview_id"])
        self.workspace.cancel(preview["preview_id"])
        with self.assertRaises(core.OperatorError) as raised:
            self.workspace.apply(preview["preview_id"])
        self.assertEqual(raised.exception.code, "cancelled")
        self.assertEqual(self.workspace.station_path.read_bytes(), before)
        reviewed = self.location()
        self.assertNotEqual(reviewed["preview_id"], preview["preview_id"])
        self.assertEqual(self.workspace.apply(reviewed["preview_id"])["result"], "saved")

    def test_apply_reload_repeat_and_identical_request(self):
        preview = self.location()
        first = self.workspace.apply(preview["preview_id"])
        saved = self.workspace.station_path.read_bytes()
        self.assertEqual(self.workspace.apply(preview["preview_id"]), first)
        self.assertEqual(self.workspace.station_path.read_bytes(), saved)
        reloaded = core.Workspace(self.root)
        self.assertEqual(reloaded.inspect()["location"], preview["proposed"])
        second = reloaded.preview_location(42, -71, 12.5, "unspecified")
        self.assertFalse(second["changed"])
        result = reloaded.apply(second["preview_id"])
        self.assertEqual(result["result"], "unchanged")
        self.assertEqual(self.workspace.station_path.read_bytes(), saved)
        with self.assertRaises(core.OperatorError):
            self.workspace.cancel(preview["preview_id"])

    def test_reference_change_changes_planning_identity_without_inventing_conversion(self):
        first = self.location()
        self.workspace.apply(first["preview_id"])
        second = self.location(altitude_reference="mean_sea_level")
        self.assertTrue(second["changed"])
        self.assertEqual(first["proposed"]["identity"], second["proposed"]["identity"])
        self.assertNotEqual(first["proposed"]["planning_identity"], second["proposed"]["planning_identity"])
        self.assertEqual(second["proposed"]["altitude_m"], 12.5)
        self.assertFalse(second["proposed"]["altitude_qualified"])

    def test_invalid_nonfinite_boundary_and_revision_inputs(self):
        before = self.workspace.station_path.read_bytes()
        for options in ({"latitude_deg": True}, {"latitude_deg": float("nan")},
                        {"longitude_deg": float("inf")}, {"altitude_m": float("-inf")},
                        {"latitude_deg": 91}, {"longitude_deg": -181},
                        {"altitude_reference": "ellipsoid-guessed"}, {"expected_revision": ""}):
            with self.subTest(options=options), self.assertRaises(core.OperatorError):
                self.location(**options)
        for latitude, longitude in ((-90, -180), (90, 180)):
            self.assertEqual(self.location(latitude_deg=latitude, longitude_deg=longitude, altitude_m=-10)["proposed"]["altitude_m"], -10)
        with self.assertRaises(core.OperatorError) as raised:
            self.location(expected_revision="b" * 64)
        self.assertEqual(raised.exception.code, "stale_revision")
        self.assertEqual(self.workspace.station_path.read_bytes(), before)

    def test_preserves_unrelated_private_values_and_reports_do_not_expose_them(self):
        _, settings = self.workspace.snapshot()
        settings.update(amq_password="SYNTHETIC-PRIVATE-OPERATOR-CANARY", unrelated={"values": [1, 2]})
        self.workspace.station_path.write_text(json.dumps(settings))
        preview = self.location()
        self.workspace.apply(preview["preview_id"])
        _, saved = self.workspace.snapshot()
        self.assertEqual(saved["unrelated"], {"values": [1, 2]})
        self.assertEqual(saved["amq_password"], settings["amq_password"])
        self.assertNotIn(settings["amq_password"], json.dumps(self.workspace.report()))
        self.assertNotIn(settings["amq_password"], json.dumps(preview))

    def test_stale_previews_and_conflicting_threads_cannot_overwrite(self):
        first = self.location()
        second = self.location(latitude_deg=43)
        results = []
        start = threading.Barrier(3)

        def apply(identity):
            start.wait()
            try:
                results.append(self.workspace.apply(identity)["result"])
            except core.OperatorError as error:
                results.append(error.code)

        workers = [threading.Thread(target=apply, args=(record["preview_id"],)) for record in (first, second)]
        for worker in workers:
            worker.start()
        start.wait()
        for worker in workers:
            worker.join(5)
            self.assertFalse(worker.is_alive())
        self.assertEqual(results.count("saved"), 1)
        self.assertTrue(set(results) <= {"saved", "active_work", "stale_revision"})

    def test_active_work_rejects_apply_without_changing_station(self):
        preview = self.location()
        before = self.workspace.station_path.read_bytes()
        with StationLease(self.root):
            with self.assertRaises(core.OperatorError) as raised:
                self.workspace.apply(preview["preview_id"])
        self.assertEqual(raised.exception.code, "active_work")
        self.assertEqual(self.workspace.station_path.read_bytes(), before)
        self.assertEqual(self.workspace.apply(preview["preview_id"])["result"], "saved")

    def test_failure_before_replace_preserves_station_and_no_receipt_is_claimed(self):
        preview = self.location()
        before = self.workspace.station_path.read_bytes()
        with patch.object(core.os, "replace", side_effect=OSError("synthetic private canary")):
            with self.assertRaises(core.OperatorError) as raised:
                self.workspace.apply(preview["preview_id"])
        self.assertEqual(raised.exception.exit_code, 4)
        self.assertEqual(self.workspace.station_path.read_bytes(), before)
        self.assertFalse((self.root / f"receipt-{preview['preview_id']}.json").exists())

    def test_receipt_failure_is_partial_after_real_save_and_retry_recovers(self):
        preview = self.location()
        write = core._write_new

        def fail_receipt(path, payload):
            if Path(path).name.startswith("receipt-"):
                raise core.OperatorError("controlled receipt failure", "io", 4)
            return write(path, payload)

        with patch.object(core, "_write_new", side_effect=fail_receipt):
            result = self.workspace.apply(preview["preview_id"])
        self.assertTrue(result["configuration_saved"])
        self.assertTrue(result["partial"])
        self.assertFalse(result["receipt_recorded"])
        self.assertEqual(self.workspace.inspect()["location"], preview["proposed"])
        saved = self.workspace.station_path.read_bytes()
        recovered = self.workspace.apply(preview["preview_id"])
        self.assertTrue(recovered["receipt_recorded"])
        self.assertEqual(saved, self.workspace.station_path.read_bytes())

    def test_component_profiles_custom_and_physical_case_constraints(self):
        self.assertEqual(len(self.workspace.catalog()["profiles"]), 2)
        for profile in ("full_msel", "guided_arrow"):
            preview = self.workspace.preview_components(profile)
            self.assertEqual(preview["proposed"]["configuration"]["preset"], profile)
            self.workspace.apply(preview["preview_id"])
        custom = self.workspace.preview_components("custom", {"rf.frontend": "omit"})
        self.assertIsNone(custom["proposed"]["configuration"]["preset"])
        self.workspace.apply(custom["preview_id"])
        outcomes = {item["component"]: item for item in self.workspace.inspect()["deployment_plan"]["outcomes"]}
        self.assertEqual(outcomes["rf.frontend"]["outcome"], "omitted")
        with self.assertRaises(core.OperatorError):
            self.workspace.preview_components("custom", ptu_model="QPT500")
        with self.assertRaises(core.OperatorError):
            self.workspace.preview_components("guided_arrow", {"pointing.ptu": "omit"})

    def test_saved_operation_without_receipt_cannot_be_cancelled_and_remains_recoverable(self):
        preview = self.location()
        write = core._write_new

        def fail_receipt(path, payload):
            if Path(path).name.startswith("receipt-"):
                raise core.OperatorError("controlled receipt failure", "io", 4)
            return write(path, payload)

        with patch.object(core, "_write_new", side_effect=fail_receipt):
            partial = self.workspace.apply(preview["preview_id"])
        self.assertTrue(partial["configuration_saved"])
        self.assertFalse(partial["receipt_recorded"])
        saved = self.workspace.station_path.read_bytes()
        with self.assertRaises(core.OperatorError) as raised:
            self.workspace.cancel(preview["preview_id"])
        self.assertEqual(raised.exception.code, "conflict")
        self.assertFalse((self.root / f"cancel-{preview['preview_id']}.json").exists())
        recovered = self.workspace.apply(preview["preview_id"])
        self.assertTrue(recovered["receipt_recorded"])
        self.assertEqual(self.workspace.station_path.read_bytes(), saved)

    def test_plan_binding_and_revalidation_follow_saved_revision(self):
        first = self.location()
        self.workspace.apply(first["preview_id"])
        revision, _ = self.workspace.snapshot()
        plan = self.workspace.record_plan({"station_revision": revision, "source": "synthetic_replay", "passes": []})
        self.assertFalse(self.workspace.inspect()["plans"][0]["revalidation_required"])
        second = self.location(longitude_deg=-70)
        self.assertEqual(second["affected_plans"][0]["plan_id"], plan["plan_id"])
        self.workspace.apply(second["preview_id"])
        self.assertTrue(self.workspace.inspect()["plans"][0]["revalidation_required"])
        with self.assertRaises(core.OperatorError):
            self.workspace.record_plan({"station_revision": revision})

    def test_partial_save_followed_by_another_save_cannot_be_reported_cancelled(self):
        first = self.location()
        write = core._write_new

        def fail_receipt(path, payload):
            if Path(path).name.startswith("receipt-"):
                raise core.OperatorError("controlled receipt failure", "io", 4)
            return write(path, payload)

        with patch.object(core, "_write_new", side_effect=fail_receipt):
            result = self.workspace.apply(first["preview_id"])
        self.assertTrue(result["configuration_saved"])
        self.assertFalse(result["receipt_recorded"])
        second = self.location(longitude_deg=-70)
        self.workspace.apply(second["preview_id"])
        saved = self.workspace.station_path.read_bytes()
        with self.assertRaises(core.OperatorError) as raised:
            self.workspace.cancel(first["preview_id"])
        self.assertEqual(raised.exception.code, "stale_revision")
        self.assertEqual(saved, self.workspace.station_path.read_bytes())
        self.assertFalse((self.root / f"cancel-{first['preview_id']}.json").exists())

    def test_replay_dimensions_are_independent_and_not_measured_coordinates(self):
        expected = {"unknown", "disconnected", "silent", "no_fix", "reported_3d", "stale", "mismatched", "incomplete", "critical"}
        self.assertEqual(set(core.REPLAY_STATES), expected)
        for state in sorted(expected):
            with self.subTest(state=state):
                result = self.workspace.replay(state)
                self.assertEqual(result["observations"]["provenance"], "synthetic_replay")
                self.assertFalse(result["observations"]["live_hardware_observed"])
                if state in ("reported_3d", "stale", "critical"):
                    self.assertEqual(result["measured_gps"]["provenance"], "synthetic_replay")
                    self.assertEqual(result["measured_gps"]["coordinates"]["latitude_deg"], 43.25)
                    self.assertEqual(result["measured_gps"]["coordinates"]["altitude_reference"], "unspecified")
                else:
                    self.assertIsNone(result["measured_gps"]["coordinates"])
                self.assertFalse(result["gps_selection"]["enabled"])
        status = self.workspace.replay("critical")["status"]
        self.assertEqual(status["transport_check"], "transport_pass")
        self.assertEqual(status["system_health"], "critical")
        self.assertEqual(status["heading"], "unqualified")

    def test_manual_and_synthetic_measured_coordinates_remain_separate(self):
        preview = self.location()
        self.workspace.apply(preview["preview_id"])
        result = self.workspace.replay("critical")
        self.assertEqual(result["effective_location"]["latitude_deg"], 42)
        self.assertEqual(result["manual_location"], result["effective_location"])
        self.assertEqual(result["measured_gps"]["coordinates"]["latitude_deg"], 43.25)
        self.assertFalse(result["measured_gps"]["valid_for_station_selection"])
        self.assertEqual(result["measured_gps"]["time_basis"], "synthetic_fixture_not_live_clock")
        self.assertFalse(result["owner_context_verified"])

    def test_report_export_is_private_exclusive_and_starts_no_live_checks(self):
        output = Path(self.temporary.name) / "operator-report.json"
        result = self.workspace.export_report(output)
        self.assertEqual(result["result"], "exported")
        report = json.loads(output.read_bytes())
        self.assertFalse(report["live_checks_started"])
        self.assertEqual(output.stat().st_mode & 0o777, 0o600)
        with self.assertRaises(core.OperatorError):
            self.workspace.export_report(output)

    def test_unsafe_unmanaged_and_mismatched_workspace_inputs_reject(self):
        link = Path(self.temporary.name) / "linked"
        link.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(core.OperatorError):
            core.Workspace(link).inspect()
        _, settings = self.workspace.snapshot()
        settings["satgs_operator_workspace"]["id"] = "not-an-id"
        self.workspace.station_path.write_text(json.dumps(settings))
        with self.assertRaises(core.OperatorError):
            self.workspace.inspect()

    def test_export_keeps_failed_and_unfinished_bench_records_without_unrelated_fields(self):
        attempt = "a" * 32
        base = dict(schema="satgs-bench-operation.v1", attempt_id=attempt, operation="status",
                    started_monotonic=12.5, wall_clock_quality="unconfirmed")
        (self.root / f"bench-{attempt}-started.json").write_text(json.dumps(base))
        unfinished = self.workspace.report()["bench_results"]
        self.assertEqual(len(unfinished), 1)
        self.assertFalse(unfinished[0]["result_present"])
        result = dict(base, category="deadline", submission="complete", partial=True,
                      cleanup_complete=True, amq_password="DO-NOT-EXPORT", station={"secret": "DO-NOT-EXPORT"},
                      exchanges=[{"sequence": 1, "request": "023100000000003103", "response": "0631",
                                  "submission": "complete", "category": "deadline", "secret": "DO-NOT-EXPORT"}])
        (self.root / f"bench-{attempt}-result.json").write_text(json.dumps(result))
        output = Path(self.temporary.name) / "bench-export.json"
        self.workspace.export_report(output)
        report = json.loads(output.read_bytes())
        self.assertEqual(len(report["bench_results"]), 2)
        failed = next(row for row in report["bench_results"] if row["record_kind"] == "result")
        self.assertEqual(failed["category"], "deadline")
        self.assertTrue(failed["partial"])
        self.assertEqual(failed["exchanges"][0]["response"], "0631")
        self.assertNotIn("DO-NOT-EXPORT", output.read_text())
        self.assertFalse(report["live_checks_started"])

    def test_export_rejects_bench_record_identity_mismatch(self):
        path = self.root / ("bench-" + "a" * 32 + "-result.json")
        path.write_text(json.dumps(dict(schema="satgs-bench-operation.v1", attempt_id="b" * 32)))
        with self.assertRaises(core.OperatorError):
            self.workspace.report()


if __name__ == "__main__":
    unittest.main()
