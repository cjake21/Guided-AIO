import copy
from dataclasses import FrozenInstanceError, asdict
from itertools import combinations
import json
import unittest
from unittest.mock import patch

from satgs.deployment import load_manifest
from satgs import deployment_plan as planning


class DeploymentPlanningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = load_manifest()
        cls.catalog = planning.build_catalog(cls.manifest)

    @staticmethod
    def configuration(component="serialptu", mode="install"):
        return {
            "schema_version": 1,
            "id": "custom-ptu",
            "revision": 1,
            "preset": None,
            "release_id": None,
            "target": {"id": "pi-1", "environment": "linux-arm64-python311"},
            "host_roles": [],
            "instances": [],
            "selections": [
                {
                    "component": component,
                    "mode": mode,
                    "provider": "repository",
                    "instance_ids": [],
                }
            ],
        }

    @staticmethod
    def inventory():
        return {
            "schema_version": 1,
            "id": "evidence-1",
            "target": {"id": "pi-1", "environment": "linux-arm64-python311"},
            "entries": [
                {
                    "component": "serialptu",
                    "provider": "repository",
                    "instance_ids": [],
                    "presence": "present",
                    "release_id": "r1",
                    "revision": "rev1",
                    "compatibility": "serial-v1",
                    "fresh": True,
                    "source": "inspection-1",
                    "runtime_state": "unknown",
                }
            ],
        }

    @staticmethod
    def requirements():
        return {
            "schema_version": 1,
            "release_id": "r1",
            "configuration_schema": 1,
            "environment": "linux-arm64-python311",
            "components": [
                {
                    "component": "serialptu",
                    "kind": "software",
                    "revision": "rev1",
                    "compatibility": "serial-v1",
                    "requires": [],
                    "source": "release-notes-r1",
                }
            ],
            "removed_components": [],
        }

    def plan(self, configuration=None, inventory=None, requirements=None):
        configuration = self.configuration() if configuration is None else configuration
        return planning.plan_configuration(
            planning.parse_configuration(configuration, self.catalog),
            self.catalog,
            inventory=(
                planning.parse_inventory(inventory, self.catalog)
                if inventory is not None else None
            ),
            requirements=(
                planning.parse_requirements(requirements, self.catalog)
                if requirements is not None else None
            ),
        )

    @staticmethod
    def outcomes(result):
        return {row["component"]: row for row in result.to_dict()["outcomes"]}

    @staticmethod
    def structure_nodes(value):
        if isinstance(value, dict):
            return 1 + sum(1 + DeploymentPlanningTests.structure_nodes(item) for item in value.values())
        if isinstance(value, list):
            return 1 + sum(DeploymentPlanningTests.structure_nodes(item) for item in value)
        return 1

    @staticmethod
    def sparse_requirements(count):
        components = [{
            "component": "serialptu" if index == 0 else f"optional-{index}",
            "kind": "software", "requires": [], "source": "release-r1",
        } for index in range(count)]
        components[0].update(revision="rev1", compatibility="compat1")
        return {
            "schema_version": 1, "release_id": "r1", "configuration_schema": 1,
            "environment": "linux-arm64-python311", "components": components,
        }

    def assert_preview_lifecycle(self, configuration, requirements, expected_components, inventory=None):
        records = [configuration, requirements] + ([inventory] if inventory is not None else [])
        before = [record.to_dict() for record in records]
        results = []
        for operation in (planning.plan_configuration, planning.compare_release):
            result = operation(configuration, self.catalog, requirements=requirements, inventory=inventory)
            data = result.to_dict()
            self.assertFalse(result.blocked)
            self.assertTrue(data["planning_only"])
            self.assertFalse(data["apply_supported"])
            self.assertFalse(data["complete"])
            self.assertEqual(set(self.outcomes(result)), expected_components)
            self.assertEqual(data["configuration"], before[0])
            self.assertEqual(data["candidate_release_id"], before[1]["release_id"])
            self.assertEqual(data["inventory_id"], inventory.to_dict()["id"] if inventory else None)
            repeated = operation(configuration, self.catalog, requirements=requirements, inventory=inventory)
            self.assertEqual(planning.render_json(result), planning.render_json(repeated))
            self.assertEqual(planning.render_human(result), planning.render_human(repeated))
            results.append(result)
        self.assertEqual([record.to_dict() for record in records], before)
        return results

    def test_catalog_preserves_public_canonical_profiles(self):
        expected = json.loads(json.dumps([asdict(profile) for profile in self.manifest.profiles]))
        self.assertEqual(self.catalog.to_dict()["profiles"], expected)

    def test_builtin_projection_keeps_canonical_identity(self):
        for profile in self.manifest.profiles:
            with self.subTest(profile=profile.id):
                configuration = planning.expand_preset(self.catalog, profile.id)
                result = planning.plan_configuration(configuration, self.catalog)
                data = result.to_dict()
                self.assertEqual(result.blocked, profile.id == "guided_arrow")
                self.assertEqual(data["configuration"]["preset"], profile.id)
                self.assertEqual(data["preset_definition"], json.loads(json.dumps(asdict(profile))))
                selected = self.outcomes(result)
                for package in profile.packages:
                    self.assertEqual(selected[package.id]["mode"], "install")
                for capability in profile.capabilities:
                    self.assertIn(capability.id, selected)

    def test_guided_arrow_preserves_roles_and_device_instances(self):
        profile = next(p for p in self.manifest.profiles if p.id == "guided_arrow")
        configuration = planning.expand_preset(self.catalog, profile.id)
        data = configuration.to_dict()
        self.assertCountEqual(data["host_roles"], profile.host_roles)
        self.assertEqual(
            {row["id"]: row["component"] for row in data["instances"]},
            {"ptu-1": "qpt130", "pixhawk-1": "pixhawk_dual_gps"},
        )
        selected = {row["component"]: row for row in data["selections"]}
        self.assertEqual(selected["pointing.ptu"]["instance_ids"], ["ptu-1"])
        self.assertEqual(selected["pointing.pixhawk"]["instance_ids"], ["pixhawk-1"])
        self.assertEqual(selected["pointing.dual_gps"]["instance_ids"], ["pixhawk-1"])

    def test_presets_cannot_be_weakened_by_explicit_omission(self):
        for component in ("pixhawk", "pointing.dual_gps", "pointing.qpt130"):
            with self.subTest(component=component):
                data = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
                next(row for row in data["selections"] if row["component"] == component)["mode"] = "omit"
                result = self.plan(data)
                self.assertTrue(result.blocked)

    def test_guided_arrow_additional_local_software_requires_custom(self):
        configuration = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
        configuration["selections"].append(self.configuration("dsi_instruments")["selections"][0])
        self.assertTrue(self.plan(configuration).blocked)

    def test_custom_hardware_requires_explicit_instance_identity(self):
        for component in ("pointing.qpt130", "pointing.dual_gps"):
            with self.subTest(component=component):
                configuration = self.configuration(component)
                configuration["selections"][0]["provider"] = "guided_arrow_hardware"
                self.assertTrue(self.plan(configuration).blocked)

    def test_custom_hardware_derives_control_software_with_same_instance(self):
        for component, instance_type, owner, package in (
            ("pointing.qpt130", "qpt130", "pointing.ptu", "sat_tracker"),
            ("pointing.dual_gps", "pixhawk_dual_gps", "pointing.pixhawk", "pixhawk"),
        ):
            with self.subTest(component=component):
                configuration = self.configuration(component)
                configuration["instances"] = [{
                    "id": "bench-device-7", "component": instance_type,
                    "provider": "guided_arrow_hardware",
                }]
                configuration["selections"][0].update(
                    provider="guided_arrow_hardware", instance_ids=["bench-device-7"],
                )
                result = self.plan(configuration)
                self.assertFalse(result.blocked)
                outcomes = self.outcomes(result)
                self.assertEqual(outcomes[owner]["instance_ids"], ["bench-device-7"])
                self.assertTrue(outcomes[owner]["derived"])
                self.assertIn(package, outcomes)
                self.assertIn("broker.activemq", outcomes)
                self.assertEqual(outcomes[component]["outcome"], "commissioning_required")

    def test_custom_hardware_owner_cannot_silently_use_another_instance(self):
        configuration = self.configuration("pointing.qpt130")
        configuration["instances"] = [
            {"id": identity, "component": "qpt130", "provider": "guided_arrow_hardware"}
            for identity in ("hardware-1", "controller-2")
        ]
        configuration["selections"][0].update(
            provider="guided_arrow_hardware", instance_ids=["hardware-1"],
        )
        configuration["selections"].append({
            "component": "pointing.ptu", "mode": "install", "provider": "satgs",
            "instance_ids": ["controller-2"],
        })
        result = self.plan(configuration)
        self.assertTrue(result.blocked)
        self.assertEqual(self.outcomes(result)["pointing.ptu"]["instance_ids"], ["controller-2"])

    def test_shared_selection_contract_preserves_canonical_and_custom_diagnostics(self):
        canonical = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
        next(item for item in canonical["selections"] if item["component"] == "pointing.dual_gps")["mode"] = "omit"
        custom = self.configuration("pointing.qpt130")
        custom["selections"][0]["provider"] = "guided_arrow_hardware"
        managed = copy.deepcopy(custom)
        managed["instances"] = [{"id": identity, "component": "qpt130", "provider": "guided_arrow_hardware"}
                                for identity in ("device-1", "device-2")]
        managed["selections"][0]["instance_ids"] = ["device-1"]
        managed["selections"].append({"component": "pointing.ptu", "provider": "satgs", "mode": "install",
                                      "instance_ids": ["device-2"]})
        for data, expected_code in ((canonical, "preset_requirement"), (custom, "hardware_identity"),
                                    (managed, "instance_conflict")):
            with self.subTest(expected_code=expected_code):
                configuration = planning.parse_configuration(data, self.catalog)
                before = configuration.to_dict()
                diagnostics = planning.validate_selection_contract(configuration, self.catalog)
                self.assertIn(expected_code, {item["code"] for item in diagnostics})
                result = planning.plan_configuration(configuration, self.catalog).to_dict()
                for diagnostic in diagnostics:
                    self.assertIn(diagnostic, result["diagnostics"])
                diagnostics[0]["message"] = "caller mutation"
                self.assertNotIn("caller mutation", [item["message"] for item in
                                                     planning.validate_selection_contract(configuration, self.catalog)])
                self.assertEqual(configuration.to_dict(), before)

    def test_shared_selection_contract_is_not_runtime_authorization_or_dependency_closure(self):
        configuration = planning.expand_preset(self.catalog, "guided_arrow")
        self.assertEqual(planning.validate_selection_contract(configuration, self.catalog), [])
        self.assertTrue(planning.plan_configuration(configuration, self.catalog).blocked)
        diagnostic = {"code": "contract-sentinel", "severity": "error", "component": None, "message": "test"}
        with patch.object(planning, "validate_selection_contract", return_value=[diagnostic]) as validator:
            result = planning.plan_configuration(configuration, self.catalog)
        validator.assert_called_once_with(configuration, self.catalog)
        self.assertIn(diagnostic, result.to_dict()["diagnostics"])

    def test_shared_managed_hardware_validation_applies_only_to_locally_selected_hardware(self):
        for mode in ("install", "reuse", "omit"):
            data = self.configuration("pointing.qpt130", mode)
            data["instances"] = [{"id": identity, "component": "qpt130", "provider": "guided_arrow_hardware"}
                                 for identity in ("device-1", "device-2")]
            data["selections"][0].update(provider="guided_arrow_hardware", instance_ids=["device-1"])
            data["selections"].append({"component": "pointing.ptu", "mode": "omit", "provider": "satgs",
                                       "instance_ids": ["device-2"]})
            with self.subTest(mode=mode):
                configuration = planning.parse_configuration(data, self.catalog)
                diagnostics = planning.validate_selection_contract(configuration, self.catalog)
                self.assertEqual(any(item["code"] == "instance_conflict" for item in diagnostics), mode != "omit")

    def test_managed_hardware_keeps_conflict_when_candidate_derives_owner_first(self):
        for hardware, instance_type, owner, package in (
            ("pointing.qpt130", "qpt130", "pointing.ptu", "sat_tracker"),
            ("pointing.dual_gps", "pixhawk_dual_gps", "pointing.pixhawk", "pixhawk"),
        ):
            data = self.configuration("ground_station")
            data["instances"] = [{"id": "device-1", "component": instance_type,
                                  "provider": "guided_arrow_hardware"}]
            data["selections"].append({"component": hardware, "mode": "install",
                                       "provider": "guided_arrow_hardware", "instance_ids": ["device-1"]})
            identities = {"ground_station", "meteor-api", "broker.activemq", hardware, owner, package}
            if package == "sat_tracker":
                identities.add("serialptu")
            kinds = {item["id"]: item["kind"] for item in self.catalog.to_dict()["components"]}
            requirements = self.requirements()
            requirements["components"] = [{"component": identity, "kind": kinds[identity],
                                            "revision": "rev1", "compatibility": "abi1",
                                            "requires": [owner] if identity == "ground_station" else [],
                                            "source": "release-r1"} for identity in sorted(identities)]
            before = copy.deepcopy(data)
            with self.subTest(hardware=hardware):
                configuration = planning.parse_configuration(data, self.catalog)
                self.assertEqual(planning.validate_selection_contract(configuration, self.catalog), [])
                result = self.plan(data, requirements=requirements)
                self.assertTrue(result.blocked)
                self.assertEqual(self.outcomes(result)[owner]["instance_ids"], [])
                self.assertTrue(self.outcomes(result)[owner]["derived"])
                self.assertEqual(self.outcomes(result)[hardware]["instance_ids"], ["device-1"])
                self.assertEqual([item for item in result.to_dict()["diagnostics"] if item["code"] == "instance_conflict"],
                                 [{"code": "instance_conflict", "severity": "error", "component": owner,
                                   "message": "Managed hardware and its selected control/observer capability refer to different instances."}])
                self.assertEqual(data, before)

    def test_preview_never_claims_apply_or_complete_installation(self):
        result = self.plan()
        data = result.to_dict()
        self.assertFalse(result.blocked)
        self.assertTrue(data["planning_only"])
        self.assertFalse(data["apply_supported"])
        self.assertFalse(data["complete"])
        self.assertTrue(data["diagnostics"])
        self.assertEqual(self.outcomes(result)["serialptu"]["outcome"], "proposed_install")

    def test_selected_component_derives_unspecified_prerequisites(self):
        configuration = self.configuration("sat_tracker")
        result = self.plan(configuration)
        self.assertFalse(result.blocked)
        outcomes = self.outcomes(result)
        for component in ("serialptu", "meteor-api", "ground_station"):
            with self.subTest(component=component):
                self.assertIn(component, outcomes)
                self.assertTrue(outcomes[component]["derived"])
                self.assertTrue(outcomes[component]["reasons"])
        self.assertEqual(len(result.to_dict()["configuration"]["selections"]), 1)

    def test_custom_capabilities_derive_local_owners_and_honor_explicit_omission(self):
        for capability, owners, broker_required in (
            ("rf.frontend", ("dsi_instruments",), True),
            ("power.pdu_hpa", ("cyberpowerpdu",), True),
            ("recording.signal_hound", ("signal_hound", "signal_hound_native_wrapper"), True),
            ("processing.msel_post_processing", ("msel_post_processing",), False),
        ):
            with self.subTest(capability=capability):
                configuration = self.configuration(capability)
                configuration["selections"][0]["provider"] = "satgs"
                result = self.plan(configuration)
                self.assertFalse(result.blocked)
                outcomes = self.outcomes(result)
                for owner in owners:
                    self.assertTrue(outcomes[owner]["derived"])
                    self.assertEqual(outcomes[owner]["outcome"], "proposed_install")
                    self.assertTrue(outcomes[owner]["reasons"])
                if broker_required:
                    self.assertTrue(outcomes["broker.activemq"]["derived"])
                for owner in owners:
                    with self.subTest(omitted_owner=owner):
                        omitted = copy.deepcopy(configuration)
                        omitted["selections"].append(self.configuration(owner, "omit")["selections"][0])
                        blocked = self.plan(omitted)
                        self.assertTrue(blocked.blocked)
                        self.assertEqual(self.outcomes(blocked)[owner]["mode"], "omit")
                        self.assertEqual(self.outcomes(blocked)[owner]["outcome"], "omitted")

    def test_explicit_omit_is_not_overridden_by_dependency_closure(self):
        configuration = self.configuration("sat_tracker")
        configuration["selections"].append(self.configuration(mode="omit")["selections"][0])
        result = self.plan(configuration)
        self.assertTrue(result.blocked)
        serial = self.outcomes(result)["serialptu"]
        self.assertEqual(serial["mode"], "omit")
        self.assertNotEqual(serial["outcome"], "proposed_install")

    def pass_runner_configuration(self):
        configuration = self.configuration("execution.pass_runner")
        configuration["selections"][0]["provider"] = "satgs"
        return configuration

    def test_pass_runner_explicit_unused_equipment_omissions_preserve_intent(self):
        equipment = ("dsi_instruments", "cyberpowerpdu", "signal_hound")
        for count in range(1, 4):
            for omitted in combinations(equipment, count):
                with self.subTest(omitted=omitted):
                    configuration = self.pass_runner_configuration()
                    configuration["instances"] = [{
                        "id": "bench-ptu", "component": "qpt130",
                        "provider": "guided_arrow_hardware",
                    }]
                    configuration["selections"].append({
                        "component": "pointing.qpt130", "mode": "install",
                        "provider": "guided_arrow_hardware", "instance_ids": ["bench-ptu"],
                    })
                    configuration["selections"].extend(
                        self.configuration(component, "omit")["selections"][0]
                        for component in omitted
                    )
                    before = copy.deepcopy(configuration)
                    result = self.plan(configuration)
                    self.assertFalse(result.blocked)
                    self.assertEqual(configuration, before)
                    self.assertEqual(result.to_dict()["configuration"],
                                     planning.parse_configuration(before, self.catalog).to_dict())
                    outcomes = self.outcomes(result)
                    self.assertEqual(outcomes["pointing.qpt130"]["instance_ids"], ["bench-ptu"])
                    human = planning.render_human(result)
                    self.assertEqual(json.loads(planning.render_json(result)), result.to_dict())
                    for component in omitted:
                        self.assertEqual(outcomes[component]["mode"], "omit")
                        self.assertEqual(outcomes[component]["outcome"], "omitted")
                        self.assertFalse(outcomes[component]["derived"])
                        self.assertEqual(outcomes[component]["reasons"], [])
                        self.assertFalse(any(
                            item["code"] == "prerequisite_conflict" and item["component"] == component
                            for item in result.to_dict()["diagnostics"]
                        ))
                        self.assertIn(f"{component}: omitted", human)
                        self.assertNotIn("required by execution.pass_runner: source-import", human)

    def test_pass_runner_alone_does_not_derive_unused_equipment(self):
        configuration = self.pass_runner_configuration()
        result = self.plan(configuration)
        self.assertFalse(result.blocked)
        outcomes = self.outcomes(result)
        self.assertEqual(set(outcomes), {
            "execution.pass_runner", "ground_station", "meteor-api",
        })
        self.assertEqual(result.to_dict()["configuration"], configuration)

    def test_required_frontend_import_reasons_keep_shared_and_transitive_requirements(self):
        configuration = self.pass_runner_configuration()
        configuration["selections"].append({
            "component": "rf.frontend", "mode": "install", "provider": "satgs",
            "instance_ids": [],
        })
        result = self.plan(configuration)
        self.assertFalse(result.blocked)
        outcomes = self.outcomes(result)
        self.assertEqual({reason["required_by"] for reason in outcomes["dsi_instruments"]["reasons"]},
                         {"rf.frontend"})
        self.assertEqual({reason["relationship"] for reason in outcomes["dsi_instruments"]["reasons"]},
                         {"service-program", "source-import"})
        self.assertEqual({reason["required_by"] for reason in outcomes["meteor-api"]["reasons"]},
                         {"ground_station", "dsi_instruments"})
        self.assertEqual(len(outcomes["meteor-api"]["reasons"]), 2)
        reordered = copy.deepcopy(configuration)
        reordered["selections"].reverse()
        self.assertEqual(planning.render_json(result), planning.render_json(self.plan(reordered)))

    def test_candidate_does_not_restore_unused_pass_runner_equipment_requirements(self):
        configuration = self.pass_runner_configuration()
        configuration["selections"].extend(
            self.configuration(component, "omit")["selections"][0]
            for component in ("dsi_instruments", "cyberpowerpdu", "signal_hound")
        )
        requirements = self.requirements()
        requirements["components"] = [{
            "component": component, "kind": kind, "revision": "rev1",
            "compatibility": "abi1", "requires": [], "source": "release-r1",
        } for component, kind in (("execution.pass_runner", "capability"),
                                  ("ground_station", "software"), ("meteor-api", "software"))]
        result = self.plan(configuration, requirements=requirements)
        self.assertFalse(result.blocked)
        conflicts = {item["component"] for item in result.to_dict()["diagnostics"]
                     if item["code"] == "prerequisite_conflict"}
        self.assertEqual(conflicts, set())
        for component in ("dsi_instruments", "cyberpowerpdu", "signal_hound"):
            self.assertEqual(self.outcomes(result)[component]["reasons"], [])

    def test_guided_arrow_still_blocks_queue_recording_and_processing_without_changing_preset(self):
        configuration = planning.expand_preset(self.catalog, "guided_arrow")
        before = configuration.to_dict()
        result = planning.plan_configuration(configuration, self.catalog)
        self.assertTrue(result.blocked)
        self.assertEqual(configuration.to_dict(), before)
        self.assertEqual(result.to_dict()["configuration"], before)
        self.assertEqual(result.to_dict()["configuration"]["instances"], before["instances"])
        excluded = {"dsi_instruments", "cyberpowerpdu", "signal_hound"}
        self.assertFalse(excluded & self.outcomes(result).keys())
        required = {"recording.signal_hound", "processing.msel_post_processing"}
        self.assertEqual({row["component"] for row in result.to_dict()["diagnostics"]
                          if row["code"] == "preset_prerequisite"}, required)
        self.assertEqual({row["component"] for row in result.to_dict()["diagnostics"]
                          if row["code"] == "prerequisite_conflict"}, required)
        requirements = {row["component"]: row["reasons"] for row in result.to_dict()["derived_requirements"]}
        for component in required:
            self.assertEqual(requirements[component][0]["required_by"], "orchestration.queue_manager")
            self.assertEqual(requirements[component][0]["relationship"], "required-operation")
            self.assertIn(f"{component}: external_responsibility", planning.render_human(result))
            self.assertIn("required by orchestration.queue_manager: required-operation", planning.render_human(result))
        for component in ("rf.frontend", "power.pdu_hpa", "recording.signal_hound"):
            self.assertEqual(self.outcomes(result)[component]["mode"], "external")
            self.assertEqual(self.outcomes(result)[component]["provider"], "sponsor")

    def test_candidate_cannot_erase_required_equipment_source_service_or_native_edges(self):
        for capability, component, method in (
            ("rf.frontend", "dsi_instruments", "_initialize_frontend"),
            ("power.pdu_hpa", "cyberpowerpdu", "_initialize_pdu"),
            ("recording.signal_hound", "signal_hound", "_initialize_iq_recorder"),
        ):
            configuration = self.pass_runner_configuration()
            configuration["selections"].extend([
                {"component": capability, "mode": "install", "provider": "satgs"},
                self.configuration(component, "omit")["selections"][0],
            ])
            requirements = self.requirements()
            requirements["components"] = [{"component": capability, "kind": "capability",
                                            "revision": "rev1", "compatibility": "abi1",
                                            "requires": [], "source": "release-r1"}]
            with self.subTest(capability=capability):
                result = self.plan(configuration, requirements=requirements)
                self.assertTrue(result.blocked)
                self.assertTrue(any(item["code"] == "prerequisite_conflict" and item["component"] == component
                                    for item in result.to_dict()["diagnostics"]))
                reasons = self.outcomes(result)[component]["reasons"]
                self.assertIn({"required_by": capability, "relationship": "source-import",
                               "source": f"ground_station/src/satgs/pass_runner.py:PassRunner.{method}"}, reasons)
                self.assertTrue(any(reason["relationship"] == "service-program" for reason in reasons))
                if capability == "recording.signal_hound":
                    self.assertIn({"required_by": capability, "relationship": "source-import",
                                   "source": "ground_station/src/satgs/pass_runner.py:PassRunner._initialize_trace_logger"}, reasons)
                    self.assertIn("signal_hound_native_wrapper", self.outcomes(result))

    def test_selected_queue_cannot_omit_or_externalize_forced_recording_and_processing(self):
        sources = {"recording.signal_hound": "ground_station/src/satgs/queue_manager.py:739-740",
                   "processing.msel_post_processing": "ground_station/src/satgs/queue_manager.py:773-779"}
        for mode, provider in (("omit", "satgs"), ("external", "sponsor")):
            configuration = self.configuration("orchestration.queue_manager")
            configuration["selections"][0]["provider"] = "satgs"
            configuration["selections"].extend({"component": component, "mode": mode, "provider": provider}
                                                for component in sources)
            with self.subTest(mode=mode):
                result = self.plan(configuration)
                self.assertTrue(result.blocked)
                self.assertEqual({item["component"] for item in result.to_dict()["diagnostics"]
                                  if item["code"] == "prerequisite_conflict"}, set(sources))
                for component, source in sources.items():
                    outcome = self.outcomes(result)[component]
                    self.assertEqual(outcome["mode"], mode)
                    self.assertIn({"required_by": "orchestration.queue_manager", "relationship": "required-operation",
                                   "source": source}, outcome["reasons"])

    def test_runtime_warning_retains_cycles_and_qualification_without_false_unconditional_imports(self):
        result = self.plan()
        diagnostics = result.to_dict()["diagnostics"]
        warning = next(item for item in diagnostics if item["code"] == "runtime_cycles")
        self.assertEqual(warning["severity"], "warning")
        self.assertIn("ground_station <-> sat_tracker", warning["message"])
        self.assertIn("ground_station <-> pixhawk", warning["message"])
        self.assertIn("owner contracts and target runtime integration remain unverified", warning["message"])
        self.assertNotIn("unconditionally", warning["message"])
        self.assertIn("closure_incomplete", {item["code"] for item in diagnostics})
        self.assertIn("commissioning_required", {item["code"] for item in diagnostics})
        self.assertFalse(result.to_dict()["apply_supported"])

    def test_unselected_pass_runner_does_not_block_unrelated_bench_preview(self):
        for component in ("serialptu", "ground_station", "sat_tracker"):
            with self.subTest(component=component):
                configuration = self.configuration(component)
                omitted_runner = self.pass_runner_configuration()["selections"][0]
                omitted_runner["mode"] = "omit"
                configuration["selections"].append(omitted_runner)
                result = self.plan(configuration)
                self.assertFalse(result.blocked)
                self.assertFalse(result.to_dict()["complete"])
                self.assertFalse({"dsi_instruments", "cyberpowerpdu", "signal_hound"} & self.outcomes(result).keys())

    def test_omitted_existing_software_is_never_removed_or_installed(self):
        result = self.plan(self.configuration(mode="omit"), self.inventory())
        outcome = self.outcomes(result)["serialptu"]
        self.assertEqual(outcome["outcome"], "omitted")
        self.assertEqual(outcome["mode"], "omit")

    def test_missing_inventory_remains_unknown(self):
        outcome = self.outcomes(self.plan())["serialptu"]
        self.assertEqual(outcome["presence"], "unknown")
        self.assertNotEqual(outcome["outcome"], "proposed_reuse")

    def test_empty_inventory_does_not_prove_absence(self):
        inventory = self.inventory()
        inventory["entries"] = []
        result = self.plan(inventory=inventory)
        self.assertEqual(self.outcomes(result)["serialptu"]["presence"], "unknown")
        self.assertEqual(result.to_dict()["inventory_id"], "evidence-1")

    def test_unselected_existing_software_has_no_proposed_outcome(self):
        result = self.plan(self.configuration("meteor-api"), self.inventory())
        self.assertNotIn("serialptu", self.outcomes(result))
        self.assertEqual(set(self.outcomes(result)), {"meteor-api"})

    def test_reuse_requires_sufficient_matching_evidence(self):
        result = self.plan(self.configuration(mode="reuse"), self.inventory(), self.requirements())
        self.assertFalse(result.blocked)
        self.assertEqual(self.outcomes(result)["serialptu"]["outcome"], "proposed_reuse")
        self.assertFalse(result.to_dict()["complete"])

    def test_reuse_without_inventory_or_release_requirements_blocks(self):
        for inventory, requirements in ((None, None), (self.inventory(), None), (None, self.requirements())):
            with self.subTest(inventory=inventory is not None, requirements=requirements is not None):
                result = self.plan(self.configuration(mode="reuse"), inventory, requirements)
                self.assertTrue(result.blocked)
                self.assertEqual(self.outcomes(result)["serialptu"]["outcome"], "conflict")

    def test_reuse_rejects_stale_absent_unknown_and_incompatible_evidence(self):
        cases = (
            ("fresh", False),
            ("presence", "absent"),
            ("presence", "unknown"),
            ("release_id", "r0"),
            ("revision", "other-revision"),
            ("compatibility", "other-contract"),
            ("source", None),
            ("instance_ids", ["other-instance"]),
        )
        for field, value in cases:
            with self.subTest(field=field, value=value):
                inventory = self.inventory()
                inventory["entries"][0][field] = value
                result = self.plan(self.configuration(mode="reuse"), inventory, self.requirements())
                self.assertTrue(result.blocked)
                self.assertEqual(self.outcomes(result)["serialptu"]["outcome"], "conflict")

    def test_reuse_rejects_other_target_or_environment(self):
        for field, value in (("id", "other-pi"), ("environment", "other-environment")):
            with self.subTest(field=field):
                inventory = self.inventory()
                inventory["target"][field] = value
                self.assertTrue(self.plan(self.configuration(mode="reuse"), inventory, self.requirements()).blocked)

    def test_runtime_observation_does_not_rewrite_selection(self):
        configuration = self.configuration(mode="reuse")
        inventory = self.inventory()
        inventory["entries"][0]["runtime_state"] = "disconnected"
        result = self.plan(configuration, inventory, self.requirements())
        self.assertEqual(result.to_dict()["configuration"]["selections"], configuration["selections"])
        self.assertEqual(self.outcomes(result)["serialptu"]["mode"], "reuse")

    def test_disconnected_guided_arrow_hardware_stays_selected(self):
        configuration = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
        inventory = self.inventory()
        configuration["target"] = copy.deepcopy(inventory["target"])
        inventory["entries"][0].update(
            component="pointing.qpt130", provider="guided_arrow_hardware",
            instance_ids=["ptu-1"], runtime_state="disconnected",
        )
        result = self.plan(configuration, inventory)
        outcome = self.outcomes(result)["pointing.qpt130"]
        self.assertEqual(outcome["mode"], "install")
        self.assertEqual(outcome["instance_ids"], ["ptu-1"])
        self.assertEqual(outcome["runtime_state"], "disconnected")
        self.assertEqual(outcome["outcome"], "commissioning_required")
        self.assertEqual(result.to_dict()["configuration"]["instances"], configuration["instances"])

    def test_explicit_install_does_not_overwrite_incompatible_existing_software(self):
        inventory = self.inventory()
        inventory["entries"][0]["revision"] = "incompatible-revision"
        result = self.plan(inventory=inventory, requirements=self.requirements())
        self.assertTrue(result.blocked)
        self.assertEqual(self.outcomes(result)["serialptu"]["outcome"], "conflict")

    def test_records_defensively_copy_inputs_and_serialized_outputs(self):
        for parser, original in (
            (planning.parse_configuration, self.configuration()),
            (planning.parse_inventory, self.inventory()),
            (planning.parse_requirements, self.requirements()),
        ):
            with self.subTest(parser=parser.__name__):
                supplied = copy.deepcopy(original)
                record = parser(supplied, self.catalog)
                expected = record.to_dict()
                supplied.clear()
                serialized = record.to_dict()
                serialized.clear()
                self.assertEqual(record.to_dict(), expected)
                with self.assertRaises(FrozenInstanceError):
                    record._json = "{}"
        output = self.plan()
        expected = output.to_dict()
        output.to_dict()["outcomes"].clear()
        self.assertEqual(output.to_dict(), expected)
        catalog = self.catalog.to_dict()
        catalog["profiles"].clear()
        self.assertEqual(len(self.catalog.to_dict()["profiles"]), 2)

    def test_planning_does_not_modify_caller_inputs(self):
        configuration, inventory, requirements = self.configuration(), self.inventory(), self.requirements()
        before = copy.deepcopy((configuration, inventory, requirements))
        self.plan(configuration, inventory, requirements)
        self.assertEqual((configuration, inventory, requirements), before)

    def test_order_variations_and_repeated_calls_produce_same_json(self):
        configuration = self.configuration("sat_tracker")
        configuration["selections"].append(self.configuration()["selections"][0])
        reversed_configuration = copy.deepcopy(configuration)
        reversed_configuration["selections"].reverse()
        expected = planning.render_json(self.plan(configuration))
        self.assertEqual(expected, planning.render_json(self.plan(configuration)))
        self.assertEqual(expected, planning.render_json(self.plan(reversed_configuration)))
        self.assertEqual(json.loads(expected), self.plan(configuration).to_dict())

    def test_invalid_configurations_are_rejected(self):
        cases = []
        for field, value in (("schema_version", True), ("schema_version", 2), ("revision", True), ("revision", 0), ("selections", {})):
            data = self.configuration()
            data[field] = value
            cases.append((field, value, data))
        data = self.configuration()
        data["unrecognized"] = True
        cases.append(("unknown-field", None, data))
        for field, value, data in cases:
            with self.subTest(field=field, value=value):
                with self.assertRaises(planning.InputError):
                    planning.parse_configuration(data, self.catalog)

    def test_document_structure_and_text_are_bounded(self):
        oversized_list = self.configuration()
        oversized_list["selections"] = [None] * 1025
        oversized_object = self.configuration()
        oversized_object.update({f"extra-{index}": None for index in range(65)})
        oversized_key = self.configuration()
        oversized_key["x" * 81] = None
        oversized_text = self.configuration()
        oversized_text["id"] = "x" * 257
        deep = self.configuration()
        nested = None
        for _ in range(34):
            nested = [nested]
        deep["selections"] = nested
        too_many_nodes = self.configuration()
        too_many_nodes["selections"] = [[None] * 1024 for _ in range(9)]
        for label, data in (
            ("list", oversized_list), ("object", oversized_object),
            ("key", oversized_key), ("text", oversized_text),
            ("depth", deep), ("nodes", too_many_nodes),
        ):
            with self.subTest(label=label):
                with self.assertRaisesRegex(planning.InputError, "limit|exceed|256"):
                    planning.parse_configuration(data, self.catalog)

    def test_non_json_values_and_control_text_are_rejected(self):
        for value in (float("nan"), float("inf"), object(), b"bytes", "forged\nmessage", "escape\x1b[31m"):
            with self.subTest(value_type=type(value).__name__):
                data = self.configuration()
                data["id"] = value
                with self.assertRaises(planning.InputError) as error:
                    planning.parse_configuration(data, self.catalog)
                self.assertNotIn("\x1b", str(error.exception))
                self.assertNotIn("forged\nmessage", str(error.exception))

    def test_shared_structure_counts_keys_at_8192_node_boundary(self):
        data = [[0] * 1023 for _ in range(7)] + [[0] * 1019 + [{"key": 0}]]
        before = copy.deepcopy(data)
        planning.validate_document_structure(data)
        self.assertEqual(data, before)
        data[-1].append(0)
        before = copy.deepcopy(data)
        with self.assertRaisesRegex(planning.InputError, "nodes 8192"):
            planning.validate_document_structure(data)
        self.assertEqual(data, before)

    def test_shared_structure_has_consistent_container_depth(self):
        for leaf in (0, [], {}):
            for containers in (32, 33):
                with self.subTest(leaf=leaf, containers=containers):
                    data = leaf
                    for _ in range(containers - int(isinstance(leaf, (dict, list)))):
                        data = [data]
                    before = copy.deepcopy(data)
                    if containers == 32:
                        planning.validate_document_structure(data)
                    else:
                        with self.assertRaisesRegex(planning.InputError, "depth 32"):
                            planning.validate_document_structure(data)
                    self.assertEqual(data, before)

    def test_shared_structure_retains_collection_field_key_and_text_limits(self):
        for accepted, rejected in (
            ([None] * 1024, [None] * 1025),
            ({str(index): None for index in range(64)}, {str(index): None for index in range(65)}),
            ({"k" * 80: None}, {"k" * 81: None}),
            ("v" * 256, "v" * 257),
        ):
            with self.subTest(kind=type(accepted).__name__):
                before = copy.deepcopy(accepted)
                planning.validate_document_structure(accepted)
                self.assertEqual(accepted, before)
                with self.assertRaises(planning.InputError):
                    planning.validate_document_structure(rejected)

    def test_reviewed_requirements_629_records_pass_630_exceed_shared_node_limit(self):
        for count in (629, 630):
            with self.subTest(count=count):
                data = {
                    "schema_version": 1, "release_id": "r1", "configuration_schema": 1,
                    "environment": "linux-arm64-python311", "components": [{
                        "component": "serialptu" if index == 0 else f"optional-{index}",
                        "kind": "software", "revision": "rev1", "compatibility": "compat1",
                        "requires": [], "source": "release-r1",
                    } for index in range(count)],
                }
                before = copy.deepcopy(data)
                if count == 629:
                    parsed = planning.parse_requirements(data, self.catalog)
                    self.assertEqual(len(parsed.to_dict()["components"]), count)
                else:
                    with self.assertRaisesRegex(planning.InputError, "nodes 8192"):
                        planning.parse_requirements(data, self.catalog)
                self.assertEqual(data, before)

    def test_sparse_requirements_records_remain_usable_after_default_expansion(self):
        for count, raw_nodes, normalized_nodes in ((629, 5676, 8190), (630, 5685, 8203)):
            with self.subTest(count=count):
                data = self.sparse_requirements(count)
                configuration_data = self.configuration()
                inventory_data = self.inventory()
                inventory_data["entries"][0]["presence"] = "unknown"
                before = copy.deepcopy((data, configuration_data, inventory_data))
                self.assertEqual(self.structure_nodes(data), raw_nodes)
                requirements = planning.parse_requirements(data, self.catalog)
                normalized = requirements.to_dict()
                self.assertEqual(self.structure_nodes(normalized), normalized_nodes)
                configuration = planning.parse_configuration(configuration_data, self.catalog)
                inventory = planning.parse_inventory(inventory_data, self.catalog)
                _, comparison = self.assert_preview_lifecycle(
                    configuration, requirements, {"serialptu"}, inventory,
                )
                self.assertEqual(comparison.to_dict()["unselected_optional"],
                                 sorted(f"optional-{index}" for index in range(1, count)))
                if count == 630:
                    with self.assertRaisesRegex(planning.InputError, "nodes 8192"):
                        planning.parse_requirements(normalized, self.catalog)
                else:
                    self.assertEqual(planning.parse_requirements(normalized, self.catalog), requirements)
                normalized["components"][0]["source"] = "changed-copy"
                self.assertNotEqual(normalized, requirements.to_dict())
                self.assertEqual((data, configuration_data, inventory_data), before)

    def test_sparse_requirements_optional_fields_keep_external_accounting(self):
        fields = ((), ("revision",), ("compatibility",), ("revision", "compatibility"))
        for supplied in fields:
            for removed in (None, [], ["pixhawk"]):
                with self.subTest(supplied=supplied, removed=removed):
                    data = self.sparse_requirements(630)
                    for item in data["components"][1:]:
                        for field in supplied:
                            item[field] = "rev1" if field == "revision" else "compat1"
                    if removed is not None:
                        data["removed_components"] = removed
                    before = copy.deepcopy(data)
                    if len(supplied) == 2:
                        self.assertGreater(self.structure_nodes(data), 8192)
                        with self.assertRaisesRegex(planning.InputError, "nodes 8192"):
                            planning.parse_requirements(data, self.catalog)
                    else:
                        self.assertLessEqual(self.structure_nodes(data), 8192)
                        requirements = planning.parse_requirements(data, self.catalog)
                        configuration = planning.parse_configuration(self.configuration(), self.catalog)
                        _, comparison = self.assert_preview_lifecycle(configuration, requirements, {"serialptu"})
                        self.assertEqual(len(comparison.to_dict()["unselected_optional"]), 629)
                        self.assertEqual(requirements.to_dict()["removed_components"], removed or [])
                        with self.assertRaisesRegex(planning.InputError, "nodes 8192"):
                            planning.parse_requirements(requirements.to_dict(), self.catalog)
                    self.assertEqual(data, before)

    def test_configuration_record_default_growth_preserves_stable_instances(self):
        instance_ids = [f"bench-ptu-{index}" for index in range(1019)]
        data = {
            "schema_version": 1, "id": "many-ptu", "revision": 1,
            "target": self.configuration()["target"],
            "instances": [{"id": identity, "component": "qpt130", "provider": "guided_arrow_hardware"}
                          for identity in instance_ids],
            "selections": [
                {"component": "pointing.qpt130", "mode": "install", "provider": "guided_arrow_hardware",
                 "instance_ids": instance_ids},
                {"component": "serialptu", "mode": "install", "provider": "repository"},
            ],
        }
        before = copy.deepcopy(data)
        self.assertEqual(self.structure_nodes(data), 8185)
        configuration = planning.parse_configuration(data, self.catalog)
        self.assertEqual(self.structure_nodes(configuration.to_dict()), 8193)
        self.assertEqual(planning.validate_selection_contract(configuration, self.catalog), [])
        expected = {"serialptu", "pointing.qpt130", "pointing.ptu", "sat_tracker",
                    "ground_station", "meteor-api", "broker.activemq"}
        kinds = {item["id"]: item["kind"] for item in self.catalog.to_dict()["components"]}
        requirements_data = self.requirements()
        requirements_data["components"] = [{
            "component": identity, "kind": kinds[identity], "requires": [], "source": "release-r1",
            "revision": "rev1", "compatibility": "compat1",
        } for identity in sorted(expected)]
        requirements = planning.parse_requirements(requirements_data, self.catalog)
        results = self.assert_preview_lifecycle(configuration, requirements, expected)
        for result in results:
            for identity in ("pointing.qpt130", "pointing.ptu"):
                self.assertEqual(self.outcomes(result)[identity]["instance_ids"], sorted(instance_ids))
        with self.assertRaisesRegex(planning.InputError, "nodes 8192"):
            planning.parse_configuration(configuration.to_dict(), self.catalog)
        self.assertEqual(data, before)

    def test_inventory_record_default_growth_remains_usable(self):
        components = ("serialptu", "ground_station", "pixhawk", "sat_tracker", "meteor-api",
                      "cyberpowerpdu", "dsi_instruments", "signal_hound")
        data = {
            "schema_version": 1, "id": "large-inventory", "target": self.configuration()["target"],
            "entries": [{
                "component": identity, "provider": "repository", "presence": "unknown",
                "instance_ids": [f"reported-{index}" for index in range(1002)],
            } for identity in components],
        }
        before = copy.deepcopy(data)
        self.assertEqual(self.structure_nodes(data), 8101)
        inventory = planning.parse_inventory(data, self.catalog)
        self.assertEqual(self.structure_nodes(inventory.to_dict()), 8197)
        configuration = planning.parse_configuration(self.configuration(), self.catalog)
        requirements = planning.parse_requirements(self.requirements(), self.catalog)
        results = self.assert_preview_lifecycle(configuration, requirements, {"serialptu"}, inventory)
        for result in results:
            self.assertEqual(self.outcomes(result)["serialptu"]["presence"], "unknown")
            self.assertEqual(self.outcomes(result)["serialptu"]["outcome"], "proposed_install")
        with self.assertRaisesRegex(planning.InputError, "nodes 8192"):
            planning.parse_inventory(inventory.to_dict(), self.catalog)
        self.assertEqual(data, before)

    def test_parsed_records_keep_catalog_semantic_revalidation(self):
        configuration = planning.parse_configuration(self.configuration(), self.catalog)
        core_configuration = planning.parse_configuration(self.configuration("ground_station"), self.catalog)
        inventory = planning.parse_inventory(self.inventory(), self.catalog)
        requirements = planning.parse_requirements(self.requirements(), self.catalog)
        components = {item["id"]: item for item in self.catalog.to_dict()["components"]}
        missing_component = {key: item for key, item in components.items() if key != "serialptu"}
        changed_kind = copy.deepcopy(components)
        changed_kind["serialptu"]["kind"] = "hardware"
        for operation in (planning.plan_configuration, planning.compare_release):
            with self.subTest(operation=operation.__name__, record="configuration"):
                with patch.object(planning, "_components", return_value=missing_component):
                    with self.assertRaisesRegex(planning.InputError, "unknown catalog component"):
                        operation(configuration, self.catalog, requirements=requirements)
            with self.subTest(operation=operation.__name__, record="inventory"):
                with patch.object(planning, "_components", return_value=missing_component):
                    with self.assertRaisesRegex(planning.InputError, "inventory component/provider"):
                        operation(core_configuration, self.catalog, requirements=requirements, inventory=inventory)
            with self.subTest(operation=operation.__name__, record="requirements"):
                with patch.object(planning, "_components", return_value=changed_kind):
                    with self.assertRaisesRegex(planning.InputError, "kind conflicts"):
                        operation(configuration, self.catalog, requirements=requirements)

    def test_sparse_requirements_still_reject_invalid_semantics_and_block_conflicts(self):
        for field, value in (("component", "invalid identity"), ("kind", "unsupported"),
                             ("requires", ["unknown-component"])):
            with self.subTest(field=field):
                data = self.sparse_requirements(630)
                data["components"][-1][field] = value
                with self.assertRaises(planning.InputError):
                    planning.parse_requirements(data, self.catalog)
        for missing in ("revision", "compatibility"):
            with self.subTest(missing=missing):
                data = self.sparse_requirements(630)
                del data["components"][0][missing]
                requirements = planning.parse_requirements(data, self.catalog)
                configuration = planning.parse_configuration(self.configuration(), self.catalog)
                for operation in (planning.plan_configuration, planning.compare_release):
                    result = operation(configuration, self.catalog, requirements=requirements)
                    self.assertTrue(result.blocked)
                    self.assertTrue(any(item["code"] == "compatibility_unknown" and item["component"] == "serialptu"
                                        for item in result.to_dict()["diagnostics"]))
        requirements_data = self.sparse_requirements(630)
        requirements_data["components"][0]["requires"] = ["meteor-api"]
        requirements = planning.parse_requirements(requirements_data, self.catalog)
        configuration_data = self.configuration()
        configuration_data["selections"].append(self.configuration("meteor-api", "omit")["selections"][0])
        configuration = planning.parse_configuration(configuration_data, self.catalog)
        for operation in (planning.plan_configuration, planning.compare_release):
            result = operation(configuration, self.catalog, requirements=requirements)
            self.assertTrue(result.blocked)
            self.assertTrue(any(item["code"] == "prerequisite_conflict" and item["component"] == "meteor-api"
                                for item in result.to_dict()["diagnostics"]))
        requirements_data = self.sparse_requirements(630)
        requirements_data["environment"] = "other-target"
        requirements = planning.parse_requirements(requirements_data, self.catalog)
        configuration = planning.parse_configuration(self.configuration(), self.catalog)
        for operation in (planning.plan_configuration, planning.compare_release):
            result = operation(configuration, self.catalog, requirements=requirements)
            self.assertTrue(result.blocked)
            self.assertTrue(any(item["code"] == "environment_mismatch" for item in result.to_dict()["diagnostics"]))

    def test_cyclic_caller_owned_input_is_rejected_without_recursion(self):
        data = self.configuration()
        data["selections"].append(data)
        with self.assertRaisesRegex(planning.InputError, "structure limits"):
            planning.parse_configuration(data, self.catalog)

    def test_unknown_duplicate_and_unsupported_selections_are_rejected(self):
        cases = []
        for field, value in (("component", "unknown-component"), ("mode", "activate"), ("mode", "external"), ("provider", "unapproved-provider")):
            data = self.configuration()
            data["selections"][0][field] = value
            cases.append((field, data))
        duplicate = self.configuration()
        duplicate["selections"].append(copy.deepcopy(duplicate["selections"][0]))
        cases.append(("duplicate", duplicate))
        for label, data in cases:
            with self.subTest(label=label):
                with self.assertRaises(planning.InputError):
                    planning.parse_configuration(data, self.catalog)

    def test_unresolved_and_duplicate_instance_ids_are_rejected(self):
        data = self.configuration()
        data["selections"][0]["instance_ids"] = ["missing-instance"]
        with self.assertRaises(planning.InputError):
            planning.parse_configuration(data, self.catalog)
        guided = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
        guided["instances"].append(copy.deepcopy(guided["instances"][0]))
        with self.assertRaises(planning.InputError):
            planning.parse_configuration(guided, self.catalog)

    def test_inventory_duplicate_and_unknown_components_are_rejected(self):
        for duplicate in (False, True):
            with self.subTest(duplicate=duplicate):
                data = self.inventory()
                if duplicate:
                    data["entries"].append(copy.deepcopy(data["entries"][0]))
                else:
                    data["entries"][0]["component"] = "unknown-component"
                with self.assertRaises(planning.InputError):
                    planning.parse_inventory(data, self.catalog)

    def test_inventory_and_requirements_reject_unknown_schema_and_fields(self):
        for parser, factory in ((planning.parse_inventory, self.inventory), (planning.parse_requirements, self.requirements)):
            for field, value in (("schema_version", 2), ("schema_version", True), ("unknown-field", True)):
                with self.subTest(parser=parser.__name__, field=field, value=value):
                    data = factory()
                    data[field] = value
                    with self.assertRaises(planning.InputError):
                        parser(data, self.catalog)

    def test_candidate_environment_and_schema_incompatibility_block(self):
        for field, value in (("environment", "other-target"), ("configuration_schema", 2)):
            with self.subTest(field=field):
                data = self.requirements()
                data[field] = value
                self.assertTrue(self.plan(requirements=data).blocked)
                reuse = self.plan(self.configuration(mode="reuse"), self.inventory(), data)
                self.assertTrue(reuse.blocked)
                self.assertNotEqual(self.outcomes(reuse)["serialptu"]["outcome"], "proposed_reuse")

    def test_candidate_missing_compatibility_cannot_establish_reuse(self):
        for field in ("revision", "compatibility"):
            with self.subTest(field=field):
                data = self.requirements()
                data["components"][0][field] = None
                self.assertTrue(self.plan(self.configuration(mode="reuse"), self.inventory(), data).blocked)

    def test_required_dependency_cycles_block(self):
        data = self.requirements()
        data["components"][0]["requires"] = ["ground_station"]
        data["components"].append({
            "component": "ground_station", "kind": "software", "revision": "core-r1",
            "compatibility": "core-v1", "requires": ["serialptu"], "source": "release-notes-r1",
        })
        self.assertTrue(self.plan(requirements=data).blocked)

    def test_update_optional_component_stays_unselected(self):
        requirements = self.requirements()
        requirements["components"].append({
            "component": "future-recorder", "kind": "software", "revision": "optional-r1",
            "compatibility": "optional-v1", "requires": [], "source": "release-notes-r1",
        })
        configuration = planning.parse_configuration(self.configuration(), self.catalog)
        result = planning.compare_release(configuration, self.catalog, planning.parse_requirements(requirements, self.catalog))
        self.assertFalse(result.blocked)
        self.assertIn("future-recorder", result.to_dict()["unselected_optional"])
        self.assertNotIn("future-recorder", self.outcomes(result))
        self.assertEqual(result.to_dict()["configuration"], configuration.to_dict())

    def test_update_selected_shared_component_change_is_visible(self):
        data = self.configuration()
        data["release_id"] = "r0"
        configuration = planning.parse_configuration(data, self.catalog)
        requirements = planning.parse_requirements(self.requirements(), self.catalog)
        result = planning.compare_release(configuration, self.catalog, requirements)
        self.assertEqual(result.to_dict()["candidate_release_id"], "r1")
        self.assertTrue(any(row["component"] == "serialptu" for row in result.to_dict()["changes"]))
        self.assertEqual(result.to_dict()["configuration"], configuration.to_dict())

    def test_update_missing_selected_requirements_remains_an_incomplete_preview(self):
        requirements = self.requirements()
        requirements["components"] = []
        result = planning.compare_release(
            planning.parse_configuration(self.configuration(), self.catalog), self.catalog,
            planning.parse_requirements(requirements, self.catalog),
        )
        data = result.to_dict()
        self.assertTrue(result.blocked)
        self.assertTrue(data["planning_only"])
        self.assertFalse(data["apply_supported"])
        self.assertFalse(data["complete"])
        change = next(row for row in data["changes"] if row["component"] == "serialptu")
        self.assertEqual(change["kind"], "selected_requirement")
        self.assertIsNone(change["detail"])
        self.assertEqual(data["configuration"], self.configuration())

    def test_new_required_software_is_explicit(self):
        data = self.requirements()
        data["components"][0]["requires"] = ["meteor-api"]
        data["components"].append({
            "component": "meteor-api", "kind": "software", "revision": "messaging-r1",
            "compatibility": "messaging-v1", "requires": [], "source": "release-notes-r1",
        })
        result = self.plan(requirements=data)
        self.assertFalse(result.blocked)
        outcome = self.outcomes(result)["meteor-api"]
        self.assertTrue(outcome["derived"])
        self.assertTrue(outcome["reasons"])

    def test_new_required_hardware_requires_a_configuration_decision(self):
        data = self.requirements()
        data["components"][0]["requires"] = ["pointing.qpt130"]
        data["components"].append({
            "component": "pointing.qpt130", "kind": "hardware", "revision": None,
            "compatibility": None, "requires": [], "source": "release-notes-r1",
        })
        result = self.plan(requirements=data)
        self.assertTrue(result.blocked)
        self.assertEqual(result.to_dict()["configuration"]["instances"], [])
        compared = planning.compare_release(
            planning.parse_configuration(self.configuration(), self.catalog), self.catalog,
            planning.parse_requirements(data, self.catalog),
        ).to_dict()
        self.assertNotIn("pointing.qpt130", compared["unselected_optional"])
        self.assertTrue(any(change["component"] == "pointing.qpt130" for change in compared["changes"]))

    def test_external_responsibility_cannot_satisfy_a_required_connector(self):
        configuration = self.configuration()
        configuration["selections"].append({
            "component": "rf.frontend", "mode": "external", "provider": "sponsor",
            "instance_ids": [],
        })
        requirements = self.requirements()
        requirements["components"][0]["requires"] = ["rf.frontend"]
        result = self.plan(configuration, requirements=requirements)
        self.assertTrue(result.blocked)
        self.assertEqual(self.outcomes(result)["rf.frontend"]["outcome"], "external_responsibility")

    def test_guided_arrow_missing_external_record_cannot_silently_switch_provider(self):
        configuration = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
        configuration["target"] = self.configuration()["target"]
        configuration["selections"] = [
            row for row in configuration["selections"] if row["component"] != "rf.frontend"
        ]
        requirements = self.requirements()
        requirements["components"][0]["requires"] = ["rf.frontend"]
        result = self.plan(configuration, requirements=requirements)
        self.assertTrue(result.blocked)
        self.assertEqual(result.to_dict()["configuration"], configuration)
        self.assertTrue(any(
            row["component"] == "rf.frontend" and row["severity"] == "error"
            and row["code"] == "preset_prerequisite"
            for row in result.to_dict()["diagnostics"]
        ))

    def test_removed_selected_component_blocks_without_silent_substitution(self):
        data = self.requirements()
        data["components"] = []
        data["removed_components"] = ["serialptu"]
        result = self.plan(requirements=data)
        self.assertTrue(result.blocked)
        self.assertEqual(result.to_dict()["configuration"]["selections"], self.configuration()["selections"])

    def test_human_and_json_rendering_label_the_same_incomplete_plan(self):
        result = self.plan()
        self.assertEqual(json.loads(planning.render_json(result)), result.to_dict())
        human = planning.render_human(result)
        self.assertIn("serialptu", human)
        self.assertIn("planning", human.lower())
        self.assertIn("apply", human.lower())

    def test_human_required_hardware_reasons_match_review_sensor_release_r1(self):
        requirements = self.requirements()
        requirements["components"][0].update(requires=["review-sensor"], source="release-r1")
        requirements["components"].append({
            "component": "review-sensor", "kind": "hardware", "revision": "rev1",
            "compatibility": "sensor1", "requires": [], "source": "hardware-r1",
        })
        result = self.plan(requirements=requirements)
        self.assertTrue(result.blocked)
        self.assertNotIn("review-sensor", self.outcomes(result))
        self.assertEqual(result.to_dict()["configuration"], self.configuration())
        reasons = next(row["reasons"] for row in result.to_dict()["derived_requirements"]
                       if row["component"] == "review-sensor")
        self.assertEqual(reasons, [{
            "required_by": "serialptu", "relationship": "supplied-release", "source": "release-r1",
        }])
        human = planning.render_human(result)
        self.assertIn("review-sensor: required (no selected outcome)", human)
        self.assertEqual(human.count("required by serialptu: supplied-release [release-r1]"), 1)
        self.assertEqual(json.loads(planning.render_json(result)), result.to_dict())

    def test_human_required_hardware_retains_multiple_requesters_and_sources(self):
        requirements = self.requirements()
        requirements["components"][0].update(requires=["review-sensor", "meteor-api"], source="release-r1")
        requirements["components"].extend([
            {"component": "meteor-api", "kind": "software", "revision": "rev1",
             "compatibility": "abi1", "requires": ["review-sensor"], "source": "messaging-r1"},
            {"component": "review-sensor", "kind": "hardware", "revision": "rev1",
             "compatibility": "sensor1", "requires": [], "source": "hardware-r1"},
        ])
        result = self.plan(requirements=requirements)
        self.assertTrue(result.blocked)
        self.assertNotIn("review-sensor", self.outcomes(result))
        human = planning.render_human(result)
        section = human.split("review-sensor: required (no selected outcome)\n", 1)[1]
        self.assertIn("required by meteor-api: supplied-release [messaging-r1]", section)
        self.assertIn("required by serialptu: supplied-release [release-r1]", section)
        self.assertLess(section.index("required by meteor-api"), section.index("required by serialptu"))
        reordered = copy.deepcopy(requirements)
        reordered["components"].reverse()
        self.assertEqual(human, planning.render_human(self.plan(requirements=reordered)))

    def test_human_normal_outcome_reason_is_not_repeated(self):
        result = self.plan(self.configuration("ground_station"))
        self.assertFalse(result.blocked)
        human = planning.render_human(result)
        self.assertEqual(human.count("required by ground_station: python-declaration [ground_station/pyproject.toml:8]"), 1)
        self.assertNotIn("meteor-api: required (no selected outcome)", human)


if __name__ == "__main__":
    unittest.main()
