import builtins
from contextlib import redirect_stderr, redirect_stdout
import importlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from satgs import operator_cli, operator_docs


class OperatorDocsTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="satgs-docs-test-")
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.guide = self.directory / "installed release with spaces"
        self.guide.mkdir()
        self.content = "SATGS User Guide\n\nOpen SATGS, inspect status and review changes before saving.\n"
        (self.guide / "user-guide.txt").write_text(self.content, encoding="utf-8")
        (self.guide / "user-guide.html").write_text("<!doctype html><title>SATGS User Guide</title>", encoding="utf-8")
        (self.guide / "user-guide.css").write_text("body { color: black; }\n", encoding="utf-8")
        self.resources = patch.object(operator_docs, "_GUIDE_DIRECTORY", self.guide)
        self.resources.start()
        self.addCleanup(self.resources.stop)

    def call(self, *arguments):
        output, errors = io.StringIO(), io.StringIO()
        with redirect_stdout(output), redirect_stderr(errors):
            code = operator_cli.main(list(arguments))
        return code, output.getvalue(), errors.getvalue()

    def test_three_public_forms_share_dispatch_without_a_workspace_or_viewer(self):
        with patch.object(os, "environ", {}), patch.object(operator_docs.subprocess, "run") as viewer:
            for arguments in (("docs",), ("--read-docs",), ("docs", "--text")):
                with self.subTest(arguments=arguments):
                    code, output, errors = self.call("--workspace", str(self.directory / "absent"), *arguments)
                    self.assertEqual(code, 0)
                    self.assertEqual(output, self.content)
                    self.assertEqual(errors, "" if "--text" in arguments else
                                     "No desktop display: showing the bundled user guide as text.\n")
            viewer.assert_not_called()
        self.assertFalse((self.directory / "absent").exists())

    def test_text_ignores_desktop_browser_and_pager_environment(self):
        environment = {"DISPLAY": "viewer-fixture", "BROWSER": "untrusted command --argument",
                       "PAGER": "untrusted-pager", "SHELL": "untrusted-shell"}
        with patch.object(os, "environ", environment), patch.object(operator_docs.subprocess, "run") as viewer:
            code, output, errors = self.call("docs", "--text")
        self.assertEqual((code, output, errors), (0, self.content, ""))
        viewer.assert_not_called()

    def test_desktop_dispatch_uses_one_fixed_argument_array_and_bounded_wait(self):
        environment = {"DISPLAY": "viewer-fixture", "BROWSER": "untrusted command",
                       "PATH": "/untrusted", "PYTHONPATH": "/untrusted", "BASH_ENV": "/untrusted"}
        with patch.object(os, "environ", environment), patch.object(operator_docs.subprocess, "run",
                return_value=SimpleNamespace(returncode=0)) as viewer:
            result = operator_docs.dispatch_docs()
        self.assertEqual(result["mode"], "viewer_dispatched")
        self.assertEqual(result["path"], str(self.guide / "user-guide.html"))
        self.assertEqual(result["text"], self.content)
        self.assertIn("Window visibility is not confirmed", result["message"])
        viewer.assert_called_once_with(["/usr/bin/xdg-open", str(self.guide / "user-guide.html")],
            shell=False, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            env={"DISPLAY": "viewer-fixture", "PATH": "/usr/bin:/bin"}, timeout=5, check=False)

    def test_each_ssh_marker_forces_text_even_with_a_display(self):
        for marker in ("SSH_CONNECTION", "SSH_CLIENT", "SSH_TTY"):
            with self.subTest(marker=marker), patch.object(os, "environ",
                    {"DISPLAY": "viewer-fixture", marker: "ssh-fixture"}), \
                    patch.object(operator_docs.subprocess, "run") as viewer:
                result = operator_docs.dispatch_docs()
                self.assertEqual(result["mode"], "text")
                self.assertEqual(result["reason"], "ssh_session")
                self.assertEqual(result["text"], self.content)
                viewer.assert_not_called()

    def test_viewer_failures_retain_text_and_truthful_reason(self):
        failures = ((FileNotFoundError(), "viewer_unavailable"), (PermissionError(), "viewer_failed"),
                    (subprocess.TimeoutExpired(["/usr/bin/xdg-open"], 5), "viewer_timeout"))
        for failure, reason in failures:
            with self.subTest(reason=reason), patch.object(os, "environ", {"DISPLAY": "viewer-fixture"}), \
                    patch.object(operator_docs.subprocess, "run", side_effect=failure):
                code, output, errors = self.call("docs")
                result = operator_docs.dispatch_docs()
                self.assertEqual((code, output), (0, self.content))
                self.assertTrue(errors)
                self.assertEqual(result["mode"], "text")
                self.assertEqual(result["reason"], reason)
                self.assertNotIn(str(self.directory), errors)
        with patch.object(os, "environ", {"DISPLAY": "viewer-fixture"}), \
                patch.object(operator_docs.subprocess, "run", return_value=SimpleNamespace(returncode=3)):
            result = operator_docs.dispatch_docs()
        self.assertEqual(result["reason"], "viewer_failed")
        self.assertEqual(result["text"], self.content)

    def test_json_retains_envelope_and_resource_identity(self):
        with patch.object(os, "environ", {}):
            code, output, errors = self.call("--format", "json", "docs", "--text")
        document = json.loads(output)
        self.assertEqual(code, 0)
        self.assertEqual(document["status"], "PASS")
        self.assertEqual(document["result"]["mode"], "text")
        self.assertEqual(document["result"]["path"], str(self.guide / "user-guide.txt"))
        self.assertEqual(document["result"]["text"], self.content)
        self.assertEqual(errors, "")

    def test_missing_html_falls_back_but_missing_text_is_an_installation_error(self):
        (self.guide / "user-guide.html").unlink()
        with patch.object(os, "environ", {"DISPLAY": "viewer-fixture"}), \
                patch.object(operator_docs.subprocess, "run") as viewer:
            result = operator_docs.dispatch_docs()
        self.assertEqual(result["reason"], "html_unavailable")
        self.assertEqual(result["text"], self.content)
        viewer.assert_not_called()
        (self.guide / "user-guide.txt").unlink()
        code, output, errors = self.call("--format", "json", "docs", "--text")
        self.assertEqual(code, 4)
        self.assertEqual(json.loads(output)["error"]["code"], "docs_unavailable")
        self.assertNotIn(str(self.directory), output)
        self.assertEqual(errors, "")

    def test_invalid_docs_arguments_preserve_invalid_error_contract(self):
        for arguments in (("docs", "--topic", "unknown"), ("--read-docs", "status"), ()):
            with self.subTest(arguments=arguments):
                code, output, errors = self.call("--format", "json", *arguments)
                self.assertEqual(code, 2)
                self.assertEqual(json.loads(output), {"status": "FAIL", "error": {"code": "invalid",
                    "message": "Unsupported operator arguments; use --help."}})
                self.assertEqual(errors, "")

    def test_invalid_station_is_not_read_or_rewritten(self):
        station = self.directory / "invalid station"
        station.mkdir()
        invalid = station / "station.json"
        invalid.write_bytes(b"not a station document")
        before = invalid.read_bytes()
        with patch.object(os, "environ", {}):
            code, output, errors = self.call("--workspace", str(station), "docs", "--text")
        self.assertEqual((code, output, errors), (0, self.content, ""))
        self.assertEqual(invalid.read_bytes(), before)
        self.assertEqual([path.name for path in station.iterdir()], ["station.json"])

    def test_documentation_cli_imports_do_not_need_station_or_optional_stacks(self):
        denied = ("satgs.operator_core", "satgs.deployment", "satgs.deployment_cli", "satgs.operator_runtime",
                  "satgs.operator_bench", "satgs.pass_runner", "tkinter", "yaml", "numpy", "pandas",
                  "ephem", "meteor_api", "pixhawk", "ptu_control", "stomp", "boxsdk")
        original = builtins.__import__

        def guarded_import(name, *arguments, **keywords):
            if any(name == prefix or name.startswith(prefix + ".") for prefix in denied):
                raise AssertionError("Documentation imported a station or optional stack: " + name)
            return original(name, *arguments, **keywords)

        package = sys.modules["satgs"]
        missing = object()
        original_attribute = getattr(package, "operator_cli", missing)
        original_module = sys.modules.pop("satgs.operator_cli")
        try:
            with patch.object(builtins, "__import__", side_effect=guarded_import), patch.object(os, "environ", {}):
                fresh = importlib.import_module("satgs.operator_cli")
                self.assertIsNot(fresh, original_module)
                self.assertEqual(fresh.__file__, original_module.__file__)

                def fresh_call(*arguments):
                    output, errors = io.StringIO(), io.StringIO()
                    with redirect_stdout(output), redirect_stderr(errors):
                        code = fresh.main(list(arguments))
                    return code, output.getvalue(), errors.getvalue()

                for arguments in (("docs",), ("--read-docs",), ("docs", "--text")):
                    self.assertEqual(fresh_call(*arguments)[0], 0)
                self.assertIn("docs", fresh.parser().format_help())
                self.assertEqual(fresh_call("docs", "--topic", "unknown")[0], 2)
        finally:
            sys.modules["satgs.operator_cli"] = original_module
            if original_attribute is missing:
                if hasattr(package, "operator_cli"):
                    delattr(package, "operator_cli")
            else:
                setattr(package, "operator_cli", original_attribute)


if __name__ == "__main__":
    unittest.main()
