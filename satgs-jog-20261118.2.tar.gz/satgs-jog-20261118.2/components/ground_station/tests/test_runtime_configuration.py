import copy
import csv
from dataclasses import FrozenInstanceError
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from satgs.deployment import load_manifest
from satgs import deployment_plan as planning
from satgs import runtime_configuration as runtime
from satgs.station_location import location_from_settings, prepare_manual_location


class RuntimeConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.catalog = planning.build_catalog(load_manifest())
        self.configuration = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
        self.configuration["target"] = {"id": "fixture-target", "environment": "linux-arm64-python311"}
        self.paths = {key: self.root / key for key in ("deployment.json", "bindings.json", "station.yaml", "tle.csv")}
        self.station = {
            "home_directory": str(self.root), "logging_dir": str(self.root / "results"),
            "file_prefix_source": "default", "amq_server": "synthetic.invalid", "amq_port": 61613,
            "amq_username": "SYNTHETIC-USER-ONLY", "amq_password": "SYNTHETIC-SECRET-ONLY",
            "amq_dial_address": "192.0.2.8", "amq_tls_server_name": "strict-identity.synthetic.invalid",
            "amq_ca_pem": "SYNTHETIC-PUBLIC-CA-DATA\n",
            "amq_use_ssl": True, "ground_station_lat": 42.0, "ground_station_lon": -71.0,
            "ground_station_altm": 12.5,
            "positioners": [{"id": 7, "pix_id": 9, "type": "QPT-130", "no_go_config": None},
                            {"id": 8, "pix_id": 10, "type": "QPT-500"}],
            "pixhawk_sensors": [{"id": 9, "ptu_id": 7}, {"id": 10, "ptu_id": 8}],
        }
        self.binding = {
            "schema_version": 1, "configuration_id": self.configuration["id"],
            "configuration_revision": self.configuration["revision"],
            "configuration_sha256": "", "target": self.configuration["target"],
            "bindings": [
                {"instance_id": "ptu-1", "component": "qpt130", "provider": "guided_arrow_hardware",
                 "manager_id": 7, "paired_with": "pixhawk-1"},
                {"instance_id": "pixhawk-1", "component": "pixhawk_dual_gps", "provider": "guided_arrow_hardware",
                 "manager_id": 9, "paired_with": "ptu-1"},
            ],
        }
        self.tle_row = {
            "norad_id": "28626", "name": "XM-3 (RHYTHM)",
            "tle": "XM-3 (RHYTHM),1 28626U 05008A   25135.79004957 -.00000184  00000+0  00000+0 0  9996,2 28626   0.0095  11.7717 0001427 181.9268 238.1539  1.00268135 74089",
            "date": "2025-05-16 02:51:09 UTC",
        }
        self.write_inputs()

    def write_inputs(self):
        raw = json.dumps(self.configuration, indent=2).encode()
        self.paths["deployment.json"].write_bytes(raw)
        self.binding["configuration_sha256"] = hashlib.sha256(raw).hexdigest()
        self.paths["bindings.json"].write_text(json.dumps(self.binding))
        self.paths["station.yaml"].write_text(json.dumps(self.station))
        self.write_tle([self.tle_row])

    def write_tle(self, rows):
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=("norad_id", "name", "tle", "date"))
        writer.writeheader()
        writer.writerows(rows)
        self.paths["tle.csv"].write_text(stream.getvalue())

    def load(self, **options):
        values = {"sat_id": 28626, "duration": 30.0, "elevation": 15.0}
        values.update(options)
        return runtime.load_runtime_configuration(
            self.paths["deployment.json"], self.paths["bindings.json"],
            self.paths["station.yaml"], self.paths["tle.csv"], **values,
        )

    def test_selected_manager_id_maximum_matches_owner_protocol(self):
        maximum = 2 ** 31 - 1
        self.binding['bindings'][0]['manager_id'] = maximum
        self.station['positioners'][0]['id'] = maximum
        self.station['pixhawk_sensors'][0]['ptu_id'] = maximum
        self.write_inputs()
        self.assertEqual(self.load().ptu.manager_id, maximum)

    def test_selected_manager_id_overflow_rejects_both_owners(self):
        for row in range(2):
            with self.subTest(owner=row):
                binding = copy.deepcopy(self.binding)
                binding['bindings'][row]['manager_id'] = 2 ** 31
                self.paths['bindings.json'].write_text(json.dumps(binding))
                with self.assertRaises(runtime.RuntimeConfigurationError) as raised:
                    self.load()
                self.assertEqual(str(raised.exception),
                                 'Selected manager identifiers must fit the owner protocol.')

    def test_manager_limit_does_not_redefine_norad_identifiers(self):
        runtime._positive_id(2 ** 31)

    def test_admitted_identity_and_pair_are_immutable(self):
        context = self.load()
        self.assertEqual(context.configuration_sha256, self.binding["configuration_sha256"])
        self.assertEqual(context.ptu.manager_id, 7)
        self.assertEqual(context.pixhawk.manager_id, 9)
        self.assertEqual(context.operation, "pointing")
        self.assertEqual(context.tle.norad_id, 28626)
        self.assertEqual(context.tle.to_dict()["tle"], self.tle_row["tle"])
        with self.assertRaises(FrozenInstanceError):
            context.duration = 90
        with self.assertRaises(TypeError):
            context.station["amq_password"] = "changed"
        with self.assertRaises(TypeError):
            context.station["positioners"][0]["id"] = 100

    def test_credentials_and_raw_inputs_are_not_in_repr(self):
        context = self.load()
        self.assertNotIn(self.station["amq_password"], repr(context))
        self.assertNotIn(self.station["amq_username"], repr(context))
        self.assertNotIn("amq_password", repr(context))
        self.assertNotIn("synthetic.invalid", repr(context))

    def test_only_selected_station_devices_are_passed_onward(self):
        context = self.load()
        settings = context.station_settings()
        self.assertEqual([row["id"] for row in settings["positioners"]], [7])
        self.assertEqual([row["id"] for row in settings["pixhawk_sensors"]], [9])
        settings["positioners"][0]["id"] = 999
        settings["amq_password"] = "changed"
        self.assertEqual(context.station["positioners"][0]["id"], 7)
        self.assertEqual(context.station["amq_password"], self.station["amq_password"])

    def test_original_files_are_admitted_once_and_replacement_does_not_change_context(self):
        reader = runtime.read_regular_bytes
        json_reader = runtime.read_json_document
        with patch.object(runtime, "read_regular_bytes", wraps=reader) as regular:
            with patch.object(runtime, "read_json_document", wraps=json_reader) as documents:
                context = self.load()
        self.assertEqual(regular.call_count, 2)
        self.assertEqual(documents.call_count, 2)
        original = context.station_settings()
        for path in self.paths.values():
            path.write_text("replacement must never be reread")
        self.assertEqual(context.station_settings(), original)
        self.assertEqual(context.tle.tle, self.tle_row["tle"])
        self.assertEqual(context.raw_documents[0], json.dumps(self.configuration, indent=2).encode())

    def test_manual_location_is_retained_only_in_new_admitted_context(self):
        previous = self.load()
        old_location = location_from_settings(previous.station)
        revision = hashlib.sha256(self.paths["station.yaml"].read_bytes()).hexdigest()
        selected = prepare_manual_location(self.station, latitude_deg=40, longitude_deg=-70,
                                           altitude_m=15, expected_revision=revision,
                                           current_revision=revision)
        self.paths["station.yaml"].write_text(json.dumps(selected.settings()))
        current = self.load()
        self.assertEqual(location_from_settings(previous.station), old_location)
        self.assertEqual(location_from_settings(current.station), selected.location)
        self.assertEqual(current.station_settings()["ground_station_location_source"], "manual")
        self.assertNotEqual(previous.station_sha256, current.station_sha256)
        self.assertEqual(previous.configuration_sha256, current.configuration_sha256)
        self.assertEqual(previous.binding_sha256, current.binding_sha256)

    def test_live_gps_location_source_is_not_admitted(self):
        self.station["ground_station_location_source"] = "live-gps"
        self.write_inputs()
        with self.assertRaises(runtime.RuntimeConfigurationError):
            self.load()

    def test_binding_digest_covers_raw_bytes_not_semantically_equivalent_json(self):
        self.paths["deployment.json"].write_text(json.dumps(self.configuration, separators=(",", ":")))
        with self.assertRaisesRegex(runtime.RuntimeConfigurationError, "admitted configuration bytes"):
            self.load()

    def test_binding_identity_revision_target_and_schema_are_exact(self):
        for key, value in (
            ("configuration_id", "other"), ("configuration_revision", 2),
            ("configuration_revision", True), ("configuration_sha256", "0" * 64),
            ("target", {"id": "other", "environment": "linux-arm64-python311"}),
            ("schema_version", True), ("schema_version", 2),
        ):
            with self.subTest(key=key, value=value):
                data = copy.deepcopy(self.binding)
                data[key] = value
                self.paths["bindings.json"].write_text(json.dumps(data))
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    self.load()

    def test_binding_requires_exact_pair_and_no_unknown_fields(self):
        mutations = (
            lambda value: value["bindings"].pop(),
            lambda value: value["bindings"].append(copy.deepcopy(value["bindings"][0])),
            lambda value: value.update(unrecognized=True),
            lambda value: value["bindings"][0].update(extra=True),
            lambda value: value["bindings"][0].update(instance_id="unknown"),
            lambda value: value["bindings"][1].update(instance_id="ptu-1"),
            lambda value: value["bindings"][0].update(component="pixhawk_dual_gps"),
            lambda value: value["bindings"][0].update(provider="station_hardware"),
            lambda value: value["bindings"][0].update(paired_with="ptu-1"),
        )
        for mutate in mutations:
            with self.subTest(mutation=mutate):
                data = copy.deepcopy(self.binding)
                mutate(data)
                self.paths["bindings.json"].write_text(json.dumps(data))
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    self.load()

    def test_manager_ids_cannot_be_zero_boolean_negative_or_strings(self):
        for value in (0, -1, True, "7", 1.5, None):
            with self.subTest(value=value):
                data = copy.deepcopy(self.binding)
                data["bindings"][0]["manager_id"] = value
                self.paths["bindings.json"].write_text(json.dumps(data))
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    self.load()

    def test_station_requires_both_reciprocal_associations_and_unique_ids(self):
        mutations = (
            lambda value: value["positioners"][0].update(pix_id=10),
            lambda value: value["pixhawk_sensors"][0].update(ptu_id=8),
            lambda value: value["positioners"][0].update(id=0),
            lambda value: value["positioners"][0].update(id=True),
            lambda value: value["positioners"][1].update(id=7),
            lambda value: value["pixhawk_sensors"].clear(),
            lambda value: value["positioners"][0].update(type="QPT-500"),
            lambda value: value["positioners"][0].update(allow_pointing_errors=True),
        )
        for mutate in mutations:
            with self.subTest(mutation=mutate):
                data = copy.deepcopy(self.station)
                mutate(data)
                self.paths["station.yaml"].write_text(json.dumps(data))
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    self.load()

    def test_invalid_station_types_and_geographic_values_reject(self):
        for key, value in (
            ("ground_station_lat", 91), ("ground_station_lon", -181),
            ("ground_station_altm", True), ("ground_station_lat", float("nan")),
            ("amq_port", True), ("amq_port", 65536), ("amq_use_ssl", "false"),
            ("amq_password", []), ("logging_dir", ""), ("file_prefix_source", "unknown"),
        ):
            with self.subTest(key=key):
                data = copy.deepcopy(self.station)
                data[key] = value
                self.paths["station.yaml"].write_text(json.dumps(data))
                with self.assertRaises(runtime.RuntimeConfigurationError) as error:
                    self.load()
                self.assertNotIn(self.station["amq_password"], str(error.exception))

    def test_station_duplicate_nonfinite_deep_and_oversized_inputs_reject(self):
        for payload in (
            b'{"secret":"SYNTHETIC-SECRET-ONLY","secret":2}', b'{"value":NaN}',
            b'{"value":' + b'[' * 40 + b'0' + b']' * 40 + b'}',
            b' ' * 1_048_577, b'\xff', b'{"value":1e999}',
        ):
            with self.subTest(size=len(payload)):
                self.paths["station.yaml"].write_bytes(payload)
                with self.assertRaises(runtime.RuntimeConfigurationError) as error:
                    self.load()
                self.assertNotIn("SYNTHETIC-SECRET-ONLY", str(error.exception))

    def test_non_json_yaml_fails_closed_when_pyyaml_is_unavailable(self):
        with patch.dict("sys.modules", {"yaml": None}):
            for text in ("password: SYNTHETIC-SECRET-ONLY", "value: &alias [*alias]", "key: 1\nkey: 2"):
                self.paths["station.yaml"].write_text(text)
                with self.assertRaisesRegex(runtime.RuntimeConfigurationError, "PyYAML is required"):
                    self.load()

    def test_invalid_duration_elevation_and_norad_fail_before_read(self):
        for values in (
            {"duration": 0}, {"duration": -1}, {"duration": float("inf")}, {"duration": True},
            {"elevation": 90}, {"elevation": -1}, {"elevation": float("nan")},
            {"sat_id": True}, {"sat_id": 0}, {"sat_id": "28626"},
        ):
            with self.subTest(values=values):
                with patch.object(runtime, "read_json_document", side_effect=AssertionError("unexpected read")):
                    with self.assertRaises(runtime.RuntimeConfigurationError):
                        self.load(**values)

    def test_missing_duplicate_or_malformed_selected_tle_rejects(self):
        cases = [[], [self.tle_row, self.tle_row]]
        for field, value in (
            ("norad_id", "invalid"), ("name", "other"), ("date", "invalid-date"),
            ("tle", self.tle_row["tle"][:-1] + "0"), ("tle", "name,1 wrong,2 wrong"),
            ("tle", self.tle_row["tle"].replace("28626", "28627")),
        ):
            row = dict(self.tle_row)
            row[field] = value
            cases.append([row])
        for rows in cases:
            with self.subTest(rows=len(rows)):
                self.write_tle(rows)
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    self.load()

    def test_tle_csv_duplicate_header_and_irregular_rows_reject(self):
        for text in ("norad_id,name,tle,date,date\n", "norad_id,name,tle,date\n28626,name\n"):
            self.paths["tle.csv"].write_text(text)
            with self.assertRaises(runtime.RuntimeConfigurationError):
                self.load()

    def test_selected_no_go_data_is_admitted_once_and_path_not_given_to_owner(self):
        path = self.root / "no-go.yaml"
        data = {"nogozones": [{"az_min": 290, "az_max": 330, "el_min": 0, "el_max": 30}]}
        payload = json.dumps(data).encode()
        path.write_bytes(payload)
        self.station["positioners"][0]["no_go_config"] = str(path)
        self.write_inputs()
        context = self.load()
        path.write_text("replaced")
        self.assertEqual(context.no_go_sha256, hashlib.sha256(payload).hexdigest())
        self.assertEqual(context.no_go_data["nogozones"][0]["az_min"], 290)
        self.assertIsNone(context.station["positioners"][0]["no_go_config"])
        self.assertEqual(context.raw_documents[-1], payload)

    def test_unsupported_no_go_shape_is_not_silently_discarded(self):
        path = self.root / "no-go.yaml"
        self.station["positioners"][0]["no_go_config"] = str(path)
        self.write_inputs()
        for value in ({"unknown": []}, {"nogozones": []}, {"nogozones": [{"az_min": 2}]}):
            path.write_text(json.dumps(value))
            with self.assertRaises(runtime.RuntimeConfigurationError):
                self.load()

    def test_shared_validator_is_used_and_no_planner_authorization_is_requested(self):
        with patch.object(runtime, "validate_selection_contract", wraps=planning.validate_selection_contract) as validator:
            with patch.object(planning, "plan_configuration", side_effect=AssertionError("not authority")):
                self.load()
        self.assertEqual(validator.call_count, 1)
        self.assertIsInstance(validator.call_args.args[0], planning.Configuration)

    def test_canonical_configuration_cannot_be_weakened(self):
        next(row for row in self.configuration["selections"] if row["component"] == "pointing.dual_gps")["mode"] = "omit"
        self.write_inputs()
        with self.assertRaisesRegex(runtime.RuntimeConfigurationError, "shared selection contract"):
            self.load()

    def test_custom_requires_all_local_operation_members(self):
        for component in ("pixhawk", "pointing.ptu", "pointing.qpt130", "pointing.dual_gps",
                          "execution.pass_runner", "broker.activemq", "time.ntp"):
            for mode in ("omit", "external", "missing"):
                with self.subTest(component=component, mode=mode):
                    self.configuration = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
                    self.configuration["preset"] = None
                    if mode == "missing":
                        self.configuration["selections"] = [row for row in self.configuration["selections"] if row["component"] != component]
                    else:
                        next(row for row in self.configuration["selections"] if row["component"] == component)["mode"] = mode
                    self.binding["target"] = self.configuration["target"]
                    self.write_inputs()
                    with self.assertRaises(runtime.RuntimeConfigurationError):
                        self.load()

    def test_custom_selected_extra_instances_remain_unused(self):
        self.configuration["preset"] = None
        for identity, component in (("ptu-extra", "qpt130"), ("pixhawk-extra", "pixhawk_dual_gps")):
            self.configuration["instances"].append({"id": identity, "component": component, "provider": "guided_arrow_hardware"})
        for row in self.configuration["selections"]:
            if row["component"] in ("pointing.ptu", "pointing.qpt130"):
                row["instance_ids"].append("ptu-extra")
            if row["component"] in ("pointing.pixhawk", "pointing.dual_gps"):
                row["instance_ids"].append("pixhawk-extra")
        self.write_inputs()
        self.assertEqual(self.load().ptu.instance_id, "ptu-1")

    def test_station_output_and_home_directories_fail_closed_before_output(self):
        for key in ("home_directory", "logging_dir"):
            for value in ("relative", "/", "/dev/test", "/proc/test", "/sys/test", "/tmp/../dev/test"):
                with self.subTest(key=key, value=value):
                    data = copy.deepcopy(self.station)
                    data[key] = value
                    self.paths["station.yaml"].write_text(json.dumps(data))
                    with self.assertRaisesRegex(runtime.RuntimeConfigurationError, "Station directories"):
                        self.load()
        self.assertFalse((self.root / "results").exists())

    def test_logging_directory_expansion_uses_only_admitted_absolute_home(self):
        self.station["logging_dir"] = "~/results"
        self.write_inputs()
        self.assertEqual(self.load().station["logging_dir"], str(self.root / "results"))

    def test_explicit_modular_full_msel_rejects_without_legacy_fallback(self):
        self.configuration = planning.expand_preset(self.catalog, "full_msel").to_dict()
        self.write_inputs()
        with self.assertRaisesRegex(runtime.RuntimeConfigurationError, "Full M-SEL is unsupported"):
            self.load()

    def test_legacy_requires_no_operation_and_no_modular_input(self):
        self.assertIsNone(runtime.resolve_runtime_request())
        for options in ({"operation": "unknown"}, {"deployment_config": "missing"},
                        {"runtime_bindings": "missing"}, {"operation": "pointing"}):
            with self.subTest(options=options):
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    runtime.resolve_runtime_request(**options)

    def test_explicit_request_dispatches_actual_loader_and_rejects_conflicts_before_read(self):
        options = dict(operation="pointing", deployment_config=self.paths["deployment.json"],
                       runtime_bindings=self.paths["bindings.json"], station_config=self.paths["station.yaml"],
                       sat_file=self.paths["tle.csv"], sat_id=28626, duration=30, elevation=15)
        self.assertEqual(runtime.resolve_runtime_request(**options).ptu.manager_id, 7)
        for conflict in ("noptu", "nopixhawk", "record_iq", "record_trace", "sip", "calibration", "error_profile", "rf"):
            with self.subTest(conflict=conflict):
                with patch.object(runtime, "load_runtime_configuration", side_effect=AssertionError("not admitted")):
                    with self.assertRaises(runtime.RuntimeConfigurationError):
                        runtime.resolve_runtime_request(**options, conflicts=(conflict,))

    def test_raw_external_limits_remain_unchanged(self):
        for payload in (b" " * 1_048_577, b'{"value":NaN}', b'{"key":1,"key":2}',
                        b'[' * 33 + b'0' + b']' * 33):
            self.paths["deployment.json"].write_bytes(payload)
            with self.assertRaises(runtime.RuntimeConfigurationError):
                self.load()

    def test_reg01_internal_expansion_remains_usable_without_readmission(self):
        required = {"ground_station", "meteor-api", "sat_tracker", "serialptu", "pixhawk",
                    "broker.activemq", "time.ntp",
                    "execution.pass_runner", "orbit.pass_finder", "pointing.ptu", "pointing.qpt130",
                    "pointing.pixhawk", "pointing.dual_gps"}
        base = planning.expand_preset(self.catalog, "guided_arrow").to_dict()
        base["selections"] = [row for row in base["selections"] if row["component"] in required]
        for key in ("preset", "release_id", "host_roles"):
            base.pop(key)
        for row in base["selections"]:
            if not row["instance_ids"]:
                row.pop("instance_ids")
        candidate = None
        for count in range(880, 910):
            data = copy.deepcopy(base)
            ids = [f"unused-{index}" for index in range(count)]
            data["instances"].extend({"id": identity, "component": "qpt130", "provider": "guided_arrow_hardware"} for identity in ids)
            for row in data["selections"]:
                if row["component"] in ("pointing.ptu", "pointing.qpt130"):
                    row["instance_ids"].extend(ids)
            try:
                parsed = planning.parse_configuration(data, self.catalog)
            except planning.InputError:
                continue
            try:
                planning.validate_document_structure(parsed.to_dict())
            except planning.InputError:
                candidate = data
                break
        self.assertIsNotNone(candidate, "fixture must cross the normalized-only node boundary")
        self.configuration = candidate
        self.binding["target"] = candidate["target"]
        self.write_inputs()
        context = self.load()
        with self.assertRaises(planning.InputError):
            planning.parse_configuration(context.configuration.to_dict(), self.catalog)
        self.assertEqual(context.ptu.manager_id, 7)


    def load_station(self, station):
        self.paths["station.yaml"].write_text(json.dumps(station))
        return self.load()

    def assert_station_rejected(self, station):
        with self.assertRaises(runtime.RuntimeConfigurationError) as raised:
            self.load_station(station)
        rendered = str(raised.exception) + repr(raised.exception)
        values = (self.station[key] for key in (
            "amq_username", "amq_password", "amq_ca_pem", "amq_dial_address", "amq_tls_server_name"))
        self.assertTrue(all(value not in rendered for value in values), "station input exposed by rejection")

    def test_strict_required_transport_fields_and_types(self):
        for key in ("amq_dial_address", "amq_tls_server_name", "amq_ca_pem",
                    "amq_username", "amq_password"):
            with self.subTest(field=key, category="missing"):
                station = copy.deepcopy(self.station)
                station.pop(key)
                self.assert_station_rejected(station)
            for value in (None, False, 7, [], {}, ""):
                with self.subTest(field=key, category=type(value).__name__):
                    self.assert_station_rejected(dict(self.station, **{key: value}))

    def test_strict_transport_rejects_string_subclasses(self):
        class Text(str):
            pass

        context = self.load()
        for key in ("amq_dial_address", "amq_tls_server_name", "amq_ca_pem",
                    "amq_username", "amq_password", "amq_stomp_host"):
            with self.subTest(field=key):
                station = dict(self.station, **{key: Text(self.station.get(key, "host"))})
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    runtime._station_settings(station, context.ptu, context.pixhawk)

    def test_strict_tls_requires_exact_true_and_port_bounds(self):
        self.assertIs(self.load().station["amq_use_ssl"], True)
        for value in (False, 0, 1, None, "true", "false"):
            with self.subTest(category=type(value).__name__):
                self.assert_station_rejected(dict(self.station, amq_use_ssl=value))
        station = dict(self.station)
        station.pop("amq_use_ssl")
        self.assert_station_rejected(station)
        for port in (1, 65535):
            self.assertEqual(self.load_station(dict(self.station, amq_port=port)).station["amq_port"], port)
        for port in (0, -1, 65536, True, 1.0, "61614", None):
            with self.subTest(category=type(port).__name__):
                self.assert_station_rejected(dict(self.station, amq_port=port))

    def test_operational_station_rejects_bench_marker_before_filtering(self):
        for tls in (True, False):
            with self.subTest(tls=tls):
                self.assert_station_rejected(dict(self.station, amq_use_ssl=tls,
                    amq_transport="loopback-plaintext-bench"))
        for marker in ("local-serial", "unknown", None):
            with self.subTest(bench_transport=marker):
                self.assert_station_rejected(dict(self.station, bench_transport=marker))
        restored = self.load_station(dict(self.station)).station
        self.assertIs(restored["amq_use_ssl"], True)
        self.assertNotIn("bench_transport", restored)

    def test_strict_dial_requires_canonical_numeric_address(self):
        for address in ("192.0.2.8", "2001:db8::8", "abcd:1234:5678:9abc:def0:1234:5678:9abc"):
            with self.subTest(category="canonical", size=len(address)):
                context = self.load_station(dict(self.station, amq_dial_address=address))
                self.assertTrue(context.station["amq_dial_address"] == address, "dial data changed")
        for address in ("broker.invalid", "192.0.2.008", "2001:DB8::8", "2001:0db8::8",
                        "fe80::1%zone", " 192.0.2.8", "192.0.2.8\n", "\u00e9", "1" * 46):
            with self.subTest(category="invalid", size=len(address)):
                self.assert_station_rejected(dict(self.station, amq_dial_address=address))

    def test_strict_identity_is_independent_and_bounded(self):
        maximum = ".".join(("a" * 63, "b" * 63, "c" * 63, "d" * 61))
        self.assertEqual(len(maximum), 253)
        for identity in ("Other-Broker.Example", "198.51.100.7", "2001:db8::9", "192.0.2.008", maximum):
            with self.subTest(category="valid", size=len(identity)):
                context = self.load_station(dict(self.station, amq_tls_server_name=identity))
                self.assertTrue(context.station["amq_tls_server_name"] == identity, "identity data changed")
                self.assertTrue(context.station["amq_dial_address"] == self.station["amq_dial_address"],
                                "identity replaced dial address")
        for identity in (maximum + "d", "x" * 64 + ".example", "a..b", ".a", "a.", "-a", "a-",
                         "a/b", "a\tb", "a\x7fb", "a\u00e9b", "fe80::1%zone", "2001:DB8::9"):
            with self.subTest(category="invalid", size=len(identity)):
                self.assert_station_rejected(dict(self.station, amq_tls_server_name=identity))

    def test_strict_host_absence_none_empty_and_bounds(self):
        self.assertNotIn("amq_stomp_host", self.station)
        self.assertIsNone(self.load().station.get("amq_stomp_host"))
        for host in (None, "", "different virtual host", "h" * 255):
            with self.subTest(category="valid", size=None if host is None else len(host)):
                context = self.load_station(dict(self.station, amq_stomp_host=host))
                self.assertTrue(context.station.get("amq_stomp_host") == host, "virtual host data changed")
        for host in ("h" * 256, "bad\nhost", "bad\thost", "bad\x7fhost", "\u00e9", 1, False, [], {}):
            with self.subTest(category=type(host).__name__):
                self.assert_station_rejected(dict(self.station, amq_stomp_host=host))

    def test_inline_ca_is_bounded_ascii_data_not_certificate_admission(self):
        for value in ("SYNTHETIC\r\nPUBLIC\tDATA", "x" * 65536, "not-a-certificate", "/synthetic/ca.pem"):
            with self.subTest(category="finite-data", size=len(value)):
                context = self.load_station(dict(self.station, amq_ca_pem=value))
                self.assertTrue(context.station["amq_ca_pem"] == value, "inline CA data changed")
        for value in ("x" * 65537, "bad\x00data", "bad\x7fdata", "bad\vdata", "bad\fdata", "\u00e9"):
            with self.subTest(category="invalid", size=len(value)):
                self.assert_station_rejected(dict(self.station, amq_ca_pem=value))

    def test_inline_ca_exception_is_only_the_main_root_value(self):
        for value in ("SYNTHETIC\nPUBLIC", "x" * 4097):
            with self.subTest(size=len(value)):
                document = {"amq_ca_pem": value}
                runtime._station_structure(document, allow_inline_ca=True)
                for allowed in (False, 1, "true"):
                    with self.assertRaises(runtime.RuntimeConfigurationError):
                        runtime._station_structure(document, allow_inline_ca=allowed)
                for document in (
                    {"amq_ca_pem": value, "unrelated": value},
                    {"nested": {"amq_ca_pem": value}},
                    {"amq_ca_pem": value, "nested": [value]},
                    {"amq_ca_pem": {"nested": value}},
                    {value: "ordinary"},
                ):
                    with self.assertRaises(runtime.RuntimeConfigurationError):
                        runtime._station_structure(document, allow_inline_ca=True)

    def test_no_go_parser_has_no_inline_ca_exception(self):
        payload = json.dumps({"amq_ca_pem": "SYNTHETIC\nPUBLIC"}).encode()
        with self.assertRaises(runtime.RuntimeConfigurationError):
            runtime._parse_station_yaml(payload)
        with self.assertRaises(runtime.RuntimeConfigurationError):
            runtime._parse_station_yaml(payload, allow_inline_ca=False)
        runtime._parse_station_yaml(payload, allow_inline_ca=True)
        path = self.root / "no-go.yaml"
        path.write_text(json.dumps({"nogozones": [{"az_min": 290, "az_max": 330, "el_min": 0, "el_max": 30}]}))
        self.station["positioners"][0]["no_go_config"] = str(path)
        self.write_inputs()
        with patch.object(runtime, "_parse_station_yaml", wraps=runtime._parse_station_yaml) as parser:
            self.load()
        self.assertEqual(parser.call_count, 2)
        self.assertEqual(parser.call_args_list[0].kwargs, {"allow_inline_ca": True})
        self.assertEqual(parser.call_args_list[1].kwargs, {})

    def test_inline_ca_duplicate_keys_still_reject(self):
        for payload in (b'{"amq_ca_pem":"first","amq_ca_pem":"second"}',
                        b'{"amq_ca_pem":"finite","nested":{"key":1,"key":2}}'):
            with self.assertRaises(runtime.RuntimeConfigurationError):
                runtime._parse_station_yaml(payload, allow_inline_ca=True)

    def test_strict_credentials_retain_nonempty_character_and_byte_limits(self):
        for key in ("amq_username", "amq_password"):
            for value in ("x" * 1024, "\U0001f680" * 1024):
                with self.subTest(field=key, category="maximum", bytes=len(value.encode("utf-8"))):
                    context = self.load_station(dict(self.station, **{key: value}))
                    self.assertTrue(context.station[key] == value, "credential data changed")
            for value in ("", "x" * 1025, "\U0001f680" * 1024 + "x", "bad\nvalue", "bad\tvalue",
                          "bad\x00value", "bad\x7fvalue", "bad\ud800value"):
                with self.subTest(field=key, category="invalid", size=len(value)):
                    self.assert_station_rejected(dict(self.station, **{key: value}))

    def test_connect_aggregate_exact_limit_and_optional_host_cost(self):
        username = "\U0001f680" * 1024
        for present, host in ((False, None), (True, None), (True, ""), (True, "h"), (True, "h" * 255)):
            with self.subTest(present=present, host_size=None if host is None else len(host)):
                host_bytes = 0 if host is None else 6 + len(host)
                password_bytes = 8192 - 51 - len(username.encode("utf-8")) - host_bytes
                password = "\U0001f680" * (password_bytes // 4) + "x" * (password_bytes % 4)
                self.assertLessEqual(len(password) + 1, 1024)
                self.assertLessEqual(len(password.encode("utf-8")) + 1, 4096)
                station = dict(self.station, amq_username=username, amq_password=password)
                if present:
                    station["amq_stomp_host"] = host
                self.load_station(station)
                station["amq_password"] += "x"
                self.assert_station_rejected(station)

    def test_station_byte_limit_is_unchanged_with_inline_ca(self):
        self.station["amq_ca_pem"] = "x" * 65536
        payload = json.dumps(self.station).encode()
        payload += b" " * (1_048_576 - len(payload))
        self.assertEqual(len(payload), 1_048_576)
        self.paths["station.yaml"].write_bytes(payload)
        self.load()
        self.paths["station.yaml"].write_bytes(payload + b" ")
        with self.assertRaises(runtime.RuntimeConfigurationError):
            self.load()

    def test_station_structure_limits_are_unchanged_with_inline_ca(self):
        ca = "SYNTHETIC\nPUBLIC"
        for label, allowed, rejected in (
            ("mapping", {"amq_ca_pem": ca, **{str(index): None for index in range(127)}},
             {"amq_ca_pem": ca, **{str(index): None for index in range(128)}}),
            ("list", {"amq_ca_pem": ca, "payload": [None] * 1024},
             {"amq_ca_pem": ca, "payload": [None] * 1025}),
            ("key", {"amq_ca_pem": ca, "k" * 80: None}, {"amq_ca_pem": ca, "k" * 81: None}),
            ("text", {"amq_ca_pem": ca, "payload": "x" * 4096},
             {"amq_ca_pem": ca, "payload": "x" * 4097}),
        ):
            with self.subTest(boundary=label):
                runtime._parse_station_yaml(json.dumps(allowed).encode(), allow_inline_ca=True)
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    runtime._parse_station_yaml(json.dumps(rejected).encode(), allow_inline_ca=True)

    def test_station_depth_and_node_limits_count_inline_ca(self):
        nested = 0
        for _ in range(31):
            nested = [nested]
        document = {"amq_ca_pem": "SYNTHETIC\nPUBLIC", "payload": nested}
        runtime._parse_station_yaml(json.dumps(document).encode(), allow_inline_ca=True)
        document["payload"] = [nested]
        with self.assertRaises(runtime.RuntimeConfigurationError):
            runtime._parse_station_yaml(json.dumps(document).encode(), allow_inline_ca=True)
        # Root, two keys, CA, outer list and eight inner lists count as 13 nodes.
        rows = [[None] * 1024 for _ in range(7)] + [[None] * 1011]
        document["payload"] = rows
        runtime._parse_station_yaml(json.dumps(document).encode(), allow_inline_ca=True)
        rows[-1].append(None)
        with self.assertRaises(runtime.RuntimeConfigurationError):
            runtime._parse_station_yaml(json.dumps(document).encode(), allow_inline_ca=True)

    def test_inline_ca_keeps_finite_and_supported_scalar_rules(self):
        for value in (float("inf"), float("nan"), set(), b"data", complex(1, 2)):
            with self.subTest(category=type(value).__name__):
                with self.assertRaises(runtime.RuntimeConfigurationError):
                    runtime._station_structure({"amq_ca_pem": "SYNTHETIC\nPUBLIC", "other": value},
                                               allow_inline_ca=True)

    def test_strict_data_remains_immutable_private_and_read_once(self):
        self.station["amq_stomp_host"] = "private-host-canary"
        self.write_inputs()
        with patch.object(runtime, "read_regular_bytes", wraps=runtime.read_regular_bytes) as regular:
            with patch.object(runtime, "read_json_document", wraps=runtime.read_json_document) as documents:
                context = self.load()
        self.assertEqual(regular.call_count, 2)
        self.assertEqual(documents.call_count, 2)
        keys = ("amq_dial_address", "amq_tls_server_name", "amq_ca_pem", "amq_stomp_host")
        original = {key: self.station[key] for key in keys}
        rendered = repr(context)
        self.assertTrue(all(key not in rendered and value not in rendered for key, value in original.items()),
                        "strict transport input exposed by repr")
        settings = context.station_settings()
        for key in keys:
            with self.assertRaises(TypeError):
                context.station[key] = "changed"
            settings[key] = "changed"
            self.station[key] = "changed"
        for path in self.paths.values():
            path.write_text("replaced input must not be reread")
        self.assertTrue(all(context.station[key] == value for key, value in original.items()),
                        "admitted strict transport data mutated")
        self.assertTrue(all(context.station_settings()[key] == value for key, value in original.items()),
                        "owner copy changed after source replacement")
        self.assertEqual([row["id"] for row in settings["positioners"]], [7])
        self.assertEqual([row["id"] for row in settings["pixhawk_sensors"]], [9])
        self.assertFalse(hasattr(context, "prepared"))

    def test_ca_path_shaped_data_never_creates_a_ca_read(self):
        self.station["amq_ca_pem"] = str(self.root / "absent-ca.pem")
        self.write_inputs()
        with patch.object(runtime, "read_regular_bytes", wraps=runtime.read_regular_bytes) as reader:
            context = self.load()
        self.assertEqual(reader.call_count, 2)
        self.assertTrue(context.station["amq_ca_pem"] == self.station["amq_ca_pem"], "CA data changed")
        self.assertFalse((self.root / "absent-ca.pem").exists())

    def test_strict_rejection_diagnostics_do_not_expose_canaries(self):
        canary = "PRIVATE-CONFIGURATION-CANARY"
        for key in ("amq_dial_address", "amq_tls_server_name", "amq_ca_pem",
                    "amq_username", "amq_password", "amq_stomp_host"):
            with self.subTest(field=key):
                station = dict(self.station, **{key: canary + "\x00"})
                with self.assertRaises(runtime.RuntimeConfigurationError) as raised:
                    self.load_station(station)
                rendered = str(raised.exception) + repr(raised.exception)
                self.assertTrue(canary not in rendered, "private input exposed by rejection")

    def test_legacy_resolution_does_not_admit_strict_station_inputs(self):
        with patch.object(runtime, "read_regular_bytes", side_effect=AssertionError("unexpected station read")):
            with patch.object(runtime, "read_json_document", side_effect=AssertionError("unexpected JSON read")):
                with patch.object(runtime, "load_runtime_configuration", side_effect=AssertionError("unexpected loader")):
                    self.assertIsNone(runtime.resolve_runtime_request())


if __name__ == "__main__":
    unittest.main()
