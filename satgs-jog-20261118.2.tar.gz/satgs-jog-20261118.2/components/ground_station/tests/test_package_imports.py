import contextlib
from datetime import datetime, timezone
import io
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from satgs import utils


class HttpRetrievalImportTests(unittest.TestCase):
    def test_fetch_tle_keeps_request_arguments_and_response(self):
        calls = []
        response = object()

        def get(url, **kwargs):
            calls.append((url, kwargs))
            return response

        with patch.dict(sys.modules, {"niquests": SimpleNamespace(get=get)}):
            actual = utils.fetch_tle(
                42, datetime(2000, 1, 1, 12, tzinfo=timezone.utc),
                datetime(2000, 1, 2, 12, tzinfo=timezone.utc))
        self.assertIs(actual, response)
        self.assertEqual(calls, [(
            "https://satchecker.cps.iau.org/tools/get-tle-data/",
            {"params": {"id": "42", "id_type": "catalog",
                        "start_date_jd": "2451545.0", "end_date_jd": "2451546.0"},
             "timeout": 5})])

    def test_scrape_url_keeps_request_and_response_parsing(self):
        calls = []

        def get(url, **kwargs):
            calls.append((url, kwargs))
            return SimpleNamespace(text="NAME  \r\nLINE1\r\nLINE2\r\n", status_code=200)

        with patch.dict(sys.modules, {"niquests": SimpleNamespace(get=get)}):
            self.assertEqual(utils.scrape_url(42), ["NAME", "LINE1", "LINE2"])
        self.assertEqual(calls, [(
            "https://celestrak.org/NORAD/elements/gp.php?CATNR=42&FORMAT=TLE",
            {"timeout": 5})])

    def test_http_request_failures_keep_legacy_category(self):
        def fail(*args, **kwargs):
            raise OSError("controlled retrieval failure")

        with patch.dict(sys.modules, {"niquests": SimpleNamespace(get=fail)}):
            with contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(utils.tleTimeoutException):
                    utils.fetch_tle(42)
            with self.assertRaises(utils.tleTimeoutException):
                utils.scrape_url(42)

    def test_scrape_parse_failure_keeps_legacy_category(self):
        client = SimpleNamespace(get=lambda *args, **kwargs: SimpleNamespace(text=None, status_code=200))
        with patch.dict(sys.modules, {"niquests": client}):
            with self.assertRaises(utils.TleFormatError):
                utils.scrape_url(42)


if __name__ == "__main__":
    unittest.main()
