import logging
import yaml
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
from satgs.utils import AzElTrajectory
from satgs.pass_test_runner import PassTestRunner
from satgs.utils import make_az_el_scurves
EL_RATE = 3 #deg/sec
DEFAULT_CFG = Path('~/ground_station/config.yaml').expanduser()

def main():
    
    with open(DEFAULT_CFG) as f:
        config = yaml.safe_load(f)       
        
    XM_SATs = {
        'fm-5': [201.5, 38.7],
        'fm-6': [235.9, 23.5],
        'xm-3': [200.5, 38.9],
        'xm-5': [201.5, 38.7],
        'xm-8': [201.5, 38.7],   
        'test': [15,45],
        
        
    }
    sat_name = 'test'
    angle_delta=15
    rate_dps=1
    update_rate=1
    pad_time = 30 
    el_orientaion = 10
    az_orientation = 30
    t_ax, az_err, el_err = make_az_el_scurves(angle_delta, angle_delta, rate_dps,update_rate,pad_time)
    
    t_ax0 = np.arange(0,el_orientaion+az_orientation, 5)
    az0 = np.zeros(t_ax0.shape)
    el0 = np.ones(t_ax0.shape)*XM_SATs[sat_name][1]
    az0[t_ax0>el_orientaion] = (np.linspace(0, XM_SATs[sat_name][0], np.sum(t_ax0>el_orientaion))) % 360
    el0[t_ax0<=el_orientaion] = np.linspace(30, XM_SATs[sat_name][1], np.sum(t_ax0<=el_orientaion))
    
    trajectory = AzElTrajectory(
        t_steps=np.concatenate((
            t_ax0, t_ax+t_ax0[-1]+1, t_ax0 + t_ax[-1]+t_ax0[-1]+1)), 
        t_ref=datetime.now(timezone.utc),
        az = np.concatenate((az0, 
                             az_err + XM_SATs[sat_name][0],
                            np.flip(az0))), 
        el = np.concatenate((el0,
                            el_err + XM_SATs[sat_name][1],
                            np.flip(el0))), 
    )    
    
    el_mask = 35
    run_name = 'ptu_test'
    no_ptu = False
    no_pixhawk = False
    # dt = 2   
    # duration = 60*2    
    # num_steps = int(duration/dt) 
    
    # geo_az = XM_SATs['xm-8'][0] #235.9
    # geo_el = XM_SATs['xm-8'][1] #23.5
    # trajectory = AzElTrajectory(
    #     t_steps=np.concatenate((np.array((0,)), 10+np.arange(0, num_steps*dt, dt))) , 
    #     t_ref=datetime.now(timezone.utc),
    #     az = np.concatenate((np.zeros(1), np.ones(num_steps)*geo_az)), 
    #     el = np.concatenate((np.ones(1)*geo_el, np.ones(num_steps)*geo_el)), 
    # )

    
    log = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s',datefmt='%b %d %H:%M:%S')
    log.setLevel(logging.DEBUG)


    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)
    log.addHandler(console_handler)

    now = datetime.today()
    logname = f"{run_name}" #_{now.year}-{now.month}-{now.day}_{now.hour}{now.minute}"
    parent_folder = '{}/{}'.format(now.strftime('%m-%d-%Y'),run_name)                
    log_dir = Path(config['logging_dir']) / '{}/{}'.format(parent_folder, logname)        
    if '~' in str(log_dir):
        log_dir = Path(str(log_dir).replace('~', config['home_directory']))                
    if not log_dir.exists():
        log_dir.mkdir(parents=True, mode=0o775) 
    

    file_handler = logging.FileHandler('{}/{}.log'.format(log_dir, logname), 'w+')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)        
    log.addHandler(file_handler)
    
    logging.info("Logging to: {}".format('{}/{}.log'.format(log_dir, logname)))

    
    # Print Arguments 
    try:              
        runner = PassTestRunner(config_file=DEFAULT_CFG, trajectory=trajectory,
                                logname=logname, log_dir=log_dir, el_mask=el_mask,
                                noptu=no_ptu, nopixhawk=no_pixhawk)
                            
        runner.run()
    except Exception as e:
        logging.error(e, stack_info=True, exc_info=True)
        raise ValueError('Pass Runner failed, check logs') # Raise error to bring attention in the queue manager subprocess


if __name__ == '__main__':
    main()
