from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from satgs import station_location_cli as cli
from satgs.station_location import prepare_manual_location


class StationLocationCliTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "station.json"
        self.output = self.root / "new-station.json"
        self.settings = {"ground_station_lat": 42, "ground_station_lon": -71,
                         "ground_station_altm": 12.5,
                         "amq_password": "SYNTHETIC-PRIVATE-CLI-CANARY",
                         "amq_ca_pem": "SYNTHETIC-PUBLIC-CA\n",
                         "positioners": [{"id": 7}]}
        self.raw = json.dumps(self.settings).encode("utf-8")
        self.source.write_bytes(self.raw)
        self.revision = hashlib.sha256(self.raw).hexdigest()

    def arguments(self, **options):
        values = {"station": str(self.source), "output": str(self.output),
                  "expected-revision": self.revision, "latitude-deg": "40",
                  "longitude-deg": "-70", "altitude-m": "15"}
        values.update(options)
        return [f"--{key}={value}" for key, value in values.items()]

    def run_cli(self, arguments=None):
        stream = io.StringIO()
        with redirect_stdout(stream):
            status = cli.main(self.arguments() if arguments is None else arguments)
        self.assertNotIn(self.settings["amq_password"], stream.getvalue())
        self.assertNotIn("amq_password", stream.getvalue())
        return status, json.loads(stream.getvalue())

    def test_api_cli_parity_and_exclusive_private_output(self):
        status, result = self.run_cli()
        self.assertEqual(status, 0)
        expected = prepare_manual_location(self.settings, latitude_deg=40, longitude_deg=-70,
                                           altitude_m=15, expected_revision=self.revision,
                                           current_revision=self.revision)
        self.assertEqual(json.loads(self.output.read_bytes()), expected.settings())
        self.assertEqual(result["location"], expected.location.to_dict())
        self.assertEqual(result["station_revision"], hashlib.sha256(self.output.read_bytes()).hexdigest())
        self.assertEqual(self.output.stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.source.read_bytes(), self.raw)
        self.assertFalse(result["active_run_changed"])
        self.assertTrue(result["owner_reinitialization_required"])
        self.assertEqual(result["owner_state"], "not_checked")
        saved = self.output.read_bytes()
        status, result = self.run_cli()
        self.assertEqual(status, 2)
        self.assertEqual(self.output.read_bytes(), saved)

    def test_actual_shared_operation_is_called(self):
        with patch.object(cli, "prepare_manual_location", wraps=prepare_manual_location) as operation:
            self.assertEqual(self.run_cli()[0], 0)
        operation.assert_called_once()

    def test_unchanged_manual_retry_preserves_identity(self):
        status, first = self.run_cli()
        second_path = self.root / "third-station.json"
        status, second = self.run_cli(self.arguments(station=self.output, output=second_path,
                                                    **{"expected-revision": first["station_revision"]}))
        self.assertEqual(status, 0)
        self.assertFalse(second["changed"])
        self.assertEqual(first["location"], second["location"])

    def test_invalid_stale_and_gps_requests_do_not_create_output(self):
        for options in ({"expected-revision": "b" * 64}, {"latitude-deg": "nan"},
                        {"longitude-deg": "181"}, {"altitude-m": "inf"},
                        {"source": "live-gps"}):
            with self.subTest(options=options):
                self.assertEqual(self.run_cli(self.arguments(**options))[0], 2)
                self.assertFalse(self.output.exists())
                self.assertEqual(self.source.read_bytes(), self.raw)

    def test_output_never_replaces_input_or_follows_links(self):
        link = self.root / "linked-directory"
        link.symlink_to(self.root, target_is_directory=True)
        final_link = self.root / "linked-file"
        final_link.symlink_to(self.source)
        for output in (self.source, final_link, link / "new.json"):
            with self.subTest(output=output.name):
                self.assertEqual(self.run_cli(self.arguments(output=output))[0], 2)
                self.assertEqual(self.source.read_bytes(), self.raw)
        self.assertFalse((self.root / "new.json").exists())

    def test_input_symlink_and_duplicate_keys_are_rejected(self):
        link = self.root / "input-link"
        link.symlink_to(self.source)
        self.assertEqual(self.run_cli(self.arguments(station=link))[0], 2)
        self.source.write_text('{"ground_station_lat": 1, "ground_station_lat": 2}')
        self.assertEqual(self.run_cli()[0], 2)
        self.assertFalse(self.output.exists())

    def test_repeated_arguments_fail_before_read(self):
        with patch.object(cli, "read_regular_bytes", side_effect=AssertionError("unexpected read")):
            self.assertEqual(self.run_cli(self.arguments() + ["--latitude-deg=41"])[0], 2)

    def test_output_failure_is_reported_without_source_change_or_secret(self):
        with patch.object(cli.os, "fsync", side_effect=OSError(self.settings["amq_password"])):
            status, result = self.run_cli()
        self.assertEqual(status, 2)
        self.assertIn("incomplete output may remain", result["error"]["message"])
        self.assertEqual(self.source.read_bytes(), self.raw)
        self.assertTrue(self.output.exists())
        self.assertEqual(self.output.stat().st_mode & 0o777, 0o600)

    def test_unknown_arguments_do_not_echo_values(self):
        status, result = self.run_cli(self.arguments() + ["--unknown=" + self.settings["amq_password"]])
        self.assertEqual(status, 2)
        self.assertEqual(result["error"]["code"], "invalid_location")


if __name__ == "__main__":
    unittest.main()
