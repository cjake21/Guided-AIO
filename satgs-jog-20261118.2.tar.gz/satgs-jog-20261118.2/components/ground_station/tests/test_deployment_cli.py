import contextlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

from satgs import deployment_cli as cli
from satgs import deployment_plan as core


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


def configuration_data():
    return {
        "schema_version": 1,
        "id": "custom-ptu",
        "revision": 1,
        "target": {"id": "pi-1", "environment": "linux-arm64-python311"},
        "selections": [
            {"component": "serialptu", "mode": "install", "provider": "repository", "instance_ids": []}
        ],
    }


def requirements_data():
    return {
        "schema_version": 1,
        "release_id": "r1",
        "configuration_schema": 1,
        "environment": "linux-arm64-python311",
        "components": [
            {
                "component": "serialptu",
                "kind": "software",
                "revision": "rev1",
                "compatibility": "serial-v1",
                "requires": [],
                "source": "release-notes-r1",
            }
        ],
        "removed_components": [],
    }


def inventory_data():
    return {
        "schema_version": 1,
        "id": "evidence-1",
        "target": {"id": "pi-1", "environment": "linux-arm64-python311"},
        "entries": [
            {
                "component": "serialptu",
                "provider": "repository",
                "instance_ids": [],
                "presence": "present",
                "release_id": "r1",
                "revision": "rev1",
                "compatibility": "serial-v1",
                "fresh": True,
                "source": "inspection-1",
                "runtime_state": "unknown",
            }
        ],
    }


def sparse_requirements_data(count):
    data = requirements_data()
    data.pop("removed_components")
    data["components"][0].update(compatibility="compat1", source="release-r1")
    data["components"].extend(
        {"component": f"optional-{index}", "kind": "software", "requires": [], "source": "release-r1"}
        for index in range(1, count)
    )
    return data


def structure_nodes(value):
    if isinstance(value, dict):
        return 1 + len(value) + sum(structure_nodes(item) for item in value.values())
    if isinstance(value, list):
        return 1 + sum(structure_nodes(item) for item in value)
    return 1


@contextlib.contextmanager
def mocked_file_access(payload=b"{}", *, before=None, opened=None, failure=None, link_at=None, retarget_after=None):
    regular = SimpleNamespace(st_mode=stat.S_IFREG, st_size=len(payload), st_dev=10, st_ino=20)
    state = SimpleNamespace(acquired=[], closed=[], attempts=[], reads=[], retargeted=False, prohibited_opened=False)
    directories = {}
    namespace = {("root", "review"): "review", ("review", "parent"): "parent", ("parent", "input.json"): "input"}
    stream = mock.MagicMock()
    stream.__enter__.return_value = stream

    def opening(path, flags, *, dir_fd=None):
        state.attempts.append((path, flags, dir_fd))
        if failure == "open:" + path:
            raise OSError("mocked open failure")
        if path == "/":
            if dir_fd is not None or not flags & os.O_DIRECTORY:
                raise AssertionError("invalid root traversal")
            target = "root"
        else:
            if dir_fd not in directories or "/" in path:
                raise AssertionError("access was not anchored to a directory object")
            key = (directories[dir_fd], path)
            if path == link_at:
                namespace[key] = "/proc/review-mock"
            target = namespace[key]
            if target.startswith("/proc/"):
                if flags & os.O_NOFOLLOW:
                    raise OSError("mocked symlink is not followed")
                state.prohibited_opened = True
                raise AssertionError("prohibited object opened")
            if not flags & os.O_NOFOLLOW:
                raise AssertionError("symlink following was permitted")
        descriptor = 100 + len(state.acquired)
        state.acquired.append(descriptor)
        if flags & os.O_DIRECTORY:
            directories[descriptor] = target
            if path == retarget_after:
                namespace[key] = "/proc/review-mock"
                state.retargeted = True
        elif path != "input.json" or directories[dir_fd] != "parent":
            raise AssertionError("unexpected file access")
        return descriptor

    def stating(path, *, dir_fd, follow_symlinks):
        if path != "input.json" or directories[dir_fd] != "parent" or follow_symlinks:
            raise AssertionError("stat not bound to the input parent")
        if failure == "stat":
            raise OSError("mocked stat failure")
        return before or regular

    def fstating(descriptor):
        if failure == "fstat":
            raise OSError("mocked fstat failure")
        return opened or regular

    def reading(size):
        state.reads.append(size)
        if failure == "read":
            raise OSError("mocked read failure")
        return payload[:size]

    def fdopening(descriptor, mode, *, closefd):
        if failure == "fdopen":
            raise OSError("mocked fdopen failure")
        if mode != "rb" or closefd:
            raise AssertionError("descriptor ownership changed")
        return stream

    def closing(descriptor):
        state.closed.append(descriptor)
        if failure == "close" and descriptor == state.acquired[-1]:
            raise OSError("mocked close failure")

    stream.read.side_effect = reading
    with mock.patch.object(cli.os, "open", side_effect=opening), mock.patch.object(
        cli.os, "stat", side_effect=stating
    ), mock.patch.object(cli.os, "fstat", side_effect=fstating), mock.patch.object(
        cli.os, "fdopen", side_effect=fdopening
    ), mock.patch.object(cli.os, "close", side_effect=closing):
        yield state


class DeploymentCliTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)

    def write_input(self, data, name="input.json"):
        path = self.root / name
        path.write_text(json.dumps(data), encoding="utf-8")
        return str(path)

    def invoke(self, arguments):
        output = io.StringIO()
        errors = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
            try:
                status = cli.main(arguments)
            except SystemExit as error:
                status = error.code
        return status, output.getvalue(), errors.getvalue()

    def assert_invalid(self, arguments):
        status, output, errors = self.invoke([*arguments, "--format", "json"])
        self.assertEqual(status, 2)
        self.assertEqual(errors, "")
        result = json.loads(output)
        self.assertEqual(set(result), {"error"})
        self.assertEqual(result["error"]["code"], "invalid_input")
        return output

    def test_catalog_renders_shared_record_deterministically(self):
        catalog = core.build_catalog(cli.load_manifest())
        first = self.invoke(["catalog", "--format", "json"])
        self.assertEqual(first, self.invoke(["catalog", "--format", "json"]))
        self.assertEqual(first[0], 0)
        self.assertEqual(first[2], "")
        self.assertEqual(json.loads(first[1]), catalog.to_dict())
        status, output, errors = self.invoke(["catalog"])
        self.assertEqual((status, errors), (0, ""))
        self.assertEqual(output, core.render_human(catalog) + "\n")

    def test_help_does_not_read_manifest(self):
        with mock.patch.object(cli, "load_manifest", side_effect=AssertionError("manifest read")):
            for command in ([], ["catalog"], ["validate"], ["plan"], ["compare"]):
                with self.subTest(command=command):
                    status, output, errors = self.invoke([*command, "--help"])
                    self.assertEqual((status, errors), (0, ""))
                    self.assertIn("usage:", output)

    def test_both_presets_dispatch_to_shared_planner(self):
        catalog = core.build_catalog(cli.load_manifest())
        for preset in ("guided_arrow", "full_msel"):
            with self.subTest(preset=preset):
                expected = core.plan_configuration(core.expand_preset(catalog, preset), catalog)
                status, output, errors = self.invoke(["plan", "--preset", preset, "--format", "json"])
                self.assertEqual(status, 3 if expected.blocked else 0)
                self.assertEqual(errors, "")
                self.assertEqual(json.loads(output), expected.to_dict())

    def test_validate_and_plan_share_configuration_evidence_semantics(self):
        config_path = self.write_input(configuration_data(), "config.json")
        inventory_path = self.write_input(inventory_data(), "inventory.json")
        requirements_path = self.write_input(requirements_data(), "requirements.json")
        arguments = [
            "--config", config_path, "--inventory", inventory_path,
            "--requirements", requirements_path, "--format", "json",
        ]
        catalog = core.build_catalog(cli.load_manifest())
        expected = core.plan_configuration(
            core.parse_configuration(configuration_data(), catalog),
            catalog,
            inventory=core.parse_inventory(inventory_data(), catalog),
            requirements=core.parse_requirements(requirements_data(), catalog),
        )
        for command in ("validate", "plan"):
            with self.subTest(command=command):
                status, output, errors = self.invoke([command, *arguments])
                self.assertEqual((status, errors), (3 if expected.blocked else 0, ""))
                self.assertEqual(json.loads(output), expected.to_dict())

    def test_compare_dispatches_explicit_candidate_to_shared_comparison(self):
        config_path = self.write_input(configuration_data(), "config.json")
        requirements_path = self.write_input(requirements_data(), "requirements.json")
        catalog = core.build_catalog(cli.load_manifest())
        expected = core.compare_release(
            core.parse_configuration(configuration_data(), catalog),
            catalog,
            core.parse_requirements(requirements_data(), catalog),
        )
        status, output, errors = self.invoke([
            "compare", "--config", config_path, "--requirements", requirements_path, "--format", "json",
        ])
        self.assertEqual((status, errors), (3 if expected.blocked else 0, ""))
        self.assertEqual(json.loads(output), expected.to_dict())

    def test_blocked_result_has_distinct_status(self):
        config_path = self.write_input(configuration_data(), "config.json")
        requirements = requirements_data()
        requirements["environment"] = "linux-armv7-python310"
        requirements_path = self.write_input(requirements, "requirements.json")
        status, output, errors = self.invoke([
            "plan", "--config", config_path, "--requirements", requirements_path, "--format", "json",
        ])
        self.assertEqual((status, errors), (3, ""))
        self.assertIs(json.loads(output)["blocked"], True)
        self.assertNotIn("error", json.loads(output))

    def test_incomplete_configuration_without_release_remains_reviewable(self):
        config_path = self.write_input(configuration_data())
        status, output, errors = self.invoke(["plan", "--config", config_path, "--format", "json"])
        self.assertEqual((status, errors), (0, ""))
        self.assertIsInstance(json.loads(output), dict)

    def test_only_explicit_planning_commands_and_options_are_accepted(self):
        cases = (
            [], ["install"], ["apply"], ["update"], ["start"], ["probe"], ["connect"],
            ["plan"], ["validate"], ["compare", "--config", "missing"],
            ["plan", "--preset", "unknown"],
            ["plan", "--preset", "guided_arrow", "--config", "missing"],
            ["plan", "--pre", "guided_arrow"],
            ["catalog", "--manifest", "missing"],
        )
        with mock.patch.object(cli, "load_manifest", side_effect=AssertionError("manifest read")):
            for arguments in cases:
                with self.subTest(arguments=arguments):
                    self.assert_invalid(arguments)

    def test_diagnostics_do_not_echo_paths_values_or_core_exceptions(self):
        marker = "secret-marker-\x1b[31m"
        output = self.assert_invalid(["plan", "--config", str(self.root / marker)])
        self.assertNotIn(marker, output)
        output = self.assert_invalid([marker])
        self.assertNotIn(marker, output)
        config_path = self.write_input(configuration_data())
        for error in (core.InputError(marker), cli.DeploymentError(marker)):
            with self.subTest(error=type(error).__name__), mock.patch.object(cli, "load_manifest", side_effect=error):
                output = self.assert_invalid(["validate", "--config", config_path])
                self.assertNotIn(marker, output)

    def test_repeated_input_and_format_options_are_rejected_without_reads(self):
        cases = (
            ["plan", "--config", "first", "--config", "second"],
            ["plan", "--config=first", "--config=second"],
            ["plan", "--config", "first", "--config=second"],
            ["plan", "--preset", "guided_arrow", "--preset=full_msel"],
            ["validate", "--config", "first", "--inventory", "one", "--inventory=two"],
            ["compare", "--config", "first", "--requirements=one", "--requirements", "two"],
            ["catalog", "--format", "human"],
            ["catalog", "--format=human"],
        )
        with mock.patch.object(cli, "load_manifest", side_effect=AssertionError("manifest read")):
            for arguments in cases:
                with self.subTest(arguments=arguments):
                    self.assert_invalid(arguments)

    def test_invalid_json_encodings_constants_duplicates_and_shapes(self):
        payloads = (
            b"{", b"\xff", b'{"schema_version":1,"schema_version":1}',
            b'{"nested":{"x":1,"x":2}}', b"NaN", b"Infinity", b"-Infinity",
            b"1e999", b"-1e999",
            b"[]", b"null", b"true", b"123", b'"string"',
        )
        path = self.root / "invalid.json"
        for payload in payloads:
            with self.subTest(payload=payload):
                path.write_bytes(payload)
                self.assert_invalid(["validate", "--config", str(path)])

    def test_json_byte_depth_and_node_limits(self):
        path = self.root / "bounded.json"
        path.write_bytes(b"{}" + b" " * (cli.MAX_INPUT_BYTES - 2))
        self.assertEqual(cli._read_json(str(path)), {})
        path.write_bytes(b" " * (cli.MAX_INPUT_BYTES + 1))
        with self.assertRaises(cli.CliInputError):
            cli._read_json(str(path))
        path.write_text("[" * cli.MAX_INPUT_DEPTH + "0" + "]" * cli.MAX_INPUT_DEPTH)
        cli._read_json(str(path))
        path.write_text("[" * (cli.MAX_INPUT_DEPTH + 1) + "0" + "]" * (cli.MAX_INPUT_DEPTH + 1))
        with self.assertRaises(cli.CliInputError):
            cli._read_json(str(path))
        path.write_text(json.dumps([0] * cli.MAX_INPUT_NODES))
        with self.assertRaises(cli.CliInputError):
            cli._read_json(str(path))
        path.write_text(json.dumps({"text": '["' * 100}))
        self.assertEqual(cli._read_json(str(path)), {"text": '["' * 100})

    def test_public_document_reader_preserves_exact_bytes_with_one_read(self):
        payload = b' { "name": "pointing", "revision": 1 } '
        with mocked_file_access(payload) as state:
            admitted, document = cli.read_json_document("/review/parent/input.json")
        self.assertEqual(admitted, payload)
        self.assertEqual(document, {"name": "pointing", "revision": 1})
        self.assertEqual(state.reads, [cli.MAX_INPUT_BYTES + 1])
        self.assertEqual(state.closed, list(reversed(state.acquired)))
        self.assertEqual(sum(not flags & os.O_DIRECTORY for _, flags, _ in state.attempts), 1)

    def test_public_document_reader_always_enforces_json_checks(self):
        invalid = (b'not-json', b'{"a": 1, "a": 2}', b'{"a": NaN}',
                   b'"' + bytes([255]) + b'"', b'[' * 33 + b']' * 33,
                   b'[' + b'0,' * 1024 + b'0]')
        for payload in invalid:
            with self.subTest(payload=payload[:20]), mocked_file_access(payload) as state:
                with self.assertRaises(cli.CliInputError):
                    cli.read_json_document("/review/parent/input.json")
                self.assertEqual(state.closed, list(reversed(state.acquired)))

    def test_regular_byte_reader_shares_bounded_safe_acquisition_without_json_parse(self):
        payload = b'site: synthetic-station'
        with mocked_file_access(payload) as state:
            self.assertEqual(cli.read_regular_bytes("/review/parent/input.json"), payload)
        self.assertEqual(state.reads, [cli.MAX_INPUT_BYTES + 1])
        self.assertEqual(state.closed, list(reversed(state.acquired)))
        for filename in ("/dev/null", "/proc/cpuinfo", "/sys/input", "-"):
            with self.subTest(filename=filename), mock.patch.object(cli.os, "open") as opening:
                with self.assertRaises(cli.CliInputError):
                    cli.read_regular_bytes(filename)
                opening.assert_not_called()
        oversized = b'x' * (cli.MAX_INPUT_BYTES + 1)
        with mocked_file_access(oversized, before=SimpleNamespace(st_mode=stat.S_IFREG, st_size=1, st_dev=10, st_ino=20),
                                opened=SimpleNamespace(st_mode=stat.S_IFREG, st_size=1, st_dev=10, st_ino=20)) as state:
            with self.assertRaisesRegex(cli.CliInputError, "byte limit"):
                cli.read_regular_bytes("/review/parent/input.json")
            self.assertEqual(state.reads, [cli.MAX_INPUT_BYTES + 1])
            self.assertEqual(state.closed, list(reversed(state.acquired)))

    def test_prohibited_roots_are_rejected_without_filesystem_access(self):
        paths = ("-", "/dev/null", "/proc/version", "/sys/kernel", "/tmp/../proc/review.json")
        with mock.patch.object(cli.os, "open", side_effect=AssertionError("prohibited input opened")), mock.patch.object(
            cli.os, "stat", side_effect=AssertionError("prohibited input observed")
        ):
            for path in paths:
                with self.subTest(path=path), self.assertRaises(cli.CliInputError):
                    cli._read_json(path)

    def test_nonregular_final_inputs_are_rejected_before_file_open(self):
        for mode in (stat.S_IFDIR, stat.S_IFLNK, stat.S_IFIFO, stat.S_IFCHR, stat.S_IFBLK, stat.S_IFSOCK):
            before = SimpleNamespace(st_mode=mode, st_size=0)
            with self.subTest(mode=mode), mocked_file_access(before=before) as access:
                with self.assertRaises(cli.CliInputError):
                    cli._read_json("/review/parent/input.json")
                self.assertTrue(all(flags & os.O_DIRECTORY for _, flags, _ in access.attempts))
                self.assertEqual(access.reads, [])
                self.assertIs(access.prohibited_opened, False)
                self.assertEqual(access.closed, list(reversed(access.acquired)))

    def test_safe_open_flags_and_post_open_type_validation(self):
        path = self.write_input(configuration_data())
        real_open = os.open
        with mock.patch.object(cli.os, "open", wraps=real_open) as opened:
            self.assertEqual(cli._read_json(path), configuration_data())
        flags = opened.call_args.args[1]
        self.assertTrue(flags & os.O_NOFOLLOW)
        self.assertTrue(flags & os.O_NONBLOCK)
        self.assertTrue(flags & os.O_CLOEXEC)
        for call in opened.call_args_list[:-1]:
            self.assertTrue(call.args[1] & os.O_DIRECTORY)
            self.assertTrue(call.args[1] & os.O_PATH)
            self.assertTrue(call.args[1] & os.O_NOFOLLOW)
        changed_file = SimpleNamespace(st_mode=stat.S_IFIFO, st_size=0)
        with mocked_file_access(opened=changed_file) as access:
            with self.assertRaises(cli.CliInputError):
                cli._read_json("/review/parent/input.json")
            self.assertEqual(len(access.acquired), 4)
            self.assertEqual(access.reads, [])
            self.assertEqual(access.closed, list(reversed(access.acquired)))

    def test_regular_file_replacement_is_rejected_before_read(self):
        path = self.write_input(configuration_data())
        original = Path(path).stat()
        replacement = SimpleNamespace(
            st_mode=stat.S_IFREG,
            st_size=original.st_size,
            st_dev=original.st_dev,
            st_ino=original.st_ino + 1,
        )
        with mock.patch.object(cli.os, "fstat", return_value=replacement), mock.patch.object(
            cli.os, "fdopen", side_effect=AssertionError("replacement file read")
        ), self.assertRaises(cli.CliInputError):
            cli._read_json(path)

    def test_absolute_relative_and_normalized_regular_paths(self):
        path = self.write_input(configuration_data())
        (self.root / "child").mkdir()
        for spelling in (path, os.path.relpath(path), str(self.root / "child" / ".." / "input.json")):
            with self.subTest(path=spelling):
                self.assertEqual(cli._read_json(spelling), configuration_data())

    def test_unsupported_secure_access_fails_closed(self):
        with mock.patch.object(cli, "_DIR_FD_SUPPORTED", False), mock.patch.object(
            cli.os, "open", side_effect=AssertionError("unsupported platform opened input")
        ), self.assertRaises(cli.CliInputError):
            cli._read_json("/review/parent/input.json")
        with mock.patch.object(cli.os, "O_PATH", create=True):
            del cli.os.O_PATH
            with mock.patch.object(cli.os, "open", side_effect=AssertionError("missing flag fallback")), self.assertRaises(
                cli.CliInputError
            ):
                cli._read_json("/review/parent/input.json")

    def test_symlink_ancestors_and_final_replacements_never_read_content(self):
        for component in ("review", "parent", "input.json"):
            with self.subTest(component=component), mocked_file_access(link_at=component) as access:
                with self.assertRaises(cli.CliInputError):
                    cli._read_json("/review/parent/input.json")
                attempted = access.attempts[-1]
                self.assertEqual(attempted[0], component)
                self.assertTrue(attempted[1] & os.O_NOFOLLOW)
                self.assertEqual(access.reads, [])
                self.assertEqual(access.closed, list(reversed(access.acquired)))

    def test_mutable_parent_and_canonical_ancestor_retarget_cannot_redirect_read(self):
        for component in ("review", "parent"):
            with self.subTest(component=component), mocked_file_access(
                b'{"origin":"held-directory-object"}', retarget_after=component
            ) as access:
                result = cli._read_json("/review/parent/input.json")
                self.assertIs(access.retargeted, True)
                self.assertEqual(result, {"origin": "held-directory-object"})
                self.assertIs(access.prohibited_opened, False)
                self.assertEqual([path for path, _, _ in access.attempts], ["/", "review", "parent", "input.json"])
                self.assertEqual([parent for _, _, parent in access.attempts], [None, 100, 101, 102])
                self.assertEqual(access.reads, [cli.MAX_INPUT_BYTES + 1])
                self.assertEqual(access.closed, [103, 102, 101, 100])

    def test_all_acquired_descriptors_close_at_each_failure_point(self):
        failures = ("open:/", "open:review", "open:parent", "stat", "open:input.json", "fstat", "fdopen", "read", "close")
        for failure in failures:
            with self.subTest(failure=failure), mocked_file_access(failure=failure) as access:
                with self.assertRaises(cli.CliInputError):
                    cli._read_json("/review/parent/input.json")
                self.assertEqual(access.closed, list(reversed(access.acquired)))
        with mocked_file_access(b"{") as access:
            with self.assertRaises(cli.CliInputError):
                cli._read_json("/review/parent/input.json")
            self.assertEqual(access.closed, list(reversed(access.acquired)))

    def test_identity_type_and_growth_rejected_before_content_read(self):
        for field, value in (("st_ino", 21), ("st_dev", 11), ("st_mode", stat.S_IFCHR), ("st_size", cli.MAX_INPUT_BYTES + 1)):
            opened = SimpleNamespace(st_mode=stat.S_IFREG, st_size=2, st_dev=10, st_ino=20)
            setattr(opened, field, value)
            with self.subTest(field=field), mocked_file_access(opened=opened) as access:
                with self.assertRaises(cli.CliInputError):
                    cli._read_json("/review/parent/input.json")
                self.assertEqual(access.reads, [])
                self.assertEqual(access.closed, [103, 102, 101, 100])

    def test_file_growth_during_read_is_bounded_and_rejected(self):
        metadata = SimpleNamespace(st_mode=stat.S_IFREG, st_size=2, st_dev=10, st_ino=20)
        with mocked_file_access(b" " * (cli.MAX_INPUT_BYTES + 20), before=metadata, opened=metadata) as access:
            with self.assertRaises(cli.CliInputError):
                cli._read_json("/review/parent/input.json")
            self.assertEqual(access.reads, [cli.MAX_INPUT_BYTES + 1])
            self.assertEqual(access.closed, [103, 102, 101, 100])

    def test_shared_structure_limits_match_cli_without_mutating_inputs(self):
        at_nodes = [[0] * 1023 for _ in range(7)] + [[0] * 1019 + [{"key": 0}]]
        beyond_nodes = [*at_nodes[:-1], [*at_nodes[-1], 0]]
        nested = 0
        for _ in range(32):
            nested = [nested]
        cases = (
            (at_nodes, True), (beyond_nodes, False), (nested, True), ([nested], False),
            ([0] * 1024, True), ([0] * 1025, False),
            ({str(i): None for i in range(64)}, True), ({str(i): None for i in range(65)}, False),
            ({"x" * 80: None}, True), ({"x" * 81: None}, False),
            ("x" * 256, True), ("x" * 257, False),
        )
        for index, (document, accepted) in enumerate(cases):
            before = json.dumps(document)
            path = self.write_input(document)
            with self.subTest(case=index):
                if accepted:
                    core.validate_document_structure(document)
                    self.assertEqual(cli._read_json(path), document)
                else:
                    with self.assertRaises(core.InputError):
                        core.validate_document_structure(document)
                    with self.assertRaises(cli.CliInputError):
                        cli._read_json(path)
                self.assertEqual(json.dumps(document), before)

    def test_review_629_and_630_requirement_records_match_api_and_cli(self):
        catalog = core.build_catalog(cli.load_manifest())
        for count in (629, 630):
            document = {
                "schema_version": 1, "release_id": "r1", "configuration_schema": 1,
                "environment": "linux-arm64-python311",
                "components": [
                    {"component": "serialptu" if index == 0 else f"optional-{index}", "kind": "software",
                     "revision": "rev1", "compatibility": "compat1", "requires": [], "source": "release-r1"}
                    for index in range(count)
                ],
            }
            before = json.dumps(document)
            path = self.write_input(document, "requirements.json")
            arguments = ["compare", "--config", self.write_input(configuration_data()), "--requirements", path, "--format", "json"]
            with self.subTest(count=count):
                if count == 629:
                    core.parse_requirements(document, catalog)
                    self.assertEqual(cli._read_json(path), document)
                    self.assertEqual(self.invoke(arguments)[0], 0)
                else:
                    with self.assertRaises(core.InputError):
                        core.parse_requirements(document, catalog)
                    with self.assertRaises(cli.CliInputError):
                        cli._read_json(path)
                    self.assertEqual(self.invoke(arguments)[0], 2)
                self.assertEqual(json.dumps(document), before)

    def test_pass_runner_unused_omissions_have_shared_human_json_status_and_reasons(self):
        catalog = core.build_catalog(cli.load_manifest())
        prerequisites = ("dsi_instruments", "cyberpowerpdu", "signal_hound")
        for omitted in (*[(component,) for component in prerequisites], prerequisites):
            data = configuration_data()
            data["selections"] = [{"component": "execution.pass_runner", "mode": "install", "provider": "satgs"}]
            data["selections"].extend({"component": component, "mode": "omit", "provider": "repository"} for component in omitted)
            path = self.write_input(data)
            expected = core.plan_configuration(core.parse_configuration(data, catalog), catalog)
            for output_format in ("human", "json"):
                with self.subTest(omitted=omitted, format=output_format):
                    status, output, errors = self.invoke(["plan", "--config", path, "--format", output_format])
                    self.assertEqual((status, errors), (0, ""))
                    rendered = core.render_json(expected) if output_format == "json" else core.render_human(expected)
                    self.assertEqual(output, rendered + "\n")
                    for component in omitted:
                        self.assertIn(component, output)
                    self.assertIn("execution.pass_runner", output)
                    self.assertIn("src/satgs/pass_runner.py", output)

    def test_guided_arrow_cli_keeps_queue_source_blockers_in_both_formats(self):
        expected_components = {"recording.signal_hound", "processing.msel_post_processing"}
        for output_format in ("human", "json"):
            with self.subTest(format=output_format):
                status, output, errors = self.invoke(["plan", "--preset", "guided_arrow", "--format", output_format])
                self.assertEqual((status, errors), (3, ""))
                self.assertIn("orchestration.queue_manager", output)
                self.assertIn("ground_station/src/satgs/queue_manager.py:739-740", output)
                self.assertIn("ground_station/src/satgs/queue_manager.py:773-779", output)
                self.assertNotIn("unconditionally", output)
                if output_format == "json":
                    data = json.loads(output)
                    self.assertEqual({item["component"] for item in data["diagnostics"]
                                      if item["code"] == "prerequisite_conflict"}, expected_components)
                    self.assertFalse(data["apply_supported"])

    def test_sparse_requirements_remain_usable_by_plan_and_compare(self):
        catalog = core.build_catalog(cli.load_manifest())
        config_data = configuration_data()
        config_data["id"] = "boundary"
        config_data["selections"][0].pop("instance_ids")
        configuration = core.parse_configuration(config_data, catalog)
        config_before = json.dumps(config_data)
        configuration_before = configuration.to_dict()
        config_path = self.write_input(config_data, "configuration.json")
        for count, raw_nodes, normalized_nodes in ((629, 5676, 8190), (630, 5685, 8203)):
            data = sparse_requirements_data(count)
            before = json.dumps(data)
            path = self.write_input(data, "sparse-requirements.json")
            self.assertEqual(structure_nodes(data), raw_nodes)
            self.assertEqual(cli._read_json(path), data)
            requirements = core.parse_requirements(data, catalog)
            normalized = requirements.to_dict()
            self.assertEqual(structure_nodes(normalized), normalized_nodes)
            for command, operation in (("plan", core.plan_configuration), ("compare", core.compare_release)):
                expected = operation(configuration, catalog, requirements=requirements)
                result = expected.to_dict()
                self.assertEqual(result["configuration"], configuration_before)
                self.assertEqual(result["candidate_release_id"], "r1")
                self.assertIsNone(result["inventory_id"])
                self.assertIs(result["planning_only"], True)
                self.assertIs(result["apply_supported"], False)
                self.assertIs(result["complete"], False)
                self.assertIs(result["blocked"], False)
                self.assertEqual([item["component"] for item in result["outcomes"]], ["serialptu"])
                self.assertEqual(result["outcomes"][0]["outcome"], "proposed_install")
                if command == "compare":
                    self.assertEqual(result["unselected_optional"], sorted(f"optional-{index}" for index in range(1, count)))
                    self.assertEqual([item["component"] for item in result["changes"]], ["serialptu"])
                for output_format in ("human", "json"):
                    arguments = [command, "--config", config_path, "--requirements", path, "--format", output_format]
                    with self.subTest(count=count, command=command, format=output_format):
                        actual = self.invoke(arguments)
                        rendered = core.render_json(expected) if output_format == "json" else core.render_human(expected)
                        self.assertEqual(actual, (0, rendered + "\n", ""))
                        self.assertEqual(self.invoke(arguments), actual)
                self.assertEqual(requirements.to_dict(), normalized)
            self.assertEqual(json.dumps(data), before)
        self.assertEqual(json.dumps(config_data), config_before)
        self.assertEqual(configuration.to_dict(), configuration_before)

    def test_expanded_requirements_resubmitted_as_raw_input_keep_the_node_limit(self):
        catalog = core.build_catalog(cli.load_manifest())
        normalized = core.parse_requirements(sparse_requirements_data(630), catalog).to_dict()
        self.assertEqual(structure_nodes(normalized), 8203)
        path = self.write_input(normalized, "expanded-requirements.json")
        with self.assertRaises(core.InputError):
            core.parse_requirements(normalized, catalog)
        with self.assertRaises(cli.CliInputError):
            cli._read_json(path)
        config_path = self.write_input(configuration_data(), "configuration.json")
        for command in ("plan", "compare"):
            for output_format in ("human", "json"):
                with self.subTest(command=command, format=output_format):
                    status, output, errors = self.invoke([
                        command, "--config", config_path, "--requirements", path, "--format", output_format,
                    ])
                    self.assertEqual((status, errors), (2, ""))
                    if output_format == "json":
                        self.assertEqual(json.loads(output)["error"]["code"], "invalid_input")
                    else:
                        self.assertTrue(output.startswith("Invalid input:"))

    def test_required_hardware_human_and_json_keep_same_reasons_and_status(self):
        requirements = requirements_data()
        requirements["components"][0].update(requires=["review-sensor"], source="release-r1")
        requirements["components"].append({"component": "review-sensor", "kind": "hardware", "revision": "rev1",
                                           "compatibility": "sensor1", "requires": [], "source": "hardware-r1"})
        config_path = self.write_input(configuration_data())
        requirements_path = self.write_input(requirements, "requirements.json")
        for output_format in ("human", "json"):
            with self.subTest(format=output_format):
                status, output, errors = self.invoke([
                    "plan", "--config", config_path, "--requirements", requirements_path, "--format", output_format,
                ])
                self.assertEqual((status, errors), (3, ""))
                for marker in ("review-sensor", "serialptu", "supplied-release", "release-r1"):
                    self.assertIn(marker, output)

    def test_commands_run_headlessly_under_no_effects_audit_guard(self):
        config_path = self.write_input(configuration_data(), "config.json")
        inventory_path = self.write_input(inventory_data(), "inventory.json")
        requirements_path = self.write_input(requirements_data(), "requirements.json")
        code = r'''
import builtins
import importlib.util
import os
import sys

sys.path.append(sys.argv[1])
source_root = os.path.realpath(sys.argv[1])
stdlib_root = os.path.dirname(os.path.realpath(os.__file__))
allowed_files = {os.path.realpath(os.path.join(source_root, "..", "config", "deployment_profiles.json"))}
for filename in ("__init__.py", "deployment.py", "deployment_plan.py", "deployment_cli.py"):
    source = os.path.join(source_root, "satgs", filename)
    allowed_files.add(source)
    allowed_files.add(importlib.util.cache_from_source(source))
for index, argument in enumerate(sys.argv):
    if argument in ("--config", "--inventory", "--requirements"):
        allowed_files.add(os.path.realpath(sys.argv[index + 1]))
allowed_directories = {"/"}
for filename in allowed_files:
    parent = os.path.dirname(filename)
    while parent != "/":
        allowed_directories.add(parent)
        parent = os.path.dirname(parent)
real_open, real_close = os.open, os.close
descriptor_paths = {}
pending_opens = []
def guarded_open(path, flags, mode=0o777, *, dir_fd=None):
    if dir_fd is None:
        resolved = os.path.abspath(os.fsdecode(path))
    else:
        if dir_fd not in descriptor_paths:
            raise AssertionError("untracked directory descriptor")
        resolved = os.path.normpath(os.path.join(descriptor_paths[dir_fd], os.fsdecode(path)))
    if flags & os.O_DIRECTORY:
        if resolved not in allowed_directories:
            raise AssertionError("undeclared directory access attempted")
    elif resolved not in allowed_files and not resolved.startswith(stdlib_root + "/"):
        raise AssertionError("undeclared file access attempted")
    pending_opens.append(resolved)
    try:
        descriptor = real_open(path, flags, mode, dir_fd=dir_fd)
    finally:
        pending_opens.pop()
    descriptor_paths[descriptor] = resolved
    return descriptor
def guarded_close(descriptor):
    try:
        return real_close(descriptor)
    finally:
        descriptor_paths.pop(descriptor, None)
os.open, os.close = guarded_open, guarded_close
os.supports_dir_fd = os.supports_dir_fd | {guarded_open}
write_flags = os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC
blocked_events = {
    "os.chdir", "os.chmod", "os.chown", "os.fchmod", "os.fchown", "os.lchown",
    "os.link", "os.mkdir", "os.mkfifo", "os.mknod", "os.remove", "os.removexattr",
    "os.rename", "os.replace", "os.rmdir", "os.setxattr", "os.symlink", "os.truncate",
    "os.utime", "os.fork", "os.forkpty", "os.kill", "os.killpg", "os.posix_spawn",
    "os.startfile", "os.system", "subprocess.Popen", "os.putenv", "os.unsetenv",
}
def audit(event, args):
    if event == "open":
        path, mode, flags = args
        if (isinstance(mode, str) and any(char in mode for char in "wax+")) or (
            isinstance(flags, int) and flags & write_flags
        ):
            raise AssertionError("file write attempted")
        if isinstance(path, (str, bytes)):
            resolved = pending_opens[-1] if pending_opens else os.path.abspath(os.fsdecode(path))
            if any(resolved == root or resolved.startswith(root + "/") for root in ("/dev", "/proc", "/sys")):
                raise AssertionError("device or pseudo-filesystem access attempted")
            directory_open = flags & os.O_DIRECTORY and resolved in allowed_directories
            if not directory_open and resolved not in allowed_files and not resolved.startswith(stdlib_root + "/"):
                raise AssertionError("undeclared file read attempted")
    if event in blocked_events or event.startswith(("socket.", "os.exec", "os.spawn")):
        raise AssertionError("side effect attempted")
sys.addaudithook(audit)
original_import = builtins.__import__
project_modules = {"satgs", "satgs.deployment", "satgs.deployment_plan", "satgs.deployment_cli"}
def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    root = name.split(".", 1)[0]
    if level == 0:
        if root == "satgs" and name not in project_modules:
            raise AssertionError("runtime project import attempted")
        if root != "satgs" and (root not in sys.stdlib_module_names or root == "tkinter"):
            raise AssertionError("optional or third-party import attempted")
    return original_import(name, globals, locals, fromlist, level)
builtins.__import__ = guarded_import
from satgs.deployment_cli import main
raise SystemExit(main(sys.argv[2:]))
'''
        cases = (
            ["catalog", "--format", "json"],
            ["plan", "--preset", "guided_arrow", "--format", "json"],
            ["plan", "--preset", "full_msel", "--format", "json"],
            ["validate", "--config", config_path, "--inventory", inventory_path, "--format", "json"],
            ["compare", "--config", config_path, "--requirements", requirements_path,
             "--inventory", inventory_path, "--format", "json"],
        )
        for arguments in cases:
            with self.subTest(command=arguments[0]):
                result = subprocess.run(
                    [sys.executable, "-I", "-S", "-B", "-c", code, str(REPOSITORY_ROOT / "src"), *arguments],
                    cwd=self.root,
                    env={},
                    stdin=subprocess.DEVNULL,
                    check=False,
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                expected_status = 3 if "--inventory" in arguments or "guided_arrow" in arguments else 0
                self.assertEqual(result.returncode, expected_status, result.stderr + result.stdout)
                self.assertEqual(result.stderr, "")
                document = json.loads(result.stdout)
                self.assertIsInstance(document, dict)
                if expected_status == 3:
                    self.assertIs(document["blocked"], True)

        guard_directory = self.root / "module-guard"
        guard_directory.mkdir()
        bootstrap = code.replace(
            "sys.path.append(sys.argv[1])\nsource_root = os.path.realpath(sys.argv[1])",
            f"source_root = {str(REPOSITORY_ROOT / 'src')!r}",
        ).removesuffix("from satgs.deployment_cli import main\nraise SystemExit(main(sys.argv[2:]))\n")
        self.assertNotIn("raise SystemExit(main", bootstrap)
        (guard_directory / "sitecustomize.py").write_text(bootstrap, encoding="utf-8")
        module_environment = {
            "PYTHONPATH": os.pathsep.join((str(guard_directory), str(REPOSITORY_ROOT / "src"))),
            "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
        }
        catalog = core.build_catalog(cli.load_manifest())
        sparse = sparse_requirements_data(630)
        sparse_path = self.write_input(sparse, "sparse-requirements.json")
        requirements = core.parse_requirements(sparse, catalog)
        expanded_path = self.write_input(requirements.to_dict(), "expanded-requirements.json")
        configuration = core.parse_configuration(configuration_data(), catalog)
        for command, operation in (("plan", core.plan_configuration), ("compare", core.compare_release)):
            expected = operation(configuration, catalog, requirements=requirements)
            for output_format in ("human", "json"):
                for path, expected_status in ((sparse_path, 0), (expanded_path, 2)):
                    with self.subTest(command=command, format=output_format, expected_status=expected_status):
                        result = subprocess.run(
                            [sys.executable, "-B", "-s", "-m", "satgs.deployment_cli", command,
                             "--config", config_path, "--requirements", path, "--format", output_format],
                            cwd=self.root, env=module_environment, stdin=subprocess.DEVNULL,
                            check=False, capture_output=True, text=True, timeout=10,
                        )
                        self.assertEqual(result.returncode, expected_status, result.stderr + result.stdout)
                        self.assertEqual(result.stderr, "")
                        if expected_status == 0:
                            rendered = core.render_json(expected) if output_format == "json" else core.render_human(expected)
                            self.assertEqual(result.stdout, rendered + "\n")
                        elif output_format == "json":
                            self.assertEqual(json.loads(result.stdout)["error"]["code"], "invalid_input")
                        else:
                            self.assertTrue(result.stdout.startswith("Invalid input:"))


if __name__ == "__main__":
    unittest.main()
