import builtins
from contextlib import ExitStack, redirect_stdout, redirect_stderr
from datetime import datetime, timedelta, timezone
import io
import itertools
import logging
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from types import SimpleNamespace

import runtime_test_support as support


class PassRunnerCapabilityTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.inputs = support.Inputs(Path(self.temporary.name))
        self.context = self.inputs.load()
        self.logger = logging.getLogger()
        self.before_handlers = tuple(self.logger.handlers)
        self.before_level = self.logger.level
        self.before_signals = {number: signal.getsignal(number) for number in (signal.SIGINT, signal.SIGTERM)}
        self.stack = support.controlled_runner()
        self.module = self.stack.__enter__()
        self.addCleanup(self.stack.__exit__, None, None, None)
        self.addCleanup(self.assert_owned_state_restored)

    def assert_owned_state_restored(self):
        self.assertEqual(tuple(self.logger.handlers), self.before_handlers)
        self.assertEqual(self.logger.level, self.before_level)
        self.assertEqual({number: signal.getsignal(number) for number in self.before_signals}, self.before_signals)
        self.assertFalse(any(thread.name == 'satgs-truth' and thread.is_alive() for thread in threading.enumerate()))
        self.assertEqual(support.FORBIDDEN_IMPORTS, [])

    def construct(self, **options):
        return self.module.PassRunner(self.inputs.paths['station.yaml'], self.inputs.paths['tle.csv'],
                                      28626, runtime_context=self.context, nodate=True, **options)

    def acquired(self):
        runner = self.construct()
        self.addCleanup(runner.shutdown)
        return runner

    def event_names(self):
        return [name for name, details in support.EVENTS]

    def test_ptu_policy_preflight_uses_real_validator_before_resources(self):
        from ptu_control.pointing import PointingPolicy
        self.assertEqual(PointingPolicy.__module__, 'ptu_control.pointing')
        policy = PointingPolicy.from_settings(self.context.station, 7, 15,
                                             self.context.no_go_data)
        policy.validate_tle(self.context.tle.tle)
        runner = self.acquired()
        self.assertEqual(runner.ptu_client.ptu_ids, [policy.manager_id])

    def test_missing_ptu_policy_rejects_before_transport_preparation(self):
        self.inputs.station['positioners'][0].pop('pointing_context')
        self.inputs.write()
        self.context = self.inputs.load()
        with self.assertRaises(self.module.RuntimeConfigurationError):
            self.construct()
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_mismatched_ptu_tle_digest_rejects_before_resources(self):
        self.inputs.station['positioners'][0]['pointing_context']['tle_sha256'] = 'ff' * 32
        self.inputs.write()
        self.context = self.inputs.load()
        with self.assertRaises(self.module.RuntimeConfigurationError):
            self.construct()
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_invalid_ptu_calibration_has_fixed_private_diagnostic(self):
        canary = 'SYNTHETIC-CALIBRATION-CANARY'
        self.inputs.station['positioners'][0]['pointing_context']['pan_to_az'] = canary
        self.inputs.write()
        self.context = self.inputs.load()
        with self.assertRaises(self.module.RuntimeConfigurationError) as raised:
            self.construct()
        self.assertNotIn(canary, str(raised.exception))
        self.assertEqual(str(raised.exception),
                         'Selected PTU run policy does not match the admitted inputs.')
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_actual_module_import_omits_rf_recorders_and_box(self):
        self.assertEqual(self.module.PassRunner.__module__, 'satgs.pass_runner')
        self.assertEqual(self.module.find_passes.__module__, 'satgs.utils')
        for name in support.OMITTED:
            self.assertNotIn(name, sys.modules)
        self.assertEqual(self.event_names(), [])

    def test_unreviewed_owner_revisions_reject_before_resources(self):
        with patch.dict(self.module._REVIEWED_OWNER_RELEASES, {}, clear=True):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 3)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_missing_owner_interface_rejects_before_resources(self):
        with patch.object(support.Ptu, 'close', None):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 3)
        self.assertEqual(self.event_names(), [])

    def test_selected_pair_only_and_truthful_status(self):
        runner = self.acquired()
        self.assertIs(runner.runtime_context, self.context)
        self.assertEqual(runner.ptu_client.ptu_ids, [7])
        self.assertEqual(runner.pixhawk.pix_ids, [9])
        self.assertIn('unverified', runner.get_status_str())
        self.assertFalse(runner.has_pdu or runner.record_iq or runner.record_trace)
        self.assertTrue(runner.nofrontend)
        opened = [details for name, details in support.EVENTS if name in ('ptu.open', 'pix.open')]
        self.assertEqual({details['log_dir'] for details in opened}, {str(runner.log_dir)})
        runner.shutdown()
        self.assertEqual(self.event_names()[-3:], ['pix.close', 'ptu.close', 'messenger.close'])

    def test_admitted_context_survives_original_path_replacement(self):
        for path in self.inputs.paths.values():
            path.write_text('replaced input must not be reread')
        runner = self.acquired()
        self.assertEqual(runner.tle_db[28626]['tle'], self.inputs.tle['tle'])
        self.assertNotIn('csv.read', self.event_names())

    def test_borrowed_transport_is_not_closed(self):
        borrowed = support.Transport.borrowed_for(self.context.station)
        runner = self.construct(messenger=borrowed)
        runner.shutdown()
        self.assertFalse(borrowed.closed)
        self.assertNotIn('messenger.prepare', self.event_names())
        self.assertNotIn('messenger.open', self.event_names())
        self.assertNotIn('messenger.close', self.event_names())
        self.assertEqual(self.event_names()[-2:], ['pix.close', 'ptu.close'])

    def test_failed_messenger_has_no_client_or_transport_release(self):
        support.FAIL_AT.add('messenger.open')
        with self.assertRaises(self.module.RuntimeFailure) as raised:
            self.construct()
        self.assertEqual(raised.exception.code, 4)
        self.assertEqual(self.event_names(), ['messenger.prepare', 'messenger.open'])

    def test_failed_ptu_releases_only_acquired_transport(self):
        support.FAIL_AT.add('ptu.open')
        with self.assertRaises(self.module.RuntimeFailure):
            self.construct()
        self.assertEqual(self.event_names(), ['messenger.prepare', 'messenger.open', 'ptu.open', 'messenger.close'])

    def test_failed_pixhawk_releases_ptu_and_transport(self):
        support.FAIL_AT.add('pix.open')
        with self.assertRaises(self.module.RuntimeFailure):
            self.construct()
        self.assertEqual(self.event_names(), ['messenger.prepare', 'messenger.open', 'ptu.open', 'pix.open', 'ptu.close', 'messenger.close'])

    def test_connection_failure_releases_both_clients_and_transport(self):
        support.CONNECTION = False
        with self.assertRaises(self.module.RuntimeFailure) as raised:
            self.construct()
        self.assertEqual(raised.exception.code, 4)
        self.assertEqual(self.event_names()[-3:], ['pix.close', 'ptu.close', 'messenger.close'])

    def test_each_connection_check_exception_unwinds(self):
        support.FAIL_AT.add('pix.check')
        with self.assertRaises(self.module.RuntimeFailure) as raised:
            self.construct()
        self.assertEqual(raised.exception.code, 4)
        self.assertIn('ptu.check', self.event_names())
        self.assertEqual(self.event_names()[-3:], ['pix.close', 'ptu.close', 'messenger.close'])

    def test_output_collision_preserves_previous_results(self):
        runner = self.construct()
        runner.shutdown()
        marker = runner.log_dir / 'preserved.txt'
        marker.write_text('previous execution')
        support.EVENTS.clear()
        with self.assertRaises(self.module.RuntimeFailure) as raised:
            self.construct()
        self.assertEqual(raised.exception.code, 6)
        self.assertEqual(marker.read_text(), 'previous execution')
        self.assertEqual(self.event_names(), ['messenger.prepare'])

    def test_output_creation_failure_precedes_clients(self):
        with patch.object(Path, 'mkdir', side_effect=OSError('synthetic create failure')):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 6)
        self.assertEqual(self.event_names(), ['messenger.prepare'])

    def test_second_handler_failure_restores_first_and_logger_state(self):
        real_handler = logging.FileHandler
        calls = []

        def handler(*args, **kwargs):
            calls.append(args)
            if len(calls) == 2:
                raise OSError('synthetic handler failure')
            return real_handler(*args, **kwargs)

        with patch.object(logging, 'FileHandler', side_effect=handler):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 6)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.event_names(), ['messenger.prepare'])

    def test_truth_header_failure_precedes_clients(self):
        with patch.object(self.module.csv, 'writer') as factory:
            factory.return_value.writerow.side_effect = OSError('synthetic header failure')
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 6)
        self.assertEqual(self.event_names(), ['messenger.prepare'])

    def test_truth_thread_start_failure_unwinds_owned_file(self):
        with patch.object(threading.Thread, 'start', side_effect=RuntimeError('synthetic start failure')):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 6)
        self.assertEqual(self.event_names(), ['messenger.prepare'])

    def test_immediate_cancellation_performs_only_passive_release(self):
        runner = self.acquired()
        runner.cancel_event.set()
        self.assertEqual(runner.main(), 130)
        self.assertNotIn('ptu.load_tle', self.event_names())
        self.assertNotIn('ptu.prime', self.event_names())
        self.assertNotIn('legacy.ptu.active_cleanup', self.event_names())
        self.assertEqual(runner.physical_state, 'unobserved')

    def test_signal_handler_records_cancel_without_commands(self):
        runner = self.acquired()
        before = list(support.EVENTS)
        runner._sigHandler(signal.SIGTERM, None)
        self.assertTrue(runner.cancel_event.is_set())
        self.assertEqual(support.EVENTS, before)
        self.assertEqual(runner.main(), 130)

    def test_repeated_shutdown_closes_each_resource_once(self):
        runner = self.construct()
        runner.shutdown()
        before = list(support.EVENTS)
        runner.shutdown()
        runner.shutdown()
        self.assertEqual(support.EVENTS, before)
        for name in ('pix.close', 'ptu.close', 'messenger.close'):
            self.assertEqual(self.event_names().count(name), 1)

    def test_cleanup_error_preserves_original_cancellation(self):
        runner = self.acquired()
        support.FAIL_AT.update(('pix.close', 'ptu.close'))
        runner.cancel_event.set()
        self.assertEqual(runner.main(), 130)
        self.assertEqual(runner.cleanup_errors, ['pixhawk-client', 'ptu-client'])
        self.assertEqual(self.event_names()[-1], 'messenger.close')

    def test_prime_timeout_never_enables_execution_or_rf(self):
        runner = self.acquired()
        runner.ptu_client.ptu_is_primed = {7: False}
        with self.assertRaises(self.module.RuntimeFailure) as raised:
            runner.wait_until_primed(timeout=0)
        self.assertEqual(raised.exception.code, 5)
        self.assertNotIn('ptu.prime', self.event_names())

    def test_unselected_prime_observation_is_not_readiness(self):
        runner = self.acquired()
        runner.ptu_client.ptu_is_primed = {0: True}
        with self.assertRaises(self.module.RuntimeFailure) as raised:
            runner.wait_until_primed(timeout=0)
        self.assertEqual(raised.exception.code, 5)

    def test_drop_dead_returns_nonzero_and_preserves_artifacts(self):
        runner = self.acquired()
        runner.absolute_end_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        self.assertEqual(runner.main(), 5)
        self.assertTrue((runner.log_dir / 'sat_truth_pos.csv').exists())
        self.assertNotIn('ptu.load_tle', self.event_names())

    def test_main_real_loop_reports_indeterminate_without_park(self):
        runner = self.acquired()
        with patch.object(self.module.DEFAULTS, 'tracking_update_rate', 0.001):
            self.assertEqual(runner.main(), 8)
        self.assertEqual(runner.physical_state, 'indeterminate')
        self.assertIn('ptu.load_tle', self.event_names())
        self.assertIn('ptu.prime', self.event_names())
        self.assertNotIn('legacy.ptu.park', self.event_names())
        self.assertNotIn('legacy.ptu.active_cleanup', self.event_names())

    def test_execution_exception_releases_remaining_resources(self):
        runner = self.acquired()
        support.FAIL_AT.add('ptu.load_tle')
        self.assertEqual(runner.main(), 5)
        self.assertEqual(self.event_names()[-3:], ['pix.close', 'ptu.close', 'messenger.close'])

    def test_astronomy_instances_are_independent_under_interleaving(self):
        runner = self.acquired()
        runner._stop_truth_worker()
        self.assertIsNot(runner.ground_station, runner._truth_observer)
        self.assertIsNot(runner.iss, runner._truth_body)
        first = datetime(2026, 1, 1, 1, tzinfo=timezone.utc)
        other = first + timedelta(hours=6)
        expected = runner.get_sat_pos(first)
        runner._truth_observer.date = other
        runner._truth_body.compute(runner._truth_observer)
        self.assertEqual(runner.get_sat_pos(first), expected)
        self.assertNotEqual(runner.iss.az, runner._truth_body.az)

    def test_worker_error_channel_produces_logging_outcome(self):
        runner = self.acquired()
        runner._stop_truth_worker()
        runner.sat_pos_thread_signal.clear()
        with patch.object(runner, 'sat_pos_writer') as writer:
            writer.writerow.side_effect = OSError('synthetic write failure')
            runner.create_sat_pos_writer(runner.sat_pos_thread_signal, runner.log_dir)
        self.assertEqual(runner._worker_error, 'truth-writer')
        self.assertEqual(runner.main(), 6)
        self.assertNotIn('ptu.load_tle', self.event_names())

    def test_unavailable_pass_rejects_before_output(self):
        support.EPHEMERIS_MODE = 'unavailable'
        with self.assertRaises(self.module.RuntimeConfigurationError):
            self.construct()
        self.assertFalse((self.inputs.root / 'results').exists())
        self.assertEqual(self.event_names(), [])

    def test_incompatible_direct_constructor_argument_rejects_before_output(self):
        with self.assertRaises(self.module.RuntimeConfigurationError):
            self.construct(record_trace=True)
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_synthetic_credentials_absent_from_exposed_artifacts(self):
        runner = self.acquired()
        runner.cancel_event.set()
        output = io.StringIO()
        with redirect_stdout(output):
            runner.main()
        exposed = repr(self.context) + runner.get_status_str() + output.getvalue()
        exposed += ''.join(path.read_text() for path in runner.log_dir.iterdir() if path.is_file())
        self.assertNotIn(self.inputs.station['amq_password'], exposed)
        self.assertNotIn(self.inputs.station['amq_username'], exposed)

    def test_actual_console_main_consumes_admitted_configuration(self):
        output = io.StringIO()
        with redirect_stdout(output), patch.object(self.module.DEFAULTS, 'tracking_update_rate', 0.001):
            self.assertEqual(self.module.main(self.inputs.argv()), 8)
        self.assertIn('physical_state=indeterminate', output.getvalue())
        self.assertEqual([details['ptu_id'] for name, details in support.EVENTS if name == 'ptu.open'], [7])
        self.assertEqual([details['pix_id'] for name, details in support.EVENTS if name == 'pix.open'], [9])

    def test_console_main_invalid_explicit_inputs_have_no_legacy_fallback(self):
        with redirect_stderr(io.StringIO()):
            self.assertEqual(self.module.main(['--operation', 'pointing']), 2)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_console_main_rejects_all_explicit_pointing_conflicts(self):
        conflicts = (['-rec-iq'], ['-sip-src'], ['-nptu'], ['-npx'], ['-dlfc', '0'],
                     ['-ulfc', '0'], ['-dlfs', '1'], ['-g', '0'], ['--error-profile', 'unread.json'])
        for extra in conflicts:
            with self.subTest(extra=extra), redirect_stderr(io.StringIO()):
                self.assertEqual(self.module.main(self.inputs.argv() + extra), 2)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_console_main_unsupported_owners_return_three_before_output(self):
        with patch.dict(self.module._REVIEWED_OWNER_RELEASES, {}, clear=True), redirect_stderr(io.StringIO()):
            self.assertEqual(self.module.main(self.inputs.argv()), 3)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_missing_selected_owner_is_safe_failure_before_effects(self):
        original_import = builtins.__import__

        def without_ptu(name, *args, **kwargs):
            if name == 'ptu_control.ptu_client':
                raise ImportError('private dependency details')
            return original_import(name, *args, **kwargs)

        with patch('builtins.__import__', without_ptu):
            with self.assertRaises(self.module.RuntimeFailure) as caught:
                self.construct()
        self.assertEqual(caught.exception.code, 3)
        self.assertNotIn('private dependency details', str(caught.exception))
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_actual_module_child_propagates_guard_and_indeterminate_exit(self):
        env = dict(os.environ, SATGS_RUNTIME_CHILD='1', SATGS_RUNTIME_FAKE_CONTRACT='1', SATGS_RUNTIME_REVIEWED_FAKE='1')
        result = subprocess.run([sys.executable, '-B', '-m', 'satgs.pass_runner'] + self.inputs.argv(),
                                env=env, stdin=subprocess.PIPE, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 8, result.stderr)
        self.assertIn('physical_state=indeterminate', result.stdout)
        self.assertIn('SATGS_RUNTIME_GUARD {"child": true, "denials": []}', result.stderr)
        self.assertNotIn(self.inputs.station['amq_password'], result.stdout + result.stderr)

    def test_actual_module_child_unsupported_owner_exit_is_three(self):
        env = dict(os.environ, SATGS_RUNTIME_CHILD='1', SATGS_RUNTIME_FAKE_CONTRACT='1', SATGS_RUNTIME_REVIEWED_FAKE='0')
        result = subprocess.run([sys.executable, '-B', '-m', 'satgs.pass_runner'] + self.inputs.argv(),
                                env=env, stdin=subprocess.PIPE, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 3, result.stderr)
        self.assertIn('SATGS_RUNTIME_GUARD {"child": true, "denials": []}', result.stderr)
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_actual_module_child_invalid_input_exit_is_two(self):
        env = dict(os.environ, SATGS_RUNTIME_CHILD='1', SATGS_RUNTIME_FAKE_CONTRACT='1')
        result = subprocess.run([sys.executable, '-B', '-m', 'satgs.pass_runner', '--operation', 'pointing'],
                                env=env, stdin=subprocess.PIPE, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertIn('SATGS_RUNTIME_GUARD {"child": true, "denials": []}', result.stderr)

    def test_closed_runner_cannot_restart_execution(self):
        runner = self.acquired()
        runner.cancel_event.set()
        self.assertEqual(runner.main(), 130)
        runner.cancel_event.clear()
        before = list(support.EVENTS)
        self.assertNotEqual(runner.main(), 0)
        self.assertEqual(support.EVENTS, before)

    def test_cancellation_on_transport_return_prevents_ptu_acquisition(self):
        original = support.Transport.open_bounded

        def connect(**options):
            transport = original(**options)
            options['cancel'].set()
            return transport

        with patch.object(support.Transport, 'open_bounded', side_effect=connect):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 130)
        self.assertEqual(self.event_names(), ['messenger.prepare', 'messenger.open', 'messenger.close'])

    def test_truth_file_open_failure_releases_handlers_before_clients(self):
        original = builtins.open

        def opened(path, *args, **kwargs):
            if Path(path).name == 'sat_truth_pos.csv':
                raise OSError('synthetic truth open failure')
            return original(path, *args, **kwargs)

        with patch.object(builtins, 'open', side_effect=opened):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 6)
        self.assertEqual(self.event_names(), ['messenger.prepare'])

    def test_truth_flush_failure_is_logging_not_success(self):
        runner = self.acquired()
        runner._stop_truth_worker()
        runner.sat_pos_thread_signal.clear()
        with patch.object(runner._truth_stream, 'flush', side_effect=OSError('synthetic flush failure')):
            runner.create_sat_pos_writer(runner.sat_pos_thread_signal, runner.log_dir)
        self.assertEqual(runner.main(), 6)

    def test_postmotion_cleanup_failure_is_distinct(self):
        runner = self.acquired()
        support.FAIL_AT.add('pix.close')
        with patch.object(self.module.DEFAULTS, 'tracking_update_rate', 0.001):
            self.assertEqual(runner.main(), 7)
        self.assertEqual(runner.physical_state, 'indeterminate')
        self.assertEqual(runner.cleanup_errors, ['pixhawk-client'])
        self.assertEqual(self.event_names()[-1], 'messenger.close')

    def legacy_inputs(self):
        self.inputs.station.update(iq_logger_link_side='downlink', trace_logger_link_side='downlink', channel_power={})
        self.inputs.write()
        emissions = self.inputs.root / 'emissions.csv'
        emissions.write_text('txid,fc_mhz,bw_mhz\nDL,1500,10\n')
        return emissions

    def legacy_runner(self, emissions, **options):
        return self.module.PassRunner(self.inputs.paths['station.yaml'], self.inputs.paths['tle.csv'], 28626,
                                      tx_id_file=emissions, dlfc=1500.0, down_fs=10.0, ulfc=0.0,
                                      duration=0.01, nodate=True, **options)

    def test_legacy_full_msel_normal_defaults_under_explicit_full_stack_contracts(self):
        emissions = self.legacy_inputs()
        with patch.dict(sys.modules, support.legacy_modules()):
            runner = self.legacy_runner(emissions)
            try:
                self.assertIsNone(runner.runtime_context)
                self.assertTrue(runner.record_trace)
                self.assertFalse(runner.record_iq)
                self.assertTrue(runner.has_pdu)
                self.assertFalse(runner.nofrontend or runner.nopixhawk or runner.noptu)
                self.assertTrue(runner.work_modem_tx_source)
                for name in ('legacy.frontend.open', 'legacy.pdu.open', 'legacy.pix.open', 'legacy.ptu.open', 'legacy.trace.open'):
                    self.assertIn(name, self.event_names())
                self.assertNotIn('legacy.iq.open', self.event_names())
                runner.cancel_event.set()
                self.assertEqual(runner.main(), 130)
            finally:
                runner._release_resources()

    def test_legacy_omission_flags_keep_documented_simulated_ptu_boundary(self):
        emissions = self.legacy_inputs()
        runner = self.legacy_runner(emissions, nofrontend=True, nopixhawk=True, nopdu=True, noptu=True,
                                    record_trace=False)
        try:
            self.assertTrue(runner.nofrontend and runner.nopixhawk and runner.noptu)
            self.assertFalse(runner.has_pdu or runner.record_iq or runner.record_trace)
            self.assertEqual(runner.downlink_if_fc, 1500.0)
            ptu = [details for name, details in support.EVENTS if name == 'legacy.ptu.open']
            self.assertEqual(ptu, [{'test_mode': True, 'ptu_id': 0}])
            for name in ('legacy.frontend.open', 'legacy.pdu.open', 'legacy.pix.open', 'legacy.trace.open', 'legacy.iq.open'):
                self.assertNotIn(name, self.event_names())
            runner.cancel_event.set()
            self.assertEqual(runner.main(), 130)
        finally:
            runner._release_resources()

    def test_legacy_prime_timeout_does_not_enable_rf(self):
        emissions = self.legacy_inputs()
        with patch.dict(sys.modules, support.legacy_modules()):
            runner = self.legacy_runner(emissions)
            try:
                runner.ptu_client.ptu_is_primed = {7: False}
                before = self.event_names().count('legacy.frontend.configure_rx')
                with self.assertRaises(self.module.RuntimeFailure) as raised:
                    runner.wait_until_primed(timeout=0)
                self.assertEqual(raised.exception.code, 5)
                self.assertEqual(self.event_names().count('legacy.frontend.configure_rx'), before)
                runner.cancel_event.set()
                self.assertEqual(runner.main(), 130)
            finally:
                runner._release_resources()

    def test_legacy_console_main_preserves_normal_recording_defaults(self):
        emissions = self.legacy_inputs()
        argv = ['-config', str(self.inputs.paths['station.yaml']), '-sf', str(self.inputs.paths['tle.csv']),
                '-tf', str(emissions), '-id', '28626', '-d', '0.01', '-dlfc', '1500', '-dlfs', '10', '-ulfc', '0', '-nd']
        with patch.dict(sys.modules, support.legacy_modules()), patch.object(self.module.DEFAULTS, 'tracking_update_rate', 0.001):
            self.assertEqual(self.module.main(argv), 0)
        self.assertIn('legacy.trace.start', self.event_names())
        self.assertNotIn('legacy.iq.open', self.event_names())
        self.assertIn('legacy.ptu.park', self.event_names())

    def test_explicit_modular_full_msel_rejects_in_actual_main(self):
        from satgs.deployment import load_manifest
        from satgs.deployment_plan import build_catalog, expand_preset
        self.inputs.configuration = expand_preset(build_catalog(load_manifest()), 'full_msel').to_dict()
        self.inputs.write()
        with redirect_stderr(io.StringIO()):
            self.assertEqual(self.module.main(self.inputs.argv()), 2)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_owner_error_diagnostics_do_not_expose_credentials(self):
        secret = self.inputs.station['amq_password']
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(support.Transport, 'open_bounded', side_effect=RuntimeError(secret)):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(self.module.main(self.inputs.argv()), 4)
        exposed = output.getvalue() + errors.getvalue()
        exposed += ''.join(path.read_text() for path in (self.inputs.root / 'results').rglob('*') if path.is_file())
        self.assertNotIn(secret, exposed)

    def test_unjoined_worker_keeps_file_open_and_records_bounded_release_failure(self):
        runner = self.acquired()
        runner._stop_truth_worker()
        actual_thread = runner._truth_thread
        joins = []
        simulated_unjoined = SimpleNamespace(ident=1, join=joins.append, is_alive=lambda: True)
        runner._truth_thread = simulated_unjoined
        try:
            runner.shutdown()
            self.assertEqual(joins, [self.module._RESOURCE_WAIT_SECONDS])
            self.assertEqual(runner.cleanup_errors, ['truth-thread', 'truth-file'])
            self.assertFalse(runner._truth_stream.closed)
        finally:
            runner._truth_thread = actual_thread
            runner._close_truth_file()

    def test_new_signal_owner_is_not_overwritten_during_release(self):
        runner = self.acquired()
        replacement = lambda signum, frame: None
        signal.signal(signal.SIGTERM, replacement)
        try:
            runner.shutdown()
            self.assertIs(signal.getsignal(signal.SIGTERM), replacement)
        finally:
            signal.signal(signal.SIGTERM, self.before_signals[signal.SIGTERM])

    def test_false_prime_submission_never_reaches_tracking(self):
        runner = self.acquired()
        with patch.object(runner.ptu_client, 'prime', return_value=False):
            self.assertEqual(runner.main(), 5)
        self.assertEqual(runner.physical_state, 'indeterminate')
        self.assertNotEqual(runner.state, 'tracking')

    def test_worker_error_after_motion_retains_indeterminate_state(self):
        runner = self.acquired()

        def failed_after_prime(name, details):
            if name == 'ptu.prime':
                runner._worker_error = 'controlled worker fault'

        support.ON_EVENT = failed_after_prime
        self.assertEqual(runner.main(), 6)
        self.assertEqual(runner.physical_state, 'indeterminate')
        self.assertNotIn('legacy.ptu.park', self.event_names())

    def test_direct_api_cannot_override_admitted_duration_or_elevation(self):
        for options in ({'duration': 2.0}, {'elv_mask': 30.0}):
            with self.subTest(options=options):
                with self.assertRaises(self.module.RuntimeConfigurationError):
                    self.construct(**options)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_failure_after_actual_thread_start_joins_started_worker(self):
        original = threading.Thread.start

        def started_then_failed(thread):
            original(thread)
            raise RuntimeError('synthetic post-start failure')

        with patch.object(threading.Thread, 'start', started_then_failed):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 6)
        self.assertEqual(self.event_names(), ['messenger.prepare'])

    def test_invalid_circumpolar_elevation_rejects_before_effects(self):
        for mode in ('circumpolar-below-mask', 'circumpolar-invalid-elevation', 'circumpolar-nonfinite'):
            with self.subTest(mode=mode):
                support.EPHEMERIS_MODE = mode
                with self.assertRaises(self.module.RuntimeConfigurationError):
                    self.construct()
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_new_logger_level_owner_is_not_overwritten_on_release(self):
        runner = self.acquired()
        self.logger.setLevel(logging.ERROR)
        try:
            runner.shutdown()
            self.assertEqual(self.logger.level, logging.ERROR)
        finally:
            self.logger.setLevel(self.before_level)

    def test_legacy_cancellation_at_final_primed_observation_never_enables_rf(self):
        emissions = self.legacy_inputs()
        with patch.dict(sys.modules, support.legacy_modules()):
            runner = self.legacy_runner(emissions)

            class CancelOnValues(dict):
                def values(self):
                    runner.cancel_event.set()
                    return super().values()

            try:
                runner.ptu_client.ptu_is_primed = CancelOnValues({7: True})
                before = self.event_names().count('legacy.frontend.configure_rx')
                with self.assertRaises(self.module.RuntimeFailure) as raised:
                    runner.wait_until_primed(timeout=0)
                self.assertEqual(raised.exception.code, 130)
                self.assertEqual(self.event_names().count('legacy.frontend.configure_rx'), before)
                self.assertEqual(runner.main(), 130)
            finally:
                runner._release_resources()


    def owned_primary_handler(self):
        return next(handler for handler in self.logger.handlers
                    if isinstance(handler, logging.FileHandler)
                    and Path(handler.baseFilename).name != 'warnings.log')

    def fail_once(self, original, failures):
        def operation(*args, **kwargs):
            if not failures:
                failures.append(True)
                raise OSError(self.inputs.station['amq_password'])
            return original(*args, **kwargs)
        return operation

    def assert_passive_cleanup(self):
        self.assertEqual(self.event_names()[-3:], ['pix.close', 'ptu.close', 'messenger.close'])
        self.assertFalse(any(name.startswith('legacy.') for name in self.event_names()))

    def assert_safe_diagnostics(self, output, errors, category, cleanup='none'):
        self.assertIn('primary_failure=' + category, output)
        self.assertIn('cleanup_categories=' + cleanup, output)
        exposed = output + errors
        exposed += ''.join(path.read_text() for path in (self.inputs.root / 'results').rglob('*')
                           if path.is_file())
        self.assertNotIn(self.inputs.station['amq_password'], exposed)
        self.assertNotIn(self.inputs.station['amq_username'], exposed)
        self.assertNotIn('Traceback', exposed)
        self.assertNotIn('--- Logging error ---', exposed)

    def assert_owned_stream_failure(self, operation, *, console_main=False):
        failures = []
        output, errors = io.StringIO(), io.StringIO()
        with ExitStack() as stack:
            if console_main:
                original_factory = logging.FileHandler

                def factory(*args, **kwargs):
                    handler = original_factory(*args, **kwargs)
                    if Path(handler.baseFilename).name != 'warnings.log':
                        original = getattr(handler.stream, operation)
                        stack.enter_context(patch.object(handler.stream, operation,
                            side_effect=self.fail_once(original, failures)))
                    return handler

                stack.enter_context(patch.object(logging, 'FileHandler', side_effect=factory))
                execute = lambda: self.module.main(self.inputs.argv())
            else:
                runner = self.acquired()
                handler = self.owned_primary_handler()
                original = getattr(handler.stream, operation)
                stack.enter_context(patch.object(handler.stream, operation,
                    side_effect=self.fail_once(original, failures)))
                execute = runner.main
            stack.enter_context(redirect_stdout(output))
            stack.enter_context(redirect_stderr(errors))
            self.assertEqual(execute(), 6)
        self.assertEqual(failures, [True])
        self.assertIn('logging_failure=owned-logging', output.getvalue())
        self.assertIn('physical_state=unobserved', output.getvalue())
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'owned-logging')
        self.assertNotIn('ptu.prime', self.event_names())
        self.assert_passive_cleanup()
        if not console_main:
            self.assertEqual(runner.primary_failure, 'owned-logging')
            self.assertEqual(runner.logging_failure, 'owned-logging')

    def test_owned_log_write_failure_reaches_actual_main(self):
        self.assert_owned_stream_failure('write')

    def test_owned_log_flush_failure_reaches_actual_main(self):
        self.assert_owned_stream_failure('flush')

    def test_console_main_owned_log_write_failure_returns_six(self):
        self.assert_owned_stream_failure('write', console_main=True)

    def test_console_main_owned_log_flush_failure_returns_six(self):
        self.assert_owned_stream_failure('flush', console_main=True)

    def test_owned_emit_formatter_failure_is_payload_free(self):
        runner = self.acquired()
        handler = self.owned_primary_handler()
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(handler, 'format', side_effect=RuntimeError(self.inputs.station['amq_password'])):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), 6)
        self.assertEqual(runner.logging_failure, 'owned-logging')
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'owned-logging')
        self.assert_passive_cleanup()

    def test_owned_console_stream_failure_is_payload_free(self):
        stream = io.StringIO()
        with redirect_stderr(stream):
            runner = self.acquired()
        failures = []
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(stream, 'write', side_effect=self.fail_once(stream.write, failures)):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), 6)
        self.assertEqual(failures, [True])
        self.assertFalse(stream.closed)
        self.assertEqual(runner.logging_failure, 'owned-logging')
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'owned-logging')
        self.assert_passive_cleanup()

    def assert_final_logging_failure(self, operation, primary=None):
        runner = self.acquired()
        handler = self.owned_primary_handler()
        stream = handler.stream
        failures = []
        if primary == 'cancelled':
            runner.cancel_event.set()
        elif primary == 'drop-dead':
            runner.absolute_end_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        target = stream if operation == 'flush' else handler
        original = getattr(target, operation)

        def final_failure(*args, **kwargs):
            if handler not in self.logger.handlers and not failures:
                failures.append(True)
                if operation == 'close':
                    original(*args, **kwargs)
                raise OSError(self.inputs.station['amq_password'])
            return original(*args, **kwargs)

        output, errors = io.StringIO(), io.StringIO()
        with patch.object(target, operation, side_effect=final_failure), \
                patch.object(self.module.DEFAULTS, 'tracking_update_rate', 0.001):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), {'cancelled': 130, 'drop-dead': 5}.get(primary, 6))
        self.assertEqual(failures, [True])
        self.assertTrue(stream.closed)
        self.assertEqual(runner.cleanup_errors, ['log-handler'])
        self.assertEqual(runner.primary_failure, primary or 'owned-logging')
        self.assertEqual(runner.logging_failure, 'owned-logging')
        self.assertIn('logging_failure=owned-logging', output.getvalue())
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), primary or 'owned-logging', 'log-handler')
        self.assertEqual(runner.physical_state, 'unobserved' if primary else 'indeterminate')
        self.assert_passive_cleanup()

    def test_owned_final_flush_failure_controls_outcome(self):
        self.assert_final_logging_failure('flush')

    def test_owned_final_close_failure_controls_outcome(self):
        self.assert_final_logging_failure('close')

    def test_owned_final_logging_failure_preserves_cancellation(self):
        self.assert_final_logging_failure('flush', primary='cancelled')

    def test_owned_final_logging_failure_preserves_primary_execution_failure(self):
        self.assert_final_logging_failure('flush', primary='drop-dead')

    def test_owned_logging_failure_does_not_modify_unrelated_handlers(self):
        unrelated = logging.StreamHandler(io.StringIO())
        before = (unrelated.emit, unrelated.handleError, unrelated.close, logging.raiseExceptions,
                  logging.Handler.handleError, logging.StreamHandler.emit, logging.FileHandler.emit)
        self.logger.addHandler(unrelated)
        try:
            self.assert_owned_stream_failure('write')
            self.assertIn(unrelated, self.logger.handlers)
            self.assertEqual((unrelated.emit, unrelated.handleError, unrelated.close, logging.raiseExceptions,
                              logging.Handler.handleError, logging.StreamHandler.emit, logging.FileHandler.emit), before)
            self.assertFalse(unrelated.stream.closed)
        finally:
            self.logger.removeHandler(unrelated)
            unrelated.close()

    def assert_primary_and_cleanup_diagnostics(self, category):
        runner = self.acquired()
        original_close = runner.pixhawk.close

        def close(**options):
            original_close(**options)
            raise RuntimeError(self.inputs.station['amq_password'])

        if category == 'prime-timeout':
            runner.ptu_client.ptu_is_primed = {7: False}
            ticks = itertools.count(1000000.0, 31.0)
            clock = patch.object(self.module.time, 'monotonic', side_effect=lambda: next(ticks))
        else:
            runner.absolute_end_time = datetime.now(timezone.utc) - timedelta(seconds=1)
            clock = patch.object(self.module.DEFAULTS, 'tracking_update_rate', 0.001)
        output, errors = io.StringIO(), io.StringIO()
        with clock, patch.object(runner.pixhawk, 'close', side_effect=close):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), 5)
        self.assertEqual(runner.primary_failure, category)
        self.assertEqual(runner.cleanup_errors, ['pixhawk-client'])
        self.assertIsNone(runner.logging_failure)
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), category, 'pixhawk-client')
        self.assert_passive_cleanup()
        self.assertNotEqual(runner.state, 'tracking')
        if category == 'prime-timeout':
            self.assertIn('ptu.prime', self.event_names())
            self.assertEqual(runner.physical_state, 'indeterminate')
        else:
            self.assertNotIn('ptu.load_tle', self.event_names())
            self.assertEqual(runner.physical_state, 'unobserved')

    def test_prime_timeout_retains_safe_primary_and_cleanup_categories(self):
        self.assert_primary_and_cleanup_diagnostics('prime-timeout')

    def test_drop_dead_retains_safe_primary_and_cleanup_categories(self):
        self.assert_primary_and_cleanup_diagnostics('drop-dead')

    def test_owner_execution_exception_category_is_payload_free(self):
        runner = self.acquired()
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(runner.ptu_client, 'load_tle', side_effect=RuntimeError(self.inputs.station['amq_password'])):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), 5)
        self.assertEqual(runner.primary_failure, 'execution-failure')
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'execution-failure')
        self.assert_passive_cleanup()

    def assert_noncircumpolar_policy(self, rise, setting, *, admitted, elevation=15):
        from satgs.runtime_configuration import load_runtime_configuration
        self.context = load_runtime_configuration(
            *(self.inputs.paths[name] for name in ('deployment.json', 'bindings.json', 'station.yaml', 'tle.csv')),
            sat_id=28626, duration=5, elevation=elevation)
        self.assertEqual(self.module.find_passes.__module__, 'satgs.utils')
        self.assertEqual(self.module.PassInfo.__module__, 'satgs.utils')
        with support.noncircumpolar_pass(self.module, rise=rise, setting=setting) as clock:
            if not admitted:
                with patch.object(self.module.PassRunner, '_acquire_output',
                                  side_effect=AssertionError('rejection must precede resource effects')) as acquire:
                    with self.assertRaises(self.module.RuntimeConfigurationError):
                        self.construct()
                acquire.assert_not_called()
                self.assertEqual(self.event_names(), [])
                self.assertFalse((self.inputs.root / 'results').exists())
                self.assertGreater(clock.next_pass_calls, 0)
                return
            runner = self.acquired()
            clock.runner = runner
            self.assertFalse(runner.current_pass_info.is_circumpolar)
            epoch = datetime(2026, 9, 23, 12, tzinfo=timezone.utc)
            self.assertEqual(runner.current_pass_info.sat_rise_time, epoch + timedelta(seconds=rise))
            self.assertEqual(runner.current_pass_info.sat_set_time, epoch + timedelta(seconds=setting))
            self.assertEqual(len(runner.current_pass_trajectory.t_steps), setting - rise)
            self.assertEqual(runner.current_pass_info.max_elv, 45)
            output = io.StringIO()
            with redirect_stdout(output), redirect_stderr(io.StringIO()):
                self.assertEqual(runner.main(), 8)
            self.assertEqual(runner.state, 'end')
            self.assertEqual(runner.physical_state, 'indeterminate')
            self.assertIsNone(runner.primary_failure)
            self.assertIsNone(runner.logging_failure)
            self.assertIn('ptu.load_tle', self.event_names())
            self.assertIn('ptu.prime', self.event_names())
            states = {state for state, _, _, _ in clock.observations}
            self.assertIn('primed', states)
            self.assertIn('tracking', states)
            if rise == 100 or setting == 1000:
                self.assertIn('waiting', states)
                self.assertFalse(clock.observations[0][3])
            if setting == 92:
                self.assertAlmostEqual(clock.observations[0][2], 15)
                self.assertTrue(clock.observations[0][3])
            if elevation == 0 and setting == 60:
                self.assertAlmostEqual(clock.observations[0][2], 0)
                self.assertTrue(clock.observations[0][3])
            self.assert_passive_cleanup()

    def test_late_active_pass_rejects_before_resource_effects(self):
        self.assert_noncircumpolar_policy(-100, 40, admitted=False)

    def test_lookahead_just_below_mask_rejects_before_resource_effects(self):
        self.assert_noncircumpolar_policy(-100, 91, admitted=False)

    def test_lookahead_exact_mask_preserves_inclusive_owner_boundary(self):
        self.assert_noncircumpolar_policy(-100, 92, admitted=True)

    def test_lookahead_just_above_mask_admits_active_pass(self):
        self.assert_noncircumpolar_policy(-100, 93, admitted=True)

    def test_noncircumpolar_future_pass_keeps_wait_prime_track_path(self):
        self.assert_noncircumpolar_policy(100, 300, admitted=True)

    def test_noncircumpolar_early_rising_pass_remains_supported(self):
        self.assert_noncircumpolar_policy(-10, 300, admitted=True)

    def test_early_rising_pass_with_below_mask_lookahead_waits_then_primes(self):
        self.assert_noncircumpolar_policy(-10, 1000, admitted=True)

    def test_noncircumpolar_valid_active_pass_remains_supported(self):
        self.assert_noncircumpolar_policy(-100, 200, admitted=True)

    def test_zero_mask_exact_set_lookahead_remains_inclusive(self):
        self.assert_noncircumpolar_policy(-100, 60, admitted=True, elevation=0)

    def test_lookahead_after_set_rejects_even_with_zero_mask(self):
        self.assert_noncircumpolar_policy(-100, 59, admitted=False, elevation=0)

    def test_console_main_rejects_late_active_pass_before_resource_effects(self):
        argv = self.inputs.argv()
        argv[argv.index('-d') + 1] = '5'
        with support.noncircumpolar_pass(self.module, rise=-100, setting=40) as clock:
            with redirect_stderr(io.StringIO()):
                self.assertEqual(self.module.main(argv), 2)
        self.assertGreater(clock.next_pass_calls, 0)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_owned_emit_exception_reaches_actual_main(self):
        original_factory = logging.FileHandler

        def factory(*args, **kwargs):
            handler = original_factory(*args, **kwargs)
            if Path(handler.baseFilename).name != 'warnings.log':
                def emit(record):
                    raise OSError(self.inputs.station['amq_password'])
                handler.emit = emit
            return handler

        with patch.object(logging, 'FileHandler', side_effect=factory):
            runner = self.acquired()
        output, errors = io.StringIO(), io.StringIO()
        with redirect_stdout(output), redirect_stderr(errors):
            self.assertEqual(runner.main(), 6)
        self.assertEqual(runner.logging_failure, 'owned-logging')
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'owned-logging')
        self.assert_passive_cleanup()

    def test_owner_runtime_failure_category_is_sanitized(self):
        runner = self.acquired()
        failure = self.module.RuntimeFailure(5, self.inputs.station['amq_password'])
        failure.category = self.inputs.station['amq_password']
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(runner.ptu_client, 'load_tle', side_effect=failure):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), 5)
        self.assertEqual(runner.primary_failure, 'execution-failure')
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'execution-failure')
        self.assert_passive_cleanup()

    def assert_console_primary_and_cleanup_diagnostics(self, category):
        original_close = support.Pix.close

        def close(client, **options):
            original_close(client, **options)
            raise RuntimeError(self.inputs.station['amq_password'])

        output, errors = io.StringIO(), io.StringIO()
        with ExitStack() as stack:
            stack.enter_context(patch.object(support.Pix, 'close', close))
            if category == 'prime-timeout':
                stack.enter_context(patch.object(support, 'PRIMED', False))
                ticks = itertools.count(1000000.0, 31.0)
                stack.enter_context(patch.object(self.module.time, 'monotonic', side_effect=lambda: next(ticks)))
            else:
                seconds = [0]
                epoch = datetime(2026, 9, 23, 12, tzinfo=timezone.utc)

                class VirtualDatetime(datetime):
                    @classmethod
                    def now(cls, tz=None):
                        value = epoch + timedelta(seconds=seconds[0])
                        return value if tz else value.replace(tzinfo=None)

                def acquisition_elapsed(name, details):
                    if name == 'pix.check':
                        seconds[0] = 181

                stack.enter_context(patch.object(self.module, 'datetime', VirtualDatetime))
                stack.enter_context(patch.object(support, 'ON_EVENT', acquisition_elapsed))
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(self.module.main(self.inputs.argv()), 5)
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), category, 'pixhawk-client')
        self.assertIn('logging_failure=none', output.getvalue())
        self.assert_passive_cleanup()
        if category == 'prime-timeout':
            self.assertIn('ptu.prime', self.event_names())
            self.assertIn('physical_state=indeterminate', output.getvalue())
        else:
            self.assertNotIn('ptu.load_tle', self.event_names())
            self.assertIn('physical_state=unobserved', output.getvalue())

    def test_console_main_retains_prime_timeout_and_cleanup_categories(self):
        self.assert_console_primary_and_cleanup_diagnostics('prime-timeout')

    def test_console_main_retains_drop_dead_and_cleanup_categories(self):
        self.assert_console_primary_and_cleanup_diagnostics('drop-dead')

    def test_owned_write_failure_remains_primary_over_pixhawk_cleanup(self):
        runner = self.acquired()
        handler = self.owned_primary_handler()
        failures = []
        support.FAIL_AT.add('pix.close')
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(handler.stream, 'write', side_effect=self.fail_once(handler.stream.write, failures)):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), 6)
        self.assertEqual(failures, [True])
        self.assertEqual(runner.primary_failure, 'owned-logging')
        self.assertEqual(runner.cleanup_errors, ['pixhawk-client'])
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'owned-logging', 'pixhawk-client')
        self.assert_passive_cleanup()

    def test_failed_handler_close_still_closes_owned_stream(self):
        runner = self.acquired()
        handler = self.owned_primary_handler()
        stream = handler.stream
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(handler, 'close', side_effect=OSError(self.inputs.station['amq_password'])), \
                patch.object(self.module.DEFAULTS, 'tracking_update_rate', 0.001):
            with redirect_stdout(output), redirect_stderr(errors):
                self.assertEqual(runner.main(), 6)
        self.assertTrue(stream.closed)
        self.assertEqual(runner.primary_failure, 'owned-logging')
        self.assertEqual(runner.logging_failure, 'owned-logging')
        self.assertEqual(runner.cleanup_errors, ['log-handler'])
        self.assertEqual(runner.physical_state, 'indeterminate')
        self.assert_safe_diagnostics(output.getvalue(), errors.getvalue(), 'owned-logging', 'log-handler')
        self.assert_passive_cleanup()


    def test_messenger_v2_does_not_change_selected_client_v1_contracts(self):
        self.assertEqual(support.Transport.CONTRACT_REVISION, 'satgs.pointing.v2')
        self.assertEqual(support.Ptu.CONTRACT_REVISION, 'satgs.pointing.v1')
        self.assertEqual(support.Pix.CONTRACT_REVISION, 'satgs.pointing.v1')
        for owner, revision in ((support.Transport, 'satgs.pointing.v1'),
                                (support.Ptu, 'satgs.pointing.v2'),
                                (support.Pix, 'satgs.pointing.v2')):
            with self.subTest(owner=owner.__name__), patch.object(owner, 'CONTRACT_REVISION', revision):
                with self.assertRaises(self.module.RuntimeFailure) as raised:
                    self.construct()
                self.assertEqual(raised.exception.code, 3)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_each_revised_messenger_method_is_required_before_preparation(self):
        for method in ('prepare_transport', 'open_bounded', 'close', 'strict_instance_compatible'):
            with self.subTest(method=method), patch.object(support.Transport, method, None):
                with self.assertRaises(self.module.RuntimeFailure) as raised:
                    self.construct()
                self.assertEqual(raised.exception.code, 3)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_invalid_output_prefix_rejects_before_preparation(self):
        with self.assertRaises(self.module.RuntimeConfigurationError):
            self.construct(file_prefix='../invalid')
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_preparation_precedes_effects_and_fresh_deadline_with_exact_private_controls(self):
        original_prepare = support.Transport.prepare_transport
        original_open = support.Transport.open_bounded
        original_deadline = self.module.PassRunner._deadline
        clock = SimpleNamespace(now=100.0)
        calls, preparations = [], []

        def prepare(*, settings, cancel):
            self.assertIs(settings, self.context.station)
            self.assertFalse(cancel.is_set())
            self.assertEqual(calls, [])
            self.assertFalse((self.inputs.root / 'results').exists())
            self.assert_owned_state_restored()
            calls.append('prepare')
            prepared = original_prepare(settings=settings, cancel=cancel)
            preparations.append((prepared, settings, cancel))
            clock.now = 200.0
            return prepared

        def deadline(instance):
            calls.append('deadline')
            return original_deadline(instance)

        def opened(**options):
            self.assertEqual(calls, ['prepare', 'deadline'])
            self.assertEqual(options['deadline'], 203.0)
            self.assertIs(options['prepared'], preparations[0][0])
            self.assertIs(options['settings'], preparations[0][1])
            self.assertIs(options['cancel'], preparations[0][2])
            self.assertTrue((self.inputs.root / 'results').exists())
            self.assertTrue(any(thread.name == 'satgs-truth' and thread.is_alive()
                                for thread in threading.enumerate()))
            calls.append('open')
            return original_open(**options)

        with patch.object(support.Transport, 'prepare_transport', side_effect=prepare), \
                patch.object(support.Transport, 'open_bounded', side_effect=opened), \
                patch.object(self.module.PassRunner, '_deadline', deadline), \
                patch.object(self.module.time, 'monotonic', side_effect=lambda: clock.now):
            runner = self.acquired()
            self.assertEqual(len(preparations), 1)
            self.assertIs(runner.cancel_event, preparations[0][2])
            self.assertTrue(preparations[0][0].used)
            self.assertTrue(all(value is not preparations[0][0] for value in vars(runner).values()))
            self.assertFalse(hasattr(self.context, 'prepared'))
            runner.shutdown()
        self.assertEqual(self.event_names().count('messenger.prepare'), 1)
        self.assertEqual(self.event_names().count('messenger.open'), 1)

    def test_preparation_exception_has_fixed_acquisition_status_without_effects(self):
        canary = self.inputs.station['amq_password']
        errors = io.StringIO()
        with patch.object(support.Transport, 'prepare_transport', side_effect=RuntimeError(canary)), \
                redirect_stderr(errors):
            self.assertEqual(self.module.main(self.inputs.argv()), 4)
        self.assertIn('acquisition', errors.getvalue())
        self.assertNotIn(canary, errors.getvalue())
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_actual_cancellation_during_preparation_failure_or_return_precedes_effects(self):
        original = support.Transport.prepare_transport
        for fails in (False, True):
            def prepare(*, settings, cancel):
                prepared = original(settings=settings, cancel=cancel)
                cancel.set()
                if fails:
                    raise RuntimeError(self.inputs.station['amq_password'])
                return prepared

            support.EVENTS.clear()
            with self.subTest(fails=fails), patch.object(support.Transport, 'prepare_transport', side_effect=prepare):
                with self.assertRaises(self.module.RuntimeFailure) as raised:
                    self.construct()
                self.assertEqual(raised.exception.code, 130)
                self.assertEqual(self.event_names(), ['messenger.prepare'])
                self.assertFalse((self.inputs.root / 'results').exists())

    def test_cancelled_owner_text_without_runner_event_remains_acquisition_failure(self):
        def prepare(*, settings, cancel):
            self.assertFalse(cancel.is_set())
            raise RuntimeError('cancelled')

        with patch.object(support.Transport, 'prepare_transport', side_effect=prepare):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 4)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_acquisition_exception_with_actual_cancellation_retains_130_and_cleanup(self):
        def opened(**options):
            support.event('messenger.open')
            options['cancel'].set()
            raise RuntimeError(self.inputs.station['amq_password'])

        with patch.object(support.Transport, 'open_bounded', side_effect=opened):
            with self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct()
        self.assertEqual(raised.exception.code, 130)
        self.assertEqual(self.event_names(), ['messenger.prepare', 'messenger.open'])
        self.assert_owned_state_restored()

    def test_borrowed_rejection_and_exception_use_actual_main_invalid_input_status(self):
        original_runner = self.module.PassRunner
        borrowed = support.Transport()

        def construct_with_borrowed(**options):
            return original_runner(messenger=borrowed, **options)

        for outcome in (False, 1, RuntimeError(self.inputs.station['amq_password'])):
            errors = io.StringIO()
            options = ({'side_effect': outcome} if isinstance(outcome, Exception)
                       else {'return_value': outcome})
            with self.subTest(outcome=type(outcome).__name__), \
                    patch.object(borrowed, 'strict_instance_compatible', **options), \
                    patch.object(self.module, 'PassRunner', side_effect=construct_with_borrowed), \
                    redirect_stderr(errors):
                self.assertEqual(self.module.main(self.inputs.argv()), 2)
            self.assertNotIn(self.inputs.station['amq_password'], errors.getvalue())
            self.assertFalse(borrowed.closed)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_borrowed_legacy_closed_and_mismatched_fixtures_reject_without_effects(self):
        closed = support.Transport.borrowed_for(self.context.station)
        closed.closed = True
        for borrowed in (support.Transport(), closed, support.Transport.borrowed_for({})):
            with self.subTest(borrowed=borrowed), self.assertRaises(self.module.RuntimeConfigurationError):
                self.construct(messenger=borrowed)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_actual_runner_cancellation_during_borrowed_check_precedes_false_or_exception(self):
        original_event = threading.Event
        borrowed = support.Transport.borrowed_for(self.context.station)
        for fails in (False, True):
            created = []

            def event():
                result = original_event()
                created.append(result)
                return result

            def compatible(*, settings):
                self.assertIs(settings, self.context.station)
                created[0].set()
                if fails:
                    raise RuntimeError(self.inputs.station['amq_password'])
                return False

            with self.subTest(fails=fails), patch.object(threading, 'Event', side_effect=event), \
                    patch.object(borrowed, 'strict_instance_compatible', side_effect=compatible):
                with self.assertRaises(self.module.RuntimeFailure) as raised:
                    self.construct(messenger=borrowed)
                self.assertEqual(raised.exception.code, 130)
            self.assertFalse(borrowed.closed)
        self.assertEqual(self.event_names(), [])
        self.assertFalse((self.inputs.root / 'results').exists())

    def test_borrowed_owner_survives_each_later_selected_acquisition_failure(self):
        borrowed = support.Transport.borrowed_for(self.context.station)
        for stage in ('ptu.open', 'pix.open'):
            support.EVENTS.clear()
            support.FAIL_AT.clear()
            support.FAIL_AT.add(stage)
            with self.subTest(stage=stage), self.assertRaises(self.module.RuntimeFailure) as raised:
                self.construct(messenger=borrowed, file_prefix=stage.replace('.', '_'))
            self.assertEqual(raised.exception.code, 4)
            self.assertFalse(borrowed.closed)
            self.assertNotIn('messenger.prepare', self.event_names())
            self.assertNotIn('messenger.open', self.event_names())
            self.assertNotIn('messenger.close', self.event_names())
            self.assertEqual(self.event_names(), ['ptu.open'] if stage == 'ptu.open'
                             else ['ptu.open', 'pix.open', 'ptu.close'])

    def assert_post_preparation_pass(self, *, seconds, admitted, duration=5, elevation=15,
                                     rise=-100, setting=200):
        from satgs.runtime_configuration import load_runtime_configuration
        self.context = load_runtime_configuration(
            *(self.inputs.paths[name] for name in ('deployment.json', 'bindings.json', 'station.yaml', 'tle.csv')),
            sat_id=28626, duration=duration, elevation=elevation)
        support.EVENTS.clear()
        before = sorted(path.relative_to(self.inputs.root) for path in self.inputs.root.rglob('*'))
        with support.noncircumpolar_pass(self.module, rise=rise, setting=setting) as clock:
            def prepared(name, details):
                if name == 'messenger.prepare':
                    clock.seconds = seconds

            support.ON_EVENT = prepared
            try:
                if admitted:
                    runner = self.construct(file_prefix='after_prepare_' + str(seconds).replace('.', '_'))
                    try:
                        self.assertFalse(runner.current_pass_info.is_circumpolar)
                        self.assertEqual(self.event_names().count('messenger.prepare'), 1)
                        self.assertEqual(self.event_names().count('messenger.open'), 1)
                        self.assertFalse(any(name == 'ptu.prime' for name in self.event_names()))
                    finally:
                        runner.shutdown()
                else:
                    with self.assertRaises(self.module.RuntimeConfigurationError):
                        self.construct()
                    self.assertEqual(self.event_names(), ['messenger.prepare'])
                    self.assertEqual(sorted(path.relative_to(self.inputs.root)
                                            for path in self.inputs.root.rglob('*')), before)
            finally:
                support.ON_EVENT = None

    def test_post_preparation_duration_before_equal_and_after_existing_boundary(self):
        for seconds, admitted in ((51, True), (52, True), (53, False)):
            with self.subTest(seconds=seconds):
                self.assert_post_preparation_pass(seconds=seconds, admitted=admitted, duration=148)

    def test_post_preparation_mask_before_equal_and_after_existing_lookahead(self):
        for seconds, admitted in ((89, True), (90, True), (91, False)):
            with self.subTest(seconds=seconds):
                self.assert_post_preparation_pass(seconds=seconds, admitted=admitted)

    def test_post_preparation_set_before_equal_and_after_existing_lookahead(self):
        for seconds, admitted in ((139, True), (140, True), (141, False)):
            with self.subTest(seconds=seconds):
                self.assert_post_preparation_pass(seconds=seconds, admitted=admitted, elevation=0)

    def test_delayed_preparation_preserves_future_and_early_rising_passes(self):
        for rise, setting, seconds in ((100, 300, 10), (-10, 1000, 11)):
            with self.subTest(rise=rise):
                self.assert_post_preparation_pass(seconds=seconds, admitted=True, rise=rise, setting=setting)

    def test_circumpolar_end_uses_fresh_post_preparation_time(self):
        epoch = datetime(2026, 9, 23, 12, tzinfo=timezone.utc)
        clock = SimpleNamespace(seconds=0)

        class VirtualDatetime(datetime):
            @classmethod
            def now(cls, tz=None):
                value = epoch + timedelta(seconds=clock.seconds)
                return value if tz else value.replace(tzinfo=None)

        def prepared(name, details):
            if name == 'messenger.prepare':
                clock.seconds = 30

        support.ON_EVENT = prepared
        try:
            with patch.object(self.module, 'datetime', VirtualDatetime):
                runner = self.acquired()
                self.assertTrue(runner.current_pass_info.is_circumpolar)
                self.assertEqual(runner.absolute_end_time,
                                 epoch + timedelta(seconds=30 + self.context.duration, minutes=3))
                runner.shutdown()
        finally:
            support.ON_EVENT = None


if __name__ == '__main__':
    unittest.main()
