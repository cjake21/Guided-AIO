from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest

from satgs.operator_cli import main, parser
from satgs.operator_core import Workspace
from satgs.operator_presentation import LEGACY_STATION_NAME


class OperatorCliTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name) / 'practice'
        self.call('init')

    def call(self, *arguments, expected=0):
        output = io.StringIO()
        with redirect_stdout(output):
            code = main(['--workspace', str(self.root), '--format', 'json', *arguments])
        self.assertEqual(code, expected, output.getvalue())
        return json.loads(output.getvalue())

    def preview(self):
        return self.call('location-preview', '--latitude-deg', '42', '--longitude-deg', '-71',
                         '--altitude-m', '12.5', '--altitude-reference', 'unspecified')['result']

    def human_call(self, *arguments, expected=0):
        output = io.StringIO()
        with redirect_stdout(output):
            code = main(['--workspace', str(self.root), '--format', 'human', *arguments])
        self.assertEqual(code, expected, output.getvalue())
        return output.getvalue()

    def test_human_output_and_help_remove_disclaimers_without_changing_json_contract(self):
        self.call('replay', '--state', 'critical')
        before = (self.root / 'station.json').read_bytes()
        status = Workspace(self.root).inspect()
        text = self.human_call('status')
        self.assertIn('System health: critical', text)
        self.assertIn('Transport check: transport_pass', text)
        self.assertNotIn('Provenance: synthetic_replay', text)
        self.assertEqual(status['observations']['provenance'], 'synthetic_replay')
        self.assertIn('Source id: synthetic-replay:1/1', text)
        self.assertIn('Enabled: No', text)
        self.assertFalse(text.lstrip().startswith('{'))
        for removed in ('Synthetic operator practice station', 'Warnings:', 'Limits:', 'Planning only:'):
            self.assertNotIn(removed, text)
        self.assertEqual(self.call('status')['result'], status)
        self.assertEqual(before, (self.root / 'station.json').read_bytes())
        help_text = parser().format_help()
        self.assertNotIn('synthetic scratch', help_text)
        self.assertNotIn('explicitly synthetic', help_text)
        self.assertIn('replay', help_text)

    def test_existing_default_fallback_and_custom_name_preservation_only_affect_human_output(self):
        workspace = Workspace(self.root)
        _, settings = workspace.snapshot()
        for name, expected in ((LEGACY_STATION_NAME, 'Station'), ('Cole station', 'Cole station'),
                               (LEGACY_STATION_NAME + ' north', LEGACY_STATION_NAME + ' north')):
            with self.subTest(name=name):
                settings['ground_station_name'] = name
                workspace.station_path.write_text(json.dumps(settings))
                before = workspace.station_path.read_bytes()
                self.assertIn(f'Station name: {expected}\n', self.human_call('reload'))
                self.assertEqual(self.call('status')['result']['station_name'], name)
                self.assertEqual(before, workspace.station_path.read_bytes())

    def test_human_errors_keep_failure_exit_codes_and_json_error_fields(self):
        before = (self.root / 'station.json').read_bytes()
        text = self.human_call('unsupported', expected=2)
        self.assertIn('Error: Unsupported operator arguments; use --help.', text)
        self.assertIn('Code: invalid', text)
        result = self.call('unsupported', expected=2)
        self.assertEqual(result, {'status': 'FAIL', 'error': {'code': 'invalid',
            'message': 'Unsupported operator arguments; use --help.'}})
        self.assertEqual(before, (self.root / 'station.json').read_bytes())

    def test_cli_dispatch_matches_shared_operation_and_requires_confirmation(self):
        preview = self.preview()
        before = (self.root / 'station.json').read_bytes()
        self.call('apply', '--preview', preview['preview_id'], expected=2)
        self.assertEqual((self.root / 'station.json').read_bytes(), before)
        self.call('apply', '--preview', preview['preview_id'], '--confirm')
        actual = self.call('reload')['result']
        self.assertEqual(actual, Workspace(self.root).inspect())
        self.assertEqual(actual['location']['latitude_deg'], 42)

    def test_cancel_is_dispatch_to_shared_cancellation_and_preserves_station(self):
        preview = self.preview()
        before = (self.root / 'station.json').read_bytes()
        self.call('cancel', '--preview', preview['preview_id'])
        self.assertEqual((self.root / 'station.json').read_bytes(), before)
        result = self.call('apply', '--preview', preview['preview_id'], '--confirm', expected=3)
        self.assertEqual(result['status'], 'FAIL')

    def test_report_export_and_replay_remain_explicit_and_private(self):
        result = self.call('replay', '--state', 'critical')['result']
        self.assertIn('synthetic', json.dumps(result))
        self.assertEqual(self.call('status')['result'], Workspace(self.root).inspect())
        output = self.root / 'export.json'
        self.call('export', '--output', str(output))
        self.assertTrue(output.is_file())
        self.assertEqual(output.stat().st_mode & 0o777, 0o600)
        self.call('export', '--output', str(output), expected=4)

    def test_custom_changes_are_loaded_from_the_actual_json_document(self):
        changes = self.root / 'custom.json'
        changes.write_text(json.dumps({'rf.frontend': 'omit'}))
        preview = self.call('components-preview', '--profile', 'custom', '--changes', str(changes))['result']
        self.call('apply', '--preview', preview['preview_id'], '--confirm')
        selection = Workspace(self.root).inspect()['selection']
        frontend = next(item for item in selection['selections'] if item['component'] == 'rf.frontend')
        self.assertEqual(frontend['mode'], 'omit')

    def test_invalid_arguments_and_nonfinite_values_do_not_change_configuration(self):
        before = (self.root / 'station.json').read_bytes()
        self.call('location-preview', '--latitude-deg', 'nan', '--longitude-deg', '0',
                  '--altitude-m', '0', '--altitude-reference', 'unspecified', expected=2)
        self.call('unsupported', expected=2)
        self.assertEqual((self.root / 'station.json').read_bytes(), before)

    def test_human_status_omits_internal_paths_and_hashes_while_json_retains_them(self):
        before = (self.root / 'station.json').read_bytes()
        value = self.call('status')['result']
        text = self.human_call('status')
        self.assertNotIn(str(self.root), text)
        self.assertNotIn(value['station_revision'], text)
        self.assertNotIn(value['workspace_id'], text)
        self.assertEqual(value['workspace'], str(self.root))
        self.assertEqual(value, Workspace(self.root).inspect())
        self.assertEqual((self.root / 'station.json').read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
