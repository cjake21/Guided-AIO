import copy
from dataclasses import FrozenInstanceError
import unittest

from satgs.station_location import (
    Location, LocationError, location_from_settings, prepare_manual_location,
)


class StationLocationTests(unittest.TestCase):
    def setUp(self):
        self.settings = {
            "ground_station_lat": 42, "ground_station_lon": -71.0,
            "ground_station_altm": 12.5,
            "amq_password": "SYNTHETIC-PRIVATE-LOCATION-CANARY",
            "positioners": [{"id": 7, "nested": {"values": [1, 2]}}],
        }

    def prepare(self, **options):
        values = dict(latitude_deg=40, longitude_deg=-70, altitude_m=15,
                      expected_revision="a" * 64, current_revision="a" * 64)
        values.update(options)
        return prepare_manual_location(self.settings, **values)

    def test_configured_source_units_and_public_fields(self):
        location = location_from_settings(self.settings)
        self.assertEqual(location.source, "configured")
        self.assertEqual((location.latitude_deg, location.longitude_deg, location.altitude_m),
                         (42.0, -71.0, 12.5))
        self.assertEqual(set(location.to_dict()),
                         {"source", "latitude_deg", "longitude_deg", "altitude_m", "identity"})
        self.assertRegex(location.identity, r"^[0-9a-f]{64}$")
        self.assertNotIn(self.settings["amq_password"], repr(location))

    def test_manual_selection_preserves_unrelated_fields_and_detaches_settings(self):
        original = copy.deepcopy(self.settings)
        prepared = self.prepare()
        self.assertTrue(prepared.changed)
        self.assertEqual(prepared.location.source, "manual")
        self.assertEqual(self.settings, original)
        output = prepared.settings()
        self.assertEqual(output["amq_password"], original["amq_password"])
        self.assertEqual(output["positioners"], original["positioners"])
        self.assertEqual(output["ground_station_location_source"], "manual")
        output["positioners"][0]["nested"]["values"].append(3)
        self.settings["positioners"][0]["nested"]["values"].append(4)
        self.assertEqual(prepared.settings()["positioners"], original["positioners"])
        with self.assertRaises(FrozenInstanceError):
            prepared.changed = False
        with self.assertRaises(FrozenInstanceError):
            prepared.location.latitude_deg = 0
        with self.assertRaises(TypeError):
            prepared._settings["ground_station_lat"] = 0
        self.assertNotIn(original["amq_password"], repr(prepared))

    def test_identical_manual_retry_is_unchanged(self):
        first = self.prepare()
        self.settings = first.settings()
        second = self.prepare()
        self.assertFalse(second.changed)
        self.assertEqual(first.location, second.location)
        self.assertEqual(first.settings(), second.settings())

    def test_source_change_counts_even_with_equal_coordinates(self):
        before = location_from_settings(self.settings)
        prepared = self.prepare(latitude_deg=42, longitude_deg=-71, altitude_m=12.5)
        self.assertTrue(prepared.changed)
        self.assertNotEqual(before.identity, prepared.location.identity)

    def test_identity_is_numeric_and_location_specific(self):
        before = location_from_settings(self.settings)
        self.settings.update(ground_station_lat=42.0, unrelated="ignored")
        self.assertEqual(before, location_from_settings(self.settings))
        self.assertEqual(Location("manual", 0, 0, 0), Location("manual", -0.0, 0.0, -0.0))
        self.assertNotEqual(before.identity, Location("configured", 42, -71, 13).identity)

    def test_manual_initialization_accepts_all_missing_or_null_coordinates(self):
        for settings in ({}, {"ground_station_lat": None, "ground_station_lon": None,
                              "ground_station_altm": None}):
            with self.subTest(settings=settings):
                self.settings = settings
                self.assertTrue(self.prepare().changed)

    def test_partial_or_malformed_existing_location_is_not_silently_repaired(self):
        for settings in ({"ground_station_lat": 42},
                         {"ground_station_lat": "42", "ground_station_lon": -71,
                          "ground_station_altm": 10}):
            with self.subTest(settings=settings):
                self.settings = settings
                with self.assertRaises(LocationError):
                    self.prepare()

    def test_revision_is_exact_required_and_stale_request_rejects(self):
        for revision in (None, "", "a", "A" * 64, "b" * 64, True, "a" * 63 + "\n"):
            with self.subTest(revision=revision):
                with self.assertRaises(LocationError):
                    self.prepare(expected_revision=revision)

    def test_invalid_numbers_and_geographic_bounds_reject(self):
        for key in ("latitude_deg", "longitude_deg", "altitude_m"):
            for value in (None, True, "1", float("nan"), float("inf"), float("-inf"), 10 ** 1000):
                with self.subTest(key=key, value_type=type(value).__name__):
                    with self.assertRaises(LocationError):
                        self.prepare(**{key: value})
        for values in ({"latitude_deg": 91}, {"latitude_deg": -91},
                       {"longitude_deg": 181}, {"longitude_deg": -181}):
            with self.assertRaises(LocationError):
                self.prepare(**values)
        for latitude, longitude in ((-90, -180), (90, 180)):
            self.assertEqual(self.prepare(latitude_deg=latitude, longitude_deg=longitude,
                                          altitude_m=-10).location.altitude_m, -10.0)

    def test_live_gps_and_unknown_sources_reject_in_shared_api(self):
        for source in ("live-gps", "gps", "configured", None, True):
            with self.subTest(source=source):
                with self.assertRaises(LocationError):
                    self.prepare(source=source)
        self.settings["ground_station_location_source"] = "live-gps"
        with self.assertRaises(LocationError):
            location_from_settings(self.settings)
        with self.assertRaises(LocationError):
            self.prepare()


if __name__ == "__main__":
    unittest.main()
