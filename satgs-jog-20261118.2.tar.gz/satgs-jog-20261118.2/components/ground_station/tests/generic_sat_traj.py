import logging
import yaml
from pathlib import Path
from datetime import datetime, timezone,timedelta
import numpy as np
from satgs.utils import AzElTrajectory
from satgs.pass_test_runner import PassTestRunner
from satgs.utils import make_az_el_scurves, PassInfo, find_passes
from satgs.constants import DEFAULTS
from satgs.post_run_tools import QuickLookTools, make_quick_look_report
import pandas as pd
from ephem import degree as deg2rad
import ephem

EL_RATE = 3 #deg/sec
DEFAULT_CFG = Path('~/ground_station/config/config.yaml').expanduser()

def main():
    
    with open(DEFAULT_CFG) as f:
        config = yaml.safe_load(f)       
    
    sat_file = Path('/home/cubesatpi/ground_station/sat_db.csv')
    tle_df = pd.read_csv(sat_file)

    tle_db = tle_df.set_index('norad_id').to_dict("index")
    ground_station = ephem.Observer()
    ground_station.lat = config['ground_station_lon'] * deg2rad
    ground_station.lon =  config['ground_station_lat'] * deg2rad
    ground_station.elevation =  config['ground_station_altm'] * deg2rad
    ground_station.date = datetime.now(timezone.utc)
    
    sat_id = 35931
    pass_number = 1
    elv_mask = 25
    dt= 2
    passes = find_passes(sat_id, tle_db , ground_station, 
                elv_mask)
    
    test_pass:PassInfo
    sat_trajectory:AzElTrajectory
    test_pass = passes[0]
    sat_trajectory = test_pass.get_trajectory(ground_station, dt = dt)
    sat_trajectory.t_ref = datetime.now(timezone.utc) - timedelta(seconds=15)
    run_name = 'traj_test_sat_{}'.format(sat_id)
    no_ptu = False
    no_pixhawk = False
   
   
    log = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s',datefmt='%b %d %H:%M:%S')
    log.setLevel(logging.DEBUG)


    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)
    log.addHandler(console_handler)

    now = datetime.today()
    logname = f"{run_name}" #_{now.year}-{now.month}-{now.day}_{now.hour}{now.minute}"
    parent_folder = '{}/{}'.format(now.strftime('%m-%d-%Y'),run_name)                
    log_dir = Path(config['logging_dir']) / '{}/{}'.format(parent_folder, logname)        
    if '~' in str(log_dir):
        log_dir = Path(str(log_dir).replace('~', config['home_directory']))                
    if not log_dir.exists():
        log_dir.mkdir(parents=True, mode=0o775) 
    

    file_handler = logging.FileHandler('{}/{}.log'.format(log_dir, logname), 'w+')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)        
    log.addHandler(file_handler)
    
    logging.info("Logging to: {}".format('{}/{}.log'.format(log_dir, logname)))

    
    # Print Arguments 
    try:              
        runner = PassTestRunner(config_file=DEFAULT_CFG, trajectory=sat_trajectory,
                                logname=logname, log_dir=log_dir, el_mask=DEFAULTS.elev_mask)
                            
        runner.run()
    except Exception as e:
        logging.error(e, stack_info=True, exc_info=True)
        raise ValueError('Pass Runner failed, check logs') # Raise error to bring attention in the queue manager subprocess

def run():
    import argparse

    parser = argparse.ArgumentParser(description = 'Generates quick look PDF from ground station logs and IQ recording if available')

    parser.add_argument('sid', type=int, 
                        help = 'Test Dir')     
    parser.add_argument('-e', '--elevationmask', type=float, required=False, default=DEFAULTS.elev_mask,
                        help = ' (deg) Elevation mask, default is {} degrees'.format(DEFAULTS.elev_mask))           
    parser.add_argument('-n','--passnumber', type=int, required=False, default=-1,
                        help = 'Nth pass number')  
    parser.add_argument('--track_rate', type=int, required=False, default=1,
                        help = 'Nth pass number')      
    parser.add_argument('-tref', type=str, required=False, default=None, 
                        help = 'UTC date string yyyy-mm-dd-HH:MM:SS' )               
    parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
                        help = 'Config File')        
    parser.add_argument('--snapshots', nargs="*",  # 0 or more values expected => creates a list
                        type=str, default=None)  
    parser.add_argument('-email', action = 'store_true', default = False, 
                        help= "Flag for emailing report, defaults to False")   
    args = parser.parse_args() 
    
    with open(DEFAULT_CFG) as f:
        config = yaml.safe_load(f)
        
    log = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s',datefmt='%b %d %H:%M:%S')
    log.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)
    log.addHandler(console_handler)

    now = datetime.today()
    run_name = 'test_traj_{}'.format(args.sid)
    
    logname = f"{run_name}_{now.year}-{now.month}-{now.day}_{now.hour}{now.minute}"
    parent_folder = '{}/{}'.format(now.strftime('%m-%d-%Y'),run_name)                
    log_dir = Path(config['logging_dir']) / '{}/{}'.format(parent_folder, logname)        
    if '~' in str(log_dir):
        log_dir = Path(str(log_dir).replace('~', config['home_directory']))                
    if not log_dir.exists():
        log_dir.mkdir(parents=True, mode=0o775) 
    
    file_handler = logging.FileHandler('{}/{}.log'.format(log_dir, logname), 'w+')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)        
    log.addHandler(file_handler)
    logging.info("Logging to: {}".format('{}/{}.log'.format(log_dir, logname)))        
        
    sat_file = Path('~/ground_station/config/sat_db.csv')
    tle_df = pd.read_csv(sat_file)

    tle_db = tle_df.set_index('norad_id').to_dict("index")
    ground_station = ephem.Observer()
    ground_station.lat = config['ground_station_lat'] * deg2rad
    ground_station.lon =  config['ground_station_lon'] * deg2rad
    ground_station.elevation =  config['ground_station_altm'] 
    
    if args.tref is None:
        ground_station.date = datetime.now(timezone.utc)
    else:
        ground_station.date = datetime.strptime(args.tref, '%Y-%m-%d-%H:%M:%S').replace(tzinfo=timezone.utc)   
 
    passes = find_passes(args.sid, tle_db , ground_station, 
                args.elevationmask)
         
    test_pass:PassInfo
    sat_trajectory:AzElTrajectory
    test_pass = passes[args.passnumber-1]
    sat_trajectory = test_pass.get_trajectory(ground_station, dt = args.track_rate*1.0)
    sat_trajectory.t_ref = datetime.now(timezone.utc) - timedelta(seconds=60)
    # Update this so we find the correct pass later
    ground_station.date = test_pass.sat_rise_time- timedelta(minutes=2)
    try:              
        runner = PassTestRunner(config_file=DEFAULT_CFG, 
                                use_ref_time=True,
                                trajectory=sat_trajectory,
                                logname=logname, 
                                log_dir=log_dir, 
                                el_mask=DEFAULTS.elev_mask,
                                pass_info=test_pass,
                                ground_station=ground_station
                                )
                            
        runner.run()
        # QuickLookTools
        make_quick_look_report(runner.log_dir, Path(args.config), 10, True)
    except Exception as e:
        logging.error(e, stack_info=True, exc_info=True)
        raise ValueError('Pass Runner failed, check logs') # Raise error to bring attention in the queue manager subprocess        



if __name__ == '__main__':
    run()
