import ast
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
import tempfile
import types
import unittest


ROOT = Path(__file__).resolve().parents[1]


def builder():
    path = ROOT / "tools/build_operator_docs.py"
    module = types.ModuleType("guide_build_content_test")
    module.__file__ = str(path)
    sys.modules[module.__name__] = module
    exec(compile(path.read_bytes(), str(path), "exec", dont_inherit=True), vars(module))
    return module


class GuideMarkup(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.links = []
        self.assets = []
        self.headings = []
        self.scripts = []

    def handle_starttag(self, tag, attributes):
        values = dict(attributes)
        if "id" in values:
            self.ids.append(values["id"])
        if tag == "a":
            self.links.append(values.get("href", ""))
        if tag in ("link", "img", "script", "iframe"):
            self.assets.append(values.get("href", values.get("src", "")))
        if tag in ("h1", "h2", "h3", "h4"):
            self.headings.append(tag)
        if tag == "script":
            self.scripts.append(values)


class OperatorGuideContentTests(unittest.TestCase):
    def test_build_is_deterministic_linked_local_and_version_matched(self):
        module = builder()
        with tempfile.TemporaryDirectory(prefix="satgs guide content ") as temporary:
            first, second = Path(temporary) / "first", Path(temporary) / "second"
            manifest = module.build(ROOT, first)
            self.assertEqual(manifest, module.build(ROOT, second))
            self.assertEqual(len(module.CHAPTERS), 13)
            self.assertEqual(set(manifest["sources"]), {"docs/" + name + ".md" for name in module.CHAPTERS} | set(module.IMAGES))
            self.assertEqual(set(manifest["outputs"]), {"user-guide.html", "user-guide.txt", "user-guide.css"} | set(module.IMAGES.values()))
            for path in first.iterdir():
                self.assertEqual(path.read_bytes(), (second / path.name).read_bytes())
                self.assertNotIn(str(ROOT).encode(), path.read_bytes())
            for name, digest in manifest["outputs"].items():
                self.assertEqual(hashlib.sha256((first / name).read_bytes()).hexdigest(), digest)
            markup = GuideMarkup()
            document = (first / "user-guide.html").read_text()
            markup.feed(document)
            self.assertEqual(len(markup.ids), len(set(markup.ids)))
            self.assertEqual(markup.headings.count("h1"), 1)
            self.assertEqual(markup.assets, ["user-guide.css", *module.IMAGES.values()])
            for source, output in module.IMAGES.items():
                self.assertEqual((first / output).read_bytes(), (ROOT / source).read_bytes())
            self.assertFalse(markup.scripts)
            self.assertIn('lang="en"', document)
            self.assertIn('href="#main"', document)
            for target in markup.links:
                self.assertTrue(target.startswith(("#", "https://")), target)
                if target.startswith("#"):
                    self.assertIn(target[1:], markup.ids)
            text = (first / "user-guide.txt").read_text()
            for phrase in ("Purpose and architecture", "Choose a configuration", "Component handbook",
                           "Install and prepare", "Start and use", "station location", "Operate the PTU",
                           "Practice without hardware", "Save, find and reuse", "Original M-SEL",
                           "Updates rollback", "CLI reference", "Glossary", "Maintainer reference",
                           manifest["application_version"]):
                self.assertIn(phrase, text)
            self.assertNotIn("```", text)
            self.assertNotIn("<section", text)
            self.assertNotIn("@import", (first / "user-guide.css").read_text())

    def test_builder_rejects_unknown_links_and_duplicate_headings(self):
        module = builder()
        for source in ("# Chapter\n\n[Wrong](absent.md)\n", "# Chapter\n\n## Repeated\n\n## Repeated\n"):
            with self.subTest(source=source), self.assertRaises(ValueError):
                module._chapter("operator-guide", source, set(), set())
        _, escaped, _ = module._chapter("operator-guide", "# Chapter\n\n<script>never executable</script>\n", set(), set())
        self.assertIn("&lt;script&gt;", escaped)
        self.assertNotIn("<script>", escaped)
        with self.assertRaises(ValueError):
            module._chapter("operator-guide", "# Chapter\n\n![Unknown](assets/unknown.png)\n", set(), set())

    def test_documented_commands_and_widget_labels_match_source(self):
        reference = (ROOT / "docs/operator-cli-reference.md").read_text()
        cli_tree = ast.parse((ROOT / "src/satgs/operator_cli.py").read_text())
        for node in ast.walk(cli_tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "add_parser":
                if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                    self.assertIn(node.args[0].value, reference)
        gui_source = (ROOT / "src/satgs/operator_gui.py").read_text()
        guide = "\n".join((ROOT / "docs" / (name + ".md")).read_text() for name in builder().CHAPTERS)
        for label in ("Home", "Setup", "Location", "Review", "Results", "Run", "PTU", "Save", "Calculate", "Report", "Export...", "Review run", "Start run", "Cancel run", "Use GPS", "Directions: hold locally / broker steps", "Broker step (degrees)", "Enable broker steps", "Disarm", "Keys", "Save local QPT130"):
            self.assertIn('"' + label + '"', gui_source)
            self.assertIn(label, guide)
        for form in ("satgs-operator docs", "satgs-operator --read-docs", "satgs-operator docs --text"):
            self.assertIn(form, reference)
        for form in ("manual STEP_DEGREES", "step left|right|up|down", "disarm"):
            self.assertIn(form, reference)

    def test_every_canonical_component_has_a_substantial_owner_section(self):
        manifest = json.loads((ROOT / "config/deployment_profiles.json").read_text())
        expected = {entry["id"] for profile in manifest["profiles"]
                    for field in ("packages", "capabilities") for entry in profile[field]}
        self.assertEqual(len(expected), 24)
        chapter = (ROOT / "docs/component-handbook.md").read_text()
        parts = re.split(r"^### ([a-z0-9_.-]+)\n", chapter, flags=re.MULTILINE)
        sections = dict(zip(parts[1::2], parts[2::2]))
        self.assertEqual(set(sections), expected)
        for identity, text in sections.items():
            with self.subTest(component=identity):
                self.assertGreaterEqual(len(text.split()), 80)
        for choice in ("install", "reuse", "external", "omit"):
            self.assertIn("`" + choice + "`", (ROOT / "docs/configurations.md").read_text())

    def test_retention_and_original_ptu_contracts_are_explicit(self):
        results = (ROOT / "docs/results.md").read_text()
        for name in ("station.json", "preview-<preview_id>.json", "receipt-<preview_id>.json",
                     "cancel-<preview_id>.json", "plan-<plan_id>.json", "run-request-<request_id>.json",
                     "run-<request_id>-started.json", "run-<request_id>-progress.json",
                     "run-<request_id>-cancel.json", "run-<request_id>-result.json"):
            self.assertIn(name, results)
        self.assertIn("Export does not bundle", results)
        self.assertIn("original absolute workspace path", results)
        ptu = (ROOT / "docs/ptu-operation.md").read_text()
        for phrase in ("override_soft_limits=True", "zero jog", "KeepAlive", "fresh", "physical Stop"):
            self.assertIn(phrase.lower(), ptu.lower())
        ordinary = "\n".join((ROOT / "docs" / (name + ".md")).read_text()
                             for name in builder().CHAPTERS if name != "maintainer-reference")
        self.assertNotIn("Science", ordinary)
        self.assertEqual((ROOT / "docs/maintainer-reference.md").read_text().count("Science"), 1)

    def test_examples_are_explicit_hardware_free_and_tle_matches_packaged_fixture(self):
        examples = json.loads((ROOT / "tests/operator_guide_examples.json").read_text())
        self.assertEqual(examples["schema"], "satgs-guide-examples.v1")
        names = [step["name"] for step in examples["steps"]]
        self.assertEqual(len(names), len(set(names)))
        allowed = {"init", "status", "reload", "components-preview", "location-preview", "apply", "cancel", "plan", "replay", "report", "export"}
        self.assertTrue(all(step["argv"][0] in allowed for step in examples["steps"]))
        self.assertLessEqual(len(names), 40)
        self.assertTrue({"full-preview", "reject-full-custom-identities", "guided-restore-preview",
                         "custom-preview", "custom-save", "custom-reload"} <= set(names))
        self.assertIn("CUSTOM", examples["substitutions"])
        changes = examples["custom_changes"]
        self.assertEqual(set(changes.values()), {"omit"})
        configurations = (ROOT / "docs/configurations.md").read_text()
        for component, mode in changes.items():
            self.assertIn('"' + component + '":"' + mode + '"', configurations)
        tutorial = (ROOT / "docs/operator-tutorial.md").read_text()
        csv = tutorial.split("```csv\n", 1)[1].split("```", 1)[0]
        self.assertEqual(csv.encode(), (ROOT / "src/satgs/data/operator_tle.csv").read_bytes())
        for number in ("34", "-118", "100", "-117"):
            self.assertIn(number, tutorial)
        readable = " ".join(tutorial.split())
        self.assertIn("does not initialize the daily station", readable)
        self.assertIn("ordinary owner admission remains closed", readable)


if __name__ == "__main__":
    unittest.main()
