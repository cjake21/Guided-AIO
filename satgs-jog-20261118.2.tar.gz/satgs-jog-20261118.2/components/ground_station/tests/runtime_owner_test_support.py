"""Adapted accepted October owner fixture, with real astronomy and boundary devices."""

from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
import hashlib
import inspect
import json
from pathlib import Path
import sys
import threading
import time
from unittest.mock import patch

from test_messenger_lifecycle import PrimitiveHarness, PrimitiveSocket
from test_ptu_manager_pointing import FollowingSerial

from meteor_api.messenger import Messenger
from pixhawk import pixhawk_pb2
from pixhawk.constants import Topics as PixTopics
from pixhawk.pixhawk_subscriber import PixhawkSubscriber
from ptu_control import ptu_msg_pb2
from ptu_control import ptu_manager as manager_module
from ptu_control.constants import Topics as PtuTopics
from ptu_control.ptu_client import PtuClient
from ptu_control.ptu_manager import PtuManager
from satgs import pass_runner
from serialptu.proto_impl import PTCR20
from serialptu.ptu import PTU


@contextmanager
def reviewed_test_owners():
    """Keep development declarations inside this fixture's owning lifetime."""
    def assert_rejected():
        if pass_runner._REVIEWED_OWNER_RELEASES:
            raise AssertionError("operational owner admission must remain empty")
        try:
            pass_runner._pointing_owner_types()
        except pass_runner.RuntimeFailure as error:
            if error.code != 3:
                raise AssertionError("unexpected unreviewed owner rejection") from error
        else:
            raise AssertionError("unreviewed operational owners were admitted")

    assert_rejected()
    components = Path(__file__).parents[2]
    modules = (
        (Messenger, "meteor-api", "satgs.pointing.v2", "meteor_api/messenger.py"),
        (PtuClient, "sat_tracker", "satgs.pointing.v1", "ptu_control/ptu_client.py"),
        (PixhawkSubscriber, "pixhawk", "satgs.pointing.v1", "pixhawk/pixhawk_subscriber.py"),
    )
    runner_path = Path(pass_runner.__file__).resolve()
    source_runner = components / "ground_station/src/satgs/pass_runner.py"
    installed = runner_path.parent.parent
    if runner_path != source_runner and (installed.name != "site-packages"
            or runner_path != installed / "satgs/pass_runner.py"):
        raise AssertionError("runner origin is not the selected candidate")
    declarations = {}
    original = None
    try:
        with ExitStack() as stack:
            for owner, component, contract, relative in modules:
                path = Path(inspect.getfile(owner)).resolve()
                expected = components / component / "src" / relative if runner_path == source_runner else installed / relative
                if path != expected:
                    raise AssertionError("owner origin is not the selected candidate")
                revision = "development-test-sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()
                declarations[component] = (revision,)
                stack.enter_context(patch.object(owner, "CONTRACT_REVISION", contract, create=True))
                stack.enter_context(patch.object(owner, "SOURCE_REVISION", revision, create=True))
            stack.enter_context(patch.dict(pass_runner._REVIEWED_OWNER_RELEASES, declarations, clear=True))
            if pass_runner._pointing_owner_types() != (Messenger, PtuClient, PixhawkSubscriber):
                raise AssertionError("runner selected different owners")
            yield
    except BaseException as error:
        original = error
        raise
    finally:
        try:
            assert_rejected()
        except BaseException:
            if original is None:
                raise
            original.add_note("Post-fixture operational owner rejection check failed.")


class AcceptedSocket(PrimitiveSocket):
    def send(self, data):
        accepted = super().send(data)
        if type(accepted) is not int or not 0 <= accepted <= len(data):
            raise AssertionError("invalid controlled transport send result")
        self.harness.broker.accept(self, bytes(data[:accepted]))
        return accepted


class RecordingBroker:
    def __init__(self, ptu_id, pixhawk_id):
        self.ptu_id, self.pixhawk_id = ptu_id, pixhawk_id
        self.lock = threading.RLock()
        self.buffers = {}
        self.subscriptions = {}
        self.published = []
        self.bytes_received = self.frame_count = self.delivery_count = 0
        self.drop_outcomes = False

    def accept(self, endpoint, accepted):
        with self.lock:
            self.bytes_received += len(accepted)
            if self.bytes_received > 1024 * 1024:
                raise AssertionError("recording broker byte budget exceeded")
            buffer = self.buffers.setdefault(endpoint, bytearray())
            buffer.extend(accepted)
            if len(buffer) > 65536:
                raise AssertionError("recording broker incomplete-frame budget exceeded")
            while True:
                while buffer.startswith(b"\n"):
                    del buffer[:1]
                split = buffer.find(b"\n\n")
                if split < 0:
                    return
                lines = bytes(buffer[:split]).decode("ascii").split("\n")
                headers = {}
                for line in lines[1:]:
                    key, value = line.split(":", 1)
                    if key in headers:
                        raise AssertionError("duplicate controlled STOMP header")
                    headers[key] = value
                start = split + 2
                if "content-length" in headers:
                    length = int(headers["content-length"])
                    if not 0 <= length <= 32768:
                        raise AssertionError("recording broker message budget exceeded")
                    end = start + length
                    if len(buffer) <= end:
                        return
                    if buffer[end] != 0:
                        raise AssertionError("missing controlled STOMP terminator")
                else:
                    end = buffer.find(b"\0", start)
                    if end < 0:
                        return
                body = bytes(buffer[start:end])
                del buffer[:end + 1]
                self.frame_count += 1
                if self.frame_count > 1024:
                    raise AssertionError("recording broker frame budget exceeded")
                self._frame(endpoint, lines[0], headers, body)

    def _frame(self, endpoint, command, headers, body):
        if command in ("CONNECT", "STOMP", "DISCONNECT"):
            return
        if command == "SUBSCRIBE":
            self.subscriptions[endpoint, headers["id"]] = headers["destination"]
            return
        if command == "UNSUBSCRIBE":
            self.subscriptions.pop((endpoint, headers["id"]), None)
            return
        if command != "SEND":
            raise AssertionError("unexpected controlled STOMP command")
        destination = headers["destination"]
        self.published.append((destination, body))
        outcomes = f"{PtuTopics.SCHEDULED_OUTCOME}_{self.ptu_id}"
        if destination != outcomes or not self.drop_outcomes:
            self._deliver(destination, body)
        if destination == f"{PixTopics.PING_CMD}_{self.pixhawk_id}":
            if not pixhawk_pb2.PingCmd.FromString(body).ping:
                raise AssertionError("invalid selected Pixhawk ping")
            self._deliver(f"{PixTopics.PONG_RESPONSE}_{self.pixhawk_id}",
                pixhawk_pb2.PongResponse(pix_id=self.pixhawk_id).SerializeToString())
        scheduled = f"{PtuTopics.SCHEDULED_COMMAND}_{self.ptu_id}"
        if destination == scheduled and ptu_msg_pb2.ScheduledCommand.FromString(body).operation == ptu_msg_pb2.ScheduledCommand.PRIME:
            observation = pixhawk_pb2.fused_msg(pix_id=self.pixhawk_id,
                pc_time="2026-11-10 00:00:00 UTC", pitch=1, roll=2,
                gpsStatus=4, gps2Status=4, lat=42, lon=-71, alt=12.5)
            self._deliver(f"{PixTopics.DATA_MSG}_{self.pixhawk_id}", observation.SerializeToString())

    def _deliver(self, destination, body):
        for (endpoint, identifier), topic in tuple(self.subscriptions.items()):
            if topic != destination or endpoint.resource["closed"]:
                continue
            self.delivery_count += 1
            if self.delivery_count > 2048:
                raise AssertionError("recording broker delivery budget exceeded")
            headers = (f"MESSAGE\nsubscription:{identifier}\ndestination:{destination}\n"
                       f"content-length:{len(body)}\n\n").encode("ascii")
            endpoint.recv_script.append(headers + body + b"\0")

    def messages(self, destination):
        with self.lock:
            return tuple(body for topic, body in self.published if topic == destination)


class BrokerHarness(PrimitiveHarness):
    def __init__(self, ptu_id, pixhawk_id):
        super().__init__(real_time=True)
        self.broker = RecordingBroker(ptu_id, pixhawk_id)

    def allocate(self, *args, **kwargs):
        resource = {"closed": False}
        raw = PrimitiveSocket(self, "raw", resource)
        tls = AcceptedSocket(self, "tls", resource)
        raw.tls = tls
        tls.recv_script.append(self.incoming)
        self.raws.append(raw)
        self.tls_sockets.append(tls)
        self.allocations.append((args, kwargs))
        self.phase("allocate")
        return raw


class LoopbackBrokerSocket(AcceptedSocket):
    def _would_block(self):
        return BlockingIOError()

    def __getattribute__(self, name):
        if name in ("pending", "do_handshake", "unwrap"):
            raise AttributeError(name)
        return super().__getattribute__(name)


class LoopbackBrokerHarness(BrokerHarness):
    def allocate(self, *args, **kwargs):
        raw = LoopbackBrokerSocket(self, "raw", {"closed": False})
        raw.tls = raw
        raw.recv_script.append(self.incoming)
        self.raws.append(raw)
        self.allocations.append((args, kwargs))
        self.phase("allocate")
        return raw

    def open(self, values, cancel=None):
        cancel = self.cancel if cancel is None else cancel
        prepared = Messenger.prepare_bench_loopback_transport(values, cancel)
        instance = Messenger.open_bench_loopback_bounded(values, self.deadline(), cancel, prepared=prepared)
        self.instances.append(instance)
        return instance


class OwnerScenario:
    def __init__(self, context, *, epoch=None):
        self.context = context
        self.epoch = epoch
        self.stack = ExitStack()
        self.harness = BrokerHarness(context.ptu.manager_id, context.pixhawk.manager_id)
        self.manager = self.driver = self.native = self.messenger = None
        self.cancel = threading.Event()
        self.cleanup_errors = []
        self.cleanup_observations = {}
        self.exception_observations = []
        self._diagnostics_emitted = False
        self.observer_type = manager_module.ephem.Observer
        self.observer_clock_observations = []

    def __enter__(self):
        self.worker_baseline = set(threading.enumerate())
        try:
            self.stack.enter_context(reviewed_test_owners())
            self.stack.enter_context(self.harness)
            if self.epoch is not None:
                if type(self.epoch) is not datetime or self.epoch.tzinfo is not timezone.utc:
                    raise AssertionError("synthetic clock requires an explicit UTC epoch")
                epoch, started = self.epoch, time.monotonic()

                class ScenarioDatetime(datetime):
                    @classmethod
                    def now(cls, tz=None):
                        instant = epoch.timestamp() + time.monotonic() - started
                        return cls.fromtimestamp(instant, tz=tz)

                self.stack.enter_context(patch.object(pass_runner, "datetime", ScenarioDatetime))
                self.stack.enter_context(patch.object(manager_module, "datetime", ScenarioDatetime))
                from satgs.utils import TLE
                tle_epoch = TLE(tle_str=self.context.tle.tle).tle_epoch

                def clocked_observer():
                    if len(self.observer_clock_observations) >= 64:
                        raise AssertionError("controlled observer creation budget exceeded")
                    clock = ScenarioDatetime.now(timezone.utc)
                    observer = self.observer_type()
                    observer.date = clock
                    clock_date = float(manager_module.ephem.Date(clock))
                    if type(observer) is not self.observer_type or float(observer.date) != clock_date:
                        raise AssertionError("genuine observer did not retain its controlled creation date")
                    self.observer_clock_observations.append({
                        "genuine_observer": True, "observer_date_days": float(observer.date),
                        "clock_date_days": clock_date, "clock_utc": clock.isoformat(),
                        "fixture_epoch_utc": epoch.isoformat(), "tle_epoch_utc": tle_epoch.isoformat(),
                    })
                    return observer

                self.stack.enter_context(patch.object(manager_module.ephem, "Observer", clocked_observer))
            self.messenger = self.harness.open(self.context.station)
            protocol = PTCR20()
            self.native = FollowingSerial(protocol)
            with patch("serialptu.ptu.serial.Serial", return_value=self.native):
                self.driver = PTU(protocol, "recording-only", pointing=True)
            self.deadline = time.monotonic() + 20
            self.manager = PtuManager.open_pointing(messenger=self.messenger,
                settings=self.context.station, ptu_id=self.context.ptu.manager_id,
                driver=self.driver, elevation_mask=self.context.elevation,
                no_go_data=self.context.no_go_data, run_deadline=self.deadline,
                cancel=self.cancel, outcome_timeout=.25)
            owner_type = type(self.manager)
            translated = owner_type._translated

            def observe_exception(error, submitted=None):
                try:
                    if len(self.exception_observations) < 8:
                        chain, seen = [], set()
                        current = error
                        while current is not None and id(current) not in seen and len(chain) < 3:
                            seen.add(id(current))
                            frames = []
                            traceback = current.__traceback__
                            while traceback is not None and len(frames) < 8:
                                code = traceback.tb_frame.f_code
                                frames.append({"filename": code.co_filename,
                                               "function": code.co_name,
                                               "line": traceback.tb_lineno})
                                traceback = traceback.tb_next
                            chain.append({"exception_type": type(current).__name__, "frames": frames})
                            current = current.__cause__ or current.__context__
                        self.exception_observations.append(chain)
                except BaseException:
                    pass
                return translated(error, submitted)

            self.stack.enter_context(patch.object(owner_type, "_translated", staticmethod(observe_exception)))
            self.manager.activate(deadline=self.deadline, cancel=self.cancel)
            if self.native.motion():
                raise AssertionError("strict activation unexpectedly submitted motion")
            return self
        except BaseException as error:
            self._release()
            if self.cleanup_errors:
                error.add_note("Owner fixture cleanup: " + ", ".join(self.cleanup_errors))
            raise

    def __exit__(self, kind, value, traceback):
        self._release()
        if self.cleanup_errors:
            if value is not None:
                value.add_note("Owner fixture cleanup: " + ", ".join(self.cleanup_errors))
            else:
                raise AssertionError(tuple(self.cleanup_errors))

    def _release(self):
        def attempt(name, action):
            try:
                action()
            except BaseException:
                self.cleanup_errors.append(name)

        receivers = {worker for worker in threading.enumerate()
                     if worker not in self.worker_baseline and worker.name == "stomp-bounded-receiver"}
        if self.messenger is not None:
            worker = getattr(self.messenger._lower.transport, "_bounded_receiver", None)
            if worker is not None:
                receivers.add(worker)
        if self.manager is not None:
            attempt("manager-close", lambda: self.manager.close(deadline=time.monotonic() + 2))
        if self.driver is not None and not getattr(self.driver, "_pointing_closed", False):
            attempt("driver-close", lambda: self.driver.close(deadline=time.monotonic() + 2))
        if self.messenger is not None:
            attempt("messenger-close", lambda: self.messenger.close(time.monotonic() + 2))
        attempt("fixture-stack-close", self.stack.close)
        if self.native is not None and self.native.opened:
            self.cleanup_errors.append("serial-remained-open")
            attempt("recording-serial-close", self.native.close)
        deadline = time.monotonic() + 2
        for worker in receivers:
            attempt("receiver-join", lambda worker=worker: worker.join(max(0, deadline - time.monotonic())))
        if all(not worker.is_alive() for worker in receivers):
            attempt("transport-primitives-close", self.harness.stack.close)
        self.cleanup_observations = {
            "serial_closed": self.native is None or not self.native.opened,
            "receivers_joined": all(not worker.is_alive() for worker in receivers),
            "transport_closed": all(item.resource["closed"] for item in self.harness.raws),
            "harness_recovery": tuple(getattr(self.harness, "recovery_failures", ())),
        }
        for name, valid in self.cleanup_observations.items():
            if (name == "harness_recovery" and valid) or (name != "harness_recovery" and not valid):
                self.cleanup_errors.append(name)
        if self.exception_observations and not self._diagnostics_emitted:
            self._diagnostics_emitted = True
            print("OWNER_EXCEPTION_DIAGNOSTIC " + json.dumps(self.exception_observations,
                  sort_keys=True), file=sys.stderr)
        if self.observer_clock_observations:
            print("OWNER_OBSERVER_CLOCK " + json.dumps(self.observer_clock_observations,
                  sort_keys=True), file=sys.stderr)

    def scheduled_commands(self):
        topic = f"{PtuTopics.SCHEDULED_COMMAND}_{self.context.ptu.manager_id}"
        return tuple(ptu_msg_pb2.ScheduledCommand.FromString(body)
                     for body in self.harness.broker.messages(topic))
