import tempfile
from pathlib import Path
import unittest

import runtime_test_support as support


class LocationRunnerBoundaryTests(unittest.TestCase):
    def test_manual_location_rejected_before_strict_and_legacy_owner_acquisition(self):
        with tempfile.TemporaryDirectory() as directory:
            inputs = support.Inputs(Path(directory))
            inputs.station['ground_station_location_source'] = 'manual'
            inputs.write()
            context = inputs.load()
            with support.controlled_runner() as module:
                for options in ({'runtime_context': context}, {}):
                    with self.subTest(strict=bool(options)):
                        with self.assertRaisesRegex(module.RuntimeConfigurationError, 'owner reinitialization'):
                            module.PassRunner(inputs.paths['station.yaml'], inputs.paths['tle.csv'],
                                              28626, **options)
                        self.assertEqual(support.EVENTS, [])
                        self.assertFalse((inputs.root / 'results').exists())


if __name__ == '__main__':
    unittest.main()
