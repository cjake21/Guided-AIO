from pathlib import Path
import tempfile
import unittest

from satgs.operator_core import OperatorError, initialize_workspace
from satgs.operator_planning import plan_workspace


class OperatorPlanningTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.workspace = initialize_workspace(Path(self.temporary.name) / 'station')

    def select(self, latitude=42.0, longitude=-71.0, altitude=12.5):
        preview = self.workspace.preview_location(latitude_deg=latitude, longitude_deg=longitude,
            altitude_m=altitude, altitude_reference='unspecified')
        return self.workspace.apply(preview['preview_id'])

    def test_real_calculation_uses_reloaded_selected_station_and_invalidates_old_plan(self):
        self.select()
        first = plan_workspace(self.workspace)
        self.assertTrue(first['opportunities'])
        self.assertEqual(first['location']['latitude_deg'], 42.0)
        self.assertFalse(first['refresh_performed'])
        self.assertFalse(first['execution_enabled'])
        self.select(latitude=34.0, longitude=-118.0)
        second = plan_workspace(type(self.workspace)(self.workspace.root))
        self.assertTrue(second['opportunities'])
        self.assertEqual(second['location']['latitude_deg'], 34.0)
        self.assertNotEqual(first['station_revision'], second['station_revision'])
        self.assertNotEqual(first['opportunities'], second['opportunities'])
        self.assertTrue(any(item['revalidation_required'] for item in self.workspace.inspect()['plans']))

    def test_unconfigured_and_invalid_plan_parameters_do_not_create_a_plan(self):
        with self.assertRaises((OperatorError, ValueError)):
            plan_workspace(self.workspace)
        self.select()
        for options in ({'span_days': float('nan')}, {'span_days': 8},
                        {'elevation_deg': True}, {'start_time': '2025-05-16'},
                        {'norad_id': True}, {'norad_id': 25544}):
            with self.subTest(options=options), self.assertRaises(OperatorError):
                plan_workspace(self.workspace, **options)

    def test_local_tle_is_read_without_refresh_or_modification(self):
        self.select()
        source = Path(__file__).parents[1] / 'src/satgs/data/operator_tle.csv'
        copied = self.workspace.root / 'local-tle.csv'
        raw = source.read_bytes()
        copied.write_bytes(raw)
        result = plan_workspace(self.workspace, tle_file=copied)
        self.assertEqual(copied.read_bytes(), raw)
        self.assertEqual(result['source'], 'operator_selected_local_tle')
        self.assertFalse(result['refresh_performed'])

    def test_selected_tle_rejects_mismatched_element_identity_checksum_and_headers(self):
        self.select()
        source = Path(__file__).parents[1] / 'src/satgs/data/operator_tle.csv'
        raw = source.read_bytes()
        variants = (raw.replace(b'1 25338', b'1 25544'),
                    raw.replace(b'00000+0', b'10000+0'),
                    raw.replace(b'norad_id,name,', b'norad_id,norad_id,'))
        for index, invalid in enumerate(variants):
            with self.subTest(index=index):
                target = self.workspace.root / f'invalid-{index}.csv'
                target.write_bytes(invalid)
                with self.assertRaises(OperatorError):
                    plan_workspace(self.workspace, tle_file=target)
        self.assertEqual(list(self.workspace.root.glob('plan-*.json')), [])


if __name__ == '__main__':
    unittest.main()
