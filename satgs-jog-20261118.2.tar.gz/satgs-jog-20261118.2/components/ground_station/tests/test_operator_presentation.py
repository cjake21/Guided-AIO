from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from satgs.operator_core import Workspace, initialize_workspace
from satgs.operator_presentation import (
    LEGACY_STATION_NAME, document_text, gps_document, human_text, presentation_document, station_name,
    display_document, display_document_text, display_message,
)


class OperatorPresentationTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name) / "station"
        self.workspace = initialize_workspace(self.root)

    def test_new_default_and_exact_legacy_fallback_do_not_change_existing_data(self):
        self.assertEqual(self.workspace.inspect()["station_name"], "Station")
        _, settings = self.workspace.snapshot()
        settings["ground_station_name"] = LEGACY_STATION_NAME
        self.workspace.station_path.write_text(json.dumps(settings))
        before = self.workspace.station_path.read_bytes()
        status = Workspace(self.root).inspect()
        view = presentation_document(status)
        self.assertEqual(view["station_name"], "Station")
        self.assertEqual(status["station_name"], LEGACY_STATION_NAME)
        self.assertEqual(view["workspace_id"], status["workspace_id"])
        self.assertEqual(view["station_revision"], status["station_revision"])
        self.assertEqual(before, self.workspace.station_path.read_bytes())
        self.assertNotIn(LEGACY_STATION_NAME, document_text(status))

    def test_custom_names_are_not_trimmed_or_replaced(self):
        for name in ("Cole's station", "Synthetic operator practice station north",
                     LEGACY_STATION_NAME + " ", "Station 7"):
            with self.subTest(name=name):
                self.assertEqual(station_name(name), name)
        for name in (None, "", LEGACY_STATION_NAME):
            with self.subTest(name=name):
                self.assertEqual(station_name(name), "Station")

    def test_status_view_removes_disclaimers_without_changing_source_or_health(self):
        self.workspace.replay("critical")
        status = self.workspace.inspect()
        original = deepcopy(status)
        view = presentation_document(status)
        self.assertEqual(status, original)
        self.assertEqual(view["status"], status["status"])
        self.assertEqual(view["status"]["system_health"], "critical")
        self.assertEqual(view["status"]["transport_check"], "transport_pass")
        self.assertEqual(view["observations"], status["observations"])
        self.assertEqual(view["observations"]["provenance"], "synthetic_replay")
        self.assertEqual(view["measured_gps"]["source_id"], status["measured_gps"]["source_id"])
        self.assertEqual(view["measured_gps"]["coordinates"], status["measured_gps"]["coordinates"])
        self.assertFalse(view["gps_selection"]["enabled"])
        self.assertFalse(view["measured_gps"]["valid_for_station_selection"])
        self.assertNotIn("limits", view)
        self.assertNotIn("planning_only", view)
        self.assertNotIn("unavailable_reason", view["measured_gps"])
        self.assertTrue(status["limits"])
        self.assertEqual(len(status["gps_selection"]["unmet_requirements"]), 4)

    def test_unknown_location_and_observations_do_not_become_zero_or_ready(self):
        view = presentation_document(self.workspace.inspect())
        self.assertEqual(view["effective_location"], "No location set.")
        self.assertIsNone(view["measured_gps"]["coordinates"])
        self.assertEqual(view["status"]["system_health"], "unknown")
        self.assertEqual(view["measured_gps"]["fix"], "unknown")
        self.assertEqual(gps_document({}), {})

    def test_component_preview_keeps_review_values_and_actual_plan_state(self):
        preview = self.workspace.preview_components("guided_arrow")
        original = deepcopy(preview)
        view = presentation_document(preview)
        self.assertEqual(view["previous"], preview["previous"])
        self.assertEqual(view["proposed"]["configuration"], preview["proposed"]["configuration"])
        self.assertEqual(view["expected_revision"], preview["expected_revision"])
        for field in ("apply_supported", "complete", "blocked", "outcomes"):
            self.assertEqual(view["proposed"]["plan"][field], preview["proposed"]["plan"][field])
        self.assertNotIn("diagnostics", view["proposed"]["plan"])
        self.assertEqual(preview, original)

    def test_plan_view_keeps_sources_units_values_and_disabled_execution(self):
        plan = {"station_revision": "a" * 64, "source": "bundled_historical_replay",
                "opportunities": [{"maximum_elevation_deg": 25.5}], "execution_enabled": False,
                "planning_only": True, "warnings": ["retained diagnostic"],
                "altitude_reference": "unspecified", "refresh_performed": False}
        original = deepcopy(plan)
        view = presentation_document(plan)
        for field in ("source", "opportunities", "execution_enabled", "altitude_reference", "refresh_performed"):
            self.assertEqual(view[field], plan[field])
        self.assertNotIn("warnings", view)
        self.assertNotIn("planning_only", view)
        self.assertEqual(plan, original)

    def test_partial_result_stays_incomplete_and_preserves_saved_and_receipt_facts(self):
        output = {"status": "FAIL", "result": {"operation": "apply", "kind": "location",
                  "result": "saved", "configuration_saved": True, "receipt_recorded": False,
                  "partial": True, "warnings": ["receipt failed"]}}
        view = presentation_document(output)
        self.assertEqual(view["status"], "FAIL")
        self.assertTrue(view["result"]["configuration_saved"])
        self.assertFalse(view["result"]["receipt_recorded"])
        self.assertTrue(view["result"]["partial"])
        self.assertNotIn("warnings", view["result"])
        text = human_text(output)
        self.assertIn("Operation incomplete.", text)
        self.assertIn("Configuration saved: Yes", text)
        self.assertIn("Receipt recorded: No", text)
        outcome = {"ok": False, "status": "FAIL", "action": "apply", "result": output["result"],
                   "error": {"code": "partial_result", "message": "Operation incomplete."}}
        text = human_text(outcome)
        self.assertIn("Error: Operation incomplete.", text)
        self.assertIn("Configuration saved: Yes", text)
        self.assertIn("Receipt recorded: No", text)

    def test_unknown_documents_and_action_errors_are_not_recursively_filtered(self):
        value = {"operator_note": {"warnings": ["operator-owned text"], "limits": [3]},
                 "source": "manual"}
        self.assertEqual(presentation_document(value), value)
        error = {"status": "FAIL", "error": {"code": "active_work", "message": "Operation denied."}}
        self.assertEqual(presentation_document(error), error)
        self.assertEqual(human_text(error), "Error: Operation denied.\nCode: active_work")

    def test_human_status_hides_internal_identity_but_keeps_actual_state(self):
        self.workspace.replay("critical")
        status = self.workspace.inspect()
        original = deepcopy(status)
        view = display_document(status)
        self.assertNotIn("workspace", view)
        self.assertNotIn("workspace_id", view)
        self.assertNotIn("station_revision", view)
        self.assertNotIn("provenance", view["observations"])
        self.assertNotIn("time_basis", view["measured_gps"])
        self.assertIn("time_basis", gps_document(status["measured_gps"]))
        self.assertEqual(view["status"], status["status"])
        self.assertEqual(view["measured_gps"]["fix"], "reported_3d")
        self.assertFalse(view["measured_gps"]["valid_for_station_selection"])
        self.assertEqual(status, original)
        self.assertNotIn(str(self.root), human_text(status))
        self.assertNotIn(status["station_revision"], human_text(status))
        self.assertIn(status["station_revision"], document_text(status))

    def test_nested_runtime_identity_does_not_hide_submission_or_partial_outcomes(self):
        digest = "0123456789abcdef" * 4
        outcome = {"request_id": digest, "configuration_sha256": digest,
                   "inputs": {"source_path": "/private/install", "git_commit": "a" * 40},
                   "exit_code": 8, "software_completed": True, "physical_state": "indeterminate",
                   "partial": True, "result_recorded": False,
                   "manager_outcome": {"state": "rejected", "submitted": 2, "total_submitted": 9}}
        before = deepcopy(outcome)
        view = display_document(outcome)
        self.assertEqual(view["exit_code"], 8)
        self.assertTrue(view["software_completed"])
        self.assertTrue(view["partial"])
        self.assertFalse(view["result_recorded"])
        self.assertEqual(view["manager_outcome"], outcome["manager_outcome"])
        for forbidden in (digest, "/private/install", "a" * 40, "sha256", "git_commit"):
            self.assertNotIn(forbidden, display_document_text(outcome))
        self.assertEqual(outcome, before)

    def test_human_failed_draft_still_shows_proposal_and_disabled_confirmation(self):
        value = {"status": "Not saved", "error": {"code": "invalid", "message": "Choose a provider."},
                 "proposed": {"latitude_deg": 41.25, "source": "manual"}, "confirmation_enabled": False}
        text = human_text(value)
        for expected in ("Error: Choose a provider.", "Code: invalid", "Status: Not saved",
                         "Proposed:", "Latitude deg: 41.25", "Source: manual", "Confirmation enabled: No"):
            self.assertIn(expected, text)
        self.assertEqual(value["proposed"]["latitude_deg"], 41.25)

    def test_custom_station_and_selected_source_values_are_preserved(self):
        for name in ("Cole's station", LEGACY_STATION_NAME + " north", "b" * 64):
            value = {"station_name": name, "source_id": "system:1/component:1", "source": "manual"}
            self.assertEqual(display_document(value), value)
        self.assertEqual(display_message("Check latitude and altitude."), "Check latitude and altitude.")

    def test_path_bearing_error_is_short_without_changing_error_contract(self):
        value = {"ok": False, "status": "FAIL", "error": {"code": "io",
                 "message": "Cannot read /private/install/config.json"}}
        original = deepcopy(value)
        text = human_text(value)
        self.assertNotIn("/private", text)
        self.assertIn("Error:", text)
        self.assertIn("Code: io", text)
        self.assertEqual(value, original)


if __name__ == "__main__":
    unittest.main()
