import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from satgs.operator_activity import ActivityError, StationLease, acquire_runner_activity
from satgs.operator_core import OperatorError, initialize_workspace


class OperatorActivityTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.workspace = initialize_workspace(Path(self.temporary.name) / "practice")

    def test_fresh_descriptors_conflict_and_release_is_idempotent(self):
        first = StationLease(self.workspace.root).acquire()
        try:
            with self.assertRaises(ActivityError) as raised:
                StationLease(self.workspace.root).acquire()
            self.assertEqual(raised.exception.code, "active_work")
        finally:
            first.release()
            first.release()
        with StationLease(self.workspace.root):
            pass

    def test_unmarked_station_requires_no_new_files_or_path_access(self):
        self.assertIsNone(acquire_runner_activity("/not-read/unmarked.yaml", {}))
        self.assertFalse((self.workspace.root / ".activity.lock").exists())

    def test_runtime_admission_checks_exact_bytes_under_lease(self):
        revision, settings = self.workspace.snapshot()
        lease = acquire_runner_activity(self.workspace.station_path, settings, expected_sha256=revision)
        lease.release()
        self.workspace.station_path.write_text(json.dumps(settings, indent=3))
        with self.assertRaisesRegex(ActivityError, "after runtime admission"):
            acquire_runner_activity(self.workspace.station_path, settings, expected_sha256=revision)
        with StationLease(self.workspace.root):
            pass

    def test_actual_runner_owns_lease_before_controlled_initialization_and_releases_last(self):
        import runtime_test_support as support

        _, managed = self.workspace.snapshot()
        inputs = support.Inputs(self.workspace.root)
        inputs.paths["station.yaml"] = self.workspace.station_path
        inputs.station.update(satgs_operator_workspace=managed["satgs_operator_workspace"], operator=managed["operator"])
        inputs.write()
        context = inputs.load()
        preview = self.workspace.preview_location(43, -70, 15, "unspecified")
        trace = []

        def fail_after_admission(runner, admitted, **options):
            self.assertIs(admitted, context)
            self.assertEqual(runner._resources[0][0], "operator-station-lease")
            with self.assertRaises(OperatorError) as raised:
                self.workspace.apply(preview["preview_id"])
            self.assertEqual(raised.exception.code, "active_work")

            def release_controlled_resource():
                with self.assertRaises(ActivityError):
                    StationLease(self.workspace.root).acquire()
                trace.append("resource-released-before-lease")

            runner._own("controlled-resource", release_controlled_resource)
            raise RuntimeError("controlled failure after actual runner lease admission")

        with support.controlled_runner() as module:
            with patch.object(module.PassRunner, "_initialize_pointing", fail_after_admission):
                with self.assertRaisesRegex(RuntimeError, "controlled failure"):
                    module.PassRunner(inputs.paths["station.yaml"], inputs.paths["tle.csv"], 28626,
                                      runtime_context=context)
            self.assertEqual(support.EVENTS, [])
        self.assertEqual(trace, ["resource-released-before-lease"])
        self.assertEqual(self.workspace.apply(preview["preview_id"])["result"], "saved")

    def test_actual_runner_rejects_changed_admitted_bytes_before_any_owner_effect(self):
        import runtime_test_support as support

        _, managed = self.workspace.snapshot()
        inputs = support.Inputs(self.workspace.root)
        inputs.paths["station.yaml"] = self.workspace.station_path
        inputs.station.update(satgs_operator_workspace=managed["satgs_operator_workspace"], operator=managed["operator"])
        inputs.write()
        context = inputs.load()
        inputs.station["ground_station_altm"] = 13
        inputs.write()
        with support.controlled_runner() as module:
            with self.assertRaisesRegex(module.RuntimeConfigurationError, "after runtime admission"):
                module.PassRunner(inputs.paths["station.yaml"], inputs.paths["tle.csv"], 28626,
                                  runtime_context=context)
            self.assertEqual(support.EVENTS, [])
        with StationLease(self.workspace.root):
            pass


if __name__ == "__main__":
    unittest.main()
