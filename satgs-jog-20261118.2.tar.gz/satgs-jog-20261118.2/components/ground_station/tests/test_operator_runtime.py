from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timedelta, timezone
import io
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import runtime_test_support as support
from satgs.operator_core import OperatorError, initialize_workspace
from satgs.operator_planning import plan_workspace
from satgs.operator_runtime import prepare_run


EPOCH = datetime(2025, 5, 16, 3, tzinfo=timezone.utc)


class SelectedOperatorPassTests(unittest.TestCase):
    def setUp(self):
        import ephem
        from satgs.pass_runner import PassRunner
        from satgs.runtime_configuration import _read_tle
        from satgs.utils import find_passes
        source = Path(__file__).parents[1] / "src/satgs/data/operator_tle.csv"
        record = _read_tle(source.read_bytes(), 25338)
        self.runner = object.__new__(PassRunner)
        self.runner.satid = 25338
        self.runner.el_mask = 20
        self.runner.duration = 1
        self.runner.tle_db = {25338: record.to_dict()}
        self.runner.ground_station = ephem.Observer()
        self.runner.ground_station.lat = str(42.0)
        self.runner.ground_station.lon = str(-71.0)
        self.runner.ground_station.elevation = 12.5
        self.runner.ground_station.date = EPOCH
        self.passes = find_passes(25338, self.runner.tle_db, self.runner.ground_station,
                                 20, time_window_hrs=24)
        self.assertGreaterEqual(len(self.passes), 2)

    def selected(self, index=2):
        selected = self.passes[index - 1]
        return dict(index=index, opportunity_index=index, norad_id=25338,
            planning_start_utc=EPOCH.isoformat(), planning_span_days=1,
            rise_utc=selected.sat_rise_time.isoformat(),
            set_utc=selected.sat_set_time.isoformat(),
            rising_azimuth_deg=float(selected.rising_az),
            setting_azimuth_deg=float(selected.setting_az),
            maximum_elevation_deg=float(selected.max_elv), circumpolar=False)

    def test_later_selected_pass_is_recomputed_from_frozen_planning_span_not_nearest(self):
        from satgs.pass_runner import PassRunner
        selected = self.selected()
        before = float(self.runner.ground_station.date)
        with patch.object(PassRunner, "_find_closest_pass", side_effect=AssertionError("nearest fallback")):
            resolved, trajectory = self.runner._resolve_operator_pass(selected)
        self.assertEqual(resolved.sat_rise_time, self.passes[1].sat_rise_time)
        self.assertEqual(resolved.sat_set_time, self.passes[1].sat_set_time)
        self.assertNotEqual(resolved.sat_rise_time, self.passes[0].sat_rise_time)
        self.assertEqual(trajectory.t_ref, resolved.sat_rise_time)
        self.assertEqual(float(self.runner.ground_station.date), before)

    def test_changed_saved_window_angles_identity_and_index_reject(self):
        original = self.selected()
        for name, value in (("rise_utc", self.passes[0].sat_rise_time.isoformat()),
                            ("set_utc", self.passes[0].sat_set_time.isoformat()),
                            ("rising_azimuth_deg", 0), ("setting_azimuth_deg", 0),
                            ("maximum_elevation_deg", 0), ("norad_id", 25544),
                            ("circumpolar", True), ("index", 1), ("opportunity_index", 1)):
            selected = {**original, name: value}
            with self.subTest(name=name), self.assertRaises(ValueError):
                self.runner._resolve_operator_pass(selected)

    def test_invalid_planning_provenance_rejects_before_trajectory(self):
        for name, value in (("planning_start_utc", "2025-05-16T03:00:00"),
                            ("planning_start_utc", "2025-05-16T03:00:00Z"),
                            ("planning_span_days", 8), ("planning_span_days", 0),
                            ("planning_span_days", True), ("planning_span_days", float("nan")),
                            ("opportunity_index", True), ("opportunity_index", 0),
                            ("opportunity_index", 257)):
            with self.subTest(name=name, value=value), self.assertRaises(ValueError):
                self.runner._resolve_operator_pass({**self.selected(), name: value})

    def test_selected_pass_is_still_subject_to_fresh_current_end_admission(self):
        selected = self.selected()
        resolved, trajectory = self.runner._resolve_operator_pass(selected)
        with self.assertRaises(ValueError):
            self.runner._pointing_end_time(resolved, trajectory,
                                          resolved.sat_set_time + timedelta(seconds=1))


class RuntimeFixture:
    def setUp(self):
        from test_messenger_lifecycle import PUBLIC_CA
        self.temporary = tempfile.TemporaryDirectory(prefix="operator-runtime-")
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.workspace = initialize_workspace(self.directory / "station")
        self.location(42, -71, 12.5)
        selected = self.workspace.preview_components("guided_arrow")
        self.workspace.apply(selected["preview_id"])
        owners = self.directory / "owners"
        owners.mkdir(mode=0o700)
        self.inputs = support.Inputs(owners)
        self.inputs.configuration = self.workspace.snapshot()[1]["operator"]["selection"]
        self.inputs.binding.update(configuration_id=self.inputs.configuration["id"],
            configuration_revision=self.inputs.configuration["revision"],
            target=self.inputs.configuration["target"])
        self.inputs.station["amq_ca_pem"] = PUBLIC_CA
        self.inputs.write()

    def location(self, latitude, longitude, altitude):
        preview = self.workspace.preview_location(latitude_deg=latitude, longitude_deg=longitude,
            altitude_m=altitude, altitude_reference="mean_sea_level")
        return self.workspace.apply(preview["preview_id"])

    def plan(self):
        return plan_workspace(self.workspace, start_time=EPOCH.isoformat(), norad_id=28626,
            span_days=1, elevation_deg=15, tle_file=self.inputs.paths["tle.csv"])

    def arguments(self, plan, **options):
        arguments = dict(plan_id=plan["plan_id"], deployment_config=self.inputs.paths["deployment.json"],
            runtime_bindings=self.inputs.paths["bindings.json"],
            station_config=self.inputs.paths["station.yaml"], tle_file=self.inputs.paths["tle.csv"],
            duration=.35, opportunity=1, mode="rehearsal")
        arguments.update(options)
        return arguments

    def cli(self, *arguments):
        from satgs.operator_cli import main
        output, errors = io.StringIO(), io.StringIO()
        with redirect_stdout(output), redirect_stderr(errors):
            code = main(["--workspace", str(self.workspace.root), "--format", "json", *arguments])
        documents = []
        for line in output.getvalue().splitlines():
            try:
                document = json.loads(line)
            except ValueError:
                continue
            if type(document) is dict and "status" in document and ("result" in document or "error" in document):
                documents.append(document)
        self.assertTrue(documents, output.getvalue() + errors.getvalue())
        return code, documents[-1]

    def recorded_result(self, observation):
        record = dict(observation)
        self.assertIs(record.pop("observation_is_recorded"), True)
        self.assertEqual(record.pop("liveness"), "not_established_from_record")
        return record


class OperatorRuntimeRequestTests(RuntimeFixture, unittest.TestCase):
    def test_passive_run_observation_cannot_replace_a_new_foreground_plan(self):
        from satgs.operator_gui import OperatorPresenter

        presenter = OperatorPresenter(self.workspace)
        planned = presenter.dispatch("plan", start_time=EPOCH.isoformat(), norad_id=28626,
            span_days=1, elevation_deg=15, tle_file=str(self.inputs.paths["tle.csv"]))
        self.assertTrue(planned["ok"], planned)
        self.assertIn("opportunities", planned["result"])
        presenter._runtime_request_id = "b" * 64
        for code in (8, 4, 130):
            with self.subTest(exit_code=code):
                presenter._runtime_observation = {"request_id": "b" * 64, "finished": True,
                    "exit_code": code, "physical_state": "indeterminate"}
                observed = presenter.poll_runtime()
                self.assertEqual(observed["result"]["exit_code"], code)
                self.assertEqual(observed["result"]["liveness"], "local_worker_finished")
                self.assertIs(presenter.runtime_result, observed)
                self.assertIs(presenter.result, planned)
        presenter._clear_runtime()
        self.assertIsNone(presenter.poll_runtime())
        self.assertIsNone(presenter.runtime_result)
        self.assertIs(presenter.result, planned)
        preview = self.workspace.preview_run(**self.arguments(self.plan()))
        presenter.run_preview = preview
        presenter.runtime_result = {"action": "run_status", "result": {"request_id": "b" * 64}}
        started = presenter.dispatch("run_start", request_id=preview["request_id"], confirm=True)
        try:
            self.assertEqual(started["result"]["request_id"], preview["request_id"])
            self.assertEqual(presenter.runtime_result["result"]["request_id"], preview["request_id"])
        finally:
            presenter.cancel_active()
            presenter._runtime_thread.join(2)
        self.assertFalse(presenter.runtime_active)

    def test_passive_active_run_poll_preserves_an_explicit_other_request_status(self):
        from satgs.operator_core import _bytes, _write_new
        from satgs.operator_gui import OperatorPresenter

        other = "a" * 64
        saved = {"request_id": other, "finished": True, "exit_code": 4,
                 "physical_state": "indeterminate"}
        _write_new(self.workspace.root / f"run-{other}-result.json", _bytes(saved))
        presenter = OperatorPresenter(self.workspace)
        presenter._runtime_request_id = "b" * 64
        presenter._runtime_observation = {"request_id": "b" * 64, "finished": False,
                                          "state": "tracking", "physical_state": "indeterminate"}
        selected = presenter.dispatch("run_status", request_id=other)
        self.assertFalse(selected["ok"])
        self.assertEqual(selected["result"]["request_id"], other)
        observed = presenter.poll_runtime()
        self.assertEqual(observed["result"]["request_id"], "b" * 64)
        self.assertIs(presenter.result, selected)

    def test_request_freezes_selected_station_configuration_tle_plan_and_mode(self):
        plan = self.plan()
        request = prepare_run(self.workspace, **self.arguments(plan))
        document = request.to_dict()
        self.assertEqual(document["mode"], "rehearsal")
        self.assertEqual(request.station_revision, self.workspace.snapshot()[0])
        self.assertEqual(document["location"]["source"], "manual")
        self.assertEqual(document["tle_sha256"], plan["tle_sha256"])
        self.assertEqual(document["planning_start_utc"], plan["start_utc"])
        self.assertEqual(document["planning_span_days"], plan["span_days"])
        self.assertEqual(document["opportunity"], 1)
        self.assertEqual(document["ptu_manager_id"], 7)
        self.assertEqual(document["pixhawk_manager_id"], 9)
        self.assertEqual(request.context.station["station_location"]["station_id"], document["station_id"])
        saved = request.context.station_settings()
        self.location(34, -118, 31.5)
        self.assertEqual(request.context.station_settings(), saved)
        later = prepare_run(self.workspace, **self.arguments(self.plan()))
        self.assertNotEqual(later.identity, request.identity)
        self.assertNotEqual(later.context.station["station_location"], request.context.station["station_location"])

    def test_old_plan_and_preview_cannot_execute_after_location_change(self):
        plan = self.plan()
        preview = self.workspace.preview_run(**self.arguments(plan))
        self.location(34, -118, 31.5)
        with self.assertRaises(OperatorError):
            prepare_run(self.workspace, **self.arguments(plan))
        with self.assertRaises(OperatorError):
            self.workspace.execute_run(preview["request_id"], confirm=True)
        self.assertFalse((self.workspace.root / f"run-{preview['request_id']}-started.json").exists())

    def test_changed_local_tle_rejects_before_runner_start(self):
        plan = self.plan()
        preview = self.workspace.preview_run(**self.arguments(plan))
        path = self.inputs.paths["tle.csv"]
        path.write_bytes(path.read_bytes() + b"\n")
        with self.assertRaises(OperatorError):
            self.workspace.execute_run(preview["request_id"], confirm=True)
        self.assertFalse((self.workspace.root / f"run-{preview['request_id']}-started.json").exists())

    def test_changed_owner_calibration_requires_a_new_confirmed_request(self):
        plan = self.plan()
        preview = self.workspace.preview_run(**self.arguments(plan))
        self.inputs.station["positioners"][0]["pointing_context"]["pan_to_az"] = 1
        self.inputs.write()
        with self.assertRaises(OperatorError):
            self.workspace.execute_run(preview["request_id"], confirm=True)
        self.assertFalse((self.workspace.root / f"run-{preview['request_id']}-started.json").exists())

    def test_rehearsal_mode_does_not_admit_unreviewed_operational_owners(self):
        from satgs import pass_runner
        self.assertEqual(pass_runner._REVIEWED_OWNER_RELEASES, {})
        preview = self.workspace.preview_run(**self.arguments(self.plan()))
        result = self.workspace.execute_run(preview["request_id"], confirm=True)
        self.assertEqual(result["exit_code"], 3)
        self.assertFalse(result["software_completed"])
        self.assertEqual(result["physical_state"], "unobserved")
        self.assertEqual(pass_runner._REVIEWED_OWNER_RELEASES, {})

    def test_real_cli_rehearsal_runs_actual_scheduled_owners_and_reads_same_saved_result(self):
        from runtime_owner_test_support import OwnerScenario
        from satgs import pass_runner
        plan = self.plan()
        arguments = self.arguments(plan)
        command = ["run-preview", "--plan-id", plan["plan_id"], "--duration", ".35", "--mode", "rehearsal"]
        for name in ("deployment_config", "runtime_bindings", "station_config", "tle_file"):
            command.extend(("--" + name.replace("_", "-"), str(arguments[name])))
        code, output = self.cli(*command)
        self.assertEqual(code, 0, output)
        preview = output["result"]
        request = prepare_run(self.workspace, **arguments)
        self.assertEqual(request.identity, preview["request_id"])
        from satgs.operator_presentation import human_text
        preview_before = dict(preview)
        self.assertIn("station_id", preview)
        self.assertNotIn(preview["station_id"], human_text(preview))
        self.assertEqual(preview, preview_before)
        with OwnerScenario(request.context, epoch=EPOCH) as scene, \
                patch.object(pass_runner.DEFAULTS, "tracking_update_rate", .01):
            code, output = self.cli("run-start", "--run-id", request.identity, "--confirm")
            self.assertEqual(code, 8, output)
            self.assertEqual(output["status"], "INDETERMINATE")
            self.assertTrue(output["result"]["software_completed"])
            self.assertEqual(output["result"]["physical_state"], "indeterminate")
            self.assertGreaterEqual(len(scene.scheduled_commands()), 6)
            self.assertTrue(scene.native.motion())
        code, saved = self.cli("run-status", "--run-id", request.identity)
        self.assertEqual(code, 8, saved)
        canonical = self.workspace._artifact(f"run-{request.identity}-result.json")
        started = self.workspace._artifact(f"run-{request.identity}-started.json")
        self.assertIn("attempt_id", started)
        self.assertNotIn(started["attempt_id"], human_text(started))
        self.assertNotIn(started["station_id"], human_text(started))
        self.assertIn("Physical state: unobserved", human_text(started))
        self.assertEqual(canonical, output["result"])
        self.assertEqual(self.recorded_result(saved["result"]), canonical)
        self.assertEqual(self.recorded_result(self.workspace.run_status(request.identity)), canonical)

    def test_actual_runner_admits_later_selected_leo_pass_without_nearest_substitution(self):
        import hashlib
        from runtime_owner_test_support import OwnerScenario
        from satgs import pass_runner
        from satgs.runtime_configuration import _read_tle
        source = Path(__file__).parents[1] / "src/satgs/data/operator_tle.csv"
        tle = _read_tle(source.read_bytes(), 25338)
        self.inputs.tle = {"norad_id": "25338", **tle.to_dict()}
        self.inputs.station["positioners"][0]["pointing_context"]["tle_sha256"] = hashlib.sha256(
            tle.tle.encode("ascii")).hexdigest()
        self.inputs.write()
        plan = plan_workspace(self.workspace, start_time=EPOCH.isoformat(), norad_id=25338,
            span_days=1, elevation_deg=20, tle_file=self.inputs.paths["tle.csv"])
        self.assertGreaterEqual(len(plan["opportunities"]), 2)
        request = prepare_run(self.workspace, **self.arguments(plan, duration=1, opportunity=2))
        document = request.to_dict()
        selected = {**document["pass_window"], "planning_start_utc": document["planning_start_utc"],
                    "planning_span_days": document["planning_span_days"], "opportunity_index": 2}
        runner = None
        with OwnerScenario(request.context, epoch=EPOCH) as scene:
            try:
                runner = pass_runner.PassRunner(self.workspace.station_path, None, 25338,
                    runtime_context=request.context, selected_pass=selected, nodate=True)
                self.assertEqual(runner.current_pass_info.sat_rise_time.isoformat(),
                                 plan["opportunities"][1]["rise_utc"])
                self.assertNotEqual(runner.current_pass_info.sat_rise_time.isoformat(),
                                    plan["opportunities"][0]["rise_utc"])
                self.assertEqual(scene.native.motion(), [])
            finally:
                if runner is not None:
                    runner.shutdown()

    def test_cancellation_preserves_remote_history_and_never_claims_hardware_stop(self):
        import threading
        from runtime_owner_test_support import OwnerScenario
        from satgs import pass_runner
        arguments = self.arguments(self.plan(), duration=2)
        request = prepare_run(self.workspace, **arguments)
        self.workspace.preview_run(**arguments)
        cancel = threading.Event()
        observations = []

        def progress(record):
            observations.append(record)
            if record.get("state") == "tracking":
                cancel.set()

        with OwnerScenario(request.context, epoch=EPOCH) as scene, \
                patch.object(pass_runner.DEFAULTS, "tracking_update_rate", .01):
            result = self.workspace.execute_run(request.identity, confirm=True, cancel=cancel, progress=progress)
            self.assertEqual(result["exit_code"], 130, result)
            self.assertTrue(result["local_cancellation_requested"])
            self.assertFalse(result["remote_cancellation_established"])
            self.assertFalse(result["physical_stop_established"])
            self.assertEqual(result["physical_state"], "indeterminate")
            self.assertFalse(result["software_completed"])
            self.assertGreaterEqual(len(scene.native.motion()), 2)
            self.assertTrue(any(record.get("state") == "tracking" for record in observations))
        canonical = self.workspace._artifact(f"run-{request.identity}-result.json")
        self.assertEqual(canonical, result)
        self.assertEqual(self.recorded_result(self.workspace.run_status(request.identity)), canonical)

    def test_failed_final_save_keeps_software_and_physical_outcomes_separate(self):
        from runtime_owner_test_support import OwnerScenario
        from satgs import operator_runtime, pass_runner
        arguments = self.arguments(self.plan())
        request = prepare_run(self.workspace, **arguments)
        self.workspace.preview_run(**arguments)
        write_new = operator_runtime._write_new

        def unavailable_result(path, payload):
            if str(path).endswith("-result.json"):
                raise OperatorError("Synthetic result storage unavailable.", "io", 4)
            return write_new(path, payload)

        with OwnerScenario(request.context, epoch=EPOCH), \
                patch.object(pass_runner.DEFAULTS, "tracking_update_rate", .01), \
                patch.object(operator_runtime, "_write_new", side_effect=unavailable_result):
            result = self.workspace.execute_run(request.identity, confirm=True)
        self.assertTrue(result["partial"])
        self.assertFalse(result["result_recorded"])
        self.assertTrue(result["software_completed"])
        self.assertEqual(result["physical_state"], "indeterminate")
        self.assertFalse((self.workspace.root / f"run-{request.identity}-result.json").exists())


@unittest.skipUnless(os.environ.get("DISPLAY"), "NOT RUN: native runtime rehearsal requires the reviewed local DISPLAY")
class NativeRuntimeRehearsalTests(RuntimeFixture, unittest.TestCase):
    def setUp(self):
        super().setUp()
        import tkinter as tk
        from tkinter import filedialog, ttk
        from satgs.operator_gui import OperatorPresenter, OperatorWindow
        self.root = tk.Tk()
        self.callback_errors = []
        self.root.report_callback_exception = lambda *values: self.callback_errors.append(values)
        self.addCleanup(self.close_window)
        self.presenter = OperatorPresenter(self.workspace)
        self.presenter.dispatch("refresh")
        self.window = OperatorWindow(self.root, self.presenter, tk=tk, ttk=ttk, filedialog=filedialog)
        self.root.update()

    def close_window(self):
        owned_timers = set(self.window._timers.values())
        self.window._close()
        deadline = time.monotonic() + 5
        while not self.window._window_closed:
            self.root.update()
            if time.monotonic() >= deadline:
                self.fail("Native window did not complete its real close lifecycle")
            time.sleep(.005)
        if self.presenter._runtime_thread is not None:
            self.presenter._runtime_thread.join(timeout=5)
        self.assertFalse(self.presenter.runtime_active)
        self.assertEqual(self.window._timers, {})
        remaining = set(self.root.tk.splitlist(self.root.tk.call("after", "info")))
        self.assertFalse(owned_timers & remaining)
        self.root.tk.call("update", "idletasks")
        self.root.tk.call("update")
        self.assertEqual(self.callback_errors, [])

    def wait_for(self, predicate, timeout=15):
        deadline = time.monotonic() + timeout
        while not predicate():
            self.root.update()
            if time.monotonic() >= deadline:
                self.fail("Native runtime observation exceeded the finite fixture deadline")
            time.sleep(.005)
        self.root.update()
        self.assertEqual(self.callback_errors, [])

    def test_native_location_exchange_plan_execution_lease_and_cli_result_are_coherent(self):
        from runtime_owner_test_support import OwnerScenario
        from satgs import pass_runner
        for key, value in (("latitude_deg", "42.3"), ("longitude_deg", "-71.1"), ("altitude_m", "12.5")):
            self.window.location_vars[key].set(value)
        self.window.altitude_reference.set("mean_sea_level")
        self.window.widgets["preview_location"].invoke()
        self.window.widgets["apply"].invoke()
        self.root.update()
        code, status = self.cli("status")
        self.assertEqual(code, 0, status)
        self.assertEqual(status["result"]["manual_location"]["latitude_deg"], 42.3)
        old = self.plan()
        code, pending = self.cli("location-preview", "--latitude-deg", "34", "--longitude-deg", "-118",
            "--altitude-m", "31.5", "--altitude-reference", "mean_sea_level")
        self.assertEqual(code, 0, pending)
        self.assertEqual(self.cli("apply", "--preview", pending["result"]["preview_id"], "--confirm")[0], 0)
        self.window.widgets["refresh"].invoke()
        self.root.update()
        self.assertEqual(self.presenter.status["manual_location"]["latitude_deg"], 34)
        with self.assertRaises(OperatorError):
            prepare_run(self.workspace, **self.arguments(old))
        for key, value in (("start_time", EPOCH.isoformat()), ("norad_id", "28626"),
                           ("elevation_deg", "15"), ("tle_file", str(self.inputs.paths["tle.csv"]))):
            self.window.plan_vars[key].set(value)
        self.window.widgets["plan"].invoke()
        self.wait_for(lambda: self.window._task_thread is None)
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        plan = self.presenter.result["result"]
        self.assertNotEqual(plan["opportunities"], old["opportunities"])
        arguments = self.arguments(plan, duration=1.5)
        for key, variable in self.window.runtime_vars.items():
            variable.set(str(arguments[key]))
        self.window.runtime_mode.set("rehearsal")
        self.window.widgets["run_preview"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        request = prepare_run(self.workspace, **arguments)
        lease_probe = self.workspace.preview_location(latitude_deg=35, longitude_deg=-118,
            altitude_m=31.5, altitude_reference="mean_sea_level")
        with OwnerScenario(request.context, epoch=EPOCH) as scene, \
                patch.object(pass_runner.DEFAULTS, "tracking_update_rate", .01):
            self.window.widgets["run_start"].invoke()
            self.wait_for(lambda: len(scene.scheduled_commands()) >= 3)
            code, conflict = self.cli("apply", "--preview", lease_probe["preview_id"], "--confirm")
            self.assertEqual(code, 3, conflict)
            self.assertEqual(conflict["error"]["code"], "active_work")
            self.wait_for(lambda: not self.presenter.runtime_active)
            self.window._poll_run()
            final = self.workspace.run_status(request.identity)
            self.assertEqual(final["exit_code"], 8, final)
            self.assertTrue(final["software_completed"])
            self.assertEqual(final["physical_state"], "indeterminate")
            self.assertAlmostEqual(float(scene.manager.ground_station.lat), 34 * pass_runner.deg2rad)
            self.assertAlmostEqual(float(scene.manager.ground_station.lon), -118 * pass_runner.deg2rad)
            scheduled_commands = len(scene.scheduled_commands())
        code, result = self.cli("run-status", "--run-id", request.identity)
        self.assertEqual(code, 8, result)
        self.assertEqual(result["result"], final)
        canonical = self.workspace._artifact(f"run-{request.identity}-result.json")
        self.assertEqual(self.recorded_result(final), canonical)
        local = dict(self.presenter.result["result"])
        self.assertEqual(local.pop("liveness"), "local_worker_finished")
        self.assertEqual(local, canonical)
        import hashlib
        from satgs.runtime_configuration import _read_tle
        source = Path(__file__).parents[1] / "src/satgs/data/operator_tle.csv"
        tle = _read_tle(source.read_bytes(), 25338)
        self.inputs.tle = {"norad_id": "25338", **tle.to_dict()}
        self.inputs.station["positioners"][0]["pointing_context"]["tle_sha256"] = hashlib.sha256(
            tle.tle.encode("ascii")).hexdigest()
        self.inputs.write()
        self.window.plan_vars["norad_id"].set("25338")
        self.window._schedule(self.window._poll_run)
        self.assertIn(self.window._poll_run, self.window._timers)
        pending_poll = self.window._timers[self.window._poll_run]
        self.window.widgets["plan"].invoke()
        self.wait_for(lambda: self.window._task_thread is None)
        self.wait_for(lambda: self.window._poll_run not in self.window._timers)
        self.assertNotIn(pending_poll, self.window._timers.values())
        self.assertFalse(self.window._window_closed)
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        self.assertEqual(self.presenter.result["action"], "plan")
        leo = self.presenter.result["result"]
        self.assertGreaterEqual(len(leo["opportunities"]), 2)
        visible_plan = self.window.widgets["result_detail"].get("1.0", "end")
        visible_run = self.window.widgets["run_detail"].get("1.0", "end")
        self.assertNotIn(leo["plan_id"], visible_plan)
        self.assertIn("Norad id: 25338", visible_plan)
        self.assertNotIn(request.identity, visible_run)
        self.assertIn("Physical state: indeterminate", visible_run)
        self.assertEqual(self.workspace._artifact(f"plan-{leo['plan_id']}.json"), leo)
        self.assertEqual(self.presenter.runtime_result["result"]["request_id"], request.identity)
        self.assertEqual(self.presenter.runtime_result["result"]["exit_code"], 8)
        self.assertEqual(self.workspace._artifact(f"run-{request.identity}-result.json"), canonical)
        self.window.runtime_vars["plan_id"].set(leo["plan_id"])
        self.window.runtime_vars["opportunity"].set("2")
        self.window.widgets["run_preview"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        second = self.presenter.run_preview
        self.assertEqual(second["opportunity"], 2)
        self.assertEqual(second["pass_window"], leo["opportunities"][1])
        saved_request = self.workspace._artifact(f"run-request-{second['request_id']}.json")
        self.assertEqual(saved_request["opportunity"], 2)
        self.assertEqual(saved_request["pass_window"], leo["opportunities"][1])
        self.window.runtime_vars["duration"].set("2")
        self.root.update()
        self.assertIsNone(self.presenter.run_preview)
        self.assertTrue(self.window.widgets["run_start"].instate(("disabled",)))
        self.window.widgets["run_start"].invoke()
        self.assertFalse((self.workspace.root / f"run-{second['request_id']}-started.json").exists())
        self.window.widgets["run_preview"].invoke()
        self.root.update()
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        self.window.runtime_mode.set("operational")
        self.root.update()
        self.assertIsNone(self.presenter.run_preview)
        self.assertTrue(self.window.widgets["run_start"].instate(("disabled",)))
        for state in ("stale", "incomplete"):
            code, replay = self.cli("replay", "--state", state)
            self.assertEqual(code, 0, replay)
            self.window.widgets["refresh"].invoke()
            self.root.update()
            self.assertFalse(self.presenter.status["gps_selection"]["enabled"])
            self.assertFalse(self.presenter.status["measured_gps"]["valid_for_station_selection"])
        output = self.directory / "export.json"
        self.window.report_output.set(str(output))
        self.window.widgets["export_report"].invoke()
        self.wait_for(lambda: self.window._task_thread is None)
        self.assertTrue(self.presenter.result["ok"], self.presenter.result)
        previous = output.read_bytes()
        self.window.widgets["export_report"].invoke()
        self.wait_for(lambda: self.window._task_thread is None)
        self.assertFalse(self.presenter.result["ok"])
        self.assertEqual(output.read_bytes(), previous)
        print("OPERATOR_RUNTIME_REHEARSAL " + json.dumps({
            "schema": "satgs-operator-rehearsal.v1", "mode": "hardware-free-native-gui-and-cli",
            "location_a": old["location"], "location_b": plan["location"],
            "plan_a": old["plan_id"], "plan_b": plan["plan_id"],
            "later_plan": leo["plan_id"], "scheduled_commands": scheduled_commands,
            "runner_lease_rejection": conflict["error"]["code"],
            "cli_result_equals_saved": self.recorded_result(result["result"]) == canonical,
            "completed_run": canonical, "pending_poll_consumed": pending_poll not in self.window._timers.values(),
            "failed_export_preserved": output.read_bytes() == previous,
        }, sort_keys=True))


if __name__ == "__main__":
    unittest.main()
