import copy
from dataclasses import FrozenInstanceError
import hashlib
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import runtime_test_support as support
from satgs.runtime_configuration import (
    RuntimeConfigurationError, snapshot_runtime_context,
)
from satgs.station_location import (
    LocationError, require_runtime_location, runtime_location_from_settings,
)


class RuntimeLocationBindingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.inputs = support.Inputs(self.root)
        self.context = self.inputs.load()
        self.workspace = {
            "satgs_operator_workspace": {"schema_version": 1, "id": "a" * 32,
                                         "root": str(self.root)},
            "ground_station_location_source": "manual",
            "ground_station_lat": 34.0, "ground_station_lon": -118.0,
            "ground_station_altm": 31.5,
            "operator": {"generation": 2, "altitude_reference": "mean_sea_level"},
        }

    def snapshot(self, settings=None, **options):
        settings = self.workspace if settings is None else settings
        document = (json.dumps(settings, sort_keys=True, indent=2) + "\n").encode("utf-8")
        arguments = dict(station_settings=settings, station_document=document,
                         station_revision=hashlib.sha256(document).hexdigest(), request_id="b" * 64)
        arguments.update(options)
        return snapshot_runtime_context(self.context, **arguments)

    def test_snapshot_uses_exact_document_and_does_not_read_inputs(self):
        with patch("satgs.runtime_configuration.read_regular_bytes", side_effect=AssertionError("reread")), \
                patch.object(Path, "read_bytes", side_effect=AssertionError("reread")):
            snapshot = self.snapshot()
        self.assertEqual(snapshot.station_sha256, hashlib.sha256(snapshot.raw_documents[2]).hexdigest())
        self.assertEqual(json.loads(snapshot.raw_documents[2]), self.workspace)
        self.assertEqual(snapshot.raw_documents[:2], self.context.raw_documents[:2])
        self.assertEqual(snapshot.raw_documents[3:], self.context.raw_documents[3:])
        self.assertEqual(snapshot.tle, self.context.tle)
        self.assertEqual(snapshot.ptu, self.context.ptu)
        self.assertEqual(snapshot.pixhawk, self.context.pixhawk)
        self.assertEqual(snapshot.no_go_data, self.context.no_go_data)
        self.assertEqual(snapshot.configuration, self.context.configuration)
        self.assertEqual(snapshot.station["ground_station_lat"], 34)
        self.assertEqual(snapshot.station["ground_station_lon"], -118)
        self.assertEqual(snapshot.station["ground_station_altm"], 31.5)
        self.assertEqual(snapshot.station["positioners"][0]["pointing_context"]["run_id"], "b" * 64)
        require_runtime_location(snapshot.station, bound=True)

    def test_snapshot_detaches_original_context_and_later_workspace_updates(self):
        before = self.context.station_settings()
        snapshot = self.snapshot()
        self.workspace["ground_station_lat"] = 0
        self.workspace["operator"]["generation"] = 3
        self.workspace["satgs_operator_workspace"]["id"] = "c" * 32
        self.assertEqual(snapshot.station["ground_station_lat"], 34)
        self.assertEqual(snapshot.station["station_location"]["revision"], 2)
        self.assertEqual(snapshot.station["station_location"]["station_id"], "a" * 32)
        self.assertEqual(self.context.station_settings(), before)
        with self.assertRaises(TypeError):
            snapshot.station["station_location"]["latitude_deg"] = 1
        with self.assertRaises(FrozenInstanceError):
            snapshot.duration = 100
        detached = snapshot.station_settings()
        detached["positioners"][0]["pointing_context"]["run_id"] = "d" * 64
        self.assertEqual(snapshot.station["positioners"][0]["pointing_context"]["run_id"], "b" * 64)

    def test_old_manual_record_and_legacy_manual_path_remain_rejected(self):
        old = self.context.station_settings()
        old["ground_station_location_source"] = "manual"
        for bound in (False, True):
            with self.subTest(bound=bound), self.assertRaises(LocationError):
                require_runtime_location(old, bound=bound)
        with self.assertRaisesRegex(LocationError, "owner reinitialization"):
            require_runtime_location(self.snapshot().station)

    def test_configured_source_is_preserved_without_inventing_receiver_measurement(self):
        self.workspace["ground_station_location_source"] = "configured"
        snapshot = self.snapshot()
        self.assertEqual(runtime_location_from_settings(snapshot.station)["source"], "configured")
        self.assertNotIn("measured", snapshot.station["station_location"])
        require_runtime_location(snapshot.station, bound=True)

    def test_stale_mismatched_or_changed_document_rejects(self):
        for options in ({"station_revision": "c" * 64}, {"station_document": b"{}"},
                        {"station_document": "not bytes"}, {"station_document": b"{\"operator\":1}"}):
            with self.subTest(options=tuple(options)), self.assertRaises(RuntimeConfigurationError):
                self.snapshot(**options)
        stale = copy.deepcopy(self.workspace)
        stale["ground_station_lon"] = -71
        document = json.dumps(stale).encode()
        with self.assertRaises(RuntimeConfigurationError):
            self.snapshot(station_document=document, station_revision=hashlib.sha256(document).hexdigest())

    def test_request_and_station_identities_are_exact_and_required(self):
        for field in ("request_id", "station_revision"):
            for value in (None, "", "A" * 64, "a" * 63 + "\n", True):
                with self.subTest(field=field, value=value), self.assertRaises(RuntimeConfigurationError):
                    self.snapshot(**{field: value})

    def test_invalid_station_metadata_or_units_reject_before_owner_effects(self):
        for key, value in (("generation", True), ("generation", 0), ("generation", 2 ** 63),
                           ("altitude_reference", None), ("altitude_reference", ""),
                           ("altitude_reference", "unspecified"), ("altitude_reference", "ellipsoid")):
            settings = copy.deepcopy(self.workspace)
            settings["operator"][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(RuntimeConfigurationError):
                self.snapshot(settings)
        for settings in ({}, dict(self.workspace, ground_station_location_source="gps"),
                         dict(self.workspace, ground_station_lat=91)):
            with self.subTest(settings=tuple(settings)), self.assertRaises(RuntimeConfigurationError):
                self.snapshot(settings)

    def test_bound_coordinates_revision_source_and_reference_must_match(self):
        original = self.snapshot().station_settings()
        for field, value in (("latitude_deg", 42), ("longitude_deg", -71), ("altitude_m", 12),
                             ("source", "configured"), ("coordinate_units", "radians"),
                             ("revision", 3), ("station_id", ""), ("altitude_reference", "")):
            settings = copy.deepcopy(original)
            settings["station_location"][field] = value
            with self.subTest(field=field), self.assertRaises(LocationError):
                require_runtime_location(settings, bound=True)

    def test_optional_duration_is_validated_without_changing_admitted_base(self):
        self.assertEqual(self.snapshot(duration=2.5).duration, 2.5)
        self.assertEqual(self.context.duration, .01)
        for value in (0, -1, True, float("nan"), float("inf")):
            with self.subTest(value=value), self.assertRaises(RuntimeConfigurationError):
                self.snapshot(duration=value)

    def test_canonical_document_default_requires_its_actual_identity(self):
        snapshot = self.snapshot(station_document=None)
        self.assertEqual(json.loads(snapshot.raw_documents[2]), self.workspace)

    def test_real_owner_policy_binds_every_selected_location_dimension(self):
        from ptu_control.pointing import PointingPolicy
        snapshot = self.snapshot()
        policy = PointingPolicy.from_settings(snapshot.station, 7, snapshot.elevation, snapshot.no_go_data)
        for name, value in (("station_id", "c" * 32), ("revision", 3),
                            ("altitude_reference", "other_synthetic_reference")):
            settings = snapshot.station_settings()
            settings["station_location"][name] = value
            if name == "revision":
                settings["positioners"][0]["pointing_context"]["configuration_generation"] = value
            changed = PointingPolicy.from_settings(settings, 7, snapshot.elevation, snapshot.no_go_data)
            self.assertNotEqual(policy.binding, changed.binding)
        changed_workspace = copy.deepcopy(self.workspace)
        changed_workspace.update(ground_station_lat=42, ground_station_lon=-71,
                                 ground_station_altm=12.5)
        changed = self.snapshot(changed_workspace)
        self.assertNotEqual(policy.binding, PointingPolicy.from_settings(
            changed.station, 7, changed.elevation, changed.no_go_data).binding)


class RealOwnerRuntimeBindingTests(unittest.TestCase):
    def setUp(self):
        from test_messenger_lifecycle import PUBLIC_CA
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.inputs = support.Inputs(self.root)
        self.inputs.station["amq_ca_pem"] = PUBLIC_CA
        self.inputs.write()
        self.base = self.inputs.load(duration=.35)
        self.workspace = {
            "satgs_operator_workspace": {"schema_version": 1, "id": "a" * 32,
                                         "root": str(self.root)},
            "ground_station_location_source": "manual", "ground_station_lat": 42.0,
            "ground_station_lon": -71.0, "ground_station_altm": 12.5,
            "operator": {"generation": 2, "altitude_reference": "mean_sea_level"},
        }

    def snapshot(self, settings=None, request_id="b" * 64):
        settings = self.workspace if settings is None else settings
        document = (json.dumps(settings, sort_keys=True, indent=2) + "\n").encode("utf-8")
        return snapshot_runtime_context(self.base, station_settings=settings,
            station_document=document, station_revision=hashlib.sha256(document).hexdigest(),
            request_id=request_id)

    def test_real_manager_astronomy_uses_frozen_selected_location_and_changes_for_later_site(self):
        from datetime import datetime, timezone
        import ephem
        from ptu_control.ptu_client import PtuClient
        from ptu_control.ptu_manager import PtuManager
        from runtime_owner_test_support import OwnerScenario
        epoch = datetime(2025, 5, 16, 3, tzinfo=timezone.utc)
        first = self.snapshot()
        changed = copy.deepcopy(self.workspace)
        changed.update(ground_station_lat=34, ground_station_lon=-118, ground_station_altm=31.5)
        changed["operator"]["generation"] = 3
        second = self.snapshot(changed)
        observed = []
        for context in (first, second):
            with OwnerScenario(context) as scene:
                client = PtuClient.open_pointing(messenger=scene.messenger, settings=context.station,
                    ptu_id=context.ptu.manager_id, elevation_mask=context.elevation,
                    log_dir=Path(context.station["logging_dir"]), no_go_data=context.no_go_data,
                    deadline=scene.deadline, cancel=scene.cancel)
                try:
                    client.enable_scheduled_tracking(deadline=scene.deadline, cancel=scene.cancel)
                    self.assertTrue(client.check_connection(deadline=scene.deadline, cancel=scene.cancel))
                    self.assertTrue(client.load_tle(context.tle.tle, deadline=scene.deadline, cancel=scene.cancel))
                finally:
                    client.close(deadline=scene.deadline)
                observer = scene.manager.ground_station
                self.assertIs(type(observer), scene.observer_type)
                expected_location = tuple(context.station[key] for key in
                    ("ground_station_lat", "ground_station_lon", "ground_station_altm"))
                self.assertEqual(scene.manager._location, expected_location)
                self.assertEqual(scene.manager.policy.station_location[3:6], expected_location)
                self.assertAlmostEqual(float(observer.lat), context.station["ground_station_lat"] * ephem.degree)
                self.assertAlmostEqual(float(observer.lon), context.station["ground_station_lon"] * ephem.degree)
                expected_altitude = context.station["ground_station_altm"]
                self.assertLessEqual(abs(observer.elevation - expected_altitude), math.ulp(expected_altitude))
                observed.append(PtuManager.get_sat_pos(scene.manager, epoch))
                self.assertEqual(scene.native.motion(), [])
        self.assertNotAlmostEqual(observed[0][0], observed[1][0], places=3)
        self.assertNotAlmostEqual(observed[0][1], observed[1][1], places=3)
        self.assertEqual(first.station["ground_station_lat"], 42)

    def test_real_runner_schedules_correlated_owners_and_reports_only_software_completion(self):
        from datetime import datetime, timezone
        import ephem
        from ptu_control import ptu_msg_pb2
        from runtime_owner_test_support import OwnerScenario
        from satgs import pass_runner
        context = self.snapshot()
        station = self.root / "station.json"
        station.write_bytes(context.raw_documents[2])
        station.chmod(0o600)
        self.root.chmod(0o700)
        runner = None
        epoch = datetime(2025, 5, 16, 3, tzinfo=timezone.utc)
        with OwnerScenario(context, epoch=epoch) as scene, patch.object(pass_runner.DEFAULTS, "tracking_update_rate", .01):
            try:
                runner = pass_runner.PassRunner(station, None, context.tle.norad_id,
                    runtime_context=context, nodate=True, file_prefix="real-owner")
                self.assertIs(type(runner.ground_station), scene.observer_type)
                self.assertTrue(scene.observer_clock_observations)
                for observation in scene.observer_clock_observations:
                    self.assertIs(observation["genuine_observer"], True)
                    self.assertEqual(observation["observer_date_days"], observation["clock_date_days"])
                    self.assertEqual(observation["fixture_epoch_utc"], epoch.isoformat())
                    self.assertEqual(observation["tle_epoch_utc"],
                                     pass_runner.tle_from_dict(context.tle.to_dict()).tle_epoch.isoformat())
                self.assertIs(runner.runtime_context, context)
                code = runner.main()
                commands = scene.scheduled_commands()
                self.assertEqual(code, 8)
                self.assertEqual(runner.physical_state, "indeterminate")
                self.assertEqual(runner.manager_outcome.state, "complete")
                self.assertEqual(runner.manager_outcome.category, "ok")
                self.assertGreaterEqual(sum(item.operation == ptu_msg_pb2.ScheduledCommand.TRACK
                                            for item in commands), 2)
                self.assertEqual([item.sequence for item in commands], list(range(1, len(commands) + 1)))
                self.assertTrue(all(item.request_binding == scene.manager.policy.binding for item in commands))
                self.assertEqual(commands[-1].operation, ptu_msg_pb2.ScheduledCommand.COMPLETE)
                self.assertEqual(runner.manager_outcome.total_submitted, len(scene.native.motion()))
                self.assertEqual(runner.cleanup_errors, [])
                self.assertFalse(runner._truth_thread.is_alive())
            finally:
                if runner is not None:
                    runner.shutdown()
        self.assertEqual(pass_runner._REVIEWED_OWNER_RELEASES, {})

    def test_mismatched_manager_location_rejects_before_activation_or_motion(self):
        from meteor_api.messenger import Messenger
        from ptu_control.pointing import PointingError
        from ptu_control.ptu_manager import PtuManager
        from runtime_owner_test_support import BrokerHarness
        from serialptu.proto_impl import PTCR20
        from serialptu.ptu import PTU
        from test_ptu_manager_pointing import FollowingSerial
        import threading
        import time
        context = self.snapshot()
        changed = context.station_settings()
        changed["ground_station_lon"] = -118
        with BrokerHarness(context.ptu.manager_id, context.pixhawk.manager_id) as transport:
            messenger = transport.open(changed)
            self.assertIs(type(messenger), Messenger)
            protocol = PTCR20()
            native = FollowingSerial(protocol)
            with patch("serialptu.ptu.serial.Serial", return_value=native):
                driver = PTU(protocol, "recording-only", pointing=True)
            with self.assertRaises(PointingError):
                PtuManager.open_pointing(messenger=messenger, settings=changed,
                    ptu_id=context.ptu.manager_id, driver=driver,
                    elevation_mask=context.elevation, no_go_data=context.no_go_data,
                    run_deadline=time.monotonic() + 2, cancel=threading.Event())
            self.assertFalse(native.opened)
            self.assertEqual(native.writes, [])


if __name__ == "__main__":
    unittest.main()
