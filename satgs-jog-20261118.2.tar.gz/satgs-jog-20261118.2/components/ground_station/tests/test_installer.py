import errno
import hashlib
import os
from pathlib import Path
import pty
import re
import select
import shlex
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
import unittest


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
BUILD_SCRIPT = REPOSITORY_ROOT / "build.sh"


class InstallerTests(unittest.TestCase):
    read_only_commands = ("cat", "dirname")
    dangerous_commands = (
        "apt",
        "apt-get",
        "calibrate_ptu",
        "chmod",
        "chown",
        "configure_amq.sh",
        "cp",
        "curl",
        "dd",
        "echo_pixhawk",
        "echo_ptu",
        "install",
        "git",
        "journalctl",
        "ln",
        "mkdir",
        "modprobe",
        "mount",
        "mv",
        "nc",
        "park_ptu",
        "ping",
        "pip",
        "pip3",
        "pixhawk_manager.py",
        "ptu_manager.py",
        "reset_ptu",
        "rm",
        "run_pass",
        "service",
        "socat",
        "ssh",
        "stty",
        "sudo",
        "systemctl",
        "tee",
        "telnet",
        "touch",
        "udevadm",
        "wget",
    )

    def setUp(self):
        self._assert_installer_source_safe()
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary_directory.cleanup)
        self.temporary_path = Path(self.temporary_directory.name)
        self.home_directory = self.temporary_path / "home"
        self.home_directory.mkdir()
        self.process_temp_directory = self.temporary_path / "tmp"
        self.process_temp_directory.mkdir()
        self.shim_directory = self.temporary_path / "bin"
        self.shim_directory.mkdir()
        self.command_log = self.temporary_path / "commands.log"
        self.command_log.write_text("", encoding="utf-8")
        self.audit_directory = self.temporary_path / "audit"
        self.audit_directory.mkdir()
        self.audit_sequence = 0
        self._write_audit_guard()
        for command in self.read_only_commands:
            self._write_passthrough_shim(command)
        for command in self.dangerous_commands:
            self._write_blocking_shim(command)
        self._write_python_shims()

    def _write_audit_guard(self):
        path = self.audit_directory / "sitecustomize.py"
        path.write_text(
            "import os\n"
            "import sys\n"
            "\n"
            "with open(os.environ['SATGS_AUDIT_MARKER'], 'a', encoding='utf-8') as marker:\n"
            "    marker.write('loaded\\n')\n"
            "\n"
            "blocked_events = {\n"
            "    'ctypes.dlopen', 'os.chmod', 'os.chown', 'os.link', 'os.mkdir',\n"
            "    'os.posix_spawn', 'os.putenv', 'os.remove', 'os.removexattr',\n"
            "    'os.rename', 'os.rmdir', 'os.setxattr', 'os.symlink',\n"
            "    'os.truncate', 'os.unsetenv', 'os.utime', 'subprocess.Popen',\n"
            "}\n"
            "blocked_prefixes = ('os.exec', 'os.spawn', 'shutil.', 'socket.')\n"
            "\n"
            "write_flags = (\n"
            "    os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND\n"
            ")\n"
            "\n"
            "def reject_side_effect(event, arguments):\n"
            "    if event in blocked_events or event.startswith(blocked_prefixes):\n"
            "        raise RuntimeError(f'operation blocked: {event}')\n"
            "    if event == 'os.system':\n"
            "        raise RuntimeError(f'operation blocked: {event}')\n"
            "    if event != 'open':\n"
            "        return\n"
            "    target, mode, flags = arguments\n"
            "    if isinstance(target, (str, bytes, os.PathLike)):\n"
            "        decoded = os.fsdecode(target)\n"
            "        if decoded == '/dev' or decoded.startswith('/dev/'):\n"
            "            raise RuntimeError(f'device open blocked: {decoded}')\n"
            "    if (isinstance(mode, str) and any(flag in mode for flag in 'wax+')) or (\n"
            "        isinstance(flags, int) and flags & write_flags\n"
            "    ):\n"
            "        raise RuntimeError(f'file write blocked: {target!r}')\n"
            "\n"
            "sys.addaudithook(reject_side_effect)\n",
            encoding="utf-8",
        )

    def _write_blocking_shim(self, command):
        path = self.shim_directory / command
        path.write_text(
            "#!/bin/sh\n"
            f"printf '%s\\n' {shlex.quote(command)} >> \"$SATGS_COMMAND_LOG\"\n"
            "exit 97\n",
            encoding="utf-8",
        )
        path.chmod(0o755)

    def _write_passthrough_shim(self, command):
        executable = shutil.which(command, path=os.defpath)
        self.assertIsNotNone(executable)
        (self.shim_directory / command).symlink_to(executable)

    def _write_python_shims(self):
        for executable in ("python", "python3"):
            path = self.shim_directory / executable
            pip_marker = f"{executable}-pip"
            path.write_text(
                "#!/bin/sh\n"
                'if [ "${1-}" = "-m" ] && [ "${2-}" = "pip" ]; then\n'
                f"    printf '%s\\n' {shlex.quote(pip_marker)} "
                '>> "$SATGS_COMMAND_LOG"\n'
                "    exit 97\n"
                "fi\n"
                f"exec {shlex.quote(sys.executable)} \"$@\"\n",
                encoding="utf-8",
            )
            path.chmod(0o755)

    def _next_audit_marker(self):
        self.audit_sequence += 1
        return self.temporary_path / f"audit-loaded-{self.audit_sequence}"

    def _environment(self, audit_marker):
        return {
            "HOME": str(self.home_directory),
            "LANG": "C",
            "LC_ALL": "C",
            "PATH": str(self.shim_directory),
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONNOUSERSITE": "1",
            "PYTHONPATH": (
                f"{self.audit_directory}{os.pathsep}"
                f"{REPOSITORY_ROOT / 'src'}"
            ),
            "PYTHONUTF8": "1",
            "SATGS_AUDIT_MARKER": str(audit_marker),
            "SATGS_COMMAND_LOG": str(self.command_log),
            "TMPDIR": str(self.process_temp_directory),
        }

    def _snapshot_repository(self):
        snapshot = {}
        for current_directory, directories, files in os.walk(REPOSITORY_ROOT):
            directories[:] = [
                directory
                for directory in directories
                if directory not in {".git", "__pycache__"}
            ]
            current = Path(current_directory)
            for directory in directories:
                path = current / directory
                relative = path.relative_to(REPOSITORY_ROOT).as_posix()
                snapshot[f"dir:{relative}"] = stat.S_IMODE(path.stat().st_mode)
            for filename in files:
                if filename.endswith(".pyc"):
                    continue
                path = current / filename
                relative = path.relative_to(REPOSITORY_ROOT).as_posix()
                if path.is_symlink():
                    value = ("symlink", os.readlink(path))
                else:
                    value = (
                        "file",
                        stat.S_IMODE(path.stat().st_mode),
                        hashlib.sha256(path.read_bytes()).hexdigest(),
                    )
                snapshot[f"path:{relative}"] = value
        return snapshot
    @staticmethod
    def _snapshot_path(path):
        if not os.path.lexists(path):
            return ("missing",)
        metadata = os.lstat(path)
        mode = stat.S_IMODE(metadata.st_mode)
        if stat.S_ISLNK(metadata.st_mode):
            return ("symlink", mode, os.readlink(path))
        if stat.S_ISREG(metadata.st_mode):
            return (
                "file",
                mode,
                hashlib.sha256(path.read_bytes()).hexdigest(),
            )
        if stat.S_ISDIR(metadata.st_mode):
            return ("directory", mode)
        return ("other", mode, metadata.st_size)

    def _snapshot_tree(self, root):
        root_state = self._snapshot_path(root)
        if root_state[0] != "directory":
            return ((".", root_state),)
        snapshot = {".": root_state}
        for current_directory, directories, files in os.walk(root):
            current = Path(current_directory)
            entries = sorted((*directories, *files))
            for entry in entries:
                path = current / entry
                relative = path.relative_to(root).as_posix()
                snapshot[relative] = self._snapshot_path(path)
            directories[:] = [
                directory
                for directory in sorted(directories)
                if not (current / directory).is_symlink()
            ]
        return tuple(sorted(snapshot.items()))

    def _git_output(self, *arguments):
        git_executable = shutil.which("git", path=os.defpath)
        self.assertIsNotNone(git_executable)
        result = subprocess.run(
            [git_executable, "-C", str(REPOSITORY_ROOT), *arguments],
            cwd=REPOSITORY_ROOT,
            env={
                "GIT_CONFIG_NOSYSTEM": "1",
                "GIT_OPTIONAL_LOCKS": "0",
                "GIT_TERMINAL_PROMPT": "0",
                "HOME": str(self.home_directory),
                "LANG": "C",
                "LC_ALL": "C",
                "PATH": os.defpath,
            },
            stdin=subprocess.DEVNULL,
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def _snapshot_safety_state(self):
        git_directory = REPOSITORY_ROOT / ".git"
        sentinel_paths = (
            REPOSITORY_ROOT / ".env",
            REPOSITORY_ROOT / ".venv",
            REPOSITORY_ROOT / "config/config.yaml",
            REPOSITORY_ROOT / "config/sat_db.csv",
            REPOSITORY_ROOT / "notebooks/error_profile.ipynb",
            REPOSITORY_ROOT / "notebooks/pass_plotter.ipynb",
            REPOSITORY_ROOT / "notebooks/quick_look.ipynb",
        )
        return {
            "repository": self._snapshot_repository(),
            "sentinels": tuple(
                (str(path.relative_to(REPOSITORY_ROOT)), self._snapshot_path(path))
                for path in sentinel_paths
            ),
            "git_config": self._snapshot_path(git_directory / "config"),
            "git_head": self._snapshot_path(git_directory / "HEAD"),
            "git_index": self._snapshot_path(git_directory / "index"),
            "git_modules": self._snapshot_tree(git_directory / "modules"),
            "head": self._git_output("rev-parse", "HEAD"),
            "status": self._git_output(
                "status", "--short", "--branch", "--untracked-files=all"
            ),
            "submodules": self._git_output("submodule", "status", "--recursive"),
        }
    @staticmethod
    def _audit_loads(audit_marker):
        if not audit_marker.exists():
            return ()
        return tuple(audit_marker.read_text(encoding="utf-8").splitlines())

    def _assert_no_effects(
        self, before, after, audit_marker, expected_audit_loads
    ):
        self.assertEqual(after, before)
        self.assertEqual(self.command_log.read_text(encoding="utf-8"), "")
        self.assertEqual(
            self._audit_loads(audit_marker),
            ("loaded",) * expected_audit_loads,
        )

    def _run(self, *arguments, cwd=None):
        audit_marker = self._next_audit_marker()
        result = subprocess.run(
            [str(BUILD_SCRIPT), *arguments],
            cwd=cwd or REPOSITORY_ROOT,
            env=self._environment(audit_marker),
            stdin=subprocess.DEVNULL,
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result, audit_marker

    def _run_without_effects(
        self, *arguments, cwd=None, expected_audit_loads
    ):
        before = self._snapshot_safety_state()
        result, audit_marker = self._run(*arguments, cwd=cwd)
        after = self._snapshot_safety_state()

        self._assert_no_effects(
            before, after, audit_marker, expected_audit_loads
        )
        return result

    def _run_bash_without_effects(
        self, command, *arguments, input_text=None
    ):
        before = self._snapshot_safety_state()
        audit_marker = self._next_audit_marker()
        result = subprocess.run(
            ["/bin/bash", "-c", command, "installer-test", *map(str, arguments)],
            cwd=self.temporary_path,
            env=self._environment(audit_marker),
            input=input_text,
            stdin=subprocess.DEVNULL if input_text is None else None,
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        after = self._snapshot_safety_state()

        self._assert_no_effects(before, after, audit_marker, 0)
        return result

    def _run_tty_without_effects(
        self, arguments, input_text, expected_audit_loads
    ):
        before = self._snapshot_safety_state()
        audit_marker = self._next_audit_marker()
        command = [str(BUILD_SCRIPT), *arguments]
        master_fd, slave_fd = pty.openpty()
        output = bytearray()
        process = None
        timed_out = False
        deadline = time.monotonic() + 10
        try:
            process = subprocess.Popen(
                command,
                cwd=REPOSITORY_ROOT,
                env=self._environment(audit_marker),
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                close_fds=True,
                start_new_session=True,
            )
            os.close(slave_fd)
            slave_fd = None
            pending_input = input_text.encode("utf-8")
            while pending_input:
                written = os.write(master_fd, pending_input)
                pending_input = pending_input[written:]

            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    timed_out = True
                    break
                readable, _, _ = select.select(
                    [master_fd], [], [], min(0.1, remaining)
                )
                if readable:
                    try:
                        chunk = os.read(master_fd, 4096)
                    except OSError as error:
                        if error.errno == errno.EIO:
                            break
                        raise
                    if not chunk:
                        break
                    output.extend(chunk)
                elif process.poll() is not None:
                    break

            if not timed_out:
                try:
                    process.wait(timeout=max(0.1, deadline - time.monotonic()))
                except subprocess.TimeoutExpired:
                    timed_out = True
        finally:
            if slave_fd is not None:
                os.close(slave_fd)
            if process is not None and process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=1)
            os.close(master_fd)

        after = self._snapshot_safety_state()
        if timed_out:
            self.assertEqual(after, before)
            self.assertEqual(self.command_log.read_text(encoding="utf-8"), "")
            self.fail("PTY dry run exceeded its 10-second timeout")
        self._assert_no_effects(
            before, after, audit_marker, expected_audit_loads
        )
        normalized_output = output.decode("utf-8").replace("\r\n", "\n")
        return subprocess.CompletedProcess(
            command,
            process.returncode,
            stdout=normalized_output,
            stderr="",
        )

    @staticmethod
    def _section_ids(output, heading, next_heading=None):
        section = output.split(heading, 1)[1]
        if next_heading is not None:
            section = section.split(next_heading, 1)[0]
        result = []
        for line in section.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            _, entry = stripped.split(". ", 1)
            result.append(entry.split(" | ", 1)[0])
        return tuple(result)

    def test_help_succeeds_without_side_effects(self):
        result = self._run_without_effects(
            "--help", expected_audit_loads=0
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Usage: ./build.sh", result.stdout)
        self.assertIn("full_msel", result.stdout)
        self.assertIn("guided_arrow", result.stdout)
        self.assertIn("0  Help or a successful supported operation", result.stdout)
        self.assertIn("2  Argument, selection, profile", result.stdout)
        self.assertIn("3  The selected profile does not support apply", result.stdout)
        self.assertIn("status is returned unchanged", result.stdout)

    def test_subprocess_environment_is_minimal_and_isolated(self):
        audit_marker = self._next_audit_marker()
        environment = self._environment(audit_marker)

        self.assertEqual(
            set(environment),
            {
                "HOME",
                "LANG",
                "LC_ALL",
                "PATH",
                "PYTHONDONTWRITEBYTECODE",
                "PYTHONNOUSERSITE",
                "PYTHONPATH",
                "PYTHONUTF8",
                "SATGS_AUDIT_MARKER",
                "SATGS_COMMAND_LOG",
                "TMPDIR",
            },
        )
        self.assertEqual(environment["HOME"], str(self.home_directory))
        self.assertEqual(environment["TMPDIR"], str(self.process_temp_directory))
        self.assertEqual(
            environment["PATH"],
            str(self.shim_directory),
        )
        self.assertEqual(
            environment["PYTHONPATH"],
            f"{self.audit_directory}{os.pathsep}{REPOSITORY_ROOT / 'src'}",
        )

    def _assert_installer_source_safe(self):
        source = BUILD_SCRIPT.read_text(encoding="utf-8")
        executable_lines = []
        in_heredoc = False
        for line_number, raw_line in enumerate(source.splitlines(), start=1):
            stripped = raw_line.strip()
            if in_heredoc:
                if stripped == "EOF":
                    in_heredoc = False
                continue
            executable_lines.append((line_number, raw_line))
            if stripped == "cat <<'EOF'":
                in_heredoc = True

        executable_source = "\n".join(
            raw_line for _, raw_line in executable_lines
        )
        source_without_shebang = "\n".join(
            raw_line
            for line_number, raw_line in executable_lines
            if line_number != 1
        )
        self.assertNotRegex(
            executable_source, r"/dev/(?:tcp|udp|tty|serial)(?:/|\b)"
        )
        self.assertNotRegex(
            source_without_shebang,
            r"(?m)(?<![A-Za-z0-9_.$-])/(?!/)",
        )
        self.assertNotRegex(executable_source, r"(?m)\beval(?:\s|$)")
        self.assertNotIn("`", executable_source)
        for entrypoint in (
            "configure_amq.sh",
            "run_pass",
            "ptu_manager.py",
            "pixhawk_manager.py",
            "echo_ptu",
            "calibrate_ptu",
            "reset_ptu",
            "park_ptu",
            "echo_pixhawk",
        ):
            self.assertNotIn(entrypoint, executable_source)

        exact_arithmetic_lines = {
            "while (($# > 0)); do",
            'if (($# < 2)) || [[ "$2" == --* ]]; then',
        }
        for line_number, raw_line in executable_lines:
            if "<" not in raw_line and ">" not in raw_line:
                continue
            stripped = raw_line.strip()
            safe_literal_arrow = re.fullmatch(
                r'echo "[^"$`\\]* -> [^"$`\\]*"', stripped
            )
            safe_stderr = (
                stripped == "usage >&2"
                or stripped == ">&2"
                or (
                    stripped.startswith("printf ")
                    and stripped.endswith(" >&2")
                    and stripped.count(">") == 1
                    and "<" not in stripped
                )
            )
            approved = (
                stripped == "cat <<'EOF'"
                or stripped in exact_arithmetic_lines
                or safe_literal_arrow is not None
                or safe_stderr
            )
            self.assertTrue(
                approved,
                f"unapproved shell redirection syntax on line {line_number}: "
                f"{stripped!r}",
            )

    def test_installer_source_has_only_approved_shell_effect_syntax(self):
        self._assert_installer_source_safe()

    def test_full_msel_apply_body_preserves_legacy_sequence(self):
        source = BUILD_SCRIPT.read_text(encoding="utf-8")
        body = (
            source.split("run_full_msel_install() {", 1)[1]
            .split("\n}\n\nmain() {", 1)[0]
        )
        guard = " || return $?"
        operations = []
        active_predicate = None
        saw_else = False
        saw_copy = False
        predicate_count = 0
        for raw_line in body.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith("echo "):
                self.assertRegex(line, r'^echo "[^"$`\\]*"$')
                continue
            if line == 'cd "$SCRIPT_DIR" || return 1':
                operations.append(("cwd", "$SCRIPT_DIR"))
                continue
            predicate = re.fullmatch(r'if \[ -e "([^"]+)" \]; then', line)
            if predicate is not None:
                self.assertIsNone(active_predicate)
                active_predicate = predicate.group(1)
                saw_else = False
                saw_copy = False
                predicate_count += 1
                continue
            if line == "else":
                self.assertIsNotNone(active_predicate)
                self.assertFalse(saw_else)
                saw_else = True
                continue
            if line == "fi":
                self.assertIsNotNone(active_predicate)
                self.assertTrue(saw_else)
                self.assertTrue(saw_copy)
                active_predicate = None
                continue
            self.assertNotIn(";", line)
            self.assertNotIn("`", line)
            self.assertNotIn("$(", line)
            self.assertNotIn("/dev/", line)
            if line.startswith("cp "):
                self.assertIsNotNone(active_predicate)
                self.assertTrue(saw_else)
                self.assertFalse(saw_copy)
                self.assertTrue(line.endswith(guard))
                command = line[: -len(guard)]
                for operator in ("|", ">", "<"):
                    self.assertNotIn(operator, command)
                operations.append(
                    ("copy_if_missing", active_predicate, command)
                )
                saw_copy = True
                continue
            if line.startswith("python3 -m pip install"):
                self.assertIsNone(active_predicate)
                self.assertTrue(line.endswith(guard))
                command = line[: -len(guard)]
                for operator in ("|", ">", "<"):
                    self.assertNotIn(operator, command)
                operations.append(("install", command))
                continue
            self.fail(f"unexpected Full M-SEL apply line: {line!r}")

        self.assertIsNone(active_predicate)
        self.assertEqual(predicate_count, 5)
        self.assertEqual(
            tuple(operations),
            (
                ("cwd", "$SCRIPT_DIR"),
                (
                    "copy_if_missing",
                    "./config/config.yaml",
                    "cp ./config/config_template.yaml ./config/config.yaml",
                ),
                (
                    "copy_if_missing",
                    "./config/sat_db.csv",
                    "cp ./config/sat_db_template.csv config/sat_db.csv",
                ),
                (
                    "copy_if_missing",
                    "./notebooks/error_profile.ipynb",
                    "cp ./notebooks/error_profile_template.ipynb ./notebooks/error_profile.ipynb",
                ),
                (
                    "copy_if_missing",
                    "./notebooks/pass_plotter.ipynb",
                    "cp ./notebooks/pass_plotter_template.ipynb ./notebooks/pass_plotter.ipynb",
                ),
                (
                    "copy_if_missing",
                    "./notebooks/quick_look.ipynb",
                    "cp ./notebooks/quick_look_template.ipynb ./notebooks/quick_look.ipynb",
                ),
                ("install", "python3 -m pip install -e 'lib/meteor-api[zmq]'"),
                ("install", "python3 -m pip install -e '.[full]'"),
                (
                    "install",
                    "python3 -m pip install -e lib/msel_post_processing",
                ),
                ("install", "python3 -m pip install -e lib/cyberpowerpdu"),
                ("install", "python3 -m pip install -e lib/dsi_instruments"),
                ("install", "python3 -m pip install -e 'lib/pixhawk[manager]'"),
                ("install", "python3 -m pip install -e 'lib/sat_tracker[manager]'"),
                (
                    "install",
                    "python3 -m pip install -e lib/sat_tracker/lib/serialptu",
                ),
                ("install", "python3 -m pip install -e lib/signal_hound"),
                ("install", "python3 -m pip install lib/signal_hound/lib"),
            ),
        )

        main_body = source.split("\nmain() {", 1)[1].split(
            '\n}\n\nif [[ "${BASH_SOURCE[0]}" == "$0" ]]', 1
        )[0]
        self.assertEqual(main_body.count("run_full_msel_install"), 1)
        self.assertLess(
            main_body.index('if [[ "$dry_run" == true ]]'),
            main_body.index("ensure_profile_apply_supported"),
        )
        self.assertLess(
            main_body.index("ensure_profile_apply_supported"),
            main_body.index("run_full_msel_install"),
        )
        self.assertIn(
            'if ((apply_status != 0)); then\n'
            '        return "$apply_status"\n'
            "    fi\n\n"
            "    run_full_msel_install",
            main_body,
        )

    def test_explicit_full_msel_dry_run_succeeds(self):
        result = self._run_without_effects(
            "--profile",
            "full_msel",
            "--dry-run",
            expected_audit_loads=2,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Resolved profile: full_msel", result.stdout)
        self.assertNotIn("Select a deployment profile", result.stderr)
        self.assertEqual(
            self._section_ids(
                result.stdout,
                "Package plan:\n",
                "Planned services (not installed or started):\n",
            ),
            (
                "meteor-api",
                "ground_station",
                "msel_post_processing",
                "cyberpowerpdu",
                "dsi_instruments",
                "pixhawk",
                "sat_tracker",
                "serialptu",
                "signal_hound",
                "signal_hound_native_wrapper",
            ),
        )

    def test_explicit_guided_arrow_dry_run_succeeds(self):
        result = self._run_without_effects(
            "--profile",
            "guided_arrow",
            "--dry-run",
            expected_audit_loads=2,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Resolved profile: guided_arrow", result.stdout)
        self.assertNotIn("Select a deployment profile", result.stderr)
        self.assertEqual(
            self._section_ids(
                result.stdout,
                "Package plan:\n",
                "Planned services (not installed or started):\n",
            ),
            (
                "meteor-api",
                "ground_station",
                "sat_tracker",
                "serialptu",
                "pixhawk",
            ),
        )
        self.assertEqual(
            self._section_ids(
                result.stdout,
                "Planned services (not installed or started):\n",
                "Capabilities (static installation intent only):\n",
            ),
            (
                "broker.activemq",
                "pointing.ptu",
                "pointing.pixhawk",
                "orchestration.queue_manager",
            ),
        )
        self.assertEqual(
            self._section_ids(
                result.stdout,
                "Capabilities (static installation intent only):\n",
            ),
            (
                "broker.activemq",
                "orchestration.queue_manager",
                "execution.pass_runner",
                "orbit.pass_finder",
                "pointing.ptu",
                "pointing.qpt130",
                "pointing.pixhawk",
                "pointing.dual_gps",
                "time.ntp",
                "network.connectivity",
                "rf.frontend",
                "power.pdu_hpa",
                "recording.signal_hound",
                "processing.msel_post_processing",
            ),
        )
        self.assertIn(
            "rf.frontend | provider=sponsor | applicability=external | "
            "supported=false | required_by_default=false | instances=none",
            result.stdout,
        )

    def test_noninteractive_full_msel_dry_run_succeeds(self):
        result = self._run_without_effects(
            "--non-interactive",
            "--profile",
            "full_msel",
            "--dry-run",
            expected_audit_loads=2,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Resolved profile: full_msel", result.stdout)

    def test_noninteractive_guided_arrow_dry_run_succeeds(self):
        result = self._run_without_effects(
            "--non-interactive",
            "--profile",
            "guided_arrow",
            "--dry-run",
            expected_audit_loads=2,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Resolved profile: guided_arrow", result.stdout)

    def test_tty_blank_dry_run_prompts_and_selects_full_msel(self):
        result = self._run_tty_without_effects(("--dry-run",), "\n", 2)

        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn("Select a deployment profile:", result.stdout)
        self.assertIn("Resolved profile: full_msel", result.stdout)

    def test_tty_choice_one_dry_run_prompts_and_selects_full_msel(self):
        result = self._run_tty_without_effects(("--dry-run",), "1\n", 2)

        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn("Select a deployment profile:", result.stdout)
        self.assertIn("Resolved profile: full_msel", result.stdout)

    def test_tty_choice_two_dry_run_prompts_and_selects_guided_arrow(self):
        result = self._run_tty_without_effects(("--dry-run",), "2\n", 2)

        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn("Select a deployment profile:", result.stdout)
        self.assertIn("Resolved profile: guided_arrow", result.stdout)

    def test_tty_invalid_choices_fail_after_three_attempts(self):
        result = self._run_tty_without_effects(
            ("--dry-run",), "invalid\nstill-invalid\nnope\n", 0
        )

        self.assertEqual(result.returncode, 2, result.stdout)
        self.assertEqual(result.stdout.count("Invalid selection"), 3)
        self.assertIn("too many invalid profile selections", result.stdout)

    def test_tty_noninteractive_profile_omissions_never_prompt(self):
        argument_sets = (
            ("--non-interactive",),
            ("--non-interactive", "--dry-run"),
        )
        for arguments in argument_sets:
            with self.subTest(arguments=arguments):
                result = self._run_tty_without_effects(arguments, "", 0)

                self.assertEqual(result.returncode, 2, result.stdout)
                self.assertIn(
                    "--non-interactive requires an explicit --profile",
                    result.stdout,
                )
                self.assertNotIn("Select a deployment profile", result.stdout)

    def test_non_tty_profileless_dry_run_uses_full_msel_fallback(self):
        result = self._run_without_effects(
            "--dry-run", expected_audit_loads=2
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Resolved profile: full_msel", result.stdout)
        self.assertIn(
            "no profile supplied in a non-TTY environment", result.stderr
        )

    def test_noninteractive_without_profile_or_dry_run_fails_before_effects(self):
        result = self._run_without_effects(
            "--non-interactive", expected_audit_loads=0
        )

        self.assertEqual(result.returncode, 2)
        self.assertIn(
            "--non-interactive requires an explicit --profile",
            result.stderr,
        )
        self.assertIn("Usage: ./build.sh", result.stderr)

    def test_noninteractive_without_profile_with_dry_run_fails_before_effects(self):
        result = self._run_without_effects(
            "--non-interactive",
            "--dry-run",
            expected_audit_loads=0,
        )

        self.assertEqual(result.returncode, 2)
        self.assertIn(
            "--non-interactive requires an explicit --profile",
            result.stderr,
        )
        self.assertIn("Usage: ./build.sh", result.stderr)

    def test_invalid_profile_fails_before_effects(self):
        result = self._run_without_effects(
            "--profile",
            "invalid",
            "--dry-run",
            expected_audit_loads=1,
        )

        self.assertEqual(result.returncode, 2)
        self.assertIn("unknown deployment profile", result.stderr)
        self.assertIn("Usage: ./build.sh", result.stderr)

    def test_unknown_argument_fails_before_effects(self):
        result = self._run_without_effects(
            "--unknown", expected_audit_loads=0
        )

        self.assertEqual(result.returncode, 2)
        self.assertIn("unknown argument: --unknown", result.stderr)
        self.assertIn("Usage: ./build.sh", result.stderr)

    def test_unknown_argument_escapes_terminal_control_characters(self):
        result = self._run_without_effects(
            "--forged\nline\x1b[31m", expected_audit_loads=0
        )

        self.assertEqual(result.returncode, 2)
        self.assertIn("unknown argument:", result.stderr)
        self.assertNotIn("forged\nline", result.stderr)
        self.assertNotIn("\x1b", result.stderr)

    def test_guided_arrow_apply_fails_before_effects(self):
        result = self._run_without_effects(
            "--profile", "guided_arrow", expected_audit_loads=2
        )

        self.assertEqual(result.returncode, 3)
        self.assertIn("apply is not enabled in Slice 1", result.stderr)
        self.assertIn(
            "--profile guided_arrow --dry-run",
            result.stderr,
        )
        self.assertIn("later approved slice", result.stderr)

    def test_dry_run_output_is_deterministic(self):
        first = self._run_without_effects(
            "--profile",
            "guided_arrow",
            "--dry-run",
            expected_audit_loads=2,
        )
        second = self._run_without_effects(
            "--profile",
            "guided_arrow",
            "--dry-run",
            expected_audit_loads=2,
        )

        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(first.stdout, second.stdout)
        self.assertEqual(first.stderr, second.stderr)

    def test_dry_run_works_from_a_different_current_directory(self):
        unrelated_directory = self.temporary_path / "unrelated"
        unrelated_directory.mkdir()

        result = self._run_without_effects(
            "--profile",
            "guided_arrow",
            "--dry-run",
            cwd=unrelated_directory,
            expected_audit_loads=2,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Resolved profile: guided_arrow", result.stdout)

    def test_dry_run_does_not_dispatch_mutating_or_operational_commands(self):
        for profile in ("full_msel", "guided_arrow"):
            with self.subTest(profile=profile):
                result = self._run_without_effects(
                    "--non-interactive",
                    "--profile",
                    profile,
                    "--dry-run",
                    expected_audit_loads=2,
                )
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertNotIn("connected=", result.stdout)
                self.assertNotIn("healthy=", result.stdout)
                self.assertNotIn("observed_at=", result.stdout)

    def test_prompt_choice_mapping_is_pure_and_injectable(self):
        choices = (
            ("", "full_msel"),
            ("1", "full_msel"),
            ("2", "guided_arrow"),
        )
        for choice, expected in choices:
            with self.subTest(choice=choice):
                result = self._run_bash_without_effects(
                    'source "$1"; normalize_profile_choice "$2"',
                    BUILD_SCRIPT,
                    choice,
                )

                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stdout.strip(), expected)

    def test_prompt_retries_are_bounded(self):
        result = self._run_bash_without_effects(
            'source "$1"; prompt_for_profile',
            BUILD_SCRIPT,
            input_text="invalid\nstill-invalid\nnope\n",
        )

        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stderr.count("Invalid selection"), 3)
        self.assertIn("too many invalid profile selections", result.stderr)

    def test_prompt_eof_fails_closed(self):
        result = self._run_bash_without_effects(
            'source "$1"; prompt_for_profile', BUILD_SCRIPT
        )

        self.assertEqual(result.returncode, 2)
        self.assertIn(
            "profile selection ended before a choice was read",
            result.stderr,
        )
        self.assertNotIn("Invalid selection", result.stderr)


if __name__ == "__main__":
    unittest.main()
