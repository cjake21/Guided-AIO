"""GUI/presenter bench commands use real owners at controlled transport boundaries."""
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import sys
import threading
import time
import traceback
import unittest
from unittest.mock import patch

from satgs.operator_core import initialize_workspace
from satgs.operator_gui import OperatorPresenter, OperatorWindow, display_unavailable


def local_jog_packets(native):
    from serialptu.errors import CorruptedMessageError
    packets = []
    for packet in tuple(native.writes):
        try:
            velocities = native.proto.decode_jog_packet(packet)
        except CorruptedMessageError:
            continue
        packets.append((packet, velocities))
    return packets


class HeadlessBenchInterfaceTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.workspace = initialize_workspace(self.directory / "station")
        self.presenter = OperatorPresenter(self.workspace)
        self.manager = None
        self.addCleanup(self.release)

    def release(self):
        self.presenter.close_bench()
        if self.presenter._bench_close_thread is not None:
            self.presenter._bench_close_thread.join(2)
            self.assertFalse(self.presenter._bench_close_thread.is_alive())
        if self.manager is not None:
            self.manager.close(deadline=time.monotonic() + 1)

    def settle(self, name="_bench_thread"):
        worker = getattr(self.presenter, name)
        self.assertIsNotNone(worker)
        worker.join(2)
        self.assertFalse(worker.is_alive())
        return self.presenter.bench_snapshot()["results"][-1]

    def controlled_owners(self, zone=None, selected=None):
        if selected is not None:
            from test_operator_bench_cli import local_bench_fixture, selected_bench_fixture
            if getattr(self, "local_serial", False):
                fixture = local_bench_fixture(self.stack, self.directory, query=selected == "query")
            else:
                fixture = selected_bench_fixture(self.stack, self.directory,
                    query=selected == "query", plaintext=getattr(self, "plaintext", False))
            self.__dict__.update(vars(fixture))
            return
        from meteor_api.messenger import Messenger
        from ptu_control import bench
        from ptu_control.ptu_manager import PtuManager
        from satgs import operator_bench
        from satgs.runtime_configuration import _freeze
        from serialptu.proto_impl import PTCR20
        from serialptu.ptu import PTU
        from test_ptu_bench import bench_settings
        from test_ptu_manager_pointing import FollowingSerial, MessageBus

        self.bus = MessageBus()
        self.bus.install(self.stack)
        self.stack.enter_context(patch.object(Messenger, "prepare_transport", return_value=object()))
        self.stack.enter_context(patch.object(Messenger, "open_bounded", return_value=self.bus.messenger))
        self.stack.enter_context(patch.object(Messenger, "close", return_value=None))
        self.stack.enter_context(patch.object(operator_bench, "_admit", side_effect=lambda document: _freeze(document["station"])))
        self.configuration = bench_settings()
        self.configuration["bench_context"]["exchange_timeout_seconds"] = .5
        self.configuration_file = self.directory / "bench.json"
        self.configuration_file.write_text(json.dumps({"station": self.configuration,
            "ptu_id": 2, "elevation_mask": 0, "no_go_data": zone}))
        self.protocol = PTCR20()
        self.native = FollowingSerial(self.protocol)
        with patch("serialptu.ptu.serial.Serial", return_value=self.native):
            driver = PTU(self.protocol, "recording-only", pointing=True)
        with patch.object(bench, "_controlled_rehearsal_boundary", return_value=True):
            self.manager = PtuManager.open_bench(messenger=self.bus.messenger, settings=self.configuration,
                ptu_id=2, driver=driver, elevation_mask=0, no_go_data=zone,
                run_deadline=time.monotonic() + 30, cancel=threading.Event())
        self.manager.activate(deadline=time.monotonic() + 1, cancel=self.manager._cancel)

    def connect(self):
        self.assertTrue(self.presenter.dispatch("bench_connect", configuration_file=self.configuration_file)["ok"])
        self.assertEqual(self.settle()["category"], "ok")

    def test_initial_view_and_failed_connect_have_no_external_effect(self):
        self.assertFalse(self.presenter.bench_open)
        result = self.presenter.dispatch("bench_status")
        self.assertEqual(result["error"]["code"], "not_connected")
        self.assertTrue(self.presenter.dispatch("bench_connect")["ok"])
        self.assertEqual(self.settle()["category"], "bench_input")
        self.assertFalse(self.presenter.bench_open)
        configuration = self.directory / "missing.json"
        requested = self.presenter.dispatch("bench_connect", configuration_file=configuration)
        self.assertEqual(requested["status"], "RUNNING")
        self.assertEqual(self.settle()["category"], "bench_input")
        self.assertFalse(self.presenter.bench_open)

    def test_local_selected_session_uses_existing_presenter_and_passive_cleanup(self):
        self.local_serial = True
        self.controlled_owners(selected="manual")
        self.connect()
        self.assertIsNone(self.presenter.bench_saved)
        self.assertIsNone(self.presenter._bench_session.transport)
        self.assertEqual(self.presenter.bench_snapshot()["readback"]["transport"], "local-serial")
        self.presenter.dispatch("bench_manual", step_degrees="1")
        self.assertEqual(self.settle()["category"], "ok")
        self.presenter.dispatch("bench_step", direction="right")
        self.assertEqual(self.settle()["category"], "ok")
        before = len(self.native.writes)
        self.presenter.dispatch("bench_preview", pan="2", tilt="-10")
        rejected = self.settle()
        self.assertEqual(rejected["category"], "busy")
        self.assertEqual(rejected["submission"], "none")
        self.assertEqual(rejected["exchanges"], [])
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(self.presenter.bench_snapshot()["preview_ready"])
        self.presenter.dispatch("bench_status")
        observed = self.settle()
        self.assertEqual(observed["category"], "ok")
        self.assertEqual((observed["pan"], observed["tilt"]), (1, -10))
        self.assertEqual(observed["physical_state"], "indeterminate")
        self.presenter.dispatch("bench_preview", pan="2", tilt="-10")
        self.assertEqual(self.settle()["category"], "ok")
        self.presenter.dispatch("bench_move")
        self.assertEqual(self.settle()["category"], "ok")
        self.presenter.dispatch("bench_stop")
        self.assertEqual(self.settle("_bench_stop_thread")["category"], "ok")
        before = len(self.native.writes)
        self.presenter.dispatch("bench_disconnect")
        self.assertEqual(self.settle()["category"], "ok")
        self.assertFalse(self.presenter.bench_open)
        self.assertFalse(self.native.opened)
        self.assertEqual(len(self.native.writes), before)

    def test_local_setup_is_explicit_saved_and_does_not_connect(self):
        from satgs.operator_bench import saved_bench_configuration
        self.local_serial = True
        self.controlled_owners(selected="manual")
        before = self.workspace.station_path.read_bytes()
        self.assertTrue(self.presenter.dispatch("refresh")["ok"])
        self.assertIsNone(self.presenter.bench_saved)
        self.assertEqual(self.workspace.station_path.read_bytes(), before)
        outcome = self.presenter.dispatch("bench_setup_local")
        self.assertTrue(outcome["ok"], outcome)
        saved = saved_bench_configuration(self.workspace)
        self.assertEqual(saved["station"]["bench_transport"], "local-serial")
        self.assertIsNone(saved["station"]["manual_context"]["no_go_rectangle"])
        self.assertEqual(self.presenter.bench_saved, saved)
        self.assertFalse(self.presenter.bench_open)
        self.assertEqual(self.native.writes, [])
        reloaded = OperatorPresenter(self.workspace)
        self.assertTrue(reloaded.dispatch("refresh")["ok"])
        self.assertEqual(reloaded.bench_saved, saved)
        self.assertFalse(reloaded.bench_open)
        self.assertEqual(self.native.writes, [])
        self.assertTrue(self.presenter.dispatch("bench_connect")["ok"])
        self.assertEqual(self.settle()["category"], "ok")
        self.assertEqual(local_jog_packets(self.native), [])
        self.assertEqual(self.native.motion(), [])

    def test_local_presenter_hold_is_token_scoped_and_close_retains_stop_result(self):
        self.local_serial = True
        self.controlled_owners(selected="manual")
        self.connect()
        self.assertFalse(self.presenter.bench_snapshot()["readback"]["manual_enabled"])
        self.assertTrue(self.presenter.bench_snapshot()["readback"]["jog_allowed"])
        outcome = self.presenter.dispatch("bench_jog_start", direction="right")
        self.assertTrue(outcome["ok"], outcome)
        self.assertEqual(outcome["status"], "RUNNING")
        token = outcome["result"]["jog_token"]
        deadline = time.monotonic() + 1
        while self.presenter.bench_snapshot()["readback"]["jog"]["state"] != "active" and time.monotonic() < deadline:
            self.assertTrue(self.presenter.dispatch("bench_jog_renew", jog_token=token)["result"]["accepted"])
            threading.Event().wait(.005)
        self.assertTrue(local_jog_packets(self.native))
        self.assertEqual(self.presenter.bench_snapshot()["readback"]["jog"]["state"], "active")
        self.assertTrue(self.presenter.bench_active)
        self.assertFalse(self.presenter.dispatch("bench_jog_end", jog_token=token + 1)["result"]["accepted"])
        self.assertEqual(self.presenter.bench_snapshot()["readback"]["jog"]["token"], token)
        self.assertFalse(self.presenter.dispatch("bench_preview", pan=1, tilt=-10)["ok"])
        self.presenter.close_bench()
        self.presenter._bench_close_thread.join(2)
        self.assertFalse(self.presenter._bench_close_thread.is_alive())
        self.assertFalse(self.presenter.bench_open)
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        self.assertFalse(self.native.opened)
        records = self.presenter.bench_snapshot()["results"]
        self.assertEqual([(item["operation"], item["physical_state"]) for item in records],
                         [("connect", "unobserved"), ("stop", "indeterminate"), ("jog", "indeterminate")])

    def test_live_admission_rejects_before_transport_or_owner_creation(self):
        from satgs import operator_bench
        from test_ptu_bench import bench_settings
        configuration = self.directory / "not-admitted.json"
        configuration.write_text(json.dumps({"station": bench_settings("operational"),
            "ptu_id": 2, "elevation_mask": 0, "no_go_data": None}))
        with patch.object(operator_bench, "StationLease", side_effect=AssertionError("lease before admission")):
            self.presenter.dispatch("bench_connect", configuration_file=configuration)
            result = self.settle()
        self.assertEqual(result["category"], "bench_not_admitted")
        self.assertFalse(self.presenter.bench_open)

    def test_actual_shared_preview_move_status_and_passive_disconnect(self):
        self.controlled_owners()
        self.connect()
        self.assertEqual(self.native.motion(), [])
        self.presenter.dispatch("bench_preview", pan="10", tilt="0")
        preview = self.settle()
        self.assertTrue(self.presenter.bench_snapshot()["preview_ready"])
        self.assertEqual(preview["encoded_pan_units"], 100)
        self.assertEqual(self.native.motion(), [])
        self.presenter.dispatch("bench_move")
        result = self.settle()
        self.assertEqual(result["category"], "ok")
        self.assertEqual(result["physical_state"], "indeterminate")
        self.assertEqual(len(self.native.motion()), 1)
        self.presenter.dispatch("bench_status")
        self.assertEqual(self.settle()["position_reference"], "protocol-reported-unqualified")
        before = len(self.native.writes)
        self.presenter.dispatch("bench_disconnect")
        self.assertEqual(self.settle()["category"], "ok")
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(self.presenter.bench_open)
        self.assertTrue(self.native.opened)
        saved = list(self.workspace.root.glob("bench-*-result.json"))
        self.assertEqual(len(saved), 5)

    def test_edit_invalidates_preview_and_move_requires_a_new_deliberate_preview(self):
        self.controlled_owners()
        self.connect()
        self.presenter.dispatch("bench_preview", pan="10", tilt="0")
        self.settle()
        self.presenter.invalidate_bench_preview()
        result = self.presenter.dispatch("bench_move")
        self.assertEqual(result["error"]["code"], "preview_required")
        self.assertEqual(self.native.motion(), [])

    def test_pending_preview_cannot_become_ready_after_target_edit(self):
        self.controlled_owners()
        self.connect()
        self.manager._operation.acquire()
        try:
            self.presenter.dispatch("bench_preview", pan="10", tilt="0")
            self.presenter.invalidate_bench_preview()
        finally:
            self.manager._operation.release()
        self.assertEqual(self.settle()["category"], "ok")
        self.assertFalse(self.presenter.bench_snapshot()["preview_ready"])

    def test_stop_uses_a_separate_slot_while_normal_operation_is_pending(self):
        self.controlled_owners()
        self.connect()
        self.manager._operation.acquire()
        try:
            self.presenter.dispatch("bench_status")
            result = self.presenter.dispatch("bench_stop")
            self.assertEqual(result["status"], "RUNNING")
            self.assertTrue(self.manager._bench_stop_pending.wait(.3))
            self.assertIsNot(self.presenter._bench_thread, self.presenter._bench_stop_thread)
        finally:
            self.manager._operation.release()
        self.settle("_bench_stop_thread")
        self.settle()
        records = self.presenter.bench_snapshot()["results"]
        self.assertTrue(any(row["operation"] == "stop" and row["category"] == "ok" for row in records))
        self.assertEqual(self.native.motion(), [])

    def test_gui_close_releases_client_without_automatic_stop_or_motion(self):
        self.controlled_owners()
        self.connect()
        before = len(self.native.writes)
        self.presenter.close_bench()
        self.presenter._bench_close_thread.join(2)
        self.assertFalse(self.presenter._bench_close_thread.is_alive())
        self.assertFalse(self.presenter.bench_open)
        self.assertIsNone(self.presenter.bench_snapshot()["cleanup_error"])
        self.assertEqual(len(self.native.writes), before)
        self.assertTrue(self.native.opened)

    def test_disconnect_retains_partial_result_and_stops_polling_until_explicit_cleanup(self):
        from satgs.operator_core import OperatorError
        self.controlled_owners(selected="manual")
        self.connect()
        session = self.presenter._bench_session

        def failed_close():
            session._closed = True
            raise OperatorError("controlled passive failure", "cleanup", 7)

        with patch.object(session, "close", side_effect=failed_close) as closing:
            self.presenter.dispatch("bench_disconnect")
            result = self.settle()
            self.assertEqual(closing.call_count, 1)
            self.assertTrue(result["partial"])
            self.assertFalse(result["cleanup_complete"])
            self.assertIn("attempt_id", result)
            self.assertIsNotNone(self.presenter.bench_snapshot()["cleanup_error"])
            before = len(self.native.writes)
            self.assertIsNone(self.presenter.poll_bench())
            self.assertEqual(len(self.native.writes), before)
        self.presenter.dispatch("bench_disconnect")
        recovered = self.settle()
        self.assertEqual(recovered["category"], "ok")
        self.assertTrue(recovered["passive_cleanup_retry"])
        self.assertEqual(len(self.native.writes), before)
        recorded = json.loads((self.workspace.root / f"bench-{recovered['attempt_id']}-result.json").read_bytes())
        self.assertTrue(recorded["passive_cleanup_retry"])
        self.assertTrue(recorded["cleanup_complete"])
        self.assertFalse(self.presenter.bench_open)
        self.assertIsNone(self.presenter.bench_snapshot()["cleanup_error"])

    def test_shared_manual_steps_use_measured_start_and_same_owner_encoder(self):
        self.controlled_owners()
        self.native.tilt_units = -100
        self.connect()
        session = self.presenter._bench_session
        self.assertEqual(session.perform("step", direction="right")["category"], "manual_required")
        self.assertEqual(session.perform("manual", step_degrees=1)["category"], "ok")
        for direction, expected in (("left", (-1, -10)), ("right", (0, -10)),
                                    ("up", (0, -9)), ("down", (0, -10))):
            with self.subTest(direction=direction):
                result = session.perform("step", direction=direction)
                self.assertEqual(result["category"], "ok")
                self.assertEqual([part["phase"] for part in result["steps"]], ["status", "preview", "move"])
                self.assertEqual((result["requested_pan"], result["requested_tilt"]), expected)
                self.assertEqual(result["physical_state"], "indeterminate")
                self.assertEqual(result["steps"][0]["observation_sequence"] + 1,
                                 result["steps"][1]["observation_sequence"])
        self.assertEqual(len(self.native.motion()), 4)
        self.assertEqual(self.native.opens, 1)

    def test_shared_manual_validates_increment_readback_and_disarm(self):
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        for step in (None, True, float("nan"), float("inf"), 0, -.1, .01, 101):
            with self.subTest(step=step):
                self.assertEqual(session.perform("manual", step_degrees=step)["category"], "invalid_step")
        self.assertEqual(session.perform("manual", step_degrees=.1)["category"], "ok")
        session.disarm_manual()
        self.assertEqual(session.perform("step", direction="right")["category"], "manual_required")
        self.assertEqual(session.perform("manual", step_degrees=1)["category"], "ok")
        session._observation_started -= 2
        self.assertEqual(session.readback_snapshot()["freshness"], "stale")
        before = len(self.native.writes)
        self.assertEqual(session.perform("step", direction="right")["category"], "readback_required")
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(session.readback_snapshot()["manual_enabled"])
        session._observation = None
        self.assertEqual(session.perform("manual", step_degrees=1)["category"], "readback_required")
        self.assertEqual(self.native.motion(), [])

    def test_shared_readback_poll_is_ephemeral_and_previous_session_is_not_current(self):
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        before = sorted(self.workspace.root.glob("bench-*.json"))
        result = session.perform("status", persist=False)
        self.assertTrue(result["automatic_readback"])
        self.assertEqual(sorted(self.workspace.root.glob("bench-*.json")), before)
        self.assertEqual(session.readback_snapshot()["freshness"], "fresh")
        session.perform("disconnect")
        self.assertEqual(session.readback_snapshot()["freshness"], "disconnected")

    def test_disarm_during_preview_cancels_step_before_move_and_retains_children(self):
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        session.perform("manual", step_degrees=1)
        preview = session.client.preview

        def disarm_after_preview(*args, **kwargs):
            result = preview(*args, **kwargs)
            session.disarm_manual()
            return result

        with patch.object(session.client, "preview", side_effect=disarm_after_preview):
            result = session.perform("step", direction="right")
        self.assertEqual(result["category"], "cancelled")
        self.assertEqual([part["phase"] for part in result["steps"]], ["status", "preview"])
        self.assertFalse(session.readback_snapshot()["manual_enabled"])
        self.assertEqual(self.native.motion(), [])

    def test_changed_step_start_rejects_and_failed_stop_remains_blocked(self):
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        session.perform("manual", step_degrees=1)
        preview = session.client.preview

        def changed_start(*args, **kwargs):
            self.native.pan_units = 1
            return preview(*args, **kwargs)

        with patch.object(session.client, "preview", side_effect=changed_start):
            result = session.perform("step", direction="right")
        self.assertEqual(result["category"], "context_changed")
        self.assertEqual(self.native.motion(), [])
        self.native.auto_ack = False
        failed = session.perform("stop")
        self.assertNotEqual(failed["category"], "ok")
        self.assertTrue(session.readback_snapshot()["motion_blocked"])
        self.native.auto_ack = True
        session.perform("status")
        self.assertEqual(session.perform("manual", step_degrees=1)["category"], "motion_blocked")
        self.assertFalse(session.readback_snapshot()["manual_enabled"])

    def test_relative_step_obeys_actual_encoder_no_go_rounding(self):
        from test_ptu_manager_pointing import rectangle
        self.controlled_owners(zone=rectangle())
        self.native.pan_units, self.native.tilt_units = -800, -700
        self.connect()
        session = self.presenter._bench_session
        self.assertEqual(session.perform("manual", step_degrees=9.96)["category"], "ok")
        result = session.perform("step", direction="right")
        self.assertEqual(result["category"], "endpoint_rejected")
        self.assertEqual([part["phase"] for part in result["steps"]], ["status", "preview"])
        saved = json.loads((self.workspace.root / f"bench-{result['attempt_id']}-result.json").read_text())
        self.assertEqual(saved["steps"][-1]["category"], "endpoint_rejected")
        self.assertEqual(self.native.motion(), [])

    def test_presenter_polls_nonoverlapping_and_never_after_owned_close(self):
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        session._next_poll = 0
        self.manager._operation.acquire()
        try:
            self.assertEqual(self.presenter.poll_bench()["status"], "RUNNING")
            self.assertIsNone(self.presenter.poll_bench())
            self.assertEqual(self.presenter.dispatch("bench_step", direction="right")["error"]["code"], "active_work")
        finally:
            self.manager._operation.release()
        self.settle()
        self.assertEqual(len(self.presenter.bench_snapshot()["results"]), 1)
        self.presenter.close_bench()
        self.presenter._bench_close_thread.join(2)
        self.assertIsNone(self.presenter.poll_bench())

    def test_unusable_or_replayed_readback_cannot_derive_relative_target(self):
        from ptu_control.bench import BenchResult
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        status = session.client.status
        for changes in ({"has_observation": False}, {"binding": "00" * 32}, {"units_per_degree": 100},
                        {"mode": "operational"}, {"pan": float("nan")}, {"observation_sequence": 1}):
            with self.subTest(changes=changes):
                session.perform("status")
                session.perform("manual", step_degrees=1)
                def altered_status(**kwargs):
                    values = status(**kwargs).as_record()
                    values.update(changes)
                    return BenchResult(tuple(values.items()))
                with patch.object(session.client, "status", side_effect=altered_status):
                    result = session.perform("step", direction="right")
                self.assertEqual(result["category"], "readback_required")
                self.assertEqual([part["phase"] for part in result["steps"]], ["status"])
                saved = json.loads((self.workspace.root / f"bench-{result['attempt_id']}-result.json").read_text())
                self.assertEqual(saved["category"], "readback_required")
                self.assertEqual(saved["steps"][0]["phase"], "status")
                self.assertFalse(session.readback_snapshot()["manual_enabled"])
        self.assertEqual(self.native.motion(), [])

    def test_invalid_readback_retains_configured_poll_cadence(self):
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        record = session.perform("status", persist=False)
        record["units_per_degree"] = 0
        session._next_poll = 0
        with patch("satgs.operator_bench.time.monotonic", return_value=100):
            session._remember_readback(record, 100)
            self.assertEqual(session.readback_snapshot()["error"], "invalid_readback")
            self.assertFalse(session.readback_snapshot()["poll_due"])
        with patch("satgs.operator_bench.time.monotonic", return_value=100.499):
            self.assertFalse(session.readback_snapshot()["poll_due"])
        with patch("satgs.operator_bench.time.monotonic", return_value=100.5):
            self.assertTrue(session.readback_snapshot()["poll_due"])
        self.assertEqual(self.native.motion(), [])

    def test_disarm_after_published_move_retains_unknown_outcome_and_blocks_motion(self):
        from ptu_control.ptu_client import PtuError
        self.controlled_owners()
        self.connect()
        session = self.presenter._bench_session
        session.perform("manual", step_degrees=1)
        move = session.client.move
        def lose_result(*args, **kwargs):
            move(*args, **kwargs)
            session.disarm_manual()
            raise PtuError("cancelled")
        with patch.object(session.client, "move", side_effect=lose_result):
            result = session.perform("step", direction="right")
        self.assertEqual(result["category"], "cancelled")
        self.assertEqual(result["submission"], "unknown")
        self.assertEqual(result["steps"][-1]["phase"], "move")
        saved = json.loads((self.workspace.root / f"bench-{result['attempt_id']}-result.json").read_text())
        self.assertEqual(saved["steps"][-1]["submission"], "unknown")
        self.assertEqual(len(self.native.motion()), 1)
        session.perform("status")
        self.assertTrue(session.readback_snapshot()["motion_blocked"])
        self.assertEqual(session.perform("manual", step_degrees=1)["category"], "motion_blocked")


class NativeBenchInterfaceTests(unittest.TestCase):
    def setUp(self):
        import tkinter as tk
        from tkinter import filedialog, ttk
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.window = None
        try:
            self.root = tk.Tk()
        except tk.TclError as error:
            if display_unavailable(error):
                self.skipTest("NOT RUN: reviewed native display unavailable")
            raise
        self.callback_errors = []
        self.root.report_callback_exception = self._report_callback_exception
        self.addCleanup(self.close_native)
        self.workspace = initialize_workspace(Path(self.temporary.name) / "station")
        self.presenter = OperatorPresenter(self.workspace)
        self.window = OperatorWindow(self.root, self.presenter, tk=tk, ttk=ttk, filedialog=filedialog)
        self.root.update()
        self._assert_no_callback_errors()

    def _report_callback_exception(self, exception, value, trace):
        self.callback_errors.append("".join(traceback.format_exception(exception, value, trace)))

    def _assert_no_callback_errors(self):
        self.assertEqual(self.callback_errors, [], "Native Tk callback exceptions:\n" + "\n".join(self.callback_errors))

    def close_native(self):
        if self.window is None:
            self.root.destroy()
            self._assert_no_callback_errors()
            return
        if not self.window._window_closed:
            self.window._close()
        deadline = time.monotonic() + 3
        while not self.window._window_closed and time.monotonic() < deadline:
            self.root.update()
            if not self.window._window_closed:
                threading.Event().wait(.005)
        self.assertFalse(self.presenter.runtime_active)
        self.assertFalse(self.presenter.bench_active)
        self.assertFalse(self.presenter.bench_open)
        self.assertIsNone(self.presenter.bench_snapshot()["cleanup_error"])
        self.assertTrue(self.window._window_closed)
        self.assertEqual(self.window._timers, {})
        self._assert_no_callback_errors()

    def test_real_ptu_controls_start_disabled_and_enter_has_no_motion_binding(self):
        widgets = self.window.widgets
        self.assertIn("PTU", self.window.pages)
        for name in ("bench_move", "bench_stop", "bench_status", "bench_preview", "bench_disconnect"):
            self.assertIn("disabled", widgets[name].state())
        self.window.notebook.select(self.window.pages["PTU"])
        for name in ("bench_pan", "bench_tilt"):
            self.assertFalse(widgets[name].bind("<Return>"))
            widgets[name].event_generate("<Return>")
        self.root.update()
        self.assertFalse(self.presenter.bench_open)
        self.assertEqual(self.presenter.bench_snapshot()["results"], [])
        self.assertEqual(widgets["bench_stop"].cget("text"), "Stop")
        self.assertNotEqual(widgets["bench_stop"].master, self.window.pages["PTU"])

    def test_actual_connect_button_keeps_admission_error_in_ptu_results(self):
        configuration = Path(self.temporary.name) / "missing.json"
        self.window.bench_configuration.set(str(configuration))
        self.window.widgets["bench_connect"].invoke()
        self.presenter._bench_thread.join(2)
        self.root.update()
        self.window._poll_bench()
        self.assertEqual(self.presenter.bench_snapshot()["results"][-1]["category"], "bench_input")
        text = self.window.widgets["bench_detail"].get("1.0", "end")
        self.assertIn("bench_input", text)
        self.assertFalse(self.presenter.bench_open)

    def test_actual_buttons_use_shared_real_owner_preview_move_stop_and_disconnect(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.temporary.name)
        self.manager = None
        self.addCleanup(lambda: HeadlessBenchInterfaceTests.release(self))
        HeadlessBenchInterfaceTests.controlled_owners(self)
        self.window.notebook.select(self.window.pages["PTU"])
        self.window.bench_configuration.set(str(self.configuration_file))
        self.window.widgets["bench_connect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        self.window.bench_target["pan"].set("10")
        self.window.bench_target["tilt"].set("0")
        self.window.widgets["bench_preview"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        self.assertEqual(self.native.motion(), [])
        self.assertNotIn("disabled", self.window.widgets["bench_move"].state())
        self.window.widgets["bench_move"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["physical_state"], "indeterminate")
        self.window._poll_bench()
        self.assertEqual(len(self.native.motion()), 1)
        self.window.widgets["bench_stop"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self, "_bench_stop_thread")["category"], "ok")
        self.window._poll_bench()
        self.window.widgets["bench_disconnect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        self.assertFalse(self.presenter.bench_open)
        self.assertEqual(len(self.native.motion()), 1)

    def controlled_native(self, selected=None):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.temporary.name)
        self.manager = None
        self.addCleanup(lambda: HeadlessBenchInterfaceTests.release(self))
        if selected is None and getattr(self, "local_serial", False):
            selected = "manual"
        HeadlessBenchInterfaceTests.controlled_owners(self, selected=selected)
        self.native.tilt_units = -100
        self.window.notebook.select(self.window.pages["PTU"])
        self.root.update()
        self.root.focus_force()
        self.root.update()
        self.window.bench_configuration.set(str(self.configuration_file))
        self.window.widgets["bench_connect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        self.window.widgets["bench_pad_focus"].focus_set()
        self.root.update()
        self.assertTrue(self.window._bench_focus_owned())
        if getattr(self, "local_serial", False):
            self.assertFalse(self.presenter.bench_snapshot()["readback"]["manual_enabled"])
            self.assertTrue(self.presenter.bench_snapshot()["readback"]["jog_allowed"])
            self.assertTrue(self.window.widgets["bench_manual"].instate(["disabled"]))
            self.assertTrue(self.window.widgets["bench_step"].instate(["disabled"]))
            return
        self.window.bench_step.set("1")
        self.window.widgets["bench_manual"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.root.update()
        self.window._poll_bench()
        self.assertTrue(self.window._bench_focus_owned())
        self.assertTrue(self.presenter.bench_snapshot()["readback"]["manual_enabled"])

    def test_actual_direction_buttons_and_current_readback_preserve_typed_target(self):
        self.controlled_native()
        self.window.bench_target["pan"].set("-")
        self.window.bench_target["tilt"].set("-1.")
        for direction in ("left", "right", "up", "down"):
            self.window.widgets["bench_" + direction].invoke()
            self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
            self.window._poll_bench()
        self.assertEqual(len(self.native.motion()), 4)
        self.assertEqual(self.window.bench_target["pan"].get(), "-")
        self.assertEqual(self.window.bench_target["tilt"].get(), "-1.")
        session = self.presenter._bench_session
        session._next_poll = 0
        self.presenter.poll_bench()
        HeadlessBenchInterfaceTests.settle(self)
        self.window._render_bench()
        self.assertIn("Controlled rehearsal", self.window.bench_position.get())
        self.assertIn("fresh", self.window.bench_position.get())
        self.assertIn("tilt -10°", self.window.bench_position.get())
        adapter = sys.modules.get("ui_capture")
        if adapter is not None:
            adapter.capture(self.root, "ptu")

    def test_loopback_manual_actual_widgets_and_raw_transport(self):
        self.plaintext = True
        self.test_selected_manual_actual_widgets_use_admission_and_real_encoded_commands()
        self.assertEqual(self.harness.contexts, [])
        self.assertEqual(self.harness.wraps, [])
        self.assertFalse(self.manager_transport.strict_instance_compatible(self.configuration))

    def wait_native(self, predicate):
        deadline = time.monotonic() + 2
        while not predicate() and time.monotonic() < deadline:
            self.root.update()
            self._assert_no_callback_errors()
            threading.Event().wait(.005)
        self._assert_no_callback_errors()
        self.assertTrue(predicate())

    def wait_local_stopped(self):
        self.wait_native(lambda: self.presenter.bench_snapshot()["readback"]["jog_allowed"])
        self.window._poll_bench()
        self.assertEqual(self.presenter.bench_snapshot()["readback"]["jog"]["state"], "idle")

    def wait_local_active(self, minimum_packets=1):
        self.wait_native(lambda: len(local_jog_packets(self.native)) >= minimum_packets
                         and self.presenter.bench_snapshot()["readback"]["jog"]["state"] == "active")

    def test_local_pointer_hold_refreshes_until_release_without_steps(self):
        self.local_serial = True
        self.controlled_native()
        self.window.bench_target["pan"].set("-")
        self.window.bench_target["tilt"].set("-1.")
        for direction, axis, sign in (("left", 0, -1), ("right", 0, 1), ("up", 1, 1), ("down", 1, -1)):
            button = self.window.widgets["bench_" + direction]
            previous = len(local_jog_packets(self.native))
            button.event_generate("<ButtonPress-1>")
            self.wait_local_active(previous + 2)
            hold = self.window._bench_hold
            self.assertIsNotNone(hold)
            self.assertEqual(self.presenter.bench_snapshot()["readback"]["jog"]["token"], hold["token"])
            for packet, velocity in local_jog_packets(self.native)[previous:]:
                self.assertGreater(velocity[axis] * sign, 0)
                self.assertEqual(velocity[1 - axis], 0)
                self.assertEqual(velocity[2], 127)
                self.assertEqual(self.protocol._decode_strict_packet(packet, 2)[1], 0)
            button.event_generate("<ButtonRelease-1>")
            self.wait_local_stopped()
            self.assertIsNone(self.window._bench_hold)
            self.assertIsNone(self.window._bench_hold_timer)
        self.assertEqual(self.native.motion(), [])
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 4)
        self.assertEqual(self.window.bench_target["pan"].get(), "-")
        self.assertEqual(self.window.bench_target["tilt"].get(), "-1.")
        before = len(local_jog_packets(self.native))
        self.window.widgets["bench_right"].invoke()
        self.root.update()
        self.assertEqual(len(local_jog_packets(self.native)), before)
        self.window.widgets["bench_disconnect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.assertFalse(self.native.opened)
        self.assertFalse(self.presenter.bench_open)

    def test_local_query_widgets_keep_motion_and_stop_disabled(self):
        self.local_serial = True
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.temporary.name)
        self.manager = None
        self.addCleanup(lambda: HeadlessBenchInterfaceTests.release(self))
        HeadlessBenchInterfaceTests.controlled_owners(self, selected="query")
        self.window.bench_configuration.set(str(self.configuration_file))
        self.window.widgets["bench_connect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        for name in ("preview", "move", "manual", "left", "right", "up", "down", "stop"):
            self.assertTrue(self.window.widgets["bench_" + name].instate(["disabled"]))
        self.window.widgets["bench_status"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        before = len(self.native.writes)
        self.window.widgets["bench_disconnect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.assertEqual(len(self.native.writes), before)
        self.assertFalse(self.native.opened)
        self.assertEqual(self.native.motion(), [])

    def test_local_keyboard_repeat_stale_release_and_focus_stop_the_current_hold(self):
        self.local_serial = True
        self.controlled_native()
        focus = self.window.widgets["bench_pad_focus"]
        focus.focus_force()
        self.root.update()
        focus.event_generate("<KeyPress-Right>")
        self.wait_local_active()
        first = self.window._bench_hold
        for unused in range(10):
            focus.event_generate("<KeyRelease-Right>")
            focus.event_generate("<KeyPress-Right>")
        self.root.update()
        self.assertIs(self.window._bench_hold, first)
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 0)
        focus.event_generate("<KeyRelease-Right>")
        self.wait_local_stopped()
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        previous = len(local_jog_packets(self.native))
        focus.event_generate("<KeyPress-Left>")
        self.wait_local_active(previous + 1)
        second = self.window._bench_hold
        self.assertNotEqual(first["token"], second["token"])
        self.window._bench_release_hold(first)
        focus.event_generate("<KeyRelease-Right>")
        self.root.update()
        self.assertIs(self.window._bench_hold, second)
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        target = self.window.widgets["bench_pan"]
        target.focus_force()
        self.wait_local_stopped()
        self.assertIsNone(self.window._bench_hold)
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 2)
        before = len(local_jog_packets(self.native))
        focus.focus_force()
        self.root.update()
        focus.event_generate("<KeyRelease-Left>")
        focus.event_generate("<KeyPress-Left>")
        self.root.update()
        self.assertEqual(len(local_jog_packets(self.native)), before)
        self.assertIn("Left", self.window._bench_blocked_keys)
        target.focus_force()
        self.root.update()
        target.event_generate("<KeyRelease-Left>")
        self.root.update()
        self.assertNotIn("Left", self.window._bench_blocked_keys)
        target.event_generate("<KeyPress-Right>")
        self.window.notebook.select(self.window.pages["Home"])
        self.root.update()
        focus.event_generate("<KeyPress-Right>")
        self.root.update()
        self.assertEqual(len(local_jog_packets(self.native)), before)
        self.assertEqual(self.window._bench_pressed, set())

    def test_local_stale_readback_unmap_and_close_stop_without_restarting(self):
        self.local_serial = True
        self.controlled_native()
        session = self.presenter._bench_session
        session._observation_started -= session._context["observation_max_age_seconds"] + 1
        self.window._render_bench()
        self.assertTrue(self.window.widgets["bench_right"].instate(["disabled"]))
        self.window.widgets["bench_right"].event_generate("<ButtonPress-1>")
        self.root.update()
        self.assertEqual(local_jog_packets(self.native), [])
        self.window.widgets["bench_status"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        right = self.window.widgets["bench_right"]
        right.event_generate("<ButtonPress-1>")
        self.wait_local_active()
        self.root.withdraw()
        self.wait_local_stopped()
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        before = len(local_jog_packets(self.native))
        self.root.deiconify()
        self.root.update()
        self.assertEqual(len(local_jog_packets(self.native)), before)
        self.root.focus_force()
        right.focus_set()
        self.root.update()
        right.event_generate("<ButtonPress-1>")
        self.wait_local_active(before + 1)
        self.window._close()
        self.wait_native(lambda: self.window._window_closed)
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 2)
        self.assertFalse(self.native.opened)
        self.assertFalse(self.presenter.bench_open)
        self.assertIsNone(self.window._bench_hold_timer)

    def test_local_saved_selection_connects_without_repeated_json_choice(self):
        self.local_serial = True
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = Path(self.temporary.name)
        self.manager = None
        self.addCleanup(lambda: HeadlessBenchInterfaceTests.release(self))
        HeadlessBenchInterfaceTests.controlled_owners(self, selected="manual")
        self.window.notebook.select(self.window.pages["PTU"])
        self.root.update()
        self.assertEqual(self.window.bench_configuration.get(), "")
        self.window.widgets["bench_setup_local"].invoke()
        self.assertIn("Saved local QPT130", self.window.bench_saved.get())
        self.assertIn("Numeric no-go: unconfigured", self.window.bench_saved.get())
        self.assertFalse(self.presenter.bench_open)
        self.assertEqual(self.native.writes, [])
        self.window.widgets["bench_connect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        self.assertEqual(local_jog_packets(self.native), [])
        self.assertEqual(self.native.motion(), [])
        self.assertEqual(self.window.bench_configuration.get(), "")
        self.window.widgets["bench_disconnect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        saved = self.presenter.bench_saved
        self.window.bench_configuration.set(str(self.configuration_file))
        self.window.widgets["bench_connect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.assertEqual(self.presenter.bench_saved, saved)
        self.window._poll_bench()
        self.window.widgets["bench_disconnect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        self.window.widgets["bench_setup_local"].invoke()
        self.assertEqual(self.presenter.bench_saved, self.document)
        self.assertEqual(self.window.bench_configuration.get(), "")
        self.assertFalse(self.presenter.bench_open)
        self.window.widgets["bench_connect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.assertEqual(self.presenter._bench_session.document, self.document)
        self.assertEqual(local_jog_packets(self.native), [])

    def test_local_stop_button_ends_hold_once_and_late_release_cannot_restart(self):
        self.local_serial = True
        self.controlled_native()
        right = self.window.widgets["bench_right"]
        right.event_generate("<ButtonPress-1>")
        self.wait_local_active()
        self.window.widgets["bench_stop"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self, "_bench_stop_thread")["category"], "ok")
        self.wait_local_stopped()
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        before = len(local_jog_packets(self.native))
        right.event_generate("<ButtonRelease-1>")
        self.root.update()
        self.assertEqual(len(local_jog_packets(self.native)), before)
        self.assertIsNone(self.window._bench_hold)

    def test_local_pointer_leave_and_modal_focus_end_hold(self):
        self.local_serial = True
        self.controlled_native()
        right = self.window.widgets["bench_right"]
        right.event_generate("<ButtonPress-1>")
        self.wait_local_active()
        right.event_generate("<Leave>")
        self.wait_local_stopped()
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 1)
        before = len(local_jog_packets(self.native))
        right.event_generate("<ButtonPress-1>")
        self.wait_local_active(before + 1)
        self.window.pages["PTU"].event_generate("<ButtonRelease-1>")
        self.wait_local_stopped()
        self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 2)
        before = len(local_jog_packets(self.native))
        focus = self.window.widgets["bench_pad_focus"]
        focus.focus_force()
        self.root.update()
        focus.event_generate("<KeyPress-Right>")
        self.wait_local_active(before + 1)
        modal = self.window.tk.Toplevel(self.root)
        try:
            modal.grab_set()
            self.wait_local_stopped()
            self.assertEqual(self.native.writes.count(self.protocol.stop_packet()), 3)
            before = len(local_jog_packets(self.native))
            focus.event_generate("<KeyPress-Right>")
            self.root.update()
            self.assertEqual(len(local_jog_packets(self.native)), before)
        finally:
            modal.grab_release()
            modal.destroy()

    def test_selected_manual_actual_widgets_use_admission_and_real_encoded_commands(self):
        self.controlled_native(selected="manual")
        self.assertEqual(self.native.motion(), [])
        self.assertIn("tilt -10°", self.window.bench_position.get())
        for direction in ("left", "right", "up", "down"):
            self.window.widgets["bench_" + direction].invoke()
            self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
            self.window._poll_bench()
        self.window.widgets["bench_status"].invoke()
        observed = HeadlessBenchInterfaceTests.settle(self)
        self.assertEqual(observed["category"], "ok")
        self.assertEqual((observed["pan"], observed["tilt"]), (0, -10))
        self.window._poll_bench()
        self.window.bench_target["pan"].set("2")
        self.window.bench_target["tilt"].set("-10")
        self.window.widgets["bench_preview"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.window._poll_bench()
        self.window.widgets["bench_move"].invoke()
        result = HeadlessBenchInterfaceTests.settle(self)
        self.assertEqual(result["category"], "ok")
        self.assertEqual(result["encoded_pan_units"], 20)
        self.assertEqual(len(self.native.motion()), 5)
        self.window._poll_bench()
        self.window.widgets["bench_stop"].invoke()
        result = HeadlessBenchInterfaceTests.settle(self, "_bench_stop_thread")
        self.assertEqual(result["category"], "ok")
        self.assertEqual(result["physical_state"], "indeterminate")
        self.window._poll_bench()
        before = len(self.native.writes)
        self.window.widgets["bench_disconnect"].invoke()
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.assertEqual(len(self.native.writes), before)

    def test_keyboard_repeat_release_focus_and_other_tabs_do_not_queue_steps(self):
        self.controlled_native()
        focus = self.window.widgets["bench_pad_focus"]
        focus.focus_force()
        self.root.update()
        focus.event_generate("<KeyPress-Right>")
        for unused in range(10):
            focus.event_generate("<KeyPress-Right>")
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        self.root.update()
        self.window._poll_bench()
        self.assertEqual(len(self.native.motion()), 1)
        focus.event_generate("<KeyRelease-Right>")
        self.root.update()
        focus.event_generate("<KeyPress-Right>")
        self.assertEqual(HeadlessBenchInterfaceTests.settle(self)["category"], "ok")
        focus.event_generate("<KeyRelease-Right>")
        self.root.update()
        self.assertEqual(len(self.native.motion()), 2)
        target = self.window.widgets["bench_pan"]
        target.focus_force()
        self.root.update()
        self.assertFalse(self.presenter.bench_snapshot()["readback"]["manual_enabled"])
        before = len(self.native.motion())
        target.event_generate("<KeyPress-Left>")
        target.event_generate("<KeyRelease-Left>")
        self.window.notebook.select(self.window.pages["Home"])
        self.root.update()
        focus.event_generate("<KeyPress-Right>")
        self.root.update()
        self.assertEqual(len(self.native.motion()), before)
        self.assertEqual(self.window._bench_pressed, set())

    def test_stale_readback_and_window_loss_disable_manual_without_physical_stop(self):
        from types import SimpleNamespace
        self.controlled_native()
        session = self.presenter._bench_session
        session._observation_started -= session._context["observation_max_age_seconds"] + 1
        self.window._render_bench()
        self.assertIn("stale", self.window.bench_position.get())
        self.assertTrue(self.window.widgets["bench_right"].instate(["disabled"]))
        before = len(self.native.writes)
        self.window._bench_unmapped(SimpleNamespace(widget=self.root))
        self.assertFalse(session.readback_snapshot()["manual_enabled"])
        self.assertEqual(len(self.native.writes), before)

    def test_modal_grab_prevents_arrow_dispatch_in_existing_ptu_tab(self):
        self.controlled_native()
        focus = self.window.widgets["bench_pad_focus"]
        focus.focus_force()
        self.root.update()
        modal = self.window.tk.Toplevel(self.root)
        try:
            modal.grab_set()
            self.root.update()
            before = len(self.native.writes)
            self.assertFalse(self.window._bench_focus_owned())
            focus.event_generate("<KeyPress-Right>")
            focus.event_generate("<KeyRelease-Right>")
            self.root.update()
            self.assertEqual(len(self.native.writes), before)
        finally:
            modal.grab_release()
            modal.destroy()
