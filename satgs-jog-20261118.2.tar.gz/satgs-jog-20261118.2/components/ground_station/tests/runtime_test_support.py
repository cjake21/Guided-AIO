"""Strict offline interfaces, not numerical, wire, owner, or hardware integration."""
from contextlib import contextmanager, ExitStack
from datetime import datetime, timedelta, timezone
import csv
import hashlib
import importlib
import importlib.abc
import json
import math
import os
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
from unittest.mock import patch


EVENTS = []
FAIL_AT = set()
PRIMED = True
COORDINATES_VALID = True
CONNECTION = True
ON_EVENT = None
EPHEMERIS_MODE = 'circumpolar'
FORBIDDEN_IMPORTS = []
REVIEWED = {name: ('test-only-owner-v1',) for name in ('meteor-api', 'sat_tracker', 'pixhawk')}
OMITTED = ('dsi', 'cyberpowerpdu', 'signal_hound_control', 'signal_hound',
           'telnetlib3', 'satgs.post_processing', 'box_api_sync', 'boxsdk')


def event(name, **details):
    EVENTS.append((name, details))
    if ON_EVENT is not None:
        ON_EVENT(name, details)
    if name in FAIL_AT:
        raise RuntimeError('synthetic controlled stage failure')


def reset():
    global PRIMED, COORDINATES_VALID, CONNECTION, ON_EVENT, EPHEMERIS_MODE
    EVENTS.clear()
    FAIL_AT.clear()
    FORBIDDEN_IMPORTS.clear()
    PRIMED = COORDINATES_VALID = CONNECTION = True
    ON_EVENT = None
    EPHEMERIS_MODE = 'circumpolar'


class Date(float):
    def __new__(cls, value=0):
        if isinstance(value, datetime):
            value = value.replace(tzinfo=value.tzinfo or timezone.utc).timestamp() / 86400
        return super().__new__(cls, value)

    def datetime(self):
        return datetime.fromtimestamp(float(self) * 86400, tz=timezone.utc).replace(tzinfo=None)


class Observer:
    def __init__(self):
        self.date = datetime.now(timezone.utc)

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, value):
        self._date = Date(value)

    def next_pass(self, body):
        if EPHEMERIS_MODE.startswith('circumpolar'):
            raise ValueError('synthetic circumpolar fixture')
        if EPHEMERIS_MODE == 'unavailable':
            return (None, None, None, None, None, None)
        raise AssertionError('unplanned scientific fixture mode')


class Body:
    def compute(self, observer):
        self.az = (float(observer.date) % 1) * math.pi
        self.alt = math.pi / 3
        if EPHEMERIS_MODE == 'circumpolar-below-mask':
            self.alt = -math.pi / 12
        elif EPHEMERIS_MODE == 'circumpolar-invalid-elevation':
            self.alt = 2 * math.pi / 3
        elif EPHEMERIS_MODE == 'circumpolar-nonfinite':
            self.alt = math.nan
        self.range = 1000.0
        self.range_velocity = 0.0


def readtle(name, line1, line2):
    if not name or not line1.startswith('1 ') or not line2.startswith('2 '):
        raise ValueError('invalid synthetic TLE interface')
    return Body()


class Array(list):
    @property
    def shape(self):
        return len(self)


class Frame:
    def __init__(self, rows):
        self.rows = rows

    def set_index(self, column):
        self.column = column
        return self

    def to_dict(self, orientation):
        if orientation != 'index':
            raise AssertionError('unexpected dataframe orientation')
        return {row[self.column]: {key: value for key, value in row.items() if key != self.column}
                for row in self.rows}


def read_csv(path):
    event('csv.read', filename=Path(path).name)
    with open(path, newline='') as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        if 'norad_id' in row:
            row['norad_id'] = int(row['norad_id'])
    return Frame(rows)


def unexpected(*args, **kwargs):
    raise AssertionError('unexpected dependency operation in controlled runtime lane')


def _bounded(deadline, cancel=None):
    if not isinstance(deadline, (int, float)) or not math.isfinite(deadline):
        raise AssertionError('missing finite owner deadline')
    if cancel is not None and cancel.is_set():
        raise AssertionError('new owner operation after cancellation')


class _Prepared:
    __slots__ = ('settings', 'cancel', 'used')

    def __init__(self, settings, cancel):
        self.settings, self.cancel, self.used = settings, cancel, False


class Transport:
    CONTRACT_REVISION = 'satgs.pointing.v2'
    SOURCE_REVISION = 'test-only-owner-v1'

    def __init__(self, *args, **kwargs):
        if args or kwargs:
            event('legacy.messenger.open')
        self.closed = False
        self._strict_settings = None

    @staticmethod
    def prepare_transport(*, settings, cancel):
        if cancel.is_set():
            raise AssertionError('preparation after cancellation')
        event('messenger.prepare')
        return _Prepared(settings, cancel)

    @classmethod
    def open_bounded(cls, *, settings, deadline, cancel, prepared):
        _bounded(deadline, cancel)
        assert type(prepared) is _Prepared and not prepared.used
        assert prepared.settings is settings and prepared.cancel is cancel
        prepared.used = True
        event('messenger.open')
        return cls.borrowed_for(settings)

    @classmethod
    def borrowed_for(cls, settings):
        instance = cls()
        instance._strict_settings = settings
        return instance

    def strict_instance_compatible(self, *, settings):
        return not self.closed and self._strict_settings is settings

    def close(self, *, deadline):
        _bounded(deadline)
        if self.closed:
            raise AssertionError('transport closed twice')
        self.closed = True
        event('messenger.close')


class Ptu:
    CONTRACT_REVISION = 'satgs.pointing.v1'
    SOURCE_REVISION = 'test-only-owner-v1'

    def __init__(self, messenger=None, **kwargs):
        self.closed = False
        self.modular = not bool(kwargs)
        self._scheduled = False
        self._tracking_result = None
        self._tracking_sequence = 0
        self._tracking_count = 0
        if kwargs:
            event('legacy.ptu.open', test_mode=kwargs.get('test_mode', False), ptu_id=kwargs['ptu_id'])
            self._configure(7, 9, kwargs['elevation_mask'])

    def _configure(self, ptu_id, pix_id, elevation):
        self.ptu_ids = [ptu_id]
        self.ptu_dict = {ptu_id: {'id': ptu_id, 'pix_id': pix_id, 'no_go_config': None, 'name': 'synthetic PTU'}}
        self.ptu_status = {ptu_id: SimpleNamespace(azimuth=0, elevation=60, pan=0, tilt=60,
                                                 command=None, state='synthetic unknown')}
        self.ptu_is_primed = {ptu_id: PRIMED}
        self.ptu_angles = {ptu_id: SimpleNamespace(az=0, el=60)}
        self.elevation_mask = elevation

    @classmethod
    def open_pointing(cls, *, messenger, settings, ptu_id, elevation_mask, log_dir, no_go_data, deadline, cancel):
        _bounded(deadline, cancel)
        assert ptu_id > 0 and not isinstance(ptu_id, bool)
        assert isinstance(messenger, Transport) and not messenger.closed
        positions = [row for row in settings['positioners'] if row['id'] == ptu_id]
        assert len(positions) == 1
        event('ptu.open', ptu_id=ptu_id, log_dir=str(log_dir))
        instance = cls()
        instance._configure(ptu_id, positions[0]['pix_id'], elevation_mask)
        return instance

    def check_connection(self, *, deadline=None, cancel=None):
        if deadline is not None:
            _bounded(deadline, cancel)
        event('ptu.check')
        return CONNECTION

    def load_tle(self, tle, *, deadline=None, cancel=None):
        if deadline is not None:
            _bounded(deadline, cancel)
        assert isinstance(tle, str) and ',1 ' in tle
        event('ptu.load_tle', selected=tuple(self.ptu_ids))

    def prime(self, azimuth, elevation, *, deadline=None, cancel=None):
        if deadline is not None:
            _bounded(deadline, cancel)
        assert math.isfinite(azimuth) and math.isfinite(elevation)
        event('ptu.prime', selected=tuple(self.ptu_ids))

    def enable_scheduled_tracking(self, *, deadline, cancel):
        _bounded(deadline, cancel)
        assert self.modular and not self.closed
        self._scheduled = True

    def _record_tracking(self, operation, state, submitted):
        self._tracking_sequence += 1
        self._tracking_count += submitted
        self._tracking_result = SimpleNamespace(
            manager_id=self.ptu_ids[0], sequence=self._tracking_sequence,
            operation=operation, category='ok', state=state, submitted=submitted,
            submission='none', total_submitted=self._tracking_count,
            possible_submission=self._tracking_count > 0)
        return self._tracking_result

    def track(self, *, deadline, cancel):
        _bounded(deadline, cancel)
        assert self._scheduled and not self.closed
        event('ptu.track', selected=tuple(self.ptu_ids))
        return self._record_tracking(4, 'tle_tracking', 1)

    def complete_tracking(self, *, deadline, cancel):
        _bounded(deadline, cancel)
        assert self._scheduled and not self.closed
        event('ptu.complete_tracking', selected=tuple(self.ptu_ids))
        return self._record_tracking(5, 'complete', 0)

    def tracking_outcome(self):
        return self._tracking_result

    def tracking_failure(self):
        return None

    def validateCoordinates(self, azimuth, elevation):
        assert math.isfinite(azimuth) and math.isfinite(elevation)
        event('ptu.validate')
        return COORDINATES_VALID

    def close(self, *, deadline):
        _bounded(deadline)
        assert not self.closed
        self.closed = True
        event('ptu.close')

    def calibrate_ptu(self):
        if self.modular:
            unexpected()
        event('legacy.ptu.calibrate')

    def start_logging(self):
        if self.modular:
            unexpected()
        event('legacy.ptu.start_logging')

    def park_ptu(self):
        if self.modular:
            unexpected()
        event('legacy.ptu.park')

    def clean_exit(self):
        if self.modular:
            unexpected()
        event('legacy.ptu.active_cleanup')

    def parked(self):
        if self.modular:
            unexpected()
        event('legacy.ptu.parked')
        return False


class Pix:
    CONTRACT_REVISION = 'satgs.pointing.v1'
    SOURCE_REVISION = 'test-only-owner-v1'

    def __init__(self, messenger=None, **kwargs):
        self.closed = False
        if kwargs:
            event('legacy.pix.open', pix_id=kwargs['pix_id'])
            self._configure(9, 7)

    def _configure(self, pix_id, ptu_id):
        self.pix_ids = [pix_id]
        self.pix_dict = {pix_id: {'ptu_id': ptu_id}}
        self.pix_status = {pix_id: SimpleNamespace(gpsYaw=65500, hdg=0, pitch=0, gpsStatus='synthetic unknown')}

    @classmethod
    def open_pointing(cls, *, messenger, settings, pix_id, log_dir, deadline, cancel):
        _bounded(deadline, cancel)
        assert pix_id > 0 and not isinstance(pix_id, bool)
        assert isinstance(messenger, Transport) and not messenger.closed
        sensors = [row for row in settings['pixhawk_sensors'] if row['id'] == pix_id]
        assert len(sensors) == 1
        event('pix.open', pix_id=pix_id, log_dir=str(log_dir))
        instance = cls()
        instance._configure(pix_id, sensors[0]['ptu_id'])
        return instance

    def check_connection(self, *, deadline=None, cancel=None):
        if deadline is not None:
            _bounded(deadline, cancel)
        event('pix.check')
        return CONNECTION

    def start_logging(self, *, deadline=None, cancel=None):
        if deadline is not None:
            _bounded(deadline, cancel)
        event('pix.start_logging')

    def close(self, *, deadline):
        _bounded(deadline)
        assert not self.closed
        self.closed = True
        event('pix.close')

    def clean_exit(self):
        event('legacy.pix.cleanup')


class ForbiddenImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if any(fullname == name or fullname.startswith(name + '.') for name in OMITTED):
            FORBIDDEN_IMPORTS.append(fullname)
            raise AssertionError('omitted dependency import attempted: ' + fullname)
        return None


def _module(name, **attributes):
    module = ModuleType(name)
    module.__dict__.update(attributes)
    return module


def dependency_modules():
    from ptu_control import pointing

    def json_yaml(value):
        return json.load(value) if hasattr(value, 'read') else json.loads(value)

    def dump(value, stream, **kwargs):
        json.dump(value, stream)

    def zone(name):
        if name not in ('UTC', 'US/Eastern'):
            raise AssertionError('unexpected timezone fixture')
        return timezone.utc

    return {
        'yaml': _module('yaml', safe_load=json_yaml, dump=dump),
        'ephem': _module('ephem', Observer=Observer, Date=Date, readtle=readtle, degree=math.pi / 180),
        'numpy': _module('numpy', ndarray=Array, array=lambda values: Array(values), zeros=lambda size: Array([0] * size),
                         pi=math.pi, floor=math.floor, nan=math.nan, argmax=lambda values: max(range(len(values)), key=values.__getitem__)),
        'pandas': _module('pandas', read_csv=read_csv),
        'pytz': _module('pytz', timezone=zone),
        'logging_tree': _module('logging_tree', printout=unexpected),
        'niquests': _module('niquests', get=unexpected, post=unexpected),
        'scipy': _module('scipy', __path__=[]),
        'scipy.interpolate': _module('scipy.interpolate', CubicSpline=unexpected),
        'meteor_api': _module('meteor_api', __path__=[]),
        'meteor_api.messenger': _module('meteor_api.messenger', Messenger=Transport),
        'ptu_control': _module('ptu_control', __path__=[]),
        'ptu_control.pointing': pointing,
        'ptu_control.ptu_client': _module('ptu_control.ptu_client', PtuClient=Ptu),
        'ptu_control.utils': _module('ptu_control.utils', PtuID=type('PtuID', (), {'from_dict': staticmethod(lambda value: SimpleNamespace(**value))})),
        'pixhawk': _module('pixhawk', __path__=[]),
        'pixhawk.pixhawk_subscriber': _module('pixhawk.pixhawk_subscriber', PixhawkSubscriber=Pix),
        'satgs.jobs_msg_pb2': _module('satgs.jobs_msg_pb2', JobRequest=unexpected, JobDetails=unexpected, AddJobCmdMsg=unexpected),
    }


class FrontEnd:
    def __init__(self, messenger, *, log_file):
        assert isinstance(messenger, Transport)
        event('legacy.frontend.open')

    def check_connection(self):
        event('legacy.frontend.check')
        return True

    def disconnect_tx(self):
        event('legacy.frontend.disconnect_tx')

    def disconnect_rx(self):
        event('legacy.frontend.disconnect_rx')

    def configure_rx(self, *, frequency):
        assert frequency == 1500.0
        event('legacy.frontend.configure_rx')

    def configure_tx(self, *, frequency, work_modem_tx_source):
        assert frequency > 0
        event('legacy.frontend.configure_tx')

    def request_rx_status(self):
        event('legacy.frontend.status')
        return SimpleNamespace(if_out=1000.0)

    def shutdown(self):
        event('legacy.frontend.shutdown')


class Pdu:
    def __init__(self, messenger, *, log_file):
        assert isinstance(messenger, Transport)
        event('legacy.pdu.open')

    def check_connection(self):
        event('legacy.pdu.check')
        return True

    def set_warning_lights(self, state, *, check_outcome):
        assert state in (0, 1) and check_outcome
        event('legacy.pdu.warning_lights')

    def set_hpa(self, state, *, check_outcome):
        assert state in (0, 1) and check_outcome
        event('legacy.pdu.hpa')

    def shutdown(self):
        event('legacy.pdu.shutdown')


class Trace:
    def __init__(self, messenger, *, config, log_file, standalone):
        assert isinstance(messenger, Transport) and not standalone
        event('legacy.trace.open')

    def configure(self, *, fc_mhz, bw_mhz, ch_bw_mhz, ref_level_dbm, trace_log_name, duration):
        assert fc_mhz == 1000.0 and bw_mhz == 20.0 and ch_bw_mhz == 10.0
        assert ref_level_dbm == -30 and duration >= 60
        event('legacy.trace.configure')

    def start(self, *, duration, ch_bw_mhz):
        assert duration >= 60 and ch_bw_mhz == 10.0
        event('legacy.trace.start')

    def abort(self, timeout=None):
        event('legacy.trace.abort')

    def clean_exit(self):
        event('legacy.trace.cleanup')


class Iq:
    def __init__(self, messenger):
        assert isinstance(messenger, Transport)
        event('legacy.iq.open')

    def configure_record(self, **options):
        assert set(options) == {'bw_mhz', 'fc_mhz', 'ref_level_dbm', 'filename', 'max_duration', 'fc_rf_mhz'}
        assert options['fc_mhz'] == 1000.0 and options['fc_rf_mhz'] == 1500.0
        event('legacy.iq.configure')

    def start(self):
        event('legacy.iq.start')

    def stop(self):
        event('legacy.iq.stop')


class Telnet:
    def __init__(self, host, port, *, connect_timeout):
        assert isinstance(host, str) and port == 5025 and connect_timeout == 5
        event('legacy.telnet.open')

    def __enter__(self):
        return self

    def __exit__(self, *args):
        event('legacy.telnet.close')

    def write(self, command):
        assert command in ('OUTP?\r\n', 'OUTP OFF\r\n')
        event('legacy.telnet.write')

    def readline(self):
        return '0\n'


def legacy_modules():
    return {
        'dsi': _module('dsi', __path__=[]),
        'dsi.front_end_client': _module('dsi.front_end_client', FrontEndClient=FrontEnd),
        'cyberpowerpdu': _module('cyberpowerpdu', __path__=[]),
        'cyberpowerpdu.pdu_client': _module('cyberpowerpdu.pdu_client', PduClient=Pdu),
        'cyberpowerpdu.utils': _module('cyberpowerpdu.utils', OutletState=SimpleNamespace(ON=1, OFF=0)),
        'signal_hound_control': _module('signal_hound_control', __path__=[]),
        'signal_hound_control.sh_client': _module('signal_hound_control.sh_client', SignalHoundClient=Iq),
        'signal_hound_control.sh_sa_client': _module('signal_hound_control.sh_sa_client', SigHoundSweptAnalyzerClient=Trace),
        'telnetlib3': _module('telnetlib3', __path__=[]),
        'telnetlib3.sync': _module('telnetlib3.sync', TelnetConnection=Telnet),
    }


@contextmanager
def controlled_runner(*, reviewed=True):
    reset()
    modules = dependency_modules()
    modules['pixhawk'].pixhawk_subscriber = modules['pixhawk.pixhawk_subscriber']
    finder = ForbiddenImports()
    stale = {name: sys.modules.pop(name) for name in ('satgs.pass_runner', 'satgs.utils', 'satgs.constants') if name in sys.modules}
    sys.meta_path.insert(0, finder)
    try:
        with patch.dict(sys.modules, modules):
            runner = importlib.import_module('satgs.pass_runner')
            with patch.dict(runner._REVIEWED_OWNER_RELEASES, REVIEWED if reviewed else {}, clear=True):
                yield runner
    finally:
        sys.meta_path.remove(finder)
        for name in ('satgs.pass_runner', 'satgs.utils', 'satgs.constants'):
            sys.modules.pop(name, None)
        sys.modules.update(stale)


def install_child_contract():
    reset()
    modules = dependency_modules()
    modules['pixhawk'].pixhawk_subscriber = modules['pixhawk.pixhawk_subscriber']
    sys.modules.update(modules)
    sys.meta_path.insert(0, ForbiddenImports())

    def reviewed_test_revision(frame, event_name, argument):
        if event_name == 'call' and frame.f_code.co_name == '_pointing_owner_types':
            if os.environ.get('SATGS_RUNTIME_REVIEWED_FAKE') == '1':
                frame.f_globals['_REVIEWED_OWNER_RELEASES'].update(REVIEWED)
            sys.settrace(None)
        return reviewed_test_revision

    sys.settrace(reviewed_test_revision)


@contextmanager
def noncircumpolar_pass(module, *, rise, setting):
    """Control science responses and time, preserving real pass selection and execution."""
    epoch = datetime(2026, 9, 23, 12, tzinfo=timezone.utc)
    clock = SimpleNamespace(seconds=0.0, sleeps=[], observations=[], next_pass_calls=0, runner=None)

    def sleep(seconds):
        if not 0 <= seconds <= 3 or len(clock.sleeps) >= 1000:
            raise AssertionError('unexpected or unbounded virtual wait')
        clock.seconds += seconds
        clock.sleeps.append(seconds)

    class VirtualDatetime(datetime):
        @classmethod
        def now(cls, tz=None):
            value = epoch + timedelta(seconds=clock.seconds)
            return value if tz else value.replace(tzinfo=None)

    class OrbitObserver(Observer):
        def next_pass(self, body):
            clock.next_pass_calls += 1
            offset = (self.date.datetime().replace(tzinfo=timezone.utc) - epoch).total_seconds()
            if offset < setting - 0.0001:
                left, right = rise, setting
            else:
                left, right = 8 * 3600, 8 * 3600 + setting - rise
            return (Date(epoch + timedelta(seconds=left)), 0.2,
                    Date(epoch + timedelta(seconds=(left + right) / 2)), math.pi / 4,
                    Date(epoch + timedelta(seconds=right)), 2.0)

    class OrbitBody:
        def compute(self, observer):
            offset = (observer.date.datetime().replace(tzinfo=timezone.utc) - epoch).total_seconds()
            midpoint = (rise + setting) / 2
            elevation = 45 * (1 - abs(offset - midpoint) / ((setting - rise) / 2))
            self.az = (120 + offset / 10) * math.pi / 180
            self.alt = elevation * math.pi / 180
            self.range, self.range_velocity = 1000.0, 0.0
            if clock.runner is not None and observer is clock.runner.ground_station:
                valid = clock.runner.el_mask <= elevation <= 180 - clock.runner.el_mask
                clock.observations.append((clock.runner.state, clock.seconds, elevation, valid))

    def arange(start, stop, step):
        return Array(start + step * index for index in range(math.ceil((stop - start) / step)))

    def validate(client, azimuth, elevation):
        valid = math.isfinite(azimuth) and client.elevation_mask <= elevation <= 180 - client.elevation_mask
        clock.observations.append((getattr(clock.runner, 'state', None), clock.seconds, elevation, valid))
        event('ptu.validate')
        return valid

    original_prime = Ptu.prime
    original_track = Ptu.track
    original_wait = module.threading.Event.wait

    def prime(client, azimuth, elevation, **options):
        if not any(name == 'ptu.load_tle' for name, _ in EVENTS):
            raise AssertionError('prime before admitted TLE load')
        original_prime(client, azimuth, elevation, **options)
        client.ptu_is_primed = {client.ptu_ids[0]: True}

    def track(client, **options):
        observer = OrbitObserver()
        observer.date = VirtualDatetime.now(timezone.utc)
        body = OrbitBody()
        body.compute(observer)
        elevation = body.alt * 180 / math.pi
        valid = client.elevation_mask <= elevation <= 180 - client.elevation_mask
        clock.observations.append((clock.runner.state, clock.seconds, elevation, valid))
        return original_track(client, **options)

    def wait(signal, timeout=None):
        if clock.runner is not None and signal is clock.runner.cancel_event:
            if not signal.is_set():
                sleep(timeout)
            return signal.is_set()
        return original_wait(signal, timeout)

    with ExitStack() as stack:
        stack.enter_context(patch.object(module.ephem, 'Observer', OrbitObserver))
        stack.enter_context(patch.object(module.ephem, 'readtle', lambda *args: OrbitBody()))
        stack.enter_context(patch.object(module.np, 'arange', arange, create=True))
        stack.enter_context(patch.object(module, 'datetime', VirtualDatetime))
        stack.enter_context(patch.object(module.time, 'sleep', sleep))
        stack.enter_context(patch.object(module.threading.Event, 'wait', wait))
        stack.enter_context(patch.object(Ptu, 'validateCoordinates', validate))
        stack.enter_context(patch.object(Ptu, 'prime', prime))
        stack.enter_context(patch.object(Ptu, 'track', track))
        stack.enter_context(patch.object(sys.modules[__name__], 'PRIMED', False))
        yield clock


class Inputs:
    def __init__(self, root):
        from satgs.deployment import load_manifest
        from satgs.deployment_plan import build_catalog, expand_preset
        self.root = Path(root)
        self.paths = {name: self.root / name for name in ('deployment.json', 'bindings.json', 'station.yaml', 'tle.csv')}
        self.configuration = expand_preset(build_catalog(load_manifest()), 'guided_arrow').to_dict()
        self.configuration['target'] = {'id': 'fixture-target', 'environment': 'linux-arm64-python311'}
        self.station = {
            'home_directory': str(self.root), 'logging_dir': str(self.root / 'results'),
            'file_prefix_source': 'default', 'amq_server': 'synthetic.invalid', 'amq_port': 61613,
            'amq_username': 'SYNTHETIC-USER-ONLY', 'amq_password': 'SYNTHETIC-SECRET-ONLY',
            'amq_use_ssl': True, 'ground_station_lat': 42.0, 'ground_station_lon': -71.0,
            'amq_dial_address': '192.0.2.7', 'amq_tls_server_name': 'broker.example',
            'amq_ca_pem': 'SYNTHETIC-PUBLIC-CA-ONLY',
            'ground_station_altm': 12.5,
            'positioners': [{'id': 7, 'pix_id': 9, 'type': 'QPT-130', 'no_go_config': None},
                            {'id': 8, 'pix_id': 10, 'type': 'QPT-500'}],
            'pixhawk_sensors': [{'id': 9, 'ptu_id': 7}, {'id': 10, 'ptu_id': 8}],
        }
        self.binding = {
            'schema_version': 1, 'configuration_id': self.configuration['id'],
            'configuration_revision': self.configuration['revision'],
            'configuration_sha256': '', 'target': self.configuration['target'],
            'bindings': [
                {'instance_id': 'ptu-1', 'component': 'qpt130', 'provider': 'guided_arrow_hardware',
                 'manager_id': 7, 'paired_with': 'pixhawk-1'},
                {'instance_id': 'pixhawk-1', 'component': 'pixhawk_dual_gps', 'provider': 'guided_arrow_hardware',
                 'manager_id': 9, 'paired_with': 'ptu-1'},
            ],
        }
        self.tle = {'norad_id': '28626', 'name': 'XM-3 (RHYTHM)',
                    'tle': 'XM-3 (RHYTHM),1 28626U 05008A   25135.79004957 -.00000184  00000+0  00000+0 0  9996,2 28626   0.0095  11.7717 0001427 181.9268 238.1539  1.00268135 74089',
                    'date': '2025-05-16 02:51:09 UTC'}
        self.station['positioners'][0].update(
            protocol='PTCR20', cont_rot=False, hard_pan_lim_cw=270, hard_pan_lim_ccw=-270,
            pointing_context={
                'frame': 'azimuth-elevation-degrees.v1', 'run_id': '01' * 32,
                'configuration_generation': 1, 'calibration_generation': 1,
                'pan_to_az': 0, 'tilt_to_el': 90, 'protocol_address': None,
                'tle_sha256': hashlib.sha256(self.tle['tle'].encode('ascii')).hexdigest(),
            })
        self.write()

    def write(self):
        raw = json.dumps(self.configuration, indent=2).encode()
        self.paths['deployment.json'].write_bytes(raw)
        self.binding['configuration_sha256'] = hashlib.sha256(raw).hexdigest()
        self.paths['bindings.json'].write_text(json.dumps(self.binding))
        self.paths['station.yaml'].write_text(json.dumps(self.station))
        with self.paths['tle.csv'].open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=tuple(self.tle))
            writer.writeheader()
            writer.writerow(self.tle)

    def load(self, **options):
        from satgs.runtime_configuration import load_runtime_configuration
        return load_runtime_configuration(*(self.paths[name] for name in ('deployment.json', 'bindings.json', 'station.yaml', 'tle.csv')),
                                          sat_id=28626, duration=options.get('duration', 0.01), elevation=15)

    def argv(self):
        return ['--operation', 'pointing', '--deployment-config', str(self.paths['deployment.json']),
                '--runtime-bindings', str(self.paths['bindings.json']), '-config', str(self.paths['station.yaml']),
                '-sf', str(self.paths['tle.csv']), '-id', '28626', '-d', '0.01', '-nd']
