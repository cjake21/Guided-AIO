import copy
from dataclasses import FrozenInstanceError
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

from satgs import deployment


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = REPOSITORY_ROOT / "config" / "deployment_profiles.json"


class DeploymentManifestTests(unittest.TestCase):
    def _manifest_data(self):
        return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))

    def _write_manifest(self, data):
        temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(temporary_directory.cleanup)
        path = Path(temporary_directory.name) / "deployment_profiles.json"
        path.write_text(json.dumps(data), encoding="utf-8")
        return path

    def _write_manifest_bytes(self, payload):
        temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(temporary_directory.cleanup)
        path = Path(temporary_directory.name) / "deployment_profiles.json"
        path.write_bytes(payload)
        return path

    @staticmethod
    def _profile(data, profile_id):
        return next(profile for profile in data["profiles"] if profile["id"] == profile_id)

    @staticmethod
    def _item(profile, collection, item_id):
        return next(item for item in profile[collection] if item["id"] == item_id)

    @classmethod
    def _remove_item(cls, profile, collection, item_id):
        profile[collection].remove(cls._item(profile, collection, item_id))

    @staticmethod
    def _instance_records(profile):
        return tuple(
            (instance.id, instance.component, instance.provider)
            for instance in profile.instances
        )

    @staticmethod
    def _service_records(profile):
        return tuple(
            (service.id, service.unit, service.provider, service.host_roles)
            for service in profile.services
        )

    @staticmethod
    def _capability_records(profile):
        return tuple(
            (
                capability.id,
                capability.provider,
                capability.applicability,
                capability.required_by_default,
                capability.supported,
                capability.instance_ids,
            )
            for capability in profile.capabilities
        )

    def test_manifest_parses_successfully(self):
        manifest = deployment.load_manifest()

        self.assertEqual(manifest.schema_version, 1)
        self.assertEqual(
            tuple(profile.id for profile in manifest.profiles),
            ("full_msel", "guided_arrow"),
        )

    def test_missing_default_manifest_does_not_use_another_manifest(self):
        with tempfile.TemporaryDirectory() as directory:
            absent = Path(directory) / "missing.json"
            with mock.patch.object(deployment, "DEFAULT_MANIFEST_PATH", absent):
                with self.assertRaises(deployment.ManifestError):
                    deployment.load_manifest()
                self.assertEqual(deployment.load_manifest(MANIFEST_PATH).schema_version, 1)

    def test_default_manifest_retains_type_and_content_validation(self):
        for payload in (b"{}", b"null", b"{bad-json}"):
            path = self._write_manifest_bytes(payload)
            with mock.patch.object(deployment, "DEFAULT_MANIFEST_PATH", path):
                with self.assertRaises(deployment.ManifestError):
                    deployment.load_manifest()

    def test_manifest_profile_order_is_canonical(self):
        data = self._manifest_data()
        data["profiles"].reverse()

        with self.assertRaisesRegex(
            deployment.ManifestError,
            "profile identifiers and order must be exactly",
        ):
            deployment.load_manifest(self._write_manifest(data))

    def test_schema_version_is_accepted(self):
        manifest = deployment.load_manifest(MANIFEST_PATH)

        self.assertEqual(manifest.schema_version, deployment.SCHEMA_VERSION)

    def test_unknown_schema_versions_are_rejected(self):
        for version in (0, 2, True):
            with self.subTest(version=version):
                data = self._manifest_data()
                data["schema_version"] = version
                with self.assertRaises(deployment.ManifestError):
                    deployment.load_manifest(self._write_manifest(data))

    def test_full_msel_resolves(self):
        profile = deployment.resolve_profile("full_msel")

        self.assertEqual(profile.display_name, "Full M-SEL")
        self.assertTrue(profile.apply_supported)

    def test_guided_arrow_resolves(self):
        profile = deployment.resolve_profile("guided_arrow")

        self.assertEqual(profile.display_name, "Guided Arrow AIO")
        self.assertFalse(profile.apply_supported)

    def test_builtin_profile_metadata_is_canonical(self):
        cases = (
            ("full_msel", "display_name", "Renamed Full M-SEL"),
            ("full_msel", "apply_supported", False),
            ("guided_arrow", "display_name", "Renamed Guided Arrow"),
            ("guided_arrow", "apply_supported", True),
        )

        for profile_id, field, value in cases:
            with self.subTest(profile_id=profile_id, field=field):
                data = self._manifest_data()
                self._profile(data, profile_id)[field] = value
                with self.assertRaisesRegex(
                    deployment.ManifestError,
                    f"profile {profile_id!r} {field} must match",
                ):
                    deployment.load_manifest(self._write_manifest(data))

    def test_unknown_profile_is_rejected(self):
        with self.assertRaisesRegex(
            deployment.UnknownProfileError, "unknown deployment profile"
        ):
            deployment.resolve_profile("unknown")

    def test_full_msel_plan_matches_golden_baseline(self):
        profile = deployment.resolve_profile("full_msel")
        actual = tuple(
            (step.id, step.path, step.install_mode) for step in profile.packages
        )
        expected = (
            ("meteor-api", "lib/meteor-api", "editable"),
            ("ground_station", ".", "editable"),
            (
                "msel_post_processing",
                "lib/msel_post_processing",
                "editable",
            ),
            ("cyberpowerpdu", "lib/cyberpowerpdu", "editable"),
            ("dsi_instruments", "lib/dsi_instruments", "editable"),
            ("pixhawk", "lib/pixhawk", "editable"),
            ("sat_tracker", "lib/sat_tracker", "editable"),
            (
                "serialptu",
                "lib/sat_tracker/lib/serialptu",
                "editable",
            ),
            ("signal_hound", "lib/signal_hound", "editable"),
            (
                "signal_hound_native_wrapper",
                "lib/signal_hound/lib",
                "standard",
            ),
        )

        self.assertEqual(actual, expected)
        self.assertEqual(
            profile.host_roles,
            ("controller", "pointing_controller", "rf_controller"),
        )
        self.assertEqual(self._instance_records(profile), ())
        self.assertEqual(
            self._service_records(profile),
            (
                (
                    "broker.activemq",
                    "activemq.service",
                    "system",
                    ("controller",),
                ),
                (
                    "power.pdu_hpa",
                    "cyberpower_pdu.service",
                    "satgs",
                    ("controller",),
                ),
                (
                    "rf.frontend",
                    "frontend.service",
                    "satgs",
                    ("rf_controller",),
                ),
                (
                    "pointing.ptu",
                    "ptu.service",
                    "satgs",
                    ("pointing_controller",),
                ),
                (
                    "pointing.pixhawk",
                    "pixhawk.service",
                    "satgs",
                    ("pointing_controller",),
                ),
                (
                    "rf.loopback",
                    "rf_loopback.service",
                    "satgs",
                    ("controller",),
                ),
                (
                    "recording.signal_hound_iq",
                    "sh_iq_logger.service",
                    "satgs",
                    ("controller",),
                ),
                (
                    "recording.signal_hound_trace",
                    "sh_trace_logger.service",
                    "satgs",
                    ("controller",),
                ),
                (
                    "orchestration.queue_manager",
                    "ground_station.service",
                    "satgs",
                    ("controller",),
                ),
            ),
        )
        self.assertEqual(
            self._capability_records(profile),
            (
                ("broker.activemq", "system", "included", True, True, ()),
                (
                    "orchestration.queue_manager",
                    "satgs",
                    "included",
                    True,
                    True,
                    (),
                ),
                ("execution.pass_runner", "satgs", "included", True, True, ()),
                ("orbit.pass_finder", "satgs", "included", True, True, ()),
                ("pointing.ptu", "satgs", "included", False, True, ()),
                (
                    "pointing.qpt130",
                    "station_hardware",
                    "included",
                    False,
                    True,
                    (),
                ),
                ("pointing.pixhawk", "satgs", "included", False, True, ()),
                (
                    "pointing.dual_gps",
                    "station_hardware",
                    "included",
                    False,
                    True,
                    (),
                ),
                ("time.ntp", "system", "included", True, True, ()),
                ("rf.frontend", "satgs", "included", False, True, ()),
                ("power.pdu_hpa", "satgs", "included", False, True, ()),
                (
                    "recording.signal_hound",
                    "satgs",
                    "included",
                    False,
                    True,
                    (),
                ),
                (
                    "processing.msel_post_processing",
                    "satgs",
                    "included",
                    False,
                    True,
                    (),
                ),
            ),
        )

    def test_full_msel_contract_rejects_missing_or_reordered_step(self):
        missing = self._manifest_data()
        self._profile(missing, "full_msel")["packages"].pop()

        reordered = self._manifest_data()
        packages = self._profile(reordered, "full_msel")["packages"]
        packages[0], packages[1] = packages[1], packages[0]

        for label, data in (("missing", missing), ("reordered", reordered)):
            with self.subTest(label=label):
                with self.assertRaisesRegex(
                    deployment.ManifestError, "canonical built-in contract"
                ):
                    deployment.load_manifest(self._write_manifest(data))

    def test_full_msel_contract_rejects_semantic_drift(self):
        cases = (
            (
                "host roles",
                lambda profile: profile["host_roles"].reverse(),
                "host roles",
            ),
            (
                "service provider",
                lambda profile: profile["services"][0].update(provider="satgs"),
                "service 'broker.activemq' field 'provider'",
            ),
            (
                "capability requirement",
                lambda profile: profile["capabilities"][4].update(
                    required_by_default=True
                ),
                "capability 'pointing.ptu' field 'required_by_default'",
            ),
        )

        for label, mutate, diagnostic in cases:
            with self.subTest(label=label):
                data = self._manifest_data()
                profile = self._profile(data, "full_msel")
                mutate(profile)
                with self.assertRaisesRegex(
                    deployment.ManifestError, diagnostic
                ):
                    deployment.load_manifest(self._write_manifest(data))

    def test_guided_arrow_contains_exact_approved_minimum(self):
        profile = deployment.resolve_profile("guided_arrow")

        self.assertEqual(
            tuple(
                (step.id, step.path, step.install_mode)
                for step in profile.packages
            ),
            (
                ("meteor-api", "lib/meteor-api", "editable"),
                ("ground_station", ".", "editable"),
                ("sat_tracker", "lib/sat_tracker", "editable"),
                (
                    "serialptu",
                    "lib/sat_tracker/lib/serialptu",
                    "editable",
                ),
                ("pixhawk", "lib/pixhawk", "editable"),
            ),
        )
        self.assertEqual(
            profile.host_roles,
            ("controller", "ptu", "pointing_observer"),
        )
        self.assertEqual(
            self._instance_records(profile),
            (
                ("ptu-1", "qpt130", "guided_arrow_hardware"),
                (
                    "pixhawk-1",
                    "pixhawk_dual_gps",
                    "guided_arrow_hardware",
                ),
            ),
        )
        self.assertEqual(
            self._service_records(profile),
            (
                (
                    "broker.activemq",
                    "activemq.service",
                    "system",
                    ("controller",),
                ),
                ("pointing.ptu", "ptu.service", "satgs", ("ptu",)),
                (
                    "pointing.pixhawk",
                    "pixhawk.service",
                    "satgs",
                    ("pointing_observer",),
                ),
                (
                    "orchestration.queue_manager",
                    "ground_station.service",
                    "satgs",
                    ("controller",),
                ),
            ),
        )
        self.assertEqual(
            self._capability_records(profile),
            (
                ("broker.activemq", "system", "included", True, True, ()),
                (
                    "orchestration.queue_manager",
                    "satgs",
                    "included",
                    True,
                    True,
                    (),
                ),
                ("execution.pass_runner", "satgs", "included", True, True, ()),
                ("orbit.pass_finder", "satgs", "included", True, True, ()),
                (
                    "pointing.ptu",
                    "satgs",
                    "included",
                    True,
                    True,
                    ("ptu-1",),
                ),
                (
                    "pointing.qpt130",
                    "guided_arrow_hardware",
                    "included",
                    True,
                    True,
                    ("ptu-1",),
                ),
                (
                    "pointing.pixhawk",
                    "satgs",
                    "included",
                    True,
                    True,
                    ("pixhawk-1",),
                ),
                (
                    "pointing.dual_gps",
                    "guided_arrow_hardware",
                    "included",
                    True,
                    True,
                    ("pixhawk-1",),
                ),
                ("time.ntp", "system", "included", True, True, ()),
                (
                    "network.connectivity",
                    "sponsor",
                    "external",
                    False,
                    False,
                    (),
                ),
                ("rf.frontend", "sponsor", "external", False, False, ()),
                ("power.pdu_hpa", "sponsor", "external", False, False, ()),
                (
                    "recording.signal_hound",
                    "sponsor",
                    "external",
                    False,
                    False,
                    (),
                ),
                (
                    "processing.msel_post_processing",
                    "sponsor",
                    "external",
                    False,
                    False,
                    (),
                ),
            ),
        )

    def test_guided_arrow_excludes_full_msel_components(self):
        profile = deployment.resolve_profile("guided_arrow")
        package_ids = frozenset(step.id for step in profile.packages)
        excluded = {
            "cyberpowerpdu",
            "dsi_instruments",
            "signal_hound",
            "signal_hound_native_wrapper",
            "msel_post_processing",
            "live_dashboard_be",
            "live_dashboard_fe",
        }

        self.assertTrue(package_ids.isdisjoint(excluded))
        external_capabilities = {
            capability.id
            for capability in profile.capabilities
            if capability.applicability == "external"
        }
        self.assertEqual(
            external_capabilities,
            {
                "network.connectivity",
                "rf.frontend",
                "power.pdu_hpa",
                "recording.signal_hound",
                "processing.msel_post_processing",
            },
        )

    def test_package_and_service_order_is_deterministic(self):
        first = deployment.resolve_profile("guided_arrow")
        second = deployment.resolve_profile("guided_arrow")

        self.assertEqual(first.packages, second.packages)
        self.assertEqual(first.services, second.services)
        self.assertEqual(
            deployment.render_plan(first),
            deployment.render_plan(second),
        )

    def test_guided_arrow_rendered_plan_is_exact(self):
        profile = deployment.resolve_profile("guided_arrow")
        expected = """Resolved profile: guided_arrow
Display name: Guided Arrow AIO
Apply support: not enabled in Slice 1
Host roles:
  01. controller
  02. ptu
  03. pointing_observer
Package plan:
  01. meteor-api | editable | lib/meteor-api
  02. ground_station | editable | .
  03. sat_tracker | editable | lib/sat_tracker
  04. serialptu | editable | lib/sat_tracker/lib/serialptu
  05. pixhawk | editable | lib/pixhawk
Planned services (not installed or started):
  01. broker.activemq | activemq.service | provider=system | host_roles=controller
  02. pointing.ptu | ptu.service | provider=satgs | host_roles=ptu
  03. pointing.pixhawk | pixhawk.service | provider=satgs | host_roles=pointing_observer
  04. orchestration.queue_manager | ground_station.service | provider=satgs | host_roles=controller
Capabilities (static installation intent only):
  01. broker.activemq | provider=system | applicability=included | supported=true | required_by_default=true | instances=none
  02. orchestration.queue_manager | provider=satgs | applicability=included | supported=true | required_by_default=true | instances=none
  03. execution.pass_runner | provider=satgs | applicability=included | supported=true | required_by_default=true | instances=none
  04. orbit.pass_finder | provider=satgs | applicability=included | supported=true | required_by_default=true | instances=none
  05. pointing.ptu | provider=satgs | applicability=included | supported=true | required_by_default=true | instances=ptu-1
  06. pointing.qpt130 | provider=guided_arrow_hardware | applicability=included | supported=true | required_by_default=true | instances=ptu-1
  07. pointing.pixhawk | provider=satgs | applicability=included | supported=true | required_by_default=true | instances=pixhawk-1
  08. pointing.dual_gps | provider=guided_arrow_hardware | applicability=included | supported=true | required_by_default=true | instances=pixhawk-1
  09. time.ntp | provider=system | applicability=included | supported=true | required_by_default=true | instances=none
  10. network.connectivity | provider=sponsor | applicability=external | supported=false | required_by_default=false | instances=none
  11. rf.frontend | provider=sponsor | applicability=external | supported=false | required_by_default=false | instances=none
  12. power.pdu_hpa | provider=sponsor | applicability=external | supported=false | required_by_default=false | instances=none
  13. recording.signal_hound | provider=sponsor | applicability=external | supported=false | required_by_default=false | instances=none
  14. processing.msel_post_processing | provider=sponsor | applicability=external | supported=false | required_by_default=false | instances=none
"""
        self.assertEqual(deployment.render_plan(profile), expected)

    def test_resolved_plan_is_immutable(self):
        profile = deployment.resolve_profile("guided_arrow")

        with self.assertRaises(FrozenInstanceError):
            profile.id = "full_msel"
        with self.assertRaises(FrozenInstanceError):
            profile.capabilities[0].supported = False
        with self.assertRaises(AttributeError):
            profile.services.append(profile.services[0])

    def test_duplicate_identifiers_are_rejected(self):
        for field in ("packages", "services", "capabilities"):
            with self.subTest(field=field):
                data = self._manifest_data()
                profile = self._profile(data, "guided_arrow")
                profile[field].append(copy.deepcopy(profile[field][0]))
                with self.assertRaisesRegex(deployment.ManifestError, "duplicate"):
                    deployment.load_manifest(self._write_manifest(data))

        data = self._manifest_data()
        profile = self._profile(data, "guided_arrow")
        profile["instances"].append(copy.deepcopy(profile["instances"][0]))
        with self.assertRaisesRegex(deployment.ManifestError, "duplicate"):
            deployment.load_manifest(self._write_manifest(data))

        data = self._manifest_data()
        data["profiles"].append(copy.deepcopy(data["profiles"][0]))
        with self.assertRaisesRegex(deployment.ManifestError, "duplicate"):
            deployment.load_manifest(self._write_manifest(data))

    def test_duplicate_json_keys_are_rejected(self):
        text = MANIFEST_PATH.read_text(encoding="utf-8")
        text = text.replace(
            '"schema_version": 1,',
            '"schema_version": 1, "schema_version": 1,',
            1,
        )
        temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(temporary_directory.cleanup)
        path = Path(temporary_directory.name) / "duplicate.json"
        path.write_text(text, encoding="utf-8")

        with self.assertRaisesRegex(deployment.ManifestError, "duplicate JSON key"):
            deployment.load_manifest(path)

    def test_malformed_capabilities_are_rejected(self):
        cases = []

        missing_provider = self._manifest_data()
        del self._profile(missing_provider, "guided_arrow")["capabilities"][0][
            "provider"
        ]
        cases.append(
            ("missing provider", missing_provider, "missing fields: 'provider'")
        )

        wrong_boolean = self._manifest_data()
        self._profile(wrong_boolean, "guided_arrow")["capabilities"][0][
            "required_by_default"
        ] = "true"
        cases.append(("wrong boolean", wrong_boolean, "must be a boolean"))

        contradictory = self._manifest_data()
        capability = self._profile(contradictory, "guided_arrow")["capabilities"][0]
        capability["applicability"] = "external"
        cases.append(("contradictory state", contradictory, "contradictory"))

        unknown_instance = self._manifest_data()
        self._profile(unknown_instance, "guided_arrow")["capabilities"][4][
            "instance_ids"
        ] = ["missing-1"]
        cases.append(("unknown instance", unknown_instance, "unknown instances"))

        unknown_provider = self._manifest_data()
        self._profile(unknown_provider, "guided_arrow")["capabilities"][0][
            "provider"
        ] = "unknown_provider"
        cases.append(("unknown provider", unknown_provider, "must be one of"))

        for label, data, diagnostic in cases:
            with self.subTest(label=label):
                with self.assertRaisesRegex(
                    deployment.ManifestError, diagnostic
                ):
                    deployment.load_manifest(self._write_manifest(data))

    def test_representative_malformed_shapes_are_rejected(self):
        malformed_object = self._manifest_data()
        self._profile(malformed_object, "guided_arrow")["services"][0] = []

        malformed_list = self._manifest_data()
        self._profile(malformed_list, "guided_arrow")["capabilities"][0][
            "instance_ids"
        ] = {}

        malformed_string = self._manifest_data()
        self._profile(malformed_string, "guided_arrow")["display_name"] = 7

        malformed_boolean = self._manifest_data()
        self._profile(malformed_boolean, "guided_arrow")["apply_supported"] = 0

        malformed_identifier = self._manifest_data()
        self._profile(malformed_identifier, "guided_arrow")["host_roles"][
            0
        ] = "Controller Role"

        cases = (
            ("object", malformed_object, "must be an object"),
            ("list", malformed_list, "must be a list"),
            ("string", malformed_string, "must be a non-empty string"),
            ("boolean", malformed_boolean, "must be a boolean"),
            ("identifier", malformed_identifier, "valid stable identifier"),
        )

        for label, data, diagnostic in cases:
            with self.subTest(label=label):
                with self.assertRaisesRegex(
                    deployment.ManifestError, diagnostic
                ):
                    deployment.load_manifest(self._write_manifest(data))

    def test_capability_ownership_contradictions_are_rejected(self):
        cases = []

        included_unsupported = self._manifest_data()
        self._item(
            self._profile(included_unsupported, "full_msel"),
            "capabilities",
            "pointing.ptu",
        )["supported"] = False
        cases.append(
            (
                "included unsupported",
                included_unsupported,
                "included capabilities must be supported",
            )
        )

        sponsor_included = self._manifest_data()
        self._item(
            self._profile(sponsor_included, "guided_arrow"),
            "capabilities",
            "execution.pass_runner",
        )["provider"] = "sponsor"
        cases.append(
            (
                "sponsor included",
                sponsor_included,
                "sponsor-provided capability cannot be locally included",
            )
        )

        external_non_sponsor = self._manifest_data()
        self._item(
            self._profile(external_non_sponsor, "guided_arrow"),
            "capabilities",
            "rf.frontend",
        )["provider"] = "satgs"
        cases.append(
            (
                "external non-sponsor",
                external_non_sponsor,
                "external capability must use the sponsor provider",
            )
        )

        for label, data, diagnostic in cases:
            with self.subTest(label=label):
                with self.assertRaisesRegex(
                    deployment.ManifestError, diagnostic
                ):
                    deployment.load_manifest(self._write_manifest(data))

    def test_unsafe_package_paths_are_rejected(self):
        for path in ("/tmp/meteor-api", "../meteor-api", r"lib\\meteor-api"):
            with self.subTest(path=path):
                data = self._manifest_data()
                profile = self._profile(data, "guided_arrow")
                profile["packages"][0]["path"] = path
                with self.assertRaisesRegex(
                    deployment.ManifestError, "repository-relative"
                ):
                    deployment.load_manifest(self._write_manifest(data))

    def test_guided_arrow_semantic_mutations_are_rejected(self):
        def capability_update(capability_id, **changes):
            return lambda profile: self._item(
                profile, "capabilities", capability_id
            ).update(changes)

        cases = (
            (
                "active mq provider",
                capability_update("broker.activemq", provider="sponsor"),
                "sponsor-provided capability cannot be locally included",
            ),
            (
                "queue manager provider",
                capability_update(
                    "orchestration.queue_manager", provider="system"
                ),
                "capability 'orchestration.queue_manager' field 'provider'",
            ),
            (
                "qpt provider",
                capability_update("pointing.qpt130", provider="satgs"),
                "capability 'pointing.qpt130' field 'provider'",
            ),
            (
                "pixhawk provider",
                capability_update(
                    "pointing.pixhawk",
                    provider="guided_arrow_hardware",
                ),
                "capability 'pointing.pixhawk' field 'provider'",
            ),
            (
                "required qpt instance removed",
                lambda profile: profile["instances"].pop(0),
                "unknown instances",
            ),
            (
                "required pixhawk instance removed",
                lambda profile: profile["instances"].pop(1),
                "unknown instances",
            ),
            (
                "required instance id replaced",
                lambda profile: profile["instances"][0].update(id="ptu-2"),
                "unknown instances",
            ),
            (
                "ntp made optional",
                capability_update("time.ntp", required_by_default=False),
                "capability 'time.ntp' field 'required_by_default'",
            ),
            (
                "ntp removed",
                lambda profile: self._remove_item(
                    profile, "capabilities", "time.ntp"
                ),
                "capability identifiers and order",
            ),
            (
                "rf made satgs owned",
                capability_update("rf.frontend", provider="satgs"),
                "external capability must use the sponsor provider",
            ),
            (
                "rf made included",
                capability_update(
                    "rf.frontend",
                    applicability="included",
                    supported=True,
                ),
                "sponsor-provided capability cannot be locally included",
            ),
            (
                "network removed",
                lambda profile: self._remove_item(
                    profile, "capabilities", "network.connectivity"
                ),
                "capability identifiers and order",
            ),
            (
                "network made satgs installed",
                capability_update(
                    "network.connectivity",
                    provider="satgs",
                    applicability="included",
                    supported=True,
                ),
                "capability 'network.connectivity' field 'provider'",
            ),
            (
                "excluded package added",
                lambda profile: profile["packages"].append(
                    {
                        "id": "dsi_instruments",
                        "path": "lib/dsi_instruments",
                        "install_mode": "editable",
                    }
                ),
                "package plan",
            ),
            (
                "excluded service added",
                lambda profile: profile["services"].append(
                    {
                        "id": "power.pdu_hpa",
                        "unit": "cyberpower_pdu.service",
                        "provider": "satgs",
                        "host_roles": ["controller"],
                    }
                ),
                "service identifiers and order",
            ),
            (
                "contradictory required support",
                capability_update("broker.activemq", supported=False),
                "included capabilities must be supported",
            ),
            (
                "host roles changed",
                lambda profile: profile["host_roles"].reverse(),
                "host roles",
            ),
            (
                "instance component changed",
                lambda profile: profile["instances"][0].update(
                    component="pixhawk_dual_gps"
                ),
                "instance 'ptu-1' field 'component'",
            ),
            (
                "instance order changed",
                lambda profile: profile["instances"].reverse(),
                "instance identifiers and order",
            ),
            (
                "service provider changed",
                lambda profile: profile["services"][1].update(
                    provider="sponsor"
                ),
                "service 'pointing.ptu' field 'provider'",
            ),
            (
                "service role changed",
                lambda profile: profile["services"][1].update(
                    host_roles=["controller"]
                ),
                "service 'pointing.ptu' field 'host_roles'",
            ),
            (
                "capability order changed",
                lambda profile: profile["capabilities"].reverse(),
                "capability identifiers and order",
            ),
            (
                "external supported state changed",
                capability_update("rf.frontend", supported=True),
                "capability 'rf.frontend' field 'supported'",
            ),
        )

        for label, mutate, diagnostic in cases:
            with self.subTest(label=label):
                data = self._manifest_data()
                profile = self._profile(data, "guided_arrow")
                mutate(profile)
                with self.assertRaisesRegex(
                    deployment.ManifestError, diagnostic
                ) as context:
                    deployment.load_manifest(self._write_manifest(data))
                self.assertIn("profile 'guided_arrow'", str(context.exception))

        for collection in ("capabilities", "instances"):
            with self.subTest(label=f"duplicate {collection}"):
                data = self._manifest_data()
                profile = self._profile(data, "guided_arrow")
                profile[collection].append(copy.deepcopy(profile[collection][0]))
                with self.assertRaisesRegex(
                    deployment.ManifestError, "duplicate"
                ) as context:
                    deployment.load_manifest(self._write_manifest(data))
                self.assertIn("profile 'guided_arrow'", str(context.exception))

    def test_runtime_evidence_fields_are_rejected(self):
        for field in (
            "available",
            "completed",
            "connected",
            "healthy",
            "ready",
            "synchronized",
        ):
            with self.subTest(field=field):
                data = self._manifest_data()
                profile = self._profile(data, "guided_arrow")
                profile["capabilities"][0][field] = True
                with self.assertRaisesRegex(
                    deployment.ManifestError, "unknown fields"
                ) as context:
                    deployment.load_manifest(self._write_manifest(data))
                message = str(context.exception)
                self.assertIn("profile 'guided_arrow'", message)
                self.assertIn(repr(field), message)

    def test_control_characters_and_invalid_utf8_are_rejected(self):
        data = self._manifest_data()
        self._profile(data, "guided_arrow")["display_name"] = "Guided\x1bArrow"
        with self.assertRaisesRegex(deployment.ManifestError, "control character"):
            deployment.load_manifest(self._write_manifest(data))

        temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(temporary_directory.cleanup)
        path = Path(temporary_directory.name) / "invalid-utf8.json"
        path.write_bytes(b"\xff")
        with self.assertRaisesRegex(deployment.ManifestError, "cannot read"):
            deployment.load_manifest(path)

    def test_manifest_size_limit_is_enforced(self):
        payload = MANIFEST_PATH.read_bytes()
        self.assertLess(len(payload), deployment._MAX_MANIFEST_BYTES)

        exact = payload + b" " * (
            deployment._MAX_MANIFEST_BYTES - len(payload)
        )
        exact_path = self._write_manifest_bytes(exact)
        manifest = deployment.load_manifest(exact_path)
        self.assertEqual(manifest.schema_version, deployment.SCHEMA_VERSION)

        oversized_path = self._write_manifest_bytes(exact + b" ")
        with self.assertRaisesRegex(deployment.ManifestError, "exceeds"):
            deployment.load_manifest(oversized_path)

    def test_non_regular_manifest_paths_are_rejected_before_open(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            fifo_path = root / "manifest.fifo"
            os.mkfifo(fifo_path)
            symlink_path = root / "manifest-link.json"
            symlink_path.symlink_to(MANIFEST_PATH)

            cases = (
                ("device", Path(os.devnull)),
                ("fifo", fifo_path),
                ("symlink", symlink_path),
            )
            for label, path in cases:
                with self.subTest(label=label):
                    with mock.patch(
                        "builtins.open",
                        side_effect=AssertionError("non-regular path was opened"),
                    ), mock.patch.object(
                        Path,
                        "open",
                        side_effect=AssertionError("non-regular path was opened"),
                    ):
                        with self.assertRaisesRegex(
                            deployment.ManifestError, "regular file"
                        ):
                            deployment.load_manifest(path)

    def test_json_parser_limit_errors_are_translated(self):
        for error in (RecursionError(), ValueError("integer limit")):
            with self.subTest(error=type(error).__name__):
                with mock.patch.object(
                    deployment.json, "loads", side_effect=error
                ):
                    with self.assertRaisesRegex(
                        deployment.ManifestError,
                        "value or nesting limit exceeded",
                    ):
                        deployment.load_manifest(MANIFEST_PATH)

    def test_diagnostics_escape_unknown_keys_and_custom_paths(self):
        data = self._manifest_data()
        data["bad\nkey\x1b[2J"] = True
        with self.assertRaises(deployment.ManifestError) as context:
            deployment.load_manifest(self._write_manifest(data))
        message = str(context.exception)
        self.assertNotIn("\n", message)
        self.assertNotIn("\x1b", message)
        self.assertIn("\\n", message)
        self.assertIn("\\x1b", message)

        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "bad\npath\x1b[2J.json"
            with self.assertRaises(deployment.ManifestError) as context:
                deployment.load_manifest(path)
        message = str(context.exception)
        self.assertNotIn("\n", message)
        self.assertNotIn("\x1b", message)
        self.assertIn("\\n", message)
        self.assertIn("\\x1b", message)

    def test_static_capabilities_contain_no_runtime_health_assertion(self):
        forbidden = {
            "available",
            "broker_ready",
            "completed",
            "connected",
            "device_health",
            "gps_valid",
            "health",
            "healthy",
            "installed",
            "job_ready",
            "observed_at",
            "ptu_complete",
            "ready",
            "synchronized",
            "time_synchronized",
        }
        data = self._manifest_data()

        def keys(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    yield key
                    yield from keys(child)
            elif isinstance(value, list):
                for child in value:
                    yield from keys(child)

        self.assertTrue(forbidden.isdisjoint(keys(data)))

        capability = self._profile(data, "guided_arrow")["capabilities"][0]
        capability["healthy"] = True
        with self.assertRaisesRegex(deployment.ManifestError, "unknown fields"):
            deployment.load_manifest(self._write_manifest(data))

    def test_resolver_imports_no_optional_or_hardware_package(self):
        code = """
import builtins
import os
import sys

sys.path.append(sys.argv[1])

write_flags = (
    os.O_WRONLY
    | os.O_RDWR
    | os.O_APPEND
    | os.O_CREAT
    | os.O_TRUNC
)

filesystem_mutation_events = {
    "os.chdir",
    "os.chmod",
    "os.chown",
    "os.fchmod",
    "os.fchown",
    "os.lchown",
    "os.link",
    "os.mkdir",
    "os.mkfifo",
    "os.mknod",
    "os.remove",
    "os.removexattr",
    "os.rename",
    "os.replace",
    "os.rmdir",
    "os.setxattr",
    "os.symlink",
    "os.truncate",
    "os.utime",
}
process_events = {
    "os.fork",
    "os.forkpty",
    "os.kill",
    "os.killpg",
    "os.posix_spawn",
    "os.startfile",
    "os.system",
    "subprocess.Popen",
}
blocked_read_roots = ("/dev", "/proc", "/sys")

def audit(event, args):
    if event == "open":
        path = args[0]
        mode = args[1]
        flags = args[2]
        if isinstance(mode, str) and any(value in mode for value in "wax+"):
            raise AssertionError(f"blocked file-write mode: {mode}")
        if isinstance(flags, int) and flags & write_flags:
            raise AssertionError(f"blocked file-write flags: {flags}")
        try:
            resolved_path = os.path.realpath(os.fsdecode(path))
        except TypeError:
            resolved_path = None
        if resolved_path is not None and any(
            resolved_path == root or resolved_path.startswith(root + "/")
            for root in blocked_read_roots
        ):
            raise AssertionError("blocked device or pseudo-filesystem access")
    if (
        event.startswith("socket.")
        or event.startswith("os.exec")
        or event.startswith("os.spawn")
        or event in filesystem_mutation_events
        or event in process_events
        or event in {"os.putenv", "os.unsetenv"}
    ):
        raise AssertionError(f"blocked side effect: {event}")

sys.addaudithook(audit)

allowed_deployment_imports = {
    "__future__",
    "argparse",
    "collections",
    "dataclasses",
    "json",
    "os",
    "pathlib",
    "re",
    "stat",
    "sys",
    "typing",
}
allowed_project_imports = {"satgs", "satgs.deployment"}
original_import = builtins.__import__

def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    root = name.split(".", 1)[0]
    caller_globals = globals
    if caller_globals is None:
        caller_globals = sys._getframe(1).f_globals
    caller = caller_globals.get("__name__")
    if caller == "satgs.deployment" and (
        level != 0 or root not in allowed_deployment_imports
    ):
        raise AssertionError(f"blocked resolver import: {name}")
    if level == 0 and root != "satgs" and root not in sys.stdlib_module_names:
        raise AssertionError(f"blocked non-standard import: {name}")
    if root == "satgs" and (
        name not in allowed_project_imports
        or any(item != "deployment" for item in (fromlist or ()))
    ):
        raise AssertionError(f"blocked project import: {name}")
    return original_import(name, globals, locals, fromlist, level)

builtins.__import__ = guarded_import
from satgs import deployment
deployment.resolve_profile("guided_arrow")
"""
        result = subprocess.run(
            [
                sys.executable,
                "-I",
                "-S",
                "-B",
                "-c",
                code,
                str(REPOSITORY_ROOT / "src"),
            ],
            cwd=tempfile.gettempdir(),
            env={},
            stdin=subprocess.DEVNULL,
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )

        self.assertEqual(result.returncode, 0, result.stderr)

    def test_manifest_loading_does_not_depend_on_current_working_directory(self):
        original_directory = Path.cwd()
        with tempfile.TemporaryDirectory() as temporary_directory:
            try:
                os.chdir(temporary_directory)
                profile = deployment.resolve_profile("guided_arrow")
            finally:
                os.chdir(original_directory)

        self.assertEqual(profile.id, "guided_arrow")


if __name__ == "__main__":
    unittest.main()
