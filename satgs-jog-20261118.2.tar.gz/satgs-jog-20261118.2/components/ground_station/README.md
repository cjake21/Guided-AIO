# Ground Station Control

## Development package boundaries

Build wheels from complete sources after explicitly generating `jobs_msg_pb2.py`
from the unchanged `src/satgs/jobs_msg.proto`. The build fails if the generated
module is absent. Generation tools are build-only; installed clients do not
need a compiler. The common development protobuf runtime is `6.33.6`, with
Python 3.10 or newer required by this package. Target qualification is separate.

The wheel includes the canonical `config/deployment_profiles.json` as
`satgs/data/deployment_profiles.json`. Installed default resolution uses that
resource and fails if it is missing; an explicit manifest path still uses the
same bounded reader. Source-checkout execution uses the canonical input.

`satgs[pointing]` selects the PTU and Pixhawk clients. Local managers are separate
owner extras, not dependencies of an externally supplied manager. `plotting`
and `frontend` select their optional libraries; `full` preserves both for the
existing Full M-SEL installer. Tracking retains its actual scientific dependencies.
The Full M-SEL package order and apply guards are unchanged, with explicit
Meteor ZMQ and PTU/Pixhawk manager extras. Legacy PTU test mode still uses the
PTU client; `noptu` is not a promise that the client package is unnecessary.

These development metadata changes do not activate owner releases, alter the
QPT130-only Pelican selection, qualify navigation, or establish physical completion.

This repository provides profile-aware setup for the ground station control
software. Full M-SEL apply copies the legacy configuration templates and
installs the legacy Python package set. Guided Arrow Slice 1 validates and
prints a static deployment plan only. Service installation and activation are
separate operator tasks.

Refer to the microservice repositories for component-specific setup.

Specifically, this package is for managing the queue of jobs (satellite passes), and the procedure for executing a job (tracking a satellite pass in the queue) at its start time.

# Installation Guide

## Host Preparation
1. Ensure you've got a time server / NTP setup between primary and peripheral controllers. For new NTP clients:
```
sudo apt update
sudo apt install chrony

sudo nano /etc/chrony/chrony.conf

# Add MITREs time servers to your chrony.conf file
#  or use your own time server if you have a local source
#  Add the NTP server with the following line:
server <hostname>.<your_domain> iburst

# Save close
# Restart chrony service 
sudo systemctl restart chrony

# Verify host is successfully getting NTP time from your specified server
chronyc sources
# and ensure "NTP service" says active
timedatectl
```

Configuring an NTP server is outside the scope of this readme.   
[This is a pretty good guide.](https://austinsnerdythings.com/2025/02/14/revisiting-microsecond-accurate-ntp-for-raspberry-pi-with-gps-pps-in-2025/)

The deployment profile's `time.ntp` capability records that synchronized time
is required for scheduling. Slice 1 does not select a time source, install or
configure Chrony, or prove synchronization. The commands above are manual host
preparation.

2. Install MITRE certs if reliant on MITRE network for Internet connectivity.
3. Setup Active MQ. Follow [instructions here](./docs/activemq_setup.md)
4. This project uses Box to keep result artifacts in sync across the team. This is an optional feature, and is set to `false` by default.
  - The `box-api-sync` package is available via MITRE Artifactory. Point pip at it to pip install it as an optional dependency.
  - Set `box_connectivity: true` in your `~/ground_station/config/config.yaml` in such cases.

## Ground Station Software & its Microservices

1. Clone the repository.

```text
# Clone in the SATGS runtime account's home directory
git clone ssh://git@git.codev.mitre.org/satgs/ground_station.git
cd ground_station
```

Full M-SEL apply requires the complete legacy submodule tree:

```text
git submodule update --init --recursive
```

Guided Arrow Slice 1 dry-run does not require initialized submodules. Selective
submodule initialization and Guided Arrow apply remain later-slice work.

2. Create log directories for the approved SATGS runtime account. Run these
commands as that account. The `/opt` log directory is owned by that account's
user and primary group without changing permissions on the rest of the tree.

```text
sudo install -d -o "$(id -un)" -g "$(id -gn)" -m 0750 /opt/ground_station/logs
install -d -m 0700 "$HOME/logs"
```

If another approved account needs log access, assign a dedicated group and the
minimum group permissions required by the deployment. Do not recursively relax
permissions on `/opt/ground_station` or the runtime account's home.

3. Install protobuf compiler
```
sudo apt install -y protobuf-compiler
```

This software suite uses protocol buffers as a vendor- and software-agnostic approach for defining messages and their contents.
Read more about how this works [here](https://protobuf.dev/getting-started/pythontutorial/).  
A brief description of how this project uses it:
  - `protoc`, the name of the protobuf compiler program, is used to compile the various `.proto` files found in this project.
  - The result of compilation are `.py` files, i.e., `jobs_msg_pb2.py`.
  - These modules are then imported similarly to any other Python module, and its functions are used when creating a message to be sent or interpreting a received message.
  - ActiveMQ & the METEOR API handle the actual messaging, topics, publishing and subscribing.

The following are historical reported configurations, not qualification of the
current development package requirements:

| Host OS         | protoc version     | python protobuf version |
| --------------- | ------------------ | ----------------------- |
| Ubuntu 22.04    | libprotoc 3.12.4   | 3.20.1 |
| Ubuntu 24.04    | libprotoc 3.21.12  | 6.30.0 |
| Debian Bookworm | libprotoc 3.21.12  | 3.20.1+ |

Do not infer the current development compiler/runtime pair from the system's
`protoc`. The isolated build selects protoc 33.6 and protobuf 6.33.6, with artifact
hashes verified before use. Runtime installations use pregenerated modules and
do not install the compiler. This selection does not qualify an older host OS.

See [this](https://protobuf.dev/news/2022-05-06/#python-updates) for more information.

4. Create virtual environment
```
cd ground_station
python3 -m venv .env
source .env/bin/activate
```

Before a clean-checkout Full M-SEL editable install, explicitly prepare the four
generated modules with the verified build-only compiler. From `ground_station`,
with the real complete owner checkouts at their existing `lib/` locations:

```bash
build_protoc=/absolute/path/to/verified/protoc-33.6/bin/protoc
build_include=/absolute/path/to/verified/protoc-33.6/include
"$build_protoc" --version
"$build_protoc" -I src/satgs --python_out=src/satgs src/satgs/jobs_msg.proto
"$build_protoc" -I lib/meteor-api/src/meteor_api/protobufs --python_out=lib/meteor-api/src/meteor_api/protobufs lib/meteor-api/src/meteor_api/protobufs/Meteor.proto
"$build_protoc" -I lib/sat_tracker/src/ptu_control -I "$build_include" --python_out=lib/sat_tracker/src/ptu_control lib/sat_tracker/src/ptu_control/ptu_msg.proto
"$build_protoc" -I lib/pixhawk/src/pixhawk --python_out=lib/pixhawk/src/pixhawk lib/pixhawk/src/pixhawk/pixhawk.proto
```

Require the version output `libprotoc 33.6` and successful completion of every
selected generation command before installing. Do not overwrite independently
maintained generated files without reviewing their provenance. Isolated wheel
builds run these same generation steps against complete staging copies instead
of modifying checkouts. A missing owner checkout or failed generation is a
build prerequisite failure, not permission to fabricate modules or install a
partial package. This preparation does not contact a broker or start managers.

5. Select a deployment profile

```bash
./build.sh --dry-run
```

In an interactive terminal, this prompts before any installation step. Full
M-SEL apply remains available. Guided Arrow supports dry-run planning only in
Slice 1.

## Deployment Profiles

`build.sh` supports two stable deployment profile identifiers:

- `full_msel` preserves the existing complete M-SEL package installation.
- `guided_arrow` describes the Guided Arrow all-in-one minimum.

Both `./build.sh` and `./build.sh --dry-run` prompt in an interactive terminal
before any installation step. Selection happens before the dry-run or guarded
apply path:

```text
1. Full M-SEL
2. Guided Arrow AIO
```

Blank input or `1` selects Full M-SEL. Input `2` selects Guided Arrow AIO.
Invalid input is retried at most three times, then exits with a selection
error. Passing an explicit `--profile` bypasses the prompt:

```bash
./build.sh --profile full_msel
./build.sh --profile guided_arrow --dry-run
```

For automation, `--non-interactive` requires an explicit `--profile` and
never prompts:

```bash
./build.sh --non-interactive --profile full_msel
./build.sh --non-interactive --profile guided_arrow --dry-run
```

During the compatibility period, when no `--profile` is supplied, standard
input is not a TTY, and `--non-interactive` was not supplied, both `./build.sh`
and `./build.sh --dry-run` select `full_msel`. They print a warning that
recommends explicit `--profile full_msel`. A `--non-interactive` invocation
without an explicit profile exits with status 2 before any effect, including
when `--dry-run` is present.

Use dry-run mode to inspect the ordered package, planned service, and capability
data:

```bash
./build.sh --dry-run
./build.sh --profile full_msel --dry-run
./build.sh --profile guided_arrow --dry-run
```

A dry run reads static installation intent only. It does not copy files, change
permissions, initialize submodules, install packages, start services, open
devices, or contact a broker. It does not establish whether a package is
installed or whether a device, GPS source, PTU, broker, clock, or job is ready
or healthy.

The `controller`, `ptu`, and `pointing_observer` values are logical roles in
the Guided Arrow all-in-one plan. Component instance identifiers describe
intended configuration. They do not prove discovery, connectivity,
availability, or health.

The Guided Arrow package plan contains:

- `meteor-api` at `lib/meteor-api`
- `ground_station` at the repository root
- `sat_tracker` at `lib/sat_tracker`
- `serialptu` at `lib/sat_tracker/lib/serialptu`
- `pixhawk` at `lib/pixhawk`

Its planned services are Apache ActiveMQ, PTU, Pixhawk, and the Ground Station
queue manager. These are installation-intent records. Slice 1 does not generate,
install, enable, start, or validate systemd units.

The Guided Arrow package plan excludes `dsi_instruments`, `cyberpowerpdu`,
Signal Hound and its native wrapper, `msel_post_processing`, and the dashboard
pair. Static external capability records mark sponsor-provided RF frontend and
processing (`rf.frontend`), field power (`power.pdu_hpa`), network appliances
or connectivity (`network.connectivity`), scientific recording and
instrumentation (`recording.signal_hound`), and experiment-specific processing
(`processing.msel_post_processing`). These records identify ownership and
installation scope only. They do not assert that a sponsor resource is
installed, available, connected, healthy, ready, or synchronized. In particular,
`network.connectivity` defines no topology, endpoint, reachability, readiness,
or NTP transport guarantee.

Guided Arrow apply mode is not enabled in Slice 1. Invoking
`./build.sh --profile guided_arrow` without `--dry-run` exits before any install,
service, broker, or device action. Full M-SEL apply retains the existing copy
conditions and package installation order, but stops at the first failed copy
or package installation. Earlier completed steps are not rolled back. Service
installation and activation remain separate operator actions.

Successful help, validation, and dry runs exit 0. Argument, selection, profile,
or manifest errors exit 2. Guided Arrow's intentionally unsupported apply exits
3. A Full M-SEL copy or install failure propagates that command's nonzero
status; earlier successful operations are not rolled back.

Later approved slices will add capability-aware QueueManager and PassRunner
behavior; repair and validate the PTU command and motion lifecycle; add Pixhawk
and dual-GPS health evidence; harden ActiveMQ and systemd deployment; and
validate the supported Raspberry Pi image, installation, and operations model.
Sponsor execution and runtime RF, power, network, instrument, broker, time, and
device evidence remain outside Slice 1.

## Initial SATGS Configuration

1. A template sat_db.csv and config.yaml file have been provided [here](https://git.codev.mitre.org/projects/SATGS/repos/ground_station/browse/config).
During Full M-SEL apply, `build.sh` creates `config/config.yaml` and
`config/sat_db.csv` from those templates only when the destination files do
not exist. Dry-run and Guided Arrow Slice 1 do not create them. Customize the
created files appropriately.

2. Customize your config.yaml appropriately:

  - Set your ground station lat, long, alt. This is the location `pass_finder` will use to find sat passes passing over this location.
  - If you plan to use Box for syncing files, `box_connectivity: true`. Its optional.
  - The Pixhawk section is numbered and is used to assign Pixhawks to different PTU assembly. Use one entry, with an ID of 1 for a single PTU assembly setup.
  - The PTU section relates to your PTU setup: set the baud rate and friendly name here. 
    - Supported types: QPT-130, QPT-200, QPT-500
    - Supported protocols: PTCR96, PTCR20
    - If your PTU has Continuous Rotation, set `cont_rot` to True.
    - Your No-Go PTU config `nogozones.yaml` should be placed in the `~/ground_station/lib/sat_tracker` subdir. These are the zones your antenna should NOT point.

3. Customize your sat_db.csv appropriately:

  - You can either: 
    - Use the commands `add_tle <norad_id>` and `del_tle <norad_id>` which will fetch and store the current TLE from Celestrak or delete a TLE from the db, respectively.
    - Manually enter TLEs if you know them or delete them

4. Finally, use `pass_finder --sids <your_norad_ids> --d <days> --elmask <elevation_mask>` to update all the TLEs.

  - `days` represents the span of days to look for passes over.
  - `elevation_mask` is to filter out passes whose max elevation falls below this number, i.e. `--elmask 20` would not show any passes under 20degrees max elevation.

5. If you're using the MSEL SATGS peripherals, visit each microservice lib and customize the various configuration files. Visit those repos for specific guidance.
Otherwise, you're free to start adding jobs to the queue via the `add_pass` command.


## Optional Configurations

### Install Shared Objects (.so) for Signal Hound BB Series Device

If you'll be using the Signal Hound devices, you'll need to grab shared object (.so) files from SignalHound in order to interface with the hardware.
These files:
  - libbb_api.so
  - libftd2xx.so   

Can be found in the Signal Hound SDK [here](https://signalhound.com/software/signal-hound-software-development-kit-sdk).

Once downloaded:
```
# Assuming they're in the home dir, copy them into /usr/local/lib
cp ~/libbb_api.so.5 ~/libftd2xx.so /usr/local/lib/.

# Creating symlinks in the bbdevice lib subdir
ln -s /usr/local/lib/libbb_api.so.5 /home/$USER/ground_station/lib/signal_hound/lib/bbdevice/libbb_api.so
ln -s /usr/local/lib/libftd2xx.so /home/$USER/ground_station/lib/signal_hound/lib/bbdevice/libftd2xx.so
```

### Setup Crontab File

This project collects a ton of data per pass, especially if IQ recording is enabled.  
To manage the host resources, modify, rename and install the [crontab example file](https://git.codev.mitre.org/projects/SATGS/repos/ground_station/browse/etc/scripts/cronjobs/crontab.example) via the following instructions.

Refer to the [cronjobs folder](https://git.codev.mitre.org/projects/SATGS/repos/ground_station/browse/etc/scripts/cronjobs) to learn more about the scheduled tasks available for use.

```
# Add your own cronjobs and edit job timing if desired
nano ~/ground_station/etc/scripts/cronjobs/crontab.example

# Option 1: Use crontab -e to modify your user crontab file
# Copy the cronjobs from crontab.example file into your crontab file with the following command
#  If run for the first time, select your text editor first
crontab -e

# Option 2: Create your own crontab file from the template
#  Then avoid using crontab -e in the future; this new file is the new source for cron moving forward
#  WARNING: This will overwrite your current crontab file! Ensure its backed up

# 2a. Make your own file
cp ~/ground_station/etc/scripts/cronjobs/crontab.example ~/my_new_crontab_file

# 2b. Create backup of original crontab file
crontab -l > ~/user_crontab.backup

# 2c. Install the new crontab file
crontab ~/my_new_crontab_file

# Note: In the event you update or edit your crontab file after this point, reinstall it using the command above

# In both cases, verify your cronjobs were installed properly
crontab -l

```

# Setting Up Ground Station as a Service
Generally, the Ground Station package will want to be run in the background, i.e., as a service instead of being invoked by the user.
Systemd service template files have been provided [in this repo](./etc/systemd/ground_station.service) and each microservice repo with recommended settings.

1. Edit the service files with the appropriate $USER and path to ground station config files.
2. Copy them to /etc/systemd/system directory.
3. When ready, do:
```
sudo systemctl daemon-reload
# Start service on system boot if desired
sudo systemctl enable <service_name>
sudo systemctl start <service_name>

# Check status for graceful start
sudo systemctl status <service_name>
```

## Troubleshooting the Services
The ground station can be installed in a "no hardware" mode, when physical hardware is not available or for software development purposes.
In this case, append the --nohw flag to the service ExecStart line.
These services support no hardware mode:
- pixhawk.service
- ptu.service
- frontend.service
- `cyberpower_pdu.service`

For Pixhawk & PTU services, ensure the service file is referring to the correct serial port, i.e., /dev/ttyACM0 or /dev/ttyUSB0 or similar.
To enumerate your currently connected serial devices, use command:
```
ls -al /dev/serial/by-id
# or
ls -al /dev/serial/by-path
```
Recall that moving a device from USB port 1 to USB port 2 will cause the logical port to change, i.e., /dev/ttyUSB0 will change to /dev/ttyUSB1.

## Shared Planner/CLI (planning only)

This headless interface uses only the Python standard library and the existing
validated deployment manifest. It does not change `build.sh` or its exit statuses.
It supports the repository's Python 3.10+ baseline. No desktop wizard, installer
executor, service action, device discovery, or supported apply command is included.

From the repository root:

```bash
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD/src"
python3 -m satgs.deployment_cli --help
python3 -m satgs.deployment_cli catalog --format json
python3 -m satgs.deployment_cli plan --preset guided_arrow --format json
python3 -m satgs.deployment_cli plan --preset full_msel
```

Exit 0 means valid rendering/selection preview, not an executable installation
plan. Exit 2 means invalid arguments or input. Exit 3 means blocking selection,
dependency, or compatibility conflicts. Every plan has `planning_only: true`,
`apply_supported: false`, and `complete: false`. JSON mode writes one JSON document
without banners. Human output carries the same selection and diagnostic meaning.

The Guided Arrow command above exits 3: the unchanged QueueManager still requires
local IQ recording and post-processing. External sponsor responsibility is not a
connector satisfying those requirements. PassRunner's
DSI, CyberPowerPDU, and Signal Hound imports are now conditional on the applicable
legacy operation. The plan preserves canonical packages, sponsor responsibilities,
and device instances, without adding the excluded stack or claiming queued
pointing readiness. Full M-SEL remains an incomplete
preview with exit 0. The legacy `build.sh` dry-run and apply guard are unchanged.

The shared API in `satgs.deployment_plan` is independent of the CLI:

- `build_catalog(load_manifest())` projects existing validated, frozen records.
- `expand_preset(catalog, preset)` creates explicit, serializable selections.
- `parse_configuration(data, catalog)`, `parse_inventory(data, catalog)`, and
  `parse_requirements(data, catalog)` validate supplied version-1 documents.
- `validate_document_structure(data)` applies the same decoded-document limits
  for those parsers and the CLI without changing the supplied document.
- `plan_configuration(configuration, catalog, inventory=None, requirements=None)`
  resolves selection prerequisites without changing the configuration.
- `compare_release(configuration, catalog, requirements, inventory=None)` previews
  candidate requirements without changing selections or device identities.
- Each record has `to_dict()`, returning a defensive copy. `render_json(record)`
  and `render_human(record)` are shared renderers; plan results expose `blocked`.

Records are immutable canonical JSON snapshots. Callers should use the parsing
functions, not construct record storage directly. Preset identity, configuration
schema/revision, current release identity, candidate release identity, target,
and supplied inventory are separate fields. Re-expansion is explicit, never an
automatic response to updated preset defaults. `preset: null` denotes Custom;
Custom is not a third built-in deployment profile. A PTU-only bench configuration
does not satisfy Guided Arrow's required PTU, Pixhawk/dual-GPS, broker, coordination,
and scheduling-time roles.

### Explicit inputs and examples

All files are supplied explicitly. The CLI reads regular UTF-8 JSON files and
the built-in manifest only; it neither scans the machine nor saves documents.
Standard input, symlinks, devices, duplicate JSON keys, non-finite numbers,
unknown fields and unsupported document schemas are rejected. Limits are 1 MiB
per file, 32 nested containers, 8192 structure nodes, 1024 array items, 64 object
fields, 80-character field names and 256-character printable text. Identifiers
use 1-80 lowercase letters, digits, dots, underscores or hyphens, starting with
a letter or digit. Revisions are positive integers no greater than 1,000,000,000.
The shared API and CLI each count every container, object key, and scalar value
as one node. The root container has depth 1; keys and scalar values do not add
container depth. File bytes, UTF-8 decoding, and duplicate-key rejection remain
additional CLI transport checks. Do not place credentials in these documents.
Input-error messages do not echo submitted field values.

Raw dictionaries and files receive these limits before defaults are added.
Planning and comparison semantically revalidate parser-produced immutable records
without charging added defaults against the raw-input node budget again.
Normalization adds at most eight nodes plus two per selection for configuration,
14 per inventory entry, or two plus four per requirements component. Growth is
bounded by the admitted input and fixed schema fields; repeated use adds nothing
further. An expanded `to_dict()` serialization submitted anew to a public parser
or the CLI is external input again and may exceed the unchanged limits.

JSON file access requires Linux `O_PATH`, directory-relative open/stat, and
non-following open support; unsupported platforms fail closed. Absolute and
relative paths are supported. Paths are normalized lexically against the current
directory, collapsing `.` and `..` before access; symlink/`..` traversal semantics
are not supported. `/dev`, `/proc`, and `/sys` inputs are rejected before access.
Every directory in the normalized path is opened without following links and
held by descriptor; the final file is checked and opened relative to its held
parent. Supply a regular JSON file through a stable, symlink-free directory path
if access is rejected. No directory contents are enumerated.

Ancestor symlink retargeting cannot redirect later access through an already
held directory descriptor. Final-file replacement is checked by type and
device/inode identity before reading, and reads remain byte-bounded. A final
object may have been opened before its descriptor is rejected; this is not a
guarantee that no object is opened. The policy assumes no privileged mount or
namespace changes and does not authenticate input content or freeze concurrent
in-place file writes. Every acquired descriptor is closed on success or failure.

Save this as `custom.json` in a separate working directory. Keep `PYTHONPATH`
pointing at this checkout's `src` when running file examples there:

```json
{
  "schema_version": 1,
  "id": "custom-ptu",
  "revision": 1,
  "preset": null,
  "release_id": null,
  "target": {"id": "pi-1", "environment": "linux-arm64-python311"},
  "host_roles": [],
  "instances": [],
  "selections": [
    {"component": "serialptu", "mode": "install", "provider": "repository", "instance_ids": []}
  ]
}
```

`schema_version`, `id`, `revision`, `target`, and `selections` are required.
Other top-level fields default to null or empty arrays. Each selection requires
`component`, `mode`, and `provider`; `instance_ids` defaults to an empty array.
Package selections use provider `repository`, which identifies package scope,
not publisher trust. Capability providers come from the existing manifest.
`host_roles` uses existing role IDs. `instances` contains `{id, component,
provider}` records using existing device contracts; selections reference their
stable IDs. Custom managed hardware requires explicit instances. Presets retain
their canonical provider, package, role and instance contracts; different intent
requires Custom. Full M-SEL's legacy optional hardware remains unspecified where
the foundation supplies no instances.

Modes are `install`, `reuse`, `external`, and `omit`. External mode is limited to
existing sponsor responsibility declarations. It does not establish a supported
connector and cannot satisfy a required local prerequisite. Omitted components
have no acquisition, install, activation, or removal action. Unselected inventory
entries are not scheduled for removal.

```bash
python3 -m satgs.deployment_cli validate --config custom.json --format json
python3 -m satgs.deployment_cli plan --config custom.json
```

For a reuse example, save another copy as `reuse.json`, changing only the
selection's `mode` to `reuse`. Save these supplied requirements as `release.json`:

```json
{
  "schema_version": 1,
  "release_id": "r1",
  "configuration_schema": 1,
  "environment": "linux-arm64-python311",
  "components": [
    {"component": "serialptu", "kind": "software", "revision": "rev1", "compatibility": "serial-v1", "requires": [], "source": "release-notes-r1"}
  ],
  "removed_components": []
}
```

Release documents require all fields above except `removed_components`, which
defaults to empty. Component requirements require `component`, `kind`, `requires`
and `source`; omitted `revision` or `compatibility` remains unknown and blocks a
candidate plan for selected components. Kinds are `software`, `system`,
`capability`, or `hardware`. Existing component kinds cannot be redefined.
Requirements supplement, not erase, the known source prerequisites. IDs and
compatibility labels are opaque supplied assertions, not versions to be ordered,
signed publisher evidence, artifact verification, or a general version solver.

Save the following explicitly supplied evidence as `inventory.json`:

```json
{
  "schema_version": 1,
  "id": "evidence-1",
  "target": {"id": "pi-1", "environment": "linux-arm64-python311"},
  "entries": [
    {"component": "serialptu", "provider": "repository", "instance_ids": [], "presence": "present", "release_id": "r1", "revision": "rev1", "compatibility": "serial-v1", "fresh": true, "source": "inspection-1", "runtime_state": "unknown"}
  ]
}
```

Inventory requires its four top-level fields and `component`, `provider`, and
`presence` per entry. Other entry fields default to empty instance IDs, null
identities, `fresh: false`, and `runtime_state: unknown`. Presence is `present`,
`absent`, or `unknown`; runtime state is `unknown`, `connected`, or `disconnected`.
Only fresh, sourced evidence matching target, environment, provider and instance
IDs establishes supplied presence/absence. Reuse additionally needs exact
candidate release, revision and compatibility matches. Freshness is a caller
assertion, not a clock-based check. A directory name or version alone is never
enough. Disconnection never removes an explicit selected device.

POLICY-01 remains conservative: unchanged component revision and compatibility
under a new aggregate candidate release do not make old release-specific
evidence sufficient. Reuse stays blocked as unproven, not as confirmed
incompatibility or permission to reinstall. Transferable component-scoped
evidence needs an explicit future contract; do not relabel old evidence or infer
compatibility from version ordering.

```bash
python3 -m satgs.deployment_cli plan --config reuse.json --inventory inventory.json --requirements release.json --format json
```

The example proposes reuse and exits 0, without probing the target. For an
incompatible case, save `incompatible.json` as a copy of the inventory with
`compatibility` changed to `serial-v0`; this command exits 3:

```bash
python3 -m satgs.deployment_cli plan --config reuse.json --inventory incompatible.json --requirements release.json --format json
```

For comparison, save `candidate.json` as a copy of `release.json`, change its
`release_id` to `r2`, change the serialptu revision to `rev2`, and append this
optional component to its `components` array:

```json
{"component": "future-recorder", "kind": "software", "revision": "rev1", "compatibility": "recorder-v1", "requires": [], "source": "release-notes-r2"}
```

```bash
python3 -m satgs.deployment_cli compare --config custom.json --requirements candidate.json --format json
```

The selected serialptu candidate requirement is shown; `future-recorder` stays
unselected. New required software appears separately with its source reason.
New required hardware needs an explicit configuration decision, never an
invented device ID. Both formats retain every requiring component, relationship,
and source, including requirements with no selected outcome. Required omissions,
removed selections, unresolved references,
cycles, unsupported schema changes and insufficient compatibility evidence block
the relevant result. Comparison does not infer compatibility from newer-looking
versions and does not stage, migrate, activate, roll back, or update anything.

Invalid combinations and mutation attempts exit 2 without effects:

```bash
python3 -m satgs.deployment_cli plan --preset guided_arrow --config custom.json --format json
python3 -m satgs.deployment_cli apply --format json
```

### Dependency scope and deferred validation

Each derived prerequisite carries a source path and relationship type:
Python declaration, source import, owning module/service program, managed-hardware
association, operational service, or supplied release requirement. Source paths
are relative to the named repository at the integrated component pins. A local
broker is a managed service requirement, not a blanket dependency of every Meteor
library use. Selecting only `serialptu` remains a direct bench software preview.
Selecting managed QPT or dual-GPS hardware entails its PTU or Pixhawk service
path. These relationships do not prove systemd ordering or service readiness.

Optional driver imports are no longer unconditional `execution.pass_runner`
prerequisites. Their operation-specific requirements remain under
`rf.frontend -> dsi_instruments`, `power.pdu_hpa -> cyberpowerpdu`, and
`recording.signal_hound -> signal_hound`, including applicable service/native
requirements. `orchestration.queue_manager` still requires local
`recording.signal_hound` and `processing.msel_post_processing`; queue source is
unchanged. Explicit omissions block
without being overwritten. Unspecified software may be derived for Custom;
software excluded by a canonical preset remains excluded and blocks feasibility.
Supplemental requirements cannot erase source-backed prerequisites. An unrelated
`serialptu` bench preview does not inherit execution or queue requirements.

The model intentionally does not claim complete Python/build/native dependency
closure. Source package cycles between `ground_station` and `sat_tracker` or
`pixhawk`, incomplete package metadata, and queue recording/processing coupling
remain visible. Artifacts, publisher trust, the Pi's Python/ARM64 environment,
broker readiness, synchronized time and physical commissioning are unverified.
R1 adds owned direct-run logging, independent truth ephemerides, cancellation/error
propagation and exclusive output ownership. This does not qualify real client
lifecycle, physical completion or the queue. API/CLI parity, a desktop GUI and
Pi commissioning remain separate concerns.

## R1 explicit direct pointing

R1 connects `run_pass` and `python -m satgs.pass_runner` to the same `main()` and
existing `PassRunner`. It is local implementation with hardware-free contract
tests, not an activation approval. Required owner contracts and reviewed release
integration are currently absent, so production pointing fails closed before
creating output, changing logging, starting workers or acquiring clients.

Set `STOMP_SKIP_HOSTNAME_SCAN=1` in the launch environment before starting the
interpreter and before any Meteor/lower import. Setting it after import does not
undo hostname discovery. The consumer does not change this policy at runtime.

The supported explicit options are `--operation pointing`,
`--deployment-config PATH`, and `--runtime-bindings PATH`. The existing `-config`,
`-sf`, `-id`, `-d` and `-elmask` supply station YAML, local TLE CSV, NORAD identity,
duration and elevation mask. Invocation shape, not an instruction to run equipment:

```text
run_pass --operation pointing --deployment-config guided-arrow.json --runtime-bindings pointing-bindings.json -config station.yaml -sf local-tle.csv -id 28626 -d 30 -elmask 15
```

Explicit pointing requires exactly one bound QPT-130/Pixhawk dual-GPS pair.
Additional installed devices remain unused. Custom requires complete local
pointing, software, broker and time selections; a PTU-only bench selection is
insufficient. Missing or invalid explicit inputs never select legacy behavior.
Explicit modular Full M-SEL is unsupported because its canonical foundation does
not provide stable hardware instances. The no-operation, no-modular-input legacy
Full M-SEL path retains normal RF defaults, trace recording and omission flags.
Pointing rejects RF selectors, recording, SIP-source, error-injection, calibration,
`--noptu` and `--nopixhawk` requests. `--nofrontend` and `--nopdu` are compatible
narrowing. Explicit pointing adds no calibration, reset or parking during
configuration or acquisition.

### Planning-only configuration and binding example

In a separate empty directory with `PYTHONPATH` pointing to this checkout's `src`,
the following creates only two ordinary planning inputs. It imports no runner or
driver and contacts nothing. The target and manager IDs are illustrative, not
host qualification or equipment assignments. Exclusive writes refuse collisions.

```python
import hashlib
import json
from pathlib import Path

from satgs.deployment import load_manifest
from satgs.deployment_plan import build_catalog, expand_preset

catalog = build_catalog(load_manifest())
configuration = expand_preset(catalog, "guided_arrow").to_dict()
configuration["target"] = {"id": "station-1", "environment": "linux-arm64-python311"}
payload = (json.dumps(configuration, indent=2) + "\n").encode("utf-8")
binding = {
    "schema_version": 1,
    "configuration_id": configuration["id"],
    "configuration_revision": configuration["revision"],
    "configuration_sha256": hashlib.sha256(payload).hexdigest(),
    "target": configuration["target"],
    "bindings": [
        {"instance_id": "ptu-1", "component": "qpt130", "provider": "guided_arrow_hardware",
         "manager_id": 7, "paired_with": "pixhawk-1"},
        {"instance_id": "pixhawk-1", "component": "pixhawk_dual_gps", "provider": "guided_arrow_hardware",
         "manager_id": 9, "paired_with": "ptu-1"},
    ],
}
with Path("guided-arrow.json").open("xb") as stream:
    stream.write(payload)
with Path("pointing-bindings.json").open("x", encoding="utf-8") as stream:
    json.dump(binding, stream, indent=2)
```

The separate version-1 binding schema does not change installation configuration.
It must match configuration identity, revision, exact original-byte SHA-256 and
target. Both stable identities must match allowed local component/provider
selections. Manager IDs are positive nonboolean integers, never broadcast zero.
Bindings must be unique and reciprocal. The admitted station YAML must also
contain `positioners: [{id: 7, pix_id: 9, type: QPT-130, ...}]` and
`pixhawk_sensors: [{id: 9, ptu_id: 7, ...}]`. No ID is inferred from `ptu-1`, and
the first available sensor is never selected implicitly.

`load_runtime_configuration(deployment_config, runtime_bindings, station_config,
sat_file, *, sat_id, duration, elevation)` admits those inputs once and returns
immutable `RuntimeContext`. `resolve_runtime_request` adds explicit-operation
and legacy-boundary validation. Shared `validate_selection_contract` enforces
canonical/Custom identity and managed-hardware consistency without calling the
planner for authority. `read_json_document(path)` returns exact admitted bytes
and decoded data; `_read_json` remains its compatibility wrapper. REG-01 remains:
normalized internal records are not fresh external input charged against 8,192
nodes again. SHA-256 identifies bytes; it authenticates neither publisher nor
permission to operate.

Station YAML and local TLE use bounded, symlink-free regular-file admission.
JSON-compatible YAML uses real stdlib parsing with duplicate/nonfinite checks;
block YAML requires real PyYAML SafeLoader with alias, duplicate-key and structural
guards. JSON transport limits remain unchanged. Station input is limited to
1 MiB, 32 levels and 8,192 key-inclusive nodes, with finite site/transport fields.
Home/output paths must be absolute and outside root/device/observation locations.
Only selected-device settings reach owners. Selected no-go input uses the existing
single-zone format and becomes immutable in-memory data, not a path for rereading.
Credentials remain in protected input/in-memory settings, excluded from repr,
diagnostics, snapshots, command arguments and test-details exports.

Strict pointing additionally requires `amq_use_ssl: true`, a canonical numeric
`amq_dial_address` (IPv4 or IPv6, at most 45 ASCII characters), a separate
`amq_tls_server_name` (canonical IP or DNS identity, at most 253 ASCII characters),
and nonempty inline `amq_ca_pem` public-certificate text. The optional
`amq_stomp_host` is independent of both addresses: absent or null omits the header,
while an explicit empty string remains an empty header. It is bounded to 255
printable ASCII characters. `amq_server` remains legacy metadata, not strict dial
authority. No DNS fallback or implicit host inference is added.

Only the root station `amq_ca_pem` value permits up to 65,536 ASCII characters,
including CR/LF/TAB. Keys, nested values, unrelated strings and no-go input retain
their existing bounds. The CA node still counts toward all document limits.
G admits finite data only; Meteor validates public-certificate grammar and creates
its private verifying TLS context. CA data is never reopened as a path, and G
adds no certificate parser, injected context, default trust store or TLS fallback.
Credentials remain nonempty printable strings, each at most 1,024 characters and
4,096 UTF-8 bytes. The complete CONNECT header budget is 8,192 bytes, including
fixed fields and any explicit host. These rules apply only to explicit pointing;
unchanged legacy calls are not given a strict or bounded qualification.

The selected local CSV row must have a unique matching NORAD ID, valid TLE line
shape/checksums and UTC date. Existing astronomy resolves the pass without network
refresh; duration must be finite and positive, elevation within `[0, 90)`, and
the resolved pass window supported. These representation bounds do not establish
safe motion limits, approved duration budgets or current TLE suitability.

### Owner gates, lifecycle and outcomes

The consumer requires Messenger `satgs.pointing.v2`, with
`prepare_transport(settings, cancel)`,
`open_bounded(settings, deadline, cancel, prepared=...)`,
`strict_instance_compatible(settings)` and passive `close(deadline)`.
PTU/Pixhawk retain `satgs.pointing.v1` and `open_pointing` with admitted settings,
selected ID, owned output location, deadline and cancellation; bounded connection
checks; and passive idempotent close. PTU additionally consumes admitted no-go data
and addressed TLE/prime commands. Pixhawk logging must honor its bounded/cancellable
contract. Constructors own rollback until they return; clients must not close a
borrowed transport. Passive close must not send abort, park, reset or calibration.

For an owned Messenger, complete local input, pass, owner and prefix admission
precedes preparation. Preparation occurs once before output creation, logging,
signals, truth workers or clients, and before the acquisition deadline is created.
The same immutable settings and lifecycle Event, and the exact private opaque
prepared value, reach the later open. No preparation object is added to public
runtime context or runner state. Preparation is outside acquisition's budget and
does not promise interruption of native CA parsing. After preparation the runner
rechecks cancellation, remaining pass duration and the existing inclusive
60-second priming lookahead. A stale pass fails before resource effects; the
later open receives a fresh existing acquisition budget, not a new timeout.

A borrowed Messenger must pass reviewed class/release admission and its real
side-effect-free compatibility check against the admitted settings before any
output or resource effect. The runner never prepares, opens, reconfigures or
closes that borrowed owner, including after a later selected-client failure.
Compatibility rejection is invalid input, not a retry or ownership transfer.
Preparation failures use the fixed acquisition outcome; actual runner
cancellation retains precedence. Owner exception text and transport inputs are
not included in those diagnostics.

Method names alone do not qualify these contracts. The production reviewed-owner
release map is empty and has no operator-facing bypass. The dependency order is
separately approved Meteor lifecycle changes, PTU/Pixhawk lifecycle and selected
manager addressing, reviewed pin integration, then actual-client validation.
This consumer requirement does not allocate declarations or release identities
in the accepted owner/lower source. Their pins and production admission remain
unchanged. Hardware-free consumer self-validation is separate from independent
consumer acceptance, native TLS/reclamation, broker and platform qualification.
Bounded connection, calibrated
state, telemetry freshness/health, time quality and addressed motion/cancellation
policy remain activation prerequisites.

The selected owner's `ptu_is_primed` flag only advances the software state machine.
It is not evidence of calibration, fresh navigation, safe motion or physical
readiness. Neither a pong nor a successful import supplies that evidence.

Preflight precedes one exclusive output leaf and owned handlers. Failed artifacts
are retained. Execution and truth logging use independent observer/body objects;
the truth worker has a retained handle, cancellation event and error channel.
Explicit-pointing and newly owned resource releases are idempotent and bounded,
attempt remaining resources after errors, and restore only owned logger/signal
state. Existing legacy client `clean_exit`/`shutdown` calls are not qualified as
bounded passive release; one legacy client failure can prevent later legacy-client
cleanup. Collisions, prime timeout and
cancellation now fail explicitly instead of continuing or reporting false success.
This does not certify legacy drivers' internal rollback.

Exit meanings: `2` invalid/unsupported input, `3` unsupported owner integration,
`4` acquisition failure, `5` execution/timeout, `6` logging, `7` cleanup,
`8` indeterminate physical state, and `130` cancellation. `0` means software-only
completion, not verified physical completion. A pointing run that submits prime
remains indeterminate and ends with `8` even if its software loop completes.
The final summary retains a fixed `primary_failure` category, including
`prime-timeout` and `drop-dead`, with separate `cleanup_categories` and
`logging_failure` fields. Owned handler emit/write/flush or finalization failure
reports `owned-logging` and returns `6` unless an earlier primary failure or
cancellation controls the result. The new failure fields contain only fixed
categories, not owner exception text or failed log payloads.
Primary failures remain primary while cleanup,
logging and worker failures remain separately visible.
Closed runs are not automatically restarted. A nonzero process exit
does not prevent another process from starting or establish a physical stop;
cross-process enforcement and approved operating procedures remain separate gates.

Hardware-free tests exercise the actual entrypoint/runner under a runtime guard
with strict selected-owner and missing-scientific-dependency substitutes. They
are control-flow/contract evidence, not numerical, wire or physical certification.
Real-dependency numerical/import and block-YAML integration, actual owner-contract
integration, Python 3.11/ARM64 and hardware commissioning are NOT RUN in this lane.
R1 adds no authorization framework, queue integration, installer executor,
dependency installation, deployment, UI, or hardware activation. The Guided Arrow
apply guard, canonical profiles and deferred POLICY-01 remain unchanged.

### Strict owner development integration

The bounded runner preflights the selected PTU's frozen run policy and TLE binding
before transport preparation, output creation, signals or worker startup. The
selected positioner must provide the accepted `ptu_control.pointing.PointingPolicy`
fields, including protocol, mechanical limits and the complete `pointing_context`.
The run identifier, calibration/configuration generations, frame, calibration
offsets and TLE digest must be supplied by the admitting owner. The runner neither
invents calibration nor rereads manager policy files. Selected PTU and Pixhawk
manager identifiers are positive signed 31-bit integers; NORAD identity is separate.

Development integration does not activate production owner declarations or the
reviewed-release map. The strict runner enables correlated scheduling on its
inert PTU client before connectivity activation. Its existing pass loop owns the
cadence: after correlated load and prime, each TRACK request makes the selected
manager calculate the current target and submit through its frozen-policy and
final encoded-endpoint gates. The fixture does not supply tracking ticks. No
worker is added to the manager or serial driver. The existing duration boundary
sends a software-only COMPLETE request; below-mask manager completion is also
terminal. Neither completion parks or physically stops the device.

Every request/outcome is bound to the selected manager, run policy, private
client sender, monotonically increasing operation sequence and operation kind.
Only one request is pending. Old status messages cannot establish scheduled
readiness, and stale/duplicate/mismatched outcomes cannot replace a current
terminal result. Fixed outcomes distinguish the current operation's successful
move exchanges, its failing exchange disposition, cumulative successful
submissions and sticky possible submission. Counts are not physical movements.
The runner prints the manager result separately from local cancellation and
physical state. Normal software completion still returns 8 when physical state
is indeterminate; manager rejection/deadline is not relabeled as runner
cancellation. A local timeout or close may leave a newer remote outcome
unobserved, so its earlier cumulative report is not a remote upper bound.

The manager must be independently admitted in scheduled mode with a finite
run deadline and an explicit bounded nonmotion outcome-report timeout. Its
lifecycle Event is separate from the runner's Event and may be separate from
its borrowed transport Event. Expiry or cancellation cannot renew motion
authority. Report delivery is best effort; missing outcomes fail locally.
Passive client cleanup unregisters only its own subscriptions and leaves
borrowed transports alive. It sends no remote cancellation or physical stop.

A correlated prime response is software readiness evidence only. Client
cancellation is local and does not cancel remote work or stop physical motion.
Pixhawk selected-ID pong and parsed messages establish neither sensor freshness
nor navigation/heading validity. Those qualification contracts remain separate.

This Pelican configuration selects QPT130 only. Full M-SEL and other supported
external-component configurations are unchanged. Development protobuf generation
uses pinned build tooling outside runtime installs; the package boundaries and
common development runtime are described above. Installed validation and target
qualification remain separate obligations.
No Python 3.11/ARM64, installed-system or physical qualification follows from a
controlled development-host test.

## Manual station-location preparation

`satgs.station_location` owns the shared manual-selection operation used by the
CLI and dashboard adapter. Latitude and longitude are explicit finite numbers in
degrees, within `[-90, 90]` and `[-180, 180]`; altitude is a finite number in metres.
Booleans are not coordinates. No altitude datum, GPS conversion, freshness,
accuracy or navigation qualification is inferred. Live GPS selection is unsupported.

`location_from_settings(settings)` returns an immutable `Location`. Its public
`to_dict()` contains only `source`, `latitude_deg`, `longitude_deg`, `altitude_m`
and `identity`. Existing settings without `ground_station_location_source` are
labelled `configured`, not measured GPS. Manual selections set that field to
`manual` and retain the existing `ground_station_lat`, `ground_station_lon` and
`ground_station_altm` coordinate keys. The location identity is a deterministic
SHA-256 over normalized coordinates and source, not permission to operate.

`prepare_manual_location(settings, *, latitude_deg, longitude_deg, altitude_m,
expected_revision, current_revision, source="manual")` returns an immutable
`PreparedLocation` with `location`, `changed`, and a `settings()` accessor that
returns a detached copy. Full station settings are excluded from its repr.
Both revision arguments must identify the same exact station bytes by lowercase
SHA-256. Persistence adapters must compute the current revision from admitted
bytes and serialize concurrent saves; caller-supplied matching strings alone do
not establish concurrency control. Stale requests fail, and an identical manual
retry returns `changed: false`. All-missing or all-null existing coordinates may
be initialized; partially populated or malformed existing coordinates fail closed.

The separate module CLI prepares a new JSON-compatible YAML artifact. Command
shape only, with operator-supplied coordinates and an exact current input digest:

```text
python -m satgs.station_location_cli --station station.yaml --output new-station.json --expected-revision SHA256 --latitude-deg LATITUDE_DEGREES --longitude-deg LONGITUDE_DEGREES --altitude-m ALTITUDE_METRES
```

Input retains the bounded, no-symlink station reader and duplicate/nonfinite YAML
checks. Output is exclusively created in an existing no-symlink directory with
requested mode `0600`; a stricter process umask remains effective. Existing files
are never overwritten. Unrelated parsed settings, including protected transport
values, remain in the private artifact; YAML comments and formatting are not
preserved. Standard output contains only location, revision and preparation status,
never the full station document. Failure returns status 2. A failed output write
or finalization may leave an incomplete private output, which is reported and is
not reused automatically. Successful output returns status 0, not runtime readiness.

Selection does not mutate any admitted `RuntimeContext`, active run, PTU manager
or previous plan. Subsequent location-dependent plans must compare the selected
location identity before reuse. `planning_revalidation_required` and
`owner_reinitialization_required` describe changes relative to this input only;
`owner_state: not_checked` remains true in meaning even for an unchanged retry.
The shared operator Run request now snapshots the selected manual location and
revision into the strict RuntimeContext and PTU policy binding before owner
initialization. It requires an explicit mean-sea-level altitude reference and
revalidates the exact selected pass. Legacy or unbound manual initialization
remains rejected. Reloading TLEs alone is not location reinitialization. Production
owner admission remains separate; the dashboard's manual queue restriction is
unchanged. A restart alone is not evidence of a matching owner binding.
Deployment configuration and runtime-binding schemas are unchanged.

Focused hardware-free tests are `test_station_location.py`,
`test_station_location_cli.py` and the manual-location cases in
`test_runtime_configuration.py`. Execute them only in the separately approved
development environment with its offline effect controls; these test files are
not sandboxes or target authorization.

## Native operator application

The `0.0.1+runtime.20261110.1` development candidate extends `satgs-operator`
and `satgs-operator-gui`. Both use `satgs.operator_core.Workspace`, the existing
station-location validator and canonical deployment planner. The native GUI is
Tkinter/ttk, not the separately owned browser dashboard. Tk is loaded only when
opening a window; the CLI does not require a display or Tk.

Create a new private practice workspace with
`satgs-operator --workspace ./practice-station init`, then inspect it with
`satgs-operator --workspace ./practice-station status`. Open that same workspace
with `satgs-operator-gui --workspace ./practice-station`. The GUI provides Home,
Setup, Location, Review, Results, Run and PTU screens. It never starts an operational owner
merely to show a screen.

Manual latitude/longitude use degrees; altitude uses metres with an explicit
`unspecified` or operator-declared `mean_sea_level` reference. Preview and confirm
before saving. An active managed runner or stale station revision rejects a
conflicting save. Reported GPS observations remain separate from the effective
station location. GPS selection is disabled pending its source, validity, time
and coordinate-reference contract.

`satgs-operator --help` lists the supported commands. `plan` uses real local
orbit calculations and a bundled historical NOAA 15 replay by default, with no
TLE refresh. Calculating a revision-bound plan does not start a run. A station
change marks old plans for revalidation. The Run page reviews and confirms a
frozen request for the real PassRunner; the PTU page provides explicit selected-ID
bench operations through the same shared API as the CLI. Live bench admission
remains closed pending the allocated unit's current-position and Stop contract.
No installation, service activation, database or storage action is provided.
See OPERATOR.md for the shared runtime and bench commands. Side-by-side setup
and consolidated hardware-free acceptance remain separate from live control.
