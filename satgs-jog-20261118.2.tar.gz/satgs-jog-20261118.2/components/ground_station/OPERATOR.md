# SATGS native operator development candidate

This candidate adds a native Tkinter/ttk application and a headless CLI to the
existing modular ground_station product. Both use the same managed-workspace
operation, station-location validators and canonical deployment planner. The
browser dashboard is separately owned and is not replaced or started here.

Installed entry points are `satgs-operator` and `satgs-operator-gui`. Tk is
optional and loaded only when opening a window. The CLI works without a display
or Tk. No operational owner is constructed merely to inspect a workspace.

Create a NEW private scratch station outside the checkout:

```sh
satgs-operator --workspace ./practice-station init
satgs-operator --workspace ./practice-station status
satgs-operator-gui --workspace ./practice-station
```

The native window provides Home, Setup, Location, Review, Results, Run and PTU. Supported
work includes canonical Full M-SEL, Guided Arrow and Custom planning choices;
manual latitude/longitude in degrees and altitude in metres with an explicit
reference; preview, confirm, cancel, save and reload; local numerical pass
planning; and private report export. This Pelican case remains QPT130-only.
There is no install or service-activation button. PTU commands are explicit and
remain unavailable until the exact bench setup has independent admission.

The application title is SATGS. The station heading uses the saved name, with
Station as the fallback. Existing workspaces with the exact generated name
`Synthetic operator practice station` display Station without rewriting the
workspace. Other saved names, paths, IDs, coordinates and revisions are retained.
New workspaces use Station as their default name.

The interface has no warning banners, badges or replacement labels. Ordinary
status and source fields retain the actual values, including unknown, critical,
manual and replay states. GPS selection remains disabled. Preview still opens
Review, and Save confirms that specific pending change. Escape cancels it.

CLI output is human-readable by default. Use `--format json` before the command
for machine output. JSON field names, source flags, operation outcomes and exit
codes are unchanged. Report exports retain their full provenance and diagnostic
fields; the human views omit repeated scope and qualification prose.

Full M-SEL's optional local hardware has no stable instances declared. Changing
that preset to Custom therefore needs explicit operator intent. A rejected
Custom draft remains visible and unapplied, with the shared identity diagnostic
and confirmation disabled. No hardware identity or omission is invented. Use
the existing stable Guided Arrow instances, explicitly change selection modes,
or provide complete canonical JSON through the CLI for other Custom intent.

Use `satgs-operator --help` for arguments. Applying a revision-bound preview
requires `--confirm`. Stale revisions and active managed-runner work reject
conflicting changes. Completed apply is idempotent. A real save followed by
receipt failure is reported as partial, not silently undone or successful.

Read the version-matched offline User Guide with `satgs-operator docs` or
`satgs-operator --read-docs`. Use `satgs-operator docs --text` over SSH or on a
headless terminal. These commands do not require a station. The native window's
Help > User Guide opens the same packaged guide without changing drafts or
starting station work. A desktop dispatch is not proof that a viewer rendered
the page; unavailable viewers fall back to readable text.

The guide sources are in `docs/`: twelve task chapters and a technical appendix
cover architecture, profiles, all 24 canonical components, installation, daily
use, station location, PTU operation, planning/runs, results, migration, updates
and CLI/glossary. Start with [Purpose and architecture](docs/operator-guide.md).
The normal wheel build packages
deterministic HTML, text, CSS and the labelled screenshot. No browser server,
runtime documentation compiler or source checkout is needed.

`plan` uses the existing orbit calculations with a bundled historical NOAA 15
replay by default. It does not refresh TLEs. Plans bind the saved station and TLE
identity; a later station change marks old plans for revalidation. The shared
Run request now binds admitted manual mean-sea-level coordinates to the selected
strict owners. Legacy and unbound manual requests remain rejected. This location
binding does not grant production owner admission or qualify navigation.

Manual, measured/replay and effective station coordinates remain distinct.
Altitude references are operator-declared or unspecified, not surveyed or
converted. GPS selection is unavailable pending its source, validity,
timing/freshness and coordinate-reference contract. Status scenario provenance
remains in ordinary source fields and structured output. Transport pass may
coexist with critical health and unqualified heading. Incomplete messages and
final unpublished aggregates remain documented limitations, not repaired
observations.

The internal delivery includes the command reference, hands-on tutorial,
component provenance, exact dependency/build inputs and separately reviewed
offline acceptance support. Configuration, credentials, reports, logs,
environments and review evidence belong outside product Git history.

Install this candidate side-by-side, never into the passing Pi application or
diagnostic environment. Host validation is not target GUI, ARM64 navigation,
broker delivery or physical qualification. This slice does not activate
production admission, connect services, open devices, alter firmware, perform
RF operations or move a PTU. Client cancellation is not remote cancellation or
physical stopping. Existing component notices and ownership are retained.
## Runtime requests and PTU control

The runtime candidate is separate from the accepted r4 installation. Saving a
location never moves a device. GPS station selection remains unavailable.

Use the existing Calculate operation first. Review the desired opportunity,
then use the Run page with explicit local configuration, owner-settings, runtime
binding and TLE files. Review run freezes their identities together with the
saved station revision, coordinate units and declared altitude reference.
Start run is a separate action. Updating the station invalidates older plans.
The runner holds the existing station lease while active. Ordinary owner release
admission remains enforced and the production map remains empty.

Equivalent CLI operations:

```text
satgs-operator --workspace STATION run-preview --plan-id PLAN --deployment-config CONFIG.json --runtime-bindings BINDINGS.json --station-config OWNERS.json --tle-file LOCAL.csv --duration SECONDS
satgs-operator --workspace STATION run-start --run-id REQUEST --confirm
satgs-operator --workspace STATION run-status --run-id REQUEST
satgs-operator --workspace STATION run-cancel --run-id REQUEST
```

Rehearsal is an explicitly recorded mode. Selecting that label does not grant
owner admission or enable equipment. The consolidated hardware-free acceptance
uses real owner code with controlled transport and serial boundaries.

The PTU page and `satgs-operator --workspace STATION bench --configuration BENCH.json`
share one command session. The CLI accepts deliberate `connect`, `status`,
`preview PAN TILT`, `move`, `stop`, `disconnect`, and `quit` commands. There is no
move on opening the interface, entering a number, connecting or closing. The
manager remains the single serial owner. Status retains protocol-reported
coordinates and timestamps without claiming measured arrival. Acknowledgement,
local cancellation and passive disconnect do not establish physical stopping.

Live bench admission is currently unavailable pending the allocated unit's
documented current-position and Stop contract and reviewed setup binding. The
software command path can be rehearsed under controlled boundaries; it is not a
live-ready commissioning release. No force option or production fallback exists.

Results retain software completion, submission history, manager outcomes and
physical state separately. Status 8 remains physical-state-indeterminate. A
saved progress record alone does not establish a currently running process.
Keep partial results and failed saves; do not repeat uncertain motion.

