#!/bin/bash

#sudo systemctl restart activemq.service
#sleep 2
#sudo systemctl restart ptu.service  # If ptu controller for ptu2
#sleep 2
sudo systemctl restart sh_iq_logger.service
sleep 2
sudo systemctl restart rf_loopback.service
sleep 2
sudo systemctl restart cyberpower_pdu.service
sleep 2
sudo systemctl restart ground_station.service # Restart last to ensure fresh connections
sleep 2


sudo systemctl status activemq.service 
sleep 2
sudo systemctl status ptu.service
sleep 2
sudo systemctl status sh_iq_logger.service
sleep 2
sudo systemctl status rf_loopback.service
sleep 2
sudo systemctl status cyberpower_pdu.service
sleep 2
sudo systemctl status ground_station.service

