#!/usr/bin/env bash

set -euo pipefail

# Build today string
TODAY="$(date +'%m-%d-%y')"

# TODO: Read the config.yaml file to dynamically grab these locations
PARENT_DIR="$HOME/logs/"
DAYS_OLD=10

LOG_DIR="$HOME/logs/results_manager"
LOG_FILE="$LOG_DIR/clean_results_log.log"

mkdir -p "$LOG_DIR"

echo "========= $(date '+%Y-%m-%d %H:%M:%S') - CLEAN RESULTS RUN FOR $PARENT_DIR ===========" >> "$LOG_FILE"

echo "Scanning: $PARENT_DIR for results dirs older than $DAYS_OLD day(s) ... " >> "$LOG_FILE"

echo "Found: " >> "$LOG_FILE"
find "$PARENT_DIR" -mindepth 1 -maxdepth 1 -type d -mtime +"$DAYS_OLD" -print >> "$LOG_FILE"

find "$PARENT_DIR" -mindepth 1 -maxdepth 1 -type d -mtime +"$DAYS_OLD" -exec rm -rf {} + >> "$LOG_FILE" 2>&1

echo "" >> "$LOG_FILE"
