#!/bin/bash

sudo systemctl restart frontend.service
sleep 2

sudo systemctl status frontend.service
