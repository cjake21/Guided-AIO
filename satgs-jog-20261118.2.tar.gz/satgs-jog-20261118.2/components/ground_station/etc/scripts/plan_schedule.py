import sys
import yaml
import logging
import argparse
from pathlib import Path
import pandas as pd

from satgs.constants import DEFAULTS
from satgs.pass_finder import PassFinder

DEFAULT_CFG = Path("~/ground_station/config/config.yaml").expanduser()

def main():
    parser = argparse.ArgumentParser(description = 'MSEL Schedule Planner, generates a run sheet and turns it into a schedule')
    parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
                        help = 'Config File. Defaults to {}'.format(str(DEFAULT_CFG)))    
    parser.add_argument('--start-id', type=int, 
                        help = "Optional. Start schedule from given start id, non-inclusive")
    parser.add_argument('--sids', nargs="*", type=int, default=None,
                        help="List of NORAD IDs to plan. Defaults to all satellites in the satellite database")
    parser.add_argument('--el-mask', type=int, default=DEFAULTS.elev_mask,
                        help="Mask all passes under this max el value, default set in satgs constants file")
    args = parser.parse_args()

    d_options = ["down", "d", "downlink"]
    u_options = ["u", "up", "uplink"]
    dl_fc_mhz_options = ["1534.5"]
    ul_fc_mhz_options = ["4920", "5255"]
    tx_source_options = ["sg", "wm"]
    fpga_image_options = ["MITRE_RX_CAPTURE_V2", 
                          "MITRE_RX_CAPTURE", 
                          "AD_DVB_S2X"]
    
    ul_modcod_options = ["QPSK 4MSPS 35% 5/6 FEC", 
                         "QPSK 8MSPS 35% 1/2 FEC"]

    dl_modcod_options = ["QPSK 5MSPS 35% 3/4 FEC"]

    config_file = Path(args.config).expanduser()
    with open(config_file, "r") as f:
        config = yaml.safe_load(f)

    if args.start_id:
        next_id = args.start_id
        print(f"Starting from pass-id: {next_id} ...")
    else:
        print("Not assigning any pass-ids ...")
        next_id = None

    try:
        run_sheet_dir = Path(config["run_sheet_dir"]).expanduser()
    except KeyError:
        print("Key error: 'run_sheet_dir' is not defined in the ground station config file ... Exiting")
        sys.exit(-2)
    
    pass_finder = PassFinder(
        sat_file=Path(config["sat_db_file"]).expanduser(),
        config_file=config_file,
        norad_ids=args.sids,
        el_mask_deg=args.el_mask,
    )
    pass_finder.run_sat_passes()
    run_sheet = pass_finder.generate_csv_file()
    schedule = run_sheet_dir / f"planned_{run_sheet.name}"

    print(f"Planning generated run sheet: ({run_sheet})")
    print(f"Saving planned schedule to: ({schedule})")

    df = pd.read_csv(run_sheet)
    df["pass_id"] = df["pass_id"].astype(int)
    df["tx_source"] = df["tx_source"].astype(str)
    df["comment"] = df["comment"].astype(str)
    df["fpga_image"] = df["fpga_image"].astype(str)
    df["dl_modcod"] = df["dl_modcod"].astype(str)
    df["ul_modcod"] = df["ul_modcod"].astype(str)

    print(df)
    
    for index, row in df.iterrows():
        fpga_image = "AD_DVB_S2X"
        
        if next_id is None:
            next_id = 1
        else:
            next_id += 1

        print(f"Planning row {index} with pass-id {next_id} ...")
        print(row.T)
        
        if df.at[index, "pass_state"] == "SCHEDULED_PLANNED":
            confirm = input(f"Index {index} with pass-id {df.at[index, 'pass_id']} has been planned already. Overwrite? y/N").strip() or "n"
            if confirm == "" or confirm == "Y" or confirm == "y":
                pass
            else:
                continue

        up_or_down = input("UPLINK [u] or DOWNLINK [d]").strip().lower()
        if (up_or_down not in d_options) and (up_or_down not in u_options):
            print("Invalid input, cant do both")
            sys.exit(-1)

        if up_or_down in d_options:
            print(f"User selected downlink, setting FPGA Image to AD_DVB_S2X for file download")
            fpga_image = "AD_DVB_S2X"

            dl_fc_mhz = input("Input the DOWNLINK CENTER FREQUENCY IN MHZ: [1534.5] ").strip() or 1534.5
            dl_bw_mhz = input("Input the DOWNLINK BANDWIDTH IN MHZ: [10.0] ").strip() or 10.0
            
            for i, value in enumerate(dl_modcod_options, start=1):
                print(f"[{i}]: {value}")
            dl_modcod_pref = input("Input the DOWNLINK MODCOD option: [1] ").strip() or 1

            if 1 <= int(dl_modcod_pref) <= len(dl_modcod_options):
                dl_modcod = dl_modcod_options[int(dl_modcod_pref)-1]
            else:
                print("Invalid input, choosing dl_modcod option 1")
                dl_modcod = dl_modcod_options[0]
            
            # We chose a downlink, so unset all uplink options
            ul_fc_mhz = 0.0
            tx_source = "NA"
            ul_modcod = "NA"
        else:
            # We chose an uplink already, so unset all the downlink options
            dl_fc_mhz = 0.0
            dl_bw_mhz = 0.0
            dl_modcod = "NA"

        if up_or_down in u_options:  # User selected an uplink
            tx_source = input("Choose your tx_source, the signal generator or the work modem (default): [sg | wm] ").strip().lower() or "wm"
            if tx_source not in tx_source_options:
                print(f"Invalid input, options are: {tx_source_options}, setting it to Work Modem")
                tx_source = "wm"
            if tx_source == "sg":  # If the user wants to use the sig gen as the source
                print(f"{tx_source=}, setting FPGA image to MITRE_RX_CAPTURE_V2 and UPLINK MODCOD to TONE")
                fpga_image = "MITRE_RX_CAPTURE_V2"
                ul_modcod = "TONE"
            else:
                print(f"{tx_source=}, setting FPGA image to AD_DVB_S2X for file upload")
                fpga_image = "AD_DVB_S2X"
                ul_modcod = "NA"
            
            ul_fc_mhz = input("Input the UPLINK CENTER FREQUENCY IN MHZ: [5255.0]").strip() or 5255.0
            
            if ul_modcod == "TONE":
                pass
            else:
                for i, value in enumerate(ul_modcod_options, start=1):
                    print(f"[{i}]: {value}")
                ul_modcod_pref = input("Input the UPLINK MODCOD option: [1] ").strip() or 1
                if 1 <= int(ul_modcod_pref) <= len(ul_modcod_options):
                    ul_modcod = ul_modcod_options[int(ul_modcod_pref)-1]
                else:
                    print("Invalid input, choosing ul_modcod option 1")
                    ul_modcod = ul_modcod_options[0]

            dl_fc_mhz = 0.0
            dl_bw_mhz = 0.0
            dl_modcod = "NA"
        else:
            ul_fc_mhz = 0.0
            tx_source = "NA"
            ul_modcod = "NA"
        
        comment = input("Add a comment: ").strip().lower() or "used plan_schedule.py"

        try:
            print(f"Confirm your selections: \n")
            print("Comment: ", comment)
            print("FPGA Image: ", fpga_image)
            print("TX Source: ", tx_source)
            print("DL Fc: ", float(dl_fc_mhz))
            print("DL Bw: ", float(dl_bw_mhz))
            print("DL MODCOD: ", dl_modcod)
            print("UL Fc: ", float(ul_fc_mhz))
            print("UL MODCOD: ", ul_modcod)
            print(f"Pass-id: {next_id} \n")

        except Exception as e:
            print("Thats not a float, exiting")
            sys.exit(-1)
        
        confirm = input("Is this cool? Y/n").strip()

        if confirm == "" or confirm == "y" or confirm == "Y":
            df.at[index, "pass_id"] = next_id
            df.at[index, "dl_fc_mhz"] = float(dl_fc_mhz)
            df.at[index, "pass_state"] = "SCHEDULED_PLANNED"
            df.at[index, "dl_bw_mhz"] = float(dl_bw_mhz)
            df.at[index, "ul_fc_mhz"] = float(ul_fc_mhz)
            df.at[index, "ul_modcod"] = ul_modcod
            df.at[index, "dl_modcod"] = dl_modcod
            df.at[index, "tx_source"] = tx_source
            df.at[index, "comment"] = comment
            df.at[index, "fpga_image"] = fpga_image
            print(df.iloc[index:index+1].T)
            df.to_csv(schedule, index=False)
            continue
        else:
            print("Quitting")
            sys.exit(0)


if __name__ == "__main__":
    main()
