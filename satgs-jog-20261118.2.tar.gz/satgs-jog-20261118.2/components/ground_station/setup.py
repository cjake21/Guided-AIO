from pathlib import Path
import runpy

from setuptools import setup
from setuptools.command.build_py import build_py


class BuildPackage(build_py):
    def run(self):
        root = Path(__file__).parent
        if not (root / "src/satgs/jobs_msg_pb2.py").is_file():
            raise RuntimeError("Generate jobs_msg_pb2.py before building the package.")
        super().run()
        if getattr(self, "editable_mode", False):
            return
        layout = Path(self.build_lib) / "satgs/_package_layout.py"
        layout.write_text("INSTALLED = True\n", encoding="utf-8")
        target = Path(self.build_lib) / "satgs/data"
        target.mkdir(parents=True, exist_ok=True)
        self.copy_file(str(root / "config/deployment_profiles.json"), str(target / "deployment_profiles.json"))
        builder = runpy.run_path(str(root / "tools/build_operator_docs.py"), run_name="satgs_docs_build")
        builder["build"](root, target)


setup(cmdclass={"build_py": BuildPackage})
