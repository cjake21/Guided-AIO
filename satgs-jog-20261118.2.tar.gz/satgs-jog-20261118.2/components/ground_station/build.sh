#!/bin/bash

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEPLOYMENT_MODULE="$SCRIPT_DIR/src/satgs/deployment.py"
DEPLOYMENT_MANIFEST="$SCRIPT_DIR/config/deployment_profiles.json"

usage() {
    cat <<'EOF'
Usage: ./build.sh [--profile PROFILE] [--dry-run] [--non-interactive]
       ./build.sh --help

Profiles:
  full_msel       Install the legacy Full M-SEL package set.
  guided_arrow    Show the Guided Arrow AIO plan. Apply is not enabled in Slice 1.

Options:
  --profile PROFILE   Select full_msel or guided_arrow.
  --dry-run           Print the resolved plan without changing the system.
  --non-interactive   Require an explicit profile and never prompt.
  --help              Show this help text.

Exit status:
  0  Help or a successful supported operation.
  2  Argument, selection, profile, or manifest error before apply.
  3  The selected profile does not support apply.
  Full M-SEL apply returns 1 if it cannot enter the repository directory. A
  failed copy or package command's status is returned unchanged; those command
  statuses can overlap the values above.

A profile-less invocation in a terminal prompts for a profile. Outside a
terminal, a profile-less invocation selects legacy full_msel during the
compatibility period. Use --non-interactive with an explicit profile in automation.
EOF
}

argument_error() {
    printf 'Error: %s\n' "$1" >&2
    usage >&2
}

normalize_profile_choice() {
    case "$1" in
        ""|1)
            printf '%s\n' "full_msel"
            ;;
        2)
            printf '%s\n' "guided_arrow"
            ;;
        *)
            return 1
            ;;
    esac
}

prompt_for_profile() {
    local attempt
    local choice
    local normalized

    printf '%s\n' "Select a deployment profile:" >&2
    printf '%s\n' "  1. Full M-SEL" >&2
    printf '%s\n' "  2. Guided Arrow AIO" >&2
    for attempt in 1 2 3; do
        printf '%s' "Selection [1]: " >&2
        if ! IFS= read -r choice; then
            printf '%s\n' "Error: profile selection ended before a choice was read." >&2
            return 2
        fi
        if normalized="$(normalize_profile_choice "$choice")"; then
            printf '%s\n' "$normalized"
            return 0
        fi
        printf 'Invalid selection %q. Enter 1 or 2.\n' "$choice" >&2
    done
    printf '%s\n' "Error: too many invalid profile selections." >&2
    return 2
}

parse_arguments() {
    selected_profile=""
    profile_supplied=false
    dry_run=false
    non_interactive=false
    show_help=false
    local rendered_argument

    while (($# > 0)); do
        case "$1" in
            --profile)
                if [[ "$profile_supplied" == true ]]; then
                    argument_error "--profile may be specified only once."
                    return 2
                fi
                if (($# < 2)) || [[ "$2" == --* ]]; then
                    argument_error "--profile requires a value."
                    return 2
                fi
                selected_profile="$2"
                profile_supplied=true
                shift 2
                ;;
            --dry-run)
                if [[ "$dry_run" == true ]]; then
                    argument_error "--dry-run may be specified only once."
                    return 2
                fi
                dry_run=true
                shift
                ;;
            --non-interactive)
                if [[ "$non_interactive" == true ]]; then
                    argument_error "--non-interactive may be specified only once."
                    return 2
                fi
                non_interactive=true
                shift
                ;;
            --help)
                if [[ "$show_help" == true ]]; then
                    argument_error "--help may be specified only once."
                    return 2
                fi
                show_help=true
                shift
                ;;
            *)
                printf -v rendered_argument '%q' "$1"
                argument_error "unknown argument: $rendered_argument"
                return 2
                ;;
        esac
    done
}

validate_selected_profile() {
    python3 "$DEPLOYMENT_MODULE" validate-profile \
        --manifest "$DEPLOYMENT_MANIFEST" \
        --profile "$selected_profile"
}

print_deployment_plan() {
    python3 "$DEPLOYMENT_MODULE" plan \
        --manifest "$DEPLOYMENT_MANIFEST" \
        --profile "$selected_profile"
}

ensure_profile_apply_supported() {
    python3 "$DEPLOYMENT_MODULE" check-apply \
        --manifest "$DEPLOYMENT_MANIFEST" \
        --profile "$selected_profile"
}

run_full_msel_install() {
    cd "$SCRIPT_DIR" || return 1

    echo "Welcome to the MSEL Ground Station installation! Installing everything by default... "

    if [ -e "./config/config.yaml" ]; then
        echo "Existing installation detected... Skipping config file creation"
    else
        echo "New installation detected... Creating a config file from config_template.yaml"
        echo "WARNING: Go check and confirm the defaults are ok before running your ground station..."
        echo "Copying config_template.yaml -> config.yaml"
        cp ./config/config_template.yaml ./config/config.yaml || return $?
    fi

    if [ -e "./config/sat_db.csv" ]; then
        echo "Sat DB already exists... "
    else
        echo "Copying sat_db_template.csv -> sat_db.csv"
        cp ./config/sat_db_template.csv config/sat_db.csv || return $?
    fi

    if [ -e "./notebooks/error_profile.ipynb" ]; then
        echo "Error Profile Notebook already exists..."
    else
        echo "Copying error_profile_template.ipynb -> error_profile_template.ipynb"
        cp ./notebooks/error_profile_template.ipynb ./notebooks/error_profile.ipynb || return $?
    fi

    if [ -e "./notebooks/pass_plotter.ipynb" ]; then
        echo "Pass Plotter Notebook already exists..."
    else
        echo "Copying pass_plotter_template.ipynb -> pass_plotter.ipynb"
        cp ./notebooks/pass_plotter_template.ipynb ./notebooks/pass_plotter.ipynb || return $?
    fi

    if [ -e "./notebooks/quick_look.ipynb" ]; then
        echo "Quick Look Notebook already exists..."
    else
        echo "Copying quick_look_template.ipynb -> quick_look.ipynb"
        cp ./notebooks/quick_look_template.ipynb ./notebooks/quick_look.ipynb || return $?
    fi

    echo "Begin installing MSEL Ground Station software suite ..."
    python3 -m pip install -e 'lib/meteor-api[zmq]' || return $?
    python3 -m pip install -e '.[full]' || return $?
    python3 -m pip install -e lib/msel_post_processing || return $?
    python3 -m pip install -e lib/cyberpowerpdu || return $?
    python3 -m pip install -e lib/dsi_instruments || return $?
    python3 -m pip install -e 'lib/pixhawk[manager]' || return $?
    python3 -m pip install -e 'lib/sat_tracker[manager]' || return $?
    python3 -m pip install -e lib/sat_tracker/lib/serialptu || return $?
    python3 -m pip install -e lib/signal_hound || return $?
    python3 -m pip install lib/signal_hound/lib || return $?
}

main() {
    local apply_status

    if ! parse_arguments "$@"; then
        return 2
    fi

    if [[ "$show_help" == true ]]; then
        usage
        return 0
    fi

    if [[ "$non_interactive" == true && "$profile_supplied" == false ]]; then
        argument_error "--non-interactive requires an explicit --profile."
        return 2
    fi

    if [[ "$profile_supplied" == false ]]; then
        if [[ -t 0 ]]; then
            if ! selected_profile="$(prompt_for_profile)"; then
                return 2
            fi
        else
            selected_profile="full_msel"
            printf '%s\n' \
                "Warning: no profile supplied in a non-TTY environment; selecting legacy full_msel. Use --profile full_msel explicitly." \
                >&2
        fi
    fi

    if ! validate_selected_profile; then
        usage >&2
        return 2
    fi

    if [[ "$dry_run" == true ]]; then
        print_deployment_plan
        return $?
    fi

    ensure_profile_apply_supported
    apply_status=$?
    if ((apply_status != 0)); then
        return "$apply_status"
    fi

    run_full_msel_install
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    main "$@"
fi
