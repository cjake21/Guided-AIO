"""Build the fixed offline operator chapters without application imports."""

import argparse
import hashlib
import html
import json
from pathlib import Path
import re
import textwrap


CHAPTERS = (
    "operator-guide", "configurations", "component-handbook", "installation",
    "daily-operation", "station-location", "ptu-operation", "operator-tutorial",
    "results", "legacy-comparison", "updates-troubleshooting",
    "operator-cli-reference", "maintainer-reference",
)
INLINE = re.compile(r"`([^`]+)`|\[([^\]]+)\]\(([^)]+)\)|\*\*([^*]+)\*\*")
IMAGES = {
    "docs/assets/native-setup-20261112.png": "user-guide-setup.png",
    "docs/assets/native-ptu-20261112.png": "user-guide-ptu.png",
}
CSS = """:root { color-scheme: light; --ink: #182c35; --accent: #075b66; --rule: #b8cbd0; }
* { box-sizing: border-box; }
body { margin: 0; color: var(--ink); background: #f6f8f7; font: 1rem/1.65 system-ui, sans-serif; }
header, nav, main, footer { width: min(100% - 3rem, 76rem); margin-inline: auto; }
header { padding-block: 2.5rem 1rem; border-bottom: 4px solid var(--accent); }
header p { margin-block: .3rem; }
h1 { margin: 0; font-size: clamp(2rem, 5vw, 3rem); line-height: 1.15; }
nav { padding-block: 1.2rem; }
nav ol { display: grid; grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr)); gap: .6rem 2rem; padding-left: 1.5rem; }
nav a { display: inline-block; padding-block: .2rem; }
.chapter-navigation { display: flex; flex-wrap: wrap; gap: 1rem; padding-top: 1.5rem; }
main { background: #fff; padding: 1.5rem clamp(1rem, 4vw, 3rem); border: 1px solid var(--rule); }
section + section { border-top: 2px solid var(--rule); margin-top: 3rem; padding-top: 1rem; }
h2, h3, h4 { line-height: 1.25; scroll-margin-top: 1rem; }
h2 { font-size: 1.8rem; color: var(--accent); }
h3 { margin-top: 2rem; font-size: 1.25rem; }
p, li { max-width: 78ch; }
a { color: #064f91; text-underline-offset: .16em; overflow-wrap: anywhere; }
a:focus-visible, .table-scroll:focus-visible { outline: 3px solid #9b4a00; outline-offset: 4px; }
code, pre { font-family: ui-monospace, monospace; font-size: .92em; }
code { overflow-wrap: anywhere; }
pre { padding: 1rem; background: #eef3f4; border-left: 3px solid var(--accent); overflow-x: auto; line-height: 1.5; }
pre code { overflow-wrap: normal; }
img { max-width: 100%; height: auto; border: 1px solid var(--rule); }
.table-scroll { overflow-x: auto; margin-block: 1.5rem; }
table { border-collapse: collapse; width: 100%; min-width: 36rem; font-size: .95rem; }
th, td { border: 1px solid var(--rule); padding: .6rem .75rem; text-align: left; vertical-align: top; }
th { background: #e8f0f1; }
footer { padding-block: 1.5rem; }
.skip-link { position: absolute; top: -5rem; left: 1rem; padding: .75rem; background: white; }
.skip-link:focus { top: .5rem; }
@media (max-width: 600px) { header, nav, main, footer { width: calc(100% - 1.5rem); } nav ol { display: block; } nav li { margin-block: .5rem; } }
@media print { body { background: white; font-size: 10pt; } header, nav, main, footer { width: 100%; } main { padding: 0; border: 0; } pre { white-space: pre-wrap; overflow-wrap: anywhere; } table { min-width: 0; font-size: 8pt; } .table-scroll { overflow: visible; } .skip-link { display: none; } h2, h3 { break-after: avoid; } }
"""


def slug(value):
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def _target(destination, chapter):
    if destination.startswith("https://"):
        return destination
    if destination.startswith("#"):
        return "#" + chapter + "-" + destination[1:]
    name, marker, fragment = destination.partition("#")
    if name not in {item + ".md" for item in CHAPTERS}:
        raise ValueError("Unsupported guide link: " + destination)
    return "#" + name[:-3] + ("-" + fragment if marker else "")


def _inline(value, chapter, links):
    rendered = []
    cursor = 0
    for match in INLINE.finditer(value):
        rendered.append(html.escape(value[cursor:match.start()]))
        code, label, destination, strong = match.groups()
        if code is not None:
            rendered.append("<code>" + html.escape(code) + "</code>")
        elif label is not None:
            target = _target(destination, chapter)
            if target.startswith("#"):
                links.add(target[1:])
            rendered.append('<a href="' + html.escape(target, quote=True) + '">' + html.escape(label) + "</a>")
        else:
            rendered.append("<strong>" + html.escape(strong) + "</strong>")
        cursor = match.end()
    rendered.append(html.escape(value[cursor:]))
    return "".join(rendered)


def _plain(value):
    def replace(match):
        code, label, destination, strong = match.groups()
        if label is not None:
            return label + (" (optional external reference: " + destination + ")" if destination.startswith("https://") else "")
        return code if code is not None else strong
    return INLINE.sub(replace, value)


def _chapter(chapter, source, anchors, links):
    lines = source.splitlines()
    if not lines or not lines[0].startswith("# "):
        raise ValueError("A guide chapter must begin with one title: " + chapter)
    title = lines[0][2:]
    anchors.add(chapter)
    rendered = ['<section aria-labelledby="' + chapter + '"><h2 id="' + chapter + '">' + html.escape(title) + "</h2>"]
    plain = [title, "=" * len(title), ""]
    index = 1
    while index < len(lines):
        line = lines[index]
        if not line.strip():
            index += 1
            continue
        if line.startswith("```"):
            block = []
            index += 1
            while index < len(lines) and not lines[index].startswith("```"):
                block.append(lines[index])
                index += 1
            if index == len(lines):
                raise ValueError("Unclosed guide code block: " + chapter)
            rendered.append("<pre><code>" + html.escape("\n".join(block)) + "</code></pre>")
            plain.extend(block + [""])
        elif line.startswith("!["):
            image = re.fullmatch(r"!\[([^\]]+)\]\((assets/[a-z0-9-]+\.png)\)", line)
            if image is None or "docs/" + image.group(2) not in IMAGES:
                raise ValueError("Unsupported guide image: " + chapter)
            alternative = image.group(1)
            output = IMAGES["docs/" + image.group(2)]
            rendered.append('<p><img src="' + output + '" alt="' + html.escape(alternative, quote=True) + '"></p>')
            plain.extend([textwrap.fill("Screenshot: " + alternative, width=88), ""])
        elif line.startswith("## ") or line.startswith("### "):
            level = len(line) - len(line.lstrip("#"))
            heading = line[level + 1:]
            anchor = chapter + "-" + slug(heading)
            if anchor in anchors:
                raise ValueError("Duplicate guide heading: " + anchor)
            anchors.add(anchor)
            rendered.append(f'<h{level + 1} id="{anchor}">' + _inline(heading, chapter, links) + f"</h{level + 1}>")
            plain.extend([_plain(heading), "-" * len(_plain(heading)), ""])
        elif line.startswith("|"):
            table = []
            while index < len(lines) and lines[index].startswith("|"):
                table.append([cell.strip() for cell in lines[index].strip("|").split("|")])
                index += 1
            index -= 1
            if len(table) < 2 or not all(re.fullmatch(r":?-+:?", cell.replace(" ", "")) for cell in table[1]):
                raise ValueError("Malformed guide table: " + chapter)
            headings = table[0]
            if any(len(row) != len(headings) for row in table[2:]):
                raise ValueError("Inconsistent guide table columns: " + chapter)
            rendered.append('<div class="table-scroll" role="region" aria-label="' + html.escape(_plain(headings[0]), quote=True) + ' table" tabindex="0"><table><thead><tr>')
            rendered.extend('<th scope="col">' + _inline(cell, chapter, links) + "</th>" for cell in headings)
            rendered.append("</tr></thead><tbody>")
            for row in table[2:]:
                rendered.append("<tr>" + "".join("<td>" + _inline(cell, chapter, links) + "</td>" for cell in row) + "</tr>")
                plain.extend([textwrap.fill("; ".join(_plain(key) + ": " + _plain(cell) for key, cell in zip(headings, row)), width=88), ""])
            rendered.append("</tbody></table></div>")
        elif re.match(r"(?:\d+\.|-) ", line):
            ordered = line[0].isdigit()
            tag = "ol" if ordered else "ul"
            rendered.append("<" + tag + ">")
            while index < len(lines) and re.match(r"(?:\d+\.|-) ", lines[index]):
                item = re.sub(r"^(?:\d+\.|-) ", "", lines[index])
                index += 1
                while index < len(lines) and lines[index].startswith("   "):
                    item += " " + lines[index].strip()
                    index += 1
                rendered.append("<li>" + _inline(item, chapter, links) + "</li>")
                plain.append(textwrap.fill(_plain(item), width=88, initial_indent="- " if not ordered else "* ", subsequent_indent="  "))
            rendered.append("</" + tag + ">")
            plain.append("")
            index -= 1
        else:
            paragraph = [line]
            index += 1
            while index < len(lines) and lines[index].strip() and not lines[index].startswith(("#", "```", "|")):
                paragraph.append(lines[index])
                index += 1
            index -= 1
            paragraph = " ".join(paragraph)
            rendered.append("<p>" + _inline(paragraph, chapter, links) + "</p>")
            plain.extend([textwrap.fill(_plain(paragraph), width=88), ""])
        index += 1
    rendered.append("</section>")
    return title, "\n".join(rendered), "\n".join(plain)


def build(source_root, output_root):
    source_root, output_root = Path(source_root), Path(output_root)
    version_source = (source_root / "pyproject.toml").read_text(encoding="utf-8")
    version_match = re.search(r'^version\s*=\s*"([^"]+)"\s*$', version_source, re.MULTILINE)
    if version_match is None:
        raise ValueError("The guide requires the selected package version.")
    version = version_match.group(1)
    anchors, links, chapters, sources = set(), set(), [], {}
    for chapter in CHAPTERS:
        path = source_root / "docs" / (chapter + ".md")
        raw = path.read_bytes()
        sources["docs/" + path.name] = hashlib.sha256(raw).hexdigest()
        chapters.append((chapter, *_chapter(chapter, raw.decode("utf-8"), anchors, links)))
    screenshots = {}
    for source, output in IMAGES.items():
        screenshot = (source_root / source).read_bytes()
        if not screenshot.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("The guide screenshot must be the selected PNG asset: " + source)
        sources[source] = hashlib.sha256(screenshot).hexdigest()
        screenshots[output] = screenshot
    if links - anchors:
        raise ValueError("Unresolved guide links: " + ", ".join(sorted(links - anchors)))
    toc = "".join('<li><a href="#' + chapter + '">' + html.escape(title) + "</a></li>" for chapter, title, _, _ in chapters)
    sections = []
    for index, (chapter, _title, section, _plain_text) in enumerate(chapters):
        navigation = ['<a href="#contents">Contents</a>']
        if index:
            navigation.append('<a href="#' + chapters[index - 1][0] + '">Previous chapter</a>')
        if index + 1 < len(chapters):
            navigation.append('<a href="#' + chapters[index + 1][0] + '">Next chapter</a>')
        sections.append(section.removesuffix('</section>') + '<p class="chapter-navigation">'
                        + ' '.join(navigation) + '</p></section>')
    document = ('<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;; style-src &#39;self&#39;; img-src &#39;self&#39;; base-uri &#39;none&#39;; form-action &#39;none&#39;">'
        '<title>SATGS operator handbook</title><link rel="stylesheet" href="user-guide.css"></head><body>'
        '<a class="skip-link" href="#main">Skip to guide</a><header><h1>SATGS operator handbook</h1>'
        '<p>Offline operator reference</p><p>Application version ' + html.escape(version) + '</p></header>'
        '<nav id="contents" aria-label="Guide chapters"><ol>' + toc + '</ol></nav><main id="main">\n'
        + "\n".join(sections) + '\n</main><footer><a href="#contents">Back to contents</a></footer></body></html>\n')
    terminal = "SATGS user guide\nApplication version " + version + "\n\nContents\n" + "\n".join(str(index) + ". " + item[1] for index, item in enumerate(chapters, 1)) + "\n\n" + "\n\n".join(item[3] for item in chapters) + "\n"
    outputs = {"user-guide.html": document.encode("utf-8"), "user-guide.txt": terminal.encode("utf-8"),
               "user-guide.css": CSS.encode("utf-8"), **screenshots}
    manifest = {"schema": "satgs-offline-guide.v1", "application_version": version,
                "sources": sources, "outputs": {name: hashlib.sha256(value).hexdigest() for name, value in outputs.items()}}
    output_root.mkdir(parents=True, exist_ok=True)
    for name, value in outputs.items():
        (output_root / name).write_bytes(value)
    (output_root / "user-guide-manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    arguments = parser.parse_args()
    build(arguments.source_root, arguments.output_root)
