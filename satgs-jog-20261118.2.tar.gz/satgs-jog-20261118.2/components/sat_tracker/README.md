## General Installation

```
git clone ssh://git@git.codev.mitre.org/satgs/sat_tracker.git
cd sat_tracker
git submodule update --init

python3 -m venv .env
source .env/bin/activate
 
python3 -m pip install --upgrade pip
python3 -m pip install -e .
python3 -m pip install -e ./lib/serialptu
```

## Installed development packages

The checkout commands above are retained as legacy documentation. For the
installed development candidate, use non-editable wheels from the reviewed
local wheelhouse. Select `ptu_control==0.0.1` for clients or
`ptu_control[manager]==0.0.1` for a local manager or response profiler. The manager
extra adds serialptu and SciPy. Client dependencies retain the actual science
and satgs imports; selecting a client does not start a local manager.

This candidate requires Python 3.10 or newer because its client depends on
satgs. It declares Meteor 2.2.0 and protobuf 6.33.6 for this development
integration, without activating production pins or qualifying an interpreter.
Python 3.11 execution remains a separate validation requirement.

Before a normal setuptools build, explicitly generate
`src/ptu_control/ptu_msg_pb2.py` from `ptu_msg.proto` using the separately reviewed
pinned compiler and includes. A wheel build fails if that module is absent; it
does not download a compiler or generate code. Wheels contain the generated module
and schema, and source distributions include both. Compiler and installer tools
belong only in the isolated build environment. Installed-origin, dependency,
resource and behavior checks must establish the resulting artifact's validity.

## Strict pointing candidate

### Frozen operator location

An optional `settings["station_location"]` record contains exactly `source`,
`station_id`, `revision`, `latitude_deg`, `longitude_deg`, `altitude_m`,
`altitude_reference` and `coordinate_units`. Source remains `manual` or
`configured`; units are `degrees-metres`. The declared altitude reference is
retained, not inferred or converted. Coordinates must agree exactly with the
manager's `ground_station_lat`, `ground_station_lon` and `ground_station_altm`.
The immutable location and revision are included in the v3 policy binding and
used by the existing manager observer. Omitting this record retains v2 behavior.
This record is not a receiver fix, alignment change or navigation qualification.

### Mechanical bench owner

`PtuClient.open_bench` takes the same factory arguments as `open_pointing`.
`PtuManager.open_bench` takes the strict manager factory arguments except
`outcome_timeout`; the foreground owner then explicitly calls `activate`.
Both require a `bench_context` containing exactly `mode`, `equipment_label`,
`serial_port`, `baud`, `pan_min`, `pan_max`, `tilt_min`, `tilt_max`,
`max_change_degrees`, `observation_max_age_seconds` and
`exchange_timeout_seconds`. Supply every value from the reviewed setup, not
generic defaults. The actual driver port and baud must match independently.
The bench binding covers this entire context and the ordinary frozen policy.

Client operations are `connect`, `status`, `preview(pan, tilt)`,
`move(preview_sequence)`, `stop` and `disconnect`, each with explicit keyword
`deadline` and `cancel`. Results are immutable; `as_record()` returns exportable
values. Coordinates use `mechanical-pan-tilt-degrees.v1`. Preview reads position,
admits one axis within the explicit envelope, prepares the actual serial bytes
and checks the final encoded endpoint through the existing frozen policy.
Move consumes that preview once, checks its age and unchanged reported start,
and submits the same prepared bytes. It returns after the bounded exchange,
without holding a lock while travel is observed. Call `status` explicitly.
Known pre-existing serial replies are rejected rather than labeled current.

Only selected bench topics are admitted. Each sender has a monotonic sequence
that is retained across disconnect. Multiple connected clients share one serial
owner. Stop has a separate client request slot and latches before manager-lock
acquisition, gating later moves. It can use the original sealed serial owner
after an uncertain exchange, without opening another port or retrying movement.
Disconnect, close and process cancellation are passive, not physical Stop.

The real Messenger receiver calls subscribers synchronously. The bench callback
therefore only validates and fills one fixed regular slot or one priority Stop
slot. One manager-owned worker performs the serial exchanges. Stop is selected
before later regular work, but cannot preempt an exchange already in a native
write/read. Queue time consumes the original exchange deadline. Full slots
reject further admission without resending; the caller records its timeout.
Close gates work, drops unsent slots and joins this worker under the cleanup
deadline before passive owner release. A join failure retains cleanup debt.

The source-supported stop primitive is zero-velocity JOG with stop bit `0x02`,
without reset or limit override. Unit-specific physical semantics are not yet
qualified. Operational Move and Stop therefore return `unsupported`; a mode
string cannot bypass this gate. Manager construction in either mode is rejected
by default and requires a private test boundary patched only around controlled
serial and Messenger fixtures. It is not a live commissioning admission.

Raw status bytes, observation time and observation sequence are retained.
Position remains `protocol-reported-unqualified`; an ACK, matching coordinate
or a manager observation sequence cannot prove wire freshness, measured arrival
or physical stopping. The protocol has no request ID. Outcomes preserve
`possible_motion` and `physical_state=indeterminate` after possible submission.
Exact allocated-unit documentation and operator readiness are still required
before adding a supported live motion contract. No automatic park, home,
calibration, tracking or retry is introduced.

The APIs below are a provisional development candidate. They do not enable an installed service, select a production owner map, qualify a deployment or authorize motion. The installation instructions above are not validation of this candidate or its dependency pins. This documentation was contributed by an author of the strict client, not by an independent acceptance reviewer.

### Admitted frozen policy

Both the client and the separately trusted manager construct their own `PointingPolicy` from admitted inputs. A received binding never replaces the manager's restrictions.

Select exactly one positive signed-int32 positioner ID from `settings["positioners"]`. Its existing `protocol` is `PTCR20` or `PTCR96`, `cont_rot` is an exact boolean, and finite limits satisfy `-360 <= hard_pan_lim_ccw < hard_pan_lim_cw <= 360`. The selected row's `pointing_context` contains exactly:

| Key | Required value |
| --- | --- |
| `frame` | `azimuth-elevation-degrees.v1` |
| `run_id` | A trusted, never-reused lowercase 64-hex run identity |
| `configuration_generation`, `calibration_generation` | Positive signed-int64 integers |
| `pan_to_az` | Actual finite calibration in [-360, 360] degrees |
| `tilt_to_el` | Actual finite calibration in [0, 180] degrees |
| `protocol_address` | None for PTCR20; the actual supported PTCR96 address |
| `tle_sha256` | Lowercase SHA-256 hex of the exact admitted TLE text |

The current strict driver supports PTCR96 address zero, not every byte-address variant. The separate elevation mask must be finite and in [0, 90). Booleans are not numeric inputs. Calibration and context are explicit, not defaulted.

`no_go_data=None` means no rectangle. Otherwise it must contain exactly `{"nogozones": [{"az_min": ..., "az_max": ..., "el_min": ..., "el_max": ...}]}`, with one rectangle satisfying `0 <= az_min < az_max < 360` and `0 <= el_min < el_max <= 90`. Interior, edges and corners are all forbidden. Negative/wrap-crossing rectangles and malformed data do not mean “no restriction.”

The trusted admission owner must consume any selected `no_go_config` file before construction, validate its bytes, pass the admitted rectangle as `no_go_data`, and remove the selected path or set it to None. Do not discard a configured restriction by clearing a path without consuming it. Strict factories do not read or monitor policy files. Strict admission rejects an unconsumed non-None selected path, including when separate inline data is also supplied. Replacing the original file or mutating the caller's mapping cannot update the frozen policy; use a new trusted run/context.

The binding is a 32-byte SHA-256 digest of the `ptu-pointing-binding.v2` sorted compact ASCII record covering the selected manager, run, generations, frame, protocol, limits, calibration, rotation, elevation mask, rectangle and TLE digest. Numeric values use exact ratios. Equal admitted int/float values bind identically. Binding is consistency fencing, not authentication, secrecy, replay protection or proof of operator authority. The v2 tag fences v1/v2 strict peers in both directions at the existing bound handshake because prime correlation changes the strict contract; it does not allocate a production release.

The schema adds only these fields; existing field numbers and types remain:

| Message | Field |
| --- | --- |
| `PositionCommandMsg` | `bytes pointing_binding = 5` |
| `TleLoadCmd` | `bytes pointing_binding = 2` |
| `TlePrimeCmd` | `bytes pointing_binding = 4`, `bytes prime_sender_id = 5`, `uint64 prime_sequence = 6` |
| `PingCmd`, `PongResponse` | `bytes pointing_binding = 2` |
| `TleReplyMsg` | `bytes pointing_binding = 4` |
| `PositionerStatus` | `bytes pointing_binding = 11`, `bytes prime_sender_id = 12`, `uint64 prime_sequence = 13` |

Use genuinely generated protobuf modules from this schema, not hand-edited generated files or replacement message classes.

### Client lifecycle

`PtuClient.open_pointing(messenger=..., settings=..., ptu_id=..., elevation_mask=..., log_dir=..., no_go_data=..., deadline=..., cancel=...)` returns an inert owner after admission. The Messenger must be the supported exact bounded Messenger instance and compatible with the supplied settings. The factory obtains one private 16-byte sender identity using `os.urandom`, with deadline/Event checks before and after; native entropy is not promised preemptible. `log_dir` is an absolute native Path without parent traversal; the strict PTU client does not create log files. Record its `close(deadline=...)` before activation.

The supported methods are:

- `check_connection(*, deadline, cancel)`: activate three selected-ID reply/status registrations, then wait for matching selected-ID/binding pong. True is a matching observation, not hardware readiness.
- `load_tle(text, *, deadline, cancel)`: require connectivity, send unchanged admitted text, and wait for a matching positive reply. Text is at most 4096 printable ASCII characters, exactly three nonempty comma-separated parts, and must match `tle_sha256`. The client does not qualify the orbit.
- `prime(azimuth, elevation, *, deadline, cancel)`: require loaded state and publish the selected bound prime request. True means local publication succeeded, not that the manager accepted, completed or physically executed it.
- `ptu_move_to(azimuth, elevation, force_cw=False, force_ccw=False, ptu_id=None, *, deadline, cancel)` and `ptu_send_position(...)`: publish a selected bound direct request and return the checked protobuf-represented endpoint. Omitted ID means the admitted ID; broadcast zero and other IDs reject. Force flags are exact booleans and cannot both be true. There is no direct-motion acknowledgement in this interface.
- `validateCoordinates(azimuth, elevation)`: pure early policy/binary32 validation; it does not contact the manager, check the serial encoding or authorize motion.
- `diagnostics()` and `close(*, deadline)`: fixed local status/debt and passive cleanup.

`ptu_is_primed`, `tle_load_success` and `connection_status` contain only the selected ID. Prime readiness requires a `tle_primed` or `tle_tracking` observation matching the selected manager, run binding, private sender identity and current prime sequence. A synchronous observation remains provisional until local publication succeeds. Old, foreign or missing correlation cannot set readiness for a later request.

After existing operation/state-lock control admission, each prime clears prior readiness and consumes a new positive uint64 sequence before endpoint or connected/loaded validation. Rejection, failed or cancelled publication and later lifecycle calls never roll it back. Load, reconnect and close do not reset the sender or counter. Sequence exhaustion clears readiness and rejects without wrapping; no request is published. Invocation controls that fail before lock admission do not mutate callback state.

The manager requires an exact 16-byte sender and a positive uint64 sequence on both direct host and serialized prime routes, rejecting bool/non-int sequences and non-bytes identities on direct calls. After binding, controls and loaded/primed state admission, it claims the sender and consumes the sequence before endpoint/planning work. A request rejected before that admission is not consumed. It retains the claimed sender and highest consumed prime sequence across load and close for its run. Gaps are permitted; duplicate, older and foreign-sender prime requests reject before affected work. A replacement client therefore requires a new trusted run context, not a reset to sequence one in the same run. This finite prime replay fence is not authentication or remote cancellation. Correlation attributes an observation to a request, not to a later instant: it does not order same-request statuses or prove present device health. Pong and TLE reply windows still have no request correlation. Timestamps, packet acknowledgements and a ready flag are not physical safety evidence.

Client calls take a finite absolute `time.monotonic()` deadline and an exact built-in `threading.Event`. A distinct live Event may be used per operation. Do not clear an Event while an invocation using it remains active; transient set/clear cycles are not latched. Checks do not renew the supplied budget. The client does not set the borrowed Messenger's lifecycle Event or call its close method, and operation cancellation does not implicitly unregister already-owned callbacks. The Messenger/lower contract can still terminally fail a shared transport after an uncertain wire-progress or receiver-startup failure; independent operation Events do not waive those hazards. Client Events/deadlines are not transmitted as remote manager controls.

Callbacks parse bounded actual protobuf bytes, require selected identity/binding, and do not wait on a contended client state lock. Close gates future callbacks, waits within its supplied deadline, removes exact owned registrations with an internal fresh Event, and retains incomplete cleanup debt for a later explicit close. It never closes the borrowed Messenger or sends abort, reset or park. Retain the owner after activation/cleanup failure. Unsupported inherited logging, worker, calibration, reset, park and wrapper routes reject on the strict client.

### Manager lifecycle and actual encoded endpoints

`PtuManager.open_pointing(messenger=..., settings=..., ptu_id=..., driver=..., elevation_mask=..., no_go_data=..., run_deadline=..., cancel=...)` returns a separate inert strict owner. The manager also admits finite station latitude, longitude and altitude from its trusted settings.

Transfer one exclusively owned, fresh strict `PTU(..., pointing=True)` driver at successful factory return. Before that return the caller retains its cleanup responsibility. Do not share the driver concurrently, use it through a legacy manager, or bind it elsewhere. Public `pointing_available` is a freshness observation, not an atomic reservation. The manager rejects already-bound/unavailable or incompatible drivers. It owns passive driver close; its Messenger remains borrowed.

`activate(*, deadline, cancel)` claims the driver binding before serial open, obtains a checked nonmoving status observation, and installs fixed selected/broadcast routes. Activation retains ownership before effects, so failed activation still needs close. Only selected bound ping/direct/TLE/prime commands are admitted. Broadcast motion and calibration, abort, park, error injection and other legacy routes do not bypass strict ownership. The strict owner has no legacy run loop or implicit worker.

The host can call `load_tle(text, *, binding, deadline, cancel)`, `prime_ptu(azimuth, elevation, *, binding, prime_sender_id, prime_sequence, deadline, cancel)`, `move_to_az_el(azimuth, elevation, force_cw=False, force_ccw=False, *, binding, deadline, cancel)`, `track_once(at, *, binding, deadline, cancel)`, and `invalidate(*, deadline, cancel)`. Use `manager.policy.binding` only for the independently admitted manager record. `track_once` requires a built-in datetime whose tzinfo is `timezone.utc`; the host explicitly schedules it. It returns False after a computed below-mask completion without parking.

Manager operations require the original lifecycle Event and use the smaller of the supplied absolute deadline and admitted run deadline. Callbacks use those trusted manager-run controls, not remote client deadlines. Explicit invalidation is terminal and cannot renew the run budget. `close(*, deadline)` is separate passive cleanup under its supplied close deadline, using an internal fresh Event; it can be retried for retained debt even after run cancellation/expiry. No automatic compensation follows failure.

The client checks both candidate floats and their actual protobuf binary32 representation. The manager applies its own policy, the established planner/converter, and the actual PTCR20/PTCR96 encoder. It decodes the prepared packet into integer pan/tilt counts, checks the exact rational world endpoint against limits, elevation and inclusive no-go bounds, then submits those same immutable bytes under the driver generation lock. It does not duplicate rounding arithmetic, substitute a perimeter point or infer a safe margin. For example, an early-valid noncontinuous PTCR20 request at azimuth 289.96 degrees can encode to forbidden 290 degrees and must be rejected before a move write.

All finite prime targets, including the initial elevation target and any forced-direction intermediates, are prepared and checked before the first move write. Each submission rechecks the same frozen context and generation. Later tracking targets use the same final gate individually. An observed binding-relevant context change or completed explicit invalidation fences pending work; restoring a value cannot revive an invalidated generation. Private mutation and restoration outside this supported protocol is not a tracked configuration history.

Prime waits for protocol-reported pan/tilt to equal each encoded endpoint before publishing primed state. This is a bounded software position observation, not proof of settled movement, mechanical stopping, native response accuracy or clearance of the intervening path. Two individually admitted endpoints can have a path through a forbidden rectangle.

Manager `PointingError` carries fixed `primary`, `submitted` and `submission` fields. `submitted` counts this operation's move exchanges that returned successfully before failure (at most four). `submission` is the failing serial exchange's wire disposition: `none`, `partial`, `complete` or `unknown`. That exchange may be a nonmoving status poll; this is not a whole-operation result. A later manager-only check or publication failure has `submission=none`, even when earlier moves succeeded. For example, observation-time cancellation after one returned move can report `(submitted=1, submission='none')`, and a status-publication failure after two can report `(2, 'none')`. Conversely, a complete first write with missing response can report `(0, 'complete')`. Always inspect both fields. `last_outcome` retains the fixed code/count/disposition tuple; successful motion submission records `('submitted', count, 'complete')`. These fields do not count physical movements. A failure with prior/uncertain effects invalidates further strict movement; there is no retry, rollback or compensating park.

### Modes, compatibility and validation limits

Inert factory construction and `validateCoordinates` acquire no transport/serial/file resources. Client connectivity and TLE operations use the broker but issue no move request. Manager activation opens serial and performs a reviewed nonmoving status exchange, so it is not an offline probe. Prime, direct requests and explicit tracking are motion-capable. Passive close does not stop a device that is already moving.

Legacy constructors and CLI entry points remain separate. Legacy manager subscriptions retain broadcast behavior and add selected-ID TLE load/prime routes. Updated legacy handlers reject nonempty strict bindings. Old peers cannot qualify the strict handshake because their replies lack the binding. This does not retrofit strict endpoint enforcement onto legacy operations. Do not mix both ownership modes on one device.

The installed development metadata above declares the selected runtime dependencies and separates manager extras from client requirements. Earlier isolated evidence used its own explicitly provisioned compiler/runtime and real generated messages; it does not validate these new package artifacts. Tests include client lifecycle, manager pointing/addressing and the serial driver's prepared-command cases; their recording serial/public-Messenger/scientific fixtures are disclosed. A fixture pass is not a real broker, serial device or production service pass. Native calls cannot be made preemptible by software deadline checks. Python 3.11, target architectures, native astronomy, hardware timing, deployment and physical behavior require separate qualification. No test or acceptance result is asserted by this README.

### Explicit correlated scheduling

The preceding client/manager behavior remains the standalone strict contract.
The development runner selects an additive scheduled mode. Before client
activation call `enable_scheduled_tracking(*, deadline, cancel)`. The manager
must have been independently constructed with finite `outcome_timeout` in
(0, 3] seconds. This enables selected-only `ScheduledCommand` and
`ScheduledOutcome` topics and immediately fences legacy/direct motion routes.
Omitting it preserves standalone behavior. An old manager cannot satisfy the
new handshake and is not silently downgraded to uncorrelated operation.

CONNECT, LOAD, PRIME, TRACK and COMPLETE share one positive uint64 sequence
and the existing private sender and frozen policy binding. CONNECT claims a
single sender for the manager run. Old/duplicate sequences do not repeat work.
No queue, automatic retry or internal scheduling thread is added. The runner
owns cadence and invocation lifetime; TRACK carries neither an endpoint nor a
caller timestamp. The actual manager calculates current UTC, runs its existing
tracking transform and submits the same checked prepared command. PRIME still
prevalidates every finite intermediate endpoint before its first move.

`prime` returns after local publication, with any early outcome provisional
until publication returns in time. Scheduled readiness requires the matching
successful committed PRIME/TRACK outcome. `track` and `complete_tracking`
wait under the caller's original local controls. COMPLETE and a below-mask
TRACK are terminal software completion with no park, reset or additional move.
Every failed scheduled operation terminal-gates subsequent strict motion;
old successes and legacy status cannot revive it.

`tracking_outcome()` exposes the last immutable correlated manager report;
`tracking_failure()` independently retains an admitted local failure. Each
report carries current successful move-exchange count, failing exchange
disposition, cumulative successful count and sticky possible submission.
Earlier counts survive later rejection/deadline/cancellation. The wire report
also carries manager, request binding, manager binding, sender, sequence and
operation identity. Unexpected scheduler exceptions become the fixed
`scheduler_failure` category, without exception text. No count establishes
physical movement, completed travel or stopping.

Manager motion retains its original lifecycle Event and absolute run deadline.
The separately admitted outcome timeout is only for best-effort nonmotion
report publication after failure; it does not extend the driver budget.
`outcome_published` means local message submission, not client receipt.
If the borrowed transport has independently terminated, reporting can fail.
Client cancellation and passive close do not cancel remote work. A retained
old report is not an upper bound on later unobserved manager submissions.

The protobuf amendment adds two new message types and two new selected topics,
without renumbering or repurposing legacy fields. Generate genuine modules;
do not mix scheduled and standalone ownership on one device. Runtime compiler
installation, production release-map activation and physical qualification
are not implied by this development interface.
