"""Selected bench manager; imported only by the physical owner factory."""

import threading
import time
from collections.abc import Mapping

from meteor_api.messenger import Messenger
from serialptu.acquisition import SerialSettings, SerialDeviceIdentity, ReadbackContext as DriverContext
from serialptu.ptu import PTU

from ptu_control import bench as _bench_module
from ptu_control import ptu_msg_pb2 as pb
from ptu_control.bench import BenchContext, ReadbackContext, ManualContext
from ptu_control.bench_operations import _BenchOperations
from ptu_control.constants import Topics
from ptu_control.pointing import PointingError
from ptu_control.ptu_manager import _PointingManager


class BenchManager(_BenchOperations, _PointingManager):
    def __init__(self, *, messenger, settings, ptu_id, driver, elevation_mask=None, no_go_data=None,
                 run_deadline, cancel):
        if type(self) is not BenchManager or not isinstance(settings, Mapping):
            raise PointingError("invalid_argument")
        if "readback_context" in settings or "manual_context" in settings:
            self._deadline(run_deadline, cancel)
            if (elevation_mask is not None or no_go_data is not None
                    or not _bench_module._mechanical_messenger_compatible(messenger, settings)
                    or type(driver) is not PTU or driver.pointing_available is not True):
                raise PointingError("invalid_argument")
            context_type = ManualContext if "manual_context" in settings else ReadbackContext
            self._bench = context_type.from_settings(settings, ptu_id)
            expected = DriverContext(self._bench.protocol, 10, self._bench.protocol_address,
                                    SerialSettings(**self._bench.serial_settings),
                                    SerialDeviceIdentity(**self._bench.device_identity))
            capability = "manual" if self._bench.motion_allowed else "readback"
            if driver.readback_context != expected or driver.serial_capability != capability:
                raise PointingError("policy_mismatch")
            self._policy = self._location = None
            self._initialize_lifecycle(messenger, driver, run_deadline, cancel)
        else:
            super().__init__(messenger, settings, ptu_id, driver, elevation_mask,
                             no_go_data, run_deadline, cancel)
            self._bench = BenchContext.from_settings(settings, self._policy)
            if _bench_module._controlled_rehearsal_boundary(driver, messenger) is not True:
                raise PointingError("unsupported")
            serial = driver.pointing_serial_context
            if serial[:2] != (self._bench.serial_port, self._bench.baud):
                raise PointingError("policy_mismatch")
        self._manager_id = ptu_id
        self._bench_senders = {}
        self._bench_connected = set()
        self._bench_previews = {}
        self._bench_observation = None
        self._bench_observation_sequence = 0
        self._bench_stop_pending = threading.Event()
        self._bench_stop_count = 0
        self._bench_priority = threading.Lock()
        self._bench_possible_motion = False
        self._bench_motion_active = False
        self._bench_stop_failed = False
        self._bench_registration = None
        self._bench_slots = threading.Condition()
        self._bench_regular_slot = None
        self._bench_priority_slot = None
        self._bench_worker = None
        self._bench_worker_started = False
        self._bench_shutdown = threading.Event()
        self._bench_exchanges = []

    def activate(self, *, deadline, cancel):
        if self._policy is None:
            with self._locked(deadline, cancel) as deadline:
                if not self._active:
                    if self._handle is not None:
                        raise PointingError("context_changed")
                    try:
                        bind = self._driver.bind_manual if self._bench.motion_allowed else self._driver.bind_readback
                        self._handle = bind(self._bench.binding, deadline=deadline, cancel=cancel)
                        self._driver.open_bounded(deadline=deadline, cancel=cancel)
                        self._check(deadline, cancel)
                        self._state = "connected"
                        self._active = True
                    except BaseException as error:
                        self._invalid = True
                        self.last_outcome = ("activation", 0, "none")
                        if getattr(error, "primary", None) == "device-busy":
                            raise PointingError("busy") from None
                        if getattr(error, "primary", None) in ("device-identity", "serial-context"):
                            raise PointingError("policy_mismatch") from None
                        raise self._translated(error) from None
            result = True
        else:
            result = super().activate(deadline=deadline, cancel=cancel)
        if self._bench_registration is None:
            registration = ("{}_{}".format(Topics.BENCH_COMMAND, self._manager_id), self._bench_cb, "bench")
            self._bench_registration = registration
            self._registrations.append(registration)
            self.messenger.subscribe(*registration, deadline=deadline, cancel=cancel)
            self._bench_worker = threading.Thread(target=self._bench_work, name="ptu-bench-owner", daemon=False)
            self._bench_worker.start()
            self._bench_worker_started = True
        elif self._bench_worker is None or not self._bench_worker.is_alive():
            raise PointingError("context_changed")
        return result

    def close(self, *, deadline):
        self._closing.set()
        self._bench_shutdown.set()
        with self._bench_slots:
            self._bench_slots.notify_all()
        if self._bench_worker_started:
            self._bench_worker.join(max(0, deadline - time.monotonic()))
            if self._bench_worker.is_alive():
                raise PointingError("cleanup_incomplete")
        return super().close(deadline=deadline)

    def _bench_work(self):
        try:
            while not self._bench_shutdown.is_set() and not self._cancel.is_set():
                with self._bench_slots:
                    while self._bench_priority_slot is None and self._bench_regular_slot is None:
                        if self._bench_shutdown.is_set() or self._cancel.is_set() or time.monotonic() >= self._run_deadline:
                            return
                        self._bench_slots.wait(min(.01, self._run_deadline - time.monotonic()))
                    if self._bench_shutdown.is_set():
                        return
                    if self._bench_priority_slot is not None:
                        command, deadline = self._bench_priority_slot
                        self._bench_priority_slot = None
                    else:
                        command, deadline = self._bench_regular_slot
                        self._bench_regular_slot = None
                self._bench_publish(self._bench_execute(command, deadline, cancel=self._cancel))
        except BaseException:
            self._bench_shutdown.set()
            self._invalid = True
            self.last_outcome = ("worker_failure", 0, "unknown")
        finally:
            self._bench_shutdown.set()
            with self._bench_slots:
                self._bench_priority_slot = self._bench_regular_slot = None
            with self._bench_priority:
                self._bench_stop_count = 0
                self._bench_stop_pending.clear()

    def _command_cb(self, payload, identifier):
        self.rejected = min(self.rejected + 1, 2**31 - 1)

    def _admit_command(self, binding, deadline, cancel):
        raise PointingError("unsupported")

    def _bench_cb(self, body, identifier):
        try:
            if identifier != "bench" or type(body) is not bytes or not 0 < len(body) <= 8192:
                raise ValueError("command")
            command = pb.BenchCommand.FromString(body)
            if (len(command.sender) != 16 or command.binding != self._bench.binding
                    or not 0 < command.sequence < 2**64
                    or command.operation not in range(1, 7)
                    or self._bench.mode == "query-only" and command.operation not in (
                        pb.BenchCommand.CONNECT, pb.BenchCommand.STATUS, pb.BenchCommand.DISCONNECT)):
                raise ValueError("command")
            known = pb.BenchCommand()
            known.CopyFrom(command)
            known.DiscardUnknownFields()
            allowed = {1, 2, 3, 4} | ({5, 6} if command.operation == pb.BenchCommand.PREVIEW else
                                      {7} if command.operation == pb.BenchCommand.MOVE else set())
            if (known.SerializeToString() != command.SerializeToString()
                    or any(field.number not in allowed for field, value in command.ListFields())):
                raise ValueError("command")
        except Exception:
            self.rejected = min(self.rejected + 1, 2**31 - 1)
            return
        deadline = min(self._run_deadline, time.monotonic() + self._bench.exchange_timeout_seconds)
        with self._bench_slots:
            if self._closing.is_set() or self._bench_shutdown.is_set() or not self._active:
                self.rejected = min(self.rejected + 1, 2**31 - 1)
                return
            if (self._policy is None and command.operation == pb.BenchCommand.STOP
                    and command.sender not in self._bench_connected):
                self.rejected = min(self.rejected + 1, 2**31 - 1)
                return
            previous = self._bench_senders.get(command.sender)
            if previous is not None and command.sequence <= previous:
                self.rejected = min(self.rejected + 1, 2**31 - 1)
                return
            if command.operation == pb.BenchCommand.STOP:
                if self._bench_priority_slot is not None:
                    self.rejected = min(self.rejected + 1, 2**31 - 1)
                    return
                with self._bench_priority:
                    self._bench_stop_count += 1
                    self._bench_stop_pending.set()
                self._bench_priority_slot = (command, deadline)
            else:
                if self._bench_regular_slot is not None:
                    self.rejected = min(self.rejected + 1, 2**31 - 1)
                    return
                self._bench_regular_slot = (command, deadline)
            self._bench_slots.notify()

    def _bench_publish(self, message):
        try:
            self.messenger.publish("{}_{}".format(Topics.BENCH_OUTCOME, self._manager_id),
                message.SerializeToString(), deadline=time.monotonic() + self._bench.exchange_timeout_seconds,
                cancel=threading.Event())
        except Exception:
            self.last_outcome = ("outcome_unavailable", 0, message.submission)
