import yaml
import os
import math
from google.protobuf.message import DecodeError
from ptu_control.pointing import PointingPolicy, PointingError
from ptu_control.tracking import CATEGORIES, STATES, SUBMISSIONS, MAX_SEQUENCE, TrackingOutcome
import csv
import logging
import time
import argparse
import threading
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd
from typing import Union

from ptu_control import ptu_msg_pb2 as ptu_pb
from ptu_control.constants import Topics, DEFAULTS as PTU_DEFAULTS
from ptu_control.utils import ptu_move_msg_from_pb, convert_to_ptu_frame, PositionerStatus, NoGoZone
from meteor_api.messenger import Messenger, MessengerError

from satgs.constants import DEFAULTS

DEFAULT_CFG = Path('~/ground_station/config/config.yaml').expanduser()

class PtuClient:
    '''
    Client for interacting with the Quickset positioner over active MQ. This 
    client communicates with a manager connected to the actual hardware that 
    manages the serial interface to the device. Both manager and client communicate
    via the active MQ broker. 
    '''
    @classmethod
    def open_pointing(cls, *, messenger, settings, ptu_id, elevation_mask,
                      log_dir, no_go_data, deadline, cancel):
        if cls is not PtuClient:
            raise PtuError('admission')
        return _PointingClient._open(messenger, settings, ptu_id, elevation_mask,
                                    log_dir, no_go_data, deadline, cancel)

    @classmethod
    def open_bench(cls, **options):
        from ptu_control.bench import BenchClient
        return BenchClient.open(**options)

    def close(self, *, deadline):
        if type(self) is not _PointingClient:
            raise PtuError('legacy-path')
        return self._close(deadline)

    def enable_scheduled_tracking(self, *, deadline, cancel):
        if type(self) is not _PointingClient:
            raise PtuError('legacy-path')
        return self._enable_scheduled(deadline, cancel)

    def track(self, *, deadline, cancel):
        if type(self) is not _PointingClient or not self._scheduled:
            raise PtuError('admission')
        return self._schedule(ptu_pb.ScheduledCommand.TRACK, deadline, cancel)

    def complete_tracking(self, *, deadline, cancel):
        if type(self) is not _PointingClient or not self._scheduled:
            raise PtuError('admission')
        return self._schedule(ptu_pb.ScheduledCommand.COMPLETE, deadline, cancel)

    def tracking_outcome(self):
        if type(self) is not _PointingClient:
            raise PtuError('legacy-path')
        return self._scheduled_result

    def tracking_failure(self):
        if type(self) is not _PointingClient:
            raise PtuError('legacy-path')
        return self._scheduled_local_failure

    def __init__(self, 
                 messenger:Messenger, 
                 config:Path, 
                 elevation_mask:float = DEFAULTS.elev_mask, 
                 test_mode = False, 
                 ptu_id:int = 0,
                 cmd_log_file:Path=None, 
                 status_log_file:Path=None):
        """Client for interacting with the Quickset positioner over active MQ.

        Args:
            messenger (Messenger): Messenger interface
            elevation_mask (float, optional): Minimum elevation. Defaults to 5.
            test_mode (bool, optional): If true, actual interactions with the
                manager are faked. This is only used for testing. 
                Defaults to False.
            no_go_config (Path, optional): Path to YAML file describes NO GO ZONES
                These are areas the dish is prohibited to point at. If None, there 
                are no avoided zones and steering is only limited by the PTU
                hard and soft limits. Defaults to None.
            cmd_log_file (Path, optional): If specified, commands are logged to 
                this file. If unspecified, nothing is logged. 
                Defaults to None.
            status_log_file (Path, optional): If specified, commands are logged to 
                this file. If unspecified, nothing is logged. 
                Defaults to None.
        """
        
        self.test_mode = test_mode
        self.messenger = messenger
        # Load config File
        with open(config) as f:
            self.config = yaml.safe_load(f)
        ptu_ids = []
        ptu_dict = {}
        for positioner in self.config['positioners']:
            if (ptu_id == 0) or (ptu_id == positioner['id']):
                ptu_dict[positioner['id']] = positioner
                ptu_ids.append(positioner['id'])
                
        self.ptu_dict = ptu_dict
        self.ptu_ids  = ptu_ids
        self.ptu_states = {id:"" for id in self.ptu_ids}        
        self.connection_status = {id:False for id in self.ptu_ids}
        self.ptu_status = {id:PositionerStatus('free', None, id) for id in self.ptu_ids}
        self.prev_status_time = {id:None for id in self.ptu_ids}
        self.ptu_is_primed = {id:False for id in self.ptu_ids}        
        
        for id in self.ptu_ids:
            self.messenger.subscribe("{}_{}".format(Topics.PTU_STATUS, id), self.ptu_status_cb, "")        
            self.messenger.subscribe("{}_{}".format(Topics.PONG_RESPONSE, id), self.pong_cmd_cb, "")        
            self.messenger.subscribe("{}_{}".format(Topics.CALIBRATION_STATUS, id), self.cal_status_cb, "")        
            self.messenger.subscribe("{}_{}".format(Topics.TLE_LOAD_REPLY, id), self.tle_reply_cb, "")        
            self.messenger.subscribe("{}_{}".format(Topics.ERROR_PROFILE_REPLY, id), self.error_profile_reply_cb, "")        

        self.elevation_mask = elevation_mask
        self.park_status = {id:False for id in self.ptu_ids}        
         
        self.cmd_log_file = None
        self.is_logging = False
        self.prev_command_times = {id:0 for id in self.ptu_ids}
        if cmd_log_file is not None:
            if ~cmd_log_file.parent.exists():
                cmd_log_file.parent.mkdir(parents=True, exist_ok=True)            
            self.cmd_log_file = {}
            self.cmd_csv_writer = {}
            for id in self.ptu_ids:
                tdir = cmd_log_file.parent
                tstem = cmd_log_file.stem
                tsuffix = cmd_log_file.suffix
                self.cmd_log_file[id] = open(tdir / f"{tstem}_PTU_{id}{tsuffix}", 'w+')
                self.cmd_csv_writer[id] = csv.writer(self.cmd_log_file[id], delimiter=',')
                self.cmd_csv_writer[id].writerow(['utc_time', 'cmd_azimuth', 'cmd_elevation', 'cmd_pan', 'cmd_tilt']) 
            
        self.status_log_file = None
        if status_log_file is not None:
            if ~status_log_file.parent.exists():
                status_log_file.parent.mkdir(parents=True, exist_ok=True)                   
            self.status_log_file = {}
            self.status_csv_writer = {}            
            for id in self.ptu_ids:
                tdir = status_log_file.parent
                tstem = status_log_file.stem
                tsuffix = status_log_file.suffix
                self.status_log_file[id] = open(tdir / f"{tstem}_PTU_{id}{tsuffix}", 'w+')                
                self.status_csv_writer[id] = csv.writer(self.status_log_file[id], delimiter=',')
                self.status_csv_writer[id].writerow(['utc_time', 'ptu_pan', 'ptu_tilt', 'ptu_az', 'ptu_el'])    
                
                           
        
    def clean_exit(self):
        '''
        Ensures that the PTU is parked if ctrl+c is ever called
        '''
        logging.warning("Exiting")
        self.publish_wrapper("{}_0".format(Topics.ABORT_COMMAND),ptu_pb.TleResetCmd(reset=True))
        time.sleep(0.1)

        self.park_ptu()
        if self.cmd_log_file is not None:
            for id in self.ptu_ids:
                logging.info("Closing log file {}".format(self.cmd_log_file[id].name))
                self.cmd_log_file[id].close()        
        if self.status_log_file is not None:  
            for id in self.ptu_ids:                  
                logging.info("Closing log file {}".format(self.status_log_file[id].name))
                self.status_log_file[id].close()  
    
    def reset_ptu(self, timeout=5):
        logging.info("Sending Reset Command")
        self.publish_wrapper("{}_0".format(Topics.ABORT_COMMAND),ptu_pb.TleResetCmd(reset=True))
        wait_start = time.time()
        all_reset = all(ptu_state == "free" for ptu_state in self.ptu_states.values())
        while not all_reset:
            all_reset = all(ptu_state == "free" for ptu_state in self.ptu_states.values())        
            if (time.time() - wait_start)>timeout:
                logging.error("Failed to reset all PTUs")
                logging.error("PTU States: {}".format(self.ptu_states))
                break
            time.sleep(1)             
              
    def start_logging(self):
        self.is_logging = True
    
    def stop_logging(self):
        self.is_logging = False
        
    def error_profile_reply_cb(self, msg:str, id:int):
        logging.info("Error Profile ack received")                
        reply = ptu_pb.ErrorProfileReply()
        reply.ParseFromString(msg)
        
        self.error_profile_ack[reply.ptu_id] = reply.success
        if not reply.success:
            logging.error("PTU {} failed to ack profile: {}".format(reply.ptu_id, reply.msg))
        else:
            logging.info("PTU {} ack'd error profile".format(reply.ptu_id))                                   
        
    def send_pointing_error_profile(self, duration=60*5, error_range_deg= 4,
                                    rate_deg_per_sec = 0.25, pad_time = 0,
                                    rotation_rate_dps = 0.9,#90/(60*5/6), 
                                    timeout = 5, ptu_id = 0):
        logging.info("Sending Params for a pointing error profile")
        self.error_profile_ack = {id:False for id in self.ptu_ids}        

        self.publish_wrapper("{}_{}".format(Topics.ERROR_PROFILE_COMMAND, ptu_id), 
                             ptu_pb.ErrorProfileCmd(
                                duration = duration,
                                error_range_deg = error_range_deg,
                                rate_deg_per_sec = rate_deg_per_sec,
                                rotation_rate_dps = rotation_rate_dps,
                                pad_time = pad_time)
                             )   
        # Non Blocking... Maybe hacky but lets see. 
        thread_obj = threading.Thread(target=self.check_error_profile_ack)
        thread_obj.start()
        # self.check_error_profile_ack()
        
    def check_error_profile_ack(self, timeout=30):
        
        wait_start = time.time()   
        while not all(self.error_profile_ack.values()):
            if (time.time() - wait_start)>timeout:
                logging.error("Did not get ack of error profile all PTUs")
                logging.error(self.error_profile_ack)
                break
            time.sleep(1)        
        
    def tle_reply_cb(self, msg:str, id:int):
        reply = ptu_pb.TleReplyMsg()
        reply.ParseFromString(msg)
        
        self.tle_load_success[reply.ptu_id] = reply.success
        if not reply.success:
            logging.error("PTU {} failed to load TLE: {}".format(reply.ptu_id, reply.msg))
        else:
            logging.info("PTU {} loaded TLE successfully".format(reply.ptu_id))
        
    def load_tle(self, tle_str:str):
        logging.info("Sending TLE to PTU Managers")
        self.tle_load_success = {id:False for id in self.ptu_ids}        
        self.publish_wrapper("{}_0".format(Topics.TLE_LOAD_COMMAND), ptu_pb.TleLoadCmd(tle_str=tle_str))
        #This should be blocking. Want to make sure this happens
        self.check_tle_load()
    
    def check_tle_load(self, timeout=15):
        wait_start = time.time()
        while not all(self.tle_load_success.values()):
            if (time.time() - wait_start)>timeout:
                logging.error("Failed to load TLE for all PTUs in allotted time")
                logging.error(self.tle_load_success)
                break
            time.sleep(1)  
    
    def shutdown(self):
        logging.info("Unsubscribing.... ")
        self.messenger.cancelSubscribe(Topics.PTU_STATUS, self.ptu_status_cb, "")
        self.messenger.cancelSubscribe(Topics.PONG_RESPONSE, self.pong_cmd_cb, "")
        self.messenger.cancelSubscribe(Topics.CALIBRATION_STATUS, self.cal_status_cb, "")                           

    def pong_cmd_cb(self, msg:str, id:int):
        """Call back for when Pong is received from manager service/ python process
        """  
        pong_msg = ptu_pb.PongResponse()
        pong_msg.ParseFromString(msg)
                   
        logging.info("Pong Received. ID {}".format(pong_msg.pong))      
        self.got_pong = True     

    def check_connection(self, timeout:int=5)->bool:
        """Sends a ping to the manager service/python process. Returns True if 
        it gets a response, False otherwise. Waits 5 seconds for response

        Args:
            timeout (int, optional):  Defaults to 5.

        Returns:
            bool: True is gets response from manager service/ python process
        """
        connection_status = {id:False for id in self.ptu_ids}
        for ptu_id in self.ptu_ids:
            logging.info("Pinging PTU {} Manager, will wait {} seconds for response".format(ptu_id, timeout))      
            self.publish_wrapper("{}_{}".format(Topics.PING_CMD, ptu_id), ptu_pb.PingCmd(ping=True))
            self.got_pong = False
            start_time = time.time()
            while not self.got_pong:
                if time.time()-start_time>timeout:
                    logging.error("Did not get response from PTU {} in alloted time. Could be issue with activemq, or sat_tracker.service on server side".format(ptu_id))
                    connection_status[ptu_id]=False
                    break
                if self.test_mode:
                    logging.info("PTU {} ready. Running in test mode (no interaction with PTU Manager)".format(ptu_id))
                    connection_status[ptu_id]=True
                    break                    
            connection_status[ptu_id]=self.got_pong
        if not (all(connection_status.values())):
            logging.error("Did not get response from all Managers")    
            logging.error("Pong Status: {}".format(connection_status))
        return all(connection_status.values())
    
    def cal_status_cb(self, msg:str, id:int)->bool:
        cal_status_msg = ptu_pb.CalibrationStatus()
        cal_status_msg.ParseFromString(msg)        
        logging.info("Calibration Response Received from PTU {}".format(cal_status_msg.ptu_id))      
        self.cal_done[cal_status_msg.ptu_id] = True
        self.cal_success[cal_status_msg.ptu_id] = cal_status_msg.cal_success
        self.cal_msg[cal_status_msg.ptu_id] = cal_status_msg.msg
        if not self.cal_success[cal_status_msg.ptu_id]:
            logging.error("Cal Failed for PTU {}: {}".format(cal_status_msg.ptu_id, cal_status_msg.msg))
        else:
            logging.info("Cal Succeeded for PTU {}: {}".format(cal_status_msg.ptu_id, cal_status_msg.msg))
        return cal_status_msg.cal_success
        
    def calibrate_ptu(self, timeout=70)-> bool:
        logging.info("Sending Cal message to HW manager, takes up to 1 minute")      
        self.publish_wrapper("{}_0".format(Topics.CALIBRATE_COMMAND), ptu_pb.CalibrateCommand(do_cal=1))
        self.cal_done = {id:False for id in self.ptu_ids}
        self.cal_success = {id:False for id in self.ptu_ids}
        self.cal_msg = {id:"" for id in self.ptu_ids}

        start_time = time.time()
        logging.info("Waiting for positioner to calibrate")        
        while not all(self.cal_done.values()):
            if time.time()-start_time>timeout:
                logging.error("Did not get response in alloted time. Could be issue with HW manager")
                logging.error("{}".format(self.cal_done))
                return False
            if self.test_mode:
                logging.info("Running in no test mode (no interaction with PTU Manager)")
                self.cal_done = True
                self.cal_success = True   
        return self.cal_success
    
    def parked(self) -> bool:
        '''
        Determines if the PTU is in the parked position
        '''
        if self.test_mode:
            logging.warning("Queried in Test mode [not getting any replies from manager], assume its parked")            
            return True #{id:True for id in self.ptu_ids}
        
        for id in self.ptu_ids:
            wrapped_ptu_pos = (self.ptu_status[id].azimuth + 180) % 360 - 180
            ptu_park_status = (abs(wrapped_ptu_pos - PTU_DEFAULTS.PARK_PTU_AZ) < 3) and (abs(self.ptu_status[id].elevation - PTU_DEFAULTS.PARK_PTU_EL) < 3) 
            logging.debug("PTU {}: Az value: {:.2f}, El value: {:.2f}, Parked? {}".format(id, wrapped_ptu_pos, self.ptu_status[id].elevation, ptu_park_status))            
            self.park_status[id] = ptu_park_status
        return all(self.park_status.values())

    def validateCoordinates(self, azimuth, elevation):
        '''Validates if the Az/El coordinates are within the range we want to track.
        '''
        # Az/El in the ephem frame of reference in Degrees
        valid = (elevation >= self.elevation_mask and elevation <= 180 - self.elevation_mask)
        return valid
        
    def ptu_move_to(self, azimuth, elevation, force_cw:bool=False, force_ccw:bool=False, ptu_id=0)->tuple:
        '''
        Send command to move the positioner to a specific Az/El. The client will 
        adjust for NO GO Zones and send the "adjusted" positions to the manager. 
        The manager will translate these Az/Els to clockwise/counter clockwise 
        pan tilt values. 
        If the commanded positions exceed the hard limits of the positioner, 
        the manager will limit/cap the commanded pan/tilt appropriately. 
        '''
        azimuth = ((azimuth+180)%360)-180
        
        # adj_az, adj_el = self.no_go_zone.adjust_for_zone(azimuth, elevation)

        if not self.test_mode:
            self.ptu_send_position(azimuth, elevation, force_cw, force_ccw, ptu_id)          
        return azimuth, elevation
    
    def prime(self, azimuth:float, elevation:float)->tuple:
        """Primes the positioner. This is usually called from the parked position
        First tilt the positioner up to the requested elevation, and is allowed
        up to 30 seconds for this. 
        Next the positioner will pan requested az. It is alloted another 30 seconds
        for this. So in all this can take up to 1 minute but in reality is usually faster
        
        Args:
            azimuth (float): _description_
            elevation (float): _description_

        Returns:
            tuple: _description_
        """
        self.all_ptus_primed = {id:False for id in self.ptu_ids}
        self.publish_wrapper("{}_0".format(Topics.TLE_PRIME_COMMAND), 
                             ptu_pb.TlePrimeCmd(prime=True, azimuth=azimuth, elevation=elevation))

    def park_ptu(self, park_time = 90):
        """Parks the PTU. First the positioner is tiled to 35 degrees elevation, 
        then pans to 0 deg North. Then tilts down to 0 deg elevation. 
        This procedure was chosen to avoid panning at ground interferers near 
        the horizon. 
        """
        # Move up to 30 deg so we avoid low elevation stuff in no go zones.
        if self.parked(): 
            logging.info("Already Parked")
            return

        logging.info("Sending Park Command")        
        self.publish_wrapper("{}_0".format(Topics.PARK_COMMAND),ptu_pb.ParkCmd(park=True))        
        park_start = time.time()
        self.park_status = {id:False for id in self.ptu_ids}        
        while not self.parked():
            time.sleep(1)
            if (time.time() - park_start)> park_time:
                logging.warning("Did not complete parking in {} seconds. Moving on.".format(park_time))                
                logging.warning("Park Status: {}".format(self.park_status))
                return
                                        
    def ptu_send_position(self, azimuth:float, elevation:float, force_cw:bool=False, force_ccw:bool=False, ptu_id=0):
        """Sends position command to active MQ server

        Args:
            azimuth (float): _description_
            elevation (float): _description_
        """
        msg = ptu_pb.PositionCommandMsg()
        msg.azimuth = azimuth
        msg.elevation = elevation
        msg.force_cw = force_cw
        msg.force_ccw = force_ccw
        self.messenger.publish("{}_{}".format(Topics.PTU_POSITION_COMMAND, ptu_id), msg,priority=9)
        logging.debug("Sent command to point at {:0.2f} az, {:0.2f} el".format(msg.azimuth, msg.elevation, msg.force_cw, msg.force_ccw))

    def ptu_status_cb(self, msg, id):
        '''
        Callback PTU status messages that convey where the positioner think it's 
        at. Pan/Tilt values are very precise. The Az/El values depend on the 
        accuracy of survey/ calibration which is a function of the GPS compass 
        accuracy. Usually good to < 1 deg accuracy. 
        '''
        ptuStatusMsg = ptu_pb.PositionerStatus()
        ptuStatusMsg.ParseFromString(msg)
        ptu_position_status = ptu_move_msg_from_pb(msg)
        
        # logging.debug("PTU Status:\n%s" % ptuStatusMsg)
        logging.debug(ptu_position_status.print())       

        self.ptu_status[ptu_position_status.id] = ptu_position_status           
        self.ptu_states[ptu_position_status.id] = ptu_position_status.state
        if (ptu_position_status.state=='tle_primed') or (ptu_position_status.state=='tle_tracking'):
            self.ptu_is_primed[ptu_position_status.id] = True
        else:
            self.ptu_is_primed[ptu_position_status.id] = False
                        
        self.prev_status_time[ptu_position_status.id] = time.time()
        if self.status_log_file is not None and self.is_logging:
            if not self.status_log_file[ptu_position_status.id].closed:
                t_stamp = ptu_position_status.timestamp.ToDatetime()     
                utc_t_stamp = t_stamp.replace(tzinfo=timezone.utc)                
                self.status_csv_writer[ptu_position_status.id].writerow(
                    [utc_t_stamp.isoformat(), 
                     ptuStatusMsg.pan, ptuStatusMsg.tilt, 
                     ptuStatusMsg.azimuth, ptuStatusMsg.elevation])
        if self.cmd_log_file is not None and self.is_logging:
            if not self.cmd_log_file[ptu_position_status.id].closed and ptu_position_status.command is not None:
                t_stamp = ptu_position_status.command.timestamp.ToDatetime()     
                utc_t_stamp = t_stamp.replace(tzinfo=timezone.utc)           
                if self.prev_command_times[ptu_position_status.id] != utc_t_stamp: #ptu_position_status.command.timestamp.ToDatetime()                
                    self.cmd_csv_writer[ptu_position_status.id].writerow(
                        [utc_t_stamp, #ptu_position_status.command.timestamp.ToDatetime(tzinfo=timezone.utc).isoformat(), 
                        ptu_position_status.command.azimuth, ptu_position_status.command.elevation, 
                        ptu_position_status.command.azimuth, ptu_position_status.command.elevation ])                

    def publish_wrapper(self, topic, msg):
        '''
        Catches exceptions from publish. Useful if the remote AMQ server 
        restarts (or something like that). The Messenger object handles reconnecting.
        '''
        try:
            self.messenger.publish(topic, msg)
        except Exception as e:
            logging.info("Exception when sending message to ActiveMQ Broker.", exc_info = e)

_POINTING_CLIENT_CODES = ('admission', 'deadline', 'cancelled', 'closed', 'state',
                         'activation', 'rejected', 'legacy-path', 'unsupported')
_POINTING_CLIENT_DEBT = ('active-operation', 'active-callback', 'registration-debt')
_POINTING_CLIENT_PATH = type(Path())
_POINTING_CLIENT_MAX_BODY = 8192


class PtuError(Exception):
    def __init__(self, primary, cleanup=()):
        self.primary = primary if primary in _POINTING_CLIENT_CODES else 'state'
        self.cleanup = tuple(item for item in _POINTING_CLIENT_DEBT if item in cleanup)
        Exception.__init__(self, self.primary)


def _client_deadline(deadline):
    valid = type(deadline) in (int, float)
    if valid:
        try:
            valid = math.isfinite(deadline)
        except OverflowError:
            valid = False
    if not valid:
        raise PtuError('admission')


def _client_remaining(deadline, cancel):
    _client_deadline(deadline)
    if type(cancel) is not threading.Event:
        raise PtuError('admission')
    if cancel.is_set():
        raise PtuError('cancelled')
    remaining = deadline - time.monotonic()
    if cancel.is_set():
        raise PtuError('cancelled')
    if remaining <= 0:
        raise PtuError('deadline')
    return min(.010, remaining)


class _PointingClient(PtuClient):
    @property
    def ptu_is_primed(self):
        if not getattr(self, '_scheduled', False):
            return self._readiness
        result = self._scheduled_result
        publication = self._scheduled_publication
        ready = (result is not None and publication == (result.sequence, True)
                 and result.category == 'ok' and result.state in ('tle_primed', 'tle_tracking')
                 and not self._closing.is_set() and not self._scheduled_terminal.is_set())
        return {self.ptu_id: ready}

    @ptu_is_primed.setter
    def ptu_is_primed(self, value):
        self._readiness = value

    @classmethod
    def _open(cls, messenger, settings, ptu_id, elevation_mask, log_dir,
              no_go_data, deadline, cancel):
        _client_remaining(deadline, cancel)
        if (type(log_dir) is not _POINTING_CLIENT_PATH or not log_dir.is_absolute()
                or len(str(log_dir)) > 4096 or '..' in log_dir.parts
                or type(messenger) is not Messenger):
            raise PtuError('admission')
        policy = PointingPolicy.from_settings(settings, ptu_id, elevation_mask, no_go_data)
        if messenger.strict_instance_compatible(settings) is not True:
            raise PtuError('admission')
        _client_remaining(deadline, cancel)
        try:
            sender_id = os.urandom(16)
        except Exception:
            sender_id = None
        _client_remaining(deadline, cancel)
        if type(sender_id) is not bytes or len(sender_id) != 16:
            raise PtuError('admission')
        return cls._allocate(messenger, policy.manager_id, policy, sender_id, deadline, cancel)

    @classmethod
    def _allocate(cls, messenger, manager_id, policy, sender_id, deadline, cancel):
        owner = object.__new__(cls)
        owner.messenger = messenger
        owner._policy = policy
        owner.ptu_id = manager_id
        owner.ptu_ids = (manager_id,)
        owner.ptu_dict = {manager_id: {'id': manager_id}}
        owner.elevation_mask = policy.elevation_mask if policy is not None else None
        owner.ptu_states = {manager_id: 'unobserved'}
        owner.ptu_status = {}
        owner.ptu_is_primed = {manager_id: False}
        owner.tle_load_success = {manager_id: False}
        owner.connection_status = {manager_id: False}
        owner._operation = threading.Lock()
        owner._state = threading.Lock()
        owner._closing = threading.Event()
        owner._pong = threading.Event()
        owner._pong_window = threading.Event()
        owner._reply = threading.Event()
        owner._load_window = threading.Event()
        owner._reply_success = False
        owner._connected = False
        owner._loaded = False
        owner._prime_sender_id = sender_id
        owner._prime_sequence = 0
        owner._expected_prime = None
        owner._prime_sent = False
        owner._prime_observed = False
        owner._priming = False
        owner._fault = None
        owner._closed = False
        owner._activated = False
        owner._scheduled = False
        owner._scheduled_sequence = 0
        owner._scheduled_pending = None
        owner._scheduled_result = None
        owner._scheduled_publication = None
        owner._scheduled_local_failure = None
        owner._scheduled_terminal = threading.Event()
        owner._scheduled_event = threading.Event()
        owner._registrations = []
        owner._rejected = 0
        owner._callbacks = (
            ('{}_{}'.format(Topics.PONG_RESPONSE, owner.ptu_id), owner._receive_pong, ''),
            ('{}_{}'.format(Topics.TLE_LOAD_REPLY, owner.ptu_id), owner._receive_tle, ''),
            ('{}_{}'.format(Topics.PTU_STATUS, owner.ptu_id), owner._receive_status, ''),
        )
        _client_remaining(deadline, cancel)
        return owner

    def _check(self, deadline, cancel, passive=False):
        remaining = _client_remaining(deadline, cancel)
        if not passive:
            if self._closing.is_set():
                raise PtuError('closed')
            if self._fault is not None:
                raise PtuError(self._fault)
        return remaining

    def _lock(self, lock, deadline, cancel, passive=False):
        while True:
            remaining = self._check(deadline, cancel, passive)
            if lock.acquire(timeout=remaining):
                try:
                    self._check(deadline, cancel, passive)
                except BaseException:
                    lock.release()
                    raise
                return

    def _activate(self, deadline, cancel):
        if self._activated:
            return
        try:
            for registration in self._callbacks:
                self._check(deadline, cancel)
                self._registrations.append(registration)
                self.messenger.subscribe(*registration, deadline=deadline, cancel=cancel)
                self._check(deadline, cancel)
            self._activated = True
        except BaseException:
            if self._registrations:
                self._fault = 'activation'
            raise

    def check_connection(self, *, deadline, cancel):
        if self._scheduled:
            result = self._schedule(ptu_pb.ScheduledCommand.CONNECT, deadline, cancel)
            return result.category == "ok"
        self._lock(self._operation, deadline, cancel)
        try:
            self._activate(deadline, cancel)
            self._lock(self._state, deadline, cancel)
            try:
                self._connected = False
                self.connection_status[self.ptu_id] = False
                self._pong.clear()
                self._pong_window.set()
            finally:
                self._state.release()
            self._check(deadline, cancel)
            self.messenger.publish('{}_{}'.format(Topics.PING_CMD, self.ptu_id),
                ptu_pb.PingCmd(ping=True, pointing_binding=self._policy.binding).SerializeToString(),
                deadline=deadline, cancel=cancel)
            while True:
                remaining = self._check(deadline, cancel)
                if self._pong.is_set():
                    self._connected = True
                    self.connection_status[self.ptu_id] = True
                    return True
                self._pong.wait(remaining)
        finally:
            self._pong_window.clear()
            self._operation.release()

    def load_tle(self, tle_str, *, deadline, cancel):
        if self._scheduled:
            result = self._schedule(ptu_pb.ScheduledCommand.LOAD, deadline, cancel, tle=tle_str)
            return result.category == "ok"
        self._lock(self._operation, deadline, cancel)
        try:
            admitted = self._policy.validate_tle(tle_str)
            if not self._connected:
                raise PtuError('state')
            self._lock(self._state, deadline, cancel)
            try:
                self._loaded = False
                self.tle_load_success[self.ptu_id] = False
                self.ptu_is_primed[self.ptu_id] = False
                self._prime_sent = self._prime_observed = self._priming = False
                self._expected_prime = None
                self._reply_success = False
                self._reply.clear()
                self._load_window.set()
            finally:
                self._state.release()
            self._check(deadline, cancel)
            self.messenger.publish('{}_{}'.format(Topics.TLE_LOAD_COMMAND, self.ptu_id),
                ptu_pb.TleLoadCmd(tle_str=admitted,
                    pointing_binding=self._policy.binding).SerializeToString(),
                deadline=deadline, cancel=cancel)
            while True:
                remaining = self._check(deadline, cancel)
                if self._reply.is_set():
                    if not self._reply_success:
                        raise PtuError('rejected')
                    self._loaded = True
                    self.tle_load_success[self.ptu_id] = True
                    return True
                self._reply.wait(remaining)
        finally:
            self._load_window.clear()
            self._operation.release()

    def _target(self, message_type, azimuth, elevation, **options):
        azimuth, elevation = self._policy.check_endpoint(azimuth, elevation)
        message = message_type(azimuth=azimuth, elevation=elevation,
                               pointing_binding=self._policy.binding, **options)
        wire = message.SerializeToString()
        decoded = message_type()
        decoded.ParseFromString(wire)
        represented = self._policy.check_endpoint(decoded.azimuth, decoded.elevation)
        return wire, represented

    def validateCoordinates(self, azimuth, elevation):
        if self._closing.is_set() or self._fault is not None:
            return False
        try:
            self._target(ptu_pb.PositionCommandMsg, azimuth, elevation,
                         force_cw=False, force_ccw=False)
        except PointingError:
            return False
        return True

    def prime(self, azimuth, elevation, *, deadline, cancel):
        if self._scheduled:
            self._schedule(ptu_pb.ScheduledCommand.PRIME, deadline, cancel,
                           azimuth=azimuth, elevation=elevation, wait=False)
            return True
        self._lock(self._operation, deadline, cancel)
        try:
            self._lock(self._state, deadline, cancel)
            try:
                self._priming = self._prime_sent = self._prime_observed = False
                self._expected_prime = None
                self.ptu_is_primed[self.ptu_id] = False
                if self._prime_sequence >= 2 ** 64 - 1:
                    raise PtuError('state')
                self._prime_sequence += 1
                sequence = self._prime_sequence
            finally:
                self._state.release()
            try:
                wire, _ = self._target(ptu_pb.TlePrimeCmd, azimuth, elevation, prime=True,
                                      prime_sender_id=self._prime_sender_id,
                                      prime_sequence=sequence)
                if not self._connected or not self._loaded:
                    raise PtuError('state')
                self._lock(self._state, deadline, cancel)
                try:
                    self._expected_prime = (self._prime_sender_id, sequence)
                    self._priming = True
                finally:
                    self._state.release()
                self._check(deadline, cancel)
                self.messenger.publish('{}_{}'.format(Topics.TLE_PRIME_COMMAND, self.ptu_id),
                    wire, deadline=deadline, cancel=cancel)
                self._lock(self._state, deadline, cancel)
                try:
                    self._prime_sent = True
                    self.ptu_is_primed[self.ptu_id] = self._prime_observed
                    self._check(deadline, cancel)
                finally:
                    self._state.release()
            except BaseException:
                self._priming = self._prime_sent = self._prime_observed = False
                self._expected_prime = None
                self.ptu_is_primed[self.ptu_id] = False
                raise
            return True
        finally:
            self._operation.release()


    def _enable_scheduled(self, deadline, cancel):
        self._lock(self._operation, deadline, cancel)
        try:
            if self._activated or self._scheduled:
                raise PtuError('state')
            self._lock(self._state, deadline, cancel)
            try:
                self._scheduled = True
                self._callbacks += (('{}_{}'.format(Topics.SCHEDULED_OUTCOME, self.ptu_id),
                                     self._receive_outcome, ''),)
            finally:
                self._state.release()
            return True
        finally:
            self._operation.release()

    def _schedule(self, operation, deadline, cancel, *, tle="", azimuth=0, elevation=0, wait=True):
        self._lock(self._operation, deadline, cancel)
        admitted = False
        try:
            self._activate(deadline, cancel)
            self._lock(self._state, deadline, cancel)
            try:
                if (self._scheduled_terminal.is_set() or self._scheduled_pending is not None
                        or (operation != ptu_pb.ScheduledCommand.CONNECT and not self._connected)
                        or (operation in (ptu_pb.ScheduledCommand.PRIME, ptu_pb.ScheduledCommand.TRACK,
                                          ptu_pb.ScheduledCommand.COMPLETE) and not self._loaded)):
                    raise PtuError('state')
                admitted = True
                if self._scheduled_sequence >= MAX_SEQUENCE:
                    self._scheduled_terminal.set()
                    self._scheduled_local_failure = 'state'
                    raise PtuError('state')
                self._scheduled_sequence += 1
                self._scheduled_publication = (self._scheduled_sequence, False)
                self._scheduled_pending = (self._scheduled_sequence, operation)
                self._scheduled_event.clear()
                admitted = True
            finally:
                self._state.release()
            if operation == ptu_pb.ScheduledCommand.LOAD:
                tle = self._policy.validate_tle(tle)
            if operation == ptu_pb.ScheduledCommand.PRIME:
                azimuth, elevation = self._policy.check_endpoint(azimuth, elevation)
            message = ptu_pb.ScheduledCommand(operation=operation,
                request_binding=self._policy.binding, sender=self._prime_sender_id,
                sequence=self._scheduled_sequence, tle=tle, azimuth=azimuth, elevation=elevation)
            if operation == ptu_pb.ScheduledCommand.PRIME:
                self._policy.check_endpoint(message.azimuth, message.elevation)
            self._check(deadline, cancel)
            self.messenger.publish('{}_{}'.format(Topics.SCHEDULED_COMMAND, self.ptu_id),
                message.SerializeToString(), deadline=deadline, cancel=cancel)
            self._check(deadline, cancel)
            self._scheduled_publication = (message.sequence, True)
            if not wait:
                return None
            while not self._scheduled_event.wait(self._check(deadline, cancel)):
                pass
            self._check(deadline, cancel)
            result = self._scheduled_result
            if result is None or result.sequence != message.sequence:
                raise PtuError('state')
            if result.category != 'ok':
                raise PtuError('rejected')
            self._lock(self._state, deadline, cancel)
            try:
                if operation == ptu_pb.ScheduledCommand.CONNECT:
                    self._connected = True
                    self.connection_status[self.ptu_id] = True
                elif operation == ptu_pb.ScheduledCommand.LOAD:
                    self._loaded = True
                    self.tle_load_success[self.ptu_id] = True
            finally:
                self._state.release()
            return result
        except BaseException as error:
            if admitted:
                self._scheduled_terminal.set()
                remote_failure = (isinstance(error, PtuError) and error.primary == 'rejected'
                    and self._scheduled_result is not None
                    and self._scheduled_result.sequence == self._scheduled_sequence
                    and self._scheduled_result.category != 'ok')
                if not remote_failure:
                    primary = getattr(error, 'primary', 'state')
                    self._scheduled_local_failure = primary if primary in _POINTING_CLIENT_CODES else 'state'
            raise
        finally:
            self._operation.release()

    def _receive_outcome(self, body, identifier):
        if not self._callback_lock():
            return
        try:
            if (not self._scheduled or self._scheduled_terminal.is_set()
                    or type(identifier) is not str or identifier != ''
                    or type(body) is not bytes or not 0 < len(body) <= _POINTING_CLIENT_MAX_BODY):
                self._reject_message()
                return
            message = ptu_pb.ScheduledOutcome()
            try:
                message.ParseFromString(body)
            except (DecodeError, ValueError):
                self._reject_message()
                return
            previous = self._scheduled_result
            total = previous.total_submitted if previous else 0
            possible = previous.possible_submission if previous else False
            expected_states = {
                ptu_pb.ScheduledCommand.CONNECT: ('free',),
                ptu_pb.ScheduledCommand.LOAD: ('tle_loaded',),
                ptu_pb.ScheduledCommand.PRIME: ('tle_primed',),
                ptu_pb.ScheduledCommand.TRACK: ('tle_tracking', 'complete'),
                ptu_pb.ScheduledCommand.COMPLETE: ('complete',),
            }
            maximum = (4 if message.operation == ptu_pb.ScheduledCommand.PRIME else
                       1 if message.operation == ptu_pb.ScheduledCommand.TRACK else 0)
            if (self._scheduled_pending != (message.sequence, message.operation)
                    or message.manager_id != self.ptu_id
                    or message.request_binding != self._policy.binding
                    or message.sender != self._prime_sender_id
                    or len(message.manager_binding) != 32
                    or (message.manager_binding != self._policy.binding and message.category != 'policy_mismatch')
                    or message.category not in CATEGORIES or message.state not in STATES
                    or message.submitted > maximum or message.submission not in SUBMISSIONS
                    or (message.category == 'ok' and (message.submission != 'none'
                        or message.state not in expected_states.get(message.operation, ())))
                    or (message.category == 'ok' and (
                        message.operation == ptu_pb.ScheduledCommand.PRIME and message.submitted not in (2, 4)
                        or message.operation == ptu_pb.ScheduledCommand.TRACK and
                        message.submitted != (1 if message.state == 'tle_tracking' else 0)))
                    or message.total_submitted != total + message.submitted
                    or message.possible_submission != bool(possible or message.submitted or message.submission != 'none')):
                self._reject_message()
                return
            if self._scheduled_terminal.is_set():
                self._reject_message()
                return
            self._scheduled_result = TrackingOutcome(message.manager_id, message.sequence,
                message.operation, message.category, message.state, message.submitted,
                message.submission, message.total_submitted, message.possible_submission)
            self._scheduled_pending = None
            if message.category != 'ok' or message.state == 'complete':
                self._scheduled_terminal.set()
            self.ptu_states[self.ptu_id] = message.state
            self._scheduled_event.set()
        finally:
            self._state.release()

    def _send_position(self, azimuth, elevation, force_cw, force_ccw, ptu_id, deadline, cancel):
        if self._scheduled:
            raise PtuError('state')
        self._lock(self._operation, deadline, cancel)
        try:
            if ptu_id is not None and (type(ptu_id) is not int or ptu_id != self.ptu_id):
                raise PtuError('admission')
            self._policy.check_forces(force_cw, force_ccw)
            wire, represented = self._target(ptu_pb.PositionCommandMsg, azimuth, elevation,
                                             force_cw=force_cw, force_ccw=force_ccw)
            if not self._connected:
                raise PtuError('state')
            self._lock(self._state, deadline, cancel)
            try:
                self._priming = self._prime_sent = self._prime_observed = False
                self._expected_prime = None
                self.ptu_is_primed[self.ptu_id] = False
            finally:
                self._state.release()
            self._check(deadline, cancel)
            self.messenger.publish('{}_{}'.format(Topics.PTU_POSITION_COMMAND, self.ptu_id),
                wire, priority=9, deadline=deadline, cancel=cancel)
            self._check(deadline, cancel)
            return represented
        finally:
            self._operation.release()

    def ptu_move_to(self, azimuth, elevation, force_cw=False, force_ccw=False,
                    ptu_id=None, *, deadline, cancel):
        return self._send_position(azimuth, elevation, force_cw, force_ccw, ptu_id, deadline, cancel)

    def ptu_send_position(self, azimuth, elevation, force_cw=False, force_ccw=False,
                          ptu_id=None, *, deadline, cancel):
        return self._send_position(azimuth, elevation, force_cw, force_ccw, ptu_id, deadline, cancel)

    def _reject_message(self):
        self._rejected = min(2147483647, self._rejected + 1)

    def _callback_lock(self):
        if self._closing.is_set() or self._fault is not None:
            return False
        if not self._state.acquire(False):
            self._reject_message()
            return False
        if self._closing.is_set() or self._fault is not None:
            self._state.release()
            return False
        return True

    def _parse(self, message_type, body, identifier, identity):
        if (type(body) is not bytes or len(body) > _POINTING_CLIENT_MAX_BODY
                or type(identifier) is not str or identifier != ''):
            self._reject_message()
            return None
        try:
            message = message_type()
            message.ParseFromString(body)
        except (DecodeError, ValueError):
            self._reject_message()
            return None
        if (getattr(message, identity) != self.ptu_id
                or message.pointing_binding != self._policy.binding):
            self._reject_message()
            return None
        return message

    def _receive_pong(self, body, identifier):
        if not self._callback_lock():
            return
        try:
            message = self._parse(ptu_pb.PongResponse, body, identifier, 'pong')
            if message is not None and not self._closing.is_set() and self._pong_window.is_set():
                self._pong.set()
        finally:
            self._state.release()

    def _receive_tle(self, body, identifier):
        if not self._callback_lock():
            return
        try:
            message = self._parse(ptu_pb.TleReplyMsg, body, identifier, 'ptu_id')
            if message is None:
                return
            if len(message.msg) > 1024:
                self._reject_message()
                return
            if not self._closing.is_set() and self._load_window.is_set():
                self._reply_success = message.success
                self._reply.set()
        finally:
            self._state.release()

    def _receive_status(self, body, identifier):
        if self._scheduled:
            self._reject_message()
            return
        if not self._callback_lock():
            return
        try:
            message = self._parse(ptu_pb.PositionerStatus, body, identifier, 'id')
            if message is None:
                return
            try:
                if (not 1 <= len(message.state) <= 32
                        or any(not 32 <= ord(char) <= 126 for char in message.state)
                        or any(not math.isfinite(getattr(message, name)) for name in
                               ('pan', 'tilt', 'ptu_pan_to_az', 'azimuth', 'elevation'))):
                    self._reject_message()
                    return
                message.timestamp.ToDatetime()
                if message.HasField('command'):
                    message.command.timestamp.ToDatetime()
                    if (not math.isfinite(message.command.azimuth)
                            or not math.isfinite(message.command.elevation)):
                        self._reject_message()
                        return
            except (ValueError, OverflowError):
                self._reject_message()
                return
            if self._closing.is_set():
                return
            if self._priming:
                if (message.prime_sender_id, message.prime_sequence) != self._expected_prime:
                    self._reject_message()
                    return
            elif message.state in ('tle_primed', 'tle_tracking'):
                self._reject_message()
                return
            self.ptu_status[self.ptu_id] = message
            self.ptu_states[self.ptu_id] = message.state
            if self._priming:
                self._prime_observed = message.state in ('tle_primed', 'tle_tracking')
                self.ptu_is_primed[self.ptu_id] = self._prime_sent and self._prime_observed
        finally:
            self._state.release()

    def diagnostics(self):
        return {'closed': self._closed, 'fault': self._fault,
                'rejected_messages': self._rejected,
                'registrations': len(self._registrations), 'cleanup': self._debt()}

    def _debt(self):
        return tuple(code for code, present in (
            ('active-operation', self._operation.locked()),
            ('active-callback', self._state.locked()),
            ('registration-debt', bool(self._registrations))) if present)

    def _close(self, deadline):
        _client_deadline(deadline)
        self._closing.set()
        self._pong_window.clear()
        self._load_window.clear()
        self._priming = self._prime_sent = False
        self._expected_prime = None
        self.ptu_is_primed[self.ptu_id] = False
        cancel = threading.Event()
        acquired = False
        error = None
        try:
            self._lock(self._operation, deadline, cancel, passive=True)
            acquired = True
            for registration in tuple(self._registrations):
                try:
                    self._check(deadline, cancel, passive=True)
                    self.messenger.cancelSubscribe(*registration, deadline=deadline, cancel=cancel)
                except MessengerError as caught:
                    # Fixed valid inputs leave exact-registration absence as admission.
                    if caught.primary != 'admission':
                        if error is None:
                            error = caught
                        continue
                except Exception as caught:
                    if error is None:
                        error = caught
                    continue
                self._registrations.remove(registration)
            self._lock(self._state, deadline, cancel, passive=True)
            try:
                self._check(deadline, cancel, passive=True)
                self._priming = self._prime_sent = self._prime_observed = False
                self._expected_prime = None
                self.ptu_is_primed[self.ptu_id] = False
                self._loaded = self._connected = False
                self.tle_load_success[self.ptu_id] = False
                self.connection_status[self.ptu_id] = False
                self._closed = not self._registrations
            finally:
                self._state.release()
        except Exception as caught:
            if error is None:
                error = caught
        finally:
            if acquired:
                self._operation.release()
        if error is not None:
            if isinstance(error, PtuError):
                raise PtuError(error.primary, self._debt()) from None
            raise error

    def _legacy_path(self, *args, **kwargs):
        raise PtuError('legacy-path')

    __init__ = _legacy_path
    clean_exit = _legacy_path
    reset_ptu = _legacy_path
    start_logging = _legacy_path
    stop_logging = _legacy_path
    error_profile_reply_cb = _legacy_path
    send_pointing_error_profile = _legacy_path
    check_error_profile_ack = _legacy_path
    tle_reply_cb = _legacy_path
    check_tle_load = _legacy_path
    shutdown = _legacy_path
    pong_cmd_cb = _legacy_path
    cal_status_cb = _legacy_path
    calibrate_ptu = _legacy_path
    parked = _legacy_path
    park_ptu = _legacy_path
    ptu_status_cb = _legacy_path
    publish_wrapper = _legacy_path

def setupClient(args=None)->PtuClient:
    import ptu_control
    from meteor_api.messenger import Messenger
    
    package_dir = Path(ptu_control.__file__).parent    
    if args is None:
        parser = argparse.ArgumentParser(description = 'Remote client for interacting with PTU')
        parser.add_argument('ptu_id', nargs='?', default = 0, type=int, 
                            help = ('Which PTU to connect to. 0 = all, default to 0/all'))         
        parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
                            help = ('Config File, Defaults to {}.' \
                                'Yaml contains activeMQ connection information'.format(str(DEFAULT_CFG)))) 
        parser.add_argument('--test-logs', action = 'store_true', default = False,
                            help = ('Flag to enable logging. Used for testing only'))                
        args = parser.parse_args()
    logging_level = logging.DEBUG # Will change to WARN later
    
    root_logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    root_logger.setLevel(logging.DEBUG)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)    
    
    # Load config File
    with open(args.config) as f:
        config = yaml.safe_load(f)             
    credentials = {
                "username": config["amq_username"], 
                "password": config["amq_password"]}    
    messenger = Messenger(config['amq_server'], config['amq_port'], credentials, use_ssl=config['amq_use_ssl'])
    if args.test_logs:
        cmd_file = Path("~/logs/test/ptu_client_cmds.csv").expanduser()
        status_file = Path("~/logs/test/ptu_client_status.csv").expanduser()
    else:
        cmd_file = None
        status_file = None
    # PTU Sat Tracker
    nogo_config = Path(config['home_directory']) / 'ground_station/lib/sat_tracker/nogozones.yaml'            
    ptu_client = PtuClient(messenger, 
                           args.config, 
                           ptu_id=args.ptu_id,
                           elevation_mask=DEFAULTS.elev_mask, 
                           test_mode= False,
                           cmd_log_file=cmd_file, 
                           status_log_file=status_file
    )
    
    return ptu_client

def echo():
    parser = argparse.ArgumentParser(
        description = 'Command line script for echoing the PTU Status and displaying to console') 
    parser.add_argument('ptu_id', nargs='?', default = 0, type=int, 
                        help = ('Which PTU to connect to. 0 = all, default to 0/all'))        
    parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
                        help = ('Config File, Defaults to ~/ground_station/config.yaml.' \
                            'Yaml contains activeMQ connection information'))  

    parser.add_argument('--test-logs', action = 'store_true', default = False,
                        help = ('Flag to enable logging. Used for testing only'))           
    args = parser.parse_args()
          
    ptu_client = setupClient(args)
    ptu_client.check_connection()
    try:
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\nLoop interrupted by user.")     
        
def calibrate():
    parser = argparse.ArgumentParser(
        description = 'Command line script for doing a one off dish calibration') 
    parser.add_argument('ptu_id', nargs='?', default = 0, type=int, 
                        help = ('Which PTU to connect to. 0 = all, default to 0/all'))     
    parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
                        help = ('Config File, Defaults to ~/ground_station/config.yaml.' \
                            'Yaml contains activeMQ connection information'))  
    args = parser.parse_args()
    args.test_logs = False
    
    ptu_client = setupClient(args)
    ptu_client.check_connection()
    ptu_client.calibrate_ptu()
                
def reset_ptu():
    parser = argparse.ArgumentParser(
        description = 'Command line script for reset PTUs') 
    parser.add_argument('ptu_id', nargs='?', default = 0, type=int, 
                        help = ('Which PTU to connect to. 0 = all, default to 0/all'))     
    parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
                        help = ('Config File, Defaults to ~/ground_station/config.yaml.' \
                            'Yaml contains activeMQ connection information'))  
    args = parser.parse_args()
    args.test_logs = False
          
    ptu_client = setupClient(args)
    ptu_client.check_connection()
    ptu_client.reset_ptu()   
    time.sleep(5)
    
def park_ptu():
    parser = argparse.ArgumentParser(description = 'Command line script for reset PTUs')
    parser.add_argument('ptu_id', nargs='?', default = 0, type=int, 
                        help = ('Which PTU to connect to. 0 = all, default to 0/all'))      
    parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
                        help = ('Config File, Defaults to ~/ground_station/config.yaml.' \
                            'Yaml contains activeMQ connection information'))  
    args = parser.parse_args()
    args.test_logs = False
          
    ptu_client = setupClient(args)
    ptu_client.check_connection()
    ptu_client.reset_ptu() 
    time.sleep(3)    
    ptu_client.park_ptu() 
    
# def manaual_control():
#     parser = argparse.ArgumentParser(
#         description = 'Command line script for reset PTUs')
#     parser.add_argument('ptu_id', nargs='?', default = 0, type=int, 
#                         help = ('Which PTU to connect to. 0 = all, default to 0/all'))
#     parser.add_argument('-az-el', metavar='N', type=float, nargs='+', 
#                         help='az and el (in degrees) MUST Specify both\n example -az-el 40 45' )    
#     parser.add_argument('-config', default = str(DEFAULT_CFG), type=str, 
#                         help = ('Config File, Defaults to ~/ground_station/config.yaml.' \
#                             'Yaml contains activeMQ connection information'))  
#     args = parser.parse_args()
#     args.test_logs = False
          
#     ptu_client = setupClient(args)
#     ptu_client.check_connection()
#     ptu_client.ptu_move_to()
#     # ptu_client.reset_ptu() 
#     # time.sleep(3)    
#     # ptu_client.park_ptu()                      
    
def main():   
    ptu_client = setupClient()

    ptu_client.check_connection()
    # Test Commands
    # tle_df = pd.read_csv('~/ground_station/config/sat_db.csv')
    # tle_db = tle_df.set_index('norad_id').to_dict("index")          
    # ptu_client.load_tle(tle_db[41589]['tle'])
    # time.sleep(3)
    # ptu_client.prime(237, 23)
    # time.sleep(25)
    # # manager.prime_ptu(0,20)    
    
    # ptu_client.ptu_move_to(-100,40)
    # ptu_client.send_pointing_error_profile()
    
    try:
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\nLoop interrupted by user.")    

if __name__ == '__main__':
    main()
