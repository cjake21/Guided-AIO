import yaml
import math
from collections import namedtuple
from contextlib import contextmanager
from ptu_control.pointing import PointingPolicy, PointingError
from ptu_control.tracking import CATEGORIES, STATES, MAX_SEQUENCE, TrackingOutcome
import threading
import argparse
import logging
import time
import signal
import pandas as pd
import numpy as np
import traceback
import ephem
from ephem import degree as deg2rad
from google.protobuf.timestamp_pb2 import Timestamp
from pathlib import Path
from datetime import datetime, timedelta, timezone
from scipy.interpolate import CubicSpline, interp1d

import serialptu
from serialptu.ptu import PTU
from meteor_api.messenger import Messenger, MessengerError

from ptu_control import ptu_msg_pb2 as ptu_pb
from ptu_control.constants import Topics, PTUStatus, DEFAULTS as PTU_DEFAULTS
from ptu_control.utils import (PtuID, 
                               ptu_move_msg_from_pb, 
                               convert_to_ptu_frame, 
                               convert_from_ptu_frame,
                               NoGoZone,
                               PTUDataMsg
)

from satgs.utils import TLE, PassInfo, find_closest_pass, tle_from_str, make_az_el_scurves
from satgs.constants import DEFAULTS


logger = logging.getLogger(__name__)
default_cfg = Path('~/ground_station/config/config.yaml').expanduser()


class PtuManager:
    '''

    '''
    @classmethod
    def open_pointing(cls, *, messenger, settings, ptu_id, driver, elevation_mask,
                      no_go_data, run_deadline, cancel, outcome_timeout=None):
        return _PointingManager(messenger, settings, ptu_id, driver, elevation_mask,
                                no_go_data, run_deadline, cancel, outcome_timeout)

    @classmethod
    def open_bench(cls, **options):
        from ptu_control.bench import BenchManager
        return BenchManager(**options)

    def __init__(self, 
                 messenger:Messenger, 
                 config:Path, 
                 ptu_id:PtuID, 
                 ptu:PTU=None, 
                 simulate_hw:bool=False,
                 elevation_mask:float = DEFAULTS.elev_mask,
                 no_go_config:Path=None):
        
        self.running = False
        self.messenger = messenger
        self.simulate_hw = simulate_hw
        self.ptu = ptu
        self.ptu_id = ptu_id
        self.no_go_zone = NoGoZone(ptu_id.no_go_config)
        self.elevation_mask = elevation_mask
        # Data structure for conveying previous command to client
        temp_time = Timestamp()
        temp_time.GetCurrentTime()
        self.last_command = {
            'time': temp_time,
            'azimuth': 0,
            'elevation':0,
        }
        # if self.ptu_id.cont_rot:
        self.counter_adjustments = 0
        self.pan_buffer = np.array(10)
        self.quadrant = 1
        self.rising_az = 0
        self.ptu_state = "free"        
        self.ptu_pan_pos = 0
        self.ptu_tilt_pos = 0
        self.ptu_pan_to_az = PTU_DEFAULTS.PTU_PAN_TO_AZ
        self.ptu_tilt_to_el = PTU_DEFAULTS.PTU_TILT_TO_EL 
        self.ptu_az_pos, self.ptu_el_pos=self._convert_from_ptu_frame(self.ptu_pan_pos, self.ptu_tilt_pos)        
        self.apply_errors = False
        self.is_rx_antenna = not ("tx" in self.ptu_id.name.lower())
        self.az_err_spline = interp1d([0, 1e6], [0, 0], 'previous', bounds_error=False, fill_value=0)
        self.el_err_spline = interp1d([0, 1e6], [0, 0], 'previous', bounds_error=False, fill_value=0)
        

        self.config_file = config
        # Load config File
        with open(config) as f:
            self.config = yaml.safe_load(f)              
        
        if not self.simulate_hw:
            logger.info("Opening PTU Serial Port")
            try:
                self.ptu.open()
                logger.info("Port Open")            
            except:
                logger.error("Cannot connect to PTU serial port")
                return
            self.ptu.connect_status_listener(self.ptu_status_listener)            
        else:
            self.last_pan = 0.5
            self.last_tilt = 0.5
            logger.warning("Running in test mode! HW is simulated! Manager only replies to client with dummy messages.")                    
        
        self.ground_station = ephem.Observer()
        self.ground_station.lat = self.config['ground_station_lat'] * deg2rad
        self.ground_station.lon = self.config['ground_station_lon'] * deg2rad
        self.ground_station.elevation = self.config['ground_station_altm']        
        
        self.messenger.subscribe("{}_0".format(Topics.PTU_POSITION_COMMAND), self.position_command_cb, "")
        self.messenger.subscribe("{}_0".format(Topics.PING_CMD), self.ping_cmd_cb, "")
        self.messenger.subscribe("{}_0".format(Topics.CALIBRATE_COMMAND), self.calibrate_cmd_cb, "")
        self.messenger.subscribe("{}_0".format(Topics.TLE_LOAD_COMMAND), self.tle_load_cmd_cb, "")
        self.messenger.subscribe("{}_0".format(Topics.TLE_PRIME_COMMAND), self.tle_prime_cmd_cb, "")
        self.messenger.subscribe("{}_0".format(Topics.ABORT_COMMAND), self.abort_cmd_cb, "")
        self.messenger.subscribe("{}_0".format(Topics.PARK_COMMAND), self.park_cmd_cb, "")
        self.messenger.subscribe("{}_0".format(Topics.ERROR_PROFILE_COMMAND), self.error_profile_cmd_cb, "")
        
        
        self.messenger.subscribe("{}_{}".format(Topics.PTU_POSITION_COMMAND, self.ptu_id.id), self.position_command_cb, "")        
        self.messenger.subscribe("{}_{}".format(Topics.PING_CMD, self.ptu_id.id), self.ping_cmd_cb, "")        
        self.messenger.subscribe("{}_{}".format(Topics.CALIBRATE_COMMAND, self.ptu_id.id), self.calibrate_cmd_cb, "")
        self.messenger.subscribe("{}_{}".format(Topics.TLE_LOAD_COMMAND, self.ptu_id.id), self.tle_load_cmd_cb, "")
        self.messenger.subscribe("{}_{}".format(Topics.TLE_PRIME_COMMAND, self.ptu_id.id), self.tle_prime_cmd_cb, "")
        self.messenger.subscribe("{}_{}".format(Topics.PARK_COMMAND, self.ptu_id.id), self.park_cmd_cb, "")
        self.messenger.subscribe("{}_{}".format(Topics.ERROR_PROFILE_COMMAND, self.ptu_id.id), self.error_profile_cmd_cb, "")
        
        self.running = True
        # add handlers for clean exit 
        signal.signal(signal.SIGINT, self._sig_handler)
        signal.signal(signal.SIGTERM, self._sig_handler)    
        
        self.curr_tle = None    
        self.iss = None
        self.curr_pass_prime_cw = False
        self.curr_pass_prime_ccw = False
        self.curr_pass_force_cw = False
        self.curr_pass_force_ccw = False            
        if self.simulate_hw:
            simulated_ptu_publisher = threading.Thread(target=self.simulated_hw_listener)
            simulated_ptu_publisher.start()
        
        # self.calibrate()
        logger.info("Initializing with PTU Az Calibration Error of {:0.1f}".format(self.ptu_pan_to_az))        
        logger.error("Ready")
                
    def _sig_handler(self, *args):
        logger.info('Control-C detected. Shutting Down')
        self.shutdown()

    def _timer(func):
        '''
        Annotation/Decorator that will log (info) the duration of a function call. Place @_timer before functions that require logging.
        '''
        def wrapper(*args, **kwargs):
            timeStart = time.time()
            result = func(*args, **kwargs)
            timeStop = time.time()
            logger.info("Took {:.4f} seconds to execute {:s}".format((timeStop - timeStart), func.__name__))
            return result
        return wrapper
    
    def _get_quadrant(self, pan:float)->int:
        if (pan > 0) and (pan <= 90):
            return 1
        elif (pan > 90) and (pan <= 180):
            return 2
        elif (pan > 180) and (pan <= 270):
            return 3
        elif (pan > 270) and (pan <= 360):
            return 4

    def _convert_to_ptu_frame(self, azimuth:float, elevation:float, 
                              force_cw:bool=False, force_ccw:bool=False):
        """
        """
        # print(self.ptu_id.cont_rot)
        pan, tilt = convert_to_ptu_frame(
            azimuth, elevation, self.ptu_pan_to_az, self.ptu_tilt_to_el,
            self.ptu_id.cont_rot, force_cw, force_ccw, 
            self.ptu_id.hard_pan_lim_cw, self.ptu_id.hard_pan_lim_ccw)
        return pan, tilt    
    
    def _convert_from_ptu_frame(self, pan:float, tilt:float)-> tuple:
        """
        """
        azimuth, elevation = convert_from_ptu_frame(pan, tilt, self.ptu_pan_to_az, self.ptu_tilt_to_el, self.ptu_id.cont_rot)
        return azimuth, elevation      
        
    def shutdown(self):
        logger.info('Shutting Down PTU')
        if not self.simulate_hw:
            self.ptu.close()
        logger.info(' PTU Closed')        
        self.running=False       
        
    def error_profile_cmd_cb(self, msg:str, id:int):
        logger.info("Command to set error profile received")            
        
        cmd_msg = ptu_pb.ErrorProfileCmd()   
        cmd_msg.ParseFromString(msg)                     
        self.set_error_profile(
            cmd_msg.duration, 
            cmd_msg.error_range_deg,
            cmd_msg.rate_deg_per_sec, 
            cmd_msg.pad_time,
            cmd_msg.rotation_rate_dps)
        
    def tle_load_cmd_cb(self, msg:str, id:int):
        """Callback function for loading a TLE into the manager from a client
        """
        tle_msg = ptu_pb.TleLoadCmd()
        tle_msg.ParseFromString(msg)
        if tle_msg.pointing_binding:
            return
        outcome, reply_msg = self.tle_load(tle_msg.tle_str)
        self.publish_wrapper(
            "{}_{}".format(Topics.TLE_LOAD_REPLY, self.ptu_id.id), 
            ptu_pb.TleReplyMsg(success=outcome, msg=reply_msg, ptu_id = self.ptu_id.id)
            )
                
    def tle_prime_cmd_cb(self, msg:str, id:int):
        logger.warning("TLE Prime Command Received")
        prime_msg = ptu_pb.TlePrimeCmd()
        prime_msg.ParseFromString(msg)
        if prime_msg.pointing_binding:
            return
        az_cmd = round(prime_msg.azimuth*100)/100
        el_cmd = round(prime_msg.elevation*100)/100
        self.prime_ptu(az_cmd, el_cmd)
        
    def park_cmd_cb(self, msg:str, id:int):
        logger.info("Park Command Received") 
        if self.ptu_state!="parking":      
            self.park_ptu()        
        else:
            logger.warning("Already in park procedure")
        
    def abort_cmd_cb(self, msg:str, id:int):
        logger.info("Reset Command Received")        
        success, reply_msg = self.abort()

    def position_command_cb(self, msg:str, id:int):
        '''
        Callback for the subscriber to Topics.PTU_POSITION_COMMAND
        Rotates the PTU to the target position.
        '''
        if (self.ptu_state == "tle_primed") or (self.ptu_state =="tle_tracking"):
            logger.error("Move to command received while in TLE mode, cannot process unless you reset PTU manager first.")
            return
        positionCommandMsg = ptu_pb.PositionCommandMsg()
        positionCommandMsg.ParseFromString(msg)
        if positionCommandMsg.pointing_binding:
            return
        logger.debug(positionCommandMsg)
        az_cmd = round(positionCommandMsg.azimuth*100)/100
        el_cmd = round(positionCommandMsg.elevation*100)/100
        force_cw = positionCommandMsg.force_cw
        force_ccw = positionCommandMsg.force_ccw
        if force_cw or force_ccw:
            logger.warning("Move command callback, Moving to: Az: {:.4f}, El: {:.4f} || Force CW {} Force CCW {}".format(az_cmd, el_cmd, force_cw, force_ccw))
        else:            
            logger.warning("Move command callback, Moving to: Az: {:.4f}, El: {:.4f}".format(az_cmd, el_cmd))
        # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(az_cmd, el_cmd))
        self.move_to_az_el(az_cmd, el_cmd, force_cw, force_ccw)
                
    def ping_cmd_cb(self, msg:str, id:int):
        """Call back for when Ping is received
        """             
        ping = ptu_pb.PingCmd.FromString(msg)
        if ping.pointing_binding:
            return
        logger.info("Ping Received.")      
        logger.info("Sending Pong Response, PTU ID: {}".format(self.ptu_id.id))
        self.publish_wrapper("{}_{}".format(Topics.PONG_RESPONSE, self.ptu_id.id), ptu_pb.PongResponse(pong=self.ptu_id.id))                     
    
    def calibrate_cmd_cb(self, msg:str, id:int):
        """Call back for when Ping is received
        """             
        logger.info("Commanded to calibrate the positioner")
        self.calibrate()      
        
    def abort(self)->tuple:
        # if self.ptu_state=="tle_primed" or self.ptu_state=="tle_tracking":
        self.ptu_state = "free"
        self.curr_pass_prime_cw = False
        self.curr_pass_prime_ccw = False
        self.curr_pass_force_cw = False
        self.curr_pass_force_ccw = False            
        self.apply_errors = False
        self.az_err_spline = interp1d([0, 1e6], [0, 0], 'previous', bounds_error=False, fill_value=0)
        self.el_err_spline = interp1d([0, 1e6], [0, 0], 'previous', bounds_error=False, fill_value=0)                    
        success = True
        reply_msg = "State reset to free"
        return success, reply_msg
            
    def set_error_profile(self, duration:float, error_range_deg:float, rate_deg_per_sec:float, 
                            pad_time:float, rotation_rate_dps:float):
        try:
            if (self.ptu_state=="tle_loaded") or (self.ptu_state=="tle_primed") or (self.ptu_state=="tle_tracking"):
                self.apply_errors = True
                if self.pass_info.is_circumpolar:
                    num_reps = 10
                else:
                    pass_duration = (self.pass_info.sat_set_time - self.pass_info.sat_rise_time).total_seconds()
                    num_reps = np.ceil(pass_duration/duration)
                t_ax, az_error, el_error = make_az_el_scurves(0,error_range_deg,rate_deg_per_sec,1,pad_time,rotation_rate_dps,duration*num_reps)
                # t_ax, az_error, el_error = make_az_el_scurves(
                #     0,error_range_deg, rate_deg_per_sec, update_rate=1,
                    # pad_time=pad_time,rotation_rate_dps=rotation_rate_dps,duration=duration*num_reps)
                self.az_err_spline = CubicSpline(t_ax, az_error, extrapolate=False)
                self.el_err_spline = CubicSpline(t_ax, el_error, extrapolate=False) 
                self.send_error_profile_ack(True,"")                                   
            else:
                msg = "PTU Not in Proper state. Must be in tle_loaded, tle_primed, tle_tracking"
                self.send_error_profile_ack(False, msg)
        except:
            self.apply_errors = False
            self.send_error_profile_ack(False,"Error Creating Spline")                      
                  
    def send_error_profile_ack(self, success:bool, msg:str):
        
        logger.info("Sending Error Profile Reply: Success={}, MSG: {}".format(success, msg))    
        self.publish_wrapper("{}_{}".format(
            Topics.ERROR_PROFILE_REPLY, self.ptu_id.id),
            ptu_pb.ErrorProfileReply(success=success, msg=msg, ptu_id=self.ptu_id.id))  
                       
    def tle_load(self, tle_str:str)->tuple:
        if self.ptu_state=="tle_primed" or self.ptu_state=="tle_tracking":
            reply_msg = "PTU manager already primed or tracking, need to clear TLE with reset command"
            success = False
            logger.error(reply_msg)
        else:       
            try:
                tle_parts = tle_str.split(',')
                self.curr_tle = TLE(name = tle_parts[0], 
                        tle_str=",".join(tle_parts[0:3]), 
                        t_ref = datetime.now(timezone.utc),
                        norad_id=tle_parts[1][2:7])
                self.iss = ephem.readtle(tle_parts[0], tle_parts[1], tle_parts[2])
                self.ptu_state  = "tle_loaded" 
                reply_msg = "TLE Loaded Successfully"
                success = True          
                logger.info(reply_msg)
                logger.warning("TLE: {}".format(self.curr_tle.to_str()))
            except:
                reply_msg = "TLE Not Loaded. Check TLE Format"
                success = False
                logger.error(reply_msg)
                
        return success, reply_msg              
    
    def calibrate(self)->bool:
        """_summary_

        Returns:
            bool: _description_
        """
        if self.ptu_state == "free":
            next_state = "free"
        elif self.ptu_state == "tle_loaded":
            next_state = "tle_loaded"          
        else:
            next_state="free"  
        self.ptu_state = "calibrating"
                
        if self.simulate_hw:
            status_msg = "Simulated HW Mode!!!: No pixhawk connection"
            logger.info(status_msg)
            time.sleep(1)            
            self.ptu_state = next_state
            logger.info("Simulated Cal over:Current State = {}".format(self.ptu_state))
            self.publish_wrapper("{}_{}".format(
                Topics.CALIBRATION_STATUS, self.ptu_id.id), 
                ptu_pb.CalibrationStatus(cal_success=True, msg=status_msg, ptu_id=self.ptu_id.id))                
            return True
            
        from pixhawk.pixhawk_subscriber import PixhawkSubscriber                 
        logger.info("Beginning positioner calibration")
        logger.info("Connecting to Pixhawk")
        # Use standalone messenger since using a common one was causing bugs... 
        #might have to do with threading in subscriber??
        credentials = {
                    "username": self.config["amq_username"], 
                    "password": self.config["amq_password"]}    
        messenger = Messenger(self.config['amq_server'], self.config['amq_port'], credentials, use_ssl=self.config['amq_use_ssl'])        
        pixhawk_client = PixhawkSubscriber(
            messenger, pix_id=self.ptu_id.pix_id, config=self.config_file, standalone=False)        
        if not pixhawk_client.check_connection():
            err_msg = "Could not connect to Pixhawk ID {} manager. Cannot do calibration".format(self.ptu_id.pix_id)
            logger.error(err_msg)
            self.publish_wrapper("{}_{}".format(Topics.CALIBRATION_STATUS,self.ptu_id.id), ptu_pb.CalibrationStatus(cal_success=False, msg=err_msg))      
            self.ptu_state = next_state
            return False
        
        pix_logger = logging.getLogger("pixhawk")
        pix_logger.propagate = False
        logger.info("Moving to perceived 0/ 0")
        # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(0, 0))
        self.move_to_az_el(0, 0)
        # pan0, tilt0 = self._convert_to_ptu_frame(0, 0)
        # self.move_to(pan0, tilt0)
     
        t0 = time.time()
        if (abs(self.ptu_az_pos)<2) and (abs(self.ptu_el_pos)<2):
            logger.info("Positioner already close enough to 0/0")
        else:
            logger.info("Waiting 15 seconds for dish to move")            
            while (abs(self.ptu_az_pos)>2) and (abs(self.ptu_el_pos)>2):
                if (abs(self.ptu_az_pos)<2) and (abs(self.ptu_el_pos)<2):
                    logger.info("Reached perceived 0/0 position")        
                    break
                if (time.time()-t0 > 15):
                    logger.info("Didn't reach perceived 0/0 in 15 seconds.... starting cal anyway")
                    break
            
        cal_duration = 45
        t0 = time.time()
        logger.info("Averaging GPS Compass Heading for 45 seconds")
        hdg_sum = 0
        hdg_cnt = 0
        bad_meas_cnt = 0
        while (time.time() - t0) < cal_duration :
            pix_status = pixhawk_client.pix_status[pixhawk_client.pix_id]            
            if (pix_status.gpsStatus==5) or (pix_status.gpsStatus==6):
                hdg_meas = ((pix_status.hdg/100) + 180) % 360 - 180
                gps_yaw =pix_status.gpsYaw/100
                if np.floor(gps_yaw) == 655:
                    bad_meas_cnt = bad_meas_cnt +1
                    logger.info("Bad GPS reading.... Likely not getting good RTK FIX")
                else:
                    hdg_sum = hdg_sum + hdg_meas
                    hdg_cnt = hdg_cnt + 1
                    logger.info("Average GPS Compass {:0.2f}, (Current: {:0.2f} [{:0.2f}]) Cnt {}/{}".format(hdg_sum/hdg_cnt, hdg_meas,gps_yaw, hdg_cnt,cal_duration))
            time.sleep(1)
            # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(0, 0))
            self.move_to_az_el(0, 0)        
            # az0, el0 = self._convert_to_ptu_frame(0, 0)
            # self.move_to(az0, el0)                               
        if bad_meas_cnt > hdg_cnt:
            status_msg = "Cal Failure. Did not update offset. Too many bad GPS measurements, likely due to bad RTK Fix"  
            logger.info(status_msg)
            
            # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(0, 0))
            self.move_to_az_el(0, 0)                
            cal_msg_out = ptu_pb.CalibrationStatus(cal_success=False, msg=status_msg, ptu_id=self.ptu_id.id)
            self.publish_wrapper("{}_{}".format(Topics.CALIBRATION_STATUS, self.ptu_id.id), cal_msg_out)    
            pixhawk_client.clean_exit()  
            self.ptu_state = next_state
            return False   
        else:
            avg_hdg = hdg_sum / hdg_cnt
            new_az_cal = round((self.ptu_pan_to_az + avg_hdg)*100)/100      
            status_msg = "Off by {:0.2f}... Updating Pan to Az Offset from {:0.2f} to {:0.2f}".format(avg_hdg, self.ptu_pan_to_az, new_az_cal)  
            logger.info(status_msg)
            
            self.ptu_pan_to_az = new_az_cal
            logger.info("Re-Orienting to 0/0")
            # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(0, 0))
            self.move_to_az_el(0, 0)                
            # pan0, tilt0 = self._convert_to_ptu_frame(0, 0)
            # self.move_to(pan0, tilt0)
            cal_msg_out = ptu_pb.CalibrationStatus(cal_success=True, msg=status_msg, ptu_id=self.ptu_id.id)
            # logger.info(cal_msg_out)
            self.publish_wrapper("{}_{}".format(Topics.CALIBRATION_STATUS, self.ptu_id.id), cal_msg_out)    
            pixhawk_client.clean_exit()  
            self.ptu_state = next_state
            return True   
         
    def parked(self):
        '''
        Determines if the PTU is in the parked position
        '''
        if self.simulate_hw:
            logger.warning("Simulating HW... ")            
        
        parkStatus = (abs(self.ptu_az_pos - PTU_DEFAULTS.PARK_PTU_AZ) < 1) and ( abs(self.ptu_el_pos - PTU_DEFAULTS.PARK_PTU_EL) < 1)
        logger.debug("Az value: {:.4f}, El value: {:.4f}, Parked? {}".format(self.ptu_az_pos, self.ptu_el_pos, parkStatus))
        return parkStatus
        
    def get_sat_pos(self, time:datetime)-> tuple:
        if self.curr_tle is None:
            logger.error("No TLE loaded")
            return (0,0)
        
        self.ground_station.date = (time)
        self.iss.compute(self.ground_station)
        azimuth = self.iss.az*180/np.pi
        elevation = self.iss.alt*180/np.pi
        return (azimuth, elevation)    
        
    def prime_ptu(self, azimuth:float, elevation:float):

        logger.warning("Priming to: Az: {:.2f}, El: {:.1f}".format(azimuth, elevation))
        # try:
        prime_cw, prime_ccw, force_cw, force_ccw = self.pre_plan_pass()
        # except Exception as e:
            
        
        self.prime_pos_az = azimuth
        self.prime_pos_el = elevation
        self.prime_t_ref  = datetime.now(timezone.utc)
        
        logging.info("Priming El: Tilting to {:3.1f} deg elv".format(elevation))   
        # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(self.no_go_zone.last_az_el[0], elevation))
        adj_az, adj_el = self.move_to_az_el(self.no_go_zone.last_az_el[0], elevation)
        prime_start = time.time()
        while ((time.time() - prime_start) < 30) :          
            # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(self.no_go_zone.last_az_el[0], elevation))
            adj_az, adj_el = self.move_to_az_el(self.no_go_zone.last_az_el[0], elevation)        
            time.sleep(2)  
            if abs((self.ptu_el_pos - adj_el))<1:
                break    
                            
        self.curr_pass_prime_cw = prime_cw
        self.curr_pass_prime_ccw = prime_ccw
        self.curr_pass_force_cw = force_cw
        self.curr_pass_force_ccw = force_ccw        
        # Prime in clockwise position (+ Pan)
        if prime_cw:
            logger.warning("Priming in CW direction due to starting point and direction of pass")
            az_360 = azimuth % 360
            # Assumes we are starting near zero... Move the dish clockwise in steps
            self.move_to_az_el(az_360 / 3, elevation, force_cw=prime_cw)
            time.sleep(5)
            self.move_to_az_el(2* az_360 / 3, elevation, force_cw=prime_cw)
            time.sleep(5)
            self.move_to_az_el(az_360 , elevation, force_cw=prime_cw)
        elif prime_ccw:
            logger.warning("Priming in CCW direction due to starting point and direction of pass")            
            az_neg_360 = (azimuth % 360) -360
            # Assumes we are starting near zero
            self.move_to_az_el(az_neg_360/3, elevation, force_ccw=prime_ccw)
            time.sleep(5)
            self.move_to_az_el(2*az_neg_360/3, elevation, force_ccw=prime_ccw)
            time.sleep(5)
            self.move_to_az_el(az_neg_360, elevation, force_ccw=prime_ccw)
        else:                
            # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(azimuth, elevation))

            adj_az, adj_el = self.move_to_az_el(azimuth, elevation)  
        self.ptu_state = "tle_primed"
        
    def pre_plan_pass(self, *, diagnostics=True)->tuple:
        """_summary_

        Returns:
            tuple: Tuple containing
                prime_cw bool, if true pass is primed in CW direction
                prime_ccw bool, if true pass is primed in CCW direction
                force_cw bool, if true pass is forced in CW direction. 
                force_ccw bool, if true pass is forced in CW direction. 
        """
        if diagnostics:
            logger.warning("Pre Plan Pass....")
        prime_cw = False
        prime_ccw = False   
        force_cw = False
        force_ccw = False     
        
        pass_info = find_closest_pass(
            self.curr_tle.norad_id, self.ground_station, self.curr_tle.to_dict(), 
            el_mask=self.elevation_mask, hrs_past=12, hrs_future=12, 
            utc_ref=datetime.now(timezone.utc))
        if pass_info.is_circumpolar:
            sat_trajectory = pass_info.get_trajectory(self.ground_station) 

            # Updated attributes of pass
            self.setting_az = pass_info.rising_az
            self.rising_az = pass_info.rising_az
            self.pass_info = pass_info
            self.pass_trajectory = sat_trajectory              
            if diagnostics:
                logger.info("Pass is GEO. Dont need to do anything.")
            return prime_cw, prime_ccw, force_cw, force_ccw
        else:
    
            sat_trajectory = pass_info.get_trajectory(self.ground_station) 
            prime_idx = np.argmax(sat_trajectory.el>self.elevation_mask)            
            setting_idx = np.argmax((sat_trajectory.el<=self.elevation_mask) & (sat_trajectory.range_rate>0) )
            
            valid_idx = np.argwhere(sat_trajectory.el>self.elevation_mask)
            set_idx = valid_idx[-1]
            rising_az = sat_trajectory.az[prime_idx]
            rising_az_pan = (rising_az - self.ptu_pan_to_az) % 360
            
            setting_az = sat_trajectory.az[setting_idx]
            setting_az_pan = (setting_az - self.ptu_pan_to_az) % 360            
            
            az_unwrapped = np.unwrap(sat_trajectory.az*np.pi/180)*180/np.pi
            az_change = az_unwrapped[-1] - az_unwrapped[0]
            rotation_dir = np.sign(az_change)   
            
            # Updated attributes of pass
            self.setting_az = sat_trajectory.az[set_idx]
            self.rising_az = rising_az
            self.pass_info = pass_info
            self.pass_trajectory = sat_trajectory  
            
            azimuthal_range = self.ptu_id.hard_pan_lim_cw - self.ptu_id.hard_pan_lim_ccw
            
            if self.ptu_id.cont_rot:
                if diagnostics:
                    logger.info("PTU has continuous rotation, dont need to apply any logic")
                return prime_cw, prime_ccw, force_cw, force_ccw
            elif azimuthal_range > 360:
                if diagnostics:
                    logger.info("need to do some logic")
            else:
                if diagnostics:
                    logger.info("PTU has less than 360 azimuthal range... nothing to do here. ")
                return prime_cw, prime_ccw, force_cw, force_ccw
            
            # rotation_dir > 0 ==> ClockWise || rotation <0 Counter Clockwise            
            # Starts in overlapped zone
            if (rising_az_pan >= (self.ptu_id.hard_pan_lim_ccw%360)) and (rising_az_pan <= (self.ptu_id.hard_pan_lim_cw%360)):
                # Rises in SW and rotates Counter Clockwise
                if (rising_az_pan >= 180) and (rotation_dir<0):
                    # Pan values should be positive when in overlapped zone
                    prime_cw = True 
                    force_cw = True
                    if diagnostics:
                        logger.warning("Priming Clock Wise: Sat rising in SW Pan quadrant and orbit moving Counter CW")
                # Rises in SE and pass goes Clockwise
                elif (rising_az_pan <= 180) and (rotation_dir>0):
                    # Pan values should be negative, when in overlapped zone
                    prime_ccw=True 
                    force_ccw=True
                    if diagnostics:
                        logger.warning("Priming Counter Clock Wise: Sat rising in SE Pan quadrant and orbit moving CW")
            # Satellite sets in overlapped zone
            # In these cases we just need to force the dish, but now prime it in given direction. 
            elif (setting_az_pan >= (self.ptu_id.hard_pan_lim_ccw%360)) and (setting_az_pan <= (self.ptu_id.hard_pan_lim_cw%360)):
                # Sets in SW and rotates Clockwise, meaning we should force CW rotation
                if (setting_az_pan >= 180) and (rotation_dir>0):
                    # Pan values should be positive when in overlapped zone
                    force_cw = True 
                    if diagnostics:
                        logger.warning("Forcing Clock Wise: Sat setting in SW Pan quadrant and orbit moving CW")
                # Sets in SE and goes counter clockwise, meaning we should for CCW rotation
                elif (setting_az_pan <= 180) and (rotation_dir>0):
                    # Pan values should be negative when in overlapped zone
                    force_ccw=True 
                    if diagnostics:
                        logger.warning("Forcing Counter Clock Wise: Sat setting in SE Pan quadrant and orbit moving Counter-CW")
        if diagnostics:
            logger.warning(f"Pass planning successful: Prime CW {prime_cw}, Prime CCW {prime_ccw}, Force CW {force_cw}, Force CCW {force_ccw}")
        return prime_cw, prime_ccw, force_cw, force_ccw
        
    def park_ptu(self):
        """Parks the PTU. First the positioner is tiled to 35 degrees elevation, 
        then pans to 0 deg North. Then tilts down to 0 deg elevation. 
        This procedure was chosen to avoid panning at ground interferers near 
        the horizon. 
        """
        # Move up to 30 deg so we avoid low elevation stuff in no go zones.
        reverse_pass = False
        if self.ptu_state == "free":
            next_state = "free"
        elif self.ptu_state == "tle_tracking":
            next_state = "free"
            if self.ptu_id.cont_rot:
                reverse_pass = True
            if self.pass_info.is_circumpolar:
                logger.warning("Pass is GEO. Dont need to reverse pass")
                reverse_pass = False
        elif self.ptu_state == "tle_loaded":
            next_state = "tle_loaded"
        else:
            next_state="free"
        
        self.ptu_state = "parking"
        
        if self.parked(): 
            logger.info("Already Parked")
            self.ptu_state = next_state    
            return
        
        logger.info("Parking: Reverse Pass {}".format(reverse_pass))
        # Reversing Pass: 
        if reverse_pass:
            logging.warning("REVERSING PASS")     
            # Reverse pass by computing sat positions going backward from now to when 
            # it was primed. This ensures the QPT-500 cable does not get wrapped around
            # the nexk of the PTU.      
            park_start_time = datetime.now(timezone.utc)
            pass_duration = (park_start_time - self.prime_t_ref).total_seconds()
            dt = pass_duration/10
            rev_steps = []
            for k in range(1,11):
                az_step, el_step = self.get_sat_pos(park_start_time-timedelta(seconds = float(k*dt)))                
                if el_step<0:
                    logger.error('Something odd happened.')
                    break
                rev_steps.append((az_step,el_step))
            logging.warning("Reversing with steps {}".format(rev_steps))
            step_timeout = 6            
            for rev_step in rev_steps:
                az_cmd = rev_step[0]
                logging.warning("Reversing to {:.1f}".format(az_cmd))            
                adj_az, adj_el = self.move_to_az_el(az_cmd, 35)
                reverse_step = time.time()                
                while ((time.time() - reverse_step) < step_timeout) :                 
                    time.sleep(1)
                    # I guess here it makes sense to have angles 0-360
                    if abs( (self.ptu_az_pos%360) - (adj_az%360) )<1:
                        break                  
            reverse_pass = False
        else:
            park_start = time.time()
            logger.info("Tilting to 35 deg elv")        
            while ((time.time() - park_start) < 30):           
                # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(self.no_go_zone.last_az_el[0], 35))
                            
                adj_az, adj_el = self.move_to_az_el(self.no_go_zone.last_az_el[0], 35)          
                time.sleep(2)   
                if abs((self.ptu_el_pos - adj_el))<1:
                    break           

        logging.info("Panning to 0 deg az")            
        park_start = time.time()
        while ((time.time() - park_start) < 30) :   
            # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(0, 35))
            adj_az, adj_el = self.move_to_az_el(0, 35)
            time.sleep(2)                         
            # But here is makes more sense to use -180 to 180... 
            wrapped_pos = (self.ptu_az_pos + 180) % 360 - 180
            wrapped_dest_point = (adj_az + 180) % 360 - 180
            if abs((wrapped_pos - wrapped_dest_point))<1:
                break                                   
        park_start = time.time()

        logging.info("Parking to 0/0")         
        while (not self.parked()) : 
            # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(0, 0))
            adj_az, adj_el = self.move_to_az_el(0, 0)
            time.sleep(2)
            if (time.time() - park_start)>30:
                logging.warning("Did not finish parking in alloted time (45 seconds), ending")                
                break        
        self.ptu_state = next_state
        
    def move_to_az_el(self, azimuth:float, elevation: float, 
                      force_cw:bool=False,force_ccw:bool=False)->tuple:
        '''
        Send command to move the positioner to a specific Az/El. The client will 
        adjust for NO GO Zones and send the "adjusted" positions to the manager. 
        The manager will translate these Az/Els to clockwise/counter clockwise 
        pan tilt values. 
        If the commanded positions exceed the hard limits of the positioner, 
        the manager will limit/cap the commanded pan/tilt appropriately. 
        '''        
        azimuth = ((azimuth+180)%360)-180
        
        adj_az, adj_el = self.no_go_zone.adjust_for_zone(azimuth, elevation)
        if ((adj_az%360) != (azimuth%360)) or (adj_el!= elevation):            
            warning_msg = "PTU ID {} commanded point az= {:.1f} el={:.1f} is in a no go zone. Pointing to point the perimeter, az= {:.1f} el={:.1f}".format(self.ptu_id.id, azimuth,elevation, adj_az, adj_el)
            self.publish_wrapper("{}_{}".format(Topics.POINTING_WARNING_MSG, self.ptu_id), ptu_pb.PointingWarningMsg(msg=warning_msg, ptu_id = self.ptu_id.id))
        
        ptu_pan, ptu_tilt = self._convert_to_ptu_frame(adj_az, adj_el, force_cw, force_ccw )
        if self.ptu_id.cont_rot:
            ptu_pan = (ptu_pan % 360)
            adj_az = (adj_az % 360)
            
        # ptu_pan, ptu_tilt = convert_to_ptu_frame(adj_az, adj_el, self.ptu_pan_to_az, self.ptu_tilt_to_el)
        temp_time = Timestamp()
        temp_time.GetCurrentTime()
        self.last_command["time"] = temp_time
        self.last_command["azimuth"] = adj_az
        self.last_command["elevation"] = adj_el       
        logger.info("\n    Moving to Az {:0.2f} El {:0.1f} || Pan= {:0.2f}, Tilt={:0.2f} || Force CW = {}, Force CCW={} ".format(azimuth, elevation, ptu_pan, ptu_tilt, force_cw, force_ccw))        
        self.move_to(ptu_pan, ptu_tilt)
        return adj_az, adj_el            
        
    def move_to(self, pan:float, tilt:float):
        if self.simulate_hw:
            self.ptu_az_pos = self.last_command["azimuth"]
            self.ptu_el_pos = self.last_command["elevation"]
            self.ptu_pan_pos, self.ptu_tilt_pos = self._convert_to_ptu_frame(self.ptu_az_pos, self.ptu_el_pos)
            return
        try:
            self.ptu.move_to(pan, tilt)
        except serialptu.errors.TimeoutError as e:
            logger.warning("PTU Timeout Error. Set DEBUG for details")
            logger.debug("Details: ", exc_info=e)        
        except Exception as e:
            logger.warning("Some other error")
            logger.warning("Details: ", exc_info=e)                    
        
    def reset_motor_wrapper(self)->None:
        try:
            self.ptu.reset_motor_timeout()                             
        except serialptu.errors.TimeoutError as e:
            logger.warning("PTU Timeout Error. Set DEBUG for details")
            logger.debug("Details: ", exc_info=e) 
        except Exception as e:
            logger.warning("Some other error")
            logger.warning("Details: ", exc_info=e)                       
            
    def simulated_hw_listener(self):
        while self.running:
            ptu_command_msg = ptu_pb.PTUCommandStatus(
                timestamp=self.last_command["time"], 
                azimuth = self.last_command["azimuth"],
                elevation =self.last_command["elevation"] )
            
            ptu_status_msg = ptu_pb.PositionerStatus()       
            ptu_status_msg.state = self.ptu_state
            ptu_status_msg.id = self.ptu_id.id            
            ptu_status_msg.pan = self.ptu_pan_pos
            ptu_status_msg.tilt = self.ptu_tilt_pos                            
            ptu_status_msg.azimuth = self.ptu_az_pos
            ptu_status_msg.elevation = self.ptu_el_pos
            ptu_status_msg.ptu_pan_to_az = self.ptu_pan_to_az 
            
            ptu_status_msg.command.CopyFrom(ptu_command_msg) 
            temp_time = Timestamp()
            temp_time.GetCurrentTime()            
            ptu_status_msg.timestamp.CopyFrom(temp_time)
                            
            self.publish_wrapper("{}_{}".format(Topics.PTU_STATUS, self.ptu_id.id), ptu_status_msg)
            ptu_move_msg = ptu_move_msg_from_pb(ptu_status_msg)                         
            logger.info(ptu_move_msg.print())

            time.sleep(1)

    def ptu_status_listener(self, ptu_data:dict):
        '''
        Callback for the internal PTU status data. Only handles move_response messages
        Re-packages the data into a protobuf to send on topic Topics.PTU_STATUS

        Resets the PTU if there has been a Timeout (TO) or Direction Error (DE) reported in the ptu_data call
        '''
        # ptu_data = {'message_type': _ , 'command': __, 'pan': ___, 'tilt': ___ 'status'}
        reset_motor = False
        if (ptu_data["message_type"] == "move_response") or (ptu_data["message_type"] == "status_response"):
            ptu_status_msg = ptu_pb.PositionerStatus()
            ptu_dynamics_status = ptu_status_msg.status
            reset_wait = 1
            ptu_data_msg = PTUDataMsg.from_dict(ptu_data)
            if ptu_data_msg.status.pan.DE:
                logger.warning("Pan Directional Error... Resetting")
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.pan.TO:
                logger.warning("Pan Timeout Error... Resetting")                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.pan.CWSL or ptu_data_msg.status.pan.CCWSL:
                logger.warning("Pan Soft Limits Exceeded... Resetting")                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.pan.CWHL or ptu_data_msg.status.pan.CCWHL:
                logger.warning("(Maybe this more about this one?) Pan Hard Limits Exceeded... Resetting")                                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            if ptu_data_msg.status.tilt.DE:
                logger.warning("Tilt Directional Error... Resetting")
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.tilt.TO:
                logger.warning("Tilt Timeout Error... Resetting")                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.tilt.USL or ptu_data_msg.status.tilt.DSL:
                logger.warning("Tilt Soft Limits Exceeded... Resetting")                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.tilt.UHL or ptu_data_msg.status.tilt.DHL:
                logger.warning("(Maybe this more about this one?) tilt Hard Limits Exceeded... Resetting")                                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
                                
            # ptu_status_msg.command = ptu_data["command"]
            ptu_command_msg = ptu_pb.PTUCommandStatus(
                timestamp=self.last_command["time"], 
                azimuth = self.last_command["azimuth"],
                elevation =self.last_command["elevation"] )            

            ptu_status_msg = ptu_pb.PositionerStatus()       
            
            self.ptu_pan_pos = ptu_data_msg.pan #ptu_data["pan"]
            self.ptu_tilt_pos = ptu_data_msg.tilt #ptu_data["tilt"]
            self.ptu_az_pos, self.ptu_el_pos = self._convert_from_ptu_frame(ptu_data_msg.pan,  ptu_data_msg.tilt)
            
            quadrant = self._get_quadrant(ptu_data_msg.pan)

            # statusData
            ptu_data_msg.status.to_pb()
            # ptu_status_msg.status = ptu_dynamics_status
            ptu_status_msg.state = self.ptu_state
            ptu_status_msg.id = self.ptu_id.id            
            ptu_status_msg.pan = self.ptu_pan_pos
            ptu_status_msg.tilt = self.ptu_tilt_pos                            
            ptu_status_msg.azimuth = self.ptu_az_pos
            ptu_status_msg.elevation = self.ptu_el_pos
            ptu_status_msg.ptu_pan_to_az = self.ptu_pan_to_az             
                
            ptu_status_msg.command.CopyFrom(ptu_command_msg) 
            ptu_status_msg.status.CopyFrom(ptu_data_msg.status.to_pb())
            temp_time = Timestamp()
            temp_time.GetCurrentTime()            
            ptu_status_msg.timestamp.CopyFrom(temp_time)
                                 
            # Log formatted message
            ptu_move_msg = ptu_move_msg_from_pb(ptu_status_msg)
            status_str = ptu_move_msg.print()            
            
            if (self.ptu_state == "tle_loaded") or (self.ptu_state == "tle_primed") or (self.ptu_state == "tle_tracking"):
                sat_az, sat_el = self.get_sat_pos(datetime.now(timezone.utc))
                status_str += "\n{:<33}({})  Sat Pos: Az:{:6.1f} El:{:4.1f}".format("",self.curr_tle.norad_id, sat_az, sat_el)

            logger.info(status_str)
            # Publish message
            self.publish_wrapper("{}_{}".format(Topics.PTU_STATUS, self.ptu_id.id), ptu_status_msg)

        else:
            logger.warning("Received a ptuStatusMessage that isn't supported. Type: %s" % ptu_data["message_type"])

    def publish_wrapper(self, topic:str, msg):
        '''
        Wrapper function for Messenger publish
        '''
        try:
            self.messenger.publish(topic, msg)
        except Exception as e:
            logger.error("Exception when sending message to ActiveMQ Broker.", exc_info = e)
            logger.error("Topic: {}".format(topic))
            logger.error("MSG: {}".format(msg))

    def run(self):
        '''
        state machine
        '''
        if not self.running:
            logger.error("Initialization failed... Was not running")
            return
        while self.running:
            try:
                # logger.error("Test")
                time_now = datetime.now(timezone.utc)
                if self.ptu_state == "free":
                    time.sleep(1)                
                elif self.ptu_state == "parking":
                    time.sleep(1)
                elif self.ptu_state == "calibrating":
                    time.sleep(1)
                elif self.ptu_state == "tle_loaded":
                    time.sleep(1)
                elif self.ptu_state == "tle_primed":
                    sat_az, sat_el = self.get_sat_pos(time_now)                    
                    if sat_el >= self.elevation_mask:
                        self.ptu_state = "tle_tracking"
                        logger.warning("Above Elevation Mask, starting Tracking")
                    else:
                        time.sleep(0.1)
                elif self.ptu_state == "tle_tracking":
                    sat_az, sat_el = self.get_sat_pos(time_now + timedelta(seconds=PTU_DEFAULTS.TRACKING_UPDATE_RATE/2))
                    if sat_el >= self.elevation_mask:
                        if (self.apply_errors) and (self.ptu_id.allow_pointing_errors):
                            t_err = (time_now - self.prime_t_ref).total_seconds()
                            az_error = self.az_err_spline(t_err)      
                            if np.isnan(az_error):
                                az_error = 0
                            el_error = self.el_err_spline(t_err)
                            if np.isnan(el_error):
                                el_error = 0        
                        else:       
                            az_error = 0
                            el_error = 0              
                        az_dest = az_error + sat_az
                        el_dest = el_error + sat_el
                        # logger.warning("Debug move command az: {:0.1f}, el: {:0.1f}".format(az_dest, el_dest))                        
                        self.move_to_az_el(az_dest, el_dest, self.curr_pass_force_cw, self.curr_pass_force_ccw)
                    else:
                        self.curr_pass_prime_cw = False
                        self.curr_pass_prime_ccw = False  
                        self.curr_pass_force_cw = False
                        self.curr_pass_force_ccw = False                          
                        self.apply_errors = False
                        self.az_err_spline = interp1d([0, 1e6], [0, 0], 'previous', bounds_error=False, fill_value=0)
                        self.el_err_spline = interp1d([0, 1e6], [0, 0], 'previous', bounds_error=False, fill_value=0)                                          
                        self.park_ptu()                    
                    time.sleep(PTU_DEFAULTS.TRACKING_UPDATE_RATE)
                time.sleep(1)
            except Exception as e:
                logging.error("An exception occurred:")
                logging.error(traceback.print_exc())


_PointingIdentity = namedtuple("_PointingIdentity", "id cont_rot hard_pan_lim_cw hard_pan_lim_ccw")


def _prime_targets(azimuth, elevation, initial_azimuth, clockwise, counterclockwise):
    if type(clockwise) is not bool or type(counterclockwise) is not bool or (clockwise and counterclockwise):
        raise PointingError("invalid_argument")
    first = ((initial_azimuth, elevation, False, False),)
    if clockwise or counterclockwise:
        final = azimuth % 360 if clockwise else azimuth % 360 - 360
        return first + tuple((part * final / 3, elevation, clockwise, counterclockwise)
                             for part in (1, 2, 3))
    return first + ((azimuth, elevation, False, False),)


class _PointingManager:
    """Explicit strict owner; the legacy constructor and command loop are separate."""

    def __init__(self, messenger, settings, ptu_id, driver, elevation_mask,
                 no_go_data, run_deadline, cancel, outcome_timeout=None):
        self._deadline(run_deadline, cancel)
        if outcome_timeout is not None and (
                type(outcome_timeout) not in (int, float)
                or not 0 < outcome_timeout <= 3 or not math.isfinite(outcome_timeout)):
            raise PointingError("invalid_argument")
        policy = PointingPolicy.from_settings(settings, ptu_id, elevation_mask, no_go_data)
        if (type(messenger) is not Messenger or messenger.strict_instance_compatible(settings) is not True
                or type(driver) is not PTU or driver.pointing_available is not True):
            raise PointingError("invalid_argument")
        expected = (policy.protocol, 10 if policy.protocol == "PTCR20" else 100, policy.protocol_address)
        if driver.pointing_context != expected:
            raise PointingError("policy_mismatch")
        location = tuple(settings.get(key) for key in
                         ("ground_station_lat", "ground_station_lon", "ground_station_altm"))
        if (any(type(v) not in (int, float) or abs(v) > 1000000 or not math.isfinite(v) for v in location)
                or not -90 <= location[0] <= 90 or not -180 <= location[1] <= 180):
            raise PointingError("invalid_argument")
        self._policy = policy
        self._location = (tuple(policy.station_location[3:6]) if policy.station_location is not None
                          else tuple(float(v) for v in location))
        self._initialize_lifecycle(messenger, driver, run_deadline, cancel, outcome_timeout)

    def _initialize_lifecycle(self, messenger, driver, run_deadline, cancel, outcome_timeout=None):
        self._driver = driver
        self.messenger = messenger
        self._run_deadline = run_deadline
        self._cancel = cancel
        self._closing = threading.Event()
        self._operation = threading.RLock()
        self._handle = None
        self._active = False
        self._invalid = False
        self._closed = False
        self._registrations = []
        self._routes = {}
        self._tle_text = None
        self.curr_tle = None
        self.iss = None
        self.ground_station = None
        self._last_endpoint = None
        self._state = "inactive"
        self._force = (False, False)
        self._prime_sender_id = None
        self._prime_sequence = 0
        self.last_outcome = ("none", 0, "none")
        self._outcome_timeout = outcome_timeout
        self._scheduled_sender = None
        self._scheduled_sequence = 0
        self._scheduled_terminal = False
        self._scheduled_handling = False
        self._scheduled_executing = False
        self._scheduled_submitted = 0
        self._scheduled_total_submitted = 0
        self._scheduled_possible_submission = False
        self.last_tracking_outcome = None
        self.outcome_published = False
        self.rejected = 0
        self._deadline(run_deadline, cancel)

    @property
    def policy(self):
        return self._policy

    @property
    def ptu_id(self):
        p = self._policy
        return _PointingIdentity(p.manager_id, p.continuous_rotation,
                                 p.hard_pan_limit_cw, p.hard_pan_limit_ccw)

    @property
    def ptu_pan_to_az(self):
        return self._policy.pan_to_az

    @property
    def ptu_tilt_to_el(self):
        return self._policy.tilt_to_el

    @property
    def elevation_mask(self):
        return self._policy.elevation_mask

    @property
    def ptu_state(self):
        return self._state

    @staticmethod
    def _deadline(deadline, cancel):
        if type(deadline) not in (int, float) or type(cancel) is not threading.Event:
            raise PointingError("invalid_argument")
        try:
            finite = math.isfinite(deadline)
        except OverflowError:
            finite = False
        if not finite:
            raise PointingError("invalid_argument")
        if cancel.is_set():
            raise PointingError("cancelled")
        remaining = deadline - time.monotonic()
        if cancel.is_set():
            raise PointingError("cancelled")
        if remaining <= 0:
            raise PointingError("deadline")
        return min(.01, remaining)

    def _check(self, deadline, cancel):
        if cancel is not self._cancel:
            raise PointingError("invalid_argument")
        if self._cancel.is_set() or cancel.is_set():
            raise PointingError("cancelled")
        if self._closing.is_set():
            raise PointingError("disconnected")
        if self._invalid:
            raise PointingError("context_changed")
        value = self._deadline(min(deadline, self._run_deadline), cancel)
        if self._cancel.is_set():
            raise PointingError("cancelled")
        return value

    @contextmanager
    def _locked(self, deadline, cancel):
        self._deadline(deadline, cancel)
        deadline = min(deadline, self._run_deadline)
        while not self._operation.acquire(timeout=self._check(deadline, cancel)):
            pass
        try:
            self._check(deadline, cancel)
            yield deadline
        finally:
            self._operation.release()

    @staticmethod
    def _translated(error, submitted=None):
        if submitted is None:
            submitted = getattr(error, "submitted", 0)
        primary = getattr(error, "primary", "")
        if primary not in CATEGORIES - {"ok"}:
            primary = "context_changed" if primary in ("invalidated", "context-changed", "prepared") else "serial_failure"
        return PointingError(primary, submitted, getattr(error, "submission", "none"))

    def activate(self, *, deadline, cancel):
        with self._locked(deadline, cancel) as deadline:
            if self._active:
                return True
            if self._handle is not None:
                raise PointingError("context_changed")
            try:
                self._handle = self._driver.bind_pointing(self._policy.binding, deadline=deadline, cancel=cancel)
                self._check(deadline, cancel)
                self._driver.open_bounded(deadline=deadline, cancel=cancel)
                with self._driver.pointing_guard(self._handle, deadline=deadline, cancel=cancel):
                    self._observe(self._driver.get_status_bounded(self._handle, deadline=deadline, cancel=cancel)[1])
                topics = ((Topics.PING_CMD, "ping"), (Topics.PTU_POSITION_COMMAND, "move"),
                          (Topics.TLE_LOAD_COMMAND, "load"), (Topics.TLE_PRIME_COMMAND, "prime"),
                          (Topics.CALIBRATE_COMMAND, "reject"), (Topics.ABORT_COMMAND, "reject"),
                          (Topics.PARK_COMMAND, "reject"), (Topics.ERROR_PROFILE_COMMAND, "reject"))
                for topic, kind in topics:
                    for selected in (False, True):
                        identifier = str(len(self._registrations))
                        route = "{}_{}".format(topic, self._policy.manager_id if selected else 0)
                        registration = (route, self._command_cb, identifier)
                        self._routes[identifier] = (kind, selected)
                        self._registrations.append(registration)
                        self.messenger.subscribe(*registration, deadline=deadline, cancel=cancel)
                        self._check(deadline, cancel)
                if self._outcome_timeout is not None:
                    identifier = str(len(self._registrations))
                    route = "{}_{}".format(Topics.SCHEDULED_COMMAND, self._policy.manager_id)
                    registration = (route, self._scheduled_cb, identifier)
                    self._routes[identifier] = ("scheduled", True)
                    self._registrations.append(registration)
                    self.messenger.subscribe(*registration, deadline=deadline, cancel=cancel)
                    self._check(deadline, cancel)
                self._state = "free"
                self._active = True
                return True
            except BaseException as error:
                self._invalid = True
                self.last_outcome = ("activation", 0, "none")
                raise self._translated(error) from None

    def _admit_command(self, binding, deadline, cancel):
        if self._outcome_timeout is not None:
            if not self._scheduled_executing:
                raise PointingError("unsupported")
            if self._scheduled_terminal:
                raise PointingError("context_changed")
        self._check(deadline, cancel)
        if not self._active:
            raise PointingError("disconnected")
        if type(binding) is not bytes or binding != self._policy.binding:
            raise PointingError("policy_mismatch")

    def _publish(self, topic, message, deadline, cancel):
        self._check(deadline, cancel)
        payload = message.SerializeToString()
        if len(payload) > 8192:
            raise PointingError("invalid_argument")
        self.messenger.publish("{}_{}".format(topic, self._policy.manager_id), payload,
                               deadline=deadline, cancel=cancel)
        self._check(deadline, cancel)

    def _command_cb(self, payload, identifier):
        if not self._operation.acquire(False):
            self.rejected = min(self.rejected + 1, 2**31 - 1)
            return
        try:
            if self._closing.is_set() or not self._active:
                return
            if self._outcome_timeout is not None:
                raise PointingError("unsupported")
            if type(payload) is not bytes or len(payload) > 8192:
                raise PointingError("invalid_argument")
            kind, selected = self._routes.get(identifier, ("reject", False))
            if not selected or kind == "reject":
                raise PointingError("policy_mismatch")
            message_type = {"ping": ptu_pb.PingCmd, "move": ptu_pb.PositionCommandMsg,
                            "load": ptu_pb.TleLoadCmd, "prime": ptu_pb.TlePrimeCmd}[kind]
            command = message_type.FromString(payload)
            deadline, cancel = self._run_deadline, self._cancel
            self._admit_command(command.pointing_binding, deadline, cancel)
            if kind == "ping":
                if not command.ping:
                    raise PointingError("invalid_argument")
                self._publish(Topics.PONG_RESPONSE,
                              ptu_pb.PongResponse(pong=self._policy.manager_id,
                                                 pointing_binding=self._policy.binding), deadline, cancel)
            elif kind == "load":
                self.load_tle(command.tle_str, binding=command.pointing_binding, deadline=deadline, cancel=cancel)
                self._publish(Topics.TLE_LOAD_REPLY, ptu_pb.TleReplyMsg(
                    success=True, msg="loaded", ptu_id=self._policy.manager_id,
                    pointing_binding=self._policy.binding), deadline, cancel)
            elif kind == "prime":
                if not command.prime:
                    raise PointingError("invalid_argument")
                self.prime_ptu(round(command.azimuth * 100) / 100,
                               round(command.elevation * 100) / 100,
                               binding=command.pointing_binding,
                               prime_sender_id=command.prime_sender_id,
                               prime_sequence=command.prime_sequence,
                               deadline=deadline, cancel=cancel)
            else:
                self.move_to_az_el(round(command.azimuth * 100) / 100,
                                  round(command.elevation * 100) / 100,
                                  force_cw=command.force_cw, force_ccw=command.force_ccw,
                                  binding=command.pointing_binding, deadline=deadline, cancel=cancel)
        except Exception as error:
            failure = self._translated(error)
            self.rejected = min(self.rejected + 1, 2**31 - 1)
            if self._outcome_timeout is None:
                self.last_outcome = (failure.primary, getattr(error, "submitted", 0), failure.submission)
        finally:
            self._operation.release()

    @staticmethod
    def _scheduled_payload(command):
        operation = command.operation
        allowed = {1, 2, 3, 4}
        if operation == ptu_pb.ScheduledCommand.LOAD:
            allowed.add(5)
            if not command.tle:
                raise PointingError("invalid_argument")
        elif operation == ptu_pb.ScheduledCommand.PRIME:
            allowed.update((6, 7))
            if not math.isfinite(command.azimuth) or not math.isfinite(command.elevation):
                raise PointingError("invalid_argument")
        if any(field.number not in allowed for field, value in command.ListFields()):
            raise PointingError("invalid_argument")
        known = ptu_pb.ScheduledCommand()
        known.CopyFrom(command)
        known.DiscardUnknownFields()
        if known.SerializeToString() != command.SerializeToString():
            raise PointingError("invalid_argument")

    def _scheduled_operation(self, command):
        operation = command.operation
        controls = dict(binding=self._policy.binding, deadline=self._run_deadline,
                        cancel=self._cancel)
        reserve = 4 if operation == ptu_pb.ScheduledCommand.PRIME else (
            1 if operation == ptu_pb.ScheduledCommand.TRACK else 0)
        if self._scheduled_total_submitted > MAX_SEQUENCE - reserve:
            raise PointingError("unsupported")
        if operation == ptu_pb.ScheduledCommand.CONNECT:
            if self._state != "free":
                raise PointingError("busy")
        elif operation == ptu_pb.ScheduledCommand.LOAD:
            self.load_tle(command.tle, **controls)
        elif operation == ptu_pb.ScheduledCommand.PRIME:
            if self._state != "tle_loaded":
                raise PointingError("busy")
            self.prime_ptu(command.azimuth, command.elevation,
                           prime_sender_id=command.sender,
                           prime_sequence=command.sequence, **controls)
        elif operation == ptu_pb.ScheduledCommand.TRACK:
            try:
                self.track_once(datetime.now(timezone.utc), **controls)
            except PointingError:
                raise
            except Exception:
                raise PointingError("scheduler_failure") from None
        else:
            if self._state not in ("tle_primed", "tle_tracking"):
                raise PointingError("invalid_argument")
            self._state = "complete"
        if self._state == "complete":
            self._scheduled_terminal = True

    def _report_scheduled(self, command, outcome):
        try:
            message = ptu_pb.ScheduledOutcome(
                manager_id=outcome.manager_id, request_binding=command.request_binding,
                manager_binding=self._policy.binding, sender=command.sender,
                sequence=outcome.sequence, operation=outcome.operation,
                category=outcome.category, state=outcome.state,
                submitted=outcome.submitted, submission=outcome.submission,
                total_submitted=outcome.total_submitted,
                possible_submission=outcome.possible_submission)
            payload = message.SerializeToString()
            if len(payload) > 8192:
                raise PointingError("invalid_argument")
            # Reporting gets its own nonmotion budget, never fresh driver authority.
            self.messenger.publish(
                "{}_{}".format(Topics.SCHEDULED_OUTCOME, self._policy.manager_id),
                payload, deadline=time.monotonic() + self._outcome_timeout,
                cancel=threading.Event())
        except Exception:
            return False
        return True

    def _scheduled_cb(self, payload, identifier):
        if (self._outcome_timeout is None
                or type(identifier) is not str
                or self._routes.get(identifier) != ("scheduled", True)):
            self.rejected = min(self.rejected + 1, 2**31 - 1)
            return
        try:
            if type(payload) is not bytes or not 0 < len(payload) <= 8192:
                raise PointingError("invalid_argument")
            command = ptu_pb.ScheduledCommand.FromString(payload)
            if (len(command.request_binding) != 32 or len(command.sender) != 16
                    or not 0 < command.sequence <= MAX_SEQUENCE
                    or command.operation not in (
                        ptu_pb.ScheduledCommand.CONNECT, ptu_pb.ScheduledCommand.LOAD,
                        ptu_pb.ScheduledCommand.PRIME, ptu_pb.ScheduledCommand.TRACK,
                        ptu_pb.ScheduledCommand.COMPLETE)):
                raise PointingError("invalid_argument")
        except Exception:
            self.rejected = min(self.rejected + 1, 2**31 - 1)
            return
        if not self._operation.acquire(False):
            self.rejected = min(self.rejected + 1, 2**31 - 1)
            return
        if self._closing.is_set() or not self._active:
            self._operation.release()
            return
        if self._scheduled_handling:
            self._operation.release()
            self.rejected = min(self.rejected + 1, 2**31 - 1)
            return
        self._scheduled_handling = True
        try:
            if self._scheduled_terminal:
                self.rejected = min(self.rejected + 1, 2**31 - 1)
                return
            claimed = False
            category, submitted, submission = "ok", 0, "none"
            try:
                if command.request_binding != self._policy.binding:
                    raise PointingError("policy_mismatch")
                if self._scheduled_sender is not None and command.sender != self._scheduled_sender:
                    raise PointingError("policy_mismatch")
                if command.sequence <= self._scheduled_sequence:
                    self.rejected = min(self.rejected + 1, 2**31 - 1)
                    return
                if self._scheduled_sender is None and command.operation != ptu_pb.ScheduledCommand.CONNECT:
                    raise PointingError("disconnected")
                connected = self._scheduled_sender is not None
                claimed = True
                self._scheduled_sender = command.sender
                self._scheduled_sequence = command.sequence
                self._scheduled_submitted = 0
                self.outcome_published = False
                if connected and command.operation == ptu_pb.ScheduledCommand.CONNECT:
                    raise PointingError("unsupported")
                self._scheduled_payload(command)
                self._check(self._run_deadline, self._cancel)
                if not self._active:
                    raise PointingError("disconnected")
                self._scheduled_executing = True
                self._scheduled_operation(command)
                self._check(self._run_deadline, self._cancel)
                submitted = self._scheduled_submitted
            except Exception as error:
                submitted = self._scheduled_submitted if claimed else 0
                failure = self._translated(error, submitted)
                category, submission = failure.primary, failure.submission
                self.rejected = min(self.rejected + 1, 2**31 - 1)
                if claimed:
                    self._scheduled_terminal = True
                    self._invalid = True
                    if self._state not in ("fault", "complete", "invalidated"):
                        self._state = "failed"
                    if submitted or submission != "none":
                        self._scheduled_possible_submission = True
            finally:
                self._scheduled_executing = False
            state = "tle_priming" if self._state == "priming" else self._state
            if state not in STATES:
                state = "invalidated"
            outcome = TrackingOutcome(
                self._policy.manager_id, command.sequence, command.operation,
                category, state, submitted, submission, self._scheduled_total_submitted,
                self._scheduled_possible_submission)
            retain = claimed or (self.last_tracking_outcome is None
                                 and command.operation == ptu_pb.ScheduledCommand.CONNECT)
            if retain:
                self.last_tracking_outcome = outcome
                self.last_outcome = (category, submitted, submission)
                self.outcome_published = False
            published = self._report_scheduled(command, outcome)
            if retain:
                self.outcome_published = published
        finally:
            self._scheduled_handling = False
            self._operation.release()

    def _fresh_orbit(self):
        self.ground_station = ephem.Observer()
        self.ground_station.lat = self._location[0] * deg2rad
        self.ground_station.lon = self._location[1] * deg2rad
        self.ground_station.elevation = self._location[2]
        parts = self._tle_text.split(",")
        self.curr_tle = TLE(name=parts[0], tle_str=self._tle_text,
                            t_ref=datetime.now(timezone.utc), norad_id=parts[1][2:7])
        self.iss = ephem.readtle(*parts)

    def load_tle(self, text, *, binding, deadline, cancel):
        with self._locked(deadline, cancel) as deadline:
            self._admit_command(binding, deadline, cancel)
            if self._state in ("tle_primed", "tle_tracking"):
                raise PointingError("busy")
            admitted = self._policy.validate_tle(text)
            self._tle_text = admitted
            try:
                self._fresh_orbit()
                self._check(deadline, cancel)
            except BaseException as error:
                self._tle_text = None
                self.curr_tle = self.iss = self.ground_station = None
                self._state = "free"
                if isinstance(error, PointingError):
                    raise
                raise PointingError("invalid_argument") from None
            self._state = "tle_loaded"
            return True

    def _prepare(self, targets, deadline, cancel):
        packets = []
        if not 1 <= len(targets) <= 4:
            raise PointingError("invalid_argument")
        for azimuth, elevation, cw, ccw in targets:
            self._check(deadline, cancel)
            self._policy.check_forces(cw, ccw)
            azimuth, elevation = self._policy.check_endpoint(azimuth, elevation)
            try:
                pan, tilt = convert_to_ptu_frame(
                    ((azimuth + 180) % 360) - 180, elevation,
                    self._policy.pan_to_az, self._policy.tilt_to_el,
                    self._policy.continuous_rotation, cw, ccw,
                    self._policy.hard_pan_limit_cw, self._policy.hard_pan_limit_ccw,
                    diagnostics=False)
            except Exception:
                raise PointingError("endpoint_rejected") from None
            self._check(deadline, cancel)
            packet = self._driver.prepare_move_to(self._handle, pan, tilt,
                                                  deadline=deadline, cancel=cancel)
            self._policy.check_encoded(packet)
            packets.append(packet)
        return tuple(packets)

    def _observe(self, data):
        if type(data) is not dict or data.get("message_type") not in ("move_response", "status_response"):
            raise PointingError("serial_failure")
        pan, tilt = data.get("pan"), data.get("tilt")
        if (any(type(v) not in (int, float) or abs(v) > 1000000 or not math.isfinite(v)
                for v in (pan, tilt)) or type(data.get("status")) is not list):
            raise PointingError("serial_failure")
        parsed = PTUDataMsg.from_dict(data)
        if parsed.status.pan.any_true() or parsed.status.tilt.any_true():
            self._invalid = True
            self._state = "fault"
            raise PointingError("serial_failure")
        azimuth, elevation = convert_from_ptu_frame(pan, tilt, self._policy.pan_to_az,
                                                    self._policy.tilt_to_el, self._policy.continuous_rotation)
        self._last_endpoint = (azimuth, elevation)
        return pan, tilt

    def _await_target(self, packet, data, deadline, cancel):
        while True:
            pan, tilt = self._observe(data)
            if pan == packet.pan_units / packet.units_per_degree and tilt == packet.tilt_units / packet.units_per_degree:
                return
            self._cancel.wait(self._check(deadline, cancel))
            self._check(deadline, cancel)
            data = self._driver.get_status_bounded(self._handle, deadline=deadline, cancel=cancel)[1]

    def _execute_targets(self, targets, deadline, cancel, await_position=False):
        submitted = 0
        try:
            with self._driver.pointing_guard(self._handle, deadline=deadline, cancel=cancel):
                packets = self._prepare(targets, deadline, cancel)
                for packet in packets:
                    self._check(deadline, cancel)
                    self._policy.check_encoded(packet)
                    self._check(deadline, cancel)
                    response = self._driver.submit_prepared_move(self._handle, packet,
                                                                  deadline=deadline, cancel=cancel)
                    submitted += 1
                    if self._outcome_timeout is not None and self._scheduled_executing:
                        self._scheduled_submitted += 1
                        self._scheduled_total_submitted += 1
                        self._scheduled_possible_submission = True
                    self._check(deadline, cancel)
                    if await_position:
                        self._await_target(packet, response[1], deadline, cancel)
                    else:
                        self._observe(response[1])
                    self._check(deadline, cancel)
                self._check(deadline, cancel)
                self.last_outcome = ("submitted", submitted, "complete")
                return packets
        except BaseException as error:
            failure = self._translated(error, submitted)
            self.last_outcome = (failure.primary, submitted, failure.submission)
            self._state = "failed"
            if submitted or failure.submission != "none" or failure.primary in ("serial_failure", "context_changed"):
                self._invalid = True
            raise failure from None

    def move_to_az_el(self, azimuth, elevation, force_cw=False, force_ccw=False, *,
                      binding, deadline, cancel):
        with self._locked(deadline, cancel) as deadline:
            self._admit_command(binding, deadline, cancel)
            if self._state in ("tle_primed", "tle_tracking"):
                raise PointingError("busy")
            self._execute_targets(((azimuth, elevation, force_cw, force_ccw),), deadline, cancel)
            return True

    def prime_ptu(self, azimuth, elevation, *, binding, prime_sender_id,
                  prime_sequence, deadline, cancel):
        with self._locked(deadline, cancel) as deadline:
            self._admit_command(binding, deadline, cancel)
            if self._tle_text is None or self._state not in ("tle_loaded", "tle_primed"):
                raise PointingError("invalid_argument")
            if (type(prime_sender_id) is not bytes or len(prime_sender_id) != 16
                    or type(prime_sequence) is not int or not 0 < prime_sequence <= 2**64 - 1):
                raise PointingError("invalid_argument")
            if (self._prime_sender_id is not None and prime_sender_id != self._prime_sender_id
                    or prime_sequence <= self._prime_sequence):
                raise PointingError("policy_mismatch")
            self._prime_sender_id = prime_sender_id
            self._prime_sequence = prime_sequence
            self._state = "priming"
            submitted = 0
            try:
                azimuth, elevation = self._policy.check_endpoint(azimuth, elevation)
                self._fresh_orbit()
                plan = PtuManager.pre_plan_pass(self, diagnostics=False)
                if (type(plan) is not tuple or len(plan) != 4 or any(type(v) is not bool for v in plan)
                        or (plan[0] and plan[1]) or (plan[2] and plan[3])):
                    raise PointingError("invalid_argument")
                self._check(deadline, cancel)
                if self._last_endpoint is None:
                    raise PointingError("disconnected")
                targets = _prime_targets(azimuth, elevation, self._last_endpoint[0], plan[0], plan[1])
                self._state = "priming"
                packets = self._execute_targets(targets, deadline, cancel, await_position=True)
                submitted = len(packets)
                self._check(deadline, cancel)
                self._force = (plan[2], plan[3])
                self._state = "tle_primed"
                self._publish_status(deadline, cancel)
                return True
            except BaseException as error:
                self._state = "failed"
                count = max(submitted, getattr(error, "submitted", 0))
                failure = self._translated(error, count)
                self.last_outcome = (failure.primary, count, failure.submission)
                if count or failure.submission != "none":
                    self._invalid = True
                raise failure from None

    def _publish_status(self, deadline, cancel):
        if self._outcome_timeout is not None:
            return
        self._check(deadline, cancel)
        azimuth, elevation = self._last_endpoint
        message = ptu_pb.PositionerStatus(state=self._state, id=self._policy.manager_id,
                                         azimuth=azimuth, elevation=elevation,
                                         pointing_binding=self._policy.binding,
                                         prime_sender_id=self._prime_sender_id or b"",
                                         prime_sequence=self._prime_sequence)
        message.timestamp.GetCurrentTime()
        self._publish(Topics.PTU_STATUS, message, deadline, cancel)

    def track_once(self, at, *, binding, deadline, cancel):
        with self._locked(deadline, cancel) as deadline:
            self._admit_command(binding, deadline, cancel)
            if type(at) is not datetime or at.tzinfo is not timezone.utc or self._state not in ("tle_primed", "tle_tracking"):
                raise PointingError("invalid_argument")
            azimuth, elevation = PtuManager.get_sat_pos(self, at)
            self._check(deadline, cancel)
            if type(elevation) not in (int, float) or not math.isfinite(elevation):
                raise PointingError("invalid_argument")
            if elevation < self._policy.elevation_mask:
                self._state = "complete"
                self._publish_status(deadline, cancel)
                return False
            submitted = 0
            try:
                packets = self._execute_targets(((azimuth, elevation, self._force[0], self._force[1]),), deadline, cancel)
                submitted = len(packets)
                self._state = "tle_tracking"
                self._publish_status(deadline, cancel)
                return True
            except BaseException as error:
                count = max(submitted, getattr(error, "submitted", 0))
                failure = self._translated(error, count)
                self._state = "failed"
                self.last_outcome = (failure.primary, count, failure.submission)
                if count or failure.submission != "none":
                    self._invalid = True
                raise failure from None

    def invalidate(self, *, deadline, cancel):
        self._deadline(deadline, cancel)
        if cancel is not self._cancel:
            raise PointingError("invalid_argument")
        deadline = min(deadline, self._run_deadline)
        self._deadline(deadline, cancel)
        self._invalid = True
        self._state = "invalidated"
        if self._handle is not None:
            self._driver.invalidate_pointing(self._handle, deadline=deadline, cancel=cancel)

    def close(self, *, deadline):
        self._closing.set()
        cleanup_cancel = threading.Event()
        try:
            while not self._operation.acquire(timeout=self._deadline(deadline, cleanup_cancel)):
                pass
        except PointingError:
            self._driver.close(deadline=deadline)
            raise PointingError("cleanup_incomplete") from None
        try:
            debt = []
            for registration in self._registrations:
                try:
                    self.messenger.cancelSubscribe(*registration, deadline=deadline, cancel=cleanup_cancel)
                except Exception as error:
                    if not isinstance(error, MessengerError) or error.primary != "admission":
                        debt.append(registration)
            self._registrations = debt
            self._driver.close(deadline=deadline)
            self._active = False
            self._state = "closed"
            self._closed = not debt
            if debt:
                raise PointingError("cleanup_incomplete")
            return True
        finally:
            self._operation.release()


def main():
    '''
    '''
    parser = argparse.ArgumentParser(description = 'Manager applique for active MQ clients interfacing with the Pan and tilt unit')
    parser.add_argument('-config', default = str(default_cfg), type=str, 
                        help = ('Config File, Defaults to {}.' \
                            'Yaml contains activeMQ connection information'.format(str(default_cfg))))      
    parser.add_argument("--ptu-id", required=True, type=int, 
                        help="PTU ID corresponding to PTU this instance manages as described in config.yaml")
    parser.add_argument("--port", "-p", default="/dev/ttyUSB0", help="Serial port to use")
    parser.add_argument("--nohw",  action = 'store_true', help="Test mode for when serial interface is not available. Tests interaction between client and manager")
    parser.add_argument("--protocol", choices=serialptu.get_protocols(), metavar="protocol", default="PTCR96",
                    help="(IGNORED, COMES FROM CONFIG NOW) Protocol selection, options are: " + ", ".join(serialptu.get_protocols()))

    args = parser.parse_args()
    
    # Load config File
    with open(args.config) as f:
        config = yaml.safe_load(f)      
    
    logging_level = logging.INFO # Will change to WARN later    
    root_logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    root_logger.setLevel(logging.DEBUG)
            
    log_dir = Path('/opt/ground_station/logs')    
    file_handler = logging.FileHandler(log_dir / 'ptu_manager.log', 'w+')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG) # Log DEBUG level to file.        
    logger.addHandler(file_handler)       
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)    
               
    credentials = {
                "username": config["amq_username"], 
                "password": config["amq_password"]}    
    messenger = Messenger(config['amq_server'], config['amq_port'], credentials, use_ssl=config['amq_use_ssl'])
    try:
        ptu_dict = {}
        for positioner in config['positioners']:
            ptu_dict[positioner['id']] = positioner    
        if ptu_dict[args.ptu_id]['no_go_config'] is None:
            no_go_config = None
        else:
            no_go_config = Path(ptu_dict[args.ptu_id]['no_go_config'])
            if '~' in str(no_go_config):
                no_go_config = Path(str(no_go_config).replace('~', config['home_directory']))                
            
        ptu_details = PtuID(args.ptu_id, ptu_dict[args.ptu_id]['protocol'],
                            ptu_dict[args.ptu_id]['baud'],
                            ptu_dict[args.ptu_id]['cont_rot'], 
                            ptu_dict[args.ptu_id]['hard_pan_lim_cw'], 
                            ptu_dict[args.ptu_id]['hard_pan_lim_ccw'], 
                            ptu_dict[args.ptu_id]['type'],
                            ptu_dict[args.ptu_id]['name'],
                            ptu_dict[args.ptu_id]['pix_id'],
                            ptu_dict[args.ptu_id]['allow_pointing_errors'],                            
                            no_go_config,
                            )
    except:
        logger.error("Formatting error of positioners value in config, check config.yaml")
        return
    if args.nohw:
        ptu = None
    else:
        serial_lib_logger = logging.getLogger('serial_ptu')
        formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
        serial_lib_logger.setLevel(logging.DEBUG)
                
        log_dir = Path('/opt/ground_station/logs')    
        file_handler = logging.FileHandler(log_dir / 'serial_ptu.log', 'w+')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.DEBUG) # Log DEBUG level to file.        
        serial_lib_logger.addHandler(file_handler)   

        ptu = serialptu.make_ptu(ptu_dict[args.ptu_id]['protocol'], 
                                 args.port, baud=ptu_dict[args.ptu_id]['baud'], 
                                 logger=serial_lib_logger)               
    
    manager = PtuManager(messenger, 
                         config=args.config, 
                         ptu=ptu, 
                         simulate_hw=args.nohw, 
                         ptu_id=ptu_details 
    )    
    
    # Test Commands
    # manager.calibrate()
    # tle_df = pd.read_csv(config["sat_db_file"])
    # tle_db = tle_df.set_index('norad_id').to_dict("index")          
    # manager.tle_load(tle_db[41589]['tle'])
    # manager.prime_ptu(237,30)
    # manager.abort()
    # time.sleep(25)
    # manager.move_to_az_el(20, 30)
    
    manager.run()

if __name__ == '__main__':
    main()
