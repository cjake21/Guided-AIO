"""Bounded mechanical bench commands through the existing PTU owners."""
import hashlib
import json
import math
import os
import threading
import time
from collections.abc import Mapping
from dataclasses import dataclass
from fractions import Fraction
from types import MappingProxyType

from ptu_control import ptu_msg_pb2 as pb
from ptu_control.constants import Topics
from ptu_control.pointing import PointingError
from ptu_control.ptu_client import _PointingClient, PtuError, _POINTING_CLIENT_PATH, _client_remaining
from meteor_api.messenger import Messenger


_EXCHANGE_CATEGORIES = frozenset((
    "ok", "deadline", "cancelled", "deadline-admission", "cancel-admission", "binding",
    "invalidated", "context-changed", "not-open", "readback-only", "protocol", "status-motion",
    "serial-context", "response", "stale-response", "write-count", "short-write", "serial-io",
    "strict-frame", "strict-escape", "strict-checksum", "strict-address", "strict-status",
    "strict-stop", "strict-jog", "strict-response", "strict-nak", "protocol-response",
))


def _controlled_rehearsal_boundary(driver, messenger):
    return False


def _mechanical_transport(settings):
    if "bench_transport" in settings:
        if (settings["bench_transport"] != "local-serial"
                or any(isinstance(key, str) and key.startswith("amq_") for key in settings)):
            raise PointingError("invalid_argument")
        return {"mode": "local-serial"}
    if "amq_transport" not in settings:
        return None
    if (settings["amq_transport"] != "loopback-plaintext-bench"
            or settings.get("amq_use_ssl") is not False
            or settings.get("amq_dial_address") != "127.0.0.1"
            or type(settings.get("amq_port")) is not int or not 1 <= settings["amq_port"] <= 65535
            or "amq_tls_server_name" in settings or "amq_ca_pem" in settings):
        raise PointingError("invalid_argument")
    host = settings.get("amq_stomp_host")
    if host is not None and (type(host) is not str or len(host) > 255 or not host.isascii()
                             or any(ord(character) < 32 or ord(character) == 127 for character in host)):
        raise PointingError("invalid_argument")
    return {"mode": "loopback-plaintext-bench", "dial": "127.0.0.1", "port": settings["amq_port"],
            "stomp_host": host}


def _mechanical_messenger_compatible(messenger, settings):
    if "bench_transport" in settings:
        return False
    if type(messenger) is not Messenger:
        return False
    if settings.get("amq_transport") == "loopback-plaintext-bench":
        return messenger.bench_loopback_instance_compatible(settings) is True
    return messenger.strict_instance_compatible(settings) is True


@dataclass(frozen=True)
class ReadbackContext:
    manager_id: int
    session_id: str
    equipment_label: str
    model: str
    protocol: str
    protocol_address: object
    serial_settings: object
    device_identity: object
    observation_max_age_seconds: float
    exchange_timeout_seconds: float
    binding: bytes

    @property
    def mode(self):
        return "query-only"

    @property
    def motion_allowed(self):
        return False

    @property
    def serial_port(self):
        return self.serial_settings["port"]

    @property
    def baud(self):
        return self.serial_settings["baudrate"]

    @classmethod
    def from_settings(cls, settings, ptu_id):
        if (not isinstance(settings, Mapping) or "bench_context" in settings or "manual_context" in settings
                or type(ptu_id) is not int or not 0 < ptu_id < 2**31):
            raise PointingError("invalid_argument")
        value = settings.get("readback_context")
        keys = set(cls.__dataclass_fields__) - {"binding", "manager_id"} | {"schema"}
        if (not isinstance(value, Mapping) or set(value) != keys
                or value["schema"] != "ptu-readback-context.v1"
                or value["model"] != "QPT130" or value["protocol"] != "PTCR20"
                or value["protocol_address"] is not None):
            raise PointingError("invalid_argument")
        session = value["session_id"]
        label = value["equipment_label"]
        if (type(session) is not str or len(session) != 64
                or any(character not in "0123456789abcdef" for character in session)
                or type(label) is not str or not 1 <= len(label) <= 256
                or not label.isascii() or not label.isprintable()):
            raise PointingError("invalid_argument")
        serial = value["serial_settings"]
        serial_keys = {"port", "baudrate", "bytesize", "parity", "stopbits", "xonxoff", "rtscts", "dsrdtr", "rts", "dtr"}
        if not isinstance(serial, Mapping) or set(serial) != serial_keys:
            raise PointingError("invalid_argument")
        port = serial["port"]
        if (type(port) is not str or not port.startswith("/dev/serial/by-id/")
                or not 1 <= len(port) <= 256 or not port.isascii() or not port.isprintable()
                or "/" in port[len("/dev/serial/by-id/"):] or port.endswith(("/", "/.", "/.."))
                or type(serial["baudrate"]) is not int or serial["baudrate"] != 9600
                or type(serial["bytesize"]) is not int or serial["bytesize"] not in (5, 6, 7, 8)
                or type(serial["parity"]) is not str or serial["parity"] not in ("N", "E", "O", "M", "S")
                or type(serial["stopbits"]) not in (int, float) or serial["stopbits"] not in (1, 1.5, 2)
                or any(type(serial[key]) is not bool for key in ("xonxoff", "rtscts", "dsrdtr", "rts", "dtr"))):
            raise PointingError("invalid_argument")
        identity = value["device_identity"]
        if (not isinstance(identity, Mapping)
                or set(identity) != {"vendor_id", "product_id", "serial_number", "interface_number", "driver"}):
            raise PointingError("invalid_argument")
        for key, length in (("vendor_id", 4), ("product_id", 4), ("interface_number", 2)):
            text = identity[key]
            if type(text) is not str or len(text) != length or any(c not in "0123456789abcdef" for c in text):
                raise PointingError("invalid_argument")
        for key in ("serial_number", "driver"):
            text = identity[key]
            characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" + ("." if key == "serial_number" else "")
            if (type(text) is not str or not 1 <= len(text) <= (128 if key == "serial_number" else 64)
                    or any(character not in characters for character in text)):
                raise PointingError("invalid_argument")
        for key, maximum in (("observation_max_age_seconds", 3600), ("exchange_timeout_seconds", 30)):
            number = value[key]
            if type(number) not in (int, float) or not math.isfinite(number) or not 0 < number <= maximum:
                raise PointingError("invalid_argument")
        record = dict(value, manager_id=ptu_id, serial_settings=dict(serial), device_identity=dict(identity))
        transport = _mechanical_transport(settings)
        if transport is not None:
            record["transport"] = transport
        for container, key in ((record, "observation_max_age_seconds"), (record, "exchange_timeout_seconds"),
                               (record["serial_settings"], "stopbits")):
            exact = Fraction(container[key])
            container[key] = str(exact.numerator) + "/" + str(exact.denominator)
        binding = hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":")).encode("ascii")).digest()
        return cls(ptu_id, session, label, value["model"], value["protocol"], None,
                   MappingProxyType(dict(serial)), MappingProxyType(dict(identity)),
                   value["observation_max_age_seconds"], value["exchange_timeout_seconds"], binding)


@dataclass(frozen=True)
class BenchContext:
    mode: str
    equipment_label: str
    serial_port: str
    baud: int
    pan_min: float
    pan_max: float
    tilt_min: float
    tilt_max: float
    max_change_degrees: float
    observation_max_age_seconds: float
    exchange_timeout_seconds: float
    binding: bytes

    @property
    def motion_allowed(self):
        return self.mode == "rehearsal"

    @classmethod
    def from_settings(cls, settings, policy):
        value = settings.get("bench_context")
        keys = set(cls.__dataclass_fields__) - {"binding"}
        if not isinstance(value, Mapping) or set(value) != keys:
            raise PointingError("invalid_argument")
        if type(value["mode"]) is not str or value["mode"] not in ("rehearsal", "operational"):
            raise PointingError("invalid_argument")
        for key in ("equipment_label", "serial_port"):
            text = value[key]
            if (type(text) is not str or not 1 <= len(text) <= 256
                    or not text.isascii() or not text.isprintable()):
                raise PointingError("invalid_argument")
        if type(value["baud"]) is not int or not 0 < value["baud"] <= 1000000:
            raise PointingError("invalid_argument")
        numbers = tuple(value[key] for key in ("pan_min", "pan_max", "tilt_min", "tilt_max",
                        "max_change_degrees", "observation_max_age_seconds", "exchange_timeout_seconds"))
        if any(type(v) not in (int, float) or not math.isfinite(v) for v in numbers):
            raise PointingError("invalid_argument")
        if not (-360 <= numbers[0] < numbers[1] <= 360 and -90 <= numbers[2] < numbers[3] <= 0
                and 0 < numbers[4] <= 360 and 0 < numbers[5] <= 3600 and 0 < numbers[6] <= 30):
            raise PointingError("invalid_argument")
        record = dict(value)
        for key in keys - {"mode", "equipment_label", "serial_port", "baud"}:
            exact = Fraction(value[key])
            record[key] = str(exact.numerator) + "/" + str(exact.denominator)
        record.update(version="ptu-bench-binding.v1", policy=policy.binding.hex())
        binding = hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":")).encode("ascii")).digest()
        return cls(*(value[key] for key in cls.__dataclass_fields__ if key != "binding"), binding)

    def check_target(self, pan, tilt, start):
        if (any(type(v) not in (int, float) or not math.isfinite(v) for v in (pan, tilt))
                or not self.pan_min <= start[0] <= self.pan_max
                or not self.tilt_min <= start[1] <= self.tilt_max
                or not self.pan_min <= pan <= self.pan_max
                or not self.tilt_min <= tilt <= self.tilt_max
                or abs(pan - start[0]) > self.max_change_degrees
                or abs(tilt - start[1]) > self.max_change_degrees
                or (pan != start[0] and tilt != start[1])):
            raise PointingError("endpoint_rejected")


@dataclass(frozen=True)
class ManualContext(ReadbackContext):
    frame: str
    pan_min: float
    pan_max: float
    tilt_min: float
    tilt_max: float
    max_change_degrees: float
    no_go_rectangle: object

    @property
    def mode(self):
        return "manual"

    @property
    def motion_allowed(self):
        return True

    @classmethod
    def from_settings(cls, settings, ptu_id):
        if not isinstance(settings, Mapping) or "readback_context" in settings or "bench_context" in settings:
            raise PointingError("invalid_argument")
        value = settings.get("manual_context")
        extra = {"frame", "pan_min", "pan_max", "tilt_min", "tilt_max", "max_change_degrees", "no_go_rectangle"}
        common = set(ReadbackContext.__dataclass_fields__) - {"binding", "manager_id"} | {"schema"}
        if (not isinstance(value, Mapping) or set(value) != common | extra
                or value["schema"] != "ptu-manual-context.v1"
                or value["frame"] != "mechanical-pan-tilt-degrees.v1"):
            raise PointingError("invalid_argument")
        adapted = {key: item for key, item in settings.items() if key != "manual_context"}
        adapted["readback_context"] = {key: value[key] for key in common}
        adapted["readback_context"]["schema"] = "ptu-readback-context.v1"
        base = ReadbackContext.from_settings(adapted, ptu_id)
        names = ("pan_min", "pan_max", "tilt_min", "tilt_max", "max_change_degrees")
        numbers = tuple(value[key] for key in names)
        if (any(type(number) not in (int, float) or not math.isfinite(number) for number in numbers)
                or not -360 <= numbers[0] < numbers[1] <= 360
                or not -180 <= numbers[2] < numbers[3] <= 180 or not 0 < numbers[4] <= 360):
            raise PointingError("invalid_argument")
        rectangle = value["no_go_rectangle"]
        if rectangle is not None:
            if not isinstance(rectangle, Mapping) or set(rectangle) != set(names[:4]):
                raise PointingError("invalid_argument")
            bounds = tuple(rectangle[key] for key in names[:4])
            if (any(type(number) not in (int, float) or not math.isfinite(number) for number in bounds)
                    or not -360 <= bounds[0] < bounds[1] <= 360
                    or not -180 <= bounds[2] < bounds[3] <= 180):
                raise PointingError("invalid_argument")
            rectangle = tuple(bounds)
        exact = lambda number: str(Fraction(str(number)))
        record = dict(schema=value["schema"], frame=value["frame"], acquisition=base.binding.hex(),
                      limits=[exact(number) for number in numbers],
                      no_go_rectangle=None if rectangle is None else [exact(number) for number in rectangle])
        binding = hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":")).encode("ascii")).digest()
        return cls(base.manager_id, base.session_id, base.equipment_label, base.model, base.protocol, None,
                   base.serial_settings, base.device_identity, base.observation_max_age_seconds,
                   base.exchange_timeout_seconds, binding, value["frame"], *numbers, rectangle)

    def _check_range(self, pan, tilt):
        if (not Fraction(str(self.pan_min)) <= pan <= Fraction(str(self.pan_max))
                or not Fraction(str(self.tilt_min)) <= tilt <= Fraction(str(self.tilt_max))):
            raise PointingError("endpoint_rejected")

    def _check_endpoint(self, pan, tilt):
        self._check_range(pan, tilt)
        if self.no_go_rectangle is not None:
            pmin, pmax, tmin, tmax = (Fraction(str(value)) for value in self.no_go_rectangle)
            if pmin <= pan <= pmax and tmin <= tilt <= tmax:
                raise PointingError("endpoint_rejected")

    def check_target(self, pan, tilt, start):
        if any(type(value) not in (int, float) or not math.isfinite(value) for value in (pan, tilt)):
            raise PointingError("endpoint_rejected")
        # Manual inputs use their decimal spelling; returned positions remain exact protocol tenths.
        pan, tilt = Fraction(str(pan)), Fraction(str(tilt))
        self._check_endpoint(pan, tilt)
        self._check_change(pan, tilt, start)

    def _check_change(self, pan, tilt, start):
        if any(type(value) not in (int, float) or not math.isfinite(value) for value in start):
            raise PointingError("endpoint_rejected")
        units = tuple(round(value * 10) for value in start)
        if any(value != unit / 10 for value, unit in zip(start, units)):
            raise PointingError("context_changed")
        returned = tuple(Fraction(unit, 10) for unit in units)
        self._check_range(*returned)
        change = Fraction(str(self.max_change_degrees))
        if (abs(pan - returned[0]) > change or abs(tilt - returned[1]) > change
                or pan != returned[0] and tilt != returned[1]):
            raise PointingError("endpoint_rejected")

    def check_encoded(self, packet, start):
        if (type(packet.pan_units) is not int or type(packet.tilt_units) is not int
                or type(packet.units_per_degree) is not int or packet.units_per_degree != 10):
            raise PointingError("context_changed")
        pan, tilt = Fraction(packet.pan_units, 10), Fraction(packet.tilt_units, 10)
        self._check_endpoint(pan, tilt)
        self._check_change(pan, tilt, start)

    def check_jog(self, pan_velocity, tilt_velocity, packet=None):
        velocities = (pan_velocity, tilt_velocity)
        if (any(type(value) not in (int, float) or not -1 <= value <= 1
                or not math.isfinite(value) for value in velocities)
                or sum(value != 0 for value in velocities) != 1):
            raise PointingError("invalid_argument")
        if packet is not None:
            encoded = (packet.pan_velocity, packet.tilt_velocity)
            if (type(packet.velocity_scale) is not int or packet.velocity_scale != 127
                    or any(type(value) is not int or not -127 <= value <= 127 for value in encoded)
                    or any((requested != 0) != (actual != 0)
                           or requested * actual < 0 for requested, actual in zip(velocities, encoded))):
                raise PointingError("context_changed")


@dataclass(frozen=True)
class BenchResult:
    values: tuple

    def __getattr__(self, name):
        for key, value in self.values:
            if key == name:
                return value
        raise AttributeError(name)

    def as_record(self):
        return dict(self.values)

    @classmethod
    def from_message(cls, message):
        values = {field.name: value for field, value in message.ListFields()
                  if field.name not in ("binding", "sender", "observed_at", "status_bytes", "exchanges")}
        for name in ("manager_id", "sequence", "operation", "category", "state", "mode",
                     "physical_state", "position_reference", "submission", "has_observation", "pan", "tilt",
                     "observation_sequence", "requested_pan", "requested_tilt", "encoded_pan_units",
                     "encoded_tilt_units", "units_per_degree", "preview_sequence", "equipment_label", "frame",
                     "pan_min", "pan_max", "tilt_min", "tilt_max", "max_change_degrees", "possible_motion"):
            values[name] = getattr(message, name)
        values["observed_at"] = message.observed_at.ToJsonString() if message.has_observation else None
        values["status_bytes"] = message.status_bytes.hex()
        values["binding"] = message.binding.hex()
        values["sender"] = message.sender.hex()
        if message.mode == "query-only":
            for name in ("pan_min", "pan_max", "tilt_min", "tilt_max", "max_change_degrees"):
                values.pop(name, None)
            values["capabilities"] = ["connect", "status", "disconnect"]
        values["clock_quality"] = "unqualified-wall-clock"
        values["exchanges"] = []
        for receipt in message.exchanges:
            values["exchanges"].append({
                "sequence": receipt.sequence, "operation": receipt.operation,
                "request": receipt.request.hex(), "response": receipt.response.hex(),
                "response_truncated": receipt.response_truncated,
                "started_monotonic": receipt.started_monotonic, "finished_monotonic": receipt.finished_monotonic,
                "category": receipt.category, "submission": receipt.submission,
                "written": receipt.written if receipt.HasField("written") else None,
                "timing_reference": "owner-process-monotonic",
            })
        return cls(tuple(sorted(values.items())))


class BenchClient(_PointingClient):
    @classmethod
    def open(cls, **options):
        if cls is not BenchClient:
            raise PtuError("admission")
        settings = options.get("settings")
        if isinstance(settings, Mapping) and ("readback_context" in settings or "manual_context" in settings):
            required = {"messenger", "settings", "ptu_id", "log_dir", "deadline", "cancel"}
            if (not required <= set(options) or set(options) - required - {"elevation_mask", "no_go_data"}
                    or options.get("elevation_mask") is not None or options.get("no_go_data") is not None):
                raise PtuError("admission")
            deadline, cancel = options["deadline"], options["cancel"]
            _client_remaining(deadline, cancel)
            messenger, directory = options["messenger"], options["log_dir"]
            if (not _mechanical_messenger_compatible(messenger, settings)
                    or type(directory) is not _POINTING_CLIENT_PATH or not directory.is_absolute()
                    or len(str(directory)) > 4096 or ".." in directory.parts):
                raise PtuError("admission")
            context_type = ManualContext if "manual_context" in settings else ReadbackContext
            context = context_type.from_settings(settings, options["ptu_id"])
            sender = os.urandom(16)
            if type(sender) is not bytes or len(sender) != 16:
                raise PtuError("admission")
            owner = cls._allocate(messenger, context.manager_id, None, sender, deadline, cancel)
            owner._bench = context
        else:
            owner = cls._open(**options)
            owner._bench = BenchContext.from_settings(settings, owner._policy)
        owner._bench_sequence = 0
        owner._bench_pending = {}
        owner._bench_stop = threading.Lock()
        owner._bench_receipt_sequence = 0
        owner._callbacks = (("{}_{}".format(Topics.BENCH_OUTCOME, owner.ptu_id), owner._receive_bench, ""),)
        return owner

    @property
    def protocol(self):
        return self._bench.protocol if self._policy is None else self._policy.protocol

    def _unsupported_pointing(self, *args, **kwargs):
        raise PtuError("unsupported")

    check_connection = _unsupported_pointing
    load_tle = _unsupported_pointing
    validateCoordinates = _unsupported_pointing
    prime = _unsupported_pointing
    ptu_move_to = _unsupported_pointing
    ptu_send_position = _unsupported_pointing

    def connect(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.CONNECT, deadline, cancel)

    def status(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.STATUS, deadline, cancel)

    def preview(self, pan, tilt, *, deadline, cancel):
        if any(type(v) not in (int, float) or not math.isfinite(v) for v in (pan, tilt)):
            raise PtuError("admission")
        return self._request(pb.BenchCommand.PREVIEW, deadline, cancel, pan=pan, tilt=tilt)

    def move(self, preview_sequence, *, deadline, cancel):
        if type(preview_sequence) is not int or not 0 < preview_sequence < 2**64:
            raise PtuError("admission")
        return self._request(pb.BenchCommand.MOVE, deadline, cancel, preview_sequence=preview_sequence)

    def stop(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.STOP, deadline, cancel)

    def disconnect(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.DISCONNECT, deadline, cancel)

    def _request(self, operation, deadline, cancel, **fields):
        if self._bench.mode == "query-only" and operation not in (
                pb.BenchCommand.CONNECT, pb.BenchCommand.STATUS, pb.BenchCommand.DISCONNECT):
            raise PtuError("unsupported")
        lock = self._bench_stop if operation == pb.BenchCommand.STOP else self._operation
        self._lock(lock, deadline, cancel)
        sequence = None
        try:
            self._activate(deadline, cancel)
            self._lock(self._state, deadline, cancel)
            try:
                if self._bench_sequence == 2**64 - 1:
                    raise PtuError("state")
                self._bench_sequence += 1
                sequence = self._bench_sequence
                pending = [operation, threading.Event(), None]
                self._bench_pending[sequence] = pending
            finally:
                self._state.release()
            command = pb.BenchCommand(operation=operation, binding=self._bench.binding,
                                      sender=self._prime_sender_id, sequence=sequence, **fields)
            self._check(deadline, cancel)
            self.messenger.publish("{}_{}".format(Topics.BENCH_COMMAND, self.ptu_id),
                command.SerializeToString(), priority=9 if operation == pb.BenchCommand.STOP else 4,
                deadline=deadline, cancel=cancel)
            while not pending[1].wait(min(.01, self._check(deadline, cancel))):
                pass
            self._check(deadline, cancel)
            return pending[2]
        finally:
            if sequence is not None:
                self._bench_pending.pop(sequence, None)
            lock.release()

    def _receive_bench(self, body, identifier):
        if not self._callback_lock():
            return
        try:
            if type(body) is not bytes or not 0 < len(body) <= 8192 or identifier != "":
                self._reject_message()
                return
            try:
                message = pb.BenchOutcome.FromString(body)
                known = pb.BenchOutcome()
                known.CopyFrom(message)
                known.DiscardUnknownFields()
                if known.SerializeToString() != message.SerializeToString():
                    raise ValueError("unknown outcome fields")
                pending = self._bench_pending.get(message.sequence)
                numeric = (message.pan, message.tilt, message.requested_pan, message.requested_tilt,
                           message.pan_min, message.pan_max, message.tilt_min, message.tilt_max,
                           message.max_change_degrees)
                if (pending is None or pending[0] != message.operation or pending[2] is not None
                        or message.manager_id != self.ptu_id or message.binding != self._bench.binding
                        or message.sender != self._prime_sender_id or message.mode != self._bench.mode
                        or message.category not in ("ok", "invalid_argument", "policy_mismatch", "endpoint_rejected",
                            "context_changed", "deadline", "cancelled", "disconnected", "serial_failure", "busy", "unsupported")
                        or message.submission not in ("none", "partial", "complete", "unknown")
                        or message.position_reference != "protocol-reported-unqualified"
                        or message.equipment_label != self._bench.equipment_label
                        or message.units_per_degree != (10 if self.protocol == "PTCR20" else 100)
                        or message.frame != "mechanical-pan-tilt-degrees.v1"
                        or (self._bench.mode != "query-only" and (message.pan_min, message.pan_max, message.tilt_min, message.tilt_max,
                            message.max_change_degrees) != (self._bench.pan_min, self._bench.pan_max,
                            self._bench.tilt_min, self._bench.tilt_max, self._bench.max_change_degrees))
                        or message.physical_state not in ("unobserved", "indeterminate")
                        or any(not math.isfinite(v) for v in numeric)
                        or (message.has_observation and (message.observation_sequence == 0 or len(message.status_bytes) != 3))):
                    raise ValueError("outcome")
                if self._bench.mode == "query-only" and any(
                        field.number in (18, 19, 20, 21, 23, 26, 27, 28, 29, 30, 31)
                        for field, value in message.ListFields()):
                    raise ValueError("query outcome")
                sequence = self._validate_exchanges(message)
                result = BenchResult.from_message(message)
            except Exception:
                self._reject_message()
                return
            pending[2] = result
            self._bench_receipt_sequence = sequence
            pending[1].set()
        finally:
            self._state.release()

    def _validate_exchanges(self, message):
        expected = {
            pb.BenchCommand.CONNECT: ("status",), pb.BenchCommand.STATUS: ("status",),
            pb.BenchCommand.PREVIEW: ("status",), pb.BenchCommand.MOVE: ("status", "move"),
            pb.BenchCommand.STOP: ("stop", "status"), pb.BenchCommand.DISCONNECT: (),
        }[message.operation]
        actual = tuple(receipt.operation for receipt in message.exchanges)
        if len(actual) > 3 or actual != expected[:len(actual)]:
            raise ValueError("exchange operations")
        if self._bench.mode in ("query-only", "manual") and message.category == "ok" and actual != expected:
            raise ValueError("missing exchange")
        if message.category == "ok" and any(receipt.category != "ok" for receipt in message.exchanges):
            raise ValueError("failed exchange")
        sequence = self._bench_receipt_sequence
        for receipt in message.exchanges:
            if (receipt.sequence <= sequence or len(receipt.request) > 64 or not receipt.request
                    or len(receipt.response) > 64
                    or not math.isfinite(receipt.started_monotonic) or not math.isfinite(receipt.finished_monotonic)
                    or not 0 <= receipt.started_monotonic <= receipt.finished_monotonic
                    or receipt.category not in _EXCHANGE_CATEGORIES
                    or receipt.submission not in ("none", "partial", "complete", "unknown")
                    or receipt.HasField("written") and receipt.written > len(receipt.request)
                    or receipt.submission == "complete" and (
                        not receipt.HasField("written") or receipt.written != len(receipt.request))
                    or receipt.submission == "partial" and (
                        not receipt.HasField("written") or not 0 < receipt.written < len(receipt.request))
                    or receipt.submission == "unknown" and receipt.HasField("written")
                    or receipt.submission == "none" and receipt.HasField("written") and receipt.written != 0
                    or receipt.category == "ok" and (receipt.submission != "complete"
                        or not receipt.HasField("written") or receipt.written != len(receipt.request)
                        or receipt.response_truncated or not receipt.response)):
                raise ValueError("exchange receipt")
            sequence = receipt.sequence
        return sequence

    def close(self, *, deadline):
        self._closing.set()
        self._lock(self._bench_stop, deadline, threading.Event(), passive=True)
        try:
            return self._close(deadline)
        finally:
            self._bench_stop.release()


def __getattr__(name):
    if name == "BenchManager":
        from ptu_control.bench_manager import BenchManager
        return BenchManager
    raise AttributeError(name)
