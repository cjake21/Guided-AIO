from dataclasses import dataclass


class DEFAULTS:
    """
    PARK_PTU_AZ = 0
    PARK_PTU_EL = 0
    PTU_PAN_TO_AZ = 0
    PTU_TILT_TO_EL = 90
    HARD_PAN_LIM_CW = 120
    HARD_PAN_LIM_CCW = -210
    HARD_AZ_LIM_MID = HARD_PAN_LIM_CW + (HARD_PAN_LIM_CCW + 360 - HARD_PAN_LIM_CW)/2
    TRACKING_UPDATE_RATE = 1
    MAX_EL = 87
    """

    PARK_PTU_AZ = 0
    PARK_PTU_EL = 0
    
    # + value means PAN =0 ==> maps to clockwise error
    # - value means PAN =0 ==> maps to counter clockwise error
    PTU_PAN_TO_AZ = 0
    PTU_TILT_TO_EL = 90
    HARD_PAN_LIM_CW = 120
    HARD_PAN_LIM_CCW = -210
    HARD_AZ_LIM_MID = HARD_PAN_LIM_CW + (HARD_PAN_LIM_CCW + 360 - HARD_PAN_LIM_CW)/2
    TRACKING_UPDATE_RATE: float = 1.0
    MAX_EL = 87


class Topics:
    PTU_POSITION_COMMAND = "/topic/PTU_POSITION_COMMAND"
    LIGHT_COMMAND = "/topic/LIGHT_COMMAND"
    CALIBRATE_COMMAND = "/topic/CALIBRATE_COMMAND"
    CALIBRATION_STATUS = "/topic/CALIBRATION_STATUS"    

    TLE_LOAD_COMMAND = "/topic/TLE_LOAD_COMMAND"    
    TLE_LOAD_REPLY = "/topic/TLE_LOAD_REPLY"    
    POINTING_WARNING_MSG = "/topic/POINTING_WARNING_MSG" 
    POINTING_ERROR_COMMAND = "/topic/POINTING_ERROR_COMMAND"    
    POINTING_ERROR_COMMAND = "/topic/POINTING_ERROR_COMMAND"    
    ERROR_PROFILE_COMMAND = "/topic/ERROR_PROFILE_COMMAND"    
    ERROR_PROFILE_REPLY = "/topic/ERROR_PROFILE_REPLY"    

    
    TLE_PRIME_COMMAND = "/topic/TLE_PRIME_COMMAND"    
    ABORT_COMMAND = "/topic/ABORT_COMMAND"    
    PARK_COMMAND = "/topic/PARK_COMMAND"    
    CALIBRATION_STATUS = "/topic/CALIBRATION_STATUS"
    
    PTU_STATUS = "/topic/PTU_STATUS_TOPIC"
    PING_CMD = "/topic/PTU_PING"
    PONG_RESPONSE = "/topic/PTU_PONG"    

    SCHEDULED_COMMAND = "/topic/PTU_SCHEDULED_COMMAND"
    SCHEDULED_OUTCOME = "/topic/PTU_SCHEDULED_OUTCOME"
    BENCH_COMMAND = "/topic/PTU_BENCH_COMMAND"
    BENCH_OUTCOME = "/topic/PTU_BENCH_OUTCOME"

class PTUStatus:
    TIMEOUT = "TO"
    DIRECTION_ERROR = "DE"
    _statusDict = {}
    _statusDict["CWHL"] = "Clockwise Hard Limit"
    _statusDict["CCWHL"] = "CounterClockwise Hard Limit"
    _statusDict["CWSL"] = "Clockwise Soft Limit"
    _statusDict["CCWSL"] = "CounterClockwise Soft Limit"
    _statusDict[TIMEOUT] = " Timeout. Requires reset to clear."
    _statusDict[DIRECTION_ERROR] = "Direction Error. Moved in the wrong direction. Requires reset to clear."
    _statusDict["CWM"] = "Clockwise Moving"
    _statusDict["CCWM"] = "CounterClockwise Moving"
    _statusDict["DWNM"] = "Down Moving"
    _statusDict["UPM"] = "Up Moving"
    _statusDict["OSLR"] = "Override Return. Soft Limit Override Return"
    _statusDict["DES"] = "Destination. Coordinates are Destination, not Current"
    _statusDict["EXEC"] = "Executing. PTCR is executing a remote initiated command."
    _statusDict["CON"] = "Continuous Rotation. Pan soft/hard limits are ignored."

    @classmethod
    def get(cls, key):
        try:
            return cls._statusDict[key]
        except:
            return "Unknown Key %s" % key
