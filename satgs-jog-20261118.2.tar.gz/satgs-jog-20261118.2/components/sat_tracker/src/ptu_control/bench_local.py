"""Explicit in-process ownership of the selected serial bench driver."""

import math
import os
import threading
import time
from collections.abc import Mapping

from serialptu.acquisition import SerialSettings, SerialDeviceIdentity, ReadbackContext as DriverContext
from serialptu.proto_impl import PTCR20
from serialptu.ptu import PTU

from ptu_control import ptu_msg_pb2 as pb
from ptu_control.bench import BenchResult, ManualContext, ReadbackContext
from ptu_control.bench_operations import _BenchOperations
from ptu_control.pointing import PointingError
from ptu_control.ptu_client import PtuError, _client_deadline, _client_remaining
from ptu_control.tracking import CATEGORIES


class LocalBenchClient(_BenchOperations):
    @classmethod
    def open(cls, *, settings, ptu_id, deadline, cancel):
        if cls is not LocalBenchClient:
            raise PtuError("admission")
        return cls(settings=settings, ptu_id=ptu_id, deadline=deadline, cancel=cancel)

    def __init__(self, *, settings, ptu_id, deadline, cancel):
        _client_remaining(deadline, cancel)
        if (type(self) is not LocalBenchClient or not isinstance(settings, Mapping)
                or settings.get("bench_transport") != "local-serial"
                or set(settings) not in ({"bench_transport", "manual_context"},
                                         {"bench_transport", "readback_context"})):
            raise PtuError("admission")
        context_type = ManualContext if "manual_context" in settings else ReadbackContext
        self._bench = context_type.from_settings(settings, ptu_id)
        self._manager_id = ptu_id
        self._policy = None
        self._sender = os.urandom(16)
        if type(self._sender) is not bytes or len(self._sender) != 16:
            raise PtuError("admission")
        self._sequence = 0
        self._operation = threading.RLock()
        self._regular_request = threading.Lock()
        self._stop_request = threading.Lock()
        self._closing = threading.Event()
        self._handle = None
        self._active = False
        self._invalid = False
        self._closed = False
        self._state = "inactive"
        self._bench_senders = {}
        self._bench_connected = set()
        self._bench_previews = {}
        self._bench_observation = None
        self._bench_observation_sequence = 0
        self._bench_stop_pending = threading.Event()
        self._bench_stop_count = 0
        self._bench_priority = threading.Lock()
        self._bench_possible_motion = False
        self._bench_motion_active = False
        self._bench_stop_failed = False
        self._bench_slots = threading.Condition()
        self._bench_exchanges = []
        serial = SerialSettings(**self._bench.serial_settings)
        identity = SerialDeviceIdentity(**self._bench.device_identity)
        _client_remaining(deadline, cancel)
        self._driver = PTU(PTCR20(), serial.port, baud=serial.baudrate, pointing=True,
            serial_settings=serial, device_identity=identity,
            serial_capability="manual" if self._bench.motion_allowed else "readback")

    @property
    def protocol(self):
        return self._bench.protocol

    @staticmethod
    def _deadline(deadline, cancel):
        try:
            return _client_remaining(deadline, cancel)
        except PtuError as error:
            raise PointingError("invalid_argument" if error.primary == "admission" else error.primary) from None

    @staticmethod
    def _translated(error):
        primary = getattr(error, "primary", "")
        if primary == "device-busy":
            primary = "busy"
        elif primary in ("device-identity", "serial-context"):
            primary = "policy_mismatch"
        elif primary == "admission":
            primary = "invalid_argument"
        elif primary == "closed":
            primary = "disconnected"
        elif primary not in CATEGORIES - {"ok"}:
            primary = "context_changed" if primary in ("invalidated", "context-changed", "prepared") else "serial_failure"
        return PointingError(primary, 0, getattr(error, "submission", "none"))

    def _lock(self, lock, deadline, cancel):
        while not lock.acquire(timeout=_client_remaining(deadline, cancel)):
            pass
        try:
            _client_remaining(deadline, cancel)
            if self._closing.is_set():
                raise PtuError("closed")
        except BaseException:
            lock.release()
            raise

    def _activate(self, deadline, cancel):
        self._lock(self._operation, deadline, cancel)
        try:
            if self._active:
                return
            if self._handle is not None or self._invalid:
                raise PointingError("context_changed")
            expected = DriverContext(self._bench.protocol, 10, self._bench.protocol_address,
                                    SerialSettings(**self._bench.serial_settings),
                                    SerialDeviceIdentity(**self._bench.device_identity))
            capability = "manual" if self._bench.motion_allowed else "readback"
            if (type(self._driver) is not PTU or self._driver.pointing_available is not True
                    or self._driver.readback_context != expected or self._driver.serial_capability != capability):
                raise PointingError("policy_mismatch")
            try:
                bind = self._driver.bind_manual if self._bench.motion_allowed else self._driver.bind_readback
                self._handle = bind(self._bench.binding, deadline=deadline, cancel=cancel)
                self._driver.open_bounded(deadline=deadline, cancel=cancel)
                _client_remaining(deadline, cancel)
                self._active = True
                self._state = "connected"
            except BaseException:
                self._invalid = True
                raise
        finally:
            self._operation.release()

    def connect(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.CONNECT, deadline, cancel)

    def status(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.STATUS, deadline, cancel)

    def preview(self, pan, tilt, *, deadline, cancel):
        if any(type(value) not in (int, float) or not math.isfinite(value) for value in (pan, tilt)):
            raise PtuError("admission")
        return self._request(pb.BenchCommand.PREVIEW, deadline, cancel, pan=pan, tilt=tilt)

    def move(self, preview_sequence, *, deadline, cancel):
        if type(preview_sequence) is not int or not 0 < preview_sequence < 2**64:
            raise PtuError("admission")
        return self._request(pb.BenchCommand.MOVE, deadline, cancel, preview_sequence=preview_sequence)

    def jog(self, pan_velocity, tilt_velocity, *, deadline, cancel):
        try:
            _client_remaining(deadline, cancel)
            if not self._bench.motion_allowed:
                raise PtuError("unsupported")
            self._bench.check_jog(pan_velocity, tilt_velocity)
            deadline = min(deadline, time.monotonic() + self._bench.exchange_timeout_seconds)
            self._lock(self._regular_request, deadline, cancel)
        except PtuError as error:
            error.submission = "none"
            raise
        acquired = False
        observation = packet = None
        category, submission = "ok", "none"
        exchanges = ()
        try:
            with self._bench_slots:
                if self._sequence == 2**64 - 1:
                    raise PtuError("state")
                self._sequence += 1
                command = pb.BenchCommand(binding=self._bench.binding, sender=self._sender,
                                          sequence=self._sequence)
            try:
                while not self._operation.acquire(timeout=self._deadline(deadline, cancel)):
                    pass
                acquired = True
                self._bench_exchanges = []
                exchanges = self._bench_exchanges
                if self._closing.is_set() or not self._active:
                    raise PointingError("disconnected")
                with self._bench_slots:
                    if self._sender not in self._bench_connected:
                        raise PointingError("disconnected")
                    if command.sequence <= self._bench_senders[self._sender]:
                        raise PointingError("context_changed")
                    self._bench_senders[self._sender] = command.sequence
                if (self._invalid or self._bench_stop_failed or self._bench_stop_pending.is_set()
                        or self._bench_motion_active and not self._bench_jog_active):
                    raise PointingError("busy")
                if (self._bench_observation is None or time.monotonic() - self._bench_observation[4]
                        > self._bench.observation_max_age_seconds):
                    raise PointingError("context_changed")
                self._bench_previews.clear()
                packet = self._driver.prepare_jog(self._handle, pan_velocity, tilt_velocity,
                                                 deadline=deadline, cancel=cancel)
                self._bench.check_jog(pan_velocity, tilt_velocity, packet)
                with self._driver.pointing_guard(self._handle, deadline=deadline, cancel=cancel):
                    if self._closing.is_set():
                        raise PointingError("disconnected")
                    if self._invalid or self._bench_stop_failed or self._bench_stop_pending.is_set():
                        raise PointingError("busy")
                    self._bench_possible_motion = self._bench_motion_active = self._bench_jog_active = True
                    data = self._bench_exchange("jog", lambda: self._driver.submit_prepared_jog(
                        self._handle, packet, deadline=deadline, cancel=cancel))[1]
                submission = "complete"
                observation = self._bench_observe(data)
                self._bench_motion_active = True
                if self._invalid or self._bench_stop_failed:
                    raise PointingError("context_changed")
                self._state = "jogging"
            except Exception as error:
                failure = self._translated(error)
                category = failure.primary
                if submission != "complete":
                    submission = failure.submission
                if (self._bench_jog_active and packet is not None
                        and not (category == "cancelled" and submission == "none")):
                    self._invalid = True
                    self._bench_possible_motion = self._bench_motion_active = True
                    self._state = "stop_failed" if self._bench_stop_failed else "jog_failed"
            return self._jog_result(command, category, submission, observation, exchanges, packet,
                                    pan_velocity, tilt_velocity)
        finally:
            if acquired:
                self._operation.release()
            self._regular_request.release()

    def _jog_result(self, command, category, submission, observation, exchanges, packet,
                    pan_velocity, tilt_velocity):
        values = BenchResult.from_message(self._bench_message(
            command, category, submission, None, observation, exchanges)).as_record()
        for name in ("pan_min", "pan_max", "tilt_min", "tilt_max", "max_change_degrees",
                     "requested_pan", "requested_tilt", "encoded_pan_units", "encoded_tilt_units",
                     "preview_sequence"):
            values.pop(name, None)
        values.update(operation="jog", motion_contract="device-soft-limits-jog.v1",
            software_endpoint_limits_enforced=False, no_go_enforced=False, soft_limit_override=False,
            velocity_reference="normalized-device-configured-speed",
            requested_pan_velocity=pan_velocity, requested_tilt_velocity=tilt_velocity,
            encoded_pan_velocity=None if packet is None else packet.pan_velocity,
            encoded_tilt_velocity=None if packet is None else packet.tilt_velocity,
            velocity_scale=127, jog_active=self._bench_jog_active)
        return BenchResult(tuple(sorted(values.items())))

    def stop(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.STOP, deadline, cancel)

    def disconnect(self, *, deadline, cancel):
        return self._request(pb.BenchCommand.DISCONNECT, deadline, cancel)

    def _request(self, operation, deadline, cancel, **fields):
        _client_remaining(deadline, cancel)
        if self._bench.mode == "query-only" and operation not in (
                pb.BenchCommand.CONNECT, pb.BenchCommand.STATUS, pb.BenchCommand.DISCONNECT):
            raise PtuError("unsupported")
        deadline = min(deadline, time.monotonic() + self._bench.exchange_timeout_seconds)
        stop = operation == pb.BenchCommand.STOP
        lock = self._stop_request if stop else self._regular_request
        self._lock(lock, deadline, cancel)
        try:
            with self._bench_slots:
                if self._sequence == 2**64 - 1:
                    raise PtuError("state")
                self._sequence += 1
                command = pb.BenchCommand(operation=operation, binding=self._bench.binding,
                                          sender=self._sender, sequence=self._sequence, **fields)
            if operation == pb.BenchCommand.CONNECT:
                try:
                    self._activate(deadline, cancel)
                except Exception as error:
                    failure = self._translated(error)
                    return BenchResult.from_message(self._bench_message(
                        command, failure.primary, failure.submission, None, None, ()))
            if stop:
                with self._bench_priority:
                    self._bench_stop_count += 1
                    self._bench_stop_pending.set()
            return BenchResult.from_message(self._bench_execute(command, deadline, cancel=cancel))
        finally:
            lock.release()

    def close(self, *, deadline):
        _client_deadline(deadline)
        self._closing.set()
        acquired = self._operation.acquire(blocking=False)
        while not acquired and time.monotonic() < deadline:
            acquired = self._operation.acquire(timeout=min(.01, max(0, deadline - time.monotonic())))
        try:
            self._driver.close(deadline=deadline)
            if not acquired:
                raise PointingError("cleanup_incomplete")
            self._active = False
            self._state = "closed"
            self._closed = True
            return True
        except Exception:
            raise PointingError("cleanup_incomplete") from None
        finally:
            if acquired:
                self._operation.release()
