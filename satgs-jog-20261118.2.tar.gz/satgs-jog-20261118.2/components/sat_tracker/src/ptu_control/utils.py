import logging
from pathlib import Path
import numpy as np
import yaml
from typing import Union
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, fields, field
from ephem import Observer
from google.protobuf.timestamp_pb2 import Timestamp

from ptu_control.constants import DEFAULTS as PTU_DEFAULTS
from satgs.constants import time_format_short
from satgs.utils import TLE, find_closest_pass
from ptu_control import ptu_msg_pb2 as ptu_pb


@dataclass
class PtuID:
    id: int # Numeric Identifier
    protocol: str
    baud:int
    cont_rot: bool
    hard_pan_lim_cw: float
    hard_pan_lim_ccw: float
    type: str # QPT500/ 200/ 130
    name: str # Descriptor (TX, RX Xband, RX 1-6 GHz)
    pix_id: int # Identifier of pixhawk connected to dish
    allow_pointing_errors:bool
    no_go_config:Path=None
    
    @classmethod
    def from_dict(cls, ptu_dict:dict):
        valid_args = {}
        for key in ptu_dict.keys():
            if (key == 'no_go_config'):
                if ptu_dict[key] is not None:
                    valid_args[key] = Path(ptu_dict[key])
            else:
                valid_args[key] = ptu_dict[key]
            
        return cls(**valid_args)

    
@dataclass
class PtuGeneralStatusMsg:
    HRES: bool=False
    EXEC: bool=False
    OSLR: bool=False
    CWM: bool=False
    CCWM: bool=False
    UPM: bool=False
    DWNM: bool=False
    CON: bool=False
    
    @classmethod
    def from_list(cls, status_list):
        valid_args = {}    
        for param in status_list:
            valid_args[param[0]] = param[1]
        return cls(**valid_args)  

    def to_pb(self):
        return ptu_pb.GeneralStatusMsg(
            EXEC=self.EXEC, OSLR=self.OSLR, 
            CWM=self.CWM, CCWM=self.CCWM,
            UPM=self.UPM, DWNM=self.DWNM, CON=self.CON)

    def any_true(self)->bool:
        return any(value for value in self.__dict__.values() if isinstance(value, bool))
    
    def print(self)->str:
        if self.any_true():
            field_vals = ["{}: {}".format(field.name, getattr(self, field.name)) for field in fields(self) if getattr(self, field.name)]
            return "\n General Status:{}".format(" ".join(field_vals))
        else: 
            return ""

@dataclass
class PtuPanStatusMsg:
    CWSL: bool=False
    CCWSL: bool=False
    CWHL: bool=False
    CCWHL: bool=False
    TO: bool=False
    DE: bool=False
    OL: bool=False
    
    @classmethod
    def from_list(cls, status_list):
        valid_args = {}    
        for param in status_list:
            valid_args[param[0]] = param[1]
        return cls(**valid_args)  
    
    def to_pb(self):
        return ptu_pb.PanStatusMsg(
            CWSL=self.CWSL, CCWSL=self.CCWSL, CWHL=self.CWHL, CCWHL=self.CCWHL, 
            TO=self.TO, DE=self.DE, OL= self.OL)
                 
    def any_true(self)->bool:
        return any(value for value in self.__dict__.values() if isinstance(value, bool))
    
    def print(self)->str:
        if self.any_true():
            field_vals = ["{}: {}".format(field.name, getattr(self, field.name)) for field in fields(self) if getattr(self, field.name)]
            return "\n Pan Status:{}".format(" ".join(field_vals))
        else: 
            return ""    

@dataclass
class PtuTiltStatusMsg:
    USL: bool=False
    DSL: bool=False
    UHL: bool=False
    DHL: bool=False
    TO: bool=False
    DE: bool=False
    OL: bool=False
    
    @classmethod
    def from_list(cls, status_list):
        valid_args = {}    
        for param in status_list:
            valid_args[param[0]] = param[1]
        return cls(**valid_args)  
    
    def to_pb(self):
        return ptu_pb.TiltStatusMsg(
            USL=self.USL, DSL=self.DSL, UHL=self.UHL, DHL=self.DHL, 
            TO=self.TO, DE=self.DE, OL= self.OL)    
    
    def any_true(self)->bool:
        return any(value for value in self.__dict__.values() if isinstance(value, bool))
    
    def print(self)->str:
        if self.any_true():
            field_vals = ["{}: {}".format(field.name, getattr(self, field.name)) for field in fields(self) if getattr(self, field.name)]
            return "\n Tilt Status:{}".format(" ".join(field_vals))
        else: 
            return ""       
    
@dataclass
class PTUStatusMsg:
    general:PtuGeneralStatusMsg
    pan:PtuPanStatusMsg
    tilt:PtuTiltStatusMsg
    
    @classmethod
    def from_list(cls, status_list:list):
        valid_args = {}
        for status_item in status_list:
            if status_item[0] == 'General':
                valid_args['general'] = PtuGeneralStatusMsg.from_list(status_item[1])
            elif status_item[0] == 'Pan Status':
                valid_args['pan'] = PtuPanStatusMsg.from_list(status_item[1])                
            elif status_item[0] == 'Tilt Status':
                valid_args['tilt'] = PtuTiltStatusMsg.from_list(status_item[1])
        return cls(**valid_args)
    
    def to_pb(self):
        return( ptu_pb.PTUStatusMsg(
                    general=self.general.to_pb(),
                    pan=self.pan.to_pb(),
                    tilt=self.tilt.to_pb()) 
        )

@dataclass
class PTUDataMsg:
    message_type: str
    command:str
    pan: float
    tilt: float
    status: PTUStatusMsg
    test:PtuTiltStatusMsg
    
    @classmethod
    def from_dict(cls, data_dict:dict):
        return cls(        
                    message_type=data_dict['message_type'],
                    command=data_dict['command'],
                    pan=data_dict['pan'],
                    tilt=data_dict['tilt'],
                    status = PTUStatusMsg.from_list(data_dict['status']),
                    test= PtuTiltStatusMsg())
    
    
@dataclass
class PTUCommand:
    timestamp: Timestamp=None
    azimuth: float = float('nan')
    elevation: float = float('nan')
    def print(self):
        if self.timestamp is None:
            return ''
        else:
            dt = self.timestamp.ToDatetime()
            return "{} Az {:0.2f}, El {:0.1f}".format(dt.strftime(time_format_short), self.azimuth, self.elevation)
    
@dataclass
class PositionerStatus:
    state:str
    command:PTUCommand
    id:int
    ptu_pan_to_az:float=0
    general_status: PtuGeneralStatusMsg = field(default_factory=PtuGeneralStatusMsg)
    pan_status: PtuPanStatusMsg = field(default_factory=PtuPanStatusMsg)
    tilt_status: PtuTiltStatusMsg = field(default_factory=PtuTiltStatusMsg)
    pan:float = 0
    tilt:float = 0
    azimuth:float = 0
    elevation:float = 0    
    timestamp: Timestamp=None
            
    def print(self):
        if self.command is not None:
            msg = f"""
    ID: {self.id} State: {self.state} P:{self.pan:6.1f} T:{self.tilt:4.1f} || Az:{self.azimuth:6.1f} El:{self.elevation:4.1f} || CMD Az:{self.command.azimuth:6.1f} El:{self.command.elevation:4.1f}
        {self.general_status.print()} {self.pan_status.print()} {self.tilt_status.print()}"""
        else:
            msg = f"""            
    ID: {self.id} State: {self.state} P:{self.pan:6.1f} T:{self.tilt:4.1f} || Az:{self.azimuth:6.1f} El:{self.elevation:4.1f} || 
        {self.general_status.print()} {self.pan_status.print()} {self.tilt_status.print()}"""            
            
        return msg 


def ptu_move_msg_from_pb(pb_msg:Union[str, bytes,  ptu_pb.PositionerStatus])->PositionerStatus:
    if isinstance(pb_msg, str) or isinstance(pb_msg, bytes):
        move_msg = ptu_pb.PositionerStatus()
        move_msg.ParseFromString(pb_msg) 
    else:
        move_msg = pb_msg
    if move_msg.status.general.ByteSize()==0:
        general_status = PtuGeneralStatusMsg()
    else:
        gen_msg = move_msg.status.general
        general_status = PtuGeneralStatusMsg(
            EXEC=gen_msg.EXEC, OSLR=gen_msg.OSLR,
            CWM=gen_msg.CWM,CCWM=gen_msg.CCWM,
            UPM=gen_msg.UPM, DWNM=gen_msg.DWNM,
            CON=gen_msg.CON)
    
    if move_msg.status.pan.ByteSize()==0:
        pan_status = PtuPanStatusMsg()
    else:
        pan_msg = move_msg.status.pan        
        pan_status = PtuPanStatusMsg(
            CWSL=pan_msg.CWSL, CCWSL=pan_msg.CCWSL,
            CWHL=pan_msg.CWHL, CCWHL=pan_msg.CCWHL,
            TO=pan_msg.TO, DE=pan_msg.DE, OL=pan_msg.OL,       
        )
     
    if move_msg.status.tilt.ByteSize()==0:
        tilt_status = PtuTiltStatusMsg()   
    else:
        tilt_msg = move_msg.status.tilt        
        tilt_status = PtuTiltStatusMsg(
            USL=tilt_msg.USL, DSL=tilt_msg.DSL,
            UHL=tilt_msg.UHL, DHL=tilt_msg.DHL,
            TO=tilt_msg.TO, DE=tilt_msg.DE, OL=tilt_msg.OL,       
        ) 
    if move_msg.command.ByteSize()==0:
        prev_command = None
    else:        
        prev_command = PTUCommand(move_msg.command.timestamp,move_msg.command.azimuth, move_msg.command.elevation)
    
    return PositionerStatus(
        state=move_msg.state,
        id=move_msg.id,
        command=prev_command,
        pan=move_msg.pan,
        ptu_pan_to_az=move_msg.ptu_pan_to_az,
        tilt=move_msg.tilt,
        azimuth = move_msg.azimuth,
        elevation = move_msg.elevation,
        general_status = general_status,
        pan_status = pan_status,
        tilt_status = tilt_status,
        timestamp = move_msg.timestamp)
    

def pre_plan_pass(ground_station:Observer, 
                  tle:TLE, 
                  ptu_details:PtuID, 
                  ptu_pan_to_az:float,
                  elevation_mask = 15)->tuple:
    prime_cw = False
    prime_ccw = False        
    
    azimuthal_range = ptu_details.hard_pan_lim_cw - ptu_details.hard_pan_lim_ccw
    if ptu_details.cont_rot:
        logging.info("PTU has continuous rotation, dont need to apply any logic")
        return prime_cw, prime_ccw
    elif azimuthal_range > 360:
        logging.info("need to do some logic")
    else:
        logging.info("PTU has less than 360 azimuthal range... nothing to do here. ")
        return prime_cw, prime_ccw
        
    pass_info = find_closest_pass(
        tle.norad_id, ground_station, tle.to_dict(), 
        el_mask=elevation_mask, hrs_past=12, hrs_future=12, 
        utc_ref=ground_station.date.datetime().replace(tzinfo=timezone.utc))
    sat_trajectory = pass_info.get_trajectory(ground_station) 
    prime_idx = np.argmax(sat_trajectory.el>elevation_mask)
    rising_az = sat_trajectory.az[prime_idx]
    
    rising_az_pan = (rising_az - ptu_pan_to_az) % 360
    az_unwrapped = np.unwrap(sat_trajectory.az*np.pi/180)*180/np.pi
    az_change = az_unwrapped[-1] - az_unwrapped[0]
    rotation_dir = np.sign(az_change)
    # rotation_dir > 0 ==> ClockWise || rotation <0 Counter Clockwise
    if (rising_az_pan >= (ptu_details.hard_pan_lim_ccw%360)) and (rising_az_pan <= (ptu_details.hard_pan_lim_cw%360)):
        # Rises in SW and rotates Counter Clockwise
        if (rising_az_pan >= 180) and (rotation_dir<0):
            prime_cw = True # => Pan values should be positive
            logging.warning("Priming Clock Wise: Sat rising in SW Pan quadrant and orbit moving Counter CW")
        # Rises in SE and pass goes Clockwise
        elif (rising_az_pan <= 180) and (rotation_dir>0):
            prime_ccw=True # => Pan values should be negative
            logging.warning("Priming Counter Clock Wise: Sat rising in SE Pan quadrant and orbit moving CW")
        else:
            return prime_cw, prime_ccw
    return prime_cw, prime_ccw
    

class NoGoZone:
    def __init__(self, no_go_cfg:Path=None):
        if no_go_cfg is not None:
            self.pass_all = False
            with open(no_go_cfg) as f:
                no_go_zone = yaml.safe_load(f)                 
            self.no_go_zone = no_go_zone['nogozones'][0]
            el_bound = np.arange(self.no_go_zone['el_min'], self.no_go_zone['el_max'], 0.1)
            az_bound = np.arange(self.no_go_zone['az_min'], self.no_go_zone['az_max'], 0.1)

            perim1 = np.array([az_bound, self.no_go_zone['el_max']*np.ones(az_bound.shape)])
            perim2 = np.array([self.no_go_zone['az_min']*np.ones(el_bound.shape), el_bound])
            perim3 = np.array([self.no_go_zone['az_max']*np.ones(el_bound.shape), el_bound])

            perim_polar = np.concatenate((perim1, perim2, perim3),axis=1)
            self.perim_cart = np.array([((90-perim_polar[1,:])/90) * np.cos(perim_polar[0,:]*np.pi/180), 
                                ((90-perim_polar[1,:])/90) * np.sin(perim_polar[0,:]*np.pi/180)])            
        else: 
            self.pass_all = True
        self.last_az_el = np.array([0,0])

    def adjust_for_zone(self, azimuth:float, elevation:float)->tuple:
        """
        Args:
            azimuth (float): degrees, can be -180 to 180 or 0 to 360
            elevation (float): _description_

        Returns:
            az, el: azimuth -180 to 180
        """
        if self.pass_all:
            return azimuth, elevation
        azimuth = (azimuth+360)%360
        # Point is in a no go zone
        if (self.no_go_zone['az_min']<=azimuth<=self.no_go_zone['az_max'])  \
        and (self.no_go_zone['el_min']<=elevation<=self.no_go_zone['el_max']):
         
            last_point_cart = np.array([
                ((90-self.last_az_el[1])/90) * np.cos(self.last_az_el[0]*np.pi/180), 
                ((90-self.last_az_el[1])/90) * np.sin(self.last_az_el[0]*np.pi/180)])  
            req_point_cart = np.array([
                ((90-elevation)/90) * np.cos(azimuth*np.pi/180), 
                ((90-elevation)/90) * np.sin(azimuth*np.pi/180)])
            # Nearest point on perimeter closest to requested point
            near_idx = np.argmin( np.linalg.norm(self.perim_cart-req_point_cart[:,np.newaxis], axis=0) )
            nearest_pt_cart =  self.perim_cart[:,near_idx]     
            nearest_pt_polar = np.array([
                np.arctan2(nearest_pt_cart[1], nearest_pt_cart[0])%(2*np.pi)*180/np.pi , 
                90 - np.linalg.norm(nearest_pt_cart)*90])                
            
            # midpoint between last and next point, want to make sure we dont
            # swing through a no-go zone 
            midpoint_cart = last_point_cart + (nearest_pt_cart - last_point_cart)/2
            midpoint_el = 90 - np.linalg.norm(midpoint_cart)*90
            midpoint_az = np.arctan2(midpoint_cart[1], midpoint_cart[0])%(2*np.pi)*180/np.pi                           
            
            # If midpoint traverses through the no go zone
            if (self.no_go_zone['az_min']<midpoint_az<self.no_go_zone['az_max'])\
            and (self.no_go_zone['el_min']<midpoint_el<self.no_go_zone['el_max']):
            
                if (self.no_go_zone['az_min']<self.last_az_el[0]<self.no_go_zone['az_max']):
                    new_az = nearest_pt_polar[0]
                    new_el = self.last_az_el[1]
                    
                elif (self.no_go_zone['el_min']<self.last_az_el[1]<self.no_go_zone['el_max']):
                    new_az = self.last_az_el[0]
                    new_el = nearest_pt_polar[1]             
                else:
                    new_az = nearest_pt_polar[0]
                    new_el = nearest_pt_polar[1]                                
                             
            # If mid point does not go through no go zone, then just go to the perimeter.       
            else:
                new_az = nearest_pt_polar[0]
                new_el = nearest_pt_polar[1]
            logging.warning("Requested point az= {:.1f} el={:.1f} is in a no go zone. Pointing to point the perimeter, az= {:.1f} el={:.1f}".format(azimuth,elevation, new_az, new_el))
        # If not in no go zone, just pass through.             
        else:
            new_az = azimuth
            new_el = elevation
            
        new_az = (new_az+180)%360 - 180
        self.last_az_el = (new_az, new_el)            
        return new_az, new_el           
    
if __name__ == '__main__':
    nogozone = NoGoZone('/home/ad_user/ground_station/lib/sat_tracker/nogozones.yaml')    
    nogozone.adjust_for_zone(298.6, 20)
  
def convert_to_ptu_frame(azimuth:float, 
                         elevation:float, 
                         ptu_pan_to_az:float, 
                         ptu_tilt_to_el:float,
                         cont_rotation:False, 
                         force_cw:False, 
                         force_ccw:False,
                         hard_pan_lim_cw:float=PTU_DEFAULTS.HARD_PAN_LIM_CW, 
                         hard_pan_lim_ccw:float=PTU_DEFAULTS.HARD_PAN_LIM_CCW,
                         *, diagnostics=True):
    """Converts from global frame to local PTU body frame. 

    Args:
        azimuth (_type_): _description_
        elevation (_type_): _description_

    Returns:
        _type_: _description_
    """
    # adjusted_az = azimuth - ptu_to_az_cal
    # adjusted_el = elevation - ptu_to_el_cal
    
    if cont_rotation:
        # Continuous rotation model: Pan values are 0-360 with an angle offset of +180
        pan  = ((azimuth%360 - ptu_pan_to_az)%360 + 180)%360
    elif force_cw:
        # Check if pan value is in overlap region where forcing CW or CCW applies
        pan_360 = (azimuth - ptu_pan_to_az) % 360
        if (pan_360>(hard_pan_lim_ccw%360)) and (pan_360<(hard_pan_lim_cw%360)):
            # Force clockwise ==> Positive Pan values
            pan  = (azimuth - ptu_pan_to_az) % 360
        # If not, pan values should be +/-180
        else:
            # Make Pan +/- 180
            pan = ((azimuth - ptu_pan_to_az)+180)%360 - 180  
        # Double check we don't pass limits
        if pan>= hard_pan_lim_cw:
            if diagnostics:
                logging.error("probably did something wrong")
            pan = hard_pan_lim_cw
        elif pan <= hard_pan_lim_ccw:
            if diagnostics:
                logging.error("probably did something wrong")
            pan = hard_pan_lim_ccw
    elif force_ccw:
        # Check if pan value is in overlap region where forcing CW or CCW applies
        pan_360 = (azimuth - ptu_pan_to_az) % 360
        if (pan_360>(hard_pan_lim_ccw%360)) and (pan_360<(hard_pan_lim_cw%360)):        
            # Force counter clockwise ==> Negative Pan values
            pan  = ((azimuth - ptu_pan_to_az) % 360) -360
        else:
            # Make Pan +/- 180
            pan = ((azimuth - ptu_pan_to_az)+180)%360 - 180  
        # Double check we don't pass limits
        if pan>= hard_pan_lim_cw:
            if diagnostics:
                logging.error("probably did something wrong")
            pan = hard_pan_lim_cw
        elif pan <= hard_pan_lim_ccw:
            if diagnostics:
                logging.error("probably did something wrong")
            pan = hard_pan_lim_ccw                 
    else:
        az_rom = hard_pan_lim_cw - (hard_pan_lim_ccw)
        
        if az_rom<=360:
            pan_cw = ((azimuth - ptu_pan_to_az) % 360)
            pan_ccw = ((azimuth - ptu_pan_to_az) % 360)-360
            # Point is in range we cannot point... Figure out if rotating CW or CCW is closer
            if (pan_cw > hard_pan_lim_cw) and (pan_ccw < hard_pan_lim_ccw):
                if abs(pan_cw - hard_pan_lim_cw) < (abs(pan_ccw - hard_pan_lim_ccw)):
                    pan = pan_cw
                else:
                    pan = pan_ccw
            elif pan_cw < hard_pan_lim_cw:
                pan = pan_cw
            elif pan_ccw > hard_pan_lim_ccw:
                pan = pan_ccw                
        else:
            # Make Pan +/- 180
            pan = ((azimuth - ptu_pan_to_az)+180)%360 - 180  
            
    tilt = (elevation - ptu_tilt_to_el)         
    # tilt = adjusted_el + PTU_TILT_TO_EL
    if tilt>0:
        if diagnostics:
            logging.warning("Tilt cannot exceed 0 degrees. Clipping {:.1f} to 0 degrees".format(tilt))
        tilt = 0
    if tilt<-90:
        if diagnostics:
            logging.warning("Tilt must >= -90 degrees. Clipping {:.1f} to -90 degrees".format(tilt))
        tilt = -90            
    if diagnostics:
        logging.debug("Converted az {:.4f}, el {:.4f} to pan {:.4f}, tilt {:.4f}".format(azimuth, elevation, pan, tilt))
    return pan, tilt  
        
def convert_from_ptu_frame(pan, 
                           tilt, 
                           ptu_pan_to_az:float, 
                           ptu_tilt_to_el:float,
                           cont_rotation:bool = False):
    """Converts from PTU frame to az/el
    PTU angles are +=clockwise, -=counter clockwise
    Output angles are +/- 180 degrees

    Args:
        pan (float): _description_
        tilt (float): _description_

    Returns:
        tuple: _description_
    """
    if cont_rotation:
        azimuth = ((pan - 180) + ptu_pan_to_az) % 360
    else:
        azimuth = (pan + ptu_pan_to_az) % 360
    elevation=tilt + ptu_tilt_to_el
    # pan_cal = (pan + ptu_to_az_cal)
    # el_cal  = tilt + ptu_to_el_cal 
    
    # azimuth = ((pan_cal+PTU_PAN_TO_AZ) + 180) % 360 - 180
    # elevation = el_cal - PTU_TILT_TO_EL
    
    return azimuth, elevation

