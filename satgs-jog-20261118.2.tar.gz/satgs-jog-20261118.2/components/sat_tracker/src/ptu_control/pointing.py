"""Frozen run policy shared by strict PTU clients and managers."""
import hashlib
import json
import math
from collections.abc import Mapping
from dataclasses import dataclass
from fractions import Fraction


class PointingError(RuntimeError):
    def __init__(self, primary, submitted=0, submission="none"):
        allowed = ("invalid_argument", "policy_mismatch", "endpoint_rejected",
                   "context_changed", "deadline", "cancelled", "disconnected",
                   "cleanup_incomplete", "serial_failure", "busy", "unsupported",
                   "scheduler_failure")
        self.primary = primary if primary in allowed else "serial_failure"
        self.submitted = submitted if type(submitted) is int and 0 <= submitted <= 4 else 0
        self.submission = submission if submission in ("none", "partial", "complete", "unknown") else "unknown"
        super().__init__("PTU pointing " + self.primary)


def _number(value):
    if type(value) not in (int, float) or abs(value) > 1000000 or not math.isfinite(value):
        raise PointingError("invalid_argument")
    return float(value)


def _positive(value, maximum):
    if type(value) is not int or not 0 < value <= maximum:
        raise PointingError("invalid_argument")
    return value


def _hex(value):
    if type(value) is not str or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
        raise PointingError("invalid_argument")
    return value


def _ratio(value):
    exact = Fraction(value)
    return str(exact.numerator) + "/" + str(exact.denominator)


def _station_location(settings):
    value = settings.get("station_location")
    if value is None:
        return None
    keys = {"source", "station_id", "revision", "latitude_deg", "longitude_deg",
            "altitude_m", "altitude_reference", "coordinate_units"}
    if not isinstance(value, Mapping) or set(value) != keys:
        raise PointingError("invalid_argument")
    if (type(value["source"]) is not str or value["source"] not in ("manual", "configured")
            or type(value["coordinate_units"]) is not str or value["coordinate_units"] != "degrees-metres"):
        raise PointingError("invalid_argument")
    for key in ("station_id", "altitude_reference"):
        text = value[key]
        if (type(text) is not str or not 1 <= len(text) <= 128
                or not text.isascii() or not text.isprintable()):
            raise PointingError("invalid_argument")
    _positive(value["revision"], 2**63 - 1)
    coordinates = tuple(_number(value[key]) for key in
                        ("latitude_deg", "longitude_deg", "altitude_m"))
    if not -90 <= coordinates[0] <= 90 or not -180 <= coordinates[1] <= 180:
        raise PointingError("invalid_argument")
    supplied = tuple(_number(settings.get(key)) for key in
                     ("ground_station_lat", "ground_station_lon", "ground_station_altm"))
    if coordinates != supplied:
        raise PointingError("policy_mismatch")
    return tuple(value[key] for key in ("source", "station_id", "revision")) + coordinates + (
        value["altitude_reference"], value["coordinate_units"])


def _rectangle(data):
    if data is None:
        return None
    if not isinstance(data, Mapping) or set(data) != {"nogozones"}:
        raise PointingError("invalid_argument")
    zones = data["nogozones"]
    if type(zones) not in (list, tuple) or len(zones) != 1:
        raise PointingError("invalid_argument")
    zone = zones[0]
    keys = ("az_min", "az_max", "el_min", "el_max")
    if not isinstance(zone, Mapping) or set(zone) != set(keys):
        raise PointingError("invalid_argument")
    values = tuple(_number(zone[key]) for key in keys)
    if not (0 <= values[0] < values[1] < 360 and 0 <= values[2] < values[3] <= 90):
        raise PointingError("invalid_argument")
    return values


@dataclass(frozen=True)
class PointingPolicy:
    manager_id: int
    run_id: str
    configuration_generation: int
    calibration_generation: int
    protocol: str
    protocol_address: object
    continuous_rotation: bool
    hard_pan_limit_cw: float
    hard_pan_limit_ccw: float
    pan_to_az: float
    tilt_to_el: float
    elevation_mask: float
    no_go: object
    tle_sha256: str
    binding: bytes
    station_location: object = None

    @classmethod
    def from_settings(cls, settings, ptu_id, elevation_mask, no_go_data):
        _positive(ptu_id, 2**31 - 1)
        if not isinstance(settings, Mapping):
            raise PointingError("invalid_argument")
        positioners = settings.get("positioners")
        if type(positioners) not in (list, tuple) or not 1 <= len(positioners) <= 128:
            raise PointingError("invalid_argument")
        selected = [item for item in positioners if isinstance(item, Mapping)
                    and type(item.get("id")) is int and item["id"] == ptu_id]
        if len(selected) != 1:
            raise PointingError("invalid_argument")
        item = selected[0]
        if item.get("no_go_config") is not None:
            raise PointingError("invalid_argument")
        context = item.get("pointing_context")
        keys = {"frame", "run_id", "configuration_generation", "calibration_generation",
                "pan_to_az", "tilt_to_el", "protocol_address", "tle_sha256"}
        if not isinstance(context, Mapping) or set(context) != keys:
            raise PointingError("invalid_argument")
        if context["frame"] != "azimuth-elevation-degrees.v1" or type(context["frame"]) is not str:
            raise PointingError("invalid_argument")
        protocol = item.get("protocol")
        if type(protocol) is not str or protocol not in ("PTCR20", "PTCR96"):
            raise PointingError("invalid_argument")
        address = context["protocol_address"]
        if (protocol == "PTCR20" and address is not None) or (
                protocol == "PTCR96" and (type(address) is not int or not 0 <= address <= 255)):
            raise PointingError("invalid_argument")
        continuous = item.get("cont_rot")
        if type(continuous) is not bool:
            raise PointingError("invalid_argument")
        cw = _number(item.get("hard_pan_lim_cw"))
        ccw = _number(item.get("hard_pan_lim_ccw"))
        pan = _number(context["pan_to_az"])
        tilt = _number(context["tilt_to_el"])
        mask = _number(elevation_mask)
        if not (-360 <= ccw < cw <= 360 and -360 <= pan <= 360
                and 0 <= tilt <= 180 and 0 <= mask < 90):
            raise PointingError("invalid_argument")
        rectangle = _rectangle(no_go_data)
        run = _hex(context["run_id"])
        tle = _hex(context["tle_sha256"])
        generation = _positive(context["configuration_generation"], 2**63 - 1)
        calibration = _positive(context["calibration_generation"], 2**63 - 1)
        location = _station_location(settings)
        record = dict(version="ptu-pointing-binding.v2" if location is None else "ptu-pointing-binding.v3", frame=context["frame"],
                      manager_id=ptu_id, run_id=run, configuration_generation=generation,
                      calibration_generation=calibration, protocol=protocol,
                      protocol_address=address, continuous_rotation=continuous,
                      hard_pan_limit_cw=_ratio(cw), hard_pan_limit_ccw=_ratio(ccw),
                      pan_to_az=_ratio(pan), tilt_to_el=_ratio(tilt), elevation_mask=_ratio(mask),
                      no_go=None if rectangle is None else [_ratio(v) for v in rectangle],
                      tle_sha256=tle)
        if location is not None:
            record["station_location"] = list(location[:3]) + [_ratio(v) for v in location[3:6]] + list(location[6:])
        digest = hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":"),
                                           ensure_ascii=True).encode("ascii")).digest()
        return cls(ptu_id, run, generation, calibration, protocol, address, continuous,
                   cw, ccw, pan, tilt, mask, rectangle, tle, digest, location)

    @staticmethod
    def check_forces(cw, ccw):
        if type(cw) is not bool or type(ccw) is not bool or (cw and ccw):
            raise PointingError("invalid_argument")

    def _check_exact(self, azimuth, elevation):
        if not self.elevation_mask <= elevation <= 90:
            raise PointingError("endpoint_rejected")
        if self.no_go is not None:
            amin, amax, emin, emax = (Fraction(v) for v in self.no_go)
            if amin <= azimuth <= amax and emin <= elevation <= emax:
                raise PointingError("endpoint_rejected")

    def check_endpoint(self, azimuth, elevation):
        azimuth = _number(azimuth) % 360
        elevation = _number(elevation)
        self._check_exact(Fraction(azimuth), Fraction(elevation))
        return azimuth, elevation

    def check_encoded(self, prepared):
        scale = 10 if self.protocol == "PTCR20" else 100
        if (type(prepared.pan_units) is not int or type(prepared.tilt_units) is not int
                or type(prepared.units_per_degree) is not int or prepared.units_per_degree != scale):
            raise PointingError("context_changed")
        pan = Fraction(prepared.pan_units, scale)
        tilt = Fraction(prepared.tilt_units, scale)
        if not (Fraction(self.hard_pan_limit_ccw) <= pan <= Fraction(self.hard_pan_limit_cw)
                and -90 <= tilt <= 0):
            raise PointingError("endpoint_rejected")
        azimuth = (pan - (180 if self.continuous_rotation else 0) + Fraction(self.pan_to_az)) % 360
        elevation = tilt + Fraction(self.tilt_to_el)
        self._check_exact(azimuth, elevation)
        return azimuth, elevation

    def validate_tle(self, text):
        if (type(text) is not str or not 1 <= len(text) <= 4096
                or not text.isascii() or not text.isprintable()):
            raise PointingError("invalid_argument")
        parts = text.split(",")
        if len(parts) != 3 or any(not item for item in parts):
            raise PointingError("invalid_argument")
        if hashlib.sha256(text.encode("ascii")).hexdigest() != self.tle_sha256:
            raise PointingError("policy_mismatch")
        return text
