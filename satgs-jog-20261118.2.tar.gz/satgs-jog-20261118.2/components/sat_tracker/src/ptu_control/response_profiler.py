import csv
import yaml
import argparse
import logging
import time
import signal
import threading
from pathlib import Path
import numpy as np
import pandas as pd
from datetime import datetime, timedelta, timezone
from google.protobuf.timestamp_pb2 import Timestamp
from scipy.interpolate import CubicSpline, interp1d

import serialptu
from serialptu.ptu import PTU

from ptu_control import ptu_msg_pb2 as ptu_pb
from ptu_control.constants import Topics, PTUStatus, DEFAULTS as PTU_DEFAULTS
from ptu_control.utils import (PtuID, 
                               ptu_move_msg_from_pb, 
                               convert_to_ptu_frame, 
                               convert_from_ptu_frame,
                               NoGoZone, 
                               PTUDataMsg
)
from satgs.utils import (TLE, 
                         PassInfo, 
                         find_closest_pass, 
                         tle_from_str,
                         make_az_el_scurves
)


logger = logging.getLogger(__name__)
default_cfg = Path('~/ground_station/config/config.yaml').expanduser()


class PiecewiseRampResonseProfiler():
    def __init__(self, 
                 ptu:PTU, 
                 ptu_details:PtuID, 
                 log_dir:Path, 
                 simulate_hw:bool=False, 
                 rate:float=1.0):
        
        self.ptu = ptu
        self.ptu_details = ptu_details
        self.ptu_pan_to_az = PTU_DEFAULTS.PTU_PAN_TO_AZ #0
        self.ptu_tilt_to_el = PTU_DEFAULTS.PTU_TILT_TO_EL #90
        self.log_dir = log_dir
        self.simulate_hw = simulate_hw
        self.previous_command = {'az':0, 'el':0}
        self.rate = rate
        self.running = True
        self.measurement_logging = False
        if self.simulate_hw:
            logger.warning("Running in test mode! HW is simulated! Manager only replies to client with dummy messages.")    
            sim_thread = threading.Thread(target = self._simulated_listener)
            sim_thread.start()
            self.sim_thread = sim_thread
        else:
            self.sim_thread=None
            logger.info("Opening PTU Serial Port")
            try:
                self.ptu.open()
                logger.info("Port Open")            
            except:
                logger.error("Cannot connect to PTU serial port")
                return
            self.ptu.connect_status_listener(self.ptu_status_listener)   
                     
    def close(self):
        self.jog_cmd_log.close()
        self.ramp_log.close()
        if self.simulate_hw:
            self.previous_command = {'az':0, 'el':0}
            self.running=False
            self.sim_thread.join()
        else:
            self.ptu.close()
    
    def reset(self):
        if self.simulate_hw:
            pass
        self.measurement_logging = False
        self.hit_limit = False
        self.cont_rot_history = []
        
    def set_to_home(self)->bool:
        logger.warning("Setting to home 0/0")
        self._move_to_az_el(0,0)
        move_start = time.time()
        while ((time.time() - move_start) < 30) :          
            dest_az, dest_el = self._move_to_az_el(0,0)  
            cur_az = (self.ptu_az_pos + 180) % 360 - 180
            cur_el = (self.ptu_el_pos + 180) % 360 - 180                
            time.sleep(2)  
            if (abs(cur_az - 0)<1) and (abs(cur_el - 0)<1):
                logger.warning('Reached Home')
                return True
        logger.warning("Didn't reach home in alloted time, breaking.... ")
        return False
            
    def set_to_zenith(self)->bool:
        logger.warning("Setting to zenith 0/90")        
        self._move_to_az_el(0,PTU_DEFAULTS.MAX_EL)
        move_start = time.time()
        while ((time.time() - move_start) < 30) :          
            dest_az, dest_el = self._move_to_az_el(0,PTU_DEFAULTS.MAX_EL)  
            cur_az = (self.ptu_az_pos + 180) % 360 - 180
            cur_el = (self.ptu_el_pos + 180) % 360 - 180                
            time.sleep(2)  
            if (abs(cur_az - 0)<1) and (abs(cur_el - PTU_DEFAULTS.MAX_EL)<1):
                logger.warning('Reached Zenith')
                return True
        logger.warning("Didn't reach Zenith in alloted time, breaking.... ")
        return False  
          
    def run_response(self, axis:str, velocities:np.ndarray, t_steps:np.ndarray, name:str):
        time.sleep(3)
        if np.all(np.diff(velocities)>0):
            dir = 'pos'
        elif np.all(np.diff(velocities)<0):
            dir = 'neg'
        else:
            logger.error('Velocities must be monotonically increasing or decreasing')
            return
        if np.any(np.abs(velocities)>1):
            logger.error("Velocities must be in range -1 to 1")
            return
        # Pre log log files
        logger.info("Prepping log files")
        self.jog_cmd_log = open(self.log_dir / f'ramp_commands_axis_{axis}_{name}.csv', 'w+')
        self.jog_cmd_writer = csv.writer(self.jog_cmd_log, delimiter=',')
        self.jog_cmd_writer.writerow(['utc_time', 'cmd_pan_jog', 'cmd_tilt_jog']) 
        
        self.ramp_log = open(self.log_dir / f'ramp_response_vel_{axis}_{name}.csv', 'w+')
        self.ramp_log_writer = csv.writer(self.ramp_log, delimiter=',')
        self.ramp_log_writer.writerow(['utc_time', 'ptu_pan', 'ptu_tilt', 'ptu_az', 'ptu_el'])         
        
        self.measurement_logging = True
        ramp_start = time.time()
        self.cont_rot_history = []
        self.hit_limit = False
        if axis=='pan':
            if dir=='pos':
                direction = 'Clockwise'
                angle_limit = 180
            else:
                direction = 'CounterClockwise'
                angle_limit = -180
            self.set_to_home()
            logger.info(f"Stating {name} Jog {direction} direction. Will stop at limit")
            t_start = time.time()
            kk = 0
            while not self.hit_limit:
                vel_step = velocities[kk]
                if self.simulate_hw:
                    dt = time.time() - ramp_start
                    self.previous_command['az'] = 0 + dt*vel_step*15
                    print(f"Azimuth {self.previous_command['az']:0.3f} deg")
                    self.previous_command['el'] = 0                   
                else:
                    self.ptu.jog(vel_step, 0, False)
                self.jog_cmd_writer.writerow([datetime.now(timezone.utc), vel_step, 0])
                time.sleep(self.rate)
                elapsed_time = time.time()-t_start
                if elapsed_time>t_steps[kk]:
                    kk+=1
                if kk == t_steps.size:
                    break
                print(f"t = {elapsed_time:0.1f}, Vel  = {vel_step:0.3f}, Az Delta {abs((((self.ptu_az_pos - angle_limit)+180)%360)-180):0.2f} deg")
                if abs((((self.ptu_az_pos - angle_limit)+180)%360)-180)<5:
                    self.hit_limit=True
                if self.ptu_details.cont_rot:
                    self.cont_rot_history.append(self.ptu_az_pos)
            logger.info("Pan Ramp Complete Closing Log")
            if not self.simulate_hw:
                self.ptu.jog(0, 0, False)
            self.measurement_logging = False            
            if self.ptu_details.cont_rot and not self.simulate_hw:
                logger.info("Cont Rotation Model... Reversing Pan Profile")
                di = round(len(self.cont_rot_history)/10)
                reverse_steps = self.cont_rot_history.reverse()[0::di]
                for az in reverse_steps:
                    self._move_to_az_el(az, 0)
                    time.sleep(3)
                pass
            self.set_to_home()
            
        elif axis == 'tilt':
            if dir=='pos':
                direction = 'Up'
                angle_limit = PTU_DEFAULTS.MAX_EL
                self.set_to_home()
                el0 = 0
            else:
                direction = 'Down'
                angle_limit = 0
                self.set_to_zenith()
                el0 = PTU_DEFAULTS.MAX_EL
            logger.info(f"Stating {name} Jog {direction} direction. Will stop at limit")
            t_start = time.time()
            kk = 0            
            while not self.hit_limit:
                vel_step = velocities[kk]                
                if self.simulate_hw:
                    dt = time.time() - ramp_start
                    self.previous_command['el'] = el0 + dt*vel_step*15
                    print(f"Elevation {self.previous_command['el']:0.3f} deg")
                    self.previous_command['az'] = 0                   
                else:                
                    self.ptu.jog(0, vel_step, False)
                self.jog_cmd_writer.writerow([datetime.now(timezone.utc), 0, vel_step])                
                time.sleep(self.rate)
                elapsed_time = time.time()-t_start
                if elapsed_time>t_steps[kk]:
                    kk+=1
                if kk == t_steps.size:
                    break                    
                print(f"t = {elapsed_time:0.1f}, Vel  = {vel_step:0.3f} Tilt: {self.ptu_el_pos:0.3f} deg")
                if (vel_step>0) and (self.ptu_el_pos>(angle_limit-5)):                    
                    self.hit_limit=True
                elif (vel_step<0) and (self.ptu_el_pos<(angle_limit+5)):
                    self.hit_limit=True
            logger.info("Pan Ramp Complete Closing Log")
            if not self.simulate_hw:
                self.ptu.jog(0, 0, False)
            self.measurement_logging = False
            self.set_to_home()            
    
    def _move_to_az_el(self, 
                       azimuth: float, 
                       elevation: float, 
                       force_cw: bool = False,
                       force_ccw: bool = False) -> tuple:
        azimuth = ((azimuth+180)%360)-180
        
        adj_az=azimuth
        adj_el=elevation
        if self.simulate_hw:
            self.previous_command["az"] = adj_az
            self.previous_command["el"] = adj_el
        
        ptu_pan, ptu_tilt = self._convert_to_ptu_frame(adj_az, adj_el, force_cw, force_ccw )
        if self.ptu_details.cont_rot:
            ptu_pan = (ptu_pan % 360)
            adj_az = (adj_az % 360)
            
        # ptu_pan, ptu_tilt = convert_to_ptu_frame(adj_az, adj_el, self.ptu_pan_to_az, self.ptu_tilt_to_el)
        logger.info("\n    Moving to Az {:0.2f} El {:0.1f} || Pan= {:0.2f}, Tilt={:0.2f} || Force CW = {}, Force CCW={} ".format(azimuth, elevation, ptu_pan, ptu_tilt, force_cw, force_ccw))        
        self._move_to(ptu_pan, ptu_tilt)
        return adj_az, adj_el            
        
    def _move_to(self, pan:float, tilt:float) -> bool:
        if self.simulate_hw:
            self.ptu_az_pos = self.previous_command["az"]
            self.ptu_el_pos = self.previous_command["el"]
            self.ptu_pan_pos, self.ptu_tilt_pos = self._convert_to_ptu_frame(self.ptu_az_pos, self.ptu_el_pos)
            return True
        try:
            self.ptu.move_to(pan, tilt)
        except serialptu.errors.TimeoutError as e:
            logger.warning("PTU Timeout Error. Set DEBUG for details")
            logger.debug("Details: ", exc_info=e)        
            return False
        except Exception as e:
            logger.warning("Some other error")
            logger.warning("Details: ", exc_info=e)
            return False
        return True
        
    def _reset_motor_wrapper(self)->None:
        try:
            self.ptu.reset_motor_timeout()                             
        except serialptu.errors.TimeoutError as e:
            logger.warning("PTU Timeout Error. Set DEBUG for details")
            logger.debug("Details: ", exc_info=e) 
        except Exception as e:
            logger.warning("Some other error")
            logger.warning("Details: ", exc_info=e)
            
    def _convert_to_ptu_frame(self, azimuth:float, elevation:float, 
                              force_cw:bool=False, force_ccw:bool=False):
        pan, tilt = convert_to_ptu_frame(
            azimuth, elevation, self.ptu_pan_to_az, self.ptu_tilt_to_el,
            self.ptu_details.cont_rot, force_cw, force_ccw, 
            self.ptu_details.hard_pan_lim_cw, self.ptu_details.hard_pan_lim_ccw)
        return pan, tilt    
    
    def _convert_from_ptu_frame(self, pan:float, tilt:float)-> tuple:

        azimuth, elevation = convert_from_ptu_frame(pan, tilt, self.ptu_pan_to_az, self.ptu_tilt_to_el, self.ptu_details.cont_rot)
        return azimuth, elevation    
          
    def ptu_status_listener(self, ptu_data:dict):
        '''
        Callback for the internal PTU status data. Only handles move_response messages
        Re-packages the data into a protobuf to send on topic Topics.PTU_STATUS

        Resets the PTU if there has been a Timeout (TO) or Direction Error (DE) reported in the ptu_data call
        '''
        # ptu_data = {'message_type': _ , 'command': __, 'pan': ___, 'tilt': ___ 'status'}
        if (ptu_data["message_type"] == "move_response") or (ptu_data["message_type"] == "status_response"):
            ptu_status_msg = ptu_pb.PositionerStatus()
            ptu_dynamics_status = ptu_status_msg.status            
            reset_wait = 1
            ptu_data_msg = PTUDataMsg.from_dict(ptu_data)
            if ptu_data_msg.status.pan.DE:
                logger.warning("Pan Directional Error... Resetting")
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.pan.TO:
                logger.warning("Pan Timeout Error... Resetting")                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.pan.CWSL or ptu_data_msg.status.pan.CCWSL:
                logger.warning("Pan Soft Limits Exceeded... Stopping")                
                self.hit_limit = True
            elif ptu_data_msg.status.pan.CWHL or ptu_data_msg.status.pan.CCWHL:
                logger.warning("Pan Hard Limits Exceeded... Stopping")                
                self.hit_limit = True
            if ptu_data_msg.status.tilt.DE:
                logger.warning("Tilt Directional Error... Resetting")
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.tilt.TO:
                logger.warning("Tilt Timeout Error... Resetting")                
                self.ptu.reset_motor_timeout()                
                time.sleep(reset_wait)
            elif ptu_data_msg.status.tilt.USL or ptu_data_msg.status.tilt.DSL:
                logger.warning("Tilt Soft Limits Exceeded... Resetting")                
                self.hit_limit = True
            elif ptu_data_msg.status.tilt.UHL or ptu_data_msg.status.tilt.DHL:
                logger.warning("Tilt Hard Limits Exceeded... Stopping")                
                self.hit_limit = True

            temp_time = Timestamp()
            temp_time.GetCurrentTime()
            ptu_command_msg = ptu_pb.PTUCommandStatus(
                timestamp=temp_time, azimuth =0, elevation =0)            

            ptu_status_msg = ptu_pb.PositionerStatus()            

            self.ptu_pan_pos = ptu_data_msg.pan #ptu_data["pan"]
            self.ptu_tilt_pos = ptu_data_msg.tilt #ptu_data["tilt"]
            self.ptu_az_pos, self.ptu_el_pos = self._convert_from_ptu_frame(ptu_data_msg.pan,  ptu_data_msg.tilt)

            ptu_data_msg.status.to_pb()
            # ptu_status_msg.status = ptu_dynamics_status
            ptu_status_msg.state = "debug"
            ptu_status_msg.id = self.ptu_details.id            
            ptu_status_msg.pan = self.ptu_pan_pos
            ptu_status_msg.tilt = self.ptu_tilt_pos                            
            ptu_status_msg.azimuth = self.ptu_az_pos
            ptu_status_msg.elevation = self.ptu_el_pos
            ptu_status_msg.ptu_pan_to_az = self.ptu_pan_to_az             
                
            ptu_status_msg.command.CopyFrom(ptu_command_msg) 
            ptu_status_msg.status.CopyFrom(ptu_data_msg.status.to_pb())
            temp_time = Timestamp()
            temp_time.GetCurrentTime()            
            ptu_status_msg.timestamp.CopyFrom(temp_time)
                                 
            # Log formatted message
            ptu_move_msg = ptu_move_msg_from_pb(ptu_status_msg)
            status_str = ptu_move_msg.print()  
            logger.info(status_str)

            if self.measurement_logging:                
                utc_t_stamp = datetime.now(timezone.utc) #t_stamp.replace(tzinfo=timezone.utc)           
                self.ramp_log_writer.writerow(
                    [utc_t_stamp, ptu_data_msg.status.pan, ptu_data_msg.status.tilt, self.ptu_az_pos, self.ptu_el_pos])
        else:
            logger.warning("Received a ptuStatusMessage that isn't supported. Type: %s" % ptu_data["message_type"])          
            
    def _simulated_listener(self):
        while self.running:
            self.ptu_az_pos = self.previous_command['az']
            self.ptu_el_pos = self.previous_command['el']            
            self.ptu_pan_pos, self.ptu_tilt_pos = self._convert_to_ptu_frame(self.previous_command['az'],  self.previous_command['el'])        
            if self.measurement_logging:                
                utc_t_stamp = datetime.now(timezone.utc) #t_stamp.replace(tzinfo=timezone.utc)           
                self.ramp_log_writer.writerow(
                    [utc_t_stamp, self.ptu_pan_pos, self.ptu_tilt_pos, self.ptu_az_pos, self.ptu_el_pos])            
            time.sleep(self.rate)
          
def main():
    '''
    '''
    parser = argparse.ArgumentParser(description = 'Manager applique for active MQ clients interfacing with the Pan and tilt unit')
    parser.add_argument('-config', default = str(default_cfg), type=str, 
                        help = ('Config File, Defaults to {}.' \
                            'Yaml contains activeMQ connection information'.format(str(default_cfg))))      
    parser.add_argument("--ptu-id", required=True, type=int, 
                        help="PTU ID corresponding to PTU this instance manages as described in config.yaml")
    parser.add_argument("--port", "-p", default="/dev/ttyUSB0", help="Serial port to use")
    parser.add_argument("--nohw",  action = 'store_true', help="Test mode for when serial interface is not available. Tests interaction between client and manager")
    parser.add_argument("--axis", "-axis", default="pan", help="pan or tilt")
    parser.add_argument("--speed", "-speed", default="slow", help="slow or fast")

    args = parser.parse_args()
    
    # Load config File
    with open(args.config) as f:
        config = yaml.safe_load(f)      
    
    logging_level = logging.INFO # Will change to WARN later    
    root_logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    root_logger.setLevel(logging.DEBUG)
            
    log_dir = Path('/opt/ground_station/logs')    
    file_handler = logging.FileHandler(log_dir / 'ramp_profiler.log', 'w+')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG) # Log DEBUG level to file.        
    logger.addHandler(file_handler)       
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)     
    console_handler.setFormatter(formatter)     
    root_logger.addHandler(console_handler)    
               
    try:
        ptu_dict = {}
        for positioner in config['positioners']:
            ptu_dict[positioner['id']] = positioner    
        if ptu_dict[args.ptu_id]['no_go_config'] is None:
            no_go_config = None
        else:
            no_go_config = Path(ptu_dict[args.ptu_id]['no_go_config'])
            if '~' in str(no_go_config):
                no_go_config = Path(str(no_go_config).replace('~', config['home_directory']))                
            
        ptu_details = PtuID(args.ptu_id, ptu_dict[args.ptu_id]['protocol'],
                            ptu_dict[args.ptu_id]['baud'],
                            ptu_dict[args.ptu_id]['cont_rot'], 
                            ptu_dict[args.ptu_id]['hard_pan_lim_cw'], 
                            ptu_dict[args.ptu_id]['hard_pan_lim_ccw'], 
                            ptu_dict[args.ptu_id]['type'],
                            ptu_dict[args.ptu_id]['name'],
                            ptu_dict[args.ptu_id]['pix_id'],
                            ptu_dict[args.ptu_id]['allow_pointing_errors'],                            
                            no_go_config,
                            )
    except:
        logger.error("Formatting error of positioners value in config, check config.yaml")
        return
    if args.nohw:
        ptu = None
    else:
        serial_lib_logger = logging.getLogger('serial_ptu')
        formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
        serial_lib_logger.setLevel(logging.DEBUG)
                
        log_dir = Path('/opt/ground_station/logs')    
        file_handler = logging.FileHandler(log_dir / 'serial_ptu.log', 'w+')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.DEBUG) # Log DEBUG level to file.        
        serial_lib_logger.addHandler(file_handler)   

        ptu = serialptu.make_ptu(ptu_dict[args.ptu_id]['protocol'], 
                                 args.port, 
                                 baud=ptu_dict[args.ptu_id]['baud'], 
                                 logger=serial_lib_logger, 
                                 rate=0.1
        )
    
    # ptu:PTU, ptu_details:PtuID, log_dir:Path, simulate_hw:bool = False, rate:float = 1.0
    manager = PiecewiseRampResonseProfiler(ptu, 
                                           ptu_details, 
                                           Path(config['logging_dir'].replace('~', config['home_directory'])), 
                                           args.nohw, 
                                           rate=0.1
    )

    speed = args.speed.lower()

    if ptu_dict[args.ptu_id]['protocol']=='PTCR96':
        if speed == 'slow':
            vel = (np.arange(0,128,16) +1) /255
            dt = 5
            t_steps = np.cumsum(np.arange(vel.size,0, -1) * dt)
        else:
            vel = np.arange(128+32,255,32)/255
            dt = 2
            t_steps = np.cumsum(np.arange(vel.size,0, -1) * dt)
    if ptu_dict[args.ptu_id]['protocol']=='PTCR20':
        if speed == 'slow':
            vel = (np.arange(0,32,4) + 1)/127
            dt = 5
            t_steps = np.cumsum(np.arange(vel.size,0, -1) * dt)
        else:
            vel = np.arange(64,127,16)/127
            dt = 3
            t_steps = np.cumsum(np.arange(vel.size,0, -1) * dt)               
            
        vel = np.linspace(0,63,8)+1

    manager.run_response(args.axis, vel, t_steps,name=speed)        
    manager.close()


if __name__ == '__main__':
    main()
        
