"""Fixed correlated outcomes for explicitly enabled scheduled tracking."""
from dataclasses import dataclass


MAX_SEQUENCE = 2**64 - 1
CATEGORIES = frozenset((
    "ok", "deadline", "cancelled", "endpoint_rejected", "invalid_argument",
    "policy_mismatch", "context_changed", "disconnected", "serial_failure",
    "busy", "unsupported", "scheduler_failure",
))
STATES = frozenset((
    "free", "tle_loaded", "tle_priming", "tle_primed", "tle_tracking",
    "complete", "failed", "fault", "invalidated",
))
SUBMISSIONS = frozenset(("none", "partial", "complete", "unknown"))


@dataclass(frozen=True)
class TrackingOutcome:
    manager_id: int
    sequence: int
    operation: int
    category: str
    state: str
    submitted: int
    submission: str
    total_submitted: int
    possible_submission: bool
