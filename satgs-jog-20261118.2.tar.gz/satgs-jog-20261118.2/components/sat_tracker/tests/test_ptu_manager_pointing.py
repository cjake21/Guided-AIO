"""Real PTU policy, protobuf, planner, transforms and codec at a recording boundary."""
import hashlib
import json
import math
import os
import tempfile
import threading
import time
import unittest
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from meteor_api.messenger import Messenger, MessengerError
from ptu_control import ptu_manager as manager_module
from ptu_control import ptu_msg_pb2 as pb
from ptu_control.constants import Topics
from ptu_control.pointing import PointingPolicy, PointingError
from serialptu.proto_impl import PTCR20, PTCR96
from serialptu.ptu import PTU
from test_prepared_pointing import RecordingSerial, acknowledgement


TLE = ("FIXTURE,1 25544U 98067A   24001.00000000  .00000000  00000-0  00000-0 0  9990,"
       "2 25544  51.6400   0.0000 0001000   0.0000   0.0000 15.50000000000000")


def settings(protocol="PTCR20", zone=None):
    return {"ground_station_lat": 42, "ground_station_lon": -71, "ground_station_altm": 100,
            "positioners": [{"id": 2, "protocol": protocol, "cont_rot": False,
                "hard_pan_lim_cw": 270, "hard_pan_lim_ccw": -270,
                "pointing_context": {"frame": "azimuth-elevation-degrees.v1", "run_id": "01" * 32,
                    "configuration_generation": 1, "calibration_generation": 1,
                    "pan_to_az": 0, "tilt_to_el": 90,
                    "protocol_address": None if protocol == "PTCR20" else 0,
                    "tle_sha256": hashlib.sha256(TLE.encode("ascii")).hexdigest()}}]}


def rectangle(amin=290, amax=330, emin=0, emax=30):
    return {"nogozones": [{"az_min": amin, "az_max": amax, "el_min": emin, "el_max": emax}]}


class FollowingSerial(RecordingSerial):
    def __init__(self, protocol):
        super().__init__(protocol)
        self.pan_units = 0
        self.tilt_units = 0
        self.before_write = None

    def write(self, packet):
        self.writes.append(packet)
        command = self.proto._decode_strict_packet(packet, 2)[0]
        if self.before_write:
            self.before_write(command)
        if isinstance(self.result, BaseException):
            raise self.result
        if command == 0x33:
            self.pan_units, self.tilt_units, unused = self.proto.decode_move_to_packet(packet)
        if self.auto_ack:
            self.response.extend(acknowledgement(self.proto, command, self.pan_units, self.tilt_units))
        return len(packet) if self.result is None else self.result

    def motion(self):
        return [packet for packet in self.writes if self.proto._decode_strict_packet(packet, 2)[0] == 0x33]


class MessageBus:
    def __init__(self):
        self.messenger = object.__new__(Messenger)
        self.registrations = []
        self.messages = []
        self.subscribe_error_at = None
        self.cancel_error = False

    def subscribe(self, topic, callback, identifier, **controls):
        if len(self.registrations) == self.subscribe_error_at:
            raise MessengerError("cancelled")
        self.registrations.append((topic, callback, identifier))

    def cancel(self, topic, callback, identifier, **controls):
        if self.cancel_error:
            raise MessengerError("deadline")
        item = (topic, callback, identifier)
        if item not in self.registrations:
            raise MessengerError("admission")
        self.registrations.remove(item)

    def publish(self, topic, data, **controls):
        if type(data) is not bytes:
            raise AssertionError("strict wire data must be bytes")
        self.messages.append((topic, data))
        self.deliver(topic, data)

    def deliver(self, topic, data):
        for subscribed, callback, identifier in tuple(self.registrations):
            if subscribed == topic:
                callback(data, identifier)

    def install(self, stack):
        stack.enter_context(patch.object(Messenger, "strict_instance_compatible", return_value=True))
        stack.enter_context(patch.object(Messenger, "subscribe", side_effect=self.subscribe))
        stack.enter_context(patch.object(Messenger, "cancelSubscribe", side_effect=self.cancel))
        stack.enter_context(patch.object(Messenger, "publish", side_effect=self.publish))
        stack.enter_context(patch.object(Messenger, "close", side_effect=AssertionError("borrowed close")))


class Vector(list):
    def __gt__(self, other):
        return Vector(value > other for value in self)

    def __le__(self, other):
        return Vector(value <= other for value in self)

    def __and__(self, other):
        return Vector(a and b for a, b in zip(self, other))

    def __mul__(self, other):
        return Vector(value * other for value in self)

    def __truediv__(self, other):
        return Vector(value / other for value in self)


def planned_pass(clockwise=False):
    trajectory = SimpleNamespace(az=Vector([250, 240, 150, 100]),
                                 el=Vector([0, 20, 20, 0]), range_rate=Vector([-1, -1, 1, 1]))
    return SimpleNamespace(is_circumpolar=not clockwise, rising_az=100,
                           get_trajectory=lambda observer: trajectory)


class ManagerPointingTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.bus = MessageBus()
        self.bus.install(self.stack)
        self.owners = []
        self.addCleanup(self.release)
        self.cancel = threading.Event()
        self.deadline = time.monotonic() + 5

    def release(self):
        self.bus.cancel_error = False
        for owner, native in self.owners:
            native.close_failure = False
            owner.close(deadline=time.monotonic() + 1)
            self.assertFalse(native.opened)
        self.assertEqual(self.bus.registrations, [])

    def make(self, zone=None, configuration=None, activated=True, protocol=None):
        protocol = PTCR20() if protocol is None else protocol
        configuration = settings(type(protocol).__name__) if configuration is None else configuration
        native = FollowingSerial(protocol)
        with patch("serialptu.ptu.serial.Serial", return_value=native):
            driver = PTU(protocol, "recording-only", pointing=True)
        owner = manager_module.PtuManager.open_pointing(messenger=self.bus.messenger,
            settings=configuration, ptu_id=2, driver=driver, elevation_mask=0,
            no_go_data=zone, run_deadline=self.deadline, cancel=self.cancel)
        self.owners.append((owner, native))
        if activated:
            owner.activate(deadline=self.deadline, cancel=self.cancel)
        return owner, native, driver

    def move(self, owner, az=100, el=20, **extra):
        return owner.move_to_az_el(az, el, binding=owner.policy.binding,
                                   deadline=self.deadline, cancel=self.cancel, **extra)

    def orbit(self, owner, clockwise=False):
        owner.load_tle(TLE, binding=owner.policy.binding, deadline=self.deadline, cancel=self.cancel)
        self.stack.enter_context(patch.object(manager_module, "find_closest_pass",
                                              return_value=planned_pass(clockwise)))
        if clockwise:
            numeric = SimpleNamespace(pi=math.pi, argmax=lambda seq: max(range(len(seq)), key=seq.__getitem__),
                argwhere=lambda seq: [i for i, value in enumerate(seq) if value],
                unwrap=lambda seq: seq, sign=lambda value: -1 if value < 0 else 1 if value > 0 else 0)
            self.stack.enter_context(patch.object(manager_module, "np", numeric))

    def test_unresolved_selected_no_go_path_is_not_an_unrestricted_policy(self):
        for value in ("missing.yaml", "", False, 0, Path("missing.yaml"), [], {}):
            for admitted in (None, rectangle()):
                with self.subTest(value=repr(value), admitted=admitted is not None):
                    configured = settings()
                    configured["positioners"][0]["no_go_config"] = value
                    native = FollowingSerial(PTCR20())
                    with patch("serialptu.ptu.serial.Serial", return_value=native):
                        driver = PTU(native.proto, "recording-only", pointing=True)
                    with self.assertRaises(PointingError) as error:
                        manager_module.PtuManager.open_pointing(
                            messenger=self.bus.messenger, settings=configured, ptu_id=2,
                            driver=driver, elevation_mask=0, no_go_data=admitted,
                            run_deadline=self.deadline, cancel=self.cancel)
                    self.assertEqual(error.exception.primary, "invalid_argument")
                    self.assertFalse(native.opened)
                    self.assertEqual(native.writes, [])
                    self.assertTrue(driver.pointing_available)
                    self.assertEqual(self.bus.registrations, [])
                    self.assertEqual(self.bus.messages, [])
        absent = settings()
        cleared = settings()
        cleared["positioners"][0]["no_go_config"] = None
        cleared["positioners"].append({"id": 3, "no_go_config": "other-manager.yaml"})
        self.assertEqual(PointingPolicy.from_settings(absent, 2, 0, None),
                         PointingPolicy.from_settings(cleared, 2, 0, None))
        self.assertIsNone(PointingPolicy.from_settings(cleared, 2, 0, None).no_go)
        self.assertIsNotNone(PointingPolicy.from_settings(cleared, 2, 0, rectangle()).no_go)

    def test_factory_inert_then_binding_precedes_open(self):
        owner, native, driver = self.make(activated=False)
        self.assertEqual((native.opens, native.writes, self.bus.registrations), (0, [], []))
        native.on_open = lambda: self.assertEqual(driver._pointing_handle.binding, owner.policy.binding)
        owner.activate(deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(native.opens, 1)
        self.assertIsNone(driver._keepalive)
        self.assertEqual(len(self.bus.registrations), 16)

    def test_legacy_tle_handler_preserves_unbound_and_rejects_bound_messages(self):
        from ptu_control.utils import PtuID
        identity = PtuID(2, "PTCR20", 57600, False, 270, -270, "QPT130", "fixture", 7, False)
        original = object.__new__(manager_module.PtuManager)
        original.ptu_id = identity
        calls = []
        with patch.object(manager_module.PtuManager, "tle_load", return_value=(True, "ok")) as load:
            with patch.object(manager_module.PtuManager, "publish_wrapper", side_effect=lambda *a: calls.append(a)):
                original.tle_load_cmd_cb(pb.TleLoadCmd(tle_str=TLE).SerializeToString(), "")
                original.tle_load_cmd_cb(pb.TleLoadCmd(tle_str=TLE, pointing_binding=bytes(32)).SerializeToString(), "")
        load.assert_called_once_with(TLE)
        self.assertEqual(calls[0][0], Topics.TLE_LOAD_REPLY + "_2")

    def test_real_protobuf_selected_and_binding_ping_handshake(self):
        owner, native, unused = self.make()
        payload = pb.PingCmd(ping=True, pointing_binding=owner.policy.binding).SerializeToString()
        self.assertEqual(payload, b"\x08\x01\x12\x20" + owner.policy.binding)
        self.bus.deliver(Topics.PING_CMD + "_2", payload)
        reply = pb.PongResponse.FromString(self.bus.messages[-1][1])
        self.assertEqual((reply.pong, reply.pointing_binding), (2, owner.policy.binding))
        self.assertEqual(native.motion(), [])

    def test_wrong_manager_run_missing_binding_and_broadcast_have_no_motion(self):
        owner, native, unused = self.make()
        for topic, binding in ((Topics.PTU_POSITION_COMMAND + "_3", owner.policy.binding),
                               (Topics.PTU_POSITION_COMMAND + "_0", owner.policy.binding),
                               (Topics.PTU_POSITION_COMMAND + "_2", bytes(32)),
                               (Topics.PTU_POSITION_COMMAND + "_2", b"")):
            self.bus.deliver(topic, pb.PositionCommandMsg(azimuth=100, elevation=20,
                             pointing_binding=binding).SerializeToString())
        self.assertEqual(native.motion(), [])

    def test_encoded_quantization_counterexample_rejected_without_affected_write(self):
        owner, native, unused = self.make(rectangle())
        self.assertEqual(owner.policy.check_endpoint(289.96, 20), (289.96, 20))
        self.bus.deliver(Topics.PTU_POSITION_COMMAND + "_2",
            pb.PositionCommandMsg(azimuth=289.96, elevation=20,
                                   pointing_binding=owner.policy.binding).SerializeToString())
        self.assertEqual(native.motion(), [])
        self.assertEqual(owner.last_outcome[0], "endpoint_rejected")

    def test_literal_allowed_packet_same_encoder_bytes_are_submitted(self):
        owner, native, driver = self.make(rectangle())
        self.move(owner, 289.89, 20)
        # Pan -701 and tilt -700 in signed little-endian tenths, checksum 0x34.
        self.assertEqual(native.motion(), [bytes.fromhex("02 33 43 fd 44 fd 00 00 34 03")])
        self.assertEqual(owner.last_outcome, ("submitted", 1, "complete"))

    def test_all_inclusive_rectangle_edges_corners_and_interior_reject(self):
        points = ((310, 20), (290, 20), (330, 20), (310, 0), (310, 30),
                  (290, 0), (290, 30), (330, 0), (330, 30))
        for point in points:
            owner, native, unused = self.make(rectangle())
            with self.assertRaises(PointingError) as caught:
                self.move(owner, *point)
            self.assertEqual(caught.exception.primary, "endpoint_rejected")
            self.assertEqual(native.motion(), [])

    def test_immediate_boundary_neighbors_and_quantization(self):
        for point in ((289.999, 20), (310, 9.999), (290.001, 20), (329.999, 20), (310, 10.001), (310, 29.999)):
            owner, native, unused = self.make(rectangle(290, 330, 10, 30))
            with self.assertRaises(PointingError):
                self.move(owner, *point)
            self.assertEqual(native.motion(), [])
        for point in ((289.8, 20), (330.001, 20), (330.2, 20), (310, 9.8), (310, 30.001), (310, 30.2)):
            owner, native, unused = self.make(rectangle(290, 330, 10, 30))
            self.assertTrue(self.move(owner, *point))
            self.assertEqual(len(native.motion()), 1)

    def test_nonfinite_and_unsupported_context_do_not_open_or_send(self):
        for value in (math.nan, math.inf, -math.inf, True, 10**400):
            candidate = settings()
            candidate["positioners"][0]["pointing_context"]["pan_to_az"] = value
            with self.assertRaises(PointingError):
                self.make(configuration=candidate)
        self.assertEqual(self.owners, [])

    def test_policy_digest_binds_every_context_value_and_matches_numeric_values(self):
        base = PointingPolicy.from_settings(settings(), 2, 0, rectangle())
        changed = settings()
        changed["positioners"][0]["pointing_context"]["pan_to_az"] = 0.0
        self.assertEqual(base.binding, PointingPolicy.from_settings(changed, 2, 0.0, rectangle()).binding)
        for key, value in (("run_id", "02" * 32), ("calibration_generation", 2),
                           ("configuration_generation", 2), ("pan_to_az", 1), ("tilt_to_el", 89),
                           ("tle_sha256", "ab" * 32)):
            changed = settings()
            changed["positioners"][0]["pointing_context"][key] = value
            self.assertNotEqual(base.binding, PointingPolicy.from_settings(changed, 2, 0, rectangle()).binding)
        self.assertNotEqual(base.binding, PointingPolicy.from_settings(settings(), 2, 0, None).binding)

    def test_strict_rectangle_none_is_not_malformed_or_wrap_crossing(self):
        self.assertIsNone(PointingPolicy.from_settings(settings(), 2, 0, None).no_go)
        for zone in ({}, {"nogozones": []}, rectangle(350, 10), rectangle(-70, -30),
                     rectangle(290, 360), rectangle(290, 330, 30, 20), rectangle(290, 330, 0, math.nan)):
            with self.assertRaises(PointingError):
                PointingPolicy.from_settings(settings(), 2, 0, zone)

    def test_frozen_inputs_and_file_replacement_do_not_change_policy(self):
        data = settings()
        with tempfile.TemporaryDirectory(dir=os.environ["PTU_TEST_OUTPUT"]) as directory:
            path = Path(directory) / "no-go.json"
            path.write_text(json.dumps(rectangle()), encoding="utf-8")
            zone = json.loads(path.read_text(encoding="utf-8"))
            owner, native, unused = self.make(zone, data)
            digest = owner.policy.binding
            data["positioners"][0]["pointing_context"]["pan_to_az"] = 17
            zone["nogozones"][0].update(az_min=100, az_max=150)
            replacement = Path(directory) / "replacement.json"
            replacement.write_text(json.dumps(rectangle(100, 150)), encoding="utf-8")
            replacement.replace(path)
            with patch("builtins.open", side_effect=AssertionError("no strict policy reread")):
                with self.assertRaises(PointingError):
                    self.move(owner, 310, 20)
            self.assertEqual(owner.policy.binding, digest)
            self.assertEqual(owner.policy.pan_to_az, 0)
            self.assertEqual(owner.policy.no_go, (290., 330., 0., 30.))
            self.assertEqual(native.motion(), [])

    def test_calibration_wrapping_continuous_and_other_protocol(self):
        for protocol in (PTCR20(), PTCR96()):
            data = settings(type(protocol).__name__)
            data["positioners"][0]["pointing_context"]["pan_to_az"] = 10
            owner, native, unused = self.make(None, data, protocol=protocol)
            self.move(owner, -80, 20)
            counts = protocol.decode_move_to_packet(native.motion()[0])
            self.assertEqual(counts, (-900, -700, 10) if type(protocol) is PTCR20 else (-9000, -7000, 100))
        data = settings()
        data["positioners"][0].update(cont_rot=True, hard_pan_lim_cw=360, hard_pan_lim_ccw=0)
        owner, native, unused = self.make(rectangle(), data)
        with self.assertRaises(PointingError):
            self.move(owner, 330.04, 20)
        self.assertEqual(native.motion(), [])

    def test_actual_clipping_cannot_bypass_final_forbidden_endpoint(self):
        data = settings()
        data["positioners"][0]["pointing_context"]["tilt_to_el"] = 30
        owner, native, unused = self.make(rectangle(), data)
        self.assertEqual(owner.policy.check_endpoint(310, 40), (310, 40))
        with self.assertRaises(PointingError):
            self.move(owner, 310, 40)
        self.assertEqual(native.motion(), [])

    def test_prime_forbidden_initial_intermediate_prevalidated_before_first_move(self):
        owner, native, unused = self.make(rectangle())
        native.pan_units, native.tilt_units = -500, 0
        owner._observe(owner._driver.get_status_bounded(owner._handle, deadline=self.deadline, cancel=self.cancel)[1])
        self.orbit(owner)
        with self.assertRaises(PointingError):
            owner.prime_ptu(100, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1, deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(native.motion(), [])
        self.assertNotEqual(owner.ptu_state, "tle_primed")

    def test_actual_planner_forced_prime_intermediate_rejected(self):
        owner, native, unused = self.make(rectangle(210, 230))
        self.orbit(owner, clockwise=True)
        with self.assertRaises(PointingError):
            owner.prime_ptu(330, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1, deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(native.motion(), [])

    def test_finite_prime_sequence_uses_real_planner_transform_encoder_and_status(self):
        owner, native, unused = self.make()
        self.orbit(owner, clockwise=True)
        self.assertTrue(owner.prime_ptu(240, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1,
                                       deadline=self.deadline, cancel=self.cancel))
        coordinates = [native.proto.decode_move_to_packet(packet) for packet in native.motion()]
        self.assertEqual(coordinates, [(0, -700, 10), (800, -700, 10), (1600, -700, 10), (2400, -700, 10)])
        self.assertEqual(owner.ptu_state, "tle_primed")
        status = pb.PositionerStatus.FromString(self.bus.messages[-1][1])
        self.assertEqual((status.state, status.id, status.pointing_binding), ("tle_primed", 2, owner.policy.binding))

    def test_later_prime_failure_reports_previous_submission_and_never_primed(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        calls = []
        def fail_second(command):
            if command == 0x33:
                calls.append(command)
                if len(calls) == 2:
                    native.result = 2
        native.before_write = fail_second
        with self.assertRaises(PointingError) as caught:
            owner.prime_ptu(100, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1, deadline=self.deadline, cancel=self.cancel)
        self.assertEqual((caught.exception.submitted, caught.exception.submission), (1, "partial"))
        self.assertEqual(len(native.motion()), 2)
        self.assertEqual(owner.ptu_state, "failed")
        self.assertFalse(any(pb.PositionerStatus.FromString(body).state == "tle_primed"
                             for topic, body in self.bus.messages if topic == Topics.PTU_STATUS + "_2"))

    def test_context_invalidation_between_sequence_steps_stops_further_commands(self):
        owner, native, driver = self.make()
        self.orbit(owner)
        def invalidate(command):
            if command == 0x33:
                owner.invalidate(deadline=self.deadline, cancel=self.cancel)
        native.before_write = invalidate
        with self.assertRaises(PointingError):
            owner.prime_ptu(100, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1, deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(len(native.motion()), 1)
        self.assertNotEqual(owner.ptu_state, "tle_primed")
        with self.assertRaises(PointingError):
            self.move(owner)

    def test_changed_protocol_context_cannot_revive_after_restoration(self):
        owner, native, driver = self.make()
        driver.protocol._degree_factor = 100
        with self.assertRaises(PointingError):
            self.move(owner)
        driver.protocol._degree_factor = 10
        with self.assertRaises(PointingError):
            self.move(owner)
        self.assertEqual(native.motion(), [])

    def test_alternate_routes_reject_during_strict_ownership(self):
        owner, native, driver = self.make()
        for topic in (Topics.CALIBRATE_COMMAND, Topics.ABORT_COMMAND, Topics.PARK_COMMAND, Topics.ERROR_PROFILE_COMMAND):
            for suffix in ("_0", "_2"):
                self.bus.deliver(topic + suffix, b"\x08\x01")
        for name in ("calibrate", "park_ptu", "run", "move_to", "reset_motor_wrapper", "set_error_profile"):
            self.assertFalse(hasattr(owner, name))
        for call in (lambda: driver.move_to(0, 0), lambda: driver.jog(1, 0), driver.reset_motor_timeout):
            with self.assertRaises(Exception):
                call()
        self.assertEqual(native.motion(), [])

    def test_cancellation_deadline_and_wrong_manager_event_no_motion(self):
        owner, native, unused = self.make()
        with self.assertRaises(PointingError):
            owner.move_to_az_el(100, 20, binding=owner.policy.binding,
                               deadline=self.deadline, cancel=threading.Event())
        with self.assertRaises(PointingError) as caught:
            owner.move_to_az_el(100, 20, binding=owner.policy.binding,
                               deadline=time.monotonic(), cancel=self.cancel)
        self.assertEqual(caught.exception.primary, "deadline")
        self.cancel.set()
        with self.assertRaises(PointingError) as caught:
            self.move(owner)
        self.assertEqual(caught.exception.primary, "cancelled")
        self.assertEqual(native.motion(), [])

    def test_partial_subscription_failure_retains_exact_removal_debt(self):
        owner, native, unused = self.make(activated=False)
        self.bus.subscribe_error_at = 2
        with self.assertRaises(PointingError):
            owner.activate(deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(len(owner._registrations), 3)
        self.assertTrue(native.opened)
        owner.close(deadline=self.deadline)
        self.assertEqual(self.bus.registrations, [])
        self.assertFalse(native.opened)

    def test_cleanup_failure_retains_registrations_and_retry_releases(self):
        owner, native, unused = self.make()
        self.bus.cancel_error = True
        with self.assertRaises(PointingError):
            owner.close(deadline=self.deadline)
        self.assertEqual(len(owner._registrations), 16)
        self.assertFalse(native.opened)
        self.bus.cancel_error = False
        self.assertTrue(owner.close(deadline=self.deadline))
        self.assertTrue(owner.close(deadline=self.deadline))

    def test_endpoint_acceptance_does_not_evaluate_intervening_path(self):
        owner, native, unused = self.make(rectangle())
        self.move(owner, 280, 20)
        self.move(owner, 340, 20)
        self.assertEqual(len(native.motion()), 2)
        # The azimuth interval between these accepted endpoints crosses the rectangle.
        self.assertLess(280, 290)
        self.assertGreater(340, 330)


    def test_prime_post_submission_publish_failure_preserves_count(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        with patch.object(Messenger, "publish", side_effect=MessengerError("send")):
            with self.assertRaises(PointingError) as caught:
                owner.prime_ptu(100, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1, deadline=self.deadline, cancel=self.cancel)
        self.assertEqual((caught.exception.submitted, caught.exception.submission), (2, "none"))
        self.assertEqual(owner.last_outcome, ("serial_failure", 2, "none"))
        self.assertEqual(len(native.motion()), 2)
        self.assertEqual(owner.ptu_state, "failed")

    def test_callback_prime_post_submission_failure_keeps_count(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        with patch.object(Messenger, "publish", side_effect=MessengerError("send")):
            self.bus.deliver(Topics.TLE_PRIME_COMMAND + "_2", pb.TlePrimeCmd(
                prime=True, azimuth=100, elevation=20, pointing_binding=owner.policy.binding,
                prime_sender_id=b"M" * 16, prime_sequence=1).SerializeToString())
        self.assertEqual(owner.last_outcome[1], 2)
        self.assertEqual(len(native.motion()), 2)

    def test_final_response_cancellation_fails_with_submitted_count(self):
        owner, native, unused = self.make()
        original_read = native.read
        def read(count):
            response = original_read(count)
            if native.motion() and not native.response and response:
                self.cancel.set()
            return response
        native.read = read
        with self.assertRaises(PointingError) as caught:
            self.move(owner)
        self.assertEqual(caught.exception.primary, "cancelled")
        self.assertEqual((caught.exception.submitted, caught.exception.submission), (0, "complete"))
        self.assertEqual(len(native.motion()), 1)

    def test_final_observation_cancellation_is_not_direct_move_success(self):
        owner, native, unused = self.make()
        original_convert = manager_module.convert_from_ptu_frame
        def convert(*args, **kwargs):
            value = original_convert(*args, **kwargs)
            self.cancel.set()
            return value
        with patch.object(manager_module, "convert_from_ptu_frame", side_effect=convert):
            with self.assertRaises(PointingError) as caught:
                self.move(owner)
        self.assertEqual((caught.exception.primary, caught.exception.submitted,
                          caught.exception.submission), ("cancelled", 1, "none"))
        self.assertEqual(len(native.motion()), 1)

    def test_invalidation_validates_identity_and_controls_before_gating(self):
        owner, native, driver = self.make()
        for deadline, cancel in ((self.deadline, threading.Event()), (math.nan, self.cancel),
                                 (True, self.cancel), (time.monotonic(), self.cancel)):
            with self.assertRaises(PointingError):
                owner.invalidate(deadline=deadline, cancel=cancel)
        self.assertTrue(self.move(owner))
        self.assertEqual(len(native.motion()), 1)

    def test_invalidation_wait_cannot_extend_the_manager_run_budget(self):
        self.deadline = time.monotonic() + .15
        owner, native, driver = self.make()
        held, release = threading.Event(), threading.Event()
        def hold():
            with driver._lock:
                held.set()
                if not release.wait(2):
                    raise AssertionError("fixture release")
        worker = threading.Thread(target=hold)
        worker.start()
        try:
            self.assertTrue(held.wait(1))
            with self.assertRaises(Exception) as caught:
                owner.invalidate(deadline=self.deadline + 3, cancel=self.cancel)
            self.assertEqual(getattr(caught.exception, "primary", None), "deadline")
            self.assertLess(time.monotonic(), self.deadline + .5)
            self.assertEqual(native.motion(), [])
        finally:
            release.set()
            worker.join(2)
            self.assertFalse(worker.is_alive())

    def test_bound_driver_is_not_transferred_to_second_manager(self):
        owner, native, driver = self.make()
        with self.assertRaises(PointingError):
            manager_module.PtuManager.open_pointing(messenger=self.bus.messenger,
                settings=settings(), ptu_id=2, driver=driver, elevation_mask=0, no_go_data=None,
                run_deadline=self.deadline, cancel=self.cancel)
        self.assertTrue(native.opened)
        self.assertTrue(self.move(owner))

    def test_real_client_manager_serialization_and_actual_serial_endpoint_gate(self):
        from ptu_control.ptu_client import PtuClient
        configuration = settings()
        owner, native, unused = self.make(rectangle(), configuration)
        with tempfile.TemporaryDirectory(dir=os.environ["PTU_TEST_OUTPUT"]) as directory:
            client = PtuClient.open_pointing(messenger=self.bus.messenger, settings=configuration,
                ptu_id=2, elevation_mask=0, log_dir=Path(directory), no_go_data=rectangle(),
                deadline=self.deadline, cancel=self.cancel)
            try:
                self.assertTrue(client.check_connection(deadline=self.deadline, cancel=self.cancel))
                client.ptu_move_to(289.96, 20, deadline=self.deadline, cancel=self.cancel)
                self.assertEqual(native.motion(), [])
                self.assertEqual(owner.last_outcome[0], "endpoint_rejected")
                client.ptu_move_to(289.8, 20, deadline=self.deadline, cancel=self.cancel)
                self.assertEqual(len(native.motion()), 1)
            finally:
                client.close(deadline=time.monotonic() + 1)



    def test_legacy_constructor_keeps_broadcast_and_adds_selected_load_prime_routes(self):
        import json
        from ptu_control.utils import PtuID
        identity = PtuID(2, "PTCR20", 57600, False, 270, -270, "QPT130", "fixture", 7, False)
        driver = SimpleNamespace(open=lambda: None, connect_status_listener=lambda cb: None,
                                 close=lambda: None)
        with tempfile.TemporaryDirectory(dir=os.environ["PTU_TEST_OUTPUT"]) as directory:
            config = Path(directory) / "station.json"
            config.write_text(json.dumps({"ground_station_lat": 42, "ground_station_lon": -71,
                                          "ground_station_altm": 100}))
            with ExitStack() as stack:
                stack.enter_context(patch.object(manager_module.np, "array",
                    side_effect=lambda value: value if type(value) in (int, float) else list(value)))
                stack.enter_context(patch.object(manager_module, "interp1d", return_value=lambda value: 0))
                stack.enter_context(patch.object(manager_module.signal, "signal", return_value=None))
                legacy = manager_module.PtuManager(self.bus.messenger, config, identity, ptu=driver)
                try:
                    topics = [topic for topic, callback, identifier in self.bus.registrations]
                    self.assertEqual(len(topics), 15)
                    for name in (Topics.TLE_LOAD_COMMAND, Topics.TLE_PRIME_COMMAND):
                        self.assertIn(name + "_0", topics)
                        self.assertIn(name + "_2", topics)
                        self.assertNotIn(name + "_3", topics)
                    load = stack.enter_context(patch.object(legacy, "tle_load", return_value=(True, "ok")))
                    prime = stack.enter_context(patch.object(legacy, "prime_ptu"))
                    stack.enter_context(patch.object(legacy, "publish_wrapper"))
                    for suffix in ("_0", "_2", "_3"):
                        self.bus.deliver(Topics.TLE_LOAD_COMMAND + suffix, pb.TleLoadCmd(tle_str=TLE).SerializeToString())
                        self.bus.deliver(Topics.TLE_PRIME_COMMAND + suffix,
                                         pb.TlePrimeCmd(prime=True, azimuth=100, elevation=20).SerializeToString())
                    self.assertEqual(load.call_count, 2)
                    self.assertEqual(prime.call_count, 2)
                    self.assertEqual(prime.call_args.args, (100, 20))
                finally:
                    legacy.shutdown()
                    self.bus.registrations.clear()

    def test_first_prime_short_write_reports_uncertainty_without_false_success(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        native.result = 2
        with self.assertRaises(PointingError) as caught:
            owner.prime_ptu(100, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1, deadline=self.deadline, cancel=self.cancel)
        self.assertEqual((caught.exception.submitted, caught.exception.submission), (0, "partial"))
        self.assertEqual(len(native.motion()), 1)
        self.assertEqual(owner.ptu_state, "failed")

    def test_tracking_status_failure_counts_only_this_operation(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        owner.prime_ptu(100, 20, binding=owner.policy.binding, prime_sender_id=b"M" * 16, prime_sequence=1, deadline=self.deadline, cancel=self.cancel)
        previous = len(native.motion())
        self.assertEqual(previous, 2)
        with patch.object(Messenger, "publish", side_effect=MessengerError("send")):
            with self.assertRaises(PointingError) as caught:
                owner.track_once(datetime(2026, 9, 29, 12, tzinfo=timezone.utc),
                    binding=owner.policy.binding, deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(caught.exception.submitted, 1)
        self.assertEqual(owner.last_outcome[1], 1)
        self.assertEqual(len(native.motion()), previous + 1)
        self.assertEqual(owner.ptu_state, "failed")
        with self.assertRaises(PointingError):
            self.move(owner)


    def test_prime_requires_explicit_well_formed_correlation_before_work(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        for sender, sequence in ((b"", 1), (b"M" * 15, 1), (b"M" * 17, 1),
                                 ("M" * 16, 1), (bytearray(16), 1), (None, 1),
                                 (b"M" * 16, 0), (b"M" * 16, -1), (b"M" * 16, True),
                                 (b"M" * 16, 1.0), (b"M" * 16, 2**64)):
            with self.subTest(sender=type(sender).__name__, sequence=sequence):
                with self.assertRaises(PointingError) as caught:
                    owner.prime_ptu(100, 20, binding=owner.policy.binding,
                        prime_sender_id=sender, prime_sequence=sequence,
                        deadline=self.deadline, cancel=self.cancel)
                self.assertEqual(caught.exception.primary, "invalid_argument")
                self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (None, 0))
                self.assertEqual(native.motion(), [])
                self.assertEqual(self.bus.messages, [])
        with self.assertRaises(TypeError):
            owner.prime_ptu(100, 20, binding=owner.policy.binding,
                            deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(owner.ptu_state, "tle_loaded")
        self.assertEqual(native.motion(), [])

    def test_serialized_absent_or_malformed_prime_correlation_cannot_move(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        for sender, sequence in ((b"", 0), (b"M" * 16, 0), (b"", 1),
                                 (b"M" * 15, 1), (b"M" * 17, 1)):
            payload = pb.TlePrimeCmd(prime=True, azimuth=100, elevation=20,
                pointing_binding=owner.policy.binding, prime_sender_id=sender,
                prime_sequence=sequence).SerializeToString()
            self.bus.deliver(Topics.TLE_PRIME_COMMAND + "_2", payload)
            self.assertEqual(owner.last_outcome, ("invalid_argument", 0, "none"))
            self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (None, 0))
            self.assertEqual(native.motion(), [])
            self.assertEqual(self.bus.messages, [])
        self.assertEqual(owner.rejected, 5)

    def test_serialized_repeat_gap_and_replay_fence_echo_exact_request(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        for sequence in (1, 3):
            payload = pb.TlePrimeCmd(prime=True, azimuth=100, elevation=20,
                pointing_binding=owner.policy.binding, prime_sender_id=b"M" * 16,
                prime_sequence=sequence).SerializeToString()
            self.bus.deliver(Topics.TLE_PRIME_COMMAND + "_2", payload)
            status = pb.PositionerStatus.FromString(self.bus.messages[-1][1])
            self.assertEqual((status.state, status.prime_sender_id, status.prime_sequence),
                             ("tle_primed", b"M" * 16, sequence))
        self.assertEqual(len(native.motion()), 4)
        writes, messages = tuple(native.motion()), tuple(self.bus.messages)
        for sender, sequence in ((b"M" * 16, 3), (b"M" * 16, 1),
                                 (b"M" * 16, 2), (b"N" * 16, 4)):
            self.bus.deliver(Topics.TLE_PRIME_COMMAND + "_2",
                pb.TlePrimeCmd(prime=True, azimuth=120, elevation=20,
                    pointing_binding=owner.policy.binding, prime_sender_id=sender,
                    prime_sequence=sequence).SerializeToString())
            self.assertEqual(owner.last_outcome, ("policy_mismatch", 0, "none"))
            self.assertEqual(tuple(native.motion()), writes)
            self.assertEqual(tuple(self.bus.messages), messages)
            self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (b"M" * 16, 3))
        self.assertEqual(owner.ptu_state, "tle_primed")

    def test_rejected_endpoint_consumes_admitted_request_across_load_and_close(self):
        owner, native, unused = self.make(rectangle())
        self.orbit(owner)
        with self.assertRaises(PointingError) as caught:
            owner.prime_ptu(289.96, 20, binding=owner.policy.binding,
                prime_sender_id=b"M" * 16, prime_sequence=4,
                deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(caught.exception.primary, "endpoint_rejected")
        self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (b"M" * 16, 4))
        self.assertEqual(owner.ptu_state, "failed")
        self.assertEqual(native.motion(), [])
        self.assertEqual(self.bus.messages, [])
        owner.load_tle(TLE, binding=owner.policy.binding, deadline=self.deadline, cancel=self.cancel)
        for sender, sequence in ((b"M" * 16, 4), (b"N" * 16, 5)):
            with self.assertRaises(PointingError) as caught:
                owner.prime_ptu(100, 20, binding=owner.policy.binding,
                    prime_sender_id=sender, prime_sequence=sequence,
                    deadline=self.deadline, cancel=self.cancel)
            self.assertEqual(caught.exception.primary, "policy_mismatch")
        self.assertTrue(owner.prime_ptu(100, 20, binding=owner.policy.binding,
            prime_sender_id=b"M" * 16, prime_sequence=5,
            deadline=self.deadline, cancel=self.cancel))
        self.assertEqual(len(native.motion()), 2)
        owner.close(deadline=self.deadline)
        self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (b"M" * 16, 5))
        with self.assertRaises(PointingError):
            owner.activate(deadline=self.deadline, cancel=self.cancel)
        self.assertFalse(native.opened)
        self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (b"M" * 16, 5))

    def test_unadmitted_state_and_wrong_binding_do_not_claim_a_sender(self):
        owner, native, unused = self.make()
        with self.assertRaises(PointingError):
            owner.prime_ptu(100, 20, binding=owner.policy.binding,
                prime_sender_id=b"N" * 16, prime_sequence=7,
                deadline=self.deadline, cancel=self.cancel)
        self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (None, 0))
        self.orbit(owner)
        with self.assertRaises(PointingError) as caught:
            owner.prime_ptu(100, 20, binding=bytes(32),
                prime_sender_id=b"N" * 16, prime_sequence=7,
                deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(caught.exception.primary, "policy_mismatch")
        self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (None, 0))
        self.assertEqual(native.motion(), [])
        self.assertTrue(owner.prime_ptu(100, 20, binding=owner.policy.binding,
            prime_sender_id=b"M" * 16, prime_sequence=1,
            deadline=self.deadline, cancel=self.cancel))

    def test_cancelled_prime_admission_and_post_claim_cancellation_have_no_motion(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        with self.assertRaises(PointingError) as caught:
            owner.prime_ptu(100, 20, binding=owner.policy.binding,
                prime_sender_id=b"M" * 16, prime_sequence=1,
                deadline=time.monotonic(), cancel=self.cancel)
        self.assertEqual(caught.exception.primary, "deadline")
        self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (None, 0))
        def cancel_plan(*args, **kwargs):
            self.cancel.set()
            return planned_pass()
        with patch.object(manager_module, "find_closest_pass", side_effect=cancel_plan):
            with self.assertRaises(PointingError) as caught:
                owner.prime_ptu(100, 20, binding=owner.policy.binding,
                    prime_sender_id=b"M" * 16, prime_sequence=1,
                    deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(caught.exception.primary, "cancelled")
        self.assertEqual((owner._prime_sender_id, owner._prime_sequence), (b"M" * 16, 1))
        self.assertEqual(owner.ptu_state, "failed")
        self.assertEqual(native.motion(), [])
        self.assertEqual(self.bus.messages, [])
        with self.assertRaises(PointingError) as caught:
            owner.prime_ptu(100, 20, binding=owner.policy.binding,
                prime_sender_id=b"M" * 16, prime_sequence=2,
                deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(caught.exception.primary, "cancelled")
        self.assertEqual(owner._prime_sequence, 1)

    def test_prime_uint64_maximum_has_no_wrap_or_reset(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        maximum = 2**64 - 1
        self.assertTrue(owner.prime_ptu(100, 20, binding=owner.policy.binding,
            prime_sender_id=b"M" * 16, prime_sequence=maximum,
            deadline=self.deadline, cancel=self.cancel))
        status = pb.PositionerStatus.FromString(self.bus.messages[-1][1])
        self.assertEqual(status.prime_sequence, maximum)
        for sequence in (maximum, 1, maximum + 1, 0):
            with self.assertRaises(PointingError):
                owner.prime_ptu(100, 20, binding=owner.policy.binding,
                    prime_sender_id=b"M" * 16, prime_sequence=sequence,
                    deadline=self.deadline, cancel=self.cancel)
        self.assertEqual(len(native.motion()), 2)
        self.assertEqual(owner._prime_sequence, maximum)

    def test_tracking_status_retains_successfully_admitted_prime_correlation(self):
        owner, native, unused = self.make()
        self.orbit(owner)
        owner.prime_ptu(100, 20, binding=owner.policy.binding,
            prime_sender_id=b"M" * 16, prime_sequence=8,
            deadline=self.deadline, cancel=self.cancel)
        owner.track_once(datetime(2026, 9, 29, 12, tzinfo=timezone.utc),
            binding=owner.policy.binding, deadline=self.deadline, cancel=self.cancel)
        status = pb.PositionerStatus.FromString(self.bus.messages[-1][1])
        self.assertEqual((status.state, status.prime_sender_id, status.prime_sequence),
                         ("tle_tracking", b"M" * 16, 8))
        self.assertEqual(len(native.motion()), 3)

    def test_correlation_fields_have_literal_additive_wire_and_legacy_defaults(self):
        legacy = pb.TlePrimeCmd(prime=True, azimuth=100, elevation=20)
        self.assertEqual(legacy.SerializeToString(), bytes.fromhex("0801150000c8421d0000a041"))
        strict = pb.TlePrimeCmd(prime=True, azimuth=100, elevation=20,
            pointing_binding=b"B" * 32, prime_sender_id=b"M" * 16, prime_sequence=1)
        self.assertEqual(strict.SerializeToString(),
            bytes.fromhex("0801150000c8421d0000a0412220") + b"B" * 32
            + bytes.fromhex("2a10") + b"M" * 16 + bytes.fromhex("3001"))
        self.assertEqual(pb.PositionerStatus(prime_sender_id=b"M" * 16,
            prime_sequence=1).SerializeToString(), bytes.fromhex("6210") + b"M" * 16 + b"\x68\x01")
        self.assertEqual(pb.PositionerStatus().SerializeToString(), b"")

    def test_v2_canonical_binding_fences_prior_strict_peer_messages(self):
        from ptu_control.ptu_client import PtuClient, PtuError
        record = dict(version="ptu-pointing-binding.v1", frame="azimuth-elevation-degrees.v1",
            manager_id=2, run_id="01" * 32, configuration_generation=1,
            calibration_generation=1, protocol="PTCR20", protocol_address=None,
            continuous_rotation=False, hard_pan_limit_cw="270/1", hard_pan_limit_ccw="-270/1",
            pan_to_az="0/1", tilt_to_el="90/1", elevation_mask="0/1", no_go=None,
            tle_sha256=hashlib.sha256(TLE.encode("ascii")).hexdigest())
        def digest():
            return hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":"),
                                               ensure_ascii=True).encode("ascii")).digest()
        old_binding = digest()
        record["version"] = "ptu-pointing-binding.v2"
        new_binding = digest()
        configuration = settings()
        owner, native, unused = self.make(configuration=configuration)
        self.assertEqual(owner.policy.binding, new_binding)
        self.assertNotEqual(old_binding, new_binding)
        self.bus.deliver(Topics.PING_CMD + "_2",
            pb.PingCmd(ping=True, pointing_binding=old_binding).SerializeToString())
        self.assertEqual(self.bus.messages, [])
        self.assertEqual(owner.last_outcome, ("policy_mismatch", 0, "none"))
        with tempfile.TemporaryDirectory(dir=os.environ["PTU_TEST_OUTPUT"]) as directory:
            client = PtuClient.open_pointing(messenger=self.bus.messenger, settings=configuration,
                ptu_id=2, elevation_mask=0, log_dir=Path(directory), no_go_data=None,
                deadline=self.deadline, cancel=self.cancel)
            try:
                def old_reply(topic, data, **controls):
                    command = pb.PingCmd.FromString(data)
                    self.assertEqual(command.pointing_binding, new_binding)
                    self.bus.deliver(Topics.PONG_RESPONSE + "_2",
                        pb.PongResponse(pong=2, pointing_binding=old_binding).SerializeToString())
                with patch.object(Messenger, "publish", side_effect=old_reply):
                    with self.assertRaises(PtuError) as caught:
                        client.check_connection(deadline=time.monotonic() + .05, cancel=self.cancel)
                self.assertEqual(caught.exception.primary, "deadline")
                self.assertFalse(client.connection_status[2])
            finally:
                client.close(deadline=time.monotonic() + 1)
        self.assertEqual(native.motion(), [])


if __name__ == "__main__":
    unittest.main()
