"""Strict client boundary tests: real frozen policy and generated protobuf.

Public Messenger methods are substituted in unit cases. Integration cases use
the actual owner/lower with controlled socket/TLS/readiness primitives. Nothing
here substitutes a serial endpoint check or qualifies physical motion.
"""
import hashlib
import os
import tempfile
import threading
import time
import unittest
from contextlib import ExitStack
from pathlib import Path
from types import MappingProxyType
from unittest import mock

from meteor_api.messenger import Messenger, MessengerError
from ptu_control import ptu_client as client_module
from ptu_control import ptu_msg_pb2 as pb
from ptu_control.constants import Topics
from ptu_control.pointing import PointingError, PointingPolicy


TLE = 'FIXTURE,line-one,line-two'
NO_GO = {'nogozones': [{'az_min': 290, 'az_max': 330, 'el_min': 0, 'el_max': 30}]}


def station():
    return {'positioners': [{
        'id': 2, 'protocol': 'PTCR20', 'cont_rot': False,
        'hard_pan_lim_cw': 270, 'hard_pan_lim_ccw': -270,
        'pointing_context': {
            'frame': 'azimuth-elevation-degrees.v1', 'run_id': '01' * 32,
            'configuration_generation': 1, 'calibration_generation': 1,
            'pan_to_az': 0, 'tilt_to_el': 90, 'protocol_address': None,
            'tle_sha256': hashlib.sha256(TLE.encode('ascii')).hexdigest(),
        },
    }]}


class PublicMessengerScript:
    def __init__(self):
        self.instance = object.__new__(Messenger)
        self.calls = []
        self.registrations = []
        self.binding = None
        self.reply_binding = None
        self.reply_id = 2
        self.load_success = True
        self.status_on_prime = True
        self.prime_requests = []
        self.before_return = None
        self.subscribe_error = None
        self.cancel_error = None

    def subscribe(self, topic, callback, identifier, **controls):
        self.calls.append(('subscribe', topic, callback, identifier, controls))
        if self.subscribe_error is not None:
            self.subscribe_error(topic)
        self.registrations.append((topic, callback, identifier))

    def cancel(self, topic, callback, identifier, **controls):
        self.calls.append(('cancel', topic, callback, identifier, controls))
        if self.cancel_error is not None:
            raise self.cancel_error
        registration = (topic, callback, identifier)
        if registration not in self.registrations:
            raise MessengerError('admission')
        self.registrations.remove(registration)

    def deliver(self, topic, body):
        for name, callback, identifier in tuple(self.registrations):
            if name == topic:
                callback(body, identifier)

    def publish(self, topic, payload, **controls):
        self.calls.append(('publish', topic, payload, controls))
        if type(payload) is not bytes:
            raise AssertionError('strict protobuf must be serialized')
        binding = self.binding if self.reply_binding is None else self.reply_binding
        if topic == Topics.PING_CMD + '_2':
            request = pb.PingCmd()
            request.ParseFromString(payload)
            if request.pointing_binding != self.binding or not request.ping:
                raise AssertionError('invalid ping binding')
            if self.reply_id is not None:
                self.deliver(Topics.PONG_RESPONSE + '_2',
                    pb.PongResponse(pong=self.reply_id, pointing_binding=binding).SerializeToString())
        elif topic == Topics.TLE_LOAD_COMMAND + '_2':
            request = pb.TleLoadCmd()
            request.ParseFromString(payload)
            if request.pointing_binding != self.binding or request.tle_str != TLE:
                raise AssertionError('invalid TLE request')
            if self.load_success is not None:
                self.deliver(Topics.TLE_LOAD_REPLY + '_2',
                    pb.TleReplyMsg(success=self.load_success, ptu_id=self.reply_id,
                        pointing_binding=binding, msg='controlled').SerializeToString())
        elif topic == Topics.TLE_PRIME_COMMAND + '_2':
            request = pb.TlePrimeCmd()
            request.ParseFromString(payload)
            if (request.pointing_binding != self.binding or not request.prime
                    or len(request.prime_sender_id) != 16 or request.prime_sequence == 0):
                raise AssertionError('invalid prime request')
            self.prime_requests.append((request.prime_sender_id, request.prime_sequence))
            if self.status_on_prime:
                self.deliver(Topics.PTU_STATUS + '_2',
                    pb.PositionerStatus(id=self.reply_id, pointing_binding=binding,
                        state='tle_primed', azimuth=request.azimuth,
                        elevation=request.elevation, prime_sender_id=request.prime_sender_id,
                        prime_sequence=request.prime_sequence).SerializeToString())
        elif topic == Topics.PTU_POSITION_COMMAND + '_2':
            request = pb.PositionCommandMsg()
            request.ParseFromString(payload)
            if request.pointing_binding != self.binding:
                raise AssertionError('invalid direct binding')
        else:
            raise AssertionError('unexpected or broadcast topic')
        if self.before_return is not None:
            self.before_return(topic)

    def install(self, stack):
        stack.enter_context(mock.patch.object(Messenger, 'strict_instance_compatible', return_value=True))
        stack.enter_context(mock.patch.object(Messenger, 'subscribe', side_effect=self.subscribe))
        stack.enter_context(mock.patch.object(Messenger, 'cancelSubscribe', side_effect=self.cancel))
        stack.enter_context(mock.patch.object(Messenger, 'publish', side_effect=self.publish))
        stack.enter_context(mock.patch.object(Messenger, 'close',
            side_effect=AssertionError('borrowed owner closure')))


class PtuPointingTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(
            prefix='ptu-client-', dir=os.environ['PTU_TEST_OUTPUT'])
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.script = PublicMessengerScript()
        self.script.install(self.stack)
        self.entropy = self.stack.enter_context(mock.patch.object(
            client_module.os, 'urandom', return_value=b's' * 16))
        self.clients = []
        self.addCleanup(self.cleanup_clients)

    def cleanup_clients(self):
        self.script.cancel_error = self.script.subscribe_error = None
        for client in self.clients:
            client.close(deadline=time.monotonic() + 1)

    def controls(self, seconds=1):
        return dict(deadline=time.monotonic() + seconds, cancel=threading.Event())

    def opened(self, **changes):
        values = dict(messenger=self.script.instance, settings=station(), ptu_id=2,
                      elevation_mask=0, log_dir=self.root, no_go_data=NO_GO,
                      **self.controls())
        values.update(changes)
        client = client_module.PtuClient.open_pointing(**values)
        self.clients.append(client)
        self.script.binding = client._policy.binding
        return client

    def connected(self):
        client = self.opened()
        self.assertIs(client.check_connection(**self.controls()), True)
        return client

    def loaded(self):
        client = self.connected()
        self.assertIs(client.load_tle(TLE, **self.controls()), True)
        return client

    def published(self):
        return [call for call in self.script.calls if call[0] == 'publish']

    def status(self, **changes):
        sender, sequence = self.script.prime_requests[-1] if self.script.prime_requests else (b'', 0)
        values = dict(id=2, pointing_binding=self.script.binding, state='tle_primed',
                      azimuth=100, elevation=45, prime_sender_id=sender, prime_sequence=sequence)
        values.update(changes)
        return pb.PositionerStatus(**values).SerializeToString()

    def test_legacy_constructor_selection_and_coordinate_range_remain_distinct(self):
        source = '{"positioners": [{"id": 2}, {"id": 3}]}'
        with mock.patch.object(client_module, 'open', create=True,
                               new=mock.mock_open(read_data=source)):
            client = client_module.PtuClient(self.script.instance, Path('/unused'), elevation_mask=5)
        self.assertIs(type(client), client_module.PtuClient)
        self.assertEqual(client.ptu_ids, [2, 3])
        self.assertEqual(len(self.script.registrations), 10)
        self.assertTrue(all(call[-1] == {} for call in self.script.calls))
        self.assertTrue(client.validateCoordinates(310, 170))
        client.start_logging()
        self.assertTrue(client.is_logging)
        client.stop_logging()
        self.assertFalse(client.is_logging)
        self.script.registrations.clear()

    def test_factory_inert_real_policy_and_selected_local_state(self):
        before = tuple(threading.enumerate())
        with mock.patch.object(client_module, 'open', create=True,
                               side_effect=AssertionError('factory file access')):
            client = self.opened()
        self.assertEqual(self.script.calls, [])
        self.assertEqual(tuple(self.root.iterdir()), ())
        self.assertEqual(tuple(threading.enumerate()), before)
        self.assertIsInstance(client._policy, PointingPolicy)
        self.assertEqual(client.ptu_ids, (2,))
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertEqual(client.tle_load_success, {2: False})
        self.assertFalse(hasattr(client, 'config'))
        self.assertEqual(len(client._policy.binding), 32)

    def test_frozen_policy_does_not_follow_mutated_input(self):
        settings = station()
        no_go = {'nogozones': [dict(NO_GO['nogozones'][0])]}
        client = self.opened(settings=settings, no_go_data=no_go)
        original = client._policy.binding
        settings['positioners'][0]['pointing_context']['run_id'] = '02' * 32
        no_go['nogozones'][0]['az_min'] = 100
        self.assertEqual(client._policy.binding, original)
        self.assertFalse(client.validateCoordinates(310, 20))
        self.assertTrue(client.validateCoordinates(110, 20))

    def test_invalid_binding_context_and_selected_identity_rejected_without_effects(self):
        for changes in ({'ptu_id': True}, {'ptu_id': 0}, {'ptu_id': 3},
                        {'settings': {'positioners': [{'id': 2}]}},
                        {'no_go_data': {}}, {'elevation_mask': float('nan')}):
            with self.subTest(keys=tuple(changes)):
                with self.assertRaises(PointingError):
                    self.opened(**changes)
        self.assertEqual(self.script.calls, [])

    def test_unconsumed_no_go_path_rejects_before_any_factory_effect(self):
        frozen = MappingProxyType({'nogozones': (
            MappingProxyType(dict(NO_GO['nogozones'][0])),)})
        unresolved = ('/unresolved/no-go.yaml', Path('/unresolved/no-go.yaml'),
                      '', False, 0, [])
        with mock.patch('builtins.open', side_effect=AssertionError('strict file reread')), \
             mock.patch.object(Messenger, 'close') as borrowed_close:
            for path in unresolved:
                for no_go in (None, frozen):
                    settings = station()
                    settings['positioners'][0]['no_go_config'] = path
                    with self.subTest(path_type=type(path).__name__, inline=no_go is not None):
                        with self.assertRaises(PointingError) as caught:
                            self.opened(settings=settings, no_go_data=no_go)
                        self.assertEqual(caught.exception.primary, 'invalid_argument')
            borrowed_close.assert_not_called()
        self.assertEqual(self.script.calls, [])
        self.assertEqual(self.script.registrations, [])
        self.assertEqual(self.clients, [])

    def test_invalid_exact_controls_paths_and_messenger_reject(self):
        for changes in ({'deadline': True}, {'deadline': float('inf')},
                        {'deadline': 10 ** 400}, {'cancel': object()},
                        {'log_dir': 'path'}, {'log_dir': Path('relative')},
                        {'messenger': object()}):
            with self.subTest(keys=tuple(changes)):
                with self.assertRaises(client_module.PtuError) as caught:
                    self.opened(**changes)
                self.assertEqual(caught.exception.primary, 'admission')
        self.assertEqual(self.script.calls, [])

    def test_equality_deadline_cancel_and_contention_never_renew_budget(self):
        client = self.opened()
        with mock.patch.object(client_module.time, 'monotonic', return_value=50):
            for deadline in (49, 50):
                with self.assertRaises(client_module.PtuError) as caught:
                    client.check_connection(deadline=deadline, cancel=threading.Event())
                self.assertEqual(caught.exception.primary, 'deadline')
        controls = self.controls()
        controls['cancel'].set()
        with self.assertRaises(client_module.PtuError) as caught:
            client.check_connection(**controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        client._operation.acquire()
        try:
            with self.assertRaises(client_module.PtuError) as caught:
                client.check_connection(**self.controls(.02))
            self.assertEqual(caught.exception.primary, 'deadline')
        finally:
            client._operation.release()
        self.assertEqual(self.script.calls, [])

    def test_synchronous_bound_pong_uses_exact_selected_topics_and_controls(self):
        client = self.opened()
        controls = self.controls()
        self.assertIs(client.check_connection(**controls), True)
        self.assertEqual([call[1] for call in self.script.calls],
            [Topics.PONG_RESPONSE + '_2', Topics.TLE_LOAD_REPLY + '_2',
             Topics.PTU_STATUS + '_2', Topics.PING_CMD + '_2'])
        for call in self.script.calls:
            self.assertEqual(call[-1]['deadline'], controls['deadline'])
            self.assertIs(call[-1]['cancel'], controls['cancel'])

    def test_old_manager_wrong_id_and_other_binding_pongs_cannot_qualify(self):
        client = self.opened()
        for identity, binding in ((3, None), (2, b''), (2, b'x' * 32)):
            self.script.reply_id, self.script.reply_binding = identity, binding
            with self.subTest(identity=identity, binding_length=len(binding or b'')):
                with self.assertRaises(client_module.PtuError) as caught:
                    client.check_connection(**self.controls(.02))
                self.assertEqual(caught.exception.primary, 'deadline')
                self.assertEqual(client.connection_status, {2: False})
        self.assertEqual(len(self.script.registrations), 3)

    def test_tle_requires_matching_digest_and_unchanged_bounded_ascii(self):
        client = self.connected()
        count = len(self.published())
        for text in ('other,line-one,line-two', 'only-two,parts', TLE + '\n',
                     TLE + '\u00e9', 'x' * 4097, b'bytes'):
            with self.subTest(kind=type(text).__name__):
                with self.assertRaises(PointingError):
                    client.load_tle(text, **self.controls())
        self.assertEqual(len(self.published()), count)
        self.assertIs(client.load_tle(TLE, **self.controls()), True)
        request = pb.TleLoadCmd()
        request.ParseFromString(self.published()[-1][2])
        self.assertEqual(request.tle_str, TLE)
        self.assertEqual(request.pointing_binding, client._policy.binding)
        self.assertEqual(client.tle_load_success, {2: True})

    def test_delayed_and_wrong_binding_tle_reply_never_reuses_loaded_success(self):
        client = self.connected()
        self.script.deliver(Topics.TLE_LOAD_REPLY + '_2',
            pb.TleReplyMsg(ptu_id=2, success=True,
                          pointing_binding=client._policy.binding).SerializeToString())
        self.assertFalse(client._loaded)
        client.load_tle(TLE, **self.controls())
        self.script.reply_binding = b'x' * 32
        with self.assertRaises(client_module.PtuError) as caught:
            client.load_tle(TLE, **self.controls(.02))
        self.assertEqual(caught.exception.primary, 'deadline')
        self.assertEqual(client.tle_load_success, {2: False})

    def test_negative_tle_reply_is_explicit_without_raw_reply_logging(self):
        client = self.connected()
        self.script.load_success = False
        with self.assertRaises(client_module.PtuError) as caught:
            client.load_tle(TLE, **self.controls())
        self.assertEqual(str(caught.exception), 'rejected')
        self.assertFalse(client._loaded)
        self.assertEqual(client.tle_load_success, {2: False})

    def test_inclusive_rectangle_edges_corners_and_wrapped_equivalents_reject(self):
        client = self.loaded()
        count = len(self.published())
        endpoints = ((290, 0), (330, 0), (290, 30), (330, 30),
                     (290, 15), (330, 15), (310, 0), (310, 30), (310, 20),
                     (-70, 15), (690, 15), (100, -1), (100, 91))
        for azimuth, elevation in endpoints:
            self.assertFalse(client.validateCoordinates(azimuth, elevation))
            for operation in (client.prime, client.ptu_move_to, client.ptu_send_position):
                with self.subTest(target=(azimuth, elevation), operation=operation.__name__):
                    with self.assertRaises(PointingError) as caught:
                        operation(azimuth, elevation, **self.controls())
                    self.assertEqual(caught.exception.primary, 'endpoint_rejected')
        self.assertEqual(len(self.published()), count)
        self.assertEqual(client.ptu_is_primed, {2: False})

    def test_binary32_rounding_onto_forbidden_endpoint_rejects_before_publish(self):
        client = self.loaded()
        count = len(self.published())
        for azimuth, elevation in ((289.9999999, 20), (330.0000001, 20), (310, 30.0000001)):
            self.assertTrue(client._policy.check_endpoint(azimuth, elevation))
            self.assertFalse(client.validateCoordinates(azimuth, elevation))
            for operation in (client.prime, client.ptu_move_to, client.ptu_send_position):
                with self.subTest(operation=operation.__name__, target=(azimuth, elevation)):
                    with self.assertRaises(PointingError):
                        operation(azimuth, elevation, **self.controls())
        self.assertEqual(len(self.published()), count)

    def test_invalid_numeric_inputs_are_pure_rejection_not_coercion(self):
        client = self.connected()
        for azimuth, elevation in ((True, 20), ('10', 20), (float('nan'), 20),
                                    (20, float('inf')), (10 ** 400, 20)):
            with self.subTest(azimuth_type=type(azimuth).__name__):
                self.assertFalse(client.validateCoordinates(azimuth, elevation))
                with self.assertRaises(PointingError):
                    client.ptu_send_position(azimuth, elevation, **self.controls())

    def test_selected_direct_routes_and_force_flags_preserve_checked_wire(self):
        client = self.connected()
        for operation, options in ((client.ptu_move_to, {'force_cw': True}),
                                   (client.ptu_send_position, {'force_ccw': True, 'ptu_id': 2})):
            represented = operation(-260, 45, **options, **self.controls())
            call = self.published()[-1]
            self.assertEqual(call[1], Topics.PTU_POSITION_COMMAND + '_2')
            self.assertEqual(call[-1]['priority'], 9)
            message = pb.PositionCommandMsg()
            message.ParseFromString(call[2])
            self.assertEqual((message.azimuth, message.elevation), represented)
            self.assertEqual(represented, (100, 45))
            self.assertEqual(message.pointing_binding, client._policy.binding)
            self.assertEqual(message.force_cw, options.get('force_cw', False))
            self.assertEqual(message.force_ccw, options.get('force_ccw', False))

    def test_broadcast_other_id_and_ambiguous_forces_reject(self):
        client = self.connected()
        count = len(self.published())
        for identity in (0, 3, True):
            with self.assertRaises(client_module.PtuError):
                client.ptu_move_to(100, 45, ptu_id=identity, **self.controls())
        for options in ({'force_cw': 1}, {'force_ccw': 'false'},
                        {'force_cw': True, 'force_ccw': True}):
            with self.assertRaises(PointingError):
                client.ptu_send_position(100, 45, **options, **self.controls())
        self.assertEqual(len(self.published()), count)

    def test_client_does_not_claim_final_serial_quantization_enforcement(self):
        client = self.connected()
        self.assertTrue(client.validateCoordinates(289.96, 20))
        represented = client.ptu_move_to(289.96, 20, **self.controls())
        self.assertLess(represented[0], 290)
        self.assertEqual(self.published()[-1][1], Topics.PTU_POSITION_COMMAND + '_2')
        # The separately tested manager/driver must reject its actual encoded 290-degree endpoint.

    def test_prime_requires_load_and_bound_status_not_submission_alone(self):
        client = self.connected()
        with self.assertRaises(client_module.PtuError) as caught:
            client.prime(100, 45, **self.controls())
        self.assertEqual(caught.exception.primary, 'state')
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: False})
        client.load_tle(TLE, **self.controls())
        self.script.status_on_prime = False
        self.assertIs(client.prime(100, 45, **self.controls()), True)
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: True})
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status(state='free'))
        self.assertEqual(client.ptu_is_primed, {2: False})

    def test_synchronous_prime_status_is_provisional_until_local_publish_success(self):
        client = self.loaded()
        observed = []
        self.script.before_return = lambda topic: observed.append(dict(client.ptu_is_primed))
        self.assertIs(client.prime(100, 45, **self.controls()), True)
        self.assertEqual(observed, [{2: False}])
        self.assertEqual(client.ptu_is_primed, {2: True})

    def test_cancel_after_provisional_status_clears_readiness_without_compensation(self):
        client = self.loaded()
        controls = self.controls()
        self.script.before_return = lambda topic: controls['cancel'].set()
        count = len(self.published())
        with self.assertRaises(client_module.PtuError) as caught:
            client.prime(100, 45, **controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertEqual(len(self.published()), count + 1)
        self.assertEqual(self.published()[-1][1], Topics.TLE_PRIME_COMMAND + '_2')

    def test_publish_failure_propagates_and_does_not_mark_primed(self):
        client = self.loaded()
        failure = MessengerError('send')
        with mock.patch.object(Messenger, 'publish', side_effect=failure):
            with self.assertRaises(MessengerError) as caught:
                client.prime(100, 45, **self.controls())
        self.assertIs(caught.exception, failure)
        self.assertEqual(client.ptu_is_primed, {2: False})

    def test_status_rejects_malformed_wrong_id_binding_oversize_and_nonfinite(self):
        client = self.loaded()
        self.script.status_on_prime = False
        client.prime(100, 45, **self.controls())
        bad = (b'\x80', b'x' * 8193, bytearray(self.status()), self.status(id=3),
               self.status(pointing_binding=b''), self.status(pointing_binding=b'x' * 32),
               self.status(pan=float('nan')), self.status(state='x' * 33))
        for body in bad:
            self.script.deliver(Topics.PTU_STATUS + '_2', body)
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertEqual(client.ptu_status, {})
        self.assertEqual(client.diagnostics()['rejected_messages'], len(bad))

    def test_callback_contention_is_nonblocking_and_never_sets_readiness(self):
        client = self.loaded()
        self.script.status_on_prime = False
        client.prime(100, 45, **self.controls())
        client._state.acquire()
        try:
            self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        finally:
            client._state.release()
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertEqual(client.diagnostics()['rejected_messages'], 1)

    def test_sender_entropy_is_controlled_once_per_owner_before_any_effect(self):
        self.entropy.side_effect = (b'a' * 16, b'b' * 16)
        first, second = self.opened(), self.opened()
        self.assertEqual(self.entropy.call_args_list, [mock.call(16), mock.call(16)])
        self.assertEqual((first._prime_sender_id, second._prime_sender_id), (b'a' * 16, b'b' * 16))
        self.assertEqual((first._prime_sequence, second._prime_sequence), (0, 0))
        self.assertEqual(self.script.calls, [])

    def test_sender_entropy_failure_or_nonexact_result_rejects_without_return(self):
        for value in (None, b'', b'x' * 15, b'x' * 17, bytearray(b'x' * 16)):
            self.entropy.return_value = value
            with self.subTest(result_type=type(value).__name__):
                with self.assertRaises(client_module.PtuError) as caught:
                    self.opened()
                self.assertEqual(caught.exception.primary, 'admission')
        self.entropy.side_effect = OSError('controlled entropy failure')
        with self.assertRaises(client_module.PtuError) as caught:
            self.opened()
        self.assertEqual(str(caught.exception), 'admission')
        self.assertEqual(self.clients, [])
        self.assertEqual(self.script.calls, [])

    def test_sender_entropy_checks_cancellation_and_deadline_before_and_after(self):
        controls = self.controls()
        controls['cancel'].set()
        with self.assertRaises(client_module.PtuError):
            self.opened(**controls)
        self.entropy.assert_not_called()
        controls = self.controls()
        def cancelled(size):
            controls['cancel'].set()
            return b'c' * size
        self.entropy.side_effect = cancelled
        with self.assertRaises(client_module.PtuError) as caught:
            self.opened(**controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        now = [10]
        def late(size):
            now[0] = 11
            return b'd' * size
        self.entropy.side_effect = late
        with mock.patch.object(client_module.time, 'monotonic', side_effect=lambda: now[0]):
            with self.assertRaises(client_module.PtuError) as caught:
                self.opened(deadline=11)
        self.assertEqual(caught.exception.primary, 'deadline')
        self.assertEqual(self.clients, [])
        self.assertEqual(self.script.calls, [])

    def test_identical_repeat_primes_correlate_and_delayed_old_ready_cannot_revive(self):
        client = self.loaded()
        client.prime(100, 45, **self.controls())
        old_ready = self.status()
        old_free = self.status(state='free')
        self.assertEqual(client.ptu_is_primed, {2: True})
        self.script.status_on_prime = False
        client.prime(100, 45, **self.controls())
        self.assertEqual([pair[1] for pair in self.script.prime_requests], [1, 2])
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.script.deliver(Topics.PTU_STATUS + '_2', old_ready)
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: True})
        self.script.deliver(Topics.PTU_STATUS + '_2', old_free)
        self.assertEqual(client.ptu_is_primed, {2: True})

    def test_rejected_endpoint_clears_readiness_and_consumes_unsent_sequence(self):
        client = self.loaded()
        client.prime(100, 45, **self.controls())
        old_ready = self.status()
        with self.assertRaises(PointingError):
            client.prime(310, 20, **self.controls())
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertIsNone(client._expected_prime)
        self.assertEqual(client._prime_sequence, 2)
        self.script.deliver(Topics.PTU_STATUS + '_2', old_ready)
        self.assertEqual(client.ptu_is_primed, {2: False})
        client.prime(100, 45, **self.controls())
        self.assertEqual([pair[1] for pair in self.script.prime_requests], [1, 3])
        self.assertEqual(client.ptu_is_primed, {2: True})

    def test_missing_load_consumes_sequence_before_later_state_validation(self):
        client = self.connected()
        with self.assertRaises(client_module.PtuError) as caught:
            client.prime(100, 45, **self.controls())
        self.assertEqual(caught.exception.primary, 'state')
        self.assertEqual(client._prime_sequence, 1)
        self.assertIsNone(client._expected_prime)
        self.assertEqual(self.script.prime_requests, [])
        client.load_tle(TLE, **self.controls())
        client.prime(100, 45, **self.controls())
        self.assertEqual(self.script.prime_requests, [(b's' * 16, 2)])

    def test_failed_send_consumes_sequence_and_cannot_accept_its_delayed_status(self):
        client = self.loaded()
        with mock.patch.object(Messenger, 'publish', side_effect=MessengerError('send')) as publish:
            with self.assertRaises(MessengerError):
                client.prime(100, 45, **self.controls())
            failed = pb.TlePrimeCmd.FromString(publish.call_args.args[1])
        self.assertEqual((failed.prime_sender_id, failed.prime_sequence), (b's' * 16, 1))
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertIsNone(client._expected_prime)
        self.script.status_on_prime = False
        client.prime(100, 45, **self.controls())
        self.assertEqual(self.script.prime_requests, [(b's' * 16, 2)])
        self.script.deliver(Topics.PTU_STATUS + '_2',
            self.status(prime_sender_id=failed.prime_sender_id, prime_sequence=failed.prime_sequence))
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: True})

    def test_cancelled_send_consumes_sequence_without_reusing_readiness(self):
        client = self.loaded()
        client.prime(100, 45, **self.controls())
        old_ready = self.status()
        controls = self.controls()
        self.script.before_return = lambda topic: controls['cancel'].set()
        with self.assertRaises(client_module.PtuError) as caught:
            client.prime(100, 45, **controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        cancelled_ready = self.status()
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.script.before_return = None
        self.script.status_on_prime = False
        client.prime(100, 45, **self.controls())
        for body in (old_ready, cancelled_ready):
            self.script.deliver(Topics.PTU_STATUS + '_2', body)
            self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertEqual([pair[1] for pair in self.script.prime_requests], [1, 2, 3])
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: True})

    def test_wrong_or_missing_sender_sequence_cannot_mutate_current_readiness(self):
        client = self.loaded()
        self.script.status_on_prime = False
        client.prime(100, 45, **self.controls())
        malformed = ((b'', 1), (b's' * 15, 1), (b's' * 17, 1), (b'f' * 16, 1),
                     (b's' * 16, 0), (b's' * 16, 2), (b's' * 16, 2 ** 64 - 1))
        for sender, sequence in malformed:
            with self.subTest(sender_length=len(sender), sequence=sequence):
                self.script.deliver(Topics.PTU_STATUS + '_2',
                    self.status(prime_sender_id=sender, prime_sequence=sequence))
                self.assertEqual(client.ptu_is_primed, {2: False})
                self.assertEqual(client.ptu_status, {})
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: True})

    def test_sequence_exhaustion_clears_ready_without_wrap_or_lifecycle_reset(self):
        client = self.loaded()
        client._prime_sequence = 2 ** 64 - 2
        client.prime(100, 45, **self.controls())
        old_ready = self.status()
        self.assertEqual(self.script.prime_requests, [(b's' * 16, 2 ** 64 - 1)])
        with self.assertRaises(client_module.PtuError) as caught:
            client.prime(100, 45, **self.controls())
        self.assertEqual(caught.exception.primary, 'state')
        self.assertEqual(client._prime_sequence, 2 ** 64 - 1)
        self.assertEqual(client.ptu_is_primed, {2: False})
        self.assertIsNone(client._expected_prime)
        self.script.deliver(Topics.PTU_STATUS + '_2', old_ready)
        self.assertEqual(client.ptu_is_primed, {2: False})
        client.check_connection(**self.controls())
        client.load_tle(TLE, **self.controls())
        with self.assertRaises(client_module.PtuError):
            client.prime(100, 45, **self.controls())
        self.assertEqual(self.script.prime_requests, [(b's' * 16, 2 ** 64 - 1)])
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client._prime_sequence, 2 ** 64 - 1)
        self.assertEqual(client._prime_sender_id, b's' * 16)

    def test_reconnect_reload_and_close_do_not_reset_sender_or_sequence(self):
        client = self.loaded()
        client.prime(100, 45, **self.controls())
        client.check_connection(**self.controls())
        client.load_tle(TLE, **self.controls())
        client.prime(100, 45, **self.controls())
        self.assertEqual(self.script.prime_requests, [(b's' * 16, 1), (b's' * 16, 2)])
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual((client._prime_sender_id, client._prime_sequence), (b's' * 16, 2))

    def test_default_legacy_prime_wire_bytes_do_not_gain_correlation_fields(self):
        legacy = pb.TlePrimeCmd(prime=True, azimuth=100, elevation=45)
        self.assertEqual(legacy.SerializeToString(), bytes.fromhex('08 01 15 00 00 c8 42 1d 00 00 34 42'))
        self.assertEqual((legacy.prime_sender_id, legacy.prime_sequence), (b'', 0))
        self.assertEqual(pb.PositionerStatus().SerializeToString(), b'')

    def test_partial_activation_and_absent_attempt_retain_exact_cleanup(self):
        client = self.opened()
        def fail(topic):
            if topic == Topics.PTU_STATUS + '_2':
                raise MessengerError('operation-limit')
        self.script.subscribe_error = fail
        with self.assertRaises(MessengerError) as caught:
            client.check_connection(**self.controls())
        self.assertEqual(caught.exception.primary, 'operation-limit')
        self.assertEqual(client.diagnostics()['registrations'], 3)
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client.diagnostics()['cleanup'], ())
        self.assertEqual(self.script.registrations, [])

    def test_passive_close_does_not_abort_park_or_close_borrowed_owner(self):
        client = self.loaded()
        client.prime(100, 45, **self.controls())
        count = len(self.published())
        deadline = time.monotonic() + 1
        client.close(deadline=deadline)
        self.assertEqual(len(self.published()), count)
        self.assertEqual(client.ptu_is_primed, {2: False})
        removals = [call for call in self.script.calls if call[0] == 'cancel']
        self.assertEqual(len(removals), 3)
        for call in removals:
            self.assertEqual(call[-1]['deadline'], deadline)
            self.assertFalse(call[-1]['cancel'].is_set())
        self.assertTrue(all(call[-1]['cancel'] is removals[0][-1]['cancel'] for call in removals))
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client.diagnostics()['cleanup'], ())
        self.script.deliver(Topics.PTU_STATUS + '_2', self.status())
        self.assertEqual(client.ptu_is_primed, {2: False})

    def test_failed_close_gates_and_retains_debt_for_later_retry(self):
        client = self.connected()
        failure = MessengerError('disconnected')
        self.script.cancel_error = failure
        with self.assertRaises(MessengerError) as caught:
            client.close(deadline=time.monotonic() + 1)
        self.assertIs(caught.exception, failure)
        self.assertIn('registration-debt', client.diagnostics()['cleanup'])
        self.assertFalse(client.validateCoordinates(100, 45))
        self.script.cancel_error = None
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client.diagnostics()['cleanup'], ())

    def test_close_waits_for_active_state_with_original_deadline(self):
        client = self.connected()
        client._state.acquire()
        try:
            with self.assertRaises(client_module.PtuError) as caught:
                client.close(deadline=time.monotonic() + .02)
            self.assertEqual(caught.exception.primary, 'deadline')
            self.assertIn('active-callback', caught.exception.cleanup)
        finally:
            client._state.release()
        client.close(deadline=time.monotonic() + 1)
        self.assertTrue(client.diagnostics()['closed'])

    def test_unsupported_legacy_paths_reject_before_any_effect(self):
        client = self.opened()
        for name in ('__init__', 'clean_exit', 'reset_ptu', 'start_logging', 'stop_logging',
                     'error_profile_reply_cb', 'send_pointing_error_profile',
                     'check_error_profile_ack', 'tle_reply_cb', 'check_tle_load', 'shutdown',
                     'pong_cmd_cb', 'cal_status_cb', 'calibrate_ptu', 'parked', 'park_ptu',
                     'ptu_status_cb', 'publish_wrapper'):
            with self.subTest(name=name):
                with self.assertRaises(client_module.PtuError) as caught:
                    getattr(client, name)()
                self.assertEqual(caught.exception.primary, 'legacy-path')
        self.assertEqual(self.script.calls, [])


class PtuRealMessengerTests(unittest.TestCase):
    def test_selected_bound_wire_and_status_use_actual_owner_lower(self):
        from test_messenger_lifecycle import PrimitiveHarness, settings
        with tempfile.TemporaryDirectory(prefix='ptu-real-',
                dir=os.environ['PTU_TEST_OUTPUT']) as directory, PrimitiveHarness() as harness:
            values = settings(**station())
            messenger = harness.open(values)
            operation = threading.Event()
            with mock.patch.object(client_module.os, 'urandom', return_value=b'r' * 16):
                client = client_module.PtuClient.open_pointing(messenger=messenger, settings=values,
                    ptu_id=2, elevation_mask=0, no_go_data=NO_GO, log_dir=Path(directory),
                    deadline=harness.deadline(), cancel=operation)
            sent_requests = []
            def sent(frame):
                if not frame.startswith(b'SEND\n'):
                    return
                body = frame.split(b'\n\n', 1)[1][:-1]
                if b'/topic/PTU_PING_2' in frame:
                    request = pb.PingCmd()
                    request.ParseFromString(body)
                    sent_requests.append(('ping', request.pointing_binding))
                    harness.message(1, pb.PongResponse(pong=2,
                        pointing_binding=request.pointing_binding).SerializeToString(),
                        destination=Topics.PONG_RESPONSE + '_2')
                elif b'/topic/TLE_LOAD_COMMAND_2' in frame:
                    request = pb.TleLoadCmd()
                    request.ParseFromString(body)
                    sent_requests.append(('load', request.pointing_binding))
                    harness.message(2, pb.TleReplyMsg(ptu_id=2, success=True,
                        pointing_binding=request.pointing_binding).SerializeToString(),
                        destination=Topics.TLE_LOAD_REPLY + '_2')
                elif b'/topic/TLE_PRIME_COMMAND_2' in frame:
                    request = pb.TlePrimeCmd()
                    request.ParseFromString(body)
                    sent_requests.append(('prime', request.pointing_binding))
                    self.assertEqual((request.prime_sender_id, request.prime_sequence), (b'r' * 16, 1))
                    harness.message(3, pb.PositionerStatus(id=2, state='tle_primed',
                        azimuth=request.azimuth, elevation=request.elevation,
                        pointing_binding=request.pointing_binding,
                        prime_sender_id=request.prime_sender_id,
                        prime_sequence=request.prime_sequence).SerializeToString(),
                        destination=Topics.PTU_STATUS + '_2')
            harness.hooks['send'] = sent
            try:
                self.assertIs(client.check_connection(deadline=harness.deadline(), cancel=operation), True)
                self.assertIs(client.load_tle(TLE, deadline=harness.deadline(), cancel=operation), True)
                self.assertIs(client.prime(100, 45, deadline=harness.deadline(), cancel=operation), True)
                end = time.monotonic() + 1
                while not client.ptu_is_primed[2] and time.monotonic() < end:
                    threading.Event().wait(.001)
                self.assertEqual(client.ptu_is_primed, {2: True})
                self.assertEqual(sent_requests,
                    [(kind, client._policy.binding) for kind in ('ping', 'load', 'prime')])
                operation.set()
                self.assertFalse(harness.cancel.is_set())
                client.close(deadline=harness.deadline())
                self.assertTrue(messenger.strict_instance_compatible(values))
                messenger.publish('/topic/caller', b'alive', deadline=harness.deadline(),
                                  cancel=threading.Event())
                self.assertFalse(harness.raws[0].resource['closed'])
                self.assertEqual(client.diagnostics()['cleanup'], ())
                self.assertEqual(tuple(Path(directory).iterdir()), ())
            finally:
                client.close(deadline=harness.deadline())
                harness.hooks.clear()


if __name__ == '__main__':
    unittest.main(verbosity=2)
