"""Actual Messenger receiver dispatch with controlled TLS sockets and serial replies."""
from contextlib import ExitStack
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from ptu_control import bench
from ptu_control.constants import Topics
from ptu_control.ptu_client import PtuClient
from ptu_control.ptu_manager import PtuManager
from serialptu.proto_impl import PTCR20
from serialptu.ptu import PTU
from test_messenger_lifecycle import settings as transport_settings
from test_ptu_bench import bench_settings
from test_ptu_manager_pointing import FollowingSerial
from runtime_owner_test_support import BrokerHarness


class BenchReceiverTransportTests(unittest.TestCase):
    def test_stop_reaches_actual_receiver_while_move_reply_is_held(self):
        with ExitStack() as stack:
            directory = Path(stack.enter_context(tempfile.TemporaryDirectory()))
            harness = stack.enter_context(BrokerHarness(2, 3))
            configuration = bench_settings()
            configuration.update(transport_settings())
            configuration["bench_context"]["exchange_timeout_seconds"] = 1
            configuration["bench_context"]["observation_max_age_seconds"] = 5
            messenger = harness.open(configuration)
            protocol = PTCR20()
            native = FollowingSerial(protocol)
            with patch("serialptu.ptu.serial.Serial", return_value=native):
                driver = PTU(protocol, "recording-only", pointing=True)
            cancel = threading.Event()
            deadline = time.monotonic() + 15
            with patch.object(bench, "_controlled_rehearsal_boundary", return_value=True):
                manager = PtuManager.open_bench(messenger=messenger, settings=configuration,
                    ptu_id=2, driver=driver, elevation_mask=0, no_go_data=None,
                    run_deadline=deadline, cancel=cancel)
            clients, workers, failures, results = [], [], [], {}
            release_reply = threading.Event()
            held_reply = threading.Event()
            original_read = native.read

            def read(count):
                if held_reply.is_set() and not release_reply.is_set():
                    return b""
                return original_read(count)

            def before_write(command):
                if command == 0x33:
                    held_reply.set()

            def invoke(name, operation):
                try:
                    results[name] = operation()
                except BaseException as error:
                    failures.append(error)

            def controls():
                return dict(deadline=min(deadline, time.monotonic() + 3), cancel=cancel)

            try:
                manager.activate(**controls())
                for unused in range(3):
                    client = PtuClient.open_bench(messenger=messenger, settings=configuration,
                        ptu_id=2, elevation_mask=0, log_dir=directory, no_go_data=None, **controls())
                    clients.append(client)
                    self.assertEqual(client.connect(**controls()).category, "ok")
                preview = clients[0].preview(10, 0, **controls())
                later_preview = clients[2].preview(20, 0, **controls())
                native.read = read
                native.before_write = before_write
                moving = threading.Thread(target=invoke, args=("move", lambda: clients[0].move(preview.preview_sequence, **controls())))
                workers.append(moving)
                moving.start()
                self.assertTrue(held_reply.wait(1), "move never reached the real serial boundary")
                stopping = threading.Thread(target=invoke, args=("stop", lambda: clients[1].stop(**controls())))
                workers.append(stopping)
                stopping.start()
                self.assertTrue(manager._bench_stop_pending.wait(.5),
                    "synchronous serial work trapped Stop behind the Messenger receiver callback")
                self.assertFalse(release_reply.is_set())
                self.assertTrue(moving.is_alive())
                later = threading.Thread(target=invoke, args=("later", lambda: clients[2].move(later_preview.preview_sequence, **controls())))
                workers.append(later)
                later.start()
                end = time.monotonic() + .5
                while manager._bench_regular_slot is None and time.monotonic() < end:
                    threading.Event().wait(.001)
                self.assertIsNotNone(manager._bench_regular_slot)
                release_reply.set()
                for worker in workers:
                    worker.join(3)
                    self.assertFalse(worker.is_alive())
                self.assertEqual(failures, [])
                self.assertEqual(results["move"].category, "ok")
                self.assertEqual(results["stop"].category, "ok")
                self.assertNotEqual(results["later"].category, "ok")
                self.assertEqual(len(native.motion()), 1)
                packets = [protocol._decode_strict_packet(packet, 2) for packet in native.writes]
                move_index = next(index for index, packet in enumerate(packets) if packet[0] == 0x33)
                self.assertEqual(packets[move_index + 1][:2], b"\x31\x02")
                commands = harness.broker.messages(Topics.BENCH_COMMAND + "_2")
                self.assertGreaterEqual(len(commands), 8)
                self.assertEqual(results["stop"].physical_state, "indeterminate")
            finally:
                release_reply.set()
                for worker in workers:
                    worker.join(3)
                for client in clients:
                    client.close(deadline=time.monotonic() + 2)
                manager.close(deadline=time.monotonic() + 2)
                self.assertFalse(manager._bench_worker.is_alive())
                self.assertFalse(native.opened)
