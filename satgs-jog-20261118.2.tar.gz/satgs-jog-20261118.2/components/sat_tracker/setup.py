from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py


class GeneratedBuildPy(build_py):
    def run(self):
        generated = Path(__file__).parent / "src" / "ptu_control" / "ptu_msg_pb2.py"
        if not generated.is_file():
            raise RuntimeError("Generate ptu_control/ptu_msg_pb2.py before building.")
        super().run()


setup(cmdclass={"build_py": GeneratedBuildPy})
