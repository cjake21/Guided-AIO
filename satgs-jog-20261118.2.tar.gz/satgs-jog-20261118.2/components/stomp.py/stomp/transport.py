"""Provides the underlying transport functionality (for stomp message transmission) - (mostly) independent
from the actual STOMP protocol
"""

import errno
import ipaddress
import math
import random
import select
import socket
import sys
import threading
import time
import types
from io import BytesIO
from time import monotonic

try:
    from socket import SOL_SOCKET, SO_KEEPALIVE, SOL_TCP, TCP_KEEPIDLE, TCP_KEEPINTVL, TCP_KEEPCNT
    LINUX_KEEPALIVE_AVAIL = True
except ImportError:
    LINUX_KEEPALIVE_AVAIL = False

try:
    from socket import IPPROTO_TCP
    MAC_KEEPALIVE_AVAIL = True
except ImportError:
    MAC_KEEPALIVE_AVAIL = False

try:
    import ssl
    from ssl import SSLError
    DEFAULT_SSL_VERSION = ssl.PROTOCOL_TLS_CLIENT
except (ImportError, AttributeError):
    ssl = None
    class SSLError(object):
        pass
    DEFAULT_SSL_VERSION = None


import stomp.exception as exception
import stomp.listener
from stomp.utils import *
from stomp import logging


_BOUNDED_CODES = ('none', 'admission', 'deadline', 'cancelled', 'tcp', 'tls-trust',
                  'tls-identity', 'tls', 'protocol', 'send', 'disconnected', 'callback',
                  'worker-start', 'diagnostic-recording', 'socket-release', 'active-operation',
                  'active-callback', 'worker-start-pending', 'worker-live', 'acquisition',
                  'operation-limit', 'topic-limit', 'wire-id', 'pending-limit', 'framing',
                  'legacy-path', 'non-quiescent', 'receive', 'state', 'frame', 'io', 'closed')


class BoundedError(Exception):
    def __init__(self, primary, cleanup=()):
        self.primary = primary if type(primary) is str and primary in _BOUNDED_CODES else 'admission'
        self.cleanup = tuple(code for code in _BOUNDED_CODES if code in cleanup)
        Exception.__init__(self, self.primary)


class _BoundedTicket:
    __slots__ = ('done', 'committed')

    def __init__(self):
        self.done = False
        self.committed = False


class _BoundedTopic:
    __slots__ = ('state', 'ticket', 'removal')

    def __init__(self, ticket):
        self.state = 'pending'
        self.ticket = ticket
        self.removal = None


def bounded_text(value, maxchars, maxbytes, empty=False, ascii_only=False):
    if type(value) is not str or len(value) > maxchars or (not empty and not value):
        raise BoundedError('admission')
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise BoundedError('admission')
    encoded = None
    try:
        encoded = value.encode('ascii' if ascii_only else 'utf-8')
    except UnicodeError:
        pass
    if encoded is None or len(encoded) > maxbytes:
        raise BoundedError('admission')
    return value


def bounded_body(value):
    if type(value) is not bytes or len(value) > 262144:
        raise BoundedError('admission')
    return value


def bounded_wire_id(value):
    if type(value) is not int or not 1 <= value <= 2 ** 63 - 1:
        raise BoundedError('wire-id')
    return value


def _bounded_deadline(value):
    valid = type(value) in (int, float)
    if valid:
        try:
            valid = math.isfinite(value)
        except OverflowError:
            valid = False
    if not valid:
        raise BoundedError('admission')


def _bounded_encode(command, headers, body):
    bounded_text(command, 32, 32, ascii_only=True)
    if any(char < 'A' or char > 'Z' for char in command):
        raise BoundedError('framing')
    bounded_body(body)
    if type(headers) is not dict or len(headers) > 64:
        raise BoundedError('framing')
    lines = []
    size = 0
    for key, value in headers.items():
        bounded_text(key, 8192, 8192)
        bounded_text(value, 8192, 8192, empty=True)
        if command in ('STOMP', 'CONNECT') and ':' in key:
            raise BoundedError('framing')
        if command not in ('STOMP', 'CONNECT'):
            key = key.replace('\\', '\\\\').replace(':', '\\c')
            value = value.replace('\\', '\\\\').replace(':', '\\c')
        line = (key + ':' + value + '\n').encode('utf-8')
        size += len(line)
        if size > 8192:
            raise BoundedError('framing')
        lines.append(line)
    block = b''.join(lines)
    if len(block) > 8192:
        raise BoundedError('framing')
    length = headers.get('content-length')
    if length is None and b'\0' in body:
        raise BoundedError('framing')
    if length is not None and (not length or len(length) > 6 or not all('0' <= char <= '9' for char in length)
                               or int(length) != len(body)):
        raise BoundedError('framing')
    frame = command.encode('ascii') + b'\n' + block + b'\n' + body + b'\0'
    if len(frame) > 270400:
        raise BoundedError('framing')
    return frame


class BaseTransport(stomp.listener.Publisher):
    """
    Base class for transport classes providing support for listeners, threading overrides,
    and anything else outside of actually establishing a network connection, sending and
    receiving of messages (so generally socket-agnostic functions).

    :param bool auto_decode: automatically decode message responses as strings, rather than
        leaving them as bytes. This preserves the behaviour as of version 4.0.16.
        (To be defaulted to False as of the next release)
    :param encoding: the character encoding to use for the message body
    """

    #
    # Used to parse the STOMP "content-length" header lines,
    #
    __content_length_re = re.compile(b"^content-length[:]\\s*(?P<value>[0-9]+)", re.MULTILINE)

    def __init__(self, auto_decode=True, encoding="utf-8", is_eol_fc=is_eol_default):
        self.__recvbuf = b""
        self.listeners = {}
        self.running = False
        self.blocking = None
        self.connected = False
        self.connection_error = False
        self.disconnecting = False
        self.__receipts = {}
        self.current_host_and_port = None
        self.bind_host_port = None
        # flag used when we receive the disconnect receipt
        self.__disconnect_receipt = None
        self.notified_on_disconnect = False

        # function for creating threads used by the connection
        self.create_thread_fc = default_create_thread

        self.__listeners_change_condition = threading.Condition()
        self.__receiver_thread_exit_condition = threading.Condition()
        self.__receiver_thread_exited = False
        self.__send_wait_condition = threading.Condition()
        self.__connect_wait_condition = threading.Condition()
        self.__auto_decode = auto_decode
        self.__encoding = encoding
        self.__is_eol = is_eol_fc

    def _init_bounded(self, cancel, *, endpoint=None):
        if type(cancel) is not threading.Event or getattr(self, '_bounded_mode', False):
            raise BoundedError('admission')
        if endpoint is None:
            endpoint = ('tls', None, None, None)
        if (type(endpoint) is not tuple or len(endpoint) != 4 or type(endpoint[0]) is not str
                or endpoint[0] not in ('tls', 'loopback-plaintext')):
            raise BoundedError('admission')
        self.__bounded_endpoint = endpoint
        self._bounded_mode = True
        self._bounded_cancel = cancel
        self._bounded_gate = False
        self._bounded_returned = False
        self._bounded_state_lock = threading.Lock()
        self._bounded_frame_lock = threading.Lock()
        self._bounded_io_lock = threading.Lock()
        self._bounded_tickets = []
        self._bounded_receiver = None
        self._bounded_startup = None
        self._bounded_callback = None
        self._bounded_dispatch = None
        self._bounded_topics = {}
        self._bounded_last_id = 0
        self._bounded_pending = []
        self._bounded_pending_bytes = 0
        self._bounded_buffer = b''
        self._bounded_primary = 'none'
        self._bounded_phase = 'admission'
        self._bounded_cleanup = ()
        self._bounded_ledger_lock = threading.Lock()
        self._bounded_counters = [0] * 32
        self._bounded_record_failed = False

    @property
    def bounded_endpoint(self):
        return self.__bounded_endpoint

    def _record_bounded(self, code):
        acquired = False
        try:
            acquired = self._bounded_ledger_lock.acquire(False)
            if acquired:
                index = _BOUNDED_CODES.index(code)
                self._bounded_counters[index] = min(2 ** 31 - 1, self._bounded_counters[index] + 1)
        except Exception:
            self._bounded_record_failed = True
        finally:
            if acquired:
                try:
                    self._bounded_ledger_lock.release()
                except Exception:
                    self._bounded_record_failed = True

    def diagnostics_bounded(self):
        return {'primary': self._bounded_primary, 'cleanup': self._bounded_cleanup,
                'counters': tuple(zip(_BOUNDED_CODES, self._bounded_counters)),
                'recording_failed': self._bounded_record_failed}

    def _check_bounded(self, deadline, cancel, passive=False):
        if not passive:
            if (type(cancel) is not threading.Event
                    or not self._bounded_returned and cancel is not self._bounded_cancel):
                raise BoundedError('admission')
            if self._bounded_cancel.is_set():
                self._bounded_gate = True
                raise BoundedError('cancelled')
            if cancel.is_set():
                raise BoundedError('cancelled')
            if self._bounded_gate:
                raise BoundedError('disconnected')
        if deadline is not None and monotonic() >= deadline:
            raise BoundedError('deadline')

    def _remaining_bounded(self, deadline, cancel, passive=False):
        self._check_bounded(deadline, cancel, passive)
        remaining = 0.010 if deadline is None else deadline - monotonic()
        if remaining <= 0:
            self._check_bounded(None, cancel, passive)
            raise BoundedError('deadline')
        return min(0.010, remaining)

    def _lock_bounded(self, lock, deadline, cancel, passive=False):
        while True:
            remaining = self._remaining_bounded(deadline, cancel, passive)
            if lock.acquire(timeout=remaining):
                try:
                    self._check_bounded(deadline, cancel, passive)
                except BaseException:
                    lock.release()
                    raise
                return

    def _discard_pending_bounded(self, wire_id):
        self._bounded_pending = [item for item in self._bounded_pending if item[0] != wire_id]
        self._bounded_pending_bytes = sum(item[2] for item in self._bounded_pending)

    def _reconcile_bounded(self):
        self._bounded_tickets = [ticket for ticket in self._bounded_tickets if not ticket.done]
        for wire_id, topic in self._bounded_topics.items():
            if topic.state == 'pending' and topic.ticket.done:
                topic.state = 'debt'
            if topic.state == 'debt':
                self._discard_pending_bounded(wire_id)

    def _admit_bounded(self, deadline, cancel):
        _bounded_deadline(deadline)
        try:
            self._lock_bounded(self._bounded_state_lock, deadline, cancel)
        except BoundedError:
            if self._bounded_gate:
                self._abort_now_bounded()
            raise
        try:
            self._reconcile_bounded()
            if len(self._bounded_tickets) >= 64:
                raise BoundedError('operation-limit')
            ticket = _BoundedTicket()
            self._bounded_tickets.append(ticket)
            return ticket
        finally:
            self._bounded_state_lock.release()

    def _feed_bounded(self, data):
        if type(data) is not bytes or len(data) > 16384 or len(self._bounded_buffer) + len(data) > 286784:
            raise BoundedError('framing')
        self._bounded_buffer += data

    def _extract_bounded(self):
        data = self._bounded_buffer
        if data.startswith(b'\n') or data.startswith(b'\r\n'):
            size = 2 if data.startswith(b'\r') else 1
            self._bounded_buffer = data[size:]
            return '', {}, b'', size
        line_end = data.find(b'\n')
        if line_end < 0:
            if len(data) > 33:
                raise BoundedError('framing')
            return None
        command = data[:line_end]
        if command.endswith(b'\r'):
            command = command[:-1]
        if not command or len(command) > 32 or any(char < 65 or char > 90 for char in command):
            raise BoundedError('framing')
        markers = [(pos, width) for pos, width in ((data.find(b'\n\n'), 2),
                                                  (data.find(b'\r\n\r\n'), 4)) if pos >= 0]
        if not markers:
            if len(data) - line_end - 1 > 8192:
                raise BoundedError('framing')
            return None
        header_end, separator = min(markers)
        header_bytes = data[line_end + 1:header_end + (1 if separator == 2 else 2)]
        if len(header_bytes) > 8192:
            raise BoundedError('framing')
        lines = header_bytes.split(b'\n')[:-1] if header_bytes else []
        lines = [line[:-1] if line.endswith(b'\r') else line for line in lines]
        if len(lines) > 64:
            raise BoundedError('framing')
        headers = {}
        valid = True
        for line in lines:
            if any(char < 32 or char == 127 for char in line):
                raise BoundedError('framing')
            if b':' not in line:
                raise BoundedError('framing')
            key, value = line.split(b':', 1)
            try:
                key, value = key.decode('utf-8'), value.decode('utf-8')
            except UnicodeError:
                valid = False
                break
            if command not in (b'CONNECT', b'CONNECTED', b'STOMP'):
                decoded = []
                for text in (key, value):
                    result = []
                    index = 0
                    while index < len(text):
                        if text[index] == '\\':
                            index += 1
                            if index == len(text) or text[index] not in ('n', 'c', '\\'):
                                raise BoundedError('framing')
                            result.append({'n': '\n', 'c': ':', '\\': '\\'}[text[index]])
                        else:
                            result.append(text[index])
                        index += 1
                    decoded.append(''.join(result))
                key, value = decoded
            if not key or key in headers or '\0' in key or '\0' in value:
                raise BoundedError('framing')
            headers[key] = value
        if not valid:
            raise BoundedError('framing')
        body_start = header_end + separator
        length = headers.get('content-length')
        if length is not None:
            if not length or len(length) > 6 or not all('0' <= char <= '9' for char in length):
                raise BoundedError('framing')
            count = int(length)
            if count > 262144:
                raise BoundedError('framing')
            end = body_start + count
            if len(data) <= end:
                return None
            if data[end] != 0:
                raise BoundedError('framing')
        else:
            end = data.find(b'\0', body_start)
            if end < 0:
                if len(data) - body_start > 262144:
                    raise BoundedError('framing')
                return None
            if end - body_start > 262144:
                raise BoundedError('framing')
        if end + 1 > 270400:
            raise BoundedError('framing')
        frame = command.decode('ascii'), headers, data[body_start:end], end + 1
        self._bounded_buffer = data[end + 1:]
        return frame

    def override_threading(self, create_thread_fc):
        """
        Override for thread creation. Use an alternate threading library by
        setting this to a function with a single argument (which is the receiver loop callback).
        The thread which is returned should be started (ready to run)

        :param function create_thread_fc: single argument function for creating a thread
        """
        self.create_thread_fc = create_thread_fc

    #
    # Manage the connection
    #

    def start(self):
        """
        Start the connection. This should be called after all
        listeners have been registered. If this method is not called,
        no frames will be received by the connection and no SSL/TLS
        handshake will occur.
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        self.running = True
        self.attempt_connection()
        receiver_thread = self.create_thread_fc(self.__receiver_loop)
        logging.debug("created thread %s using func %s", receiver_thread, self.create_thread_fc)
        self.notify("connecting")

    def stop(self):
        """
        Stop the connection. Performs a clean shutdown by waiting for the
        receiver thread to exit.
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        with self.__receiver_thread_exit_condition:
            while not self.__receiver_thread_exited and self.is_connected():
                self.__receiver_thread_exit_condition.wait()

    def is_connected(self):
        """
        :rtype: bool
        """
        return self.connected

    def set_connected(self, connected):
        """
        :param bool connected:
        """
        with self.__connect_wait_condition:
            self.connected = connected
            if connected:
                self.disconnecting = False
                self.__connect_wait_condition.notify()

    def set_receipt(self, receipt_id, value):
        if value:
            self.__receipts[receipt_id] = value
        elif receipt_id in self.__receipts:
            del self.__receipts[receipt_id]

    #
    # Manage objects listening to incoming frames
    #

    def set_listener(self, name, listener):
        """
        Set a named listener to use with this connection.
        See :py:class:`stomp.listener.ConnectionListener`

        :param str name: the name of the listener
        :param ConnectionListener listener: the listener object
        """
        assert listener is not None
        with self.__listeners_change_condition:
            self.listeners[name] = listener

    def remove_listener(self, name):
        """
        Remove a listener according to the specified name

        :param str name: the name of the listener to remove
        """
        with self.__listeners_change_condition:
            del self.listeners[name]

    def get_listener(self, name):
        """
        Return the named listener

        :param str name: the listener to return

        :rtype: ConnectionListener
        """
        return self.listeners.get(name)

    def process_frame(self, f, frame_str):
        """
        :param Frame f: Frame object
        :param bytes frame_str: raw frame content
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        frame_type = f.cmd.lower()
        if frame_type in ["connected", "message", "receipt", "error", "heartbeat"]:
            if frame_type == "message":
                self.notify("before_message", f)
            if logging.isEnabledFor(logging.DEBUG):
                logging.debug("received frame: %r, headers=%r, body=%r", f.cmd, f.headers, f.body)
            self.notify(frame_type, f)
        else:
            logging.warning("unknown response frame type: '%s' (frame length was %d)", frame_type, length(frame_str))

    def notify(self, frame_type, frame=None):
        """
        Utility function for notifying listeners of incoming and outgoing messages

        :param str frame_type: the type of message
        :param Frame frame: the stomp frame
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        if frame_type == "receipt":
            # logic for wait-on-receipt notification
            receipt = frame.headers["receipt-id"]
            receipt_value = self.__receipts.get(receipt)
            with self.__send_wait_condition:
                self.set_receipt(receipt, None)
                self.__send_wait_condition.notify()

            if receipt_value == CMD_DISCONNECT:
                self.set_connected(False)
                # received a stomp 1.1+ disconnect receipt
                if receipt == self.__disconnect_receipt:
                    self.disconnect_socket()
                self.__disconnect_receipt = None

        elif frame_type == "connected":
            self.set_connected(True)

        elif frame_type == "disconnected":
            self.notified_on_disconnect = True
            self.set_connected(False)

        with self.__listeners_change_condition:
            listeners = sorted(self.listeners.items())

        for (_, listener) in listeners:
            notify_func = getattr(listener, "on_%s" % frame_type, None)
            if not notify_func:
                logging.debug("listener %s has no method on_%s", listener, frame_type)
                continue
            if frame_type in ("heartbeat", "disconnected"):
                notify_func()
                continue
            if frame_type == "connecting":
                notify_func(self.current_host_and_port)
                continue

            if frame_type == "error" and not self.connected:
                with self.__connect_wait_condition:
                    self.connection_error = True
                    self.__connect_wait_condition.notify()

            notify_func(frame)

    def transmit(self, frame):
        """
        Convert a frame object to a frame string and transmit to the server.

        :param Frame frame: the Frame object to transmit
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        with self.__listeners_change_condition:
            listeners = sorted(self.listeners.items())

        for (_, listener) in listeners:
            try:
                listener.on_send(frame)
            except AttributeError:
                continue

        if frame.cmd == CMD_DISCONNECT and HDR_RECEIPT in frame.headers:
            self.__disconnect_receipt = frame.headers[HDR_RECEIPT]

        lines = convert_frame(frame)
        packed_frame = pack(lines)

        if logging.isEnabledFor(logging.DEBUG):
            logging.debug("sending frame: %s", clean_lines(lines))
        self.send(packed_frame)

    def send(self, encoded_frame):
        """
        Send an encoded frame over this transport (to be implemented in subclasses)

        :param bytes encoded_frame: a Frame object which has been encoded for transmission
        """
        pass

    def receive(self):
        """
        Receive a chunk of data (to be implemented in subclasses)

        :rtype: bytes
        """
        pass

    def cleanup(self):
        """
        Cleanup the transport (to be implemented in subclasses)
        """
        pass

    def attempt_connection(self):
        """
        Attempt to establish a connection.
        """
        pass

    def disconnect_socket(self):
        """
        Disconnect the socket.
        """
        pass

    def wait_for_connection(self, timeout=None):
        """
        Wait until we've established a connection with the server.

        :param float timeout: how long to wait, in seconds
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        if timeout is not None:
            wait_time = timeout / 10.0
        else:
            wait_time = None
        with self.__connect_wait_condition:
            while self.running and not self.is_connected() and not self.connection_error:
                self.__connect_wait_condition.wait(wait_time)
        if not self.running or not self.is_connected():
            raise exception.ConnectFailedException()

    def __receiver_loop(self):
        """
        Main loop listening for incoming data.
        """
        logging.debug("starting receiver loop (%s)", threading.current_thread())
        notify_disconnected = True
        try:
            while self.running:
                try:
                    while self.running:
                        frames = self.__read()

                        for frame in frames:
                            if self.__is_eol(frame):
                                f = HEARTBEAT_FRAME
                            else:
                                f = parse_frame(frame)
                            if f is None:
                                continue
                            if self.__auto_decode:
                                f.body = decode(f.body)
                            self.process_frame(f, frame)
                except exception.ConnectionClosedException:
                    if self.running:
                        #
                        # Clear out any half-received messages after losing connection
                        #
                        self.__recvbuf = b""
                        self.running = False
                        notify_disconnected = True
                    break
                finally:
                    self.cleanup()
        finally:
            with self.__receiver_thread_exit_condition:
                self.__receiver_thread_exited = True
                self.__receiver_thread_exit_condition.notify_all()
            logging.debug("receiver loop ended")
            self.notify("receiver_loop_completed")
            if notify_disconnected and not self.notified_on_disconnect:
                self.notify("disconnected")
            with self.__connect_wait_condition:
                self.__connect_wait_condition.notify_all()
            self.notified_on_disconnect = False

    def __read(self):
        """
        Read the next frame(s) from the socket.

        :return: list of frames read
        :rtype: list(bytes)
        """
        fastbuf = BytesIO()
        while self.running:
            try:
                try:
                    c = self.receive()
                except exception.InterruptedException:
                    logging.debug("socket read interrupted, restarting")
                    continue
            except Exception:
                logging.debug("socket read error", exc_info=logging.verbose)
                c = b""
            if c is None or len(c) == 0:
                logging.debug("nothing received, raising CCE")
                raise exception.ConnectionClosedException()
            if self.__is_eol(c) and not self.__recvbuf and not fastbuf.tell():
                #
                # EOL to an empty receive buffer: treat as heartbeat.
                # Note that this may misdetect an optional EOL at end of frame as heartbeat in case the
                # previous receive() got a complete frame whose NUL at end of frame happened to be the
                # last byte of that read. But that should be harmless in practice.
                #
                fastbuf.close()
                return [c]
            fastbuf.write(c)
            if b"\x00" in c:
                #
                # Possible end of frame
                #
                break
        self.__recvbuf += fastbuf.getvalue()
        fastbuf.close()
        result = []

        if self.__recvbuf and self.running:
            while True:
                pos = self.__recvbuf.find(b"\x00")

                if pos >= 0:
                    frame = self.__recvbuf[0:pos]
                    preamble_end_match = PREAMBLE_END_RE.search(frame)
                    if preamble_end_match:
                        preamble_end = preamble_end_match.start()
                        content_length_match = BaseTransport.__content_length_re.search(frame[0:preamble_end])
                        if content_length_match:
                            content_length = int(content_length_match.group("value"))
                            content_offset = preamble_end_match.end()
                            frame_size = content_offset + content_length
                            if frame_size > len(frame):
                                #
                                # Frame contains NUL bytes, need to read more
                                #
                                if frame_size < len(self.__recvbuf):
                                    pos = frame_size
                                    frame = self.__recvbuf[0:pos]
                                else:
                                    #
                                    # Haven't read enough data yet, exit loop and wait for more to arrive
                                    #
                                    break
                    result.append(frame)
                    pos += 1
                    #
                    # Ignore optional EOLs at end of frame
                    #
                    while 1:
                        if self.__is_eol(self.__recvbuf[pos:pos + 1]):
                            pos += 1
                        elif self.__is_eol(self.__recvbuf[pos:pos + 2]):
                            pos += 2
                        else:
                            break
                    self.__recvbuf = self.__recvbuf[pos:]
                else:
                    break
        return result


class Transport(BaseTransport):
    """
    Represents a STOMP client 'transport'. Effectively this is the communications mechanism without the definition of
    the protocol.

    :param list((str,int)) host_and_ports: a list of (host, port) tuples
    :param bool prefer_localhost: if True and the local host is mentioned in the (host,
        port) tuples, try to connect to this first
    :param bool try_loopback_connect: if True and the local host is found in the host
        tuples, try connecting to it using loopback interface
        (127.0.0.1)
    :param float reconnect_sleep_initial: initial delay in seconds to wait before reattempting
        to establish a connection if connection to any of the
        hosts fails.
    :param float reconnect_sleep_increase: factor by which the sleep delay is increased after
        each connection attempt. For example, 0.5 means
        to wait 50% longer than before the previous attempt,
        1.0 means wait twice as long, and 0.0 means keep
        the delay constant.
    :param float reconnect_sleep_max: maximum delay between connection attempts, regardless
        of the reconnect_sleep_increase.
    :param float reconnect_sleep_jitter: random additional time to wait (as a percentage of
        the time determined using the previous parameters)
        between connection attempts in order to avoid
        stampeding. For example, a value of 0.1 means to wait
        an extra 0%-10% (randomly determined) of the delay
        calculated using the previous three parameters.
    :param int reconnect_attempts_max: maximum attempts to reconnect (Can also be used for infinite attempts : `-1`)
    :param timeout: the timeout value to use when connecting the stomp socket
    :param keepalive: some operating systems support sending the occasional heart
        beat packets to detect when a connection fails.  This
        parameter can either be set set to a boolean to turn on the
        default keepalive options for your OS, or as a tuple of
        values, which also enables keepalive packets, but specifies
        options specific to your OS implementation.
        For linux, supply ("linux", ka_idle, ka_intvl, ka_cnt)
        For macos, supply ("mac", ka_intvl)
    :param str vhost: specify a virtual hostname to provide in the 'host' header of the connection
    :param int recv_bytes: the number of bytes to use when calling recv
    """

    def __init__(self,
                 host_and_ports=None,
                 prefer_localhost=True,
                 try_loopback_connect=True,
                 reconnect_sleep_initial=0.1,
                 reconnect_sleep_increase=0.5,
                 reconnect_sleep_jitter=0.1,
                 reconnect_sleep_max=60.0,
                 reconnect_attempts_max=3,
                 timeout=None,
                 keepalive=None,
                 vhost=None,
                 auto_decode=True,
                 encoding="utf-8",
                 recv_bytes=1024,
                 is_eol_fc=is_eol_default,
                 bind_host_port=None):
        BaseTransport.__init__(self, auto_decode, encoding, is_eol_fc)

        if host_and_ports is None:
            logging.debug("no hosts_and_ports specified, adding default localhost")
            host_and_ports = [("localhost", 61613)]

        sorted_host_and_ports = []
        sorted_host_and_ports.extend(host_and_ports)

        #
        # If localhost is preferred, make sure all (host, port) tuples that refer to the local host come first in
        # the list
        #
        if prefer_localhost:
            sorted_host_and_ports.sort(key=is_localhost)

        #
        # If the user wishes to attempt connecting to local ports using the loopback interface, for each (host, port)
        # tuple referring to a local host, add an entry with the host name replaced by 127.0.0.1 if it doesn't
        # exist already
        #
        loopback_host_and_ports = []
        if try_loopback_connect:
            for host_and_port in sorted_host_and_ports:
                if is_localhost(host_and_port) == 1:
                    port = host_and_port[1]
                    if not (("127.0.0.1", port) in sorted_host_and_ports or (
                    "localhost", port) in sorted_host_and_ports):
                        loopback_host_and_ports.append(("127.0.0.1", port))

        #
        # Assemble the final, possibly sorted list of (host, port) tuples
        #
        self.__host_and_ports = []
        self.__host_and_ports.extend(loopback_host_and_ports)
        self.__host_and_ports.extend(sorted_host_and_ports)
        self.__bind_host_port = bind_host_port

        self.__reconnect_sleep_initial = reconnect_sleep_initial
        self.__reconnect_sleep_increase = reconnect_sleep_increase
        self.__reconnect_sleep_jitter = reconnect_sleep_jitter
        self.__reconnect_sleep_max = reconnect_sleep_max
        self.__reconnect_attempts_max = reconnect_attempts_max
        self.__timeout = timeout

        self.socket = None
        self.__socket_semaphore = threading.BoundedSemaphore(1)
        self.current_host_and_port = None

        # setup SSL
        self.__ssl_params = {}
        self.__keepalive = keepalive
        self.vhost = vhost
        self.__recv_bytes = recv_bytes

    def _wait_bounded(self, reading, deadline, cancel, once=False):
        while True:
            self._check_bounded(deadline, cancel)
            owned = self.socket
            if owned is None:
                raise BoundedError('disconnected')
            timeout = self._remaining_bounded(deadline, cancel)
            try:
                ready = select.select([owned] if reading else [], [] if reading else [owned], [], timeout)
            except InterruptedError:
                continue
            self._check_bounded(deadline, cancel)
            if owned is not self.socket:
                raise BoundedError('disconnected')
            if ready[0] if reading else ready[1]:
                return True
            if once:
                return False

    def _primitive_bounded(self, name, args, deadline, cancel, progress=None):
        self._lock_bounded(self._bounded_io_lock, deadline, cancel)
        try:
            self._check_bounded(deadline, cancel)
            if self.socket is None:
                raise BoundedError('disconnected')
            if progress is not None:
                progress[0] = True
            result = getattr(self.socket, name)(*args)
            self._check_bounded(deadline, cancel)
            return result
        finally:
            self._bounded_io_lock.release()

    def _close_owned_bounded(self):
        if self.socket is None:
            return True
        released = False
        try:
            self.socket.close()
            released = True
        except BaseException:
            pass
        if released:
            self.socket = None
            self.connected = False
        return released

    def _abort_now_bounded(self):
        self._bounded_gate = True
        if self._bounded_io_lock.acquire(False):
            try:
                return self._close_owned_bounded()
            finally:
                self._bounded_io_lock.release()

    def _debt_bounded(self):
        debt = []
        if self.socket is not None:
            debt.append('socket-release')
        if any(not ticket.done for ticket in self._bounded_tickets):
            debt.append('active-operation')
        if self._bounded_callback is not None and not self._bounded_callback.done:
            debt.append('active-callback')
        if self._bounded_startup is not None and not self._bounded_startup.done:
            debt.append('worker-start-pending')
        if self._bounded_receiver is not None and self._bounded_receiver.is_alive():
            debt.append('worker-live')
        return tuple(debt)

    def _error_bounded(self, primary):
        if type(primary) is not str or primary not in _BOUNDED_CODES:
            primary = 'admission'
        if self._bounded_primary == 'none':
            self._bounded_primary = primary
        self._bounded_cleanup = self._debt_bounded()
        self._record_bounded(primary)
        return BoundedError(primary, self._bounded_cleanup)

    def _rollback_bounded(self, primary):
        self._abort_now_bounded()
        return self._error_bounded(primary)

    def acquire_bounded(self, dial_address, port, tls_identity, ssl_context, *, deadline, cancel):
        _bounded_deadline(deadline)
        self._check_bounded(deadline, cancel)
        bounded_text(dial_address, 45, 45, ascii_only=True)
        bounded_text(tls_identity, 253, 253, ascii_only=True)
        if type(port) is not int or not 1 <= port <= 65535 or '%' in dial_address:
            raise BoundedError('admission')
        address = None
        try:
            address = ipaddress.ip_address(dial_address)
        except ValueError:
            pass
        if address is None or str(address) != dial_address:
            raise BoundedError('admission')
        identity = None
        try:
            identity = ipaddress.ip_address(tls_identity)
        except ValueError:
            pass
        if identity is not None:
            valid_identity = '%' not in tls_identity and str(identity) == tls_identity
        else:
            valid_identity = all(0 < len(label) <= 63 and label[0] != '-' and label[-1] != '-'
                                 and all(char.isalnum() or char == '-' for char in label)
                                 for label in tls_identity.split('.'))
        if not valid_identity:
            raise BoundedError('tls-identity')
        if ssl is None or type(ssl_context) is not ssl.SSLContext:
            raise BoundedError('tls-trust')
        if ssl_context.verify_mode != ssl.CERT_REQUIRED or ssl_context.check_hostname is not True:
            raise BoundedError('tls-trust')
        if hasattr(ssl, 'TLSVersion') and hasattr(ssl_context, 'minimum_version'):
            minimum_ok = ssl_context.minimum_version >= ssl.TLSVersion.TLSv1_2
        else:
            mask = ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
            minimum_ok = ssl_context.options & mask == mask
        if not minimum_ok or self.socket is not None or self._bounded_returned:
            raise BoundedError('tls-trust')
        if self.bounded_endpoint != ('tls', dial_address, port, tls_identity):
            raise BoundedError('admission')
        family = socket.AF_INET if address.version == 4 else socket.AF_INET6
        endpoint = (dial_address, port) if address.version == 4 else (dial_address, port, 0, 0)
        self._acquire_tcp_bounded(family, endpoint, deadline, cancel)
        self._check_bounded(deadline, cancel)
        self._bounded_phase = 'tls'
        wrapped = ssl_context.wrap_socket(self.socket, server_hostname=tls_identity, do_handshake_on_connect=False)
        self.socket = wrapped
        self._check_bounded(deadline, cancel)
        self._primitive_bounded('setblocking', (False,), deadline, cancel)
        while True:
            try:
                self._primitive_bounded('do_handshake', (), deadline, cancel)
                break
            except ssl.SSLWantReadError:
                self._wait_bounded(True, deadline, cancel)
            except ssl.SSLWantWriteError:
                self._wait_bounded(False, deadline, cancel)
            except InterruptedError:
                self._check_bounded(deadline, cancel)

    def acquire_loopback_bounded(self, dial_address, port, *, deadline, cancel):
        _bounded_deadline(deadline)
        self._check_bounded(deadline, cancel)
        if (type(dial_address) is not str or dial_address != '127.0.0.1'
                or type(port) is not int or not 1 <= port <= 65535
                or self.bounded_endpoint != ('loopback-plaintext', dial_address, port, None)
                or self.socket is not None or self._bounded_returned):
            raise BoundedError('admission')
        self._acquire_tcp_bounded(socket.AF_INET, (dial_address, port), deadline, cancel)

    def _acquire_tcp_bounded(self, family, endpoint, deadline, cancel):
        self._check_bounded(deadline, cancel)
        self._bounded_phase = 'tcp'
        self.socket = socket.socket(family, socket.SOCK_STREAM)
        self._check_bounded(deadline, cancel)
        self._primitive_bounded('setblocking', (False,), deadline, cancel)
        result = self._primitive_bounded('connect_ex', (endpoint,), deadline, cancel)
        if result in (errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY, errno.EINTR):
            self._wait_bounded(False, deadline, cancel)
        elif result not in (0, errno.EISCONN):
            raise BoundedError('tcp')
        if self._primitive_bounded('getsockopt', (socket.SOL_SOCKET, socket.SO_ERROR), deadline, cancel) != 0:
            raise BoundedError('tcp')

    def _receive_bounded(self, deadline, cancel, receiver=False):
        while True:
            self._check_bounded(deadline, cancel)
            if receiver:
                pending = self._take_pending_bounded()
                if pending is not None:
                    self._invoke_bounded(*pending)
                    continue
            frame = self._extract_bounded()
            if frame is not None:
                if frame[0]:
                    self._check_bounded(deadline, cancel)
                    return frame
                continue
            if (self.bounded_endpoint[0] != 'tls'
                    or not self._primitive_bounded('pending', (), deadline, cancel)):
                if not self._wait_bounded(True, deadline, cancel, once=receiver):
                    continue
            try:
                data = self._primitive_bounded('recv', (16384,), deadline, cancel)
            except (ssl.SSLWantReadError, BlockingIOError):
                self._wait_bounded(True, deadline, cancel, once=receiver)
                continue
            except ssl.SSLWantWriteError:
                self._wait_bounded(False, deadline, cancel, once=receiver)
                continue
            except InterruptedError:
                continue
            if not data:
                raise BoundedError('disconnected')
            self._feed_bounded(data)

    def observe_connected_bounded(self, *, deadline, cancel):
        _bounded_deadline(deadline)
        self._bounded_phase = 'protocol'
        frame = self._receive_bounded(deadline, cancel)
        if frame[0] != 'CONNECTED' or frame[1].get('version') != '1.1' or frame[2]:
            raise BoundedError('protocol')
        self._check_bounded(deadline, cancel)

    def _commit_open_bounded(self, *, deadline, cancel):
        self._check_bounded(deadline, cancel)
        self.connected = True
        self._bounded_returned = True

    def _send_bytes_bounded(self, data, deadline, cancel, topic=None):
        offset = 0
        progress = [False]
        try:
            self._lock_bounded(self._bounded_frame_lock, deadline, cancel)
            try:
                while offset < len(data):
                    if topic is not None and topic.state != 'pending':
                        raise BoundedError('state')
                    try:
                        sent = self._primitive_bounded('send', (data[offset:],), deadline, cancel, progress)
                    except (ssl.SSLWantWriteError, BlockingIOError):
                        self._wait_bounded(False, deadline, cancel)
                        continue
                    except ssl.SSLWantReadError:
                        self._wait_bounded(True, deadline, cancel)
                        continue
                    except InterruptedError:
                        continue
                    if type(sent) is not int or sent <= 0 or sent > len(data) - offset:
                        raise BoundedError('send')
                    offset += sent
                self._check_bounded(deadline, cancel)
            finally:
                self._bounded_frame_lock.release()
        except BaseException:
            # A late native send can have effects even before its result is admitted.
            if progress[0] or self._bounded_gate:
                self._abort_now_bounded()
            raise

    def send_bounded(self, data, *, deadline, cancel):
        if type(data) is not bytes or not data or len(data) > 270400:
            raise BoundedError('framing')
        ticket = self._admit_bounded(deadline, cancel)
        primary = None
        try:
            self._send_bytes_bounded(data, deadline, cancel)
        except BoundedError as error:
            primary = error.primary
        except BaseException:
            primary = 'send'
        finally:
            ticket.done = True
        if primary is not None:
            raise self._error_bounded(primary) from None

    def transmit_bounded(self, command, headers, body=b'', *, deadline, cancel,
                         _subscription=None, _unsubscribe=None, _dispatch=None):
        data = _bounded_encode(command, headers, body)
        ticket = self._admit_bounded(deadline, cancel)
        primary = None
        topic = None
        try:
            if _subscription is not None or _unsubscribe is not None:
                wire_id = bounded_wire_id(_subscription if _subscription is not None else _unsubscribe)
                if not self._bounded_returned:
                    raise BoundedError('admission')
                self._lock_bounded(self._bounded_state_lock, deadline, cancel)
                try:
                    if _subscription is not None:
                        if wire_id <= self._bounded_last_id:
                            raise BoundedError('wire-id')
                        if len(self._bounded_topics) >= 128:
                            raise BoundedError('topic-limit')
                        topic = _BoundedTopic(ticket)
                        self._bounded_topics[wire_id] = topic
                        self._bounded_last_id = wire_id
                    else:
                        if wire_id not in self._bounded_topics:
                            raise BoundedError('wire-id')
                        removal = self._bounded_topics[wire_id]
                        if removal.removal is not None and not removal.removal.done:
                            raise BoundedError('state')
                        removal.state = 'debt'
                        removal.removal = ticket
                        self._discard_pending_bounded(wire_id)
                finally:
                    self._bounded_state_lock.release()
                if _subscription is not None:
                    self.activate_receiver_bounded(_dispatch, deadline=deadline, cancel=cancel)
            self._bounded_phase = 'send'
            self._send_bytes_bounded(data, deadline, cancel, topic)
            if _subscription is not None or _unsubscribe is not None:
                self._lock_bounded(self._bounded_state_lock, deadline, cancel)
                try:
                    if topic is not None:
                        if self._bounded_topics.get(wire_id) is not topic or topic.state != 'pending':
                            raise BoundedError('state')
                        topic.state = 'active'
                    else:
                        del self._bounded_topics[wire_id]
                finally:
                    self._bounded_state_lock.release()
            self._check_bounded(deadline, cancel)
            ticket.committed = True
        except BoundedError as error:
            primary = error.primary
        except BaseException:
            primary = 'send'
            self._abort_now_bounded()
        finally:
            ticket.done = True
        if primary is not None:
            if topic is not None:
                topic.state = 'debt'
            if self._bounded_gate:
                self._abort_now_bounded()
            raise self._error_bounded(primary) from None

    def activate_receiver_bounded(self, dispatch, *, deadline, cancel):
        _bounded_deadline(deadline)
        if type(dispatch) not in (types.FunctionType, types.MethodType) or not self._bounded_returned:
            raise BoundedError('admission')
        self._check_bounded(deadline, cancel)
        starting = False
        self._lock_bounded(self._bounded_state_lock, deadline, cancel)
        try:
            if self._bounded_receiver is not None:
                if dispatch is not self._bounded_dispatch:
                    raise BoundedError('admission')
                startup = self._bounded_startup
            else:
                worker = threading.Thread(target=self._receiver_bounded, name='stomp-bounded-receiver')
                startup = _BoundedTicket()
                self._bounded_dispatch = dispatch
                self._bounded_receiver = worker
                self._bounded_startup = startup
                starting = True
        finally:
            self._bounded_state_lock.release()
        if not starting:
            while not startup.done:
                time.sleep(self._remaining_bounded(deadline, cancel))
            self._check_bounded(deadline, cancel)
            if not startup.committed:
                raise BoundedError('worker-start')
            return
        primary = None
        try:
            self._check_bounded(deadline, cancel)
            worker.start()
            self._check_bounded(deadline, cancel)
            startup.committed = True
        except BoundedError as error:
            primary = error.primary
        except BaseException:
            primary = 'worker-start'
        finally:
            if primary is not None:
                self._bounded_gate = True
            startup.done = True
        if primary is not None:
            self._abort_now_bounded()
            raise self._error_bounded(primary) from None

    def _queue_bounded(self, wire_id, frame):
        if len(self._bounded_pending) >= 8 or self._bounded_pending_bytes + frame[3] > 1048576:
            self._bounded_gate = True
            raise BoundedError('pending-limit')
        self._bounded_pending.append((wire_id, frame, frame[3]))
        self._bounded_pending_bytes += frame[3]

    def _invoke_bounded(self, wire_id, frame, callback):
        failed = False
        try:
            self._bounded_dispatch(wire_id, frame)
        except BaseException:
            failed = True
        finally:
            callback.done = True
        if failed:
            raise BoundedError('callback')

    def _dispatch_frame_bounded(self, frame):
        if frame[0] != 'MESSAGE':
            raise BoundedError('protocol')
        value = frame[1].get('subscription', '')
        if not value or len(value) > 19 or not all('0' <= char <= '9' for char in value):
            raise BoundedError('protocol')
        wire_id = int(value)
        if wire_id < 1 or wire_id > 2 ** 63 - 1 or str(wire_id) != value:
            raise BoundedError('protocol')
        callback = None
        self._lock_bounded(self._bounded_state_lock, None, self._bounded_cancel)
        try:
            self._reconcile_bounded()
            topic = self._bounded_topics.get(wire_id)
            if topic is None or topic.state == 'debt':
                return
            if topic.state == 'pending' or not topic.ticket.committed or any(item[0] == wire_id for item in self._bounded_pending):
                self._queue_bounded(wire_id, frame)
                return
            callback = _BoundedTicket()
            self._bounded_callback = callback
        finally:
            self._bounded_state_lock.release()
        self._invoke_bounded(wire_id, frame, callback)

    def _take_pending_bounded(self):
        self._lock_bounded(self._bounded_state_lock, None, self._bounded_cancel)
        try:
            self._reconcile_bounded()
            for index, item in enumerate(self._bounded_pending):
                topic = self._bounded_topics.get(item[0])
                if topic is not None and topic.state == 'active' and topic.ticket.committed:
                    del self._bounded_pending[index]
                    self._bounded_pending_bytes -= item[2]
                    callback = _BoundedTicket()
                    self._bounded_callback = callback
                    return item[0], item[1], callback
            return None
        finally:
            self._bounded_state_lock.release()

    def _receiver_bounded(self):
        primary = None
        try:
            while True:
                self._check_bounded(None, self._bounded_cancel)
                frame = self._receive_bounded(None, self._bounded_cancel, receiver=True)
                self._dispatch_frame_bounded(frame)
        except BoundedError as error:
            primary = error.primary
            if primary == 'disconnected' and self._bounded_gate:
                primary = None
        except BaseException:
            primary = 'receive'
        finally:
            self._abort_now_bounded()
        if primary is not None:
            self._error_bounded(primary)

    def abort_bounded(self, *, deadline):
        _bounded_deadline(deadline)
        self._bounded_gate = True
        released = self._abort_now_bounded()
        primary = None
        try:
            self._check_bounded(deadline, None, passive=True)
            if released is False:
                raise BoundedError('socket-release')
            if self._bounded_receiver is threading.current_thread():
                raise BoundedError('non-quiescent')
            if self.socket is not None:
                self._lock_bounded(self._bounded_io_lock, deadline, None, passive=True)
                try:
                    if not self._close_owned_bounded():
                        raise BoundedError('socket-release')
                finally:
                    self._bounded_io_lock.release()
            while True:
                self._lock_bounded(self._bounded_state_lock, deadline, None, passive=True)
                try:
                    self._reconcile_bounded()
                    active = bool(self._bounded_tickets)
                    startup = self._bounded_startup is not None and not self._bounded_startup.done
                    callback = self._bounded_callback is not None and not self._bounded_callback.done
                finally:
                    self._bounded_state_lock.release()
                worker = self._bounded_receiver
                if not active and not startup and not callback:
                    if worker is not None and worker.is_alive():
                        worker.join(timeout=self._remaining_bounded(deadline, None, passive=True))
                    if worker is None or not worker.is_alive():
                        break
                self._check_bounded(deadline, None, passive=True)
                time.sleep(self._remaining_bounded(deadline, None, passive=True))
            self._check_bounded(deadline, None, passive=True)
        except BoundedError as error:
            primary = error.primary
        except BaseException:
            primary = 'non-quiescent'
        if primary is not None:
            raise self._error_bounded(primary) from None
        self._bounded_cleanup = ()

    def is_connected(self):
        """
        Return true if the socket managed by this connection is connected

        :rtype: bool
        """
        if getattr(self, '_bounded_mode', False):
            return self.connected and not self._bounded_gate and self.socket is not None
        try:
            return self.socket is not None and self.socket.getsockname()[1] != 0 and BaseTransport.is_connected(self)
        except socket.error:
            return False

    def disconnect_socket(self):
        """
        Disconnect the underlying socket connection
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        self.running = False
        if self.socket is not None:
            if self.__need_ssl():
                #
                # Even though we don't want to use the socket, unwrap is the only API method which does a proper SSL
                # shutdown
                #
                try:
                    self.socket = self.socket.unwrap()
                except Exception:
                    #
                    # unwrap seems flaky on Win with the back-ported ssl mod, so catch any exception and log it
                    #
                    _, e, _ = sys.exc_info()
                    logging.warning(e)
            elif hasattr(socket, "SHUT_RDWR"):
                try:
                    self.socket.shutdown(socket.SHUT_RDWR)
                except socket.error:
                    _, e, _ = sys.exc_info()
                    # ignore when socket already closed
                    if get_errno(e) != errno.ENOTCONN:
                        logging.warning("unable to issue SHUT_RDWR on socket because of error '%s'", e)

        #
        # split this into a separate check, because sometimes the socket is nulled between shutdown and this call
        #
        if self.socket is not None:
            try:
                self.socket.close()
            except socket.error:
                _, e, _ = sys.exc_info()
                logging.warning("unable to close socket because of error '%s'", e)
        self.current_host_and_port = None
        self.socket = None
        if not self.notified_on_disconnect:
            self.notify("disconnected")

    def send(self, encoded_frame):
        """
        :param bytes encoded_frame:
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        if self.socket is not None:
            try:
                with self.__socket_semaphore:
                    self.socket.sendall(encoded_frame)
            except Exception:
                _, e, _ = sys.exc_info()
                logging.error("error sending frame", exc_info=True)
                raise e
        else:
            raise exception.NotConnectedException()

    def receive(self):
        """
        :rtype: bytes
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        try:
            return self.socket.recv(self.__recv_bytes)
        except socket.error:
            _, e, _ = sys.exc_info()
            if get_errno(e) in (errno.EAGAIN, errno.EINTR):
                logging.debug("socket read interrupted, restarting")
                raise exception.InterruptedException()
            if self.is_connected():
                raise

    def cleanup(self):
        """
        Close the socket and clear the current host and port details.
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        try:
            self.socket.close()
        except:
            pass  # ignore errors when attempting to close socket
        self.socket = None

    def __enable_keepalive(self):
        def try_setsockopt(sock, name, fam, opt, val=None):
            if val is None:
                return True  # no value to set always works
            try:
                sock.setsockopt(fam, opt, val)
                logging.debug("keepalive: set %r option to %r on socket", name, val)
            except:
                logging.error("keepalive: unable to set %r option to %r on socket", name, val)
                return False
            return True

        ka = self.__keepalive

        if not ka:
            return

        if ka is True:
            ka_sig = "auto"
            ka_args = ()
        else:
            try:
                ka_sig = ka[0]
                ka_args = ka[1:]
            except Exception:
                logging.error("keepalive: bad specification %r", ka)
                return

        if ka_sig == "auto":
            if LINUX_KEEPALIVE_AVAIL:
                ka_sig = "linux"
                ka_args = None
                logging.debug("keepalive: autodetected linux-style support")
            elif MAC_KEEPALIVE_AVAIL:
                ka_sig = "mac"
                ka_args = None
                logging.debug("keepalive: autodetected mac-style support")
            else:
                logging.error("keepalive: unable to detect any implementation, DISABLED!")
                return

        if ka_sig == "linux":
            logging.debug("keepalive: activating linux-style support")
            if ka_args is None:
                logging.debug("keepalive: using system defaults")
                ka_args = (None, None, None)
            ka_idle, ka_intvl, ka_cnt = ka_args
            if try_setsockopt(self.socket, "enable", SOL_SOCKET, SO_KEEPALIVE, 1):
                try_setsockopt(self.socket, "idle time", SOL_TCP, TCP_KEEPIDLE, ka_idle)
                try_setsockopt(self.socket, "interval", SOL_TCP, TCP_KEEPINTVL, ka_intvl)
                try_setsockopt(self.socket, "count", SOL_TCP, TCP_KEEPCNT, ka_cnt)
        elif ka_sig == "mac":
            logging.debug("keepalive: activating mac-style support")
            if ka_args is None:
                logging.debug("keepalive: using system defaults")
                ka_args = (3,)
            ka_intvl = ka_args
            if try_setsockopt(self.socket, "enable", SOL_SOCKET, SO_KEEPALIVE, 1):
                try_setsockopt(self.socket, socket.IPPROTO_TCP, 0x10, ka_intvl)
        else:
            logging.error("keepalive: implementation %r not recognized or not supported", ka_sig)

    def attempt_connection(self):
        """
        Try connecting to the (host, port) tuples specified at construction time.
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        self.connection_error = False
        sleep_exp = 1
        connect_count = 0

        logging.debug("attempt reconnection (%s, %s, %s)", self.running, self.socket, connect_count)
        while self.running and self.socket is None and (connect_count < self.__reconnect_attempts_max or
                                                        self.__reconnect_attempts_max == -1):
            for host_and_port in self.__host_and_ports:
                try:
                    logging.debug("attempting connection to host %s, port %s", host_and_port[0], host_and_port[1])
                    if self.__bind_host_port:
                        self.socket = socket.create_connection(host_and_port, self.__timeout, self.__bind_host_port)
                    else:
                        self.socket = socket.create_connection(host_and_port, self.__timeout)
                    self.__enable_keepalive()
                    need_ssl = self.__need_ssl(host_and_port)

                    if need_ssl:  # wrap socket
                        ssl_params = self.get_ssl(host_and_port)
                        tls_context = ssl.SSLContext(DEFAULT_SSL_VERSION)
                        if ssl_params["ca_certs"]:
                            cert_validation = ssl.CERT_REQUIRED
                            tls_context.load_verify_locations(ssl_params["ca_certs"])
                        else:
                            cert_validation = ssl.CERT_NONE
                        if tls_context:
                            # Wrap the socket for TLS
                            certfile = ssl_params["cert_file"]
                            keyfile = ssl_params["key_file"]
                            password = ssl_params.get("password")
                            if certfile and not keyfile:
                                keyfile = certfile
                            if certfile:
                                tls_context.load_cert_chain(certfile, keyfile, password)
                            if cert_validation is None or cert_validation == ssl.CERT_NONE:
                                tls_context.check_hostname = False
                            tls_context.verify_mode = cert_validation
                            logging.debug("wrapping SSL socket")
                            self.socket = tls_context.wrap_socket(self.socket, server_hostname=host_and_port[0])
                        else:
                            # Old-style wrap_socket where we don't have a modern SSLContext (so no SNI)
                            logging.debug("wrapping SSL socket (old style)")
                            self.socket = ssl.wrap_socket(
                                self.socket,
                                keyfile=ssl_params["key_file"],
                                certfile=ssl_params["cert_file"],
                                cert_reqs=cert_validation,
                                ca_certs=ssl_params["ca_certs"],
                                ssl_version=ssl_params["ssl_version"])

                    self.socket.settimeout(self.__timeout)

                    if self.blocking is not None:
                        self.socket.setblocking(self.blocking)

                    #
                    # Validate server cert
                    #
                    if need_ssl and ssl_params["cert_validator"]:
                        cert = self.socket.getpeercert()
                        (ok, errmsg) = ssl_params["cert_validator"](cert, host_and_port[0])
                        if not ok:
                            raise SSLError("Server certificate validation failed: %s", errmsg)

                    self.current_host_and_port = host_and_port
                    logging.info("established connection to host %s, port %s", host_and_port[0], host_and_port[1])
                    break
                except (OSError, AssertionError):
                    self.socket = None
                    connect_count += 1
                    logging.warning("could not connect to host %s, port %s", host_and_port[0], host_and_port[1],
                                    exc_info=logging.verbose)

            if self.socket is None:
                sleep_duration = (min(self.__reconnect_sleep_max,
                                      ((self.__reconnect_sleep_initial / (1.0 + self.__reconnect_sleep_increase))
                                       * math.pow(1.0 + self.__reconnect_sleep_increase, sleep_exp)))
                                  * (1.0 + random.random() * self.__reconnect_sleep_jitter))
                sleep_end = monotonic() + sleep_duration
                logging.debug("sleeping for %.1f seconds before attempting reconnect", sleep_duration)
                while self.running and monotonic() < sleep_end:
                    time.sleep(0.2)

                if sleep_duration < self.__reconnect_sleep_max:
                    sleep_exp += 1

        if not self.socket:
            raise exception.ConnectFailedException()

    def set_ssl(self,
                for_hosts=[],
                key_file=None,
                cert_file=None,
                ca_certs=None,
                cert_validator=None,
                ssl_version=DEFAULT_SSL_VERSION,
                password=None):
        """
        Sets up SSL configuration for the given hosts. This ensures socket is wrapped in a SSL connection, raising an
        exception if the SSL module can't be found.

        :param for_hosts: a list of tuples describing hosts this SSL configuration should be applied to
        :param cert_file: the path to a X509 certificate
        :param key_file: the path to a X509 key file
        :param ca_certs: the path to the a file containing CA certificates to validate the server against.
                         If this is not set, server side certificate validation is not done.
        :param cert_validator: function which performs extra validation on the client certificate, for example
                               checking the returned certificate has a commonName attribute equal to the
                               hostname (to avoid man in the middle attacks).
                               The signature is: (OK, err_msg) = validation_function(cert, hostname)
                               where OK is a boolean, and cert is a certificate structure
                               as returned by ssl.SSLSocket.getpeercert()
        :param ssl_version: SSL protocol to use for the connection. This should be one of the PROTOCOL_x
                            constants provided by the ssl module. The default is ssl.PROTOCOL_TLSv1
        :param password: SSL password
        """
        if getattr(self, '_bounded_mode', False):
            raise BoundedError('legacy-path')
        if not ssl:
            raise Exception("SSL connection requested, but SSL library not found")

        for host_port in for_hosts:
            self.__ssl_params[host_port] = dict(key_file=key_file,
                                                cert_file=cert_file,
                                                ca_certs=ca_certs,
                                                cert_validator=cert_validator,
                                                ssl_version=ssl_version,
                                                password=password)

    def __need_ssl(self, host_and_port=None):
        """
        Whether current host needs SSL or not.

        :param (str,int) host_and_port: the host/port pair to check, default current_host_and_port
        """
        if not host_and_port:
            host_and_port = self.current_host_and_port

        return host_and_port in self.__ssl_params

    def get_ssl(self, host_and_port=None):
        """
        Get SSL params for the given host.

        :param (str,int) host_and_port: the host/port pair we want SSL params for, default current_host_and_port
        """
        if not host_and_port:
            host_and_port = self.current_host_and_port

        return self.__ssl_params.get(host_and_port)
