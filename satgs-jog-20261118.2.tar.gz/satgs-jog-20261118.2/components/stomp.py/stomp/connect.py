"""Main entry point for clients to create a STOMP connection.

Provides connection classes for `1.0 <http://stomp.github.io/stomp-specification-1.0.html>`_,
`1.1 <http://stomp.github.io/stomp-specification-1.1.html>`_, and
`1.2 <http://stomp.github.io/stomp-specification-1.2.html>`_ versions of the STOMP protocol.
"""

from stomp.protocol import *
from stomp.transport import *
from stomp.utils import get_uuid


class BaseConnection(Publisher):
    """
    Base class for all connection classes.
    """

    def __init__(self, transport):
        """
        :param Transport transport:
        """
        self.transport = transport

    def __enter__(self):
        if getattr(self.transport, "_bounded_mode", False):
            raise BoundedError("legacy-path")
        self.disconnect_receipt_id = get_uuid()
        self.disconnect_listener = WaitingListener(self.disconnect_receipt_id)
        self.set_listener("ZZZZZ-disconnect-listener", self.disconnect_listener)
        return self

    def disconnect(self, receipt=None, headers=None, **keyword_headers): pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect(self.disconnect_receipt_id)
        self.disconnect_listener.wait_on_receipt()
        self.disconnect_listener.wait_on_disconnected()

    def set_listener(self, name, listener):
        """
        :param str name:
        :param ConnectionListener listener:
        """
        self.transport.set_listener(name, listener)

    def remove_listener(self, name):
        """
        :param str name:
        """
        self.transport.remove_listener(name)

    def get_listener(self, name):
        """
        :param str name:

        :rtype: ConnectionListener
        """
        return self.transport.get_listener(name)

    def is_connected(self):
        """
        :rtype: bool
        """
        return self.transport.is_connected()

    def set_receipt(self, receipt_id, value):
        self.transport.set_receipt(receipt_id, value)

    def set_ssl(self, *args, **kwargs):
        self.transport.set_ssl(*args, **kwargs)

    def get_ssl(self, host_and_port=None):
        return self.transport.get_ssl(host_and_port)


class StompConnection10(BaseConnection, Protocol10):
    """
    Represents a 1.0 connection (comprising transport plus 1.0 protocol class).
    See :py:class:`stomp.transport.Transport` for details on the initialisation parameters.
    """
    def __init__(self,
                 host_and_ports=None,
                 prefer_localhost=True,
                 try_loopback_connect=True,
                 reconnect_sleep_initial=0.1,
                 reconnect_sleep_increase=0.5,
                 reconnect_sleep_jitter=0.1,
                 reconnect_sleep_max=60.0,
                 reconnect_attempts_max=3,
                 timeout=None,
                 keepalive=None,
                 auto_decode=True,
                 encoding="utf-8",
                 auto_content_length=True,
                 bind_host_port=None):
        transport = Transport(host_and_ports, prefer_localhost, try_loopback_connect,
                              reconnect_sleep_initial, reconnect_sleep_increase, reconnect_sleep_jitter,
                              reconnect_sleep_max, reconnect_attempts_max, timeout,
                              keepalive, None, auto_decode, encoding, bind_host_port=bind_host_port)
        BaseConnection.__init__(self, transport)
        Protocol10.__init__(self, transport, auto_content_length)

    def connect(self, *args, **kwargs):
        self.transport.start()
        Protocol10.connect(self, *args, **kwargs)

    def disconnect(self, receipt=None, headers=None, **keyword_headers):
        """
        Call the protocol disconnection, and then stop the transport itself.

        :param str receipt: the receipt to use with the disconnect
        :param dict headers: a map of any additional headers to send with the disconnection
        :param keyword_headers: any additional headers to send with the disconnection
        """
        Protocol10.disconnect(self, receipt, headers, **keyword_headers)
        if receipt is not None:
            self.transport.stop()


class StompConnection11(BaseConnection, Protocol11):
    """
    Represents a 1.1 connection (comprising transport plus 1.1 protocol class)
    See :py:class:`stomp.transport.Transport` for details on the initialisation parameters.
    """
    @classmethod
    def open_bounded(cls, *, dial_address, port, tls_identity, ssl_context,
                     username, passcode, vhost=None, deadline, cancel):
        if cls is not StompConnection11:
            raise BoundedError("admission")
        return cls._open_bounded('tls', dial_address, port, tls_identity, ssl_context,
                                 username, passcode, vhost, deadline, cancel)

    @classmethod
    def open_loopback_bounded(cls, *, dial_address, port, username, passcode,
                              vhost=None, deadline, cancel):
        if cls is not StompConnection11:
            raise BoundedError("admission")
        return cls._open_bounded('loopback-plaintext', dial_address, port, None, None,
                                 username, passcode, vhost, deadline, cancel)

    @classmethod
    def _open_bounded(cls, mode, dial_address, port, tls_identity, ssl_context,
                      username, passcode, vhost, deadline, cancel):
        if (cls is not StompConnection11 or type(mode) is not str
                or mode not in ('tls', 'loopback-plaintext')):
            raise BoundedError("admission")
        Protocol11._bounded_connect_headers(username, passcode, vhost)
        transport = Transport([(dial_address, port)], prefer_localhost=False,
                              try_loopback_connect=False, auto_decode=False, vhost=vhost)
        transport._init_bounded(cancel, endpoint=(mode, dial_address, port, tls_identity))
        error = None
        try:
            connection = cls.__new__(cls)
            BaseConnection.__init__(connection, transport)
            connection.version = "1.1"
            connection.auto_content_length = True
            if mode == 'tls':
                transport.acquire_bounded(dial_address, port, tls_identity, ssl_context,
                                          deadline=deadline, cancel=cancel)
            else:
                if tls_identity is not None or ssl_context is not None:
                    raise BoundedError("admission")
                transport.acquire_loopback_bounded(dial_address, port, deadline=deadline, cancel=cancel)
            connection.connect_bounded(username, passcode, deadline=deadline, cancel=cancel)
            transport.observe_connected_bounded(deadline=deadline, cancel=cancel)
            transport._commit_open_bounded(deadline=deadline, cancel=cancel)
        except BaseException as failure:
            primary = failure.primary if type(failure) is BoundedError else transport._bounded_phase
            error = transport._rollback_bounded(primary)
        if error is not None:
            raise error from None
        return connection

    @property
    def bounded_endpoint(self):
        return self.transport.bounded_endpoint

    def close_bounded(self, *, deadline):
        return self.transport.abort_bounded(deadline=deadline)

    def __init__(self,
                 host_and_ports=None,
                 prefer_localhost=True,
                 try_loopback_connect=True,
                 reconnect_sleep_initial=0.1,
                 reconnect_sleep_increase=0.5,
                 reconnect_sleep_jitter=0.1,
                 reconnect_sleep_max=60.0,
                 reconnect_attempts_max=3,
                 timeout=None,
                 heartbeats=(0, 0),
                 keepalive=None,
                 vhost=None,
                 auto_decode=True,
                 encoding="utf-8",
                 auto_content_length=True,
                 heart_beat_receive_scale=1.5,
                 bind_host_port=None):
        transport = Transport(host_and_ports, prefer_localhost, try_loopback_connect,
                              reconnect_sleep_initial, reconnect_sleep_increase, reconnect_sleep_jitter,
                              reconnect_sleep_max, reconnect_attempts_max, timeout,
                              keepalive, vhost, auto_decode, encoding, bind_host_port=bind_host_port)
        BaseConnection.__init__(self, transport)
        Protocol11.__init__(self, transport, heartbeats, auto_content_length,
                            heart_beat_receive_scale=heart_beat_receive_scale)

    def connect(self, *args, **kwargs):
        if getattr(self.transport, "_bounded_mode", False):
            raise BoundedError("legacy-path")
        self.transport.start()
        Protocol11.connect(self, *args, **kwargs)

    def disconnect(self, receipt=None, headers=None, **keyword_headers):
        """
        Call the protocol disconnection, and then stop the transport itself.

        :param str receipt: the receipt to use with the disconnect
        :param dict headers: a map of any additional headers to send with the disconnection
        :param keyword_headers: any additional headers to send with the disconnection
        """
        if getattr(self.transport, "_bounded_mode", False):
            raise BoundedError("legacy-path")
        Protocol11.disconnect(self, receipt, headers, **keyword_headers)
        if receipt is not None:
            self.transport.stop()


class StompConnection12(BaseConnection, Protocol12):
    """
    Represents a 1.2 connection (comprising transport plus 1.2 protocol class).
    See :py:class:`stomp.transport.Transport` for details on the initialisation parameters.
    """
    def __init__(self,
                 host_and_ports=None,
                 prefer_localhost=True,
                 try_loopback_connect=True,
                 reconnect_sleep_initial=0.1,
                 reconnect_sleep_increase=0.5,
                 reconnect_sleep_jitter=0.1,
                 reconnect_sleep_max=60.0,
                 reconnect_attempts_max=3,
                 timeout=None,
                 heartbeats=(0, 0),
                 keepalive=None,
                 vhost=None,
                 auto_decode=True,
                 encoding="utf-8",
                 auto_content_length=True,
                 heart_beat_receive_scale=1.5,
                 bind_host_port=None):
        transport = Transport(host_and_ports, prefer_localhost, try_loopback_connect,
                              reconnect_sleep_initial, reconnect_sleep_increase, reconnect_sleep_jitter,
                              reconnect_sleep_max, reconnect_attempts_max, timeout,
                              keepalive, vhost, auto_decode, encoding, bind_host_port=bind_host_port)
        BaseConnection.__init__(self, transport)
        Protocol12.__init__(self, transport, heartbeats, auto_content_length,
                            heart_beat_receive_scale=heart_beat_receive_scale)

    def connect(self, *args, **kwargs):
        self.transport.start()
        Protocol12.connect(self, *args, **kwargs)

    def disconnect(self, receipt=None, headers=None, **keyword_headers):
        """
        Call the protocol disconnection, and then stop the transport itself.

        :param str receipt: the receipt to use with the disconnect
        :param dict headers: a map of any additional headers to send with the disconnection
        :param keyword_headers: any additional headers to send with the disconnection
        """
        Protocol12.disconnect(self, receipt, headers, **keyword_headers)
        if receipt is not None:
            self.transport.stop()

    @staticmethod
    def is_eol(c):
        return c == b"\x0a" or c == b"\x0d\x0a"
