========
stomp.py
========

.. image:: https://badge.fury.io/py/stomp.py.svg
    :target: https://badge.fury.io/py/stomp.py
    :alt: PyPI version

"stomp.py" is a Python client library for accessing messaging servers (such as ActiveMQ_, Artemis_ or RabbitMQ_) using the STOMP_ protocol (`STOMP v1.0`_, `STOMP v1.1`_ and `STOMP v1.2`_). It can also be run as a standalone, command-line client for testing.  NOTE: Stomp.py has officially ended support for Python2.x. See `python3statement.org`_ for more information. 

.. contents:: \ 
    :depth: 1


Unreleased local Stage A candidate
=================================

This plain-source candidate amends the verified stomp.py 8.1.0 baseline. Inherited
package metadata identifies that baseline, not a release of these amended bytes.
No version, release identifier, production contract or artifact has been allocated.
The external Stage A evidence manifest binds baseline, candidate, patch and
source-only websocket-client 1.3.1 prerequisite identities. It also records actual
validation results; this README does not certify tests, independent acceptance or
deployment readiness. The inherited broker examples and installation instructions
below are not the offline Stage A validation procedure.

The additive STOMP 1.1 lower interface is::

    StompConnection11.open_bounded(
        *, dial_address, port, tls_identity, ssl_context,
        username, passcode, vhost=None, deadline, cancel)
    StompConnection11.open_loopback_bounded(
        *, dial_address, port, username, passcode,
        vhost=None, deadline, cancel)
    connection.send_bounded(destination, body, priority=None, *, deadline, cancel)
    connection.subscribe_bounded(destination, id, *, deadline, cancel, dispatch)
    connection.unsubscribe_bounded(id, *, deadline, cancel)
    connection.close_bounded(*, deadline)

``open_bounded`` consumes already-admitted lower inputs: one canonical unscoped
numeric IPv4/IPv6 address, a separate ASCII TLS identity, optional STOMP virtual host and
a privately owned, unmodified SSLContext with certificate/hostname verification
and TLS 1.2 or newer. There is no DNS, address rotation, plaintext fallback,
default-root preparation or reconnect on this path. Context preparation and
public-CA provenance are caller preconditions, not established by inspecting the
context flags. Meteor's single-use prepared control, CA parsing/settings binding,
registration API and borrowed-instance admission are not implemented here. This
lower API does not satisfy unchanged R1's factory or allocate a revised contract.

The separately approved local bench amendment adds ``open_loopback_bounded``.
It accepts only the exact string ``127.0.0.1`` and an exact integer port from
1 through 65535. Hostnames, other loopback addresses, IPv6, wildcard/remote
addresses and TLS arguments are rejected. This explicit path uses plaintext:
credentials and message bodies are not encrypted, and the broker's identity is
not authenticated. Local processes remain inside its trust boundary. The caller
must separately arrange a broker listener bound only to loopback. This API does
not provision, start or inspect a broker and does not qualify physical operations.

Both factories expose a read-only ``connection.bounded_endpoint`` tuple:
``('tls', dial_address, port, tls_identity)`` or
``('loopback-plaintext', '127.0.0.1', port, None)``. The tuple is bound before
acquisition and cannot be changed through the public interface. There is no
mode switch, reacquisition, TLS-to-plaintext fallback, DNS or reconnect. Existing
``open_bounded`` still requires verified TLS even for a loopback address. Legacy
``set_ssl`` rejects bounded instances. Diagnostics do not include the endpoint
tuple or credentials.

Acquisition completes TCP, TLS when explicitly selected, and validated CONNECTED
synchronously without a worker. The first strict subscription retains and starts one receiver after the
usable connection has been returned. Concurrent subscribers observe successful
startup admission under their own original controls before wire effects or local
commit; a retained worker or finished failed/late startup is not admission.
Its audited internal ``dispatch(wire_id,
frame)`` receives ``(command, headers, body_bytes, wire_size_bytes)``; the last
element is an integer byte count. Reuse the same retained dispatch function or
bound-method object. This is not a public application-listener registration API.
The caller retains strong ownership of callbacks and bound-method receivers
through completed cancellation/close. Dispatch runs outside internal locks;
arbitrary callback execution cannot be forcibly bounded or terminated.
The plaintext receiver uses nonblocking raw-socket readiness and receive calls;
only the TLS path consults SSL pending bytes. Framing, pending-message limits,
operation controls, worker ownership and passive cleanup are shared.

Acquisition retains the exact ordinary threading.Event supplied at open as its
lifecycle Event. After open succeeds, each active operation may supply a different
exact threading.Event with its original absolute monotonic deadline. Subclasses
and duck-typed control objects reject before use. Every active boundary observes
the original lifecycle Event first, then the operation Event, terminal state and
deadline. Lifecycle cancellation remains terminal. A distinct operation Event
cancels that invocation without itself setting or clearing the lifecycle gate.
Callers must not clear an operation Event while its invocation remains active.
Event polling does not latch a transient set/clear between observations.

Each operation retains its original deadline; equality is expired and retries
do not create another budget. A nonpositive recomputed remaining budget rejects
before readiness polling, timed lock acquisition or close-observer waits, while
mandatory immediate passive abort and bookkeeping remain available.

A cancelled pending startup waiter can leave the startup owner and siblings
unaffected. The caller that has reserved receiver startup can still fail
terminally, even before Thread.start or wire effects. Failed/late startup,
uncertain native send progress and terminal connection faults retain their shared
abort behavior. Independent operation cancellation does not guarantee that a
shared connection survives those effects or that submitted data is undone.

Operation Events are not subscription-lifetime tokens. The receiver retains the
original lifecycle Event; setting a completed subscription's operation Event
does not unregister it or stop sibling callbacks. Explicit unsubscribe uses its
own admitted operation Event and supplied deadline. Terminal state prevents
further work and reconnect. Passive close ignores set Events and
does not send DISCONNECT, await receipts or unwrap TLS. Normal return certifies
observed socket, operation, callback, startup and actual receiver completion.
Incomplete/self-close raises BoundedError with fixed primary/cleanup categories
and retains visible debt on the returned instance; a later close needs an
explicit new deadline. An expired close can still attempt immediate passive
release but cannot report timely success. Failed open has no worker and performs
mandatory immediate rollback without a new waiting budget.

Strict limits include exact bytes bodies up to 262,144 bytes, exact string topics
of 1-256 characters/1,024 UTF-8 bytes, exact integer priorities 0-9 or None, and
credentials up to 1,024 characters/4,096 UTF-8 bytes each. Wire controls and
unsupported subclasses/serialization hooks are rejected. Lower storage admits
64 concurrent operation tickets, 128 live/pending/debt wire IDs, monotonically
increasing non-reused IDs through 2**63-1, and eight pending frames totaling at
most 1,048,576 bytes. Frames have at most a 32-byte command, 64 headers/8,192
header bytes, six content-length digits and a 270,400-byte total cap.
Reads are at most 16,384 bytes; incomplete buffering is capped at 286,784 bytes.
Dial addresses, TLS identities and virtual hosts are limited to 45, 253 and 255
ASCII characters respectively. Polling is at most 10 ms and never exceeds the
remaining budget. Meteor's 256-registration limit, callback identifiers of
0-256 characters/1,024 UTF-8 bytes and 65,536-byte public-CA preparation limit
remain future owner-layer obligations.

``connection.transport.diagnostics_bounded()`` returns fixed local data with 32
saturating counters capped at 2**31-1 and separate primary/cleanup fields.
Strict lifecycle work does not invoke global logging handlers or export payloads,
credentials, endpoint strings or raw exceptions. Presentation is separate caller work. Legacy call
forms and keyword headers remain available on legacy instances, without bounded
guarantees; legacy wire methods reject strict instances before processing inputs.
Strict context-manager entry rejects with ``legacy-path`` before legacy setup;
it does not close the caller's instance. Use explicit ``close_bounded`` instead.

Native non-lingering close, nonblocking TCP/TLS/readiness, scheduling, Thread.start
and CPython completion-record visibility still require qualification. A fake
close failure demonstrates failed reclamation qualification, not successful
cleanup. Thread.start is non-preemptible despite pre/post checks. Python 3.6
compatibility, Python 3.11/ARM64 execution, real trust/broker behavior and target
performance are unqualified by controlled current-interpreter tests.

The narrow suite, from this source directory, is::

    python -B -m unittest discover -s tests -p 'test_bounded_*.py' -v

Stage A instead runs those same unittest arguments through its inspected,
self-tested offline bootstrap::

    /usr/bin/python3 -B -s -S <evidence>/runtime-guard/guarded_entry.py suite

The evidence root is
``/workspace/.codex-transfer/context/messenger-stage-a-resume-20260923-l6Q1oVgZ``.
Its controller establishes ``STOMP_SKIP_HOSTNAME_SCAN=1`` before any package
import, suppresses bytecode/user-site processing and selects this exact source
directory with ``STAGE_A_STOMP_ROOT``. It admits only the verified prerequisite
at ``<evidence>/prerequisites/source/websocket-client-1.3.1`` after source review,
sets ``STAGE_A_WEBSOCKET_ADMITTED=1`` and points ``SATGS_RUNTIME_OUTPUT`` at the
fresh evidence runtime-output directory. Uncontrolled Python/loader paths are
excluded. Normal package initializers run under the guard. DNS, native sockets,
services, devices, FFI, uncontrolled children and out-of-root writes remain
denied. Passing suite output alone is insufficient if independent guard records
show a caught denial. Tests use explicit socket/TLS/clock substitutes and retained
real workers, not live endpoints or an installed package.


Quick Start
===========

You can connect to a message broker running on the local machine, and send a message using the following example.

.. code-block:: python

  import stomp

  conn = stomp.Connection()
  conn.connect('admin', 'password', wait=True)
  conn.send(body=' '.join(sys.argv[1:]), destination='/queue/test')
  conn.disconnect()


Documentation and Resources
===========================

- `Main documentation`_
- `API documentation`_ (see `stomp.github.io`_ for details on the STOMP protocol itself)
- A basic example of using stomp.py with a message listener can be found in the `quick start`_ section of the main documentation
- Description of the `command-line interface`_
- `Travis`_ for continuous integration builds
- Current `test coverage report`_
- `PyPi stomp.py page`_

The current version of stomp.py supports:

- Python 3.x (Python2 support ended as of Jan 2020)
- STOMP version 1.0, 1.1 and 1.2

There is also legacy 3.1.7 version using the old 3-series code (see `3.1.7 on PyPi`_ and `3.1.7 on GitHub`_). This is no longer supported, but (at least as of 2018) there were still a couple of reports of this version still being used in the wild.

Note: stomp.py now follows `semantic versioning`_:

- MAJOR version for incompatible API changes,
- MINOR version for functionality added in a backwards compatible manner, and
- PATCH version for backwards compatible bug fixes.



Testing
=======

stomp.py has been perfunctorily tested on:

- Pivotal `RabbitMQ`_   (`test_rabbitmq.py <https://github.com/jasonrbriggs/stomp.py/blob/dev/tests/test_rabbitmq.py>`_)
- Apache `ActiveMQ`_   (`test_activemq.py <https://github.com/jasonrbriggs/stomp.py/blob/dev/tests/test_activemq.py>`_)
- Apache ActiveMQ `Artemis`_  (`test_artemis.py <https://github.com/jasonrbriggs/stomp.py/blob/dev/tests/test_artemis.py>`_)
- `stompserver`_  (`test_stompserver.py <https://github.com/jasonrbriggs/stomp.py/blob/dev/tests/test_stompserver.py>`_)

For testing locally, you'll need to install docker (or `podman`_). Once installed:

#. Install dependencies:
        ``poetry install``
#. Create the docker (or podman) image:
        ``make docker-image`` (or ``make podman-image``)
#. Run the container:
        ``make run-docker`` (or ``make run-podman``)
#. Run stomp.py unit tests:
        ``make test``
#. Cleanup the container afterwards if you don't need it any more:
        ``make remove-docker`` (or ``make remove-podman``)

If you want to connect to the test services locally (other than from the included tests), you'll want to add test domain names to your hosts file like so:
      |  172.17.0.2  my.example.com
      |  172.17.0.2  my.example.org
      |  172.17.0.2  my.example.net

If you're using `podman`_ and you want to access services via their private IP addresses, you'll want to run your commands with::

  podman unshare --rootless-netns <command>

so that <command> has access to the private container network. Service ports are also exposed to the host and can be accessed directly.


.. _`STOMP`: http://stomp.github.io
.. _`STOMP v1.0`: http://stomp.github.io/stomp-specification-1.0.html
.. _`STOMP v1.1`: http://stomp.github.io/stomp-specification-1.1.html
.. _`STOMP v1.2`: http://stomp.github.io/stomp-specification-1.2.html
.. _`python3statement.org`: http://python3statement.org/

.. _`Main documentation`: http://jasonrbriggs.github.io/stomp.py/index.html
.. _`stomp.github.io`: http://stomp.github.io/
.. _`quick start`: http://jasonrbriggs.github.io/stomp.py/quickstart.html
.. _`command-line interface`: http://jasonrbriggs.github.io/stomp.py/commandline.html
.. _`PyPi stomp.py page`: https://pypi.org/project/stomp.py/
.. _`API documentation`: http://jasonrbriggs.github.io/stomp.py/api.html
.. _`test coverage report`: http://jasonrbriggs.github.io/stomp.py/htmlcov/
.. _`Travis`: https://travis-ci.org/jasonrbriggs/stomp.py

.. _`3.1.7 on PyPi`: https://pypi.org/project/stomp.py/3.1.7/
.. _`3.1.7 on GitHub`: https://github.com/jasonrbriggs/stomp.py/tree/stomppy-3series

.. _`ActiveMQ`:  http://activemq.apache.org/
.. _`Artemis`: https://activemq.apache.org/components/artemis/
.. _`RabbitMQ`: http://www.rabbitmq.com
.. _`stompserver`: http://stompserver.rubyforge.org

.. _`semantic versioning`: https://semver.org/

.. _`podman`: https://podman.io/
