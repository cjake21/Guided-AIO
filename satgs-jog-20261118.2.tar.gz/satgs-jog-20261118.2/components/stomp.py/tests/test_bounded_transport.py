import errno
import socket
import ssl
import threading
import time
import unittest
import sys
from collections import deque
from contextlib import ExitStack
from unittest import mock

from stomp import transport
from stomp.connect import StompConnection11


CONNECTED = b'CONNECTED\nversion:1.1\nheart-beat:0,0\n\n\x00'
CANARY = 'PRIVATE_OWNER_EXCEPTION_CANARY'


class Clock:
    def __init__(self, value=10.0):
        self.value = value

    def __call__(self):
        return self.value

    def advance(self, delta):
        self.value += delta


class FakeRawSocket:
    """A scripted primitive, never a substitute for lower lifecycle decisions."""
    def __init__(self, harness, name, resource):
        self.harness = harness
        self.name = name
        self.resource = resource
        self.detached = False
        self.close_calls = 0
        self.blocking = []
        self.sent = []
        self.connect_calls = []
        self.recv_sizes = []
        self.send_script = deque()
        self.recv_script = deque()
        self.handshake_script = deque()
        self.connect_result = 0
        self.socket_error = 0
        self.close_error = None
        self.on_close = None

    @property
    def closed(self):
        return self.detached or self.resource['closed']

    @staticmethod
    def _result(action):
        if isinstance(action, BaseException):
            raise action
        return action() if callable(action) else action

    def setblocking(self, value):
        self.blocking.append(value)
        hook = self.harness.hooks.get(self.name + '-blocking')
        if hook:
            hook()

    def connect_ex(self, address):
        self.connect_calls.append(address)
        hook = self.harness.hooks.get('connect')
        if hook:
            hook()
        return self._result(self.connect_result)

    def getsockopt(self, level, option):
        if (level, option) != (socket.SOL_SOCKET, socket.SO_ERROR):
            raise AssertionError('unexpected native option')
        return self._result(self.socket_error)

    def send(self, data):
        if self.resource['closed']:
            raise OSError('controlled closed socket')
        hook = self.harness.hooks.get('send')
        if hook:
            hook()
        amount = self._result(self.send_script.popleft()) if self.send_script else len(data)
        if amount is None:
            amount = len(data)
        self.sent.append(bytes(data[:amount]))
        return amount

    def recv(self, amount):
        self.recv_sizes.append(amount)
        if self.resource['closed']:
            raise OSError('controlled closed socket')
        hook = self.harness.hooks.get('recv')
        if hook:
            hook()
        if not self.recv_script:
            self._empty_read()
        value = self._result(self.recv_script.popleft())
        if type(value) is bytes and len(value) > amount:
            self.recv_script.appendleft(value[amount:])
            return value[:amount]
        return value

    def close(self):
        self.close_calls += 1
        if self.on_close:
            self.on_close()
        if self.close_error:
            raise self.close_error
        if not self.detached:
            self.resource['closed'] = True

    def _empty_read(self):
        raise BlockingIOError()

    def shutdown(self, how):
        raise AssertionError('passive release must not await shutdown')

    def sendall(self, data):
        raise AssertionError('strict writes must report partial progress')


class FakeSocket(FakeRawSocket):
    def do_handshake(self):
        self.harness.handshakes += 1
        if self.handshake_script:
            self._result(self.handshake_script.popleft())
        hook = self.harness.hooks.get('handshake')
        if hook:
            hook()

    def pending(self):
        if self.recv_script and type(self.recv_script[0]) is bytes:
            return len(self.recv_script[0])
        return 0

    def _empty_read(self):
        raise ssl.SSLWantReadError()

    def unwrap(self):
        raise AssertionError('passive release must not unwrap')


class FakeTLSContext:
    def __init__(self, harness):
        self.harness = harness
        self.verify_mode = ssl.CERT_REQUIRED
        self.check_hostname = True
        self.minimum_version = getattr(ssl, 'TLSVersion', None)
        if self.minimum_version is not None:
            self.minimum_version = self.minimum_version.TLSv1_2
        self.options = ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1

    def wrap_socket(self, raw, server_hostname=None, do_handshake_on_connect=True, **kwargs):
        self.harness.wraps.append((raw, server_hostname, do_handshake_on_connect, kwargs))
        hook = self.harness.hooks.get('wrap')
        if hook:
            hook()
        raw.detached = True
        return self.harness.tls


class PrimitiveHarness:
    def __init__(self, incoming=CONNECTED, real_time=False, loopback=False):
        self.clock = Clock()
        self.real_time = real_time
        self.loopback = loopback
        self.real_monotonic = time.monotonic
        self.real_sleep = time.sleep
        self.cancel = threading.Event()
        self.hooks = {}
        self.allocations = []
        self.wraps = []
        self.handshakes = 0
        self.waits = []
        self.resource = {'closed': False}
        self.raw = (FakeRawSocket if loopback else FakeSocket)(self, 'raw', self.resource)
        self.tls = FakeSocket(self, 'tls', self.resource)
        self.wire = self.raw if loopback else self.tls
        self.wire.recv_script.append(incoming)
        self.context = FakeTLSContext(self)
        self.stack = ExitStack()

    def now(self):
        return self.real_monotonic() if self.real_time else self.clock()

    def deadline(self, seconds=1.0):
        return self.now() + seconds

    def allocate(self, *args, **kwargs):
        self.allocations.append((args, kwargs))
        hook = self.hooks.get('allocate')
        if hook:
            hook()
        return self.raw

    def readiness(self, reads, writes, errors, timeout):
        if timeout < 0 or timeout > 0.010000001:
            raise AssertionError('readiness timeout exceeds policy')
        self.waits.append(timeout)
        hook = self.hooks.get('wait')
        if hook:
            hook()
        if writes:
            return [], writes, []
        if self.wire.recv_script:
            return reads, [], []
        if self.real_time:
            self.real_sleep(min(timeout, 0.001))
        else:
            self.clock.advance(max(timeout, 0.000001))
        return [], [], []

    def __enter__(self):
        self.stack.enter_context(mock.patch.object(transport.socket, 'socket', self.allocate))
        self.stack.enter_context(mock.patch.object(transport.ssl, 'SSLContext', FakeTLSContext))
        if self.loopback:
            self.stack.enter_context(mock.patch.object(FakeTLSContext, 'wrap_socket',
                side_effect=AssertionError('TLS wrapping forbidden for loopback')))
        self.stack.enter_context(mock.patch.object(transport.select, 'select', self.readiness))
        if not self.real_time:
            self.stack.enter_context(mock.patch.object(transport.time, 'monotonic', self.clock))
            self.stack.enter_context(mock.patch.object(transport, 'monotonic', self.clock))
        self.stack.enter_context(mock.patch.object(transport.socket, 'getaddrinfo', side_effect=AssertionError('DNS forbidden')))
        self.stack.enter_context(mock.patch.object(transport.socket, 'create_connection', side_effect=AssertionError('legacy connector forbidden')))
        return self

    def __exit__(self, kind, value, tb):
        self.stack.close()

    def open(self, **overrides):
        if self.loopback:
            values = {'dial_address': '127.0.0.1', 'port': 61613,
                      'username': 'synthetic-user', 'passcode': 'synthetic-pass',
                      'deadline': self.deadline(), 'cancel': self.cancel}
            values.update(overrides)
            return StompConnection11.open_loopback_bounded(**values)
        values = {'dial_address': '192.0.2.1', 'port': 61614, 'tls_identity': 'broker.example',
                  'ssl_context': self.context, 'username': 'synthetic-user', 'passcode': 'synthetic-pass',
                  'deadline': self.deadline(), 'cancel': self.cancel}
        values.update(overrides)
        return StompConnection11.open_bounded(**values)

    def close(self, connection):
        return connection.close_bounded(deadline=self.deadline())


class TransportEncodingTests(unittest.TestCase):
    def test_command_maximum_and_maximum_plus_one(self):
        self.assertTrue(transport._bounded_encode('X' * 32, {}, b'').startswith(b'X' * 32 + b'\n'))
        with self.assertRaises(transport.BoundedError):
            transport._bounded_encode('X' * 33, {}, b'')

    def test_header_block_maximum_and_maximum_plus_one(self):
        frame = transport._bounded_encode('SEND', {'x': 'a' * 8189}, b'')
        self.assertEqual(len(frame), 4 + 1 + 8192 + 1 + 1)
        with self.assertRaises(transport.BoundedError):
            transport._bounded_encode('SEND', {'x': 'a' * 8190}, b'')

    def test_header_count_maximum_and_maximum_plus_one(self):
        headers = {'h' + str(index): '' for index in range(64)}
        self.assertTrue(transport._bounded_encode('SEND', headers, b''))
        headers['extra'] = ''
        with self.assertRaises(transport.BoundedError):
            transport._bounded_encode('SEND', headers, b'')

    def test_body_maximum_and_maximum_plus_one(self):
        self.assertTrue(transport._bounded_encode('SEND', {}, b'x' * 262144).endswith(b'x\0'))
        with self.assertRaises(transport.BoundedError):
            transport._bounded_encode('SEND', {}, b'x' * 262145)

    def test_coupled_maximum_frame_remains_under_total_cap(self):
        frame = transport._bounded_encode('X' * 32, {'x': 'a' * 8189}, b'x' * 262144)
        self.assertEqual(len(frame), 270371)
        self.assertLessEqual(len(frame), 270400)

    def test_decimal_length_exact_six_digits_and_invalid_variants(self):
        self.assertTrue(transport._bounded_encode('SEND', {'content-length': '000000'}, b''))
        for length in ('0000000', '-1', '+0', '０', '', '1', '262145'):
            with self.subTest(length=length), self.assertRaises(transport.BoundedError):
                transport._bounded_encode('SEND', {'content-length': length}, b'')

    def test_encoded_escaping_counts_toward_header_byte_cap(self):
        self.assertTrue(transport._bounded_encode('SEND', {'x': ':' * 4094}, b''))
        with self.assertRaises(transport.BoundedError):
            transport._bounded_encode('SEND', {'x': ':' * 4095}, b'')

    def test_hostile_values_do_not_run_conversion_hooks(self):
        class Hostile:
            def __str__(self):
                raise AssertionError('arbitrary conversion')

            def __repr__(self):
                raise AssertionError('arbitrary representation')

        for command, headers, body in ((Hostile(), {}, b''), ('SEND', {'x': Hostile()}, b''),
                                       ('SEND', {}, Hostile())):
            with self.assertRaises(transport.BoundedError):
                transport._bounded_encode(command, headers, body)


class TransportAcquisitionTests(unittest.TestCase):
    def assert_safe(self, error):
        self.assertIsInstance(error, transport.BoundedError)
        self.assertNotIn(CANARY, str(error))
        self.assertNotIn(CANARY, repr(error))
        self.assertIsNone(error.__cause__)

    def test_worker_free_open_and_passive_idempotent_close(self):
        with PrimitiveHarness() as h, mock.patch.object(transport.threading.Thread, 'start', side_effect=AssertionError('worker before return')):
            connection = h.open()
            self.assertEqual(len(h.allocations), 1)
            self.assertEqual(h.raw.blocking, [False])
            self.assertEqual(h.wraps[0][1:3], ('broker.example', False))
            self.assertEqual(h.handshakes, 1)
            connection.close_bounded(deadline=h.deadline())
            connection.close_bounded(deadline=h.deadline())
            self.assertEqual(h.tls.close_calls, 1)
            self.assertEqual(h.raw.close_calls, 0)
            self.assertTrue(h.resource['closed'])
            self.assertNotIn(b'DISCONNECT', b''.join(h.tls.sent))

    def test_admission_deadline_before_equal_after(self):
        for offset in (-1.0, 0.0, 0.0001):
            with self.subTest(offset=offset), PrimitiveHarness() as h:
                if offset <= 0:
                    with self.assertRaises(transport.BoundedError) as result:
                        h.open(deadline=h.now() + offset)
                    self.assertEqual(result.exception.primary, 'deadline')
                    self.assertEqual(h.allocations, [])
                else:
                    connection = h.open(deadline=h.now() + offset)
                    connection.close_bounded(deadline=h.deadline())

    def test_invalid_deadlines_reject_before_resource_effects(self):
        for value in (True, None, '12', float('nan'), float('inf'), -float('inf')):
            with self.subTest(value=value), PrimitiveHarness() as h:
                with self.assertRaises(transport.BoundedError):
                    h.open(deadline=value)
                self.assertEqual(h.allocations, [])

    def test_already_cancelled_has_no_resource_effects(self):
        with PrimitiveHarness() as h:
            h.cancel.set()
            with self.assertRaises(transport.BoundedError) as result:
                h.open()
            self.assertEqual(result.exception.primary, 'cancelled')
            self.assertEqual(h.allocations, [])

    def test_hostname_scoped_noncanonical_and_oversize_address_rejected(self):
        for address in ('broker.example', '::1%eth0', '192.000.2.1', '1' * 46):
            with self.subTest(address=address), PrimitiveHarness() as h:
                with self.assertRaises(transport.BoundedError):
                    h.open(dial_address=address)
                self.assertEqual(h.allocations, [])

    def test_ipv6_uses_one_numeric_endpoint(self):
        with PrimitiveHarness() as h:
            connection = h.open(dial_address='2001:db8::1')
            self.assertEqual(h.allocations[0][0][0], socket.AF_INET6)
            self.assertEqual(h.raw.connect_calls, [('2001:db8::1', 61614, 0, 0)])
            connection.close_bounded(deadline=h.deadline())

    def test_unverified_context_rejects_before_allocation(self):
        for field, value in (('verify_mode', ssl.CERT_NONE), ('check_hostname', False)):
            with self.subTest(field=field), PrimitiveHarness() as h:
                setattr(h.context, field, value)
                with self.assertRaises(transport.BoundedError):
                    h.open()
                self.assertEqual(h.allocations, [])

    def test_late_native_success_is_failure_and_reclaims_exact_owner(self):
        for phase in ('allocate', 'raw-blocking', 'connect', 'wrap', 'tls-blocking', 'handshake', 'send', 'recv'):
            with self.subTest(phase=phase), PrimitiveHarness() as h:
                h.hooks[phase] = lambda: h.clock.advance(2.0)
                with self.assertRaises(transport.BoundedError) as result:
                    h.open()
                self.assertEqual(result.exception.primary, 'deadline')
                self.assertTrue(h.resource['closed'])
                self.assertEqual(h.raw.close_calls + h.tls.close_calls, 1)

    def test_cancellation_during_every_native_phase_reclaims_owner(self):
        for phase in ('allocate', 'raw-blocking', 'connect', 'wrap', 'tls-blocking', 'handshake', 'send', 'recv'):
            with self.subTest(phase=phase), PrimitiveHarness() as h:
                h.hooks[phase] = h.cancel.set
                with self.assertRaises(transport.BoundedError) as result:
                    h.open()
                self.assertEqual(result.exception.primary, 'cancelled')
                self.assertTrue(h.resource['closed'])
                self.assertEqual(h.raw.close_calls + h.tls.close_calls, 1)

    def test_failed_wrap_and_handshake_preserve_safe_primary_and_cleanup(self):
        for phase in ('wrap', 'handshake'):
            with self.subTest(phase=phase), PrimitiveHarness() as h:
                def fail():
                    raise ssl.SSLError(CANARY)
                h.hooks[phase] = fail
                with self.assertRaises(transport.BoundedError) as result:
                    h.open()
                self.assert_safe(result.exception)
                self.assertTrue(h.resource['closed'])
                self.assertEqual(h.raw.close_calls + h.tls.close_calls, 1)

    def test_connect_completion_checks_socket_error(self):
        with PrimitiveHarness() as h:
            h.raw.connect_result = errno.EINPROGRESS
            h.raw.socket_error = errno.ECONNREFUSED
            with self.assertRaises(transport.BoundedError) as result:
                h.open()
            self.assertEqual(result.exception.primary, 'tcp')
            self.assertEqual(h.raw.close_calls, 1)
            self.assertEqual(h.wraps, [])

    def test_connect_inprogress_and_tls_want_read_write_keep_budget(self):
        with PrimitiveHarness() as h:
            h.raw.connect_result = errno.EINPROGRESS
            h.tls.handshake_script.extend((ssl.SSLWantReadError(), ssl.SSLWantWriteError(), None))
            connection = h.open()
            self.assertEqual(h.handshakes, 3)
            self.assertTrue(h.waits)
            self.assertTrue(all(0 <= value <= 0.01 for value in h.waits))
            connection.close_bounded(deadline=h.deadline())

    def test_invalid_connected_error_eof_and_premature_message_reclaim(self):
        for frame in (b'', b'ERROR\nmessage:' + CANARY.encode() + b'\n\n\x00',
                      b'MESSAGE\nsubscription:1\n\nx\x00', b'CONNECTED\nversion:1.2\n\n\x00'):
            with self.subTest(frame=frame[:20]), PrimitiveHarness(frame) as h:
                with self.assertRaises(transport.BoundedError) as result:
                    h.open()
                self.assert_safe(result.exception)
                self.assertTrue(h.resource['closed'])

    def test_fake_abort_failure_is_failed_reclamation_qualification(self):
        with PrimitiveHarness(b'ERROR\n\n\x00') as h:
            h.tls.close_error = OSError(CANARY)
            with self.assertRaises(transport.BoundedError) as result:
                h.open()
            self.assert_safe(result.exception)
            self.assertIn('socket-release', result.exception.cleanup)
            self.assertFalse(h.resource['closed'], 'this fault must not masquerade as proven no-leak release')
            h.tls.close_error = None
            h.tls.close()
            self.assertTrue(h.resource['closed'], 'test fixture explicitly reclaims its controlled resource')


class TransportWireTests(unittest.TestCase):
    def test_partial_send_preserves_byte_order_without_sendall(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            h.tls.sent[:] = []
            h.tls.send_script.extend((1, 2, 3))
            connection.send_bounded('/topic/demo', b'payload', deadline=h.deadline(), cancel=h.cancel)
            wire = b''.join(h.tls.sent)
            self.assertTrue(wire.startswith(b'SEND\n'))
            self.assertTrue(wire.endswith(b'payload\x00'))
            self.assertNotIn(b'deadline:', wire)
            self.assertNotIn(b'cancel:', wire)
            connection.close_bounded(deadline=h.deadline())

    def test_partial_send_failure_poison_prevents_later_frames(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            h.tls.send_script.extend((2, OSError(CANARY)))
            with self.assertRaises(transport.BoundedError):
                connection.send_bounded('/topic/demo', b'payload', deadline=h.deadline(), cancel=h.cancel)
            count = len(h.tls.sent)
            with self.assertRaises(transport.BoundedError):
                connection.send_bounded('/topic/demo', b'later', deadline=h.deadline(), cancel=h.cancel)
            self.assertEqual(len(h.tls.sent), count)
            self.assertTrue(h.resource['closed'])
            connection.close_bounded(deadline=h.deadline())

    def test_zero_send_terminal_failure_and_passive_release(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            h.tls.send_script.append(0)
            with self.assertRaises(transport.BoundedError):
                connection.send_bounded('/topic/demo', b'x', deadline=h.deadline(), cancel=h.cancel)
            self.assertTrue(h.resource['closed'])
            connection.close_bounded(deadline=h.deadline())

    def test_late_full_send_does_not_report_success(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            h.hooks['send'] = lambda: h.clock.advance(2.0)
            with self.assertRaises(transport.BoundedError) as result:
                connection.send_bounded('/topic/demo', b'x', deadline=h.deadline(), cancel=h.cancel)
            self.assertEqual(result.exception.primary, 'deadline')
            self.assertTrue(h.resource['closed'])
            h.hooks.clear()
            connection.close_bounded(deadline=h.deadline())

    def test_lifecycle_cancel_is_terminal_and_close_remains_passive(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            h.cancel.set()
            with self.assertRaises(transport.BoundedError) as result:
                connection.send_bounded('/topic/demo', b'x', deadline=h.deadline(), cancel=h.cancel)
            self.assertEqual(result.exception.primary, 'cancelled')
            h.cancel.clear()
            with self.assertRaises(transport.BoundedError):
                connection.send_bounded('/topic/demo', b'x', deadline=h.deadline(), cancel=h.cancel)
            connection.close_bounded(deadline=h.deadline())
            self.assertTrue(h.resource['closed'])

    def test_strict_paths_never_call_global_logger(self):
        with PrimitiveHarness() as h, ExitStack() as patches:
            originals = {}
            for name in ('debug', 'info', 'warning', 'error', 'exception', 'isEnabledFor'):
                if hasattr(transport.logging, name):
                    originals[name] = getattr(transport.logging, name)
                    patches.enter_context(mock.patch.object(transport.logging, name, side_effect=AssertionError('global logger used')))
            connection = h.open()
            connection.send_bounded('/topic/demo', b'PRIVATE_PAYLOAD_CANARY', deadline=h.deadline(), cancel=h.cancel)
            connection.close_bounded(deadline=h.deadline())
        for name, original in originals.items():
            self.assertIs(getattr(transport.logging, name), original)


class AdvancingLock:
    def __init__(self, clock):
        self.clock = clock
        self.waits = []

    def acquire(self, blocking=True, timeout=-1):
        self.waits.append(timeout)
        if not blocking:
            return False
        if timeout < 0 or timeout > 0.010000001:
            raise AssertionError('unbudgeted lock wait')
        self.clock.advance(timeout)
        return False

    def release(self):
        raise AssertionError('unacquired controlled lock released')


class TransportCompletionTests(unittest.TestCase):
    def test_independent_state_frame_and_io_contention_expire(self):
        for name in ('_bounded_state_lock', '_bounded_frame_lock', '_bounded_io_lock'):
            with self.subTest(lock=name), PrimitiveHarness() as h:
                connection = h.open()
                lower = connection.transport
                original = getattr(lower, name)
                controlled = AdvancingLock(h.clock)
                setattr(lower, name, controlled)
                count = len(h.tls.sent)
                try:
                    with self.assertRaises(transport.BoundedError):
                        connection.send_bounded('/topic/demo', b'x', deadline=h.deadline(0.02), cancel=h.cancel)
                    self.assertEqual(len(h.tls.sent), count)
                    self.assertTrue(controlled.waits)
                    self.assertTrue(all(ticket.done for ticket in lower._bounded_tickets))
                finally:
                    setattr(lower, name, original)
                    connection.close_bounded(deadline=h.deadline())

    def test_ticket_limit_64_and_65_before_wire_effects(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            lower._bounded_tickets[:] = [transport._BoundedTicket() for _ in range(63)]
            connection.send_bounded('/topic/demo', b'at-capacity', deadline=h.deadline(), cancel=h.cancel)
            self.assertLessEqual(len(lower._bounded_tickets), 64)
            lower._bounded_tickets[:] = [transport._BoundedTicket() for _ in range(64)]
            count = len(h.tls.sent)
            try:
                with self.assertRaises(transport.BoundedError) as result:
                    connection.send_bounded('/topic/demo', b'excess', deadline=h.deadline(), cancel=h.cancel)
                self.assertEqual(result.exception.primary, 'operation-limit')
                self.assertEqual(len(h.tls.sent), count)
                self.assertEqual(len(lower._bounded_tickets), 64)
            finally:
                for ticket in lower._bounded_tickets:
                    ticket.done = True
                connection.close_bounded(deadline=h.deadline())

    def test_final_accounting_does_not_wait_for_contended_state_lock(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            def contend_and_expire():
                lower._bounded_state_lock.acquire()
                h.clock.advance(2.0)
            h.hooks['send'] = contend_and_expire
            try:
                with self.assertRaises(transport.BoundedError) as result:
                    connection.send_bounded('/topic/demo', b'x', deadline=h.deadline(), cancel=h.cancel)
                self.assertEqual(result.exception.primary, 'deadline')
                self.assertTrue(lower._bounded_tickets)
                self.assertTrue(all(ticket.done for ticket in lower._bounded_tickets))
            finally:
                h.hooks.clear()
                if lower._bounded_state_lock.locked():
                    lower._bounded_state_lock.release()
                connection.close_bounded(deadline=h.deadline())

    def test_close_bypasses_frame_lock_and_gates_before_io_contention(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            lower._bounded_frame_lock.acquire()
            try:
                connection.close_bounded(deadline=h.deadline())
                self.assertTrue(h.resource['closed'])
            finally:
                lower._bounded_frame_lock.release()
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            original = lower._bounded_io_lock
            lower._bounded_io_lock = AdvancingLock(h.clock)
            try:
                with self.assertRaises(transport.BoundedError):
                    connection.close_bounded(deadline=h.deadline(0.02))
                self.assertTrue(lower._bounded_gate)
                self.assertFalse(h.resource['closed'])
            finally:
                lower._bounded_io_lock = original
                connection.close_bounded(deadline=h.deadline())
            self.assertEqual(h.tls.close_calls, 1)

    def test_expired_close_releases_but_cannot_claim_timely_success(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            with self.assertRaises(transport.BoundedError) as result:
                connection.close_bounded(deadline=h.now())
            self.assertEqual(result.exception.primary, 'deadline')
            self.assertTrue(h.resource['closed'])
            connection.close_bounded(deadline=h.deadline())
            self.assertEqual(h.tls.close_calls, 1)

    def test_close_error_retains_socket_debt_until_explicit_retry(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            h.tls.close_error = OSError(CANARY)
            with self.assertRaises(transport.BoundedError) as result:
                connection.close_bounded(deadline=h.deadline())
            self.assertIn('socket-release', result.exception.cleanup)
            self.assertFalse(h.resource['closed'])
            self.assertIs(connection.transport.socket, h.tls)
            h.tls.close_error = None
            connection.close_bounded(deadline=h.deadline())
            self.assertTrue(h.resource['closed'])

    def test_ledger_contention_and_failure_cannot_replace_primary(self):
        for broken in (False, True):
            with self.subTest(broken=broken), PrimitiveHarness() as h:
                connection = h.open()
                lower = connection.transport
                original = lower._bounded_ledger_lock
                if broken:
                    class BrokenLedgerLock:
                        def acquire(self, blocking=True):
                            raise OSError(CANARY)
                    lower._bounded_ledger_lock = BrokenLedgerLock()
                else:
                    original.acquire()
                try:
                    h.tls.send_script.append(OSError(CANARY))
                    with self.assertRaises(transport.BoundedError) as result:
                        connection.send_bounded('/topic/demo', b'x', deadline=h.deadline(), cancel=h.cancel)
                    self.assertEqual(result.exception.primary, 'send')
                    self.assertNotIn(CANARY, str(result.exception))
                    self.assertTrue(h.resource['closed'])
                finally:
                    lower._bounded_ledger_lock = original
                    if not broken:
                        original.release()
                    connection.close_bounded(deadline=h.deadline())

    def test_diagnostic_32_counters_saturate_without_payload(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            index = transport._BOUNDED_CODES.index('send')
            self.assertEqual(len(lower._bounded_counters), 32)
            lower._bounded_counters[index] = 2 ** 31 - 2
            lower._record_bounded('send')
            self.assertEqual(lower._bounded_counters[index], 2 ** 31 - 1)
            lower._record_bounded('send')
            self.assertEqual(lower._bounded_counters[index], 2 ** 31 - 1)
            self.assertEqual(len(lower.diagnostics_bounded()['counters']), 32)
            connection.close_bounded(deadline=h.deadline())


class TransportFramingTests(unittest.TestCase):
    def test_incremental_and_multiple_frames_preserve_wire_order(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            lower._feed_bounded(b'MESS')
            self.assertIsNone(lower._extract_bounded())
            lower._feed_bounded(b'AGE\nsubscription:1\ncontent-length:1\n\nx\0MESSAGE\nsubscription:2\n\ny\0')
            first, second = lower._extract_bounded(), lower._extract_bounded()
            self.assertEqual((first[0], first[1]['subscription'], first[2]), ('MESSAGE', '1', b'x'))
            self.assertEqual((second[0], second[1]['subscription'], second[2]), ('MESSAGE', '2', b'y'))
            self.assertIsNone(lower._extract_bounded())
            connection.close_bounded(deadline=h.deadline())


class TransportWorkerTests(unittest.TestCase):
    def finish_worker(self, connection, harness, release=None):
        if release is not None:
            release.set()
        connection.transport._bounded_gate = True
        worker = connection.transport._bounded_receiver
        if worker is not None and worker.ident is not None:
            worker.join(2.0)
            self.assertFalse(worker.is_alive(), 'controlled test worker must actually finish')
        connection.close_bounded(deadline=harness.deadline())

    def test_receiver_begins_only_after_first_subscription(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            lower = connection.transport
            received = []
            entered = threading.Event()
            def dispatch(*args):
                received.append(args)
                entered.set()
            try:
                self.assertIsNone(lower._bounded_receiver)
                connection.subscribe_bounded('/topic/demo', 1, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                worker = lower._bounded_receiver
                self.assertIsInstance(worker, threading.Thread)
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\ncontent-length:1\n\nx\0')
                self.assertTrue(entered.wait(1.0))
                self.assertEqual(len(received), 1)
                connection.close_bounded(deadline=h.deadline())
                self.assertFalse(worker.is_alive())
                self.assertTrue(h.resource['closed'])
            finally:
                self.finish_worker(connection, h)

    def test_active_callback_prevents_false_close_success_until_release(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            entered, release = threading.Event(), threading.Event()
            callback_outcomes = []
            def dispatch(*args):
                entered.set()
                callback_outcomes.append(release.wait(2.0))
            try:
                connection.subscribe_bounded('/topic/demo', 1, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0')
                self.assertTrue(entered.wait(1.0))
                with self.assertRaises(transport.BoundedError) as result:
                    connection.close_bounded(deadline=h.deadline(0.03))
                self.assertIn('active-callback', result.exception.cleanup)
                self.assertIn('worker-live', result.exception.cleanup)
                self.assertTrue(h.resource['closed'])
                self.assertTrue(connection.transport._bounded_receiver.is_alive())
            finally:
                self.finish_worker(connection, h, release)
            self.assertEqual(callback_outcomes, [True])

    def test_callback_self_close_reports_non_quiescence_without_self_join(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            completed = threading.Event()
            results = []
            def dispatch(*args):
                try:
                    connection.close_bounded(deadline=h.deadline())
                except transport.BoundedError as error:
                    results.append((error.primary, error.cleanup))
                finally:
                    completed.set()
            try:
                connection.subscribe_bounded('/topic/demo', 1, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0')
                self.assertTrue(completed.wait(1.0))
                self.assertEqual(len(results), 1)
                self.assertIn('worker-live', results[0][1])
                self.assertTrue(h.resource['closed'])
            finally:
                self.finish_worker(connection, h)

    def test_callback_exception_is_fixed_and_worker_actually_finishes(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            entered = threading.Event()
            def dispatch(*args):
                entered.set()
                raise ValueError(CANARY)
            try:
                connection.subscribe_bounded('/topic/demo', 1, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0')
                self.assertTrue(entered.wait(1.0))
                worker = connection.transport._bounded_receiver
                worker.join(1.0)
                self.assertFalse(worker.is_alive())
                self.assertEqual(connection.transport._bounded_primary, 'callback')
                self.assertNotIn(CANARY, repr(connection.transport.diagnostics_bounded()))
            finally:
                self.finish_worker(connection, h)

    def test_worker_exit_flag_does_not_replace_actual_completion(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            lower = connection.transport
            entered, release = threading.Event(), threading.Event()
            def controlled_finalizer():
                lower._BaseTransport__receiver_thread_exited = True
                entered.set()
                release.wait(2.0)
            worker = threading.Thread(target=controlled_finalizer)
            lower._bounded_receiver = worker
            worker.start()
            try:
                self.assertTrue(entered.wait(1.0))
                with self.assertRaises(transport.BoundedError) as result:
                    connection.close_bounded(deadline=h.deadline(0.03))
                self.assertIn('worker-live', result.exception.cleanup)
                self.assertTrue(worker.is_alive())
            finally:
                self.finish_worker(connection, h, release)

    def test_late_start_retains_real_handle_and_visible_completion_debt(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            release, waiting = threading.Event(), threading.Event()
            actual_start = threading.Thread.start
            def controlled_wait():
                waiting.set()
                release.wait(2.0)
            def late_start(worker):
                actual_start(worker)
                self.assertTrue(waiting.wait(1.0))
                h.clock.advance(2.0)
            h.hooks['wait'] = controlled_wait
            try:
                with mock.patch.object(threading.Thread, 'start', late_start):
                    with self.assertRaises(transport.BoundedError):
                        connection.subscribe_bounded('/topic/demo', 1, deadline=h.deadline(), cancel=h.cancel, dispatch=lambda *args: None)
                self.assertIsInstance(connection.transport._bounded_receiver, threading.Thread)
                self.assertTrue(connection.transport._bounded_gate)
                self.assertTrue(connection.transport._bounded_receiver.is_alive())
            finally:
                h.hooks.clear()
                self.finish_worker(connection, h, release)

    def test_concurrent_close_has_one_owned_abort(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            start = threading.Event()
            outcomes = []
            def close():
                if not start.wait(1.0):
                    outcomes.append('test-barrier-timeout')
                    return
                try:
                    connection.close_bounded(deadline=h.deadline())
                    outcomes.append('closed')
                except BaseException as error:
                    outcomes.append(type(error).__name__)
            workers = [threading.Thread(target=close) for _ in range(2)]
            try:
                for worker in workers:
                    worker.start()
                start.set()
                for worker in workers:
                    worker.join(2.0)
                    self.assertFalse(worker.is_alive())
                self.assertEqual(outcomes, ['closed', 'closed'])
                self.assertEqual(h.tls.close_calls, 1)
                self.assertTrue(h.resource['closed'])
            finally:
                start.set()
                for worker in workers:
                    if worker.ident is not None:
                        worker.join(2.0)
                        self.assertFalse(worker.is_alive())
                connection.close_bounded(deadline=h.deadline())

class TransportFramingBoundaryTests(unittest.TestCase):
    @staticmethod
    def feed(lower, data):
        for offset in range(0, len(data), 16384):
            lower._feed_bounded(data[offset:offset + 16384])

    def test_content_length_duplicates_inconsistency_and_seven_digits_reject(self):
        cases = (b'MESSAGE\ncontent-length:1\ncontent-length:1\n\nx\0',
                 b'MESSAGE\ncontent-length:1\n\nxy\0',
                 b'MESSAGE\ncontent-length:0000000\n\n\0',
                 b'MESSAGE\ncontent-length:262145\n\n')
        for data in cases:
            with self.subTest(data=data), PrimitiveHarness() as h:
                connection = h.open()
                try:
                    with self.assertRaises(transport.BoundedError):
                        self.feed(connection.transport, data)
                        connection.transport._extract_bounded()
                finally:
                    connection.close_bounded(deadline=h.deadline())

    def test_receive_body_maximum_and_maximum_plus_one(self):
        for size in (262144, 262145):
            with self.subTest(size=size), PrimitiveHarness() as h:
                connection = h.open()
                data = b'MESSAGE\n\n' + b'x' * size + b'\0'
                try:
                    if size == 262144:
                        self.feed(connection.transport, data)
                        self.assertEqual(len(connection.transport._extract_bounded()[2]), size)
                    else:
                        with self.assertRaises(transport.BoundedError):
                            self.feed(connection.transport, data)
                            connection.transport._extract_bounded()
                finally:
                    connection.close_bounded(deadline=h.deadline())

    def test_receive_command_header_bytes_and_header_count_boundaries(self):
        cases = ((b'X' * 32 + b'\n\n\0', True), (b'X' * 33 + b'\n\n\0', False),
                 (b'MESSAGE\nx:' + b'a' * 8189 + b'\n\n\0', True),
                 (b'MESSAGE\nx:' + b'a' * 8190 + b'\n\n\0', False),
                 (b'MESSAGE\n' + b''.join(('h' + str(i) + ':\n').encode() for i in range(64)) + b'\n\0', True),
                 (b'MESSAGE\n' + b''.join(('h' + str(i) + ':\n').encode() for i in range(65)) + b'\n\0', False))
        for data, admitted in cases:
            with self.subTest(bytes=len(data), admitted=admitted), PrimitiveHarness() as h:
                connection = h.open()
                try:
                    if admitted:
                        connection.transport._feed_bounded(data)
                        self.assertIsNotNone(connection.transport._extract_bounded())
                    else:
                        with self.assertRaises(transport.BoundedError):
                            connection.transport._feed_bounded(data)
                            connection.transport._extract_bounded()
                finally:
                    connection.close_bounded(deadline=h.deadline())

    def test_incomplete_buffer_cap_and_read_size(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            self.assertTrue(all(size <= 16384 for size in h.tls.recv_sizes))
            lower = connection.transport
            self.feed(lower, b'x' * (270400 + 16384))
            with self.assertRaises(transport.BoundedError):
                lower._feed_bounded(b'x')
            connection.close_bounded(deadline=h.deadline())

    def test_single_read_maximum_and_maximum_plus_one(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            lower._feed_bounded(b'x' * 16384)
            with self.assertRaises(transport.BoundedError):
                lower._feed_bounded(b'x' * 16385)
            connection.close_bounded(deadline=h.deadline())


class CommitPauseLock:
    def __init__(self, harness, paused, release):
        self.lock = threading.Lock()
        self.harness = harness
        self.paused = paused
        self.resume = release

    def acquire(self, blocking=True, timeout=-1):
        submitted = any(item.startswith(b'SUBSCRIBE\n') for item in self.harness.wire.sent)
        if threading.current_thread().name == 'bounded-subscribe-test' and submitted and not self.resume.is_set():
            self.paused.set()
            self.resume.wait(timeout)
            return False
        return self.lock.acquire(blocking, timeout)

    def release(self):
        self.lock.release()


class TransportReviewedRegressionTests(unittest.TestCase):
    def test_native_receive_failure_is_not_misclassified_as_callback(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            callbacks = []
            entered = threading.Event()
            try:
                connection.subscribe_bounded('topic', 1, deadline=h.deadline(), cancel=h.cancel,
                                             dispatch=lambda *args: callbacks.append(args))
                h.hooks['recv'] = entered.set
                h.tls.recv_script.append(OSError(CANARY))
                self.assertTrue(entered.wait(1))
                worker = connection.transport._bounded_receiver
                worker.join(1)
                self.assertFalse(worker.is_alive())
                self.assertEqual(callbacks, [])
                self.assertTrue(h.resource['closed'])
                self.assertEqual(connection.transport._bounded_primary, 'receive')
                self.assertNotIn(CANARY, repr(connection.transport.diagnostics_bounded()))
            finally:
                connection.close_bounded(deadline=h.deadline())

    def test_concurrent_unsubscribe_has_one_wire_effect(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            entered, release = threading.Event(), threading.Event()
            outcomes = []
            caller = None
            def hold_send():
                if threading.current_thread().name == 'bounded-unsubscribe-test':
                    entered.set()
                    if not release.wait(2):
                        raise AssertionError('test release deadline')
            def unsubscribe():
                try:
                    connection.unsubscribe_bounded(1, deadline=h.deadline(3), cancel=h.cancel)
                    outcomes.append('ok')
                except transport.BoundedError as error:
                    outcomes.append(error.primary)
            try:
                connection.subscribe_bounded('topic', 1, deadline=h.deadline(), cancel=h.cancel, dispatch=lambda *args: None)
                h.hooks['send'] = hold_send
                caller = threading.Thread(target=unsubscribe, name='bounded-unsubscribe-test')
                caller.start()
                self.assertTrue(entered.wait(1))
                with self.assertRaises(transport.BoundedError) as error:
                    connection.unsubscribe_bounded(1, deadline=h.deadline(), cancel=h.cancel)
                self.assertEqual(error.exception.primary, 'state')
                release.set()
                caller.join(2)
                self.assertFalse(caller.is_alive())
                self.assertEqual(outcomes, ['ok'])
                self.assertEqual(b''.join(h.tls.sent).count(b'UNSUBSCRIBE\n'), 1)
                self.assertFalse(connection.transport._bounded_gate)
            finally:
                release.set()
                if caller is not None:
                    caller.join(2)
                    self.assertFalse(caller.is_alive())
                h.hooks.clear()
                connection.close_bounded(deadline=h.deadline())

    def test_topic_id_limit_includes_128_live_entries_and_nonreuse(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            lower = connection.transport
            dispatch = lambda wire_id, frame: None
            try:
                for wire_id in range(1, 129):
                    connection.subscribe_bounded('topic', wire_id, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                self.assertEqual(len(lower._bounded_topics), 128)
                before = len(h.tls.sent)
                with self.assertRaises(transport.BoundedError) as error:
                    connection.subscribe_bounded('topic', 129, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                self.assertEqual(error.exception.primary, 'topic-limit')
                self.assertEqual(len(h.tls.sent), before)
                connection.unsubscribe_bounded(1, deadline=h.deadline(), cancel=h.cancel)
                with self.assertRaises(transport.BoundedError) as error:
                    connection.subscribe_bounded('topic', 1, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                self.assertEqual(error.exception.primary, 'wire-id')
                connection.subscribe_bounded('topic', 2 ** 63 - 1, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
                self.assertEqual(lower._bounded_last_id, 2 ** 63 - 1)
                with self.assertRaises(transport.BoundedError):
                    connection.subscribe_bounded('topic', 2 ** 63, deadline=h.deadline(), cancel=h.cancel, dispatch=dispatch)
            finally:
                connection.close_bounded(deadline=h.deadline())
                self.assertFalse(lower._bounded_receiver.is_alive())

    def test_endpoint_identity_port_and_tls_compatibility_boundaries(self):
        maximum_name = '.'.join(('a' * 63, 'b' * 63, 'c' * 63, 'd' * 61))
        self.assertEqual(len(maximum_name), 253)
        with PrimitiveHarness() as h:
            connection = h.open(dial_address='2001:db88:1111:2222:3333:4444:5555:6666',
                                tls_identity=maximum_name, port=65535)
            connection.close_bounded(deadline=h.deadline())
        for overrides in ({'tls_identity': maximum_name + 'd'}, {'tls_identity': 'bad_underscore'},
                          {'tls_identity': '\u00e9.example'}, {'tls_identity': '-bad.example'},
                          {'port': 0}, {'port': 65536}, {'port': True}):
            with self.subTest(overrides=overrides), PrimitiveHarness() as h:
                with self.assertRaises(transport.BoundedError):
                    h.open(**overrides)
                self.assertEqual(h.allocations, [])
        for compatible in (True, False):
            with PrimitiveHarness() as h:
                del h.context.minimum_version
                if not compatible:
                    h.context.options = 0
                    with self.assertRaises(transport.BoundedError) as error:
                        h.open()
                    self.assertEqual(error.exception.primary, 'tls-trust')
                    self.assertEqual(h.allocations, [])
                else:
                    connection = h.open()
                    connection.close_bounded(deadline=h.deadline())

    def test_exact_final_open_commit_boundaries(self):
        for offset in (-0.0001, 0.0, 0.0001):
            with PrimitiveHarness() as h:
                lower = transport.Transport([('192.0.2.1', 61614)], prefer_localhost=False, try_loopback_connect=False)
                lower._init_bounded(h.cancel)
                lower.socket = h.tls
                if offset > 0:
                    lower._commit_open_bounded(deadline=h.now() + offset, cancel=h.cancel)
                    self.assertTrue(lower._bounded_returned)
                else:
                    with self.assertRaises(transport.BoundedError) as error:
                        lower._commit_open_bounded(deadline=h.now() + offset, cancel=h.cancel)
                    self.assertEqual(error.exception.primary, 'deadline')
                    self.assertFalse(lower._bounded_returned)
                lower.abort_bounded(deadline=h.deadline())

    def wait_until(self, predicate):
        limit = time.monotonic() + 1.0
        while not predicate() and time.monotonic() < limit:
            time.sleep(0.001)
        self.assertTrue(predicate())

    def run_pending_transition(self, cancel_pending):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            lower = connection.transport
            paused, release = threading.Event(), threading.Event()
            original = lower._bounded_state_lock
            lower._bounded_state_lock = CommitPauseLock(h, paused, release)
            received, outcomes = [], []
            def dispatch(wire_id, frame):
                received.append((wire_id, frame[2]))
            def subscribe():
                try:
                    connection.subscribe_bounded('topic', 1, deadline=h.deadline(2), cancel=h.cancel, dispatch=dispatch)
                    outcomes.append('ok')
                except transport.BoundedError as error:
                    outcomes.append(error.primary)
            caller = threading.Thread(target=subscribe, name='bounded-subscribe-test')
            try:
                caller.start()
                self.assertTrue(paused.wait(1))
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0MESSAGE\nsubscription:1\n\ny\0')
                self.wait_until(lambda: len(lower._bounded_pending) == 2)
                self.assertEqual(received, [])
                if cancel_pending:
                    connection.unsubscribe_bounded(1, deadline=h.deadline(), cancel=h.cancel)
                    self.assertEqual(lower._bounded_pending, [])
                release.set()
                caller.join(2)
                self.assertFalse(caller.is_alive())
                if cancel_pending:
                    self.assertEqual(outcomes, ['state'])
                    self.assertEqual(received, [])
                    self.assertNotIn(1, lower._bounded_topics)
                else:
                    self.assertEqual(outcomes, ['ok'])
                    self.wait_until(lambda: len(received) == 2)
                    self.assertEqual(received, [(1, b'x'), (1, b'y')])
                    self.assertEqual(lower._bounded_pending, [])
            finally:
                release.set()
                caller.join(2)
                self.assertFalse(caller.is_alive())
                lower._bounded_gate = True
                if lower._bounded_receiver is not None:
                    lower._bounded_receiver.join(2)
                    self.assertFalse(lower._bounded_receiver.is_alive())
                lower._bounded_state_lock = original
                connection.close_bounded(deadline=h.deadline())

    def test_pending_frames_drain_in_order_without_new_wire_input(self):
        self.run_pending_transition(False)

    def test_unsubscribe_pending_topic_prevents_late_activation(self):
        self.run_pending_transition(True)

    def test_pre_effect_frame_contention_preserves_connection(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            original = lower._bounded_frame_lock
            lower._bounded_frame_lock = AdvancingLock(h.clock)
            try:
                with self.assertRaises(transport.BoundedError):
                    connection.send_bounded('topic', b'x', deadline=h.deadline(0.02), cancel=h.cancel)
                self.assertFalse(lower._bounded_gate)
                self.assertFalse(h.resource['closed'])
            finally:
                lower._bounded_frame_lock = original
            connection.send_bounded('topic', b'later', deadline=h.deadline(), cancel=h.cancel)
            connection.close_bounded(deadline=h.deadline())

    def test_established_primary_survives_cleanup_deadline(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            h.tls.send_script.append(OSError(CANARY))
            with self.assertRaises(transport.BoundedError):
                connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=h.cancel)
            with self.assertRaises(transport.BoundedError) as error:
                connection.close_bounded(deadline=h.now())
            self.assertEqual(error.exception.primary, 'deadline')
            self.assertEqual(connection.transport.diagnostics_bounded()['primary'], 'send')
            connection.close_bounded(deadline=h.deadline())

    def test_ledger_release_failure_does_not_replace_primary(self):
        class BrokenRelease:
            def acquire(self, blocking=True):
                return True
            def release(self):
                raise RuntimeError(CANARY)
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            lower._bounded_ledger_lock = BrokenRelease()
            h.tls.send_script.append(OSError(CANARY))
            with self.assertRaises(transport.BoundedError) as error:
                connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=h.cancel)
            self.assertEqual(error.exception.primary, 'send')
            self.assertTrue(lower._bounded_record_failed)
            connection.close_bounded(deadline=h.deadline())

    def test_pending_count_and_byte_maxima_and_overflow_are_terminal(self):
        for sizes in ([26] * 8, [262144] * 4, [262144] * 3 + [262120]):
            with self.subTest(sizes=sizes), PrimitiveHarness() as h:
                connection = h.open()
                lower = connection.transport
                for frame_size in sizes:
                    wire = b'MESSAGE\nsubscription:1\n\n' + b'x' * (frame_size - 25) + b'\0'
                    self.assertEqual(len(wire), frame_size)
                    TransportFramingBoundaryTests.feed(lower, wire)
                    frame = lower._extract_bounded()
                    lower._queue_bounded(1, frame)
                self.assertEqual(len(lower._bounded_pending), len(sizes))
                self.assertEqual(lower._bounded_pending_bytes, sum(sizes))
                lower._feed_bounded(b'MESSAGE\nsubscription:1\n\n\0')
                excess = lower._extract_bounded()
                self.assertEqual(excess[3], 25)
                with self.assertRaises(transport.BoundedError) as error:
                    lower._queue_bounded(1, excess)
                self.assertEqual(error.exception.primary, 'pending-limit')
                self.assertTrue(lower._bounded_gate)
                self.assertEqual(len(lower._bounded_pending), len(sizes))
                connection.close_bounded(deadline=h.deadline())

    def test_rollback_queue_is_discarded_when_completion_is_reconciled(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            lower = connection.transport
            ticket = transport._BoundedTicket()
            topic = transport._BoundedTopic(ticket)
            lower._bounded_topics[1] = topic
            lower._feed_bounded(b'MESSAGE\nsubscription:1\n\nx\0')
            lower._queue_bounded(1, lower._extract_bounded())
            topic.state = 'debt'
            ticket.done = True
            lower._reconcile_bounded()
            self.assertEqual(lower._bounded_pending, [])
            self.assertEqual(lower._bounded_pending_bytes, 0)
            connection.close_bounded(deadline=h.deadline())

    def test_incoming_wire_id_alias_and_overflow_are_rejected(self):
        for value in ('0', '01', '9223372036854775808', '-1', '1x'):
            with self.subTest(value=value), PrimitiveHarness() as h:
                connection = h.open()
                with self.assertRaises(transport.BoundedError) as error:
                    connection.transport._dispatch_frame_bounded(('MESSAGE', {'subscription': value}, b'', 30))
                self.assertEqual(error.exception.primary, 'protocol')
                connection.close_bounded(deadline=h.deadline())

    def test_frame_grammar_rejects_control_aliases_and_accepts_crlf(self):
        for wire in (b'MESSAGE\r\r\n\n\0', b'MESSAGE\nx:a\vx:b\n\n\0', b'MESSAGE\nx:a\rx:b\n\n\0'):
            with PrimitiveHarness() as h:
                connection = h.open()
                connection.transport._feed_bounded(wire)
                with self.assertRaises(transport.BoundedError):
                    connection.transport._extract_bounded()
                connection.close_bounded(deadline=h.deadline())
        with PrimitiveHarness() as h:
            connection = h.open()
            connection.transport._feed_bounded(b'MESSAGE\r\nsubscription:1\r\n\r\nx\0')
            self.assertEqual(connection.transport._extract_bounded()[2], b'x')
            connection.close_bounded(deadline=h.deadline())


class PendingStartupHarness:
    def __init__(self, case, harness, outcome='success'):
        self.case = case
        self.harness = harness
        self.connection = harness.open()
        self.lower = self.connection.transport
        self.outcome = outcome
        self.entered = threading.Event()
        self.release = threading.Event()
        self.callers = []
        self.results = {}
        self.starts = []
        self.owner_deadline = harness.deadline(2)
        self.owner_late = False
        self.actual_start = threading.Thread.start
        self.dispatch = lambda *args: None
        self.patches = ExitStack()
        harness.wire.sent[:] = []

    def now(self):
        if self.owner_late and threading.current_thread().name == 'bounded-start-owner':
            return self.owner_deadline
        return self.harness.real_monotonic()

    def start(self, worker):
        if worker.name == 'stomp-bounded-receiver':
            self.starts.append(worker)
            acquired = self.lower._bounded_state_lock.acquire(False)
            if acquired:
                self.lower._bounded_state_lock.release()
            self.case.assertTrue(acquired, 'state must be released before Thread.start')
            self.entered.set()
            if not self.release.wait(2):
                raise AssertionError('controlled startup release expired')
            if self.outcome == 'failed':
                raise RuntimeError(CANARY)
            self.actual_start(worker)
            self.owner_late = self.outcome == 'late'
        else:
            self.actual_start(worker)

    def subscribe(self, wire_id, deadline=None, cancel=None):
        if deadline is None:
            deadline = self.owner_deadline if wire_id == 1 else self.harness.deadline(2)
        if cancel is None:
            cancel = self.harness.cancel

        def invoke():
            try:
                self.connection.subscribe_bounded('topic-' + str(wire_id), wire_id,
                                                  deadline=deadline, cancel=cancel,
                                                  dispatch=self.dispatch)
                self.results[wire_id] = 'ok'
            except transport.BoundedError as error:
                self.results[wire_id] = error.primary
            except BaseException as error:
                self.results[wire_id] = type(error).__name__

        name = 'bounded-start-owner' if wire_id == 1 else 'bounded-start-waiter'
        caller = threading.Thread(target=invoke, name=name)
        self.callers.append(caller)
        caller.start()
        return caller

    def pending(self, wire_id):
        limit = self.harness.real_monotonic() + 1
        while wire_id not in self.lower._bounded_topics and self.harness.real_monotonic() < limit:
            self.harness.real_sleep(.001)
        self.case.assertIn(wire_id, self.lower._bounded_topics)
        self.case.assertEqual(self.lower._bounded_topics[wire_id].state, 'pending')
        self.case.assertFalse(self.lower._bounded_startup.done)

    def join_callers(self):
        for caller in self.callers:
            caller.join(2)
            self.case.assertFalse(caller.is_alive(), 'controlled caller must finish')

    @staticmethod
    def frame(wire_id):
        value = str(wire_id).encode('ascii')
        return b'SUBSCRIBE\ndestination:topic-' + value + b'\nid:' + value + b'\nack:auto\n\n\0'

    def __enter__(self):
        def held_start(worker):
            return self.start(worker)
        self.patches.enter_context(mock.patch.object(threading.Thread, 'start', held_start))
        self.patches.enter_context(mock.patch.object(transport, 'monotonic', self.now))
        return self

    def __exit__(self, kind, value, trace):
        self.lower._bounded_gate = True
        self.release.set()
        alive = []
        try:
            for caller in self.callers:
                if caller.ident is not None:
                    caller.join(2)
                    alive.append(caller.is_alive())
            worker = self.lower._bounded_receiver
            if worker is not None and worker.ident is not None:
                worker.join(2)
                alive.append(worker.is_alive())
            self.case.assertFalse(any(alive), 'all controlled workers must finish')
            self.connection.close_bounded(deadline=self.harness.deadline())
        finally:
            self.patches.close()


class TransportStartupAdmissionTests(unittest.TestCase):
    def test_delayed_startup_admits_concurrent_and_later_subscriptions_once(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h) as p:
            p.subscribe(1)
            self.assertTrue(p.entered.wait(1))
            p.subscribe(2)
            p.pending(2)
            self.assertEqual(h.tls.sent, [])
            self.assertIsNone(p.lower._bounded_receiver.ident)
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'ok', 2: 'ok'})
            self.assertTrue(p.lower._bounded_startup.done)
            self.assertTrue(p.lower._bounded_startup.committed)
            self.assertCountEqual(h.tls.sent, [p.frame(1), p.frame(2)])
            p.connection.subscribe_bounded('topic-3', 3, deadline=h.deadline(), cancel=h.cancel,
                                            dispatch=p.dispatch)
            self.assertEqual(h.tls.sent[-1], p.frame(3))
            self.assertEqual([topic.state for topic in p.lower._bounded_topics.values()], ['active'] * 3)
            self.assertEqual(p.starts, [p.lower._bounded_receiver])

    def test_pending_waiter_uses_own_deadline_without_late_activation(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h) as p:
            p.subscribe(1)
            self.assertTrue(p.entered.wait(1))
            caller = p.subscribe(2, deadline=h.deadline(.025))
            caller.join(1)
            self.assertFalse(caller.is_alive())
            self.assertEqual(p.results, {2: 'deadline'})
            self.assertEqual(h.tls.sent, [])
            self.assertEqual(p.lower._bounded_topics[2].state, 'debt')
            self.assertFalse(p.lower._bounded_startup.done)
            self.assertFalse(p.lower._bounded_gate)
            self.assertFalse(h.resource['closed'])
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'ok', 2: 'deadline'})
            p.connection.subscribe_bounded('topic-3', 3, deadline=h.deadline(), cancel=h.cancel,
                                            dispatch=p.dispatch)
            self.assertEqual(h.tls.sent, [p.frame(1), p.frame(3)])
            self.assertEqual(p.lower._bounded_topics[2].state, 'debt')
            self.assertFalse(p.lower._bounded_topics[2].ticket.committed)
            self.assertEqual(len(p.starts), 1)

    def test_cancellation_of_pending_waiter_prevents_all_subscription_effects(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h) as p:
            p.subscribe(1)
            self.assertTrue(p.entered.wait(1))
            waiter = p.subscribe(2)
            p.pending(2)
            h.cancel.set()
            waiter.join(1)
            self.assertFalse(waiter.is_alive())
            self.assertEqual(p.results[2], 'cancelled')
            self.assertTrue(h.resource['closed'])
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'cancelled', 2: 'cancelled'})
            self.assertEqual(h.tls.sent, [])
            self.assertTrue(p.lower._bounded_startup.done)
            self.assertFalse(p.lower._bounded_startup.committed)
            self.assertTrue(all(topic.state == 'debt' for topic in p.lower._bounded_topics.values()))

    def test_failed_startup_cannot_admit_waiter_or_restart_receiver(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h, 'failed') as p:
            p.subscribe(1)
            self.assertTrue(p.entered.wait(1))
            p.subscribe(2)
            p.pending(2)
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'worker-start', 2: 'disconnected'})
            self.assertEqual(h.tls.sent, [])
            self.assertTrue(p.lower._bounded_startup.done)
            self.assertFalse(p.lower._bounded_startup.committed)
            self.assertIsNone(p.lower._bounded_receiver.ident)
            self.assertTrue(all(topic.state == 'debt' for topic in p.lower._bounded_topics.values()))
            with self.assertRaises(transport.BoundedError) as error:
                p.connection.subscribe_bounded('topic-3', 3, deadline=h.deadline(), cancel=h.cancel,
                                                dispatch=p.dispatch)
            self.assertEqual(error.exception.primary, 'disconnected')
            self.assertEqual(len(p.starts), 1)
            self.assertEqual(h.tls.sent, [])

    def test_late_startup_ident_and_done_do_not_admit_waiter(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h, 'late') as p:
            p.subscribe(1)
            self.assertTrue(p.entered.wait(1))
            p.subscribe(2)
            p.pending(2)
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'deadline', 2: 'disconnected'})
            self.assertIsNotNone(p.lower._bounded_receiver.ident)
            self.assertTrue(p.lower._bounded_startup.done)
            self.assertFalse(p.lower._bounded_startup.committed)
            self.assertEqual(h.tls.sent, [])
            self.assertTrue(h.resource['closed'])
            self.assertTrue(all(topic.state == 'debt' for topic in p.lower._bounded_topics.values()))
            self.assertEqual(len(p.starts), 1)

    def test_close_during_pending_startup_exposes_debt_and_blocks_waiter(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h) as p:
            p.subscribe(1)
            self.assertTrue(p.entered.wait(1))
            p.subscribe(2)
            p.pending(2)
            with self.assertRaises(transport.BoundedError) as error:
                p.connection.close_bounded(deadline=h.deadline(.025))
            self.assertEqual(error.exception.primary, 'deadline')
            self.assertIn('worker-start-pending', error.exception.cleanup)
            self.assertIn('active-operation', error.exception.cleanup)
            self.assertTrue(h.resource['closed'])
            self.assertEqual(h.tls.sent, [])
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'disconnected', 2: 'disconnected'})
            self.assertFalse(p.lower._bounded_startup.committed)
            self.assertEqual(h.tls.sent, [])
            self.assertTrue(all(topic.state == 'debt' for topic in p.lower._bounded_topics.values()))

    def test_tombstoned_pending_waiter_never_becomes_active_after_start(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h) as p:
            p.subscribe(1)
            self.assertTrue(p.entered.wait(1))
            p.subscribe(2)
            p.pending(2)
            topic = p.lower._bounded_topics[2]
            p.connection.unsubscribe_bounded(2, deadline=h.deadline(), cancel=h.cancel)
            self.assertNotIn(2, p.lower._bounded_topics)
            self.assertEqual(h.tls.sent, [b'UNSUBSCRIBE\nid:2\n\n\0'])
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'ok', 2: 'state'})
            self.assertEqual(h.tls.sent, [b'UNSUBSCRIBE\nid:2\n\n\0', p.frame(1)])
            self.assertNotIn(2, p.lower._bounded_topics)
            self.assertEqual(topic.state, 'debt')
            self.assertFalse(topic.ticket.committed)
            self.assertFalse(p.lower._bounded_gate)


class RecomputedBudgetClock:
    def __init__(self, harness, target, boundary, lock=None, cancel=False, rollback=False):
        self.harness = harness
        self.target = target
        self.boundary = boundary
        self.lock = lock
        self.cancel = cancel
        self.rollback = rollback
        self.crossings = 0

    def __call__(self):
        caller = sys._getframe(1)
        if caller.f_code.co_name == '_remaining_bounded':
            caller = caller.f_back
        matches = caller.f_code.co_name == self.target
        if self.lock is not None:
            matches = matches and caller.f_locals.get('lock') is self.lock
        if matches and not self.crossings:
            self.crossings += 1
            self.harness.clock.value = 10.0 if self.rollback else self.boundary
            if self.cancel:
                self.harness.cancel.set()
            return self.boundary
        return self.harness.clock()


class RecomputedBudgetLock:
    def __init__(self, harness, contended=False):
        self.harness = harness
        self.contended = contended
        self.native = threading.Lock()
        self.timed = []
        self.immediate = 0

    def acquire(self, blocking=True, timeout=-1):
        if not blocking:
            self.immediate += 1
            return False if self.contended else self.native.acquire(False)
        if not 0 <= timeout <= .010000001:
            raise AssertionError('unbudgeted detector lock wait')
        self.timed.append(timeout)
        if self.contended:
            self.harness.clock.advance(timeout)
            return False
        return self.native.acquire(False)

    def release(self):
        self.native.release()


class TransportRecomputedBudgetTests(unittest.TestCase):
    def test_factory_readiness_recomputation_before_equal_after(self):
        for phase in ('connect', 'handshake-read', 'handshake-write', 'connected'):
            for offset in (-.0001, 0.0, .0001):
                with self.subTest(phase=phase, offset=offset), PrimitiveHarness() as h:
                    if phase == 'connect':
                        h.raw.connect_result = errno.EINPROGRESS
                    elif phase.startswith('handshake'):
                        h.tls.handshake_script.append(ssl.SSLWantReadError() if phase.endswith('read') else ssl.SSLWantWriteError())
                    else:
                        h.tls.recv_script.appendleft(ssl.SSLWantReadError())
                    clock = RecomputedBudgetClock(h, '_wait_bounded', 11.0 + offset)
                    connection = None
                    try:
                        with mock.patch.object(transport, 'monotonic', clock):
                            if offset < 0:
                                connection = h.open(deadline=11.0)
                            else:
                                with self.assertRaises(transport.BoundedError) as error:
                                    h.open(deadline=11.0)
                                self.assertEqual(error.exception.primary, 'deadline')
                        self.assertEqual(clock.crossings, 1)
                        if offset < 0:
                            self.assertTrue(h.waits)
                            self.assertTrue(all(0 < timeout <= .000100001 for timeout in h.waits))
                        else:
                            self.assertEqual(h.waits, [])
                            self.assertTrue(h.resource['closed'])
                            self.assertEqual(h.raw.close_calls + h.tls.close_calls, 1)
                    finally:
                        if connection is not None:
                            connection.close_bounded(deadline=h.deadline())

    def test_factory_cancellation_and_clock_rollback_preserve_expiry_admission(self):
        for boundary in (11.0, 11.0001):
            for cancel in (False, True):
                for rollback in (False, True):
                    with self.subTest(boundary=boundary, cancel=cancel, rollback=rollback), PrimitiveHarness() as h:
                        h.raw.connect_result = errno.EINPROGRESS
                        clock = RecomputedBudgetClock(h, '_wait_bounded', boundary, cancel=cancel, rollback=rollback)
                        with mock.patch.object(transport, 'monotonic', clock):
                            with self.assertRaises(transport.BoundedError) as error:
                                h.open(deadline=11.0)
                        self.assertEqual(error.exception.primary, 'cancelled' if cancel else 'deadline')
                        self.assertEqual(clock.crossings, 1)
                        self.assertEqual(h.waits, [])
                        self.assertTrue(h.resource['closed'])
                        self.assertEqual(h.raw.close_calls, 1)

    def test_interrupted_and_spurious_readiness_reuse_original_positive_budget(self):
        with PrimitiveHarness() as h:
            h.raw.connect_result = errno.EINPROGRESS
            waits = []

            def readiness(reads, writes, errors, timeout):
                waits.append(timeout)
                if len(waits) <= 2:
                    h.clock.advance(.004)
                    if len(waits) == 1:
                        raise InterruptedError()
                    return [], [], []
                return h.readiness(reads, writes, errors, timeout)

            with mock.patch.object(transport.select, 'select', readiness):
                connection = h.open(deadline=10.015)
            try:
                self.assertEqual(len(waits), 3)
                for actual, expected in zip(waits, (.010, .010, .007)):
                    self.assertAlmostEqual(actual, expected)
            finally:
                connection.close_bounded(deadline=h.deadline())

    def test_state_frame_io_lock_recomputation_before_equal_after(self):
        for name in ('_bounded_state_lock', '_bounded_frame_lock', '_bounded_io_lock'):
            for offset in (-.0001, 0.0, .0001):
                for contended in (False, True):
                    with self.subTest(lock=name, offset=offset, contended=contended), PrimitiveHarness() as h:
                        connection = h.open()
                        lower = connection.transport
                        original = getattr(lower, name)
                        detector = RecomputedBudgetLock(h, contended)
                        setattr(lower, name, detector)
                        h.tls.sent[:] = []
                        clock = RecomputedBudgetClock(h, '_lock_bounded', 11.0 + offset, detector)
                        try:
                            with mock.patch.object(transport, 'monotonic', clock):
                                if offset < 0 and not contended:
                                    connection.send_bounded('topic', b'x', deadline=11.0, cancel=h.cancel)
                                else:
                                    with self.assertRaises(transport.BoundedError) as error:
                                        connection.send_bounded('topic', b'x', deadline=11.0, cancel=h.cancel)
                                    self.assertEqual(error.exception.primary, 'deadline')
                            self.assertEqual(clock.crossings, 1)
                            self.assertEqual(len(detector.timed), 1 if offset < 0 else 0)
                            expected = [b'SEND\ndestination:topic\ncontent-length:1\n\nx\0'] if offset < 0 and not contended else []
                            self.assertEqual(h.tls.sent, expected)
                            self.assertFalse(lower._bounded_gate)
                            self.assertTrue(all(ticket.done for ticket in lower._bounded_tickets))
                        finally:
                            setattr(lower, name, original)
                            connection.close_bounded(deadline=h.deadline())

    def test_lock_cancellation_at_recomputed_expiry_precedes_deadline(self):
        for name in ('_bounded_state_lock', '_bounded_frame_lock', '_bounded_io_lock'):
            with self.subTest(lock=name), PrimitiveHarness() as h:
                connection = h.open()
                lower = connection.transport
                original = getattr(lower, name)
                detector = RecomputedBudgetLock(h)
                setattr(lower, name, detector)
                h.tls.sent[:] = []
                clock = RecomputedBudgetClock(h, '_lock_bounded', 11.0, detector, cancel=True)
                try:
                    with mock.patch.object(transport, 'monotonic', clock):
                        with self.assertRaises(transport.BoundedError) as error:
                            connection.send_bounded('topic', b'x', deadline=11.0, cancel=h.cancel)
                    self.assertEqual(error.exception.primary, 'cancelled')
                    self.assertEqual(detector.timed, [])
                    self.assertEqual(h.tls.sent, [])
                    self.assertTrue(lower._bounded_gate)
                    self.assertTrue(h.resource['closed'])
                finally:
                    setattr(lower, name, original)
                    connection.close_bounded(deadline=h.deadline())

    def test_close_join_and_sleep_recomputation_before_equal_after(self):
        for kind in ('join', 'sleep'):
            for offset in (-.0001, 0.0, .0001):
                with self.subTest(kind=kind, offset=offset), PrimitiveHarness() as h:
                    connection = h.open()
                    lower = connection.transport
                    release, entered = threading.Event(), threading.Event()
                    worker, ticket = None, None
                    waits = []
                    if kind == 'join':
                        def held_worker():
                            entered.set()
                            release.wait(2)
                        worker = threading.Thread(target=held_worker)
                        lower._bounded_receiver = worker
                        worker.start()
                        actual_join = worker.join

                        def observe(timeout):
                            waits.append(timeout)
                            actual_join(timeout)
                            h.clock.advance(timeout)
                        patch = mock.patch.object(worker, 'join', observe)
                    else:
                        ticket = transport._BoundedTicket()
                        lower._bounded_tickets.append(ticket)

                        def observe(timeout):
                            waits.append(timeout)
                            h.clock.advance(timeout)
                        patch = mock.patch.object(transport.time, 'sleep', observe)
                    clock = RecomputedBudgetClock(h, 'abort_bounded', 11.0 + offset)
                    try:
                        if worker is not None:
                            self.assertTrue(entered.wait(1))
                        with mock.patch.object(transport, 'monotonic', clock), patch:
                            with self.assertRaises(transport.BoundedError) as error:
                                connection.close_bounded(deadline=11.0)
                        self.assertEqual(error.exception.primary, 'deadline')
                        self.assertEqual(clock.crossings, 1)
                        self.assertEqual(len(waits), 1 if offset < 0 else 0)
                        self.assertTrue(h.resource['closed'])
                        self.assertEqual(h.tls.close_calls, 1)
                        self.assertIn('worker-live' if worker is not None else 'active-operation', error.exception.cleanup)
                    finally:
                        release.set()
                        if ticket is not None:
                            ticket.done = True
                        if worker is not None:
                            worker.join(2)
                            self.assertFalse(worker.is_alive())
                        connection.close_bounded(deadline=h.deadline())

    def test_close_io_expiry_preserves_immediate_abort_and_visible_debt(self):
        for offset in (-.0001, 0.0, .0001):
            with self.subTest(recompute=offset), PrimitiveHarness() as h:
                connection = h.open()
                lower = connection.transport
                original = lower._bounded_io_lock
                detector = RecomputedBudgetLock(h, contended=True)
                lower._bounded_io_lock = detector
                clock = RecomputedBudgetClock(h, '_lock_bounded', 11.0 + offset, detector)
                try:
                    with mock.patch.object(transport, 'monotonic', clock):
                        with self.assertRaises(transport.BoundedError) as error:
                            connection.close_bounded(deadline=11.0)
                    self.assertEqual(error.exception.primary, 'deadline')
                    self.assertEqual(detector.immediate, 1)
                    self.assertEqual(len(detector.timed), 1 if offset < 0 else 0)
                    self.assertIn('socket-release', error.exception.cleanup)
                    self.assertFalse(h.resource['closed'])
                finally:
                    lower._bounded_io_lock = original
                    connection.close_bounded(deadline=h.deadline())
                self.assertTrue(h.resource['closed'])
        for contended in (False, True):
            with self.subTest(expired_immediate=contended), PrimitiveHarness() as h:
                connection = h.open()
                lower = connection.transport
                original = lower._bounded_io_lock
                detector = RecomputedBudgetLock(h, contended)
                lower._bounded_io_lock = detector
                h.cancel.set()
                try:
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.close_bounded(deadline=h.now())
                    self.assertEqual(error.exception.primary, 'deadline')
                    self.assertEqual(detector.immediate, 1)
                    self.assertEqual(detector.timed, [])
                    self.assertEqual(h.resource['closed'], not contended)
                finally:
                    lower._bounded_io_lock = original
                    connection.close_bounded(deadline=h.deadline())
                self.assertEqual(h.tls.close_calls, 1)

    def test_send_readiness_recomputation_reclaims_entered_native_attempt(self):
        for native_error in (ssl.SSLWantReadError, ssl.SSLWantWriteError, BlockingIOError):
            for offset in (-.0001, 0.0, .0001):
                with self.subTest(native=native_error.__name__, offset=offset), PrimitiveHarness() as h:
                    connection = h.open()
                    h.tls.sent[:] = []
                    h.tls.send_script.append(native_error())
                    clock = RecomputedBudgetClock(h, '_wait_bounded', 11.0 + offset)
                    if native_error is ssl.SSLWantReadError:
                        h.tls.recv_script.append(b'\n')
                    try:
                        with mock.patch.object(transport, 'monotonic', clock):
                            if offset < 0:
                                connection.send_bounded('topic', b'x', deadline=11.0, cancel=h.cancel)
                            else:
                                with self.assertRaises(transport.BoundedError) as error:
                                    connection.send_bounded('topic', b'x', deadline=11.0, cancel=h.cancel)
                                self.assertEqual(error.exception.primary, 'deadline')
                        self.assertEqual(clock.crossings, 1)
                        if offset < 0:
                            self.assertEqual(h.tls.sent, [b'SEND\ndestination:topic\ncontent-length:1\n\nx\0'])
                            self.assertFalse(connection.transport._bounded_gate)
                        else:
                            self.assertEqual(h.waits, [])
                            self.assertEqual(h.tls.sent, [])
                            self.assertTrue(connection.transport._bounded_gate)
                            self.assertTrue(h.resource['closed'])
                    finally:
                        connection.close_bounded(deadline=h.deadline())



class TransportOperationCancellationTests(unittest.TestCase):
    def test_distinct_send_event_keeps_original_lifecycle_and_wire_controls(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            operation = threading.Event()
            try:
                connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=operation)
                self.assertIs(connection.transport._bounded_cancel, h.cancel)
                self.assertFalse(operation.is_set())
                self.assertFalse(h.cancel.is_set())
                self.assertFalse(connection.transport._bounded_gate)
                self.assertEqual(h.tls.sent[-1], b'SEND\ndestination:topic\ncontent-length:1\n\nx\0')
            finally:
                connection.close_bounded(deadline=h.deadline())

    def test_distinct_subscribe_event_does_not_become_registration_lifetime(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            operation = threading.Event()
            received, delivered = [], threading.Event()

            def dispatch(wire_id, frame):
                received.append((wire_id, frame[2]))
                delivered.set()

            try:
                connection.subscribe_bounded('topic', 1, deadline=h.deadline(), cancel=operation,
                                             dispatch=dispatch)
                operation.set()
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0')
                self.assertTrue(delivered.wait(1))
                self.assertEqual(received, [(1, b'x')])
                self.assertIs(connection.transport._bounded_cancel, h.cancel)
                self.assertFalse(h.cancel.is_set())
                self.assertFalse(connection.transport._bounded_gate)
                connection.subscribe_bounded('sibling', 2, deadline=h.deadline(),
                                             cancel=threading.Event(), dispatch=dispatch)
                connection.unsubscribe_bounded(1, deadline=h.deadline(), cancel=threading.Event())
                self.assertNotIn(1, connection.transport._bounded_topics)
                self.assertEqual(connection.transport._bounded_topics[2].state, 'active')
                delivered.clear()
                h.tls.recv_script.append(b'MESSAGE\nsubscription:2\n\ny\0')
                self.assertTrue(delivered.wait(1))
                self.assertEqual(received, [(1, b'x'), (2, b'y')])
            finally:
                connection.close_bounded(deadline=h.deadline(2))

    def test_operation_event_type_rejects_before_custom_hooks(self):
        class EventSubclass(threading.Event):
            def is_set(self):
                raise AssertionError('event-subclass-hook')

        class EventLike:
            def is_set(self):
                raise AssertionError('event-like-hook')

        with PrimitiveHarness() as h:
            connection = h.open()
            before = tuple(h.tls.sent)
            try:
                for operation in (None, object(), EventSubclass(), EventLike()):
                    with self.subTest(kind=type(operation).__name__):
                        with self.assertRaises(transport.BoundedError) as error:
                            connection.send_bounded('topic', b'x', deadline=h.deadline(),
                                                    cancel=operation)
                        self.assertEqual(error.exception.primary, 'admission')
                self.assertEqual(tuple(h.tls.sent), before)
                self.assertFalse(connection.transport._bounded_gate)
            finally:
                connection.close_bounded(deadline=h.deadline())

    def test_acquisition_still_requires_the_original_event(self):
        with PrimitiveHarness() as h:
            lower = transport.Transport([('192.0.2.1', 61614)], prefer_localhost=False,
                                        try_loopback_connect=False)
            lower._init_bounded(h.cancel)
            operation = threading.Event()
            with self.assertRaises(transport.BoundedError) as error:
                lower.acquire_bounded('192.0.2.1', 61614, 'broker.example', h.context,
                                      deadline=h.deadline(), cancel=operation)
            self.assertEqual(error.exception.primary, 'admission')
            with self.assertRaises(transport.BoundedError) as error:
                lower._commit_open_bounded(deadline=h.deadline(), cancel=operation)
            self.assertEqual(error.exception.primary, 'admission')
            self.assertIs(lower._bounded_cancel, h.cancel)
            self.assertFalse(lower._bounded_returned)
            self.assertFalse(lower.connected)
            self.assertIsNone(lower.socket)
            self.assertEqual(h.allocations, [])

    def test_pre_set_operation_cancel_leaves_other_callers_usable(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            operation = threading.Event()
            operation.set()
            before = tuple(h.tls.sent)
            try:
                with self.assertRaises(transport.BoundedError) as error:
                    connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=operation)
                self.assertEqual(error.exception.primary, 'cancelled')
                self.assertEqual(tuple(h.tls.sent), before)
                self.assertFalse(connection.transport._bounded_gate)
                self.assertFalse(h.resource['closed'])
                self.assertFalse(h.cancel.is_set())
                connection.send_bounded('topic', b'sibling', deadline=h.deadline(),
                                        cancel=threading.Event())
                connection.send_bounded('topic', b'owner', deadline=h.deadline(), cancel=h.cancel)
            finally:
                connection.close_bounded(deadline=h.deadline())

    def test_lifecycle_cancel_precedes_distinct_operation_and_expiry(self):
        for operation_set in (False, True):
            with self.subTest(operation_set=operation_set), PrimitiveHarness() as h:
                connection = h.open()
                operation = threading.Event()
                if operation_set:
                    operation.set()
                h.cancel.set()
                try:
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.send_bounded('topic', b'x', deadline=h.now(), cancel=operation)
                    self.assertEqual(error.exception.primary, 'cancelled')
                    self.assertTrue(connection.transport._bounded_gate)
                    self.assertTrue(h.resource['closed'])
                    h.cancel.clear()
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.send_bounded('topic', b'x', deadline=h.deadline(),
                                                cancel=threading.Event())
                    self.assertEqual(error.exception.primary, 'disconnected')
                finally:
                    connection.close_bounded(deadline=h.deadline())

    def test_operation_cancel_never_clears_existing_terminal_gate(self):
        with PrimitiveHarness() as h:
            connection = h.open()
            connection.close_bounded(deadline=h.deadline())
            operation = threading.Event()
            operation.set()
            with self.assertRaises(transport.BoundedError) as error:
                connection.send_bounded('topic', b'x', deadline=h.now(), cancel=operation)
            self.assertEqual(error.exception.primary, 'cancelled')
            self.assertTrue(connection.transport._bounded_gate)
            self.assertTrue(h.resource['closed'])
            self.assertFalse(h.cancel.is_set())
            with self.assertRaises(transport.BoundedError) as error:
                connection.send_bounded('topic', b'x', deadline=h.now(), cancel=threading.Event())
            self.assertEqual(error.exception.primary, 'disconnected')

    def test_operation_cancel_during_each_pre_effect_lock_preserves_siblings(self):
        for name in ('_bounded_state_lock', '_bounded_frame_lock', '_bounded_io_lock'):
            with self.subTest(lock=name), PrimitiveHarness() as h:
                connection = h.open()
                lower = connection.transport
                operation = threading.Event()
                original = getattr(lower, name)
                controlled = AdvancingLock(h.clock)
                acquire = controlled.acquire

                def cancel_wait(*args, **kwargs):
                    operation.set()
                    return acquire(*args, **kwargs)

                controlled.acquire = cancel_wait
                setattr(lower, name, controlled)
                before = tuple(h.tls.sent)
                try:
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.send_bounded('topic', b'x', deadline=h.deadline(),
                                                cancel=operation)
                    self.assertEqual(error.exception.primary, 'cancelled')
                    self.assertEqual(tuple(h.tls.sent), before)
                    self.assertTrue(controlled.waits)
                    self.assertFalse(lower._bounded_gate)
                    self.assertFalse(h.resource['closed'])
                    self.assertFalse(h.cancel.is_set())
                    self.assertTrue(all(ticket.done for ticket in lower._bounded_tickets))
                    setattr(lower, name, original)
                    connection.send_bounded('sibling', b'x', deadline=h.deadline(),
                                            cancel=threading.Event())
                finally:
                    setattr(lower, name, original)
                    connection.close_bounded(deadline=h.deadline())

    def test_distinct_operation_keeps_exact_admission_deadline(self):
        for offset in (-0.000001, 0, 0.000001):
            with self.subTest(offset=offset), PrimitiveHarness() as h:
                connection = h.open()
                operation = threading.Event()
                h.clock.value = 11.0 + offset
                before = tuple(h.tls.sent)
                try:
                    if offset < 0:
                        connection.send_bounded('topic', b'x', deadline=11.0, cancel=operation)
                        self.assertEqual(len(h.tls.sent), len(before) + 1)
                    else:
                        with self.assertRaises(transport.BoundedError) as error:
                            connection.send_bounded('topic', b'x', deadline=11.0, cancel=operation)
                        self.assertEqual(error.exception.primary, 'deadline')
                        self.assertEqual(tuple(h.tls.sent), before)
                    self.assertFalse(connection.transport._bounded_gate)
                finally:
                    connection.close_bounded(deadline=h.deadline())

    def test_distinct_operation_native_result_keeps_exact_deadline(self):
        for offset in (-0.000001, 0, 0.000001):
            with self.subTest(offset=offset), PrimitiveHarness() as h:
                connection = h.open()
                operation = threading.Event()

                def finish_native():
                    h.clock.value = 11.0 + offset

                h.hooks['send'] = finish_native
                try:
                    if offset < 0:
                        connection.send_bounded('topic', b'x', deadline=11.0, cancel=operation)
                        self.assertFalse(connection.transport._bounded_gate)
                    else:
                        with self.assertRaises(transport.BoundedError) as error:
                            connection.send_bounded('topic', b'x', deadline=11.0, cancel=operation)
                        self.assertEqual(error.exception.primary, 'deadline')
                        self.assertTrue(connection.transport._bounded_gate)
                        self.assertTrue(h.resource['closed'])
                    self.assertFalse(h.cancel.is_set())
                finally:
                    h.hooks.clear()
                    connection.close_bounded(deadline=h.deadline())

    def test_distinct_operation_readiness_never_renews_deadline(self):
        for offset in (-0.000001, 0, 0.000001):
            with self.subTest(offset=offset), PrimitiveHarness() as h:
                connection = h.open()
                h.tls.sent[:] = []
                h.tls.send_script.append(ssl.SSLWantWriteError())
                operation = threading.Event()
                clock = RecomputedBudgetClock(h, '_wait_bounded', 11.0 + offset)
                try:
                    with mock.patch.object(transport, 'monotonic', clock):
                        if offset < 0:
                            connection.send_bounded('topic', b'x', deadline=11.0, cancel=operation)
                        else:
                            with self.assertRaises(transport.BoundedError) as error:
                                connection.send_bounded('topic', b'x', deadline=11.0,
                                                        cancel=operation)
                            self.assertEqual(error.exception.primary, 'deadline')
                    self.assertEqual(clock.crossings, 1)
                    if offset < 0:
                        self.assertTrue(h.waits)
                        self.assertLessEqual(max(h.waits), 0.000001001)
                        self.assertFalse(connection.transport._bounded_gate)
                    else:
                        self.assertEqual(h.waits, [])
                        self.assertTrue(h.resource['closed'])
                    self.assertFalse(h.cancel.is_set())
                finally:
                    connection.close_bounded(deadline=h.deadline())

    def test_operation_cancel_after_native_send_retains_shared_abort(self):
        for amount in (1, None):
            with self.subTest(amount=amount), PrimitiveHarness() as h:
                connection = h.open()
                operation = threading.Event()
                h.tls.send_script.append(amount)
                h.hooks['send'] = operation.set
                try:
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=operation)
                    self.assertEqual(error.exception.primary, 'cancelled')
                    self.assertTrue(connection.transport._bounded_gate)
                    self.assertTrue(h.resource['closed'])
                    self.assertFalse(h.cancel.is_set())
                    self.assertTrue(all(ticket.done for ticket in connection.transport._bounded_tickets))
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.send_bounded('topic', b'later', deadline=h.deadline(),
                                                cancel=threading.Event())
                    self.assertEqual(error.exception.primary, 'disconnected')
                finally:
                    h.hooks.clear()
                    connection.close_bounded(deadline=h.deadline())

    def test_cancelled_startup_waiter_does_not_cancel_starter_or_later_subscriber(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h) as p:
            starter, waiter_event = threading.Event(), threading.Event()
            p.subscribe(1, cancel=starter)
            self.assertTrue(p.entered.wait(1))
            waiter = p.subscribe(2, cancel=waiter_event)
            p.pending(2)
            waiter_event.set()
            waiter.join(1)
            self.assertFalse(waiter.is_alive())
            self.assertEqual(p.results, {2: 'cancelled'})
            self.assertEqual(h.tls.sent, [])
            self.assertFalse(p.lower._bounded_gate)
            self.assertFalse(h.resource['closed'])
            self.assertFalse(h.cancel.is_set())
            self.assertFalse(starter.is_set())
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'ok', 2: 'cancelled'})
            self.assertEqual(p.lower._bounded_topics[2].state, 'debt')
            self.assertFalse(p.lower._bounded_topics[2].ticket.committed)
            p.connection.subscribe_bounded('topic-3', 3, deadline=h.deadline(),
                                            cancel=threading.Event(), dispatch=p.dispatch)
            self.assertEqual(h.tls.sent, [p.frame(1), p.frame(3)])
            self.assertEqual(p.starts, [p.lower._bounded_receiver])

    def test_cancel_after_startup_reservation_remains_terminal_without_start(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            operation = threading.Event()
            actual_thread = threading.Thread
            workers = []
            before = tuple(h.tls.sent)

            def reserve(*args, **kwargs):
                worker = actual_thread(*args, **kwargs)
                workers.append(worker)
                operation.set()
                return worker

            try:
                with mock.patch.object(threading, 'Thread', side_effect=reserve):
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.subscribe_bounded('topic', 1, deadline=h.deadline(),
                                                     cancel=operation, dispatch=lambda *args: None)
                self.assertEqual(error.exception.primary, 'cancelled')
                self.assertEqual(workers, [connection.transport._bounded_receiver])
                self.assertIsNone(workers[0].ident)
                self.assertTrue(connection.transport._bounded_startup.done)
                self.assertFalse(connection.transport._bounded_startup.committed)
                self.assertTrue(connection.transport._bounded_gate)
                self.assertTrue(h.resource['closed'])
                self.assertEqual(tuple(h.tls.sent), before)
                self.assertFalse(h.cancel.is_set())
            finally:
                connection.close_bounded(deadline=h.deadline())

    def test_cancelled_startup_owner_retains_real_worker_and_shared_failure(self):
        with PrimitiveHarness(real_time=True) as h, PendingStartupHarness(self, h) as p:
            starter = threading.Event()
            p.subscribe(1, cancel=starter)
            self.assertTrue(p.entered.wait(1))
            p.subscribe(2, cancel=threading.Event())
            p.pending(2)
            starter.set()
            p.release.set()
            p.join_callers()
            self.assertEqual(p.results, {1: 'cancelled', 2: 'disconnected'})
            self.assertEqual(h.tls.sent, [])
            self.assertTrue(p.lower._bounded_gate)
            self.assertTrue(h.resource['closed'])
            self.assertFalse(h.cancel.is_set())
            self.assertTrue(p.lower._bounded_startup.done)
            self.assertFalse(p.lower._bounded_startup.committed)
            self.assertIsNotNone(p.lower._bounded_receiver.ident)
            self.assertEqual(p.starts, [p.lower._bounded_receiver])

    def test_operation_cancel_before_subscribe_commit_discards_pending_frames(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            lower = connection.transport
            paused, release, operation = threading.Event(), threading.Event(), threading.Event()
            original = lower._bounded_state_lock
            lower._bounded_state_lock = CommitPauseLock(h, paused, release)
            received, outcomes = [], []

            def dispatch(wire_id, frame):
                received.append((wire_id, frame[2]))

            def subscribe():
                try:
                    connection.subscribe_bounded('topic', 1, deadline=h.deadline(2),
                                                 cancel=operation, dispatch=dispatch)
                    outcomes.append('ok')
                except transport.BoundedError as error:
                    outcomes.append(error.primary)

            caller = threading.Thread(target=subscribe, name='bounded-subscribe-test')
            try:
                caller.start()
                self.assertTrue(paused.wait(1))
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0')
                TransportReviewedRegressionTests.wait_until(self, lambda: len(lower._bounded_pending) == 1)
                operation.set()
                caller.join(1)
                self.assertFalse(caller.is_alive())
                self.assertEqual(outcomes, ['cancelled'])
                self.assertFalse(lower._bounded_topics[1].ticket.committed)
                self.assertEqual(lower._bounded_topics[1].state, 'debt')
                TransportReviewedRegressionTests.wait_until(self, lambda: not lower._bounded_pending)
                self.assertEqual(received, [])
                self.assertFalse(lower._bounded_gate)
                self.assertFalse(h.resource['closed'])
                self.assertFalse(h.cancel.is_set())
                connection.unsubscribe_bounded(1, deadline=h.deadline(), cancel=threading.Event())
                connection.send_bounded('sibling', b'x', deadline=h.deadline(), cancel=threading.Event())
            finally:
                release.set()
                if caller.ident is not None:
                    caller.join(2)
                    self.assertFalse(caller.is_alive())
                lower._bounded_gate = True
                if lower._bounded_receiver is not None and lower._bounded_receiver.ident is not None:
                    lower._bounded_receiver.join(2)
                    self.assertFalse(lower._bounded_receiver.is_alive())
                lower._bounded_state_lock = original
                connection.close_bounded(deadline=h.deadline())

    def test_operation_cancel_does_not_hide_callback_debt_from_passive_close(self):
        with PrimitiveHarness(real_time=True) as h:
            connection = h.open()
            operation, entered, release = threading.Event(), threading.Event(), threading.Event()

            def dispatch(wire_id, frame):
                entered.set()
                if not release.wait(2):
                    raise AssertionError('controlled callback release expired')

            try:
                connection.subscribe_bounded('topic', 1, deadline=h.deadline(), cancel=operation,
                                             dispatch=dispatch)
                h.tls.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0')
                self.assertTrue(entered.wait(1))
                operation.set()
                self.assertFalse(connection.transport._bounded_gate)
                self.assertFalse(h.cancel.is_set())
                with self.assertRaises(transport.BoundedError) as error:
                    connection.close_bounded(deadline=h.deadline(.025))
                self.assertEqual(error.exception.primary, 'deadline')
                self.assertIn('active-callback', error.exception.cleanup)
                self.assertTrue(h.resource['closed'])
                release.set()
                connection.close_bounded(deadline=h.deadline())
                self.assertFalse(connection.transport._bounded_receiver.is_alive())
            finally:
                release.set()
                connection.close_bounded(deadline=h.deadline(2))


class LoopbackAcquisitionTests(unittest.TestCase):
    def test_raw_factory_has_no_tls_methods_or_worker_and_binds_endpoint(self):
        with PrimitiveHarness(loopback=True) as h, mock.patch.object(
                threading.Thread, 'start', side_effect=AssertionError('worker before return')):
            for name in ('pending', 'do_handshake', 'unwrap'):
                self.assertFalse(hasattr(h.raw, name))
            connection = h.open()
            try:
                self.assertEqual(h.allocations, [((socket.AF_INET, socket.SOCK_STREAM), {})])
                self.assertEqual(h.raw.connect_calls, [('127.0.0.1', 61613)])
                self.assertEqual(h.raw.blocking, [False])
                self.assertEqual(connection.bounded_endpoint,
                                 ('loopback-plaintext', '127.0.0.1', 61613, None))
                self.assertIs(connection.bounded_endpoint, connection.transport.bounded_endpoint)
                self.assertEqual(h.wraps, [])
                self.assertEqual(h.handshakes, 0)
                self.assertIsNone(connection.transport._bounded_receiver)
                self.assertTrue(h.waits, 'raw receive must use readiness, not SSL pending')
                self.assertTrue(connection.is_connected())
            finally:
                h.close(connection)
            h.close(connection)
            self.assertEqual(h.raw.close_calls, 1)
            self.assertEqual(h.tls.close_calls, 0)
            self.assertNotIn(b'DISCONNECT', b''.join(h.raw.sent))

    def test_only_exact_ipv4_loopback_and_integer_port_are_admitted(self):
        class Text(str):
            def __eq__(self, other):
                raise AssertionError('address subclass hook')
        class Port(int):
            def __le__(self, other):
                raise AssertionError('port subclass hook')
        addresses = ('localhost', '127.0.0.2', '127.1', '127.000.0.1', '::1',
                     '::ffff:127.0.0.1', '0.0.0.0', '192.0.2.1', None, b'127.0.0.1',
                     Text('127.0.0.1'))
        overrides = [{'dial_address': value} for value in addresses]
        overrides += [{'port': value} for value in (0, 65536, True, '61613', 61613.0, Port(61613))]
        for values in overrides:
            with self.subTest(fields=list(values)), PrimitiveHarness(loopback=True) as h:
                with self.assertRaises(transport.BoundedError) as error:
                    h.open(**values)
                self.assertEqual(error.exception.primary, 'admission')
                self.assertEqual(h.allocations, [])
                self.assertEqual(h.raw.sent, [])
        for port in (1, 65535):
            with self.subTest(port=port), PrimitiveHarness(loopback=True) as h:
                connection = h.open(port=port)
                try:
                    self.assertEqual(h.raw.connect_calls, [('127.0.0.1', port)])
                finally:
                    h.close(connection)

    def test_loopback_signature_rejects_tls_arguments_before_allocation(self):
        for values in ({'tls_identity': None}, {'ssl_context': None}):
            with self.subTest(fields=list(values)), PrimitiveHarness(loopback=True) as h:
                with self.assertRaises(TypeError):
                    h.open(**values)
                self.assertEqual(h.allocations, [])

    def test_tls_factory_still_requires_verified_tls_on_loopback(self):
        with PrimitiveHarness() as h:
            with self.assertRaises(transport.BoundedError) as error:
                h.open(dial_address='127.0.0.1', ssl_context=None)
            self.assertEqual(error.exception.primary, 'tls-trust')
            self.assertEqual(h.allocations, [])
        with PrimitiveHarness() as h:
            connection = h.open(dial_address='127.0.0.1')
            try:
                self.assertEqual(connection.bounded_endpoint,
                                 ('tls', '127.0.0.1', 61614, 'broker.example'))
                self.assertEqual(len(h.wraps), 1)
                self.assertEqual(h.handshakes, 1)
            finally:
                h.close(connection)

    def test_endpoint_and_mode_cannot_be_changed_on_bounded_connections(self):
        for loopback in (False, True):
            with self.subTest(loopback=loopback), PrimitiveHarness(loopback=loopback) as h:
                connection = h.open()
                endpoint = connection.bounded_endpoint
                before = tuple(h.wire.sent)
                try:
                    for owner in (connection, connection.transport):
                        with self.assertRaises(AttributeError):
                            owner.bounded_endpoint = ('loopback-plaintext', '127.0.0.1', 1, None)
                    with self.assertRaises(transport.BoundedError):
                        connection.transport._init_bounded(h.cancel, endpoint=endpoint)
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.set_ssl(for_hosts=[('127.0.0.1', 61613)])
                    self.assertEqual(error.exception.primary, 'legacy-path')
                    with self.assertRaises(transport.BoundedError):
                        if loopback:
                            connection.transport.acquire_bounded('127.0.0.1', 61613, 'broker.example',
                                h.context, deadline=h.deadline(), cancel=h.cancel)
                        else:
                            connection.transport.acquire_loopback_bounded('127.0.0.1', 61613,
                                deadline=h.deadline(), cancel=h.cancel)
                    self.assertEqual(connection.bounded_endpoint, endpoint)
                    self.assertEqual(tuple(h.wire.sent), before)
                    self.assertEqual(len(h.allocations), 1)
                finally:
                    h.close(connection)
                with self.assertRaises(transport.BoundedError):
                    connection.transport.acquire_loopback_bounded('127.0.0.1', 61613,
                        deadline=h.deadline(), cancel=h.cancel)
                self.assertEqual(len(h.allocations), 1)

    def test_raw_connect_and_fragmented_connected_keep_one_budget(self):
        with PrimitiveHarness(loopback=True) as h:
            h.raw.connect_result = errno.EINPROGRESS
            h.raw.recv_script.clear()
            h.raw.recv_script.extend((BlockingIOError(), b'CON', InterruptedError(), CONNECTED[3:]))
            h.raw.send_script.extend((BlockingIOError(), 2, InterruptedError(), 1))
            connection = h.open()
            try:
                expected = (b'STOMP\naccept-version:1.1\nheart-beat:0,0\n'
                            b'login:synthetic-user\npasscode:synthetic-pass\n\n\0')
                self.assertEqual(b''.join(h.raw.sent), expected)
                self.assertEqual(len(h.allocations), 1)
                self.assertEqual(h.wraps, [])
                self.assertTrue(all(0 < timeout <= 0.01 for timeout in h.waits))
                self.assertTrue(all(size == 16384 for size in h.raw.recv_sizes))
            finally:
                h.close(connection)

    def test_raw_tcp_failures_do_not_fallback_or_retry(self):
        for connect_result, socket_error in ((errno.ECONNREFUSED, 0),
                                              (errno.EINPROGRESS, errno.ECONNREFUSED)):
            with self.subTest(result=connect_result), PrimitiveHarness(loopback=True) as h:
                h.raw.connect_result = connect_result
                h.raw.socket_error = socket_error
                with self.assertRaises(transport.BoundedError) as error:
                    h.open()
                self.assertEqual(error.exception.primary, 'tcp')
                self.assertEqual(len(h.allocations), 1)
                self.assertEqual(h.raw.close_calls, 1)
                self.assertEqual(h.raw.sent, [])
                self.assertEqual(h.wraps, [])

    def test_raw_open_deadline_and_control_admission_precede_allocation(self):
        for offset in (-0.001, 0.0, 0.001):
            with self.subTest(offset=offset), PrimitiveHarness(loopback=True) as h:
                if offset > 0:
                    connection = h.open(deadline=h.now() + offset)
                    h.close(connection)
                else:
                    with self.assertRaises(transport.BoundedError) as error:
                        h.open(deadline=h.now() + offset)
                    self.assertEqual(error.exception.primary, 'deadline')
                    self.assertEqual(h.allocations, [])
        for values in ({'deadline': None}, {'deadline': True}, {'deadline': float('nan')},
                       {'deadline': float('inf')}, {'cancel': None}):
            with self.subTest(fields=list(values)), PrimitiveHarness(loopback=True) as h:
                with self.assertRaises(transport.BoundedError) as error:
                    h.open(**values)
                self.assertEqual(error.exception.primary, 'admission')
                self.assertEqual(h.allocations, [])
        with PrimitiveHarness(loopback=True) as h:
            h.cancel.set()
            with self.assertRaises(transport.BoundedError) as error:
                h.open(deadline=h.now())
            self.assertEqual(error.exception.primary, 'cancelled')
            self.assertEqual(h.allocations, [])

    def test_raw_late_or_cancelled_native_completion_reclaims_owner(self):
        for cancellation in (False, True):
            for phase in ('allocate', 'raw-blocking', 'connect', 'send', 'recv'):
                with self.subTest(cancel=cancellation, phase=phase), PrimitiveHarness(loopback=True) as h:
                    h.hooks[phase] = h.cancel.set if cancellation else lambda: h.clock.advance(2)
                    with self.assertRaises(transport.BoundedError) as error:
                        h.open()
                    self.assertEqual(error.exception.primary, 'cancelled' if cancellation else 'deadline')
                    self.assertEqual(h.raw.close_calls, 1)
                    self.assertTrue(h.resource['closed'])
                    self.assertEqual(h.wraps, [])

    def test_raw_invalid_connected_eof_and_native_failure_reclaim_once(self):
        for incoming in (b'', b'CONNECTED\nversion:1.2\n\n\0', b'MESSAGE\nsubscription:1\n\nx\0',
                         b'CONNECTED\nversion:1.1\nversion:1.1\n\n\0',
                         b'ERROR\nmessage:' + CANARY.encode() + b'\n\n\0', OSError(CANARY)):
            with self.subTest(kind=type(incoming).__name__), PrimitiveHarness(incoming, loopback=True) as h:
                with self.assertRaises(transport.BoundedError) as error:
                    h.open()
                self.assertNotIn(CANARY, str(error.exception))
                self.assertIsNone(error.exception.__cause__)
                self.assertEqual(h.raw.close_calls, 1)
                self.assertEqual(len(h.allocations), 1)
                self.assertEqual(h.wraps, [])


class LoopbackLifecycleTests(unittest.TestCase):
    def test_partial_raw_send_failure_poison_preserves_fixed_diagnostics(self):
        with PrimitiveHarness(loopback=True) as h:
            connection = h.open()
            try:
                h.raw.send_script.extend((2, OSError(CANARY)))
                with self.assertRaises(transport.BoundedError) as error:
                    connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=threading.Event())
                self.assertEqual(error.exception.primary, 'send')
                self.assertTrue(connection.transport._bounded_gate)
                self.assertTrue(h.resource['closed'])
                before = tuple(h.raw.sent)
                with self.assertRaises(transport.BoundedError):
                    connection.send_bounded('topic', b'y', deadline=h.deadline(), cancel=threading.Event())
                self.assertEqual(tuple(h.raw.sent), before)
                self.assertNotIn(CANARY, repr(connection.transport.diagnostics_bounded()))
            finally:
                h.close(connection)

    def test_operation_cancel_before_send_leaves_raw_siblings_usable(self):
        with PrimitiveHarness(loopback=True) as h:
            connection = h.open()
            operation = threading.Event()
            operation.set()
            try:
                before = tuple(h.raw.sent)
                with self.assertRaises(transport.BoundedError) as error:
                    connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=operation)
                self.assertEqual(error.exception.primary, 'cancelled')
                self.assertEqual(tuple(h.raw.sent), before)
                self.assertFalse(connection.transport._bounded_gate)
                connection.send_bounded('topic', b'y', deadline=h.deadline(), cancel=threading.Event())
                self.assertTrue(connection.is_connected())
            finally:
                h.close(connection)

    def test_raw_send_late_success_or_cancellation_remains_terminal(self):
        for cancellation in (False, True):
            with self.subTest(cancel=cancellation), PrimitiveHarness(loopback=True) as h:
                connection = h.open()
                operation = threading.Event()
                try:
                    h.hooks['send'] = operation.set if cancellation else lambda: h.clock.advance(2)
                    with self.assertRaises(transport.BoundedError) as error:
                        connection.send_bounded('topic', b'x', deadline=h.deadline(), cancel=operation)
                    self.assertEqual(error.exception.primary, 'cancelled' if cancellation else 'deadline')
                    self.assertTrue(connection.transport._bounded_gate)
                    self.assertTrue(h.resource['closed'])
                    self.assertTrue(all(ticket.done for ticket in connection.transport._bounded_tickets))
                finally:
                    h.close(connection)

    def test_raw_close_failure_retains_socket_debt_until_explicit_retry(self):
        with PrimitiveHarness(loopback=True) as h:
            connection = h.open()
            h.raw.close_error = OSError(CANARY)
            try:
                with self.assertRaises(transport.BoundedError) as error:
                    h.close(connection)
                self.assertEqual(error.exception.primary, 'socket-release')
                self.assertIn('socket-release', error.exception.cleanup)
                self.assertFalse(h.resource['closed'])
                self.assertIs(connection.transport.socket, h.raw)
                self.assertNotIn(CANARY, repr(connection.transport.diagnostics_bounded()))
            finally:
                h.raw.close_error = None
                h.close(connection)
            self.assertIsNone(connection.transport.socket)
            self.assertEqual(connection.transport.diagnostics_bounded()['cleanup'], ())

    def test_raw_receiver_handles_fragmented_messages_and_passive_close(self):
        with PrimitiveHarness(loopback=True, real_time=True) as h:
            connection = h.open()
            received, entered = [], threading.Event()
            def dispatch(wire_id, frame):
                received.append((wire_id, frame[2]))
                entered.set()
            try:
                connection.subscribe_bounded('topic', 1, deadline=h.deadline(),
                                             cancel=threading.Event(), dispatch=dispatch)
                h.raw.recv_script.extend((b'MESS', BlockingIOError(),
                                          b'AGE\nsubscription:1\ncontent-length:3\n\na\0b\0'))
                self.assertTrue(entered.wait(1))
                self.assertEqual(received, [(1, b'a\0b')])
                connection.unsubscribe_bounded(1, deadline=h.deadline(), cancel=threading.Event())
                self.assertNotIn(1, connection.transport._bounded_topics)
                h.cancel.set()
                h.close(connection)
                self.assertFalse(connection.transport._bounded_receiver.is_alive())
                self.assertTrue(h.resource['closed'])
            finally:
                TransportWorkerTests.finish_worker(self, connection, h)

    def test_raw_pending_frames_drain_in_order_after_subscription_commit(self):
        with PrimitiveHarness(loopback=True, real_time=True) as h:
            connection = h.open()
            lower = connection.transport
            paused, release = threading.Event(), threading.Event()
            original = lower._bounded_state_lock
            lower._bounded_state_lock = CommitPauseLock(h, paused, release)
            received, outcomes = [], []
            def dispatch(wire_id, frame):
                received.append((wire_id, frame[2]))
            def subscribe():
                try:
                    connection.subscribe_bounded('topic', 1, deadline=h.deadline(2),
                                                 cancel=h.cancel, dispatch=dispatch)
                    outcomes.append('ok')
                except transport.BoundedError as error:
                    outcomes.append(error.primary)
            caller = threading.Thread(target=subscribe, name='bounded-subscribe-test')
            try:
                caller.start()
                self.assertTrue(paused.wait(1))
                h.raw.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0MESSAGE\nsubscription:1\n\ny\0')
                TransportReviewedRegressionTests.wait_until(self, lambda: len(lower._bounded_pending) == 2)
                self.assertEqual(received, [])
                release.set()
                caller.join(2)
                self.assertFalse(caller.is_alive())
                self.assertEqual(outcomes, ['ok'])
                TransportReviewedRegressionTests.wait_until(self, lambda: len(received) == 2)
                self.assertEqual(received, [(1, b'x'), (1, b'y')])
                self.assertEqual(lower._bounded_pending, [])
                self.assertEqual(lower._bounded_pending_bytes, 0)
            finally:
                release.set()
                caller.join(2)
                self.assertFalse(caller.is_alive())
                lower._bounded_gate = True
                if lower._bounded_receiver is not None and lower._bounded_receiver.ident is not None:
                    lower._bounded_receiver.join(2)
                    self.assertFalse(lower._bounded_receiver.is_alive())
                lower._bounded_state_lock = original
                h.close(connection)

    def test_raw_failed_receiver_start_blocks_waiters_and_later_retry(self):
        with PrimitiveHarness(loopback=True, real_time=True) as h:
            with PendingStartupHarness(self, h, outcome='failed') as p:
                p.subscribe(1)
                self.assertTrue(p.entered.wait(1))
                p.subscribe(2)
                p.pending(2)
                p.release.set()
                p.join_callers()
                self.assertNotIn('ok', p.results.values())
                self.assertEqual(p.results[1], 'worker-start')
                self.assertTrue(p.lower._bounded_gate)
                self.assertEqual(h.raw.sent, [])
                with self.assertRaises(transport.BoundedError):
                    p.connection.subscribe_bounded('later', 3, deadline=h.deadline(),
                                                   cancel=threading.Event(), dispatch=p.dispatch)
                self.assertEqual(len(p.starts), 1)

    def test_raw_callback_debt_prevents_false_close_success(self):
        with PrimitiveHarness(loopback=True, real_time=True) as h:
            connection = h.open()
            entered, release = threading.Event(), threading.Event()
            def dispatch(*args):
                entered.set()
                if not release.wait(2):
                    raise AssertionError('controlled callback release expired')
            try:
                connection.subscribe_bounded('topic', 1, deadline=h.deadline(),
                                             cancel=threading.Event(), dispatch=dispatch)
                h.raw.recv_script.append(b'MESSAGE\nsubscription:1\n\nx\0')
                self.assertTrue(entered.wait(1))
                with self.assertRaises(transport.BoundedError) as error:
                    connection.close_bounded(deadline=h.deadline(.025))
                self.assertEqual(error.exception.primary, 'deadline')
                self.assertIn('active-callback', error.exception.cleanup)
                self.assertIn('worker-live', error.exception.cleanup)
                self.assertTrue(h.resource['closed'])
            finally:
                TransportWorkerTests.finish_worker(self, connection, h, release)


if __name__ == '__main__':
    unittest.main()
