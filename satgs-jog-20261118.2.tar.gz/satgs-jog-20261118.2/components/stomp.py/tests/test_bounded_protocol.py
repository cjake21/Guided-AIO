"""Protocol serialization tests use a recording transport, not a lifecycle substitute."""

import threading
import unittest
from contextlib import ExitStack
from unittest import mock

from stomp import connect as connect_module
from stomp import transport as transport_module
from stomp.connect import StompConnection11
from stomp.protocol import Protocol11
from stomp.transport import BoundedError
from stomp.utils import Frame

from test_bounded_transport import PrimitiveHarness


class RecordingTransport:
    def __init__(self, vhost=None):
        self.vhost = vhost
        self.calls = []
        self.legacy_frames = []

    def transmit_bounded(self, command, headers, body=b"", **controls):
        self.calls.append((command, headers, body, controls))

    def transmit(self, frame):
        self.legacy_frames.append(frame)


class TextSubclass(str):
    def encode(self, *args, **kwargs):
        raise AssertionError("text-subclass-hook")


class BodySubclass(bytes):
    pass


class BoundedProtocolTests(unittest.TestCase):
    def setUp(self):
        self.transport = RecordingTransport()
        self.protocol = Protocol11.__new__(Protocol11)
        self.protocol.transport = self.transport
        self.protocol.version = "1.1"
        self.protocol.auto_content_length = True
        self.cancel = threading.Event()
        self.controls = {"deadline": 123.0, "cancel": self.cancel}

    def assert_admission(self, function, *args, **kwargs):
        count = len(self.transport.calls)
        with self.assertRaises(BoundedError) as raised:
            function(*args, **kwargs)
        self.assertEqual(raised.exception.primary, "admission")
        self.assertEqual(len(self.transport.calls), count)

    def test_connect_headers_are_fixed_and_controls_stay_local(self):
        self.protocol.connect_bounded("user", "secret", **self.controls)
        command, headers, body, controls = self.transport.calls[-1]
        self.assertEqual(command, "STOMP")
        self.assertEqual(headers, {"accept-version": "1.1", "heart-beat": "0,0",
                                   "login": "user", "passcode": "secret"})
        self.assertEqual(body, b"")
        self.assertEqual(controls, self.controls)
        self.assertNotIn("deadline", headers)
        self.assertNotIn("cancel", headers)

    def test_optional_vhost_none_empty_and_ascii_maximum(self):
        for value in (None, "", "v" * 255):
            headers = Protocol11._bounded_connect_headers("", "", value)
            if value is None:
                self.assertNotIn("host", headers)
            else:
                self.assertEqual(headers["host"], value)
        for value in ("v" * 256, "\u00e9", "host\n", 12, TextSubclass("host")):
            self.assert_admission(Protocol11._bounded_connect_headers, "", "", value)

    def test_credentials_character_and_utf8_maxima(self):
        for value in ("", "a" * 1024, "\U0001f680" * 1024):
            headers = Protocol11._bounded_connect_headers(value, "", None)
            self.assertEqual(headers["login"], value)
            headers = Protocol11._bounded_connect_headers("", value, None)
            self.assertEqual(headers["passcode"], value)
        for value in ("a" * 1025, "\U0001f680" * 1025, None, b"user",
                      TextSubclass("user"), "user\x00", "user\r", "user\n", "user\x7f"):
            self.assert_admission(Protocol11._bounded_connect_headers, value, "", None)
            self.assert_admission(Protocol11._bounded_connect_headers, "", value, None)

    def test_connect_aggregate_header_exact_limit(self):
        username = "\U0001f680" * 1024
        passcode = "\U0001f680" * 1011 + "a"
        headers = Protocol11._bounded_connect_headers(username, passcode, None)
        size = sum(len(key.encode("utf-8")) + len(value.encode("utf-8")) + 2
                   for key, value in headers.items())
        self.assertEqual(size, 8192)
        self.assert_admission(Protocol11._bounded_connect_headers,
                              username, passcode + "b", None)

    def test_send_body_topic_and_priority_boundaries(self):
        for topic in ("x", "x" * 256, "\U0001f680" * 256):
            for body in (b"", b"x" * 262144):
                for priority in (None, 0, 9):
                    self.protocol.send_bounded(topic, body, priority, **self.controls)
                    command, headers, actual_body, controls = self.transport.calls[-1]
                    self.assertEqual(command, "SEND")
                    self.assertEqual(headers["destination"], topic)
                    self.assertEqual(headers["content-length"], str(len(body)))
                    self.assertIs(actual_body, body)
                    self.assertEqual(controls, self.controls)
                    if priority is None:
                        self.assertNotIn("priority", headers)
                    else:
                        self.assertEqual(headers["priority"], str(priority))

    def test_send_rejects_types_controls_and_maximum_plus_one(self):
        for topic in ("", "x" * 257, "\U0001f680" * 257, "x\x00", "x\r", "x\n",
                      "x\x1f", "x\x7f", b"topic", TextSubclass("topic")):
            self.assert_admission(self.protocol.send_bounded, topic, b"ok", **self.controls)
        for body in (b"x" * 262145, "text", bytearray(b"body"), BodySubclass(b"body"), None):
            self.assert_admission(self.protocol.send_bounded, "topic", body, **self.controls)
        for priority in (-1, 10, True, False, 1.0, "1"):
            self.assert_admission(self.protocol.send_bounded, "topic", b"ok", priority,
                                  **self.controls)

    def test_subscribe_wire_ids_and_dispatch_are_separate(self):
        dispatch = lambda frame: None
        for wire_id in (1, 2 ** 63 - 1):
            self.protocol.subscribe_bounded("topic", wire_id, dispatch=dispatch, **self.controls)
            command, headers, body, controls = self.transport.calls[-1]
            self.assertEqual((command, headers, body),
                             ("SUBSCRIBE", {"destination": "topic", "id": str(wire_id),
                                            "ack": "auto"}, b""))
            self.assertEqual(controls["_subscription"], wire_id)
            self.assertIs(controls["_dispatch"], dispatch)
            self.assertNotIn("dispatch", headers)
            self.protocol.unsubscribe_bounded(wire_id, **self.controls)
            command, headers, body, controls = self.transport.calls[-1]
            self.assertEqual((command, headers, body), ("UNSUBSCRIBE", {"id": str(wire_id)}, b""))
            self.assertEqual(controls["_unsubscribe"], wire_id)

    def test_subscribe_rejects_invalid_ids_before_transport(self):
        for wire_id in (0, -1, 2 ** 63, True, False, "1", 1.0):
            with self.assertRaises(BoundedError) as raised:
                self.protocol.subscribe_bounded("topic", wire_id, dispatch=lambda frame: None,
                                                **self.controls)
            self.assertEqual(raised.exception.primary, "wire-id")
            with self.assertRaises(BoundedError) as raised:
                self.protocol.unsubscribe_bounded(wire_id, **self.controls)
            self.assertEqual(raised.exception.primary, "wire-id")
            self.assertEqual(self.transport.calls, [])
        self.assert_admission(self.protocol.subscribe_bounded, "x" * 257, 1,
                              dispatch=lambda frame: None, **self.controls)

    def test_strict_controls_are_required_and_keyword_only(self):
        with self.assertRaises(TypeError):
            self.protocol.send_bounded("topic", b"body")
        with self.assertRaises(TypeError):
            self.protocol.connect_bounded("user", "pass", 10.0, self.cancel)
        with self.assertRaises(TypeError):
            self.protocol.subscribe_bounded("topic", 1, **self.controls)
        with self.assertRaises(TypeError):
            self.protocol.unsubscribe_bounded(1, 10.0, self.cancel)
        self.assertEqual(self.transport.calls, [])

    def test_legacy_send_preserves_keyword_headers_and_body_forms(self):
        self.protocol.send("legacy:topic", "text", deadline="wire-value", cancel="wire-cancel")
        frame = self.transport.legacy_frames[-1]
        self.assertEqual(frame.cmd, "SEND")
        self.assertEqual(frame.body, "text")
        self.assertEqual(frame.headers["deadline"], "wire-value")
        self.assertEqual(frame.headers["cancel"], "wire-cancel")
        self.assertEqual(frame.headers["destination"], "legacy\\ctopic")
        self.assertEqual(frame.headers["content-length"], 4)
        self.assertEqual(self.transport.calls, [])

    def test_legacy_connect_and_subscribe_keep_custom_headers(self):
        self.protocol.connect("user", "pass", deadline="wire", cancel="wire-cancel")
        frame = self.transport.legacy_frames[-1]
        self.assertEqual(frame.cmd, "STOMP")
        self.assertEqual(frame.headers["deadline"], "wire")
        self.protocol.subscribe("topic", "legacy-id", headers={"custom": "a:b"}, deadline="wire")
        frame = self.transport.legacy_frames[-1]
        self.assertEqual(frame.headers["custom"], "a\\cb")
        self.assertEqual(frame.headers["deadline"], "wire")
        self.protocol.unsubscribe("legacy-id", cancel="wire-cancel")
        self.assertEqual(self.transport.legacy_frames[-1].headers["cancel"], "wire-cancel")

    def test_factory_rejects_subclasses_before_initialization(self):
        class Subclass(StompConnection11):
            def __new__(cls, *args, **kwargs):
                raise AssertionError("subclass-construction")

        with self.assertRaises(BoundedError) as raised:
            Subclass.open_bounded(dial_address="192.0.2.1", port=61614,
                                  tls_identity="broker.invalid", ssl_context=None,
                                  username="", passcode="", **self.controls)
        self.assertEqual(raised.exception.primary, "admission")


class BoundedProtocolIntegrationTests(unittest.TestCase):
    def test_real_factory_bypasses_legacy_constructor_and_listeners(self):
        with PrimitiveHarness() as harness:
            with mock.patch.object(Protocol11, "__init__", side_effect=AssertionError("legacy-protocol")), \
                    mock.patch.object(transport_module.Transport, "set_listener",
                                      side_effect=AssertionError("legacy-listener")):
                connection = harness.open(vhost="mission")
            try:
                wire = b"".join(harness.tls.sent)
                self.assertTrue(wire.startswith(b"STOMP\n"))
                self.assertIn(b"accept-version:1.1\n", wire)
                self.assertIn(b"heart-beat:0,0\n", wire)
                self.assertIn(b"host:mission\n", wire)
                self.assertNotIn(b"deadline:", wire)
                self.assertNotIn(b"cancel:", wire)
                self.assertEqual(connection.transport.listeners, {})
                self.assertIsNone(connection.transport._bounded_receiver)
            finally:
                harness.close(connection)
            self.assertTrue(harness.tls.closed)

    def test_real_send_escapes_headers_preserves_binary_body_and_stays_worker_free(self):
        with PrimitiveHarness() as harness:
            connection = harness.open()
            try:
                sent_before = len(harness.tls.sent)
                body = b"a\x00b\xff"
                connection.send_bounded("topic:a\\b", body, 9,
                                        deadline=harness.deadline(), cancel=harness.cancel)
                wire = b"".join(harness.tls.sent[sent_before:])
                self.assertTrue(wire.startswith(b"SEND\n"))
                self.assertIn(b"destination:topic\\ca\\\\b\n", wire)
                self.assertIn(b"content-length:4\n", wire)
                self.assertIn(b"priority:9\n", wire)
                self.assertTrue(wire.endswith(b"\n\n" + body + b"\x00"))
                self.assertNotIn(b"deadline:", wire)
                self.assertNotIn(b"cancel:", wire)
                self.assertIsNone(connection.transport._bounded_receiver)
            finally:
                harness.close(connection)

    def test_real_factory_credential_and_host_rejection_precedes_socket_effects(self):
        for overrides in ({"username": "x" * 1025}, {"passcode": "x\n"},
                          {"vhost": "x" * 256}, {"username": TextSubclass("user")},
                          {"username": "\U0001f680" * 1024,
                           "passcode": "\U0001f680" * 1011 + "ab"}):
            with self.subTest(overrides=list(overrides)), PrimitiveHarness() as harness:
                with self.assertRaises(BoundedError) as raised:
                    harness.open(**overrides)
                self.assertEqual(raised.exception.primary, "admission")
                self.assertEqual(harness.allocations, [])
                self.assertEqual(harness.wraps, [])
                self.assertEqual(harness.tls.sent, [])

    def test_real_connection_rejects_legacy_lifecycle_before_effects(self):
        with PrimitiveHarness() as harness:
            connection = harness.open()
            try:
                sent_before = list(harness.tls.sent)
                for operation in (connection.connect, connection.disconnect):
                    with self.assertRaises(BoundedError) as raised:
                        operation()
                    self.assertEqual(raised.exception.primary, "legacy-path")
                    self.assertEqual(harness.tls.sent, sent_before)
                    self.assertIsNone(connection.transport._bounded_receiver)
            finally:
                harness.close(connection)

    def test_real_connection_rejects_all_legacy_protocol_routes_before_hooks(self):
        class HookCanary:
            def __getattribute__(self, name):
                raise AssertionError("legacy-input-hook")

            def __bool__(self):
                raise AssertionError("legacy-input-bool-hook")

        value = HookCanary()
        with PrimitiveHarness() as harness:
            connection = harness.open()
            try:
                sent_before = list(harness.tls.sent)
                operations = (
                    lambda: Protocol11.connect(connection, headers=value),
                    lambda: Protocol11.disconnect(connection, headers=value),
                    lambda: connection.send_frame(value, value, value),
                    lambda: connection.send(value, value, headers=value),
                    lambda: connection.subscribe(value, value, headers=value),
                    lambda: connection.unsubscribe(value, headers=value),
                    lambda: connection.abort(value, headers=value),
                    lambda: connection.ack(value, value, transaction=value),
                    lambda: connection.begin(value, headers=value),
                    lambda: connection.commit(value, headers=value),
                    lambda: connection.nack(value, value, transaction=value),
                )
                for operation in operations:
                    with self.assertRaises(BoundedError) as raised:
                        operation()
                    self.assertEqual(raised.exception.primary, "legacy-path")
                    self.assertEqual(harness.tls.sent, sent_before)
                    self.assertIsNone(connection.transport._bounded_receiver)
            finally:
                harness.close(connection)


class BoundedContextManagerTests(unittest.TestCase):
    def assert_strict_entry_rejected(self, use_with):
        with PrimitiveHarness() as harness:
            connection = harness.open()
            uuid = mock.Mock(return_value="context-receipt")
            listener = mock.Mock(return_value=mock.Mock())
            condition = mock.MagicMock()
            body_entered = []

            def snapshot():
                return [{name: value.copy() if type(value) in (dict, list) else value
                         for name, value in vars(owner).items()}
                        for owner in (connection, connection.transport)]

            try:
                with mock.patch.object(connect_module, "get_uuid", uuid), \
                        mock.patch.object(connect_module, "WaitingListener", listener), \
                        mock.patch.object(connection.transport,
                                          "_BaseTransport__listeners_change_condition", condition):
                    state_before = snapshot()
                    sent_before = list(harness.tls.sent)
                    with self.assertRaises(BoundedError) as raised:
                        if use_with:
                            with connection:
                                body_entered.append(True)
                        else:
                            connection.__enter__()
                    self.assertEqual(raised.exception.primary, "legacy-path")
                    self.assertEqual(raised.exception.cleanup, ())
                    self.assertEqual(body_entered, [])
                    self.assertEqual(snapshot(), state_before)
                    self.assertEqual(harness.tls.sent, sent_before)
                    self.assertEqual(uuid.call_count, 0)
                    self.assertEqual(listener.call_count, 0)
                    self.assertEqual(condition.__enter__.call_count, 0)
                    self.assertEqual(condition.__exit__.call_count, 0)
                    self.assertIs(connection.transport.socket, harness.tls)
                    self.assertTrue(connection.is_connected())
                    self.assertFalse(harness.tls.closed)
                    self.assertEqual(harness.tls.close_calls, 0)
            finally:
                harness.close(connection)
            self.assertIsNone(connection.transport.socket)
            self.assertTrue(harness.tls.closed)
            self.assertEqual(harness.tls.close_calls, 1)

    def test_strict_direct_context_entry_rejects_before_legacy_setup(self):
        self.assert_strict_entry_rejected(False)

    def test_strict_with_statement_never_enters_body_or_closes_owned_connection(self):
        self.assert_strict_entry_rejected(True)

    def assert_legacy_context(self, body_failure):
        receipt = "context-receipt"
        expected_wire = b"DISCONNECT\nreceipt:context-receipt\n\n\x00"
        waiting_class = connect_module.WaitingListener
        wait_receipt = waiting_class.wait_on_receipt
        wait_disconnected = waiting_class.wait_on_disconnected
        for connection_class in (connect_module.StompConnection10,
                                 connect_module.StompConnection11,
                                 connect_module.StompConnection12):
            with self.subTest(version=connection_class.__name__), PrimitiveHarness() as harness, \
                    ExitStack() as stack:
                events = []
                connection = connection_class([("192.0.2.1", 61613)],
                                              prefer_localhost=False, try_loopback_connect=False)
                controlled_socket = mock.Mock()
                controlled_socket.getsockname.return_value = ("192.0.2.2", 40000)
                connection.transport.socket = controlled_socket
                connection.transport.set_connected(True)

                def uuid():
                    events.append("uuid")
                    return receipt

                def make_listener(value):
                    events.append(("listener", value))
                    listener = waiting_class(value)
                    for condition in (listener.receipt_condition, listener.disconnect_condition):
                        stack.enter_context(mock.patch.object(
                            condition, "wait", side_effect=AssertionError("unexpected legacy wait")))
                    return listener

                def sent(data):
                    events.append(("send", data))
                    connection.disconnect_listener.on_receipt(
                        Frame("RECEIPT", {"receipt-id": receipt}))
                    connection.disconnect_listener.on_disconnected()

                def observe_receipt(listener):
                    events.append("receipt-wait")
                    return wait_receipt(listener)

                def observe_disconnected(listener):
                    events.append("disconnected-wait")
                    return wait_disconnected(listener)

                controlled_socket.sendall.side_effect = sent
                stack.enter_context(mock.patch.object(connect_module, "get_uuid", uuid))
                stack.enter_context(mock.patch.object(connect_module, "WaitingListener", make_listener))
                stack.enter_context(mock.patch.object(waiting_class, "wait_on_receipt", observe_receipt))
                stack.enter_context(mock.patch.object(waiting_class, "wait_on_disconnected",
                                                      observe_disconnected))
                stack.enter_context(mock.patch.object(connection.transport, "stop",
                                                      side_effect=lambda: events.append("stop")))
                stack.enter_context(mock.patch.object(threading.Thread, "start",
                                                      side_effect=AssertionError("unexpected worker")))
                failure = ValueError("controlled context body") if body_failure else None
                caught = None
                try:
                    with connection as entered:
                        self.assertIs(entered, connection)
                        self.assertEqual(connection.disconnect_receipt_id, receipt)
                        self.assertIs(connection.get_listener("ZZZZZ-disconnect-listener"),
                                      connection.disconnect_listener)
                        self.assertEqual(set(connection.transport.listeners),
                                         {"protocol-listener", "ZZZZZ-disconnect-listener"})
                        events.append("body")
                        if failure is not None:
                            raise failure
                except ValueError as error:
                    caught = error
                self.assertIs(caught, failure)
                self.assertEqual(events, ["uuid", ("listener", receipt), "body",
                                          ("send", expected_wire), "stop", "receipt-wait",
                                          "disconnected-wait"])
                self.assertEqual(connection.transport._BaseTransport__receipts,
                                 {receipt: "DISCONNECT"})
                self.assertEqual(connection.transport._BaseTransport__disconnect_receipt, receipt)
                self.assertFalse(connection.disconnect_listener.received)
                self.assertTrue(connection.disconnect_listener.disconnected)
                self.assertEqual(harness.allocations, [])
                self.assertEqual(harness.wraps, [])

    def test_legacy_context_entry_exit_preserves_receipt_and_wire_flow(self):
        self.assert_legacy_context(False)

    def test_legacy_context_exit_preserves_body_exception(self):
        self.assert_legacy_context(True)


class LoopbackProtocolTests(unittest.TestCase):
    def test_loopback_factory_rejects_subclass_before_initialization(self):
        class Subclass(StompConnection11):
            def __new__(cls, *args, **kwargs):
                raise AssertionError('subclass-construction')
            @classmethod
            def _open_bounded(cls, *args, **kwargs):
                raise AssertionError('subclass-factory-hook')
        with PrimitiveHarness(loopback=True) as h:
            with self.assertRaises(BoundedError) as error:
                Subclass.open_loopback_bounded(dial_address='127.0.0.1', port=61613,
                    username='', passcode='', deadline=h.deadline(), cancel=h.cancel)
            self.assertEqual(error.exception.primary, 'admission')
            self.assertEqual(h.allocations, [])

    def test_tls_factory_rejects_subclass_before_shared_factory_lookup(self):
        class Subclass(StompConnection11):
            @classmethod
            def _open_bounded(cls, *args, **kwargs):
                raise AssertionError('subclass-factory-hook')
        with PrimitiveHarness() as h:
            with self.assertRaises(BoundedError) as error:
                Subclass.open_bounded(dial_address='127.0.0.1', port=61614,
                    tls_identity='broker.example', ssl_context=h.context,
                    username='', passcode='', deadline=h.deadline(), cancel=h.cancel)
            self.assertEqual(error.exception.primary, 'admission')
            self.assertEqual(h.allocations, [])

    def test_loopback_credentials_and_vhost_reject_before_socket_effects(self):
        for values in ({'username': TextSubclass('user')}, {'passcode': 'x\n'},
                       {'username': 'x' * 1025}, {'vhost': 'x' * 256},
                       {'vhost': '\u00e9'}, {'passcode': b'not-text'}):
            with self.subTest(fields=list(values)), PrimitiveHarness(loopback=True) as h:
                with self.assertRaises(BoundedError) as error:
                    h.open(**values)
                self.assertEqual(error.exception.primary, 'admission')
                self.assertEqual(h.allocations, [])
                self.assertEqual(h.raw.sent, [])

    def test_loopback_real_factory_and_send_preserve_bounded_wire_contract(self):
        with PrimitiveHarness(loopback=True) as h:
            with mock.patch.object(Protocol11, '__init__', side_effect=AssertionError('legacy protocol')), \
                    mock.patch.object(transport_module.Transport, 'set_listener',
                                      side_effect=AssertionError('legacy listener')):
                connection = h.open(vhost='bench')
            try:
                expected = (b'STOMP\naccept-version:1.1\nheart-beat:0,0\n'
                            b'login:synthetic-user\npasscode:synthetic-pass\nhost:bench\n\n\0')
                self.assertEqual(b''.join(h.raw.sent), expected)
                self.assertEqual(connection.transport.listeners, {})
                before = len(h.raw.sent)
                connection.send_bounded('topic:a\\b', b'a\0b\xff', 9,
                                        deadline=h.deadline(), cancel=threading.Event())
                wire = b''.join(h.raw.sent[before:])
                self.assertIn(b'destination:topic\\ca\\\\b\n', wire)
                self.assertIn(b'content-length:4\n', wire)
                self.assertIn(b'priority:9\n', wire)
                self.assertTrue(wire.endswith(b'\n\na\0b\xff\0'))
                self.assertNotIn(b'deadline:', wire)
                self.assertNotIn(b'cancel:', wire)
                self.assertIsNone(connection.transport._bounded_receiver)
            finally:
                h.close(connection)

    def test_loopback_instance_rejects_legacy_routes_before_hooks(self):
        class HookCanary:
            def __getattribute__(self, name):
                raise AssertionError('legacy-input-hook')
            def __bool__(self):
                raise AssertionError('legacy-input-hook')
        value = HookCanary()
        with PrimitiveHarness(loopback=True) as h:
            connection = h.open()
            operations = (
                connection.__enter__, connection.connect, connection.disconnect,
                lambda: Protocol11.connect(connection, headers=value),
                lambda: Protocol11.disconnect(connection, headers=value),
                lambda: connection.send_frame(value, value, value),
                lambda: connection.send(value, value, headers=value),
                lambda: connection.subscribe(value, value, headers=value),
                lambda: connection.unsubscribe(value, headers=value),
                lambda: connection.abort(value, headers=value),
                lambda: connection.ack(value, value, transaction=value),
                lambda: connection.begin(value, headers=value),
                lambda: connection.commit(value, headers=value),
                lambda: connection.nack(value, value, transaction=value),
                lambda: connection.set_ssl(for_hosts=value),
                connection.transport.attempt_connection,
            )
            try:
                before = tuple(h.raw.sent)
                for operation in operations:
                    with self.assertRaises(BoundedError) as error:
                        operation()
                    self.assertEqual(error.exception.primary, 'legacy-path')
                    self.assertEqual(tuple(h.raw.sent), before)
                    self.assertTrue(connection.is_connected())
                    self.assertIsNone(connection.transport._bounded_receiver)
                self.assertEqual(len(h.allocations), 1)
            finally:
                h.close(connection)


if __name__ == "__main__":
    unittest.main()
