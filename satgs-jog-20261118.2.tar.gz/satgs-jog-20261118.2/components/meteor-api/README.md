```
#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2022 The MITRE Corporation. All Rights Reserved.                #
#############################################################################
```

# Standalone Python Messenger

## Development packaging

The development package now requires Python 3.9 or newer and protobuf `6.33.6`.
This deliberately replaces the conflicting historical protobuf pins. Generate
`src/meteor_api/protobufs/Meteor_pb2.py` from `Meteor.proto` before a normal
wheel build; the build fails if it is absent. Compiler and installer tools are
build-only, not runtime dependencies. Use the `zmq` extra for METEOR's optional
NumPy/ZeroMQ components; base Messenger does not import or require them.
`requirements.txt` describes the same base runtime. Existing notices and wire
schemas remain unchanged. This is unreleased development metadata, not an
owner-release declaration or target-platform qualification.

This repo contains the standalone python messenger, a python wrapper for Stomp/AMQ, and the METEOR app driver, a python API for applications to communicate with and control METEOR.

## Example  

See `sample_pulses.py` for a simple example of using the METEOR app driver. It assumes the 'meteor_api' package is installed and does not rely on relative imports.

## Setup:  Manually build and install wheel 

1) Clone this repo

2) Install the protobuf compiler, if it is not installed on the machine already (run `which protoc` to check)  

```
sudo apt install protobuf-compiler
```  

3) If installing standalone, create a new virtual environment. Otherwise, use the same virtual environment as the MSEL Ground Station.

```
cd meteor-api

# Use our branch
git checkout msel

# Create a new virtual environment for standalone installation
python3 -m venv .env
source ./.env/bin/activate

# OR

# Use the virtual environment in your ~/ground_station repo
cd ~/ground_station
source ./.env/bin/activate

```

4) Install the project. This should compile protobufs and place it in `src/meteor_api/protobufs` subdir:

```
python3 -m pip install -e .
```

5) Check install by opening python module and running:
```
from meteor_api.meteor_app_driver import *
from meteor_api.protobufs import Meteor_pb2 as mpb
```

## Unreleased strict Messenger candidate

The bounded owner API is an unreleased development candidate. It requires the
separately accepted amended lower transport source, not unmodified stomp.py 8.1.0.
The bench candidate pairs `meteor_api==2.2.0+bench.20261117.1` with
`stomp.py==8.1.0+bench.20261117.1`. These are distinct development identities,
not production admission. Requiring preparation is not compatibility with
unchanged `satgs.pointing.v1`.

Set `STOMP_SKIP_HOSTNAME_SCAN=1` before normal package import. Strict preparation
uses `prepare_transport(settings, cancel)` (also `Messenger.prepare_transport`).
Supply a Mapping containing exact built-in transport values:

| Setting | Required value |
| --- | --- |
| `amq_dial_address` | Canonical numeric IPv4/IPv6 string, no zone, at most 45 ASCII bytes |
| `amq_port` | Integer 1 through 65535, not bool |
| `amq_tls_server_name` | Separate canonical IP or DNS certificate identity, at most 253 ASCII bytes |
| `amq_stomp_host` | Optional STOMP host, at most 255 ASCII bytes; absent remains omitted |
| `amq_ca_pem` | Public CERTIFICATE-only PEM string, at most 65536 ASCII bytes |
| `amq_username`, `amq_password` | Each at most 1024 characters and 4096 UTF-8 bytes |
| `amq_use_ssl` | Exactly `True` |

The ordinary TLS preparation accepts no `amq_transport` key. An absent key
preserves this API; unknown markers do not select a fallback transport.

Wire text excludes controls; the complete CONNECT header bound is 8192 bytes.
Only these transport values are copied. Preparation creates a private verifying
TLS 1.2+ context directly from admitted cadata, without default roots, keylog
helpers, private keys or caller contexts. Preparation is outside acquisition's
deadline; native certificate parsing is not claimed interruptible. Its opaque
result binds the copied values and exact `threading.Event`, and is single-use.

`Messenger.open_bounded(settings, deadline, cancel, *, prepared)` acquires
synchronously under one absolute monotonic deadline. Strict instances use:

```python
messenger.publish(topic, serialized_bytes, priority, deadline=deadline, cancel=cancel)
messenger.subscribe(topic, callback, identifier, deadline=deadline, cancel=cancel)
messenger.cancelSubscribe(topic, callback, identifier, deadline=deadline, cancel=cancel)
messenger.close(deadline)
```

Each operation requires its own explicit deadline and an exact built-in
`threading.Event`. Preparation and open must use the same lifecycle Event.
After open returns, an operation may use a different Event; cancelling that
operation alone does not set the shared lifecycle gate. The original lifecycle
Event remains authoritative for the receiver and all callers, including those
using different operation Events. Do not clear an operation Event while any
invocation using it remains active. Cancellation is observed at the existing
checks, not guaranteed to capture a transient set-and-clear.

Equality is expired. Topics are nonempty built-in strings of at most 256
characters/1024 UTF-8 bytes. Identifiers are built-in strings, empty allowed, with
the same size bounds. Bodies are pre-serialized built-in bytes up to 262144 bytes;
priority is absent or an integer 0 through 9, not bool. Strict code does not call
arbitrary serializers, callback equality or string-conversion hooks. Successful
send means local submission only, not broker receipt, delivery or physical action.

Each instance admits at most 64 simultaneous caller operations, 128 wire topics
and 256 registrations, including unresolved debt. Wire IDs increase without reuse
through `2**63 - 1`. Duplicate registrations share their wire subscription;
removal removes one exact token, and only the last removes the wire. Fresh Python
bound methods match by function/self identity. Retain strong references to
callbacks, their receivers and other externally owned callable objects until
explicit removal/close completes. No arbitrary destructor latency is bounded.

First-wire transactions serialize admission, preserving the lower's original
8-frame/1048576-byte pending bound. A lower receiver may hold its current frame
until owner commit under the originating subscription controls; there is no
second owner queue and no application callback before owner admission. Failed
compensation leaves counted, nondispatchable debt that explicit cancellation or
close can later observe/reclaim. It is not proof of broker rollback. Callbacks run
outside owner locks on the actual lower receiver; self-cancellation is supported.

Pending dispatch observes the exact published topic and producer outcome before
each owner-state wait. Expiry, operation cancellation or unsuccessful completion
releases its held frame without that lock; counted debt remains for explicit
reconciliation. Successful commit is distinct from producer completion. Once
committed, neither the setup deadline nor its operation Event expires later
reception. Explicit registration removal uses its supplied deadline and a valid
noncancelled operation Event; cancellation does not silently unregister callbacks. The bounded built-in topic
snapshot and completion/reference publication rely on the adopted supported-
CPython assumptions, not a portable lock-free guarantee.

Lifecycle cancellation or disconnect terminal-gates the strict instance. A
distinct operation cancelled while waiting for owner/lower state or another
caller's receiver startup does not cancel those callers. Independent cancellation
is not a rollback guarantee: completed wire effects may leave counted registration
debt, and uncertain native send progress still requires shared abort. Failure of
the first receiver-startup reservation remains terminal, even before observable
wire or thread-start effects. No arbitrary native operation or callback is made
preemptible. There is no implicit reconnect/resubscribe. Passive `close` performs no DISCONNECT, receipt
wait or TLS unwrap. Normal return means observed completion; fixed
`MessengerError.primary` and separate `.cleanup` categories report incomplete
release, including self-close non-quiescence. Later explicit close may observe
completion. No callback is killed. Native abort failure is not qualified and a
reported residual socket is not successful reclamation.

`diagnostics()` exposes fixed categories and saturating counters only. Optional
recording is nonblocking, payload-free and cannot replace the primary cause.
`strict_instance_compatible(settings)` is a side-effect-free, nonblocking check
of bound provenance/settings, the actual lower endpoint and nonterminal state,
not network health or production release admission. It rejects legacy and
plaintext bench instances and lock contention.

### Explicit local plaintext bench transport

The separate `prepare_bench_loopback_transport(settings, cancel)` function
(also `Messenger.prepare_bench_loopback_transport`) and
`Messenger.open_bench_loopback_bounded(settings, deadline, cancel, *, prepared)`
support the explicitly selected local bench workflow. They do not change the
ordinary TLS API or admit scheduled/operational consumers to plaintext.

Supply `amq_transport="loopback-plaintext-bench"`, `amq_use_ssl=False`, and the
exact `amq_dial_address="127.0.0.1"`. `amq_port` remains a built-in integer from
1 through 65535. Explicit nonempty `amq_username` and `amq_password` are required,
with the same text and CONNECT header bounds above. The optional `amq_stomp_host`
retains its existing semantics. Both `amq_tls_server_name` and `amq_ca_pem` must
be absent, not null. Hostnames, loopback aliases, IPv6, other numeric addresses,
implicit mode selection and unknown markers are rejected before acquisition.

Preparation is inert and binds the explicit mode, copied settings and exact
lifecycle Event. It is single-use and cannot be exchanged with TLS preparation.
Open uses the lower's dedicated raw loopback factory and verifies its bound
endpoint. `bench_loopback_instance_compatible(settings)` checks this mode and
endpoint without sending traffic; it rejects TLS and legacy instances. Both
bounded modes reuse the same operations, receiver admission, cancellation,
fixed diagnostics and passive cleanup rules. There is no TLS failure fallback,
DNS lookup, reconnect, second queue or new worker implementation.

Plaintext has no encryption or authenticated broker identity. Credentials and
messages are visible to the local transport; loopback is not a secure-peer claim.
This API only constrains its own dial target. It does not configure a broker,
prove the broker listens only on loopback, start a service or qualify a live
device. Keep private credentials outside source and logs. The local broker and
the separately admitted bench owner remain explicit operator responsibilities.

Legacy eager construction, positional operations, protobuf-like serialization,
listener callbacks and reconnect remain separate and unbounded. The setup and
operational examples above document historical legacy use, not commands validated
for this strict candidate. Controlled tests do not qualify native TLS trust,
abort reclamation, OS/thread scheduling, older Python runtimes, ARM64, broker
interoperability or physical behavior. Independent owner/dependency acceptance
and release/consumer work remain separate gates.

# Change Log

### April 2025: Introduced setuptools-protobuf to auto compile protobufs

- Updated readme
- Updated path to Meteor.proto & compiled protobuf file path
- Updated import statements to point to new path

### June 2023: Add Update PDAP Params Functionality

- **POTENTIALLY BREAKING CHANGE:** Order of constructor arguments `name` and `credentials_json` swapped
- Constructor argument `credentials_json` made optional, since amq login in the underlying messenger is optional
- Adds `update_pdap_params` function to facilitate setting PDAP parameters in a scripted workflow
- Adds `get_current_pdap_params` function to facilitate getting the current PDAP parameters of the system, and supporting callback function `current_pdap_params_cb`
- Minor cleanup
