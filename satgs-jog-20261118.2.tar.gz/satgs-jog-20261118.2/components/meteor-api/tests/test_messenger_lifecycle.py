"""Hardware-free owner/lower contract tests with controlled TLS/socket primitives."""

import base64
import socket
import ssl
import sys
import threading
import time
import unittest
from collections import deque
from contextlib import ExitStack
from types import MappingProxyType
from unittest import mock

from meteor_api import messenger
from stomp import transport


CONNECTED = b'CONNECTED\nversion:1.1\nheart-beat:0,0\n\n\0'
PUBLIC_CA = ('-----BEGIN CERTIFICATE-----\n' +
             base64.b64encode(b'synthetic controlled public certificate').decode('ascii') +
             '\n-----END CERTIFICATE-----\n')
CANARY = 'PRIVATE_MESSENGER_CANARY'


def settings(**changes):
    result = {
        'amq_dial_address': '192.0.2.7', 'amq_port': 61614,
        'amq_tls_server_name': 'broker.example', 'amq_ca_pem': PUBLIC_CA,
        'amq_username': 'synthetic-user', 'amq_password': 'synthetic-password',
        'amq_use_ssl': True,
    }
    result.update(changes)
    return result


def loopback_settings(**changes):
    result = {
        'amq_transport': 'loopback-plaintext-bench', 'amq_use_ssl': False,
        'amq_dial_address': '127.0.0.1', 'amq_port': 61613,
        'amq_username': 'synthetic-user', 'amq_password': 'synthetic-password',
    }
    result.update(changes)
    return result


class Clock:
    def __init__(self, value=10.0):
        self.value = value

    def __call__(self):
        return self.value


class PrimitiveRawSocket:
    def __init__(self, harness, name, resource):
        self.harness = harness
        self.name = name
        self.resource = resource
        self.detached = False
        self.close_calls = 0
        self.sent = []
        self.recv_script = deque()
        self.send_script = deque()
        self.addresses = []
        self.blocking = []
        self.close_error = None
        self.tls = None

    @staticmethod
    def result(action):
        if isinstance(action, BaseException):
            raise action
        return action() if callable(action) else action

    def setblocking(self, value):
        self.blocking.append(value)
        self.harness.phase(self.name + '-blocking')

    def connect_ex(self, address):
        self.addresses.append(address)
        self.harness.phase('connect')
        return self.harness.connect_result

    def getsockopt(self, level, option):
        if (level, option) != (socket.SOL_SOCKET, socket.SO_ERROR):
            raise AssertionError('unexpected socket option')
        self.harness.phase('socket-error')
        return 0

    def _would_block(self):
        return BlockingIOError()

    def recv(self, size):
        if self.resource['closed']:
            raise OSError('controlled closed socket')
        self.harness.phase('recv')
        if not self.recv_script:
            raise self._would_block()
        result = self.result(self.recv_script.popleft())
        if type(result) is bytes and len(result) > size:
            self.recv_script.appendleft(result[size:])
            return result[:size]
        return result

    def send(self, data):
        if self.resource['closed']:
            raise OSError('controlled closed socket')
        self.harness.phase('send', data)
        amount = self.result(self.send_script.popleft()) if self.send_script else len(data)
        if amount is None:
            amount = len(data)
        self.sent.append(bytes(data[:amount]))
        return amount

    def close(self):
        self.close_calls += 1
        self.harness.phase('close')
        if self.close_error is not None:
            raise self.close_error
        if not self.detached:
            self.resource['closed'] = True

    def shutdown(self, how):
        raise AssertionError('passive close must not use shutdown')

    def sendall(self, data):
        raise AssertionError('strict sends require progress accounting')


class PrimitiveSocket(PrimitiveRawSocket):
    def _would_block(self):
        return ssl.SSLWantReadError()

    def do_handshake(self):
        self.harness.phase('handshake')

    def pending(self):
        if self.recv_script and type(self.recv_script[0]) is bytes:
            return len(self.recv_script[0])
        return 0

    def unwrap(self):
        raise AssertionError('passive close must not unwrap TLS')


class PrimitiveHarness:
    """Only socket, TLS context, readiness and clock primitives are replaced."""
    def __init__(self, real_time=True, loopback=False):
        self.real_time = real_time
        self.loopback = loopback
        self.real_clock = time.monotonic
        self.real_sleep = time.sleep
        self.clock = Clock()
        self.cancel = threading.Event()
        self.contexts = []
        self.raws = []
        self.tls_sockets = []
        self.allocations = []
        self.wraps = []
        self.waits = []
        self.instances = []
        self.hooks = {}
        self.connect_result = 0
        self.incoming = CONNECTED
        self.stack = ExitStack()

    def phase(self, name, *args):
        hook = self.hooks.get(name)
        if hook is not None:
            hook(*args)

    def now(self):
        return self.real_clock() if self.real_time else self.clock()

    def deadline(self, seconds=2.0):
        return self.now() + seconds

    def allocate(self, *args, **kwargs):
        resource = {'closed': False}
        if self.loopback:
            raw = PrimitiveRawSocket(self, 'raw', resource)
            raw.recv_script.append(self.incoming)
        else:
            raw = PrimitiveSocket(self, 'raw', resource)
            tls = PrimitiveSocket(self, 'tls', resource)
            raw.tls = tls
            tls.recv_script.append(self.incoming)
            self.tls_sockets.append(tls)
        self.raws.append(raw)
        self.allocations.append((args, kwargs))
        self.phase('allocate')
        return raw

    def readiness(self, reads, writes, errors, timeout):
        if not 0 < timeout <= 0.010000001:
            raise AssertionError('invalid readiness budget')
        self.waits.append(timeout)
        self.phase('wait')
        if writes:
            return [], writes, []
        if reads and reads[0].recv_script:
            return reads, [], []
        if self.real_time:
            self.real_sleep(min(timeout, 0.001))
        else:
            self.clock.value += timeout
        return [], [], []

    def __enter__(self):
        owner = self

        class ControlledContext:
            def __init__(self, protocol):
                self.protocol = protocol
                self.verify_mode = ssl.CERT_NONE
                self.check_hostname = False
                if hasattr(ssl, 'TLSVersion'):
                    self.minimum_version = ssl.TLSVersion.MINIMUM_SUPPORTED
                self.options = 0
                self.loaded = []
                owner.contexts.append(self)
                owner.phase('context')

            def load_verify_locations(self, cafile=None, capath=None, cadata=None):
                if cafile is not None or capath is not None:
                    raise AssertionError('trust must use admitted cadata')
                self.loaded.append(cadata)
                owner.phase('trust')

            def load_default_certs(self, *args, **kwargs):
                raise AssertionError('default trust roots forbidden')

            def load_cert_chain(self, *args, **kwargs):
                raise AssertionError('private key loading forbidden')

            def wrap_socket(self, raw, server_hostname=None,
                            do_handshake_on_connect=True, **kwargs):
                owner.wraps.append((server_hostname, do_handshake_on_connect, kwargs))
                owner.phase('wrap')
                raw.detached = True
                return raw.tls

        try:
            self._install_primitives(ControlledContext)
        except BaseException:
            self.stack.close()
            raise
        return self

    def _install_primitives(self, context):
        self.worker_baseline = set(threading.enumerate())
        self.stack.enter_context(mock.patch.object(ssl, 'SSLContext', context))
        self.stack.enter_context(mock.patch.object(ssl, 'create_default_context',
                                                   side_effect=AssertionError('default context forbidden')))
        self.stack.enter_context(mock.patch.object(socket, 'socket', self.allocate))
        self.stack.enter_context(mock.patch.object(socket, 'getaddrinfo',
                                                   side_effect=AssertionError('DNS forbidden')))
        self.stack.enter_context(mock.patch.object(socket, 'create_connection',
                                                   side_effect=AssertionError('legacy connector forbidden')))
        self.stack.enter_context(mock.patch.object(transport.select, 'select', self.readiness))
        if not self.real_time:
            self.stack.enter_context(mock.patch.object(messenger, 'monotonic', self.clock))
            self.stack.enter_context(mock.patch.object(transport, 'monotonic', self.clock))

    def open(self, values=None, cancel=None):
        values = (loopback_settings() if self.loopback else settings()) if values is None else values
        cancel = self.cancel if cancel is None else cancel
        prepare = messenger.prepare_bench_loopback_transport if self.loopback else messenger.prepare_transport
        acquire = (messenger.Messenger.open_bench_loopback_bounded if self.loopback
                   else messenger.Messenger.open_bounded)
        prepared = prepare(values, cancel)
        instance = acquire(values, self.deadline(), cancel, prepared=prepared)
        self.instances.append(instance)
        return instance

    def controls(self):
        return {'deadline': self.deadline(), 'cancel': self.cancel}

    def message(self, wire_id, body, destination='topic', socket_index=-1):
        frame = ('MESSAGE\nsubscription:%s\ndestination:%s\ncontent-length:%s\n\n' %
                 (wire_id, destination, len(body))).encode('ascii') + body + b'\0'
        sockets = self.raws if self.loopback else self.tls_sockets
        sockets[socket_index].recv_script.append(frame)

    def __exit__(self, kind, value, tb):
        self.recovery_failures = []
        retry = []
        live_workers = []
        try:
            self.hooks.clear()
            for raw in self.raws:
                raw.close_error = None
                if raw.tls is not None:
                    raw.tls.close_error = None
            for instance in self.instances:
                try:
                    instance.close(self.deadline())
                except messenger.MessengerError:
                    retry.append(instance)
                except BaseException:
                    self.recovery_failures.append('unexpected-owner-close')
        finally:
            try:
                self.cancel.set()
                for raw in self.raws:
                    try:
                        if not raw.resource['closed']:
                            (raw if self.loopback else raw.tls).close()
                    except BaseException:
                        self.recovery_failures.append('controlled-socket-release')
            finally:
                try:
                    end = self.real_clock() + 2.0
                    workers = [worker for worker in threading.enumerate()
                               if worker not in self.worker_baseline
                               and worker.name == 'stomp-bounded-receiver']
                    for worker in workers:
                        try:
                            worker.join(max(0, end - self.real_clock()))
                        except BaseException:
                            self.recovery_failures.append('receiver-join')
                        if worker.is_alive():
                            live_workers.append(worker)
                    for instance in retry:
                        try:
                            instance.close(self.deadline())
                        except BaseException:
                            self.recovery_failures.append('owner-close-retry')
                finally:
                    if live_workers:
                        self.recovery_failures.append('live-receiver-primitives-retained')
                    else:
                        self.stack.close()
        if kind is None and self.recovery_failures:
            raise AssertionError(tuple(self.recovery_failures))


class StrictTestCase(unittest.TestCase):
    def wait_until(self, harness, predicate):
        end = harness.real_clock() + 2.0
        while not predicate() and harness.real_clock() < end:
            harness.real_sleep(.001)
        self.assertTrue(predicate())

    def rejected(self, call, primary=None):
        with self.assertRaises(messenger.MessengerError) as caught:
            call()
        error = caught.exception
        self.assertIs(type(error.primary), str)
        self.assertIs(type(error.cleanup), tuple)
        self.assertNotIn(CANARY, str(error))
        self.assertIsNone(error.__cause__)
        if primary is not None:
            self.assertEqual(error.primary, primary)
        return error


class ControlledCallers:
    def __init__(self, harness, *releases):
        self.harness = harness
        self.releases = releases
        self.workers = []
        self.results = []

    def start(self, action):
        def invoke():
            try:
                action()
                self.results.append(('success', ()))
            except messenger.MessengerError as error:
                self.results.append((error.primary, error.cleanup))
            except BaseException:
                self.results.append(('fixture-unexpected', ()))
        worker = threading.Thread(target=invoke, name='messenger-fixture-caller')
        self.workers.append(worker)
        worker.start()
        return worker

    def finish(self):
        for release in self.releases:
            release.set()
        end = self.harness.real_clock() + 3.0
        for worker in self.workers:
            if worker.ident is not None:
                worker.join(max(0, end - self.harness.real_clock()))
        if any(worker.is_alive() for worker in self.workers):
            self.harness.cancel.set()
            end = self.harness.real_clock() + 2.0
            for worker in self.workers:
                if worker.ident is not None:
                    worker.join(max(0, end - self.harness.real_clock()))
        if any(worker.is_alive() for worker in self.workers):
            raise AssertionError('fixture retained a live caller')


class PreparationTests(StrictTestCase):
    def test_mapping_and_static_alias_use_private_verified_context_without_effects(self):
        with PrimitiveHarness() as h:
            values = MappingProxyType(settings())
            prepared = messenger.Messenger.prepare_transport(values, h.cancel)
            self.assertEqual(h.allocations, [])
            self.assertEqual(len(h.contexts), 1)
            context = h.contexts[0]
            self.assertEqual(context.protocol, ssl.PROTOCOL_TLS_CLIENT)
            self.assertEqual(context.verify_mode, ssl.CERT_REQUIRED)
            self.assertIs(context.check_hostname, True)
            if hasattr(ssl, 'TLSVersion'):
                self.assertGreaterEqual(context.minimum_version, ssl.TLSVersion.TLSv1_2)
            else:
                forbidden = ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
                self.assertEqual(context.options & forbidden, forbidden)
            self.assertEqual(context.loaded, [PUBLIC_CA])
            for secret in ('synthetic-user', 'synthetic-password', PUBLIC_CA):
                self.assertNotIn(secret, repr(prepared))

    def test_non_mapping_and_non_event_inputs_reject_without_context_or_socket(self):
        with PrimitiveHarness() as h:
            for values in (None, [], (), 'settings'):
                self.rejected(lambda: messenger.prepare_transport(values, h.cancel))
            for cancel in (None, object(), False):
                self.rejected(lambda: messenger.prepare_transport(settings(), cancel))
            self.assertEqual(h.contexts, [])
            self.assertEqual(h.allocations, [])

    def test_missing_required_fields_reject_before_connection_effects(self):
        with PrimitiveHarness() as h:
            for key in settings():
                values = settings()
                del values[key]
                with self.subTest(field=key):
                    self.rejected(lambda: messenger.prepare_transport(values, h.cancel))
            self.assertEqual(h.allocations, [])

    def test_invalid_endpoint_identity_and_exact_types_reject(self):
        class String(str):
            pass

        with PrimitiveHarness() as h:
            cases = [
                ('amq_dial_address', 'broker.example'), ('amq_dial_address', 'fe80::1%eth0'),
                ('amq_dial_address', '192.000.2.7'), ('amq_dial_address', 'x' * 46),
                ('amq_dial_address', String('192.0.2.7')), ('amq_port', True),
                ('amq_port', 0), ('amq_port', 65536), ('amq_tls_server_name', ''),
                ('amq_tls_server_name', '*.example'), ('amq_tls_server_name', '-bad.example'),
                ('amq_tls_server_name', 'bad..example'), ('amq_tls_server_name', 'b\n.example'),
                ('amq_tls_server_name', 'é.example'), ('amq_use_ssl', False),
                ('amq_use_ssl', 1), ('amq_username', b'user'),
                ('amq_password', 'bad\npassword'), ('amq_stomp_host', 'bad\rhost'),
                ('amq_stomp_host', 'x' * 256), ('amq_stomp_host', 3),
            ]
            for key, value in cases:
                with self.subTest(field=key, value_type=type(value).__name__):
                    self.rejected(lambda: messenger.prepare_transport(settings(**{key: value}), h.cancel))
            self.assertEqual(h.allocations, [])

    def test_public_ca_maximum_and_maximum_plus_one(self):
        with PrimitiveHarness() as h:
            maximum = PUBLIC_CA + ' ' * (65536 - len(PUBLIC_CA))
            messenger.prepare_transport(settings(amq_ca_pem=maximum), h.cancel)
            self.assertEqual(h.contexts[-1].loaded, [maximum])
            self.rejected(lambda: messenger.prepare_transport(settings(amq_ca_pem=maximum + ' '), h.cancel))
            self.assertEqual(h.allocations, [])

    def test_only_public_certificate_pem_is_admitted(self):
        with PrimitiveHarness() as h:
            for pem in ('', ' ', b'bytes', 'not pem',
                        '-----BEGIN PRIVATE KEY-----\nQQ==\n-----END PRIVATE KEY-----',
                        PUBLIC_CA + 'unrelated trailing data',
                        '-----BEGIN CERTIFICATE-----\n%%%\n-----END CERTIFICATE-----',
                        '-----BEGIN CERTIFICATE-----\n-----END CERTIFICATE-----',
                        PUBLIC_CA.replace('END CERTIFICATE', 'END PUBLIC KEY')):
                with self.subTest(pem_type=type(pem).__name__):
                    self.rejected(lambda: messenger.prepare_transport(settings(amq_ca_pem=pem), h.cancel))
            self.assertEqual(h.allocations, [])

    def test_prepare_cancellation_before_and_after_context_trust(self):
        with PrimitiveHarness() as h:
            h.cancel.set()
            self.rejected(lambda: messenger.prepare_transport(settings(), h.cancel), 'cancelled')
            self.assertEqual(h.contexts, [])
            h.cancel.clear()
            h.hooks['trust'] = h.cancel.set
            self.rejected(lambda: messenger.prepare_transport(settings(), h.cancel), 'cancelled')
            self.assertEqual(h.allocations, [])

    def test_context_failure_is_payload_free(self):
        class Failure(Exception):
            def __str__(self):
                raise AssertionError('raw context exception formatted')

        with PrimitiveHarness() as h:
            def fail():
                raise Failure(CANARY)
            h.hooks['trust'] = fail
            self.rejected(lambda: messenger.prepare_transport(settings(amq_password=CANARY), h.cancel))
            self.assertEqual(h.allocations, [])

    def test_settings_copy_ignores_unrelated_values_and_binds_required_values(self):
        with PrimitiveHarness() as h:
            values = settings(unrelated=object())
            prepared = messenger.prepare_transport(values, h.cancel)
            values['unrelated'] = object()
            instance = messenger.Messenger.open_bounded(values, h.deadline(), h.cancel, prepared=prepared)
            h.instances.append(instance)
            self.assertTrue(instance.strict_instance_compatible(settings()))
            values = settings()
            prepared = messenger.prepare_transport(values, h.cancel)
            values['amq_password'] = 'different'
            before = len(h.allocations)
            self.rejected(lambda: messenger.Messenger.open_bounded(values, h.deadline(), h.cancel, prepared=prepared))
            self.assertEqual(len(h.allocations), before)


class FactoryTests(StrictTestCase):
    def test_real_lower_handshake_is_worker_free_and_names_stay_separate(self):
        with PrimitiveHarness() as h:
            workers = set(threading.enumerate())
            instance = h.open(MappingProxyType(settings(amq_stomp_host='virtual-host')))
            self.assertIsInstance(instance, messenger.Messenger)
            self.assertEqual(set(threading.enumerate()), workers)
            self.assertEqual(h.allocations, [((socket.AF_INET, socket.SOCK_STREAM), {})])
            self.assertEqual(h.raws[0].addresses, [('192.0.2.7', 61614)])
            self.assertEqual(h.wraps, [('broker.example', False, {})])
            wire = b''.join(h.tls_sockets[0].sent)
            self.assertIn(b'host:virtual-host\n', wire)
            self.assertIn(b'accept-version:1.1\n', wire)
            self.assertIn(b'heart-beat:0,0\n', wire)
            self.assertNotIn(b'deadline:', wire)
            self.assertNotIn(b'cancel:', wire)

    def test_absent_optional_host_stays_omitted_and_ipv6_stays_numeric(self):
        with PrimitiveHarness() as h:
            h.open(settings(amq_dial_address='2001:db8::1', amq_tls_server_name='other.example'))
            self.assertEqual(h.allocations, [((socket.AF_INET6, socket.SOCK_STREAM), {})])
            self.assertEqual(h.raws[0].addresses, [('2001:db8::1', 61614, 0, 0)])
            self.assertNotIn(b'\nhost:', b''.join(h.tls_sockets[0].sent))
            self.assertEqual(h.wraps[0][0], 'other.example')

    def test_foreign_reused_and_event_mismatched_preparation_reject_before_allocation(self):
        with PrimitiveHarness() as h:
            values = settings()
            for prepared in (None, object(), values):
                self.rejected(lambda: messenger.Messenger.open_bounded(values, h.deadline(), h.cancel, prepared=prepared))
            self.assertEqual(h.allocations, [])
            prepared = messenger.prepare_transport(values, h.cancel)
            self.rejected(lambda: messenger.Messenger.open_bounded(values, h.deadline(), threading.Event(), prepared=prepared))
            self.assertEqual(h.allocations, [])
            prepared = messenger.prepare_transport(values, h.cancel)
            instance = messenger.Messenger.open_bounded(values, h.deadline(), h.cancel, prepared=prepared)
            h.instances.append(instance)
            self.rejected(lambda: messenger.Messenger.open_bounded(values, h.deadline(), h.cancel, prepared=prepared))
            self.assertEqual(len(h.allocations), 1)

    def test_exact_open_deadline_boundary_and_invalid_deadlines(self):
        with PrimitiveHarness(real_time=False) as h:
            for deadline in (h.now() - 1, h.now(), True, float('inf'), float('nan'), None, '11'):
                prepared = messenger.prepare_transport(settings(), h.cancel)
                with self.subTest(deadline_type=type(deadline).__name__):
                    self.rejected(lambda: messenger.Messenger.open_bounded(settings(), deadline, h.cancel, prepared=prepared))
            self.assertEqual(h.allocations, [])
            instance = h.open()
            self.assertTrue(instance.strict_instance_compatible(settings()))

    def test_failed_acquisition_phases_release_owned_resource_without_worker(self):
        for phase in ('raw-blocking', 'connect', 'socket-error', 'wrap', 'handshake', 'send', 'recv'):
            with self.subTest(phase=phase), PrimitiveHarness() as h:
                workers = set(threading.enumerate())
                def fail(*args):
                    raise OSError(CANARY)
                h.hooks[phase] = fail
                self.rejected(lambda: h.open())
                self.assertEqual(set(threading.enumerate()), workers)
                self.assertEqual(len(h.raws), 1)
                self.assertTrue(h.raws[0].resource['closed'])
                self.assertEqual(h.raws[0].close_calls + h.tls_sockets[0].close_calls, 1)

    def test_mid_handshake_cancellation_and_late_success_are_not_accepted(self):
        for cancelled in (False, True):
            with self.subTest(cancelled=cancelled), PrimitiveHarness(real_time=False) as h:
                def stop():
                    if cancelled:
                        h.cancel.set()
                    else:
                        h.clock.value = 12.0
                h.hooks['handshake'] = stop
                self.rejected(lambda: h.open(), 'cancelled' if cancelled else 'deadline')
                self.assertTrue(h.raws[0].resource['closed'])
                self.assertEqual(h.tls_sockets[0].close_calls, 1)

    def test_fresh_operation_budget_is_not_the_open_deadline(self):
        with PrimitiveHarness(real_time=False) as h:
            instance = h.open()
            h.clock.value = 20.0
            instance.publish('topic', b'body', deadline=21.0, cancel=h.cancel)
            self.assertIn(b'body\0', h.tls_sockets[0].sent[-1])

    def test_wrapper_final_admission_releases_actual_returned_lower(self):
        for cancelled in (False, True):
            with self.subTest(cancelled=cancelled), PrimitiveHarness(real_time=False) as h:
                final_lower_checks = []
                deadline = h.deadline()
                prepared = messenger.prepare_transport(settings(), h.cancel)

                def lower_clock():
                    frame = sys._getframe(1)
                    try:
                        if (frame.f_code.co_name == '_check_bounded'
                                and frame.f_back.f_code.co_name == '_commit_open_bounded'):
                            # Keep this final lower sample valid; change the next owner observation.
                            final_lower_checks.append(frame.f_locals['self'])
                            if cancelled:
                                h.cancel.set()
                            else:
                                h.clock.value = deadline
                            return deadline - 1
                        return h.clock()
                    finally:
                        del frame

                workers = set(threading.enumerate())
                with mock.patch.object(transport, 'monotonic', lower_clock):
                    self.rejected(lambda: messenger.Messenger.open_bounded(
                        settings(), deadline, h.cancel, prepared=prepared),
                        'cancelled' if cancelled else 'deadline')
                self.assertEqual(len(final_lower_checks), 1)
                self.assertTrue(final_lower_checks[0]._bounded_returned)
                self.assertTrue(h.raws[0].resource['closed'])
                self.assertEqual(h.tls_sockets[0].close_calls, 1)
                self.assertEqual(set(threading.enumerate()), workers)


class OperationTests(StrictTestCase):
    def test_publish_exact_wire_priority_and_local_controls(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            instance.publish('topic', b'payload', 9, **h.controls())
            self.assertEqual(h.tls_sockets[0].sent[-1],
                             b'SEND\ndestination:topic\ncontent-length:7\npriority:9\n\npayload\0')
            instance.publish('topic', b'\0', None, **h.controls())
            self.assertEqual(h.tls_sockets[0].sent[-1],
                             b'SEND\ndestination:topic\ncontent-length:1\n\n\0\0')

    def test_strict_operations_require_controls_and_exact_event_type(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            callback = lambda body, identifier: None
            before = list(h.tls_sockets[0].sent)
            self.rejected(lambda: instance.publish('topic', b'body'))
            self.rejected(lambda: instance.subscribe('topic', callback, 'id'))
            self.rejected(lambda: instance.cancelSubscribe('topic', callback, 'id'))
            self.rejected(lambda: instance.publish('topic', b'body', deadline=h.deadline(), cancel=object()))
            self.assertEqual(h.tls_sockets[0].sent, before)

    def test_body_priority_and_topic_input_boundaries(self):
        class Bytes(bytes):
            pass

        class Serializer:
            def SerializeToString(self):
                raise AssertionError('strict path invoked arbitrary serialization')

        with PrimitiveHarness() as h:
            instance = h.open()
            instance.publish('x' * 256, b'x' * 262144, 9, **h.controls())
            for body in (b'x' * 262145, bytearray(b'x'), Bytes(b'x'), Serializer(), 'text'):
                self.rejected(lambda: instance.publish('topic', body, **h.controls()))
            for priority in (True, -1, 10, 1.0, '9'):
                self.rejected(lambda: instance.publish('topic', b'x', priority, **h.controls()))
            for topic in ('', 'x' * 257, 'bad\n', 'bad\0', 3):
                self.rejected(lambda: instance.publish(topic, b'x', **h.controls()))
            instance.publish('\U0001f600' * 256, b'body', 0, **h.controls())

    def test_identifier_maximum_and_maximum_plus_one(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            callback = lambda body, identifier: None
            for identifier in ('', 'x' * 256, '\U0001f600' * 256):
                instance.subscribe('topic', callback, identifier, **h.controls())
                instance.cancelSubscribe('topic', callback, identifier, **h.controls())
            for identifier in ('x' * 257, '\U0001f600' * 257, b'id', None):
                self.rejected(lambda: instance.subscribe('topic', callback, identifier, **h.controls()))

    def test_shared_topic_duplicate_removal_keeps_survivors_and_exact_wire_id(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            observed = []
            delivered = threading.Event()
            def callback(body, identifier):
                observed.append((body, identifier))
                delivered.set()
            instance.subscribe('topic', callback, 'same', **h.controls())
            instance.subscribe('topic', callback, 'same', **h.controls())
            self.assertEqual(sum(frame.startswith(b'SUBSCRIBE\n') for frame in h.tls_sockets[0].sent), 1)
            instance.cancelSubscribe('topic', callback, 'same', **h.controls())
            self.assertFalse(any(frame.startswith(b'UNSUBSCRIBE\n') for frame in h.tls_sockets[0].sent))
            h.message(1, b'one')
            self.assertTrue(delivered.wait(1.0))
            self.assertEqual(observed, [(b'one', 'same')])
            instance.cancelSubscribe('topic', callback, 'same', **h.controls())
            self.assertEqual(h.tls_sockets[0].sent[-1], b'UNSUBSCRIBE\nid:1\n\n\0')
            instance.subscribe('topic', callback, 'new', **h.controls())
            self.assertIn(b'id:2\n', h.tls_sockets[0].sent[-1])

    def test_fresh_bound_method_cancellation_never_invokes_equality(self):
        class Receiver:
            def callback(self, body, identifier):
                pass

            def __eq__(self, other):
                raise AssertionError('callback receiver equality invoked')

        with PrimitiveHarness() as h:
            instance = h.open()
            receiver = Receiver()
            instance.subscribe('topic', receiver.callback, 'id', **h.controls())
            instance.cancelSubscribe('topic', receiver.callback, 'id', **h.controls())
            self.assertEqual(h.tls_sockets[0].sent[-1], b'UNSUBSCRIBE\nid:1\n\n\0')

    def test_registration_maximum_and_maximum_plus_one_share_one_wire(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            callback = lambda body, identifier: None
            for index in range(256):
                instance.subscribe('topic', callback, str(index), **h.controls())
            self.rejected(lambda: instance.subscribe('topic', callback, 'overflow', **h.controls()))
            self.assertEqual(sum(frame.startswith(b'SUBSCRIBE\n') for frame in h.tls_sockets[0].sent), 1)
            instance.cancelSubscribe('topic', callback, '0', **h.controls())
            instance.subscribe('topic', callback, 'replacement', **h.controls())

    def test_topic_maximum_and_maximum_plus_one(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            callback = lambda body, identifier: None
            for index in range(128):
                instance.subscribe('topic-' + str(index), callback, '', **h.controls())
            self.rejected(lambda: instance.subscribe('overflow', callback, '', **h.controls()))
            self.assertEqual(sum(frame.startswith(b'SUBSCRIBE\n') for frame in h.tls_sockets[0].sent), 128)
            instance.cancelSubscribe('topic-0', callback, '', **h.controls())
            instance.subscribe('replacement', callback, '', **h.controls())

    def test_two_instances_isolate_callbacks_topics_and_owned_release(self):
        with PrimitiveHarness() as h:
            first = h.open()
            second = h.open()
            observed = []
            arrived = threading.Event()
            def first_callback(body, identifier):
                observed.append(('first', body))
            def second_callback(body, identifier):
                observed.append(('second', body))
                arrived.set()
            first.subscribe('topic', first_callback, '', **h.controls())
            second.subscribe('topic', second_callback, '', **h.controls())
            first.close(h.deadline())
            self.assertTrue(h.raws[0].resource['closed'])
            self.assertFalse(h.raws[1].resource['closed'])
            h.message(1, b'second', socket_index=1)
            self.assertTrue(arrived.wait(1.0))
            self.assertEqual(observed, [('second', b'second')])

    def test_lifecycle_cancel_is_terminal_even_when_event_is_cleared(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            h.cancel.set()
            self.rejected(lambda: instance.publish('topic', b'body', **h.controls()), 'cancelled')
            h.cancel.clear()
            self.assertFalse(instance.strict_instance_compatible(settings()))
            self.rejected(lambda: instance.publish('topic', b'body', **h.controls()))
            self.assertEqual(len(h.allocations), 1)

    def test_self_cancel_has_no_self_wait_or_extra_dispatch(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            observed = []
            finished = threading.Event()
            def callback(body, identifier):
                try:
                    observed.append(body)
                    instance.cancelSubscribe('topic', callback, identifier, **h.controls())
                finally:
                    finished.set()
            instance.subscribe('topic', callback, 'self', **h.controls())
            h.message(1, b'first')
            self.assertTrue(finished.wait(1.0))
            instance.close(h.deadline())
            self.assertEqual(observed, [b'first'])
            self.assertTrue(any(frame == b'UNSUBSCRIBE\nid:1\n\n\0' for frame in h.tls_sockets[0].sent))


class OwnerRaceTests(StrictTestCase):
    def test_early_frames_wait_for_owner_commit_and_preserve_fifo(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            lower_committed = threading.Event()
            dispatch_waiting = threading.Event()
            release = threading.Event()
            delivered = threading.Event()
            observed = []
            subscribing = []

            def callback(body, identifier):
                observed.append((body, identifier))
                if len(observed) == 2:
                    delivered.set()

            def owner_clock():
                topic = instance._topics.get('topic')
                wire = instance._lower.transport._bounded_topics.get(1)
                if (topic is not None and topic.state == 'pending'
                        and wire is not None and wire.ticket.committed):
                    if threading.get_ident() in subscribing:
                        lower_committed.set()
                        if not release.wait(2.0):
                            raise AssertionError('fixture owner-commit barrier expired')
                    else:
                        dispatch_waiting.set()
                return h.real_clock()

            def subscribe():
                subscribing.append(threading.get_ident())
                instance.subscribe('topic', callback, 'id', deadline=h.deadline(5), cancel=h.cancel)

            callers = ControlledCallers(h, release)
            with mock.patch.object(messenger, 'monotonic', owner_clock):
                try:
                    callers.start(subscribe)
                    self.assertTrue(lower_committed.wait(1.0))
                    h.message(1, b'first')
                    h.message(1, b'second')
                    self.assertTrue(dispatch_waiting.wait(1.0))
                    self.assertEqual(observed, [])
                    release.set()
                    self.assertTrue(delivered.wait(1.0))
                finally:
                    callers.finish()
            self.assertEqual(callers.results, [('success', ())])
            self.assertEqual(observed, [(b'first', 'id'), (b'second', 'id')])

    def test_owner_commit_expiry_keeps_nondispatchable_counted_debt_and_survivor(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            observed = []
            delivered = threading.Event()

            def survivor(body, identifier):
                observed.append(('survivor', body))
                delivered.set()

            def rolled_back(body, identifier):
                observed.append(('rolled-back', body))

            instance.subscribe('survivor', survivor, '', **h.controls())
            subscriber = threading.get_ident()
            deadline = h.deadline()

            def owner_clock():
                wire = instance._lower.transport._bounded_topics.get(2)
                if threading.get_ident() == subscriber and wire is not None and wire.ticket.committed:
                    return deadline
                return h.real_clock()

            with mock.patch.object(messenger, 'monotonic', owner_clock):
                error = self.rejected(lambda: instance.subscribe(
                    'rollback', rolled_back, '', deadline=deadline, cancel=h.cancel), 'deadline')
            self.assertIn('registration-debt', error.cleanup)
            self.assertEqual(len(instance._topics), 2)
            self.assertEqual(instance._topics['rollback'].state, 'debt')
            self.assertEqual(len(instance._registrations), 2)
            self.rejected(lambda: instance.subscribe('rollback', rolled_back, '', **h.controls()),
                          'registration-debt')
            h.message(2, b'discard', destination='rollback')
            h.message(1, b'keep', destination='survivor')
            self.assertTrue(delivered.wait(1.0))
            self.assertEqual(observed, [('survivor', b'keep')])
            self.assertFalse(any(frame.startswith(b'UNSUBSCRIBE\n') for frame in h.tls_sockets[0].sent))

    def test_cancel_during_first_subscribe_prevents_resurrection(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            sending = threading.Event()
            release = threading.Event()
            observed = []
            callback = lambda body, identifier: observed.append(body)

            def hold_send(data):
                if data.startswith(b'SUBSCRIBE\n'):
                    sending.set()
                    if not release.wait(2.0):
                        raise AssertionError('fixture subscribe-send barrier expired')

            h.hooks['send'] = hold_send
            callers = ControlledCallers(h, release)
            try:
                callers.start(lambda: instance.subscribe('topic', callback, 'id',
                                                        deadline=h.deadline(5), cancel=h.cancel))
                self.assertTrue(sending.wait(1.0))
                h.message(1, b'pending')
                callers.start(lambda: instance.cancelSubscribe('topic', callback, 'id',
                                                              deadline=h.deadline(5), cancel=h.cancel))
                self.wait_until(h, lambda: instance._topics['topic'].state == 'debt')
                release.set()
            finally:
                callers.finish()
            self.assertEqual(sorted(result[0] for result in callers.results), ['registration-debt', 'success'])
            self.assertEqual(instance._registrations, [])
            self.assertEqual(instance._topics, {})
            self.assertEqual(observed, [])
            self.assertEqual(sum(frame.startswith(b'UNSUBSCRIBE\n') for frame in h.tls_sockets[0].sent), 1)
            instance.close(h.deadline())
            self.assertEqual(observed, [])

    def test_close_during_dispatch_retains_callback_debt_and_gates_snapshot(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            entered = threading.Event()
            release = threading.Event()
            finished = threading.Event()
            observed = []

            def first(body, identifier):
                try:
                    observed.append('first')
                    entered.set()
                    if not release.wait(2.0):
                        raise AssertionError('fixture callback barrier expired')
                finally:
                    finished.set()

            def second(body, identifier):
                observed.append('second')

            instance.subscribe('topic', first, '', **h.controls())
            instance.subscribe('topic', second, '', **h.controls())
            try:
                h.message(1, b'message')
                self.assertTrue(entered.wait(1.0))
                error = self.rejected(lambda: instance.close(h.deadline(.02)))
                self.assertIn('active-callback', error.cleanup)
                self.assertFalse(instance.strict_instance_compatible(settings()))
                self.assertTrue(h.raws[0].resource['closed'])
            finally:
                release.set()
                self.assertTrue(finished.wait(1.0))
            instance.close(h.deadline())
            self.assertEqual(observed, ['first'])

    def test_64_owner_tickets_admit_and_65th_rejects_before_wire(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            entered = threading.Event()
            release = threading.Event()

            def hold_send(data):
                if data.startswith(b'SEND\n') and not release.is_set():
                    entered.set()
                    if not release.wait(4.0):
                        raise AssertionError('fixture publish barrier expired')

            h.hooks['send'] = hold_send
            callers = ControlledCallers(h, release)
            try:
                for index in range(64):
                    callers.start(lambda: instance.publish('topic', b'body',
                                                          deadline=h.deadline(5), cancel=h.cancel))
                self.assertTrue(entered.wait(1.0))
                self.wait_until(h, lambda: len(instance._tickets) == 64)
                self.assertTrue(all(not ticket.done for ticket in instance._tickets))
                before = list(h.tls_sockets[0].sent)
                self.rejected(lambda: instance.publish('overflow', b'body', **h.controls()),
                              'operation-limit')
                self.assertEqual(h.tls_sockets[0].sent, before)
                self.assertEqual(len(instance._tickets), 64)
            finally:
                callers.finish()
            self.assertEqual(len(callers.results), 64)
            self.assertTrue(all(result == ('success', ()) for result in callers.results))
            instance.publish('after-reconciliation', b'body', **h.controls())
            self.assertEqual(len(instance._tickets), 1)

    def test_last_wire_identifier_is_admitted_once_then_exhausted(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            callback = lambda body, identifier: None
            instance._last_id = 2 ** 63 - 2
            instance.subscribe('last', callback, '', **h.controls())
            self.assertIn(b'id:9223372036854775807\n', h.tls_sockets[0].sent[-1])
            instance.cancelSubscribe('last', callback, '', **h.controls())
            before = list(h.tls_sockets[0].sent)
            self.rejected(lambda: instance.subscribe('overflow', callback, '', **h.controls()), 'wire-id')
            self.assertEqual(h.tls_sockets[0].sent, before)
            self.assertEqual(instance._last_id, 2 ** 63 - 1)
            self.assertEqual(instance._topics, {})


class CloseAndAdmissionTests(StrictTestCase):
    def test_close_is_passive_terminal_and_repeatable(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            instance.close(h.deadline())
            instance.close(h.deadline())
            self.assertTrue(h.raws[0].resource['closed'])
            self.assertEqual(h.tls_sockets[0].close_calls, 1)
            self.assertFalse(any(frame.startswith(b'DISCONNECT') for frame in h.tls_sockets[0].sent))
            self.assertFalse(instance.strict_instance_compatible(settings()))
            self.rejected(lambda: instance.publish('topic', b'body', **h.controls()))

    def test_expired_close_still_releases_but_does_not_return_success(self):
        with PrimitiveHarness(real_time=False) as h:
            instance = h.open()
            self.rejected(lambda: instance.close(h.now()), 'deadline')
            self.assertTrue(h.raws[0].resource['closed'])
            instance.close(h.deadline())
            self.assertEqual(h.tls_sockets[0].close_calls, 1)

    def test_failed_close_retains_debt_and_controlled_fixture_recovers(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            h.tls_sockets[0].close_error = OSError(CANARY)
            error = self.rejected(lambda: instance.close(h.deadline()))
            self.assertIn('socket-release', error.cleanup)
            self.assertFalse(h.raws[0].resource['closed'])
            h.tls_sockets[0].close_error = None
            instance.close(h.deadline())
            self.assertTrue(h.raws[0].resource['closed'])

    def test_self_close_reports_real_non_quiescence_then_external_close_completes(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            errors = []
            finished = threading.Event()
            def callback(body, identifier):
                try:
                    instance.close(h.deadline())
                except messenger.MessengerError as error:
                    errors.append(error)
                finally:
                    finished.set()
            instance.subscribe('topic', callback, '', **h.controls())
            h.message(1, b'close')
            self.assertTrue(finished.wait(1.0))
            self.assertEqual(len(errors), 1)
            self.assertEqual(errors[0].primary, 'non-quiescent')
            self.assertIn('active-callback', errors[0].cleanup)
            instance.close(h.deadline())
            self.assertTrue(h.raws[0].resource['closed'])

    def test_borrowed_settings_and_cancel_state_check_has_no_effects(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            before = (len(h.contexts), len(h.allocations), list(h.tls_sockets[0].sent))
            self.assertTrue(instance.strict_instance_compatible(MappingProxyType(settings())))
            self.assertFalse(instance.strict_instance_compatible(settings(amq_password='other')))
            self.assertFalse(instance.strict_instance_compatible(None))
            h.cancel.set()
            self.assertFalse(instance.strict_instance_compatible(settings()))
            self.assertEqual(before, (len(h.contexts), len(h.allocations), list(h.tls_sockets[0].sent)))

    def test_strict_diagnostics_and_errors_never_use_global_logging(self):
        with PrimitiveHarness() as h:
            with ExitStack() as canaries:
                for name in ('debug', 'info', 'warning', 'error', 'exception', 'getLogger'):
                    canaries.enter_context(mock.patch.object(messenger.logging, name,
                        side_effect=AssertionError('strict owner logging forbidden')))
                for name in ('debug', 'info', 'warning', 'error', 'exception', 'isEnabledFor'):
                    if hasattr(transport.logging, name):
                        canaries.enter_context(mock.patch.object(transport.logging, name,
                            side_effect=AssertionError('strict lower logging forbidden')))
                instance = h.open(settings(amq_password=CANARY))
                instance.publish('topic', CANARY.encode('ascii'), **h.controls())
                self.rejected(lambda: instance.publish('topic', object(), **h.controls()))
                snapshot = instance.diagnostics()
                self.assertNotIn(CANARY, repr(snapshot))
                instance.close(h.deadline())


class AdditionalBoundaryTests(StrictTestCase):
    def test_callback_failure_and_eof_terminal_gate_without_reconnect(self):
        for callback_failure in (False, True):
            with self.subTest(callback_failure=callback_failure), PrimitiveHarness() as h:
                instance = h.open()
                entered = threading.Event()
                def callback(body, identifier):
                    entered.set()
                    raise RuntimeError(CANARY)
                instance.subscribe('topic', callback, '', **h.controls())
                if callback_failure:
                    h.message(1, b'body')
                    self.assertTrue(entered.wait(1))
                else:
                    h.tls_sockets[0].recv_script.append(b'')
                self.wait_until(h, lambda: not instance.strict_instance_compatible(settings()))
                self.rejected(lambda: instance.publish('topic', b'body', **h.controls()), 'disconnected')
                instance.close(h.deadline())
                self.assertEqual(len(h.allocations), 1)
                self.assertNotIn(CANARY, repr(instance.diagnostics()))
                if callback_failure:
                    self.assertEqual(instance.diagnostics()['primary'], 'callback')

    def test_caller_retained_callable_never_finalizes_or_compares_under_lock(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            finalizers = []
            class Callback:
                def __call__(self, body, identifier):
                    pass
                def __eq__(self, other):
                    raise AssertionError('arbitrary callback equality')
                def __del__(self):
                    finalizers.append(instance._state_lock.locked())
            callback = Callback()
            instance.subscribe('topic', callback, 'id', **h.controls())
            instance.cancelSubscribe('topic', callback, 'id', **h.controls())
            self.assertEqual(finalizers, [])
            del callback
            self.assertEqual(finalizers, [False])

    def test_preparation_maxima_and_opaque_assignment(self):
        identity = '.'.join(('x' * 63, 'x' * 63, 'x' * 63, 'x' * 61))
        self.assertEqual(len(identity), 253)
        with PrimitiveHarness() as h:
            for changes in ({'amq_tls_server_name': identity, 'amq_stomp_host': 'h' * 255},
                            {'amq_username': '\U0001f600' * 1024},
                            {'amq_password': '\U0001f600' * 1024}):
                prepared = messenger.prepare_transport(settings(**changes), h.cancel)
                with self.assertRaises(AttributeError):
                    prepared._context = object()
                with self.assertRaises(AttributeError):
                    prepared._values = ()
            for changes in ({'amq_tls_server_name': identity + 'x'},
                            {'amq_stomp_host': 'h' * 256},
                            {'amq_username': 'u' * 1025},
                            {'amq_password': 'p' * 1025},
                            {'amq_username': '\U0001f600' * 1024,
                             'amq_password': '\U0001f600' * 1024}):
                self.rejected(lambda: messenger.prepare_transport(settings(**changes), h.cancel))
            self.assertEqual(h.allocations, [])

    def test_operation_before_equal_after_and_observed_recomputation_expiry(self):
        for value in (11.999, 12.0, 12.001):
            with self.subTest(value=value), PrimitiveHarness(real_time=False) as h:
                instance = h.open()
                h.clock.value = value
                before = list(h.tls_sockets[0].sent)
                action = lambda: instance.publish('topic', b'body', deadline=12.0, cancel=h.cancel)
                if value < 12:
                    action()
                    self.assertEqual(len(h.tls_sockets[0].sent), len(before) + 1)
                else:
                    self.rejected(action, 'deadline')
                    self.assertEqual(h.tls_sockets[0].sent, before)
        with PrimitiveHarness(real_time=False) as h:
            instance = h.open()
            before = list(h.tls_sockets[0].sent)
            def clock():
                if sys._getframe(1).f_code is messenger.Messenger._remaining.__code__:
                    return 12.0
                return 10.0
            with mock.patch.object(messenger, 'monotonic', clock):
                self.rejected(lambda: instance.publish('topic', b'body', deadline=12.0,
                                                      cancel=h.cancel), 'deadline')
            self.assertEqual(h.tls_sockets[0].sent, before)
            self.assertEqual(instance._tickets, [])

    def test_borrowed_contention_and_owner_lock_deadline_have_no_wire_effects(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            before = list(h.tls_sockets[0].sent)
            instance._state_lock.acquire()
            try:
                self.assertFalse(instance.strict_instance_compatible(settings()))
                self.rejected(lambda: instance.publish('topic', b'body',
                    deadline=h.deadline(.01), cancel=h.cancel), 'deadline')
            finally:
                instance._state_lock.release()
            self.assertEqual(h.tls_sockets[0].sent, before)
            self.assertTrue(instance.strict_instance_compatible(settings()))

    def test_recording_failures_and_saturation_preserve_fixed_primary(self):
        class Ledger:
            def __init__(self, failure):
                self.failure = failure
            def acquire(self, blocking):
                if blocking is not False:
                    raise AssertionError('diagnostics blocked')
                if self.failure == 'acquire':
                    raise RuntimeError(CANARY)
                return self.failure != 'contended'
            def release(self):
                if self.failure == 'release':
                    raise RuntimeError(CANARY)
        for failure in ('acquire', 'release', 'contended'):
            with self.subTest(failure=failure), PrimitiveHarness() as h:
                instance = h.open()
                instance._ledger_lock = Ledger(failure)
                self.rejected(lambda: instance.publish('topic', object(), **h.controls()), 'admission')
                snapshot = instance.diagnostics()
                self.assertEqual(snapshot['primary'], 'admission')
                self.assertTrue(snapshot['recording_failed'])
                self.assertEqual(len(snapshot['counters']), 32)
                self.assertNotIn(CANARY, repr(snapshot))
                instance.close(h.deadline())
                self.assertTrue(h.raws[0].resource['closed'])
                self.assertEqual(instance.diagnostics()['primary'], 'admission')
        with PrimitiveHarness() as h:
            instance = h.open()
            instance._counters[:] = [2 ** 31 - 1] * 32
            self.rejected(lambda: instance.publish('topic', object(), **h.controls()))
            self.assertEqual([count for code, count in instance.diagnostics()['counters']],
                             [2 ** 31 - 1] * 32)

    def test_close_observes_real_startup_and_caller_debt(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            entered, release = threading.Event(), threading.Event()
            start = threading.Thread.start
            def held_start(worker):
                if worker.name == 'stomp-bounded-receiver':
                    entered.set()
                    if not release.wait(2):
                        raise AssertionError('fixture startup barrier expired')
                return start(worker)
            callers = ControlledCallers(h, release)
            with mock.patch.object(threading.Thread, 'start', held_start):
                try:
                    callers.start(lambda: instance.subscribe('topic', lambda body, ident: None,
                        '', deadline=h.deadline(5), cancel=h.cancel))
                    self.assertTrue(entered.wait(1))
                    error = self.rejected(lambda: instance.close(h.deadline(.02)), 'deadline')
                    self.assertIn('worker-start-pending', error.cleanup)
                    self.assertIn('active-operation', error.cleanup)
                    self.assertTrue(h.raws[0].resource['closed'])
                finally:
                    callers.finish()
            self.assertEqual(callers.results[0][0], 'disconnected')
            instance.close(h.deadline())
            self.assertEqual(instance._registrations, [])

    def test_concurrent_close_waits_for_real_caller_completion(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            entered, release = threading.Event(), threading.Event()
            def held_send(data):
                if data.startswith(b'SEND\n'):
                    entered.set()
                    if not release.wait(2):
                        raise AssertionError('fixture send barrier expired')
            h.hooks['send'] = held_send
            callers = ControlledCallers(h, release)
            try:
                callers.start(lambda: instance.publish('topic', b'body',
                    deadline=h.deadline(5), cancel=h.cancel))
                self.assertTrue(entered.wait(1))
                error = self.rejected(lambda: instance.close(h.deadline(.02)), 'deadline')
                self.assertIn('active-operation', error.cleanup)
                self.assertTrue(any(not ticket.done for ticket in instance._tickets))
                callers.start(lambda: instance.close(h.deadline(5)))
            finally:
                callers.finish()
            self.assertEqual(sorted(result[0] for result in callers.results), ['disconnected', 'success'])
            self.assertTrue(h.raws[0].resource['closed'])
            self.assertTrue(instance._closed)

    def test_failed_owner_removal_commit_keeps_debt_for_explicit_retry(self):
        with PrimitiveHarness() as h:
            instance = h.open()
            callback = lambda body, ident: None
            instance.subscribe('topic', callback, 'id', **h.controls())
            deadline = h.deadline()
            remover = threading.get_ident()
            def clock():
                if (threading.get_ident() == remover and
                        1 not in instance._lower.transport._bounded_topics):
                    return deadline
                return h.real_clock()
            with mock.patch.object(messenger, 'monotonic', clock):
                error = self.rejected(lambda: instance.cancelSubscribe('topic', callback, 'id',
                    deadline=deadline, cancel=h.cancel), 'deadline')
            self.assertIn('registration-debt', error.cleanup)
            self.assertEqual(len(instance._registrations), 1)
            self.assertEqual(instance._topics['topic'].state, 'debt')
            instance.cancelSubscribe('topic', callback, 'id', **h.controls())
            self.assertEqual(instance._registrations, [])
            self.assertEqual(instance._topics, {})
            self.assertEqual(sum(data.startswith(b'UNSUBSCRIBE\n') for data in h.tls_sockets[0].sent), 1)


class OwnerPendingAggregateTests(StrictTestCase):
    def _pending_aggregate_case(self, accepted, overflow=None):
        with PrimitiveHarness() as h:
            instance = h.open()
            lower = instance._lower.transport
            entered, release, delivered = threading.Event(), threading.Event(), threading.Event()
            subscribing = set()
            observed = []
            expected = [(len(body), body[:1], 'pending') for frame, body in accepted]
            expected_bytes = sum(len(frame) for frame, body in accepted)
            check_code = transport.BaseTransport._check_bounded.__code__
            transmit_code = transport.Transport.transmit_bounded.__code__

            def callback(body, identifier):
                observed.append((len(body), body[:1], identifier))
                if len(observed) == len(expected):
                    delivered.set()

            def lower_clock():
                current = sys._getframe(1)
                caller = current.f_back
                targeted = (threading.get_ident() in subscribing
                            and current.f_code is check_code
                            and caller is not None and caller.f_code is transmit_code
                            and caller.f_locals.get('_subscription') == 1)
                del caller, current
                if targeted:
                    entered.set()
                    if not release.wait(3.0):
                        raise AssertionError('fixture lower-commit barrier expired')
                return h.real_clock()

            def subscribe():
                subscribing.add(threading.get_ident())
                instance.subscribe('topic', callback, 'pending',
                                   deadline=h.deadline(5.0), cancel=h.cancel)

            callers = ControlledCallers(h, release)
            with mock.patch.object(transport, 'monotonic', lower_clock):
                try:
                    callers.start(subscribe)
                    self.assertTrue(entered.wait(1.0))
                    for frame, body in accepted:
                        h.tls_sockets[0].recv_script.append(frame)
                    self.wait_until(h, lambda: len(lower._bounded_pending) == len(accepted)
                                    and lower._bounded_pending_bytes == expected_bytes)
                    self.assertEqual(observed, [])
                    self.assertFalse(lower._bounded_topics[1].ticket.committed)
                    self.assertFalse(instance._topics['topic'].ticket.committed)
                    self.assertTrue(instance.strict_instance_compatible(settings()))
                    if overflow is not None:
                        h.tls_sockets[0].recv_script.append(overflow)
                        self.wait_until(h, lambda: lower.diagnostics_bounded()['primary'] == 'pending-limit')
                        self.assertEqual(len(lower._bounded_pending), len(accepted))
                        self.assertEqual(lower._bounded_pending_bytes, expected_bytes)
                        self.assertEqual(observed, [])
                        self.assertFalse(instance.strict_instance_compatible(settings()))
                        self.assertTrue(h.raws[0].resource['closed'])
                    release.set()
                    if overflow is None:
                        self.assertTrue(delivered.wait(1.0))
                finally:
                    callers.finish()
            if overflow is None:
                self.assertEqual(callers.results, [('success', ())])
                self.assertEqual(observed, expected)
                self.assertEqual(lower._bounded_pending, [])
                self.assertEqual(lower._bounded_pending_bytes, 0)
            else:
                self.assertEqual(len(callers.results), 1)
                self.assertEqual(callers.results[0][0], 'disconnected')
                self.assertEqual(observed, [])
                self.assertFalse(instance.strict_instance_compatible(settings()))
            instance.close(h.deadline())
            self.assertEqual(h.tls_sockets[0].close_calls, 1)
            self.assertEqual(len(h.allocations), 1)

    def test_pending_eight_frames_commit_fifo_and_ninth_overflows(self):
        header = b'MESSAGE\nsubscription:1\ndestination:topic\ncontent-length:1\n\n'
        accepted = []
        for index in range(8):
            body = str(index).encode('ascii')
            accepted.append((header + body + b'\0', body))
        for overflow in (False, True):
            with self.subTest(overflow=overflow):
                self._pending_aggregate_case(accepted, header + b'8\0' if overflow else None)

    def test_pending_aggregate_exact_byte_maximum_and_maximum_plus_one(self):
        header = b'MESSAGE\nsubscription:1\ndestination:topic\ncontent-length:262079\n\n'
        self.assertEqual(len(header), 64)
        accepted = []
        for marker in (b'a', b'b', b'c', b'd'):
            body = marker * 262079
            frame = header + body + b'\0'
            self.assertEqual(len(frame), 262144)
            accepted.append((frame, body))
        self.assertEqual(sum(len(frame) for frame, body in accepted), 1048576)
        overflow = (b'MESSAGE\nsubscription:1\ndestination:topic\ncontent-length:262080\n\n'
                    + b'e' * 262080 + b'\0')
        self.assertEqual(sum(len(frame) for frame, body in accepted[:3]) + len(overflow), 1048577)
        for over_limit in (False, True):
            with self.subTest(over_limit=over_limit):
                self._pending_aggregate_case(accepted[:3] if over_limit else accepted,
                                             overflow if over_limit else None)


class LegacyFixtureStop(BaseException):
    pass


class LegacyConnection:
    def __init__(self, events, fail_connect=False):
        self.events = events
        self.fail_connect = fail_connect

    def set_ssl(self, **kwargs):
        self.events.append(('ssl', kwargs))

    def connect(self, *args, **kwargs):
        self.events.append(('connect', args, kwargs))
        if self.fail_connect:
            raise OSError('controlled legacy retry')

    def set_listener(self, name, listener):
        self.events.append(('listener', name))
        self.listener = listener

    def send(self, **kwargs):
        self.events.append(('send', kwargs))

    def subscribe(self, *args, **kwargs):
        self.events.append(('subscribe', args, kwargs))

    def unsubscribe(self, **kwargs):
        self.events.append(('unsubscribe', kwargs))


class LegacyTests(unittest.TestCase):
    def setUp(self):
        self.events = []
        self.connections = []
        self.sleep_calls = []
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(mock.patch.object(messenger.logging, 'getLogger'))
        self.stack.enter_context(mock.patch.object(messenger, 'Connection', self.connection))
        self.stack.enter_context(mock.patch.object(messenger.time, 'sleep', self.sleep))
        self.stack.enter_context(mock.patch.object(messenger.Messenger, 'global_stomp_connection', None))
        self.stack.enter_context(mock.patch.object(messenger.Messenger, 'global_stomp_listener', None))
        self.stack.enter_context(mock.patch.object(messenger.Messenger, 'pre_connection_subscriptions', []))

    def sleep(self, seconds):
        if len(self.sleep_calls) >= 3:
            raise LegacyFixtureStop()
        self.sleep_calls.append(seconds)

    def connection(self, *args, **kwargs):
        if len(self.connections) >= 4:
            raise LegacyFixtureStop()
        self.events.append(('constructor', args, kwargs))
        connection = LegacyConnection(self.events)
        self.connections.append(connection)
        return connection

    def open(self, **kwargs):
        return messenger.Messenger('legacy.example', 61613,
                                   {'username': 'legacy-user', 'password': 'legacy-pass'}, **kwargs)

    def test_constructor_tls_login_and_borrowed_legacy_rejection(self):
        instance = self.open(reconnect_attempts_max=4)
        self.assertEqual(self.events[0], ('constructor', ([('legacy.example', 61613)],),
                         {'auto_decode': False, 'reconnect_attempts_max': 4}))
        self.assertEqual(self.events[1], ('ssl', {'for_hosts': [('legacy.example', 61613)],
                                               'ssl_version': ssl.PROTOCOL_TLS}))
        self.assertEqual(self.events[2], ('connect', ('legacy-user', 'legacy-pass'), {'wait': True}))
        self.assertFalse(instance.strict_instance_compatible(settings()))

    def test_plaintext_anonymous_legacy_call_is_unchanged(self):
        self.open(use_ssl=False, amq_login=False)
        self.assertFalse(any(event[0] == 'ssl' for event in self.events))
        self.assertIn(('connect', (), {'wait': True}), self.events)

    def test_protobuf_serializer_raw_body_and_priority_are_unchanged(self):
        class Payload:
            def SerializeToString(self):
                return b'serialized'

        instance = self.open()
        instance.publish('legacy-topic', Payload(), 9)
        self.assertEqual(self.events[-1], ('send', {'body': b'serialized', 'destination': 'legacy-topic',
                                                  'headers': {'priority': '9'}}))
        instance.publish('legacy-topic', 'raw text')
        self.assertEqual(self.events[-1], ('send', {'body': 'raw text', 'destination': 'legacy-topic'}))

    def test_duplicate_callback_order_removal_and_missing_tuple_behavior(self):
        instance = self.open()
        observed = []
        callback = lambda body, identifier: observed.append((body, identifier))
        instance.subscribe('topic', callback, 'one')
        instance.subscribe('topic', callback, 'two')
        self.connections[0].listener.on_message_further({'destination': 'topic'}, b'body')
        self.assertEqual(observed, [(b'body', 'one'), (b'body', 'two')])
        instance.cancelSubscribe('topic', callback, 'one')
        self.assertFalse(any(event[0] == 'unsubscribe' for event in self.events))
        instance.cancelSubscribe('topic', callback, 'two')
        self.assertEqual(self.events[-1], ('unsubscribe', {'destination': 'topic', 'id': 1}))
        with self.assertRaises(ValueError):
            instance.cancelSubscribe('topic', callback, 'missing')

    def test_disconnect_reconnect_replays_same_topic_id(self):
        instance = self.open()
        callback = lambda body, identifier: None
        instance.subscribe('topic', callback, 'id')
        self.connections[0].listener.on_disconnected()
        self.assertEqual(self.events[-2:], [('connect', ('legacy-user', 'legacy-pass'), {'wait': True}),
                                            ('subscribe', ('topic', 1), {})])

    def test_legacy_retry_uses_existing_three_second_sleep(self):
        def connect(*args, **kwargs):
            if len(self.connections) >= 4:
                raise LegacyFixtureStop()
            self.events.append(('constructor', args, kwargs))
            connection = LegacyConnection(self.events, fail_connect=not self.connections)
            self.connections.append(connection)
            return connection
        with mock.patch.object(messenger, 'Connection', connect), mock.patch.object(
                messenger.time, 'sleep', side_effect=self.sleep) as sleep:
            instance = self.open()
        self.assertTrue(instance.connected)
        sleep.assert_called_once_with(3)
        self.assertEqual(len(self.connections), 2)


class PendingBridgeFixture:
    """Real owner/lower bridge with finite primitive-clock barriers."""

    def __init__(self, case, harness, cancel=None):
        self.case = case
        self.harness = harness
        self.cancel = harness.cancel if cancel is None else cancel
        self.owner = harness.open()
        self.lower = self.owner._lower.transport
        self.delivered = []
        self.callback = lambda body, identifier: self.delivered.append((body, identifier))
        self.owner.subscribe('survivor', self.callback, 'survivor', **harness.controls())
        self.deadline = harness.deadline(8)
        self.producer_now = self.deadline - 1
        self.receiver_now = self.deadline - 1
        self.subscribing = set()
        self.lower_entered = threading.Event()
        self.lower_release = threading.Event()
        self.producer_entered = threading.Event()
        self.producer_release = threading.Event()
        self.receiver_entered = threading.Event()
        self.receiver_release = threading.Event()
        self.receiver_hook = None
        self.receiver_ticks = 0
        self.held = False
        self.active = True
        self.callers = ControlledCallers(harness, self.lower_release,
                                         self.producer_release, self.receiver_release)
        self.stack = ExitStack()

    def __enter__(self):
        try:
            self.stack.enter_context(mock.patch.object(transport, 'monotonic', self.lower_clock))
            self.stack.enter_context(mock.patch.object(messenger, 'monotonic', self.owner_clock))
        except BaseException:
            self.stack.close()
            raise
        return self

    def lower_clock(self):
        current = sys._getframe(1)
        parent = current.f_back
        try:
            targeted = (self.active and threading.get_ident() in self.subscribing
                        and current.f_code is transport.BaseTransport._check_bounded.__code__
                        and parent is not None
                        and parent.f_code is transport.Transport.transmit_bounded.__code__
                        and parent.f_locals.get('_subscription') == 2)
        finally:
            del parent, current
        if targeted:
            self.lower_entered.set()
            if not self.lower_release.wait(4):
                raise AssertionError('bridge lower release missing')
        return self.harness.real_clock()

    def owner_clock(self):
        if not self.active:
            return self.harness.real_clock()
        if threading.get_ident() in self.subscribing:
            wire = self.lower._bounded_topics.get(2)
            if wire is not None and wire.ticket.committed:
                self.producer_entered.set()
                if not self.producer_release.wait(4):
                    raise AssertionError('bridge producer release missing')
            return self.producer_now
        receiver = self.lower._bounded_receiver
        if receiver is not None and threading.get_ident() == receiver.ident:
            self.receiver_ticks += 1
            if self.receiver_hook is not None:
                self.receiver_hook()
            return self.receiver_now
        return self.harness.real_clock()

    def pause_receiver(self):
        self.receiver_entered.set()
        if not self.receiver_release.wait(4):
            raise AssertionError('bridge receiver release missing')

    def hold(self):
        self.case.assertFalse(self.held)
        self.held = self.owner._state_lock.acquire(False)
        self.case.assertTrue(self.held)

    def unlock(self):
        if self.held:
            self.owner._state_lock.release()
            self.held = False

    def start(self, bodies=(b'pending',)):
        def subscribe():
            self.subscribing.add(threading.get_ident())
            self.owner.subscribe('pending', self.callback, 'pending',
                                 deadline=self.deadline, cancel=self.cancel)

        self.callers.start(subscribe)
        self.case.assertTrue(self.lower_entered.wait(1))
        for body in bodies:
            self.harness.message(2, body, destination='pending')
        self.case.wait_until(self.harness,
                             lambda: len(self.lower._bounded_pending) == len(bodies))
        self.topic = self.owner._topics['pending']
        self.registration = next(item for item in self.owner._registrations
                                 if item.topic is self.topic)
        self.case.assertFalse(self.topic.ticket.committed)
        self.hold()
        self.lower_release.set()
        self.case.assertTrue(self.producer_entered.wait(1))
        self.case.wait_until(self.harness, lambda: self.lower._bounded_callback is not None
                             and not self.lower._bounded_callback.done
                             and len(self.lower._bounded_pending) == len(bodies) - 1)
        self.callback_ticket = self.lower._bounded_callback
        self.case.assertEqual(self.delivered, [])

    def assert_unpoisoned(self):
        self.case.assertTrue(self.owner._lower.is_connected())
        self.case.assertEqual(self.lower.diagnostics_bounded()['primary'], 'none')
        self.case.assertFalse(self.harness.raws[0].resource['closed'])

    def assert_survivor(self):
        self.case.assertFalse(self.held)
        self.harness.message(1, b'survives', destination='survivor')
        self.case.wait_until(self.harness,
                             lambda: (b'survives', 'survivor') in self.delivered)
        self.assert_unpoisoned()

    def __exit__(self, kind, value, traceback):
        self.active = False
        self.receiver_hook = None
        self.lower_release.set()
        self.producer_release.set()
        self.receiver_release.set()
        self.unlock()
        failures = []
        try:
            self.callers.finish()
        except BaseException:
            failures.append('bridge-caller-reclamation')
        try:
            self.stack.close()
        except BaseException:
            failures.append('bridge-clock-restoration')
        try:
            self.owner.close(self.harness.deadline())
        except BaseException:
            failures.append('bridge-owner-close')
        if self.lower._bounded_receiver.is_alive():
            failures.append('bridge-receiver-live')
        if not self.harness.raws[0].resource['closed']:
            failures.append('bridge-socket-live')
        if any(worker.is_alive() for worker in self.callers.workers):
            failures.append('bridge-caller-live')
        if failures:
            raise AssertionError(tuple(failures))


class PendingBridgeCorrectionTests(StrictTestCase):
    def test_pending_original_deadline_before_equal_and_after_owner_contention(self):
        for offset in (0, .25):
            with self.subTest(offset=offset), PrimitiveHarness() as h:
                with PendingBridgeFixture(self, h) as bridge:
                    bridge.receiver_now = bridge.deadline - .001
                    bridge.start()
                    before_ticks = bridge.receiver_ticks
                    self.wait_until(h, lambda: bridge.receiver_ticks >= before_ticks + 2)
                    self.assertFalse(bridge.callback_ticket.done)
                    self.assertFalse(bridge.topic.ticket.done)
                    self.assertFalse(bridge.topic.ticket.committed)
                    self.assertIn(bridge.topic.ticket, bridge.owner._tickets)
                    self.assertTrue(bridge.held)
                    bridge.receiver_now = bridge.deadline + offset
                    self.wait_until(h, lambda: bridge.callback_ticket.done)
                    self.assertTrue(bridge.held)
                    self.assertFalse(bridge.topic.ticket.done)
                    self.assertIn(bridge.topic.ticket, bridge.owner._tickets)
                    self.assertEqual(bridge.delivered, [])
                    bridge.producer_now = bridge.deadline
                    bridge.producer_release.set()
                    self.wait_until(h, lambda: bridge.topic.ticket.done)
                    self.wait_until(h, lambda: len(bridge.callers.results) == 1)
                    self.assertFalse(bridge.topic.ticket.committed)
                    self.assertEqual(bridge.topic.state, 'debt')
                    self.assertEqual(bridge.registration.state, 'debt')
                    self.assertEqual(len(bridge.owner._topics), 2)
                    self.assertEqual(len(bridge.owner._registrations), 2)
                    self.assertEqual(bridge.callers.results[0][0], 'deadline')
                    self.assertIn('registration-debt', bridge.callers.results[0][1])
                    bridge.assert_unpoisoned()
                    bridge.unlock()
                    bridge.assert_survivor()
                    self.assertEqual(bridge.delivered, [(b'survives', 'survivor')])

    def test_completed_uncommitted_producer_releases_frame_before_receiver_expiry(self):
        with PrimitiveHarness() as h:
            with PendingBridgeFixture(self, h) as bridge:
                bridge.start()
                bridge.producer_now = bridge.deadline
                bridge.producer_release.set()
                self.wait_until(h, lambda: bridge.topic.ticket.done)
                self.wait_until(h, lambda: len(bridge.callers.results) == 1)
                self.assertLess(bridge.receiver_now, bridge.deadline)
                self.assertFalse(bridge.topic.ticket.committed)
                self.assertEqual(bridge.topic.state, 'debt')
                self.wait_until(h, lambda: bridge.callback_ticket.done)
                self.assertTrue(bridge.held)
                self.assertEqual(bridge.delivered, [])
                self.assertEqual(bridge.callers.results[0][0], 'deadline')
                self.assertIn('registration-debt', bridge.callers.results[0][1])
                bridge.assert_unpoisoned()
                bridge.unlock()
                bridge.owner.cancelSubscribe('pending', bridge.callback, 'pending', **h.controls())
                self.assertNotIn('pending', bridge.owner._topics)
                self.assertNotIn(bridge.registration, bridge.owner._registrations)
                bridge.owner.subscribe('pending', bridge.callback, 'replacement', **h.controls())
                self.assertEqual(bridge.owner._topics['pending'].wire_id, 3)
                self.assertFalse(bridge.topic.ticket.committed)
                h.message(2, b'stale', destination='pending')
                h.message(3, b'new', destination='pending')
                self.wait_until(h, lambda: (b'new', 'replacement') in bridge.delivered)
                bridge.assert_survivor()
                self.assertEqual(bridge.delivered,
                                 [(b'new', 'replacement'), (b'survives', 'survivor')])
                self.assertEqual(sum(frame.startswith(b'UNSUBSCRIBE\n')
                                     for frame in h.tls_sockets[0].sent), 1)

    def test_supported_removal_rolls_back_producer_before_original_deadline(self):
        with PrimitiveHarness() as h:
            with PendingBridgeFixture(self, h) as bridge:
                bridge.receiver_hook = bridge.pause_receiver
                bridge.start()
                self.assertTrue(bridge.receiver_entered.wait(1))
                bridge.unlock()
                bridge.callers.start(lambda: bridge.owner.cancelSubscribe(
                    'pending', bridge.callback, 'pending',
                    deadline=bridge.deadline, cancel=h.cancel))
                self.wait_until(h, lambda: bridge.topic.state == 'debt')
                bridge.producer_release.set()
                self.wait_until(h, lambda: len(bridge.callers.results) == 2)
                self.assertEqual(sorted(result[0] for result in bridge.callers.results),
                                 ['registration-debt', 'success'])
                self.assertTrue(bridge.topic.ticket.done)
                self.assertFalse(bridge.topic.ticket.committed)
                self.assertLess(bridge.producer_now, bridge.deadline)
                self.assertLess(bridge.receiver_now, bridge.deadline)
                self.assertNotIn('pending', bridge.owner._topics)
                bridge.hold()
                bridge.receiver_hook = None
                bridge.receiver_release.set()
                self.wait_until(h, lambda: bridge.callback_ticket.done)
                self.assertTrue(bridge.held)
                self.assertEqual(bridge.delivered, [])
                bridge.assert_unpoisoned()
                bridge.unlock()
                bridge.assert_survivor()

    def test_cancel_and_close_precede_pending_deadline_under_owner_contention(self):
        for terminal in ('cancel', 'close'):
            with self.subTest(terminal=terminal), PrimitiveHarness() as h:
                with PendingBridgeFixture(self, h) as bridge:
                    bridge.start()
                    if terminal == 'cancel':
                        h.cancel.set()
                        bridge.receiver_now = bridge.deadline
                    else:
                        self.rejected(lambda: bridge.owner.close(h.deadline(.03)), 'deadline')
                    bridge.producer_release.set()
                    self.wait_until(h, lambda: bridge.callback_ticket.done)
                    self.wait_until(h, lambda: bridge.topic.ticket.done)
                    self.wait_until(h, lambda: len(bridge.callers.results) == 1)
                    self.assertTrue(bridge.held)
                    self.assertFalse(bridge.topic.ticket.committed)
                    self.assertEqual(bridge.delivered, [])
                    self.assertEqual(bridge.callers.results[0][0],
                                     'cancelled' if terminal == 'cancel' else 'disconnected')
                    self.assertTrue(bridge.owner._gate)
                    self.assertTrue(h.raws[0].resource['closed'])
                    bridge.unlock()

    def test_successive_pending_checks_reobserve_original_budget_after_recontention(self):
        with PrimitiveHarness() as h:
            with PendingBridgeFixture(self, h) as bridge:
                acquired = threading.Event()
                next_check = threading.Event()
                next_release = threading.Event()
                bridge.callers.releases += (next_release,)
                bridge.receiver_hook = bridge.pause_receiver
                bridge.start()
                self.assertTrue(bridge.receiver_entered.wait(1))
                bridge.unlock()

                def observe_next_check():
                    if bridge.owner._state_lock.locked():
                        acquired.set()
                    elif acquired.is_set():
                        next_check.set()
                        if not next_release.wait(4):
                            raise AssertionError('bridge re-contention release missing')

                bridge.receiver_hook = observe_next_check
                bridge.receiver_release.set()
                self.assertTrue(next_check.wait(1))
                self.assertTrue(acquired.is_set())
                self.assertFalse(bridge.topic.ticket.done)
                self.assertFalse(bridge.topic.ticket.committed)
                self.assertFalse(bridge.callback_ticket.done)
                bridge.hold()
                bridge.receiver_now = bridge.deadline
                bridge.receiver_hook = None
                next_release.set()
                self.wait_until(h, lambda: bridge.callback_ticket.done)
                self.assertTrue(bridge.held)
                self.assertFalse(bridge.topic.ticket.done)
                self.assertIn(bridge.topic.ticket, bridge.owner._tickets)
                self.assertEqual(bridge.delivered, [])
                bridge.producer_now = bridge.deadline
                bridge.producer_release.set()
                self.wait_until(h, lambda: len(bridge.callers.results) == 1)
                self.assertEqual(bridge.callers.results[0][0], 'deadline')
                bridge.assert_unpoisoned()
                bridge.unlock()
                bridge.assert_survivor()

    def test_in_time_commit_survives_setup_expiry_and_retains_duplicate_tokens(self):
        with PrimitiveHarness() as h:
            with PendingBridgeFixture(self, h) as bridge:
                bridge.receiver_hook = bridge.pause_receiver
                bridge.start((b'first', b'second'))
                self.assertTrue(bridge.receiver_entered.wait(1))
                self.assertEqual(bridge.delivered, [])
                reads = []
                h.hooks['recv'] = lambda: reads.append(True)
                bridge.unlock()
                bridge.producer_release.set()
                self.wait_until(h, lambda: bridge.topic.ticket.done)
                self.wait_until(h, lambda: len(bridge.callers.results) == 1)
                self.assertTrue(bridge.topic.ticket.committed)
                self.assertEqual(bridge.topic.state, 'active')
                self.assertEqual(bridge.callers.results, [('success', ())])
                bridge.hold()
                bridge.receiver_now = bridge.deadline + 1
                bridge.receiver_hook = None
                bridge.receiver_release.set()
                h.real_sleep(.025)
                self.assertFalse(bridge.callback_ticket.done)
                self.assertEqual(bridge.delivered, [])
                bridge.unlock()
                self.wait_until(h, lambda: len(bridge.delivered) == 2)
                self.assertEqual(bridge.delivered, [(b'first', 'pending'), (b'second', 'pending')])
                self.assertEqual(reads, [])
                self.assertEqual(bridge.lower._bounded_pending, [])
                self.assertEqual(bridge.lower._bounded_pending_bytes, 0)
                bridge.owner.subscribe('pending', bridge.callback, 'pending', **h.controls())
                self.assertEqual(bridge.owner._topics['pending'].wire_id, 2)
                h.message(2, b'later', destination='pending')
                self.wait_until(h, lambda: len(bridge.delivered) == 4)
                self.assertEqual(bridge.delivered[-2:], [(b'later', 'pending'), (b'later', 'pending')])
                bridge.owner.cancelSubscribe('pending', bridge.callback, 'pending', **h.controls())
                self.assertFalse(any(frame.startswith(b'UNSUBSCRIBE\n') for frame in h.tls_sockets[0].sent))
                h.message(2, b'one-token', destination='pending')
                self.wait_until(h, lambda: len(bridge.delivered) == 5)
                self.assertEqual(bridge.delivered[-1], (b'one-token', 'pending'))
                bridge.assert_survivor()


class IndependentCancellationTests(StrictTestCase):
    def test_distinct_operation_events_preserve_committed_registration_lifetime(self):
        with PrimitiveHarness() as h:
            owner = h.open()
            operation = threading.Event()
            delivered = []
            callback = lambda body, identifier: delivered.append((body, identifier))
            owner.publish('topic', b'first', deadline=h.deadline(), cancel=operation)
            self.assertEqual(h.tls_sockets[0].sent[-1],
                             b'SEND\ndestination:topic\ncontent-length:5\n\nfirst\0')
            owner.subscribe('topic', callback, 'one', deadline=h.deadline(), cancel=operation)
            operation.set()
            h.message(1, b'after-cancel')
            self.wait_until(h, lambda: delivered == [(b'after-cancel', 'one')])
            other = threading.Event()
            owner.subscribe('topic', callback, 'two', deadline=h.deadline(), cancel=other)
            owner.cancelSubscribe('topic', callback, 'one', deadline=h.deadline(), cancel=other)
            h.message(1, b'sibling')
            self.wait_until(h, lambda: len(delivered) == 2)
            self.assertEqual(delivered[-1], (b'sibling', 'two'))
            owner.cancelSubscribe('topic', callback, 'two', deadline=h.deadline(), cancel=other)
            self.assertEqual(sum(frame.startswith(b'SUBSCRIBE\n') for frame in h.tls_sockets[0].sent), 1)
            self.assertEqual(sum(frame.startswith(b'UNSUBSCRIBE\n') for frame in h.tls_sockets[0].sent), 1)
            self.assertFalse(h.cancel.is_set())
            self.assertTrue(owner.strict_instance_compatible(settings()))
            owner.publish('topic', b'lifecycle', **h.controls())

    def test_invalid_operation_event_types_do_not_invoke_hooks(self):
        class Subclass(threading.Event):
            def is_set(self):
                raise AssertionError('invalid Event hook was invoked')

        class Duck:
            def is_set(self):
                raise AssertionError('duck Event hook was invoked')

        with PrimitiveHarness() as h:
            owner = h.open()
            before = tuple(h.tls_sockets[0].sent)
            for control in (None, False, object(), Subclass(), Duck()):
                self.rejected(lambda: owner.publish('topic', b'body',
                              deadline=h.deadline(), cancel=control), 'admission')
            self.assertEqual(tuple(h.tls_sockets[0].sent), before)
            self.assertTrue(owner.strict_instance_compatible(settings()))

    def test_preset_operation_cancel_does_not_gate_but_lifecycle_cancel_does(self):
        with PrimitiveHarness() as h:
            owner = h.open()
            operation = threading.Event()
            operation.set()
            before = tuple(h.tls_sockets[0].sent)
            self.rejected(lambda: owner.publish('topic', b'body', deadline=h.deadline(),
                          cancel=operation), 'cancelled')
            self.assertEqual(tuple(h.tls_sockets[0].sent), before)
            self.assertFalse(owner._gate)
            self.assertFalse(h.cancel.is_set())
            self.assertFalse(h.raws[0].resource['closed'])
            owner.publish('topic', b'survives', deadline=h.deadline(), cancel=threading.Event())
            h.cancel.set()
            self.rejected(lambda: owner.publish('topic', b'blocked', deadline=h.deadline(),
                          cancel=operation), 'cancelled')
            self.assertTrue(owner._gate)
            self.assertTrue(h.raws[0].resource['closed'])
            h.cancel.clear()
            self.rejected(lambda: owner.publish('topic', b'still-blocked', deadline=h.deadline(),
                          cancel=threading.Event()), 'disconnected')
            self.assertTrue(owner._gate)

    def test_operation_cancel_preserves_existing_terminal_state_and_cleanup(self):
        with PrimitiveHarness() as h:
            owner = h.open()
            owner.close(h.deadline())
            operation = threading.Event()
            operation.set()
            before = tuple(h.tls_sockets[0].sent)
            self.rejected(lambda: owner.publish('topic', b'body', deadline=h.deadline(),
                          cancel=operation), 'cancelled')
            self.assertTrue(owner._gate)
            self.assertTrue(h.raws[0].resource['closed'])
            self.assertEqual(tuple(h.tls_sockets[0].sent), before)
            self.assertFalse(h.cancel.is_set())

    def test_cancelled_owner_state_wait_releases_caller_without_unlock(self):
        with PrimitiveHarness() as h:
            owner = h.open()
            operation, entered = threading.Event(), threading.Event()
            lock = owner._state_lock

            class ObservedLock:
                def acquire(self, *args, **kwargs):
                    entered.set()
                    return lock.acquire(*args, **kwargs)

                def release(self):
                    lock.release()

            callers = ControlledCallers(h)
            self.assertTrue(lock.acquire(False))
            try:
                with mock.patch.object(owner, '_state_lock', ObservedLock()):
                    callers.start(lambda: owner.publish('topic', b'cancelled',
                                  deadline=h.deadline(), cancel=operation))
                    self.assertTrue(entered.wait(1))
                    operation.set()
                    self.wait_until(h, lambda: len(callers.results) == 1)
                    self.assertEqual(callers.results[0][0], 'cancelled')
                    self.assertEqual(callers.results[0][1], ())
                    self.assertTrue(lock.locked())
                    self.assertEqual(owner._tickets, [])
                    self.assertFalse(owner._gate)
                    self.assertFalse(h.raws[0].resource['closed'])
            finally:
                lock.release()
                callers.finish()
            owner.publish('topic', b'survivor', deadline=h.deadline(), cancel=threading.Event())

    def test_pending_operation_cancel_releases_bridge_before_producer_completion(self):
        with PrimitiveHarness() as h:
            operation = threading.Event()
            with PendingBridgeFixture(self, h, cancel=operation) as bridge:
                bridge.start()
                self.assertFalse(bridge.topic.ticket.done)
                operation.set()
                self.wait_until(h, lambda: bridge.callback_ticket.done)
                self.assertTrue(bridge.held)
                self.assertFalse(bridge.topic.ticket.done)
                self.assertFalse(bridge.topic.ticket.committed)
                self.assertIn(bridge.topic.ticket, bridge.owner._tickets)
                self.assertEqual(bridge.delivered, [])
                bridge.assert_unpoisoned()
                bridge.producer_release.set()
                self.wait_until(h, lambda: len(bridge.callers.results) == 1)
                self.assertEqual(bridge.callers.results[0][0], 'cancelled')
                self.assertIn('registration-debt', bridge.callers.results[0][1])
                self.assertTrue(bridge.topic.ticket.done)
                self.assertEqual(bridge.topic.state, 'debt')
                bridge.unlock()
                bridge.owner.cancelSubscribe('pending', bridge.callback, 'pending',
                    deadline=h.deadline(), cancel=threading.Event())
                self.assertNotIn('pending', bridge.owner._topics)
                bridge.assert_survivor()
                self.assertFalse(h.cancel.is_set())

    def test_commit_during_pending_clock_outlives_operation_event_and_deadline(self):
        with PrimitiveHarness() as h:
            operation = threading.Event()
            with PendingBridgeFixture(self, h, cancel=operation) as bridge:
                bridge.receiver_hook = bridge.pause_receiver
                bridge.start((b'first', b'second'))
                self.assertTrue(bridge.receiver_entered.wait(1))
                reads = []
                h.hooks['recv'] = lambda: reads.append(True)
                bridge.unlock()
                bridge.producer_release.set()
                self.wait_until(h, lambda: len(bridge.callers.results) == 1)
                self.assertEqual(bridge.callers.results, [('success', ())])
                self.assertTrue(bridge.topic.ticket.committed)
                operation.set()
                bridge.hold()
                bridge.receiver_now = bridge.deadline + 1
                bridge.receiver_hook = None
                bridge.receiver_release.set()
                h.real_sleep(.025)
                self.assertFalse(bridge.callback_ticket.done)
                self.assertEqual(bridge.delivered, [])
                bridge.unlock()
                self.wait_until(h, lambda: len(bridge.delivered) == 2)
                self.assertEqual(bridge.delivered, [(b'first', 'pending'), (b'second', 'pending')])
                self.assertEqual(reads, [])
                bridge.owner.cancelSubscribe('pending', bridge.callback, 'pending',
                    deadline=h.deadline(), cancel=threading.Event())
                bridge.assert_survivor()
                self.assertFalse(h.cancel.is_set())

    def test_distinct_operation_event_keeps_original_deadline_and_precedence(self):
        with PrimitiveHarness(real_time=False) as h:
            owner = h.open()
            operation = threading.Event()
            deadline = h.deadline(1)
            h.clock.value = deadline - .001
            owner.publish('topic', b'before', deadline=deadline, cancel=operation)
            before = tuple(h.tls_sockets[0].sent)
            for value in (deadline, deadline + .001):
                h.clock.value = value
                self.rejected(lambda: owner.publish('topic', b'expired',
                              deadline=deadline, cancel=operation), 'deadline')
            operation.set()
            self.rejected(lambda: owner.publish('topic', b'cancelled',
                          deadline=deadline, cancel=operation), 'cancelled')
            self.assertEqual(tuple(h.tls_sockets[0].sent), before)
            self.assertFalse(owner._gate)
            self.assertFalse(h.cancel.is_set())
            owner.publish('topic', b'new-budget', deadline=h.deadline(), cancel=threading.Event())


class BenchLoopbackTests(StrictTestCase):
    def test_preparation_is_inert_opaque_and_explicitly_mode_bound(self):
        with PrimitiveHarness(loopback=True) as h:
            values = MappingProxyType(loopback_settings())
            prepared = messenger.Messenger.prepare_bench_loopback_transport(values, h.cancel)
            self.assertEqual(h.contexts, [])
            self.assertEqual(h.allocations, [])
            self.assertEqual(prepared._mode, 'loopback-plaintext-bench')
            for name in ('_mode', '_values', '_cancel', '_context'):
                with self.assertRaises(AttributeError):
                    setattr(prepared, name, object())
            for secret in ('synthetic-user', 'synthetic-password'):
                self.assertNotIn(secret, repr(prepared))

    def test_missing_and_unknown_transport_values_reject_before_acquisition(self):
        with PrimitiveHarness(loopback=True) as h:
            for key in loopback_settings():
                values = loopback_settings()
                del values[key]
                with self.subTest(missing=key):
                    self.rejected(lambda: messenger.prepare_bench_loopback_transport(values, h.cancel), 'admission')
            for values in (None, [], object(), settings(),
                           loopback_settings(amq_transport='unknown'),
                           loopback_settings(amq_transport='tls'),
                           loopback_settings(amq_transport=True),
                           loopback_settings(amq_use_ssl=True),
                           loopback_settings(amq_use_ssl=0),
                           loopback_settings(amq_tls_server_name=None),
                           loopback_settings(amq_ca_pem=None),
                           loopback_settings(amq_ca_pem=PUBLIC_CA)):
                self.rejected(lambda: messenger.prepare_bench_loopback_transport(values, h.cancel), 'admission')
            self.assertEqual(h.contexts, [])
            self.assertEqual(h.allocations, [])

    def test_only_exact_ipv4_loopback_port_and_nonempty_credentials_are_admitted(self):
        class Text(str):
            pass

        changes = ([{'amq_dial_address': value} for value in
                    ('localhost', '127.1', '127.0.0.2', '127.000.000.001', '::1',
                     '::ffff:127.0.0.1', '192.0.2.7', '', Text('127.0.0.1'))]
                   + [{'amq_port': value} for value in (0, 65536, True, 61613.0, '61613')]
                   + [{'amq_transport': Text('loopback-plaintext-bench')}]
                   + [{key: value} for key in ('amq_username', 'amq_password')
                      for value in ('', None, Text('user'), 'bad\ntext', 'x' * 1025)]
                   + [{'amq_stomp_host': 'host\ninvalid'}, {'amq_stomp_host': 'h' * 256},
                      {'amq_username': '\U0001f600' * 1024, 'amq_password': '\U0001f600' * 1024}])
        with PrimitiveHarness(loopback=True) as h:
            for change in changes:
                with self.subTest(keys=tuple(change)):
                    self.rejected(lambda: messenger.prepare_bench_loopback_transport(
                        loopback_settings(**change), h.cancel), 'admission')
            for port in (1, 65535):
                messenger.prepare_bench_loopback_transport(loopback_settings(amq_port=port), h.cancel)
            messenger.prepare_bench_loopback_transport(loopback_settings(
                amq_username='\U0001f600' * 1024, amq_stomp_host='h' * 255), h.cancel)
            self.assertEqual(h.contexts, [])
            self.assertEqual(h.allocations, [])

    def test_environment_and_exact_lifecycle_event_are_required(self):
        with PrimitiveHarness(loopback=True) as h:
            with mock.patch.dict(messenger.os.environ, {'STOMP_SKIP_HOSTNAME_SCAN': '0'}):
                self.rejected(lambda: messenger.prepare_bench_loopback_transport(loopback_settings(), h.cancel), 'admission')
            self.rejected(lambda: messenger.prepare_bench_loopback_transport(loopback_settings(), object()), 'admission')
            h.cancel.set()
            self.rejected(lambda: messenger.prepare_bench_loopback_transport(loopback_settings(), h.cancel), 'cancelled')
            self.assertEqual(h.allocations, [])

    def test_actual_lower_raw_open_has_bound_endpoint_and_no_tls_surface(self):
        with PrimitiveHarness(loopback=True) as h:
            instance = h.open()
            raw = h.raws[0]
            self.assertEqual(h.allocations, [((socket.AF_INET, socket.SOCK_STREAM), {})])
            self.assertEqual(raw.addresses, [('127.0.0.1', 61613)])
            self.assertEqual(h.contexts, [])
            self.assertEqual(h.wraps, [])
            self.assertEqual(h.tls_sockets, [])
            for name in ('pending', 'do_handshake', 'unwrap'):
                self.assertFalse(hasattr(raw, name))
            self.assertEqual(instance._lower.bounded_endpoint,
                             ('loopback-plaintext', '127.0.0.1', 61613, None))
            with self.assertRaises(AttributeError):
                instance._lower.bounded_endpoint = ('tls', '127.0.0.1', 61613, 'broker.example')
            wire = b''.join(raw.sent)
            self.assertTrue(wire.startswith(b'STOMP\n'))
            self.assertIn(b'accept-version:1.1\n', wire)
            self.assertIn(b'heart-beat:0,0\n', wire)
            self.assertIn(b'login:synthetic-user\n', wire)
            self.assertIn(b'passcode:synthetic-password\n', wire)
            self.assertNotIn(b'\nhost:', wire)
            self.assertTrue(instance.bench_loopback_instance_compatible(loopback_settings(unrelated=object())))
            self.assertFalse(instance.strict_instance_compatible(loopback_settings()))
            self.assertFalse(instance.strict_instance_compatible(settings()))

    def test_ordinary_tls_api_and_compatibility_cannot_borrow_plaintext(self):
        with PrimitiveHarness() as h:
            for values in (loopback_settings(), settings(amq_transport='loopback-plaintext-bench'),
                           settings(amq_transport='unknown'), settings(amq_transport=None)):
                self.rejected(lambda: messenger.prepare_transport(values, h.cancel), 'admission')
            self.assertEqual(h.contexts, [])
            self.assertEqual(h.allocations, [])
            instance = h.open()
            self.assertTrue(instance.strict_instance_compatible(settings()))
            self.assertFalse(instance.bench_loopback_instance_compatible(loopback_settings()))
            self.assertEqual(instance._lower.bounded_endpoint,
                             ('tls', '192.0.2.7', 61614, 'broker.example'))

    def test_actual_lower_endpoint_is_checked_on_return_and_borrow(self):
        wrong_endpoint = property(lambda lower: ('loopback-plaintext', '127.0.0.1', 61614, None))
        with PrimitiveHarness(loopback=True) as h:
            with mock.patch.object(messenger.Connection, 'bounded_endpoint', wrong_endpoint):
                self.rejected(lambda: h.open(), 'admission')
            self.assertEqual(len(h.raws), 1)
            self.assertTrue(h.raws[0].resource['closed'])
            self.assertTrue(b''.join(h.raws[0].sent).startswith(b'STOMP\n'))
            instance = h.open()
            before = tuple(h.raws[1].sent)
            with mock.patch.object(messenger.Connection, 'bounded_endpoint', wrong_endpoint):
                self.assertFalse(instance.bench_loopback_instance_compatible(loopback_settings()))
            self.assertTrue(instance.bench_loopback_instance_compatible(loopback_settings()))
            self.assertEqual(tuple(h.raws[1].sent), before)

    def test_preparations_cannot_cross_modes_settings_events_or_reuse(self):
        with PrimitiveHarness(loopback=True) as h:
            plain = messenger.prepare_bench_loopback_transport(loopback_settings(), h.cancel)
            tls = messenger.prepare_transport(settings(), h.cancel)
            self.rejected(lambda: messenger.Messenger.open_bounded(
                settings(), h.deadline(), h.cancel, prepared=plain), 'admission')
            self.rejected(lambda: messenger.Messenger.open_bench_loopback_bounded(
                loopback_settings(), h.deadline(), h.cancel, prepared=tls), 'admission')
            self.rejected(lambda: messenger.Messenger.open_bounded(
                loopback_settings(), h.deadline(), h.cancel, prepared=plain), 'admission')
            for values, cancel in ((loopback_settings(amq_port=61614), h.cancel),
                                   (loopback_settings(amq_password='changed'), h.cancel),
                                   (loopback_settings(amq_transport='unknown'), h.cancel),
                                   (loopback_settings(), threading.Event())):
                self.rejected(lambda: messenger.Messenger.open_bench_loopback_bounded(
                    values, h.deadline(), cancel, prepared=plain), 'admission')
            for foreign in (None, object(), loopback_settings()):
                self.rejected(lambda: messenger.Messenger.open_bench_loopback_bounded(
                    loopback_settings(), h.deadline(), h.cancel, prepared=foreign), 'admission')
            self.assertEqual(h.allocations, [])
            self.assertFalse(plain._used)
            self.assertFalse(tls._used)
            instance = messenger.Messenger.open_bench_loopback_bounded(
                loopback_settings(), h.deadline(), h.cancel, prepared=plain)
            h.instances.append(instance)
            self.rejected(lambda: messenger.Messenger.open_bench_loopback_bounded(
                loopback_settings(), h.deadline(), h.cancel, prepared=plain), 'admission')
            self.assertEqual(len(h.allocations), 1)

    def test_shared_publish_subscribe_dispatch_cancel_and_passive_close(self):
        with PrimitiveHarness(loopback=True) as h:
            instance = h.open(loopback_settings(amq_stomp_host='local-bench'))
            raw = h.raws[0]
            self.assertIn(b'host:local-bench\n', raw.sent[0])
            instance.publish('topic', b'body', 9, **h.controls())
            self.assertEqual(raw.sent[-1], b'SEND\ndestination:topic\ncontent-length:4\npriority:9\n\nbody\0')
            observed = []
            callback = lambda body, identifier: observed.append((body, identifier))
            instance.subscribe('topic', callback, 'one', **h.controls())
            h.message(1, b'received')
            self.wait_until(h, lambda: len(observed) == 1)
            self.assertEqual(observed, [(b'received', 'one')])
            instance.cancelSubscribe('topic', callback, 'one', **h.controls())
            self.assertTrue(raw.sent[-1].startswith(b'UNSUBSCRIBE\n'))
            before = tuple(raw.sent)
            instance.close(h.deadline())
            self.assertEqual(tuple(raw.sent), before)
            self.assertTrue(raw.resource['closed'])
            self.assertFalse(instance.bench_loopback_instance_compatible(loopback_settings(amq_stomp_host='local-bench')))

    def test_failed_connected_rolls_back_without_receiver_or_tls_fallback(self):
        for incoming in (b'CONNECTED\nversion:1.2\n\n\0', b'ERROR\n\n' + CANARY.encode() + b'\0', b''):
            with self.subTest(incoming_size=len(incoming)), PrimitiveHarness(loopback=True) as h:
                h.incoming = incoming
                workers = set(threading.enumerate())
                self.rejected(lambda: h.open())
                self.assertEqual(set(threading.enumerate()), workers)
                self.assertTrue(h.raws[0].resource['closed'])
                self.assertEqual(h.raws[0].close_calls, 1)
                self.assertEqual(h.contexts, [])
                self.assertEqual(h.wraps, [])

    def test_deadline_cancellation_and_acquisition_errors_release_raw_socket(self):
        for phase in ('raw-blocking', 'connect', 'socket-error', 'send', 'recv'):
            for failure in ('cancelled', 'deadline', 'io'):
                with self.subTest(phase=phase, failure=failure), PrimitiveHarness(real_time=False, loopback=True) as h:
                    def stop(*args):
                        if failure == 'cancelled':
                            h.cancel.set()
                        elif failure == 'deadline':
                            h.clock.value = 12.0
                        else:
                            raise OSError(CANARY)
                    h.hooks[phase] = stop
                    error = self.rejected(lambda: h.open())
                    if failure != 'io':
                        self.assertEqual(error.primary, failure)
                    self.assertTrue(h.raws[0].resource['closed'])
                    self.assertEqual(h.raws[0].close_calls, 1)
                    self.assertEqual(h.contexts, [])

    def test_preopen_deadline_and_lifecycle_cancellation_have_no_effects(self):
        with PrimitiveHarness(real_time=False, loopback=True) as h:
            prepared = messenger.prepare_bench_loopback_transport(loopback_settings(), h.cancel)
            for deadline in (h.now(), h.now() - 1, True, float('inf'), float('nan'), None):
                self.rejected(lambda: messenger.Messenger.open_bench_loopback_bounded(
                    loopback_settings(), deadline, h.cancel, prepared=prepared))
            h.cancel.set()
            self.rejected(lambda: messenger.Messenger.open_bench_loopback_bounded(
                loopback_settings(), h.deadline(), h.cancel, prepared=prepared), 'cancelled')
            self.assertEqual(h.allocations, [])
            self.assertFalse(prepared._used)

    def test_borrowing_rejects_contention_changed_settings_and_cancelled_lifecycle(self):
        with PrimitiveHarness(loopback=True) as h:
            instance = h.open()
            before = tuple(h.raws[0].sent)
            instance._state_lock.acquire()
            try:
                self.assertFalse(instance.bench_loopback_instance_compatible(loopback_settings()))
            finally:
                instance._state_lock.release()
            for values in (settings(), loopback_settings(amq_port=61614),
                           loopback_settings(amq_password='changed'),
                           loopback_settings(amq_ca_pem=None)):
                self.assertFalse(instance.bench_loopback_instance_compatible(values))
            h.cancel.set()
            self.assertFalse(instance.bench_loopback_instance_compatible(loopback_settings()))
            self.rejected(lambda: instance.publish('topic', b'body',
                          deadline=h.deadline(), cancel=threading.Event()), 'cancelled')
            self.assertEqual(tuple(h.raws[0].sent), before)

    def test_raw_close_debt_and_fixed_diagnostics_preserve_primary_failure(self):
        with PrimitiveHarness(loopback=True) as h:
            instance = h.open()
            raw = h.raws[0]
            raw.send_script.append(OSError(CANARY))
            raw.close_error = OSError(CANARY)
            error = self.rejected(lambda: instance.publish('topic', CANARY.encode(), **h.controls()))
            self.assertIn('socket-release', error.cleanup)
            primary = error.primary
            self.assertFalse(raw.resource['closed'])
            self.assertFalse(instance.bench_loopback_instance_compatible(loopback_settings()))
            snapshot = instance.diagnostics()
            self.assertEqual(snapshot['primary'], primary)
            for private in (CANARY, 'synthetic-user', 'synthetic-password', '127.0.0.1'):
                self.assertNotIn(private, repr(snapshot))
            raw.close_error = None
            instance.close(h.deadline())
            self.assertTrue(raw.resource['closed'])
            self.assertEqual(instance.diagnostics()['primary'], primary)


if __name__ == '__main__':
    unittest.main()
