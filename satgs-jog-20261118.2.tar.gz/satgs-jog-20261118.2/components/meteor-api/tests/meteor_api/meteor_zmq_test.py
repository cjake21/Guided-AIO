#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2023 The MITRE Corporation. All Rights Reserved.                #
#############################################################################
import logging
import time
import numpy as np
import unittest


# Until automated with the API install, will use this to add the code to the path
import sys
sys.path.insert(0, '../../src/')
from meteor_api.meteor_app_driver import MeteorAppDriver
from meteor_api.meteor_zmq_receiver import MeteorZMQReceiver
from meteor_api.meteor_zmq_sender import MeteorZMQSender
import meteor_api.comp_protos.Meteor_pb2 as mpb

class MeteorZMQTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.logger = logging.getLogger()
        cls.logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
        handler.setFormatter(formatter)
        cls.logger.addHandler(handler)
        
    def iqCb(self, batch, iqHeader, identifier):
        MeteorZMQTest.logger.info(f"Received IQ Data with identifier {identifier}")
        self.receivedArrayData.append(batch)

    def setUp(self):
        MeteorZMQTest.logger.warning("Setup called")
        self.receivedArrayData = list()
        self.receivedIqHeader = None

        amqIdentifier = "zmq"
        psuedoFrontend = "FRONT"
        psuedoRadio = "TEST"
        zmqURI = "ipc:///tmp/meteor-zmq-ipc-TEST"

        # These don't matter for sender-to-receiver tests. They matter when radios get involved
        sampleRate = 1e6
        bandwidth = 1e6
        driver = MeteorAppDriver("zmq", "../../credentials.json")

        self.receiver = MeteorZMQReceiver(driver, "TEST", self.iqCb, tx=True)
        self.sender = MeteorZMQSender(driver, "TEST", "FRONT", sampleRate, bandwidth, "Test IQ", "0.001", zmqURI)

        time.sleep(1)

    def tearDown(self):
        MeteorZMQTest.logger.info("Tearing Down")
        self.receiver.stop()
        self.receiver = None
        self.sender = None

    def cast_vec_float_to_short(self, input):
        maxScale = np.max([np.max(np.real(input)),np.max(np.imag(input))])
        maxShort = np.iinfo(np.short).max

        I_short = np.array(maxShort*np.real(input)/maxScale,dtype=np.short)
        Q_short = np.array(maxShort*np.imag(input)/maxScale,dtype=np.short)

        return I_short, Q_short

    # Generates floats internally
    def genQpskFloats(self, a, phi, length):
        samples = np.array([0, 1, 2, 3] * length, dtype=np.csingle)
        MeteorZMQTest.logger.debug(samples)
        sig = a*np.exp(1j * (2 * np.pi * samples) / 4)*np.exp(1j*phi) # /4 for qpsk
        MeteorZMQTest.logger.debug(sig)
        return sig

    def interleaveFloatSignal(self, sig):
        interleaved_signal = np.empty([2*len(sig)], dtype=np.single)
        interleaved_signal[::2] = np.real(sig).astype(dtype=np.single)
        interleaved_signal[1::2] = np.imag(sig).astype(dtype=np.single)
        return interleaved_signal


    def run_sig_len_floats(self, a, phi, length, batches):
        sig = None
        for i in range(batches):
            sig = self.genQpskFloats(a, phi, length)
            interleaved_signal = self.interleaveFloatSignal(sig)
            interleaved_bytes = interleaved_signal.tobytes()
            self.sender.transmit_iq_batch(interleaved_bytes, mpb.IQFormatEnum.eComplexFloat, len(sig))
        
        time.sleep(0.05)

        self.assertEqual(batches, len(self.receivedArrayData))
        for i in range(batches):
            MeteorZMQTest.logger.debug(self.receivedArrayData[i])
            self.assertEqual(len(self.receivedArrayData[i]), len(sig))

    def run_sig_len_shorts(self, a, phi, length, batches):
        interleaved_short_signal = None
        for i in range(batches):
            sig = self.genQpskFloats(a, phi, length)
            short_sig_I, short_sig_Q = self.cast_vec_float_to_short(sig)
            interleaved_short_signal = np.empty([2*len(sig)], dtype=np.short)
            interleaved_short_signal[::2] = short_sig_I
            interleaved_short_signal[1::2] = short_sig_Q
            interleaved_bytes = interleaved_short_signal.tobytes()
            self.sender.transmit_iq_batch(interleaved_bytes, mpb.IQFormatEnum.eComplexShort, len(sig))
        
        time.sleep(0.05)

        self.assertEqual(batches, len(self.receivedArrayData))
        for i in range(batches):
            MeteorZMQTest.logger.debug(self.receivedArrayData[i])
            self.assertEqual(len(self.receivedArrayData[i]), len(interleaved_short_signal)) # not automatically deinterleaved

    # Will compare signals. Currently only works on a single batch
    def run_sig_compare_floats(self, a, phi, length):
        # for i in range(batches):
        sig = self.genQpskFloats(a, phi, length)
        interleaved_signal = self.interleaveFloatSignal(sig)
        interleaved_bytes = interleaved_signal.tobytes()
        self.sender.transmit_iq_batch(interleaved_bytes, mpb.IQFormatEnum.eComplexFloat, len(sig))
        
        time.sleep(1)

        # self.assertEqual(batches, len(self.receivedArrayData))
        # for i in range(batches):
        # MeteorZMQTest.logger.debug(self.receivedArrayData)
        self.assertTrue(np.allclose(self.receivedArrayData[0], sig))

    # Will compare signals. Currently only works on a single batch
    def run_sig_compare_shorts(self, a, phi, length):
        # for i in range(batches):
        sig = self.genQpskFloats(a, phi, length)
        interleaved_signal = self.interleaveFloatSignal(sig)
        short_sig_I, short_sig_Q = self.cast_vec_float_to_short(sig)
        interleaved_short_signal = np.empty([2*len(sig)], dtype=np.short)
        interleaved_short_signal[::2] = short_sig_I
        interleaved_short_signal[1::2] = short_sig_Q
        interleaved_bytes = interleaved_short_signal.tobytes()
        self.sender.transmit_iq_batch(interleaved_bytes, mpb.IQFormatEnum.eComplexShort, len(sig))
        
        time.sleep(1)

        # self.assertEqual(batches, len(self.receivedArrayData))
        # for i in range(batches):
        MeteorZMQTest.logger.debug(self.receivedArrayData[0])
        self.assertTrue(np.allclose(self.receivedArrayData[0], interleaved_short_signal))

    def test_sig_compare_floats_1_len_1_batch(self):
        self.run_sig_compare_floats(1, 0, 1)#, 1)

    def test_sig_compare_floats_1_len_1_batch_phi(self):
        self.run_sig_compare_floats(1, np.pi/2, 1)#, 1)

    def test_sig_len_floats_1_len_1_batch(self):
        self.run_sig_len_floats(1, 0, 1, 1)
    def test_sig_len_floats_1_len_1_batch_phi(self):
        self.run_sig_len_floats(1, np.pi/2, 1, 1)
    def test_sig_len_floats_100_len_1_batch(self):
        self.run_sig_len_floats(1, 0, 100, 1)
    def test_sig_len_floats_1_len_10_batch(self):
        self.run_sig_len_floats(1, 0, 1, 10)
    def test_sig_len_floats_100_len_10_batch(self):
        self.run_sig_len_floats(1, 0, 100, 10)

    def test_sig_len_floats_1000_len_100_batch(self):
        self.run_sig_len_floats(1, 0, 1000, 100)

    def test_sig_compare_shorts_1_len_1_batch(self):
        self.run_sig_compare_shorts(1, 0, 1)#, 1)

    def test_sig_compare_shorts_1_len_1_batch_phi(self):
        self.run_sig_compare_shorts(1, np.pi/2, 1)#, 1)

    def test_sig_len_shorts_1_len_1_batch(self):
        self.run_sig_len_shorts(1, 0, 1, 1)
    def test_sig_len_shorts_1_len_1_batch_phi(self):
        self.run_sig_len_shorts(1, np.pi/2, 1, 1)
    def test_sig_len_shorts_100_len_1_batch(self):
        self.run_sig_len_shorts(1, 0, 100, 1)
    def test_sig_len_shorts_1_len_10_batch(self):
        self.run_sig_len_shorts(1, 0, 1, 10)
    def test_sig_len_shorts_100_len_10_batch(self):
        self.run_sig_len_shorts(1, 0, 100, 10)
    def test_sig_len_shorts_1000_len_100_batch(self):
        self.run_sig_len_shorts(1, 0, 1000, 100)



if __name__ == '__main__':
    unittest.main()