#!/bin/bash
#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2022 The MITRE Corporation. All Rights Reserved.                #
#############################################################################

lint_dir_and_subdirs() {
  for f in $(find $1 -type f -name "*.py");do
    if (! [[ $f == *"venv"* ]]) && (! [[ $f == *"oldHMI"* ]]);then
      # echo "linting over file $f"
      pyflakes $f 1> >(grep -v "imported but unused" >&1) 1> >(grep -v "assigned to but never used" >&1)
    fi
  done
}
status=0
lint_dir_and_subdirs ../src >> lint.txt

cat lint.txt
if [ -s lint.txt ];then
    status=1
fi
rm lint.txt
exit $status
