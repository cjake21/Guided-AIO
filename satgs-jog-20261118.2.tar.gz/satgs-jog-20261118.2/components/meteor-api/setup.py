from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py


class BuildPackage(build_py):
    def run(self):
        if not (Path(__file__).parent / "src/meteor_api/protobufs/Meteor_pb2.py").is_file():
            raise RuntimeError("Generate Meteor_pb2.py before building the package.")
        super().run()


setup(cmdclass={"build_py": BuildPackage})
