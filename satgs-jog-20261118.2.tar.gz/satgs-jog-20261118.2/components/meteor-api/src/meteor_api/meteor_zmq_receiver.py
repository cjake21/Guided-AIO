#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2023 The MITRE Corporation. All Rights Reserved.                #
#############################################################################
import os
import queue
from threading import Thread, Lock
import time
import zmq
import logging
import numpy as np
from meteor_api.meteor_app_driver import MeteorAppDriver
from meteor_api.meteor_api_constants import NEW_RX_IQ, NEW_TX_IQ
from meteor_api.internal_helpers import timer
import meteor_api.protobufs.Meteor_pb2 as mpb


class MeteorZMQReceiver:
    DATA_KEY = "DATA"
    IQ_HEADER_KEY = "IQ_HEADER"
    IDENTIFIER_KEY = "IDENTIFIER"
    """
    Receiver component of the Python IQ driver for METEOR. Currently only supports single-channel receive.

    Allows applications to receive raw IQ from a radio connected to METEOR.
    Designed to work in tandem with the METEOR App Driver

    The user constructs this and passes a callback function which will be executed whenever new IQ data is received, about every 100ms. (METEOR batch size)
    """
    def __init__(self, driver, radio_id, iq_callback, zmq_uri = "ipc:///tmp/meteor-zmq-ipc", tx = False, record = False, filename = ""):
        """
        Constructs the ZMQ Receiver

        :param driver: An instance of the METEOR App Driver connected to the METEOR system this will use
        :param radio_id: Radio name to receive IQ from
        :param iqCallback: Function that will be passed the raw IQ + IQ header when new IQ is available from the radio. Three parameters: batch (the IQ Data as a numpy array), header (the IQ header as a IqHeaderMsg), id (The identifier from the MeteorAppDriver constructor as a string).
        :param zmq_uri: ZeroMQ URI that the IQ will be sent to. Use this when starting a receive stream in METEOR. The ipc://works on the same machine, otherwise you'll want a TCP URI (or other URI supported by ZeroMQ)
        :param tx: Debugging only. Use NEW_RX_IQ or NEW_TX_IQ for the receive trigger. (Used to connect to df calibration)
        :param record: _VERY BASIC_ recording. Debugging only.
        """
        self.logger = logging.getLogger(__name__)
        self.driver = driver
        subtopic = NEW_RX_IQ
        if (tx):
            subtopic = NEW_TX_IQ
        self.driver.subscribe([radio_id, subtopic], self.new_IQ)
        self.numReceivedBatches = 0
        self.iq_callback = iq_callback
        self.record = record
        self.filename = filename
        if (self.record):
            self.outputFile = open(self.filename, 'ab')

        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PULL) # Receive from a push socket with a pull socket
        full_zmq_uri = zmq_uri + "-" + radio_id
        self.socket.bind(full_zmq_uri)

        # Inter-thread queue
        self.iqQueue = queue.Queue(maxsize=100)
        self.backgroundThread = Thread(target=self.run_iq_callback)
        self.stopBackgroundThread = False
        self.lock = Lock()
        self.processing = False
        self.backgroundThread.start()

        self.logger.warning("ZMQ Listening to socket: {}".format(full_zmq_uri))

    def __del__(self):
        self.zmqContext.destroy()
        self.stop()
        self.backgroundThread.join()

    def stop(self):
        self.logger.debug("Stop called")
        with(self.lock):
            self.stopBackgroundThread = True
            self.logger.debug("Marking stop")
        self.logger.debug("Stop Call Completed")

    def set_processing(self, new_val):
        with(self.lock):
            self.processing = new_val

    def get_processing(self):
        toReturn = False
        with(self.lock):
            toReturn = self.processing
        return toReturn

    @timer
    def new_IQ(self, msg, identifier):
        """
        Internal AMQ Callback when new IQ is available.
        Receives the IQ data and starts the ZMQ receive routine
        """
        if (self.get_processing()):
            self.logger.warning("New IQ batch received while processing the old batch.")
        size = self.iqQueue.qsize()
        if (size > 0):
            self.logger.info(f"Queue length: {size}")
        self.logger.debug("-------------------------------------------------------------------------")
        iqHeader = mpb.IqHeaderMsg()
        iqHeader.ParseFromString(msg)
        self.zmq_receive(iqHeader, identifier)
        self.logger.debug("-------------------------------------------------------------------------")


    @timer
    def raw_zmq_receive(self):
        """
        Internal Actual call to receive in ZMQ. Used for timing.
        """
        return self.socket.recv() # BLOCKING

    @timer
    def zmq_receive(self, iq_header, identifier):
        """
        Internal, Given an IQ header, receives the corresponding batch of IQ. Converts it to a numpy array and calls the user-provided callback.
        """
        message = self.raw_zmq_receive()
        callbackData = dict()
        callbackData[self.DATA_KEY] = message
        callbackData[self.IQ_HEADER_KEY] = iq_header
        callbackData[self.IDENTIFIER_KEY] = identifier
        self.iqQueue.put_nowait(callbackData)

    @timer
    def reformat_data(self, message, iqHeader):
        success = False
        numSamples = 0
        if (iqHeader.iq_format == mpb.IQFormatEnum.eComplexFloat):
            data = np.frombuffer(message, dtype=np.csingle) # will interpret interleaved data automatically
            numSamples = len(data)
            if (numSamples == iqHeader.samples_per_channel):
                success = True
        elif (iqHeader.iq_format == mpb.IQFormatEnum.eComplexShort):
            data = np.frombuffer(message, dtype=np.short)
            numSamples = (int)(len(data) / 2)
            if (numSamples == iqHeader.samples_per_channel): # Short isn't deinterleaved automatically, so there are twice the number of samples
                success = True
        else:
            print(logging.error("Unknown IQ Format."))
            data = np.zeros()

        sampleMessage = f"Received {len(message)} bytes corresponding to {numSamples} samples. Expected {iqHeader.samples_per_channel} samples. Received {numSamples / iqHeader.samples_per_channel} times the exepcted number of samples"
        if (not success):
            self.logger.error(sampleMessage)
            raise BaseException(sampleMessage)
        else:
            self.logger.debug(sampleMessage)
        return data

    def run_iq_callback(self):
        while(not self.stopBackgroundThread):
            # Moving to background async thread to keep this thread available.
            try:
                callbackData = self.iqQueue.get_nowait()
                self.set_processing(True)
                self.logger.debug("Dequeued data. Processing")

                iqHeader = callbackData[self.IQ_HEADER_KEY]
                message = callbackData[self.DATA_KEY]
                identifier = callbackData[self.IDENTIFIER_KEY]
                self.numReceivedBatches += 1
                data = self.reformat_data(message, iqHeader)

                self.real_run_iq_callback(data, iqHeader, identifier)
                # From hmi/generate_functions/helpers/save_to_binary.py
                if (self.record):
                        self.outputFile.write(data)
                self.set_processing(False)
            except queue.Empty:
                # self.logger.debug("IQ Queue empty after 0.005s")
                time.sleep(0.005)
        self.logger.info("Done")


    @timer
    def real_run_iq_callback(self, data, iq_header, identifier): # Lets us time the called function.
        self.iq_callback(data, iq_header, identifier)

# @timer
def example_receive_IQ_callback(batch, iq_header, identifier):
    """
    Example callback function. Does nothing.
    """
    pass
    # If the IQ format is Float, batch will be a numpy array of type np.csingle (complex single precision) which handles the I/Q interleaving automatically
    # If the IQ format is short, batch will be a numpy array of type np.short. This will be interleaved I/Q so the length of this array will be 2x the length of the data.
    # If the IQ format is something else, it's not supported by METEOR.
    
    # From hmi/generate_functions/helpers/save_to_binary.py
    #file = os.path.join("fname", f'channel_{ch}.dat')
    # with open("temp.dat", 'ab') as f:
    #     f.write(batch)


if __name__ == '__main__': # For debugging
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    handler.setFormatter(formatter)
    log.addHandler(handler)
    driver = MeteorAppDriver("../../credentials.json", "zmq")

    # B210 USRP-F5D84D
    # X310 31DCC9F (MM275122)
    #zmqReceiver = MeteorZMQReceiver(driver, "USRP-F5D84D", example_receive_IQ_callback, log)
    #zmqReceiver = MeteorZMQReceiver(driver, "TEST", example_receive_IQ_callback, log, tx=True)
    # zmqReceiver = MeteorZMQReceiver(driver, "USRP-323DF53", example_receive_IQ_callback, tx=False, record = False)
    #zmqReceiver = MeteorZMQReceiver(driver, "USRP-323DF53", example_receive_IQ_callback, tx=False, record = True, filename = "zmq_record_nr_tx_loop_10MHz_from_new_loopback_am_comb_10MHz.dat")
    zmqReceiver = MeteorZMQReceiver(driver, "USRP-323DF53", example_receive_IQ_callback, tx=False, record = True, filename = "temp.dat")
    while(True):
        time.sleep(.1)
