
#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2023 The MITRE Corporation. All Rights Reserved.                #
#############################################################################
import time
import logging
BATCH_DURATION_SECONDS=0.1
def timer(func):
    '''
    Annotation/Decorator that will log (info) the duration of a function call. Place @timer before functiosn that require logging.
    '''
    def wrapper(*args, **kwargs):
        timeStart = time.time()
        retVal = func(*args, **kwargs)
        timeStop = time.time()
        level = logging.INFO
        duration = timeStop - timeStart
        if (duration > BATCH_DURATION_SECONDS): # 
            level = logging.WARN
        logging.log(level, "Took {:.6f} seconds to execute {:s}".format((timeStop - timeStart), func.__name__))
        return retVal
    return wrapper
