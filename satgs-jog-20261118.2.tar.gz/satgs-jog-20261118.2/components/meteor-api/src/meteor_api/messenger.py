#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2022 The MITRE Corporation. All Rights Reserved.                #
#############################################################################

import ssl
from stomp import listener, Connection
import time
import logging
import base64
import binascii
import ipaddress
import math
import os
import threading
import types
from collections.abc import Mapping
from time import monotonic
from stomp.transport import BoundedError as _LowerError


_MISSING = object()
_PROVENANCE = object()
_TLS = 'tls'
_BENCH_LOOPBACK = 'loopback-plaintext-bench'
_CODES = ('admission', 'deadline', 'cancelled', 'tcp', 'tls-trust', 'tls-identity',
          'tls', 'protocol', 'send', 'disconnected', 'callback', 'worker-start',
          'diagnostic-recording', 'socket-release', 'active-operation', 'active-callback',
          'worker-start-pending', 'worker-live', 'acquisition', 'operation-limit',
          'topic-limit', 'wire-id', 'pending-limit', 'framing', 'legacy-path',
          'non-quiescent', 'receive', 'state', 'frame', 'io', 'registration-limit',
          'registration-debt')
_CLEANUP = ('socket-release', 'active-operation', 'active-callback',
            'worker-start-pending', 'worker-live', 'registration-debt')


class MessengerError(Exception):
    def __init__(self, primary, cleanup=()):
        self.primary = primary if type(primary) is str and primary in _CODES else 'admission'
        self.cleanup = tuple(code for code in _CLEANUP if code in cleanup)
        Exception.__init__(self, self.primary)


def _deadline(value):
    valid = type(value) in (int, float)
    if valid:
        try:
            valid = math.isfinite(value)
        except OverflowError:
            valid = False
    if not valid:
        raise MessengerError('admission')


def _event(cancel):
    if type(cancel) is not threading.Event:
        raise MessengerError('admission')
    if cancel.is_set():
        raise MessengerError('cancelled')


def _text(value, characters, size, empty=False, ascii_only=False, wire=True):
    if type(value) is not str or len(value) > characters or (not empty and not value):
        raise MessengerError('admission')
    if wire and any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise MessengerError('admission')
    encoded = None
    try:
        encoded = value.encode('ascii' if ascii_only else 'utf-8')
    except UnicodeError:
        pass
    if encoded is None or len(encoded) > size:
        raise MessengerError('admission')
    return value


def _settings(settings):
    if not isinstance(settings, Mapping):
        raise MessengerError('admission')
    try:
        if 'amq_transport' in settings:
            raise MessengerError('admission')
        values = tuple(settings[key] for key in ('amq_dial_address', 'amq_port',
            'amq_tls_server_name', 'amq_ca_pem', 'amq_username', 'amq_password', 'amq_use_ssl'))
        host = settings.get('amq_stomp_host')
    except Exception:
        raise MessengerError('admission') from None
    dial, port, identity, pem, username, password, tls = values
    _text(dial, 45, 45, ascii_only=True)
    _text(identity, 253, 253, ascii_only=True)
    if type(port) is not int or not 1 <= port <= 65535 or tls is not True or '%' in dial:
        raise MessengerError('admission')
    address = None
    try:
        address = ipaddress.ip_address(dial)
    except ValueError:
        pass
    if address is None or str(address) != dial:
        raise MessengerError('admission')
    certificate_name = None
    try:
        certificate_name = ipaddress.ip_address(identity)
    except ValueError:
        pass
    if certificate_name is not None:
        valid = '%' not in identity and str(certificate_name) == identity
    else:
        valid = all(0 < len(label) <= 63 and label[0] != '-' and label[-1] != '-'
                    and all(char.isalnum() or char == '-' for char in label)
                    for label in identity.split('.'))
    if not valid:
        raise MessengerError('tls-identity')
    _text(pem, 65536, 65536, ascii_only=True, wire=False)
    _connect_settings(username, password, host, empty=True)
    return dial, port, identity, pem, username, password, host


def _bench_loopback_settings(settings):
    if not isinstance(settings, Mapping):
        raise MessengerError('admission')
    try:
        mode, tls, dial, port, username, password = (settings[key] for key in
            ('amq_transport', 'amq_use_ssl', 'amq_dial_address', 'amq_port',
             'amq_username', 'amq_password'))
        host = settings.get('amq_stomp_host')
        has_tls_keys = 'amq_tls_server_name' in settings or 'amq_ca_pem' in settings
    except Exception:
        raise MessengerError('admission') from None
    if (type(mode) is not str or mode != _BENCH_LOOPBACK or tls is not False
            or type(dial) is not str or dial != '127.0.0.1'
            or type(port) is not int or not 1 <= port <= 65535 or has_tls_keys):
        raise MessengerError('admission')
    _connect_settings(username, password, host, empty=False)
    return dial, port, None, None, username, password, host


def _connect_settings(username, password, host, *, empty):
    if host is not None:
        _text(host, 255, 255, empty=True, ascii_only=True)
    _text(username, 1024, 4096, empty=empty)
    _text(password, 1024, 4096, empty=empty)
    headers = (('accept-version', '1.1'), ('heart-beat', '0,0'),
               ('login', username), ('passcode', password))
    if host is not None:
        headers += (('host', host),)
    if sum(len(key.encode('utf-8')) + len(value.encode('utf-8')) + 2 for key, value in headers) > 8192:
        raise MessengerError('admission')


def _endpoint(mode, values):
    lower_mode = 'loopback-plaintext' if mode == _BENCH_LOOPBACK else _TLS
    return lower_mode, values[0], values[1], values[2]


def _public_ca(pem, cancel):
    inside, count, body = False, 0, []
    for line in pem.splitlines():
        _event(cancel)
        if line == '-----BEGIN CERTIFICATE-----' and not inside:
            inside, body = True, []
        elif line == '-----END CERTIFICATE-----' and inside:
            decoded = None
            try:
                decoded = base64.b64decode(''.join(body), validate=True)
            except (ValueError, binascii.Error):
                pass
            if not decoded:
                raise MessengerError('tls-trust')
            inside, count = False, count + 1
        elif inside:
            if not line or not all(char in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=' for char in line):
                raise MessengerError('tls-trust')
            body.append(line)
        elif line.strip(' \t'):
            raise MessengerError('tls-trust')
    if inside or not count:
        raise MessengerError('tls-trust')


class _Prepared:
    __slots__ = ('_mode', '_values', '_context', '_cancel', '_used', '_lock', '_provenance')

    def __init__(self, mode, values, context, cancel):
        for name, value in (('_mode', mode), ('_values', values), ('_context', context), ('_cancel', cancel),
                            ('_used', False), ('_lock', threading.Lock()), ('_provenance', _PROVENANCE)):
            object.__setattr__(self, name, value)

    def __setattr__(self, name, value):
        raise AttributeError('opaque preparation')


def prepare_transport(settings, cancel):
    _event(cancel)
    if os.environ.get('STOMP_SKIP_HOSTNAME_SCAN') != '1':
        raise MessengerError('admission')
    values = _settings(settings)
    _public_ca(values[3], cancel)
    _event(cancel)
    context = None
    failed = False
    try:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        _event(cancel)
        context.verify_mode = ssl.CERT_REQUIRED
        context.check_hostname = True
        if hasattr(ssl, 'TLSVersion') and hasattr(context, 'minimum_version'):
            context.minimum_version = ssl.TLSVersion.TLSv1_2
        else:
            context.options |= ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
        _event(cancel)
        context.load_verify_locations(cadata=values[3])
    except MessengerError:
        raise
    except BaseException:
        failed = True
    _event(cancel)
    if failed:
        raise MessengerError('tls-trust') from None
    return _Prepared(_TLS, values, context, cancel)


def prepare_bench_loopback_transport(settings, cancel):
    _event(cancel)
    if os.environ.get('STOMP_SKIP_HOSTNAME_SCAN') != '1':
        raise MessengerError('admission')
    values = _bench_loopback_settings(settings)
    _event(cancel)
    return _Prepared(_BENCH_LOOPBACK, values, None, cancel)


class _Ticket:
    __slots__ = ('done', 'committed')

    def __init__(self):
        self.done = False
        self.committed = False


class _Topic:
    def __init__(self, name, wire_id, ticket, deadline, cancel):
        self.name = name
        self.wire_id = wire_id
        self.ticket = ticket
        self.deadline = deadline
        self.cancel = cancel
        self.state = 'pending'
        self.removal = None


class _Registration:
    def __init__(self, topic, callback, identifier, ticket):
        self.topic = topic
        self.callback = callback
        self.identifier = identifier
        self.ticket = ticket
        self.state = 'pending'

    def matches(self, callback, identifier):
        if self.identifier != identifier:
            return False
        if type(callback) is types.MethodType and type(self.callback) is types.MethodType:
            return self.callback.__self__ is callback.__self__ and self.callback.__func__ is callback.__func__
        return self.callback is callback

class Messenger:
    global_stomp_connection = None
    global_stomp_listener = None
    pre_connection_subscriptions = []
    prepare_transport = staticmethod(prepare_transport)
    prepare_bench_loopback_transport = staticmethod(prepare_bench_loopback_transport)

    @classmethod
    def open_bounded(cls, settings, deadline, cancel, *, prepared):
        return cls._open_bounded(settings, deadline, cancel, prepared, _TLS)

    @classmethod
    def open_bench_loopback_bounded(cls, settings, deadline, cancel, *, prepared):
        return cls._open_bounded(settings, deadline, cancel, prepared, _BENCH_LOOPBACK)

    @classmethod
    def _open_bounded(cls, settings, deadline, cancel, prepared, mode):
        _deadline(deadline)
        _event(cancel)
        if type(mode) is not str or mode not in (_TLS, _BENCH_LOOPBACK):
            raise MessengerError('admission')
        if cls is not Messenger or monotonic() >= deadline:
            raise MessengerError('deadline' if cls is Messenger else 'admission')
        values = (_bench_loopback_settings(settings) if mode == _BENCH_LOOPBACK
                  else _settings(settings))
        if type(prepared) is not _Prepared or prepared._provenance is not _PROVENANCE:
            raise MessengerError('admission')
        if not prepared._lock.acquire(False):
            raise MessengerError('admission')
        try:
            if (prepared._used or prepared._mode != mode or prepared._values != values
                    or prepared._cancel is not cancel):
                raise MessengerError('admission')
            _event(cancel)
            if monotonic() >= deadline:
                raise MessengerError('deadline')
            context = prepared._context
            object.__setattr__(prepared, '_used', True)
            object.__setattr__(prepared, '_context', None)
            object.__setattr__(prepared, '_values', None)
        finally:
            prepared._lock.release()
        owner = object.__new__(cls)
        owner._strict = True
        owner._transport_mode = mode
        owner._provenance = _PROVENANCE
        owner._settings = values
        owner._cancel = cancel
        owner._gate = False
        owner._closed = False
        owner._lower = None
        owner._lower_released = False
        owner._state_lock = threading.Lock()
        owner._ledger_lock = threading.Lock()
        owner._tickets = []
        owner._registrations = []
        owner._topics = {}
        owner._last_id = 0
        owner._opening = None
        owner._callback = None
        owner._callback_thread = None
        owner._dispatch_method = owner._dispatch
        owner._primary = 'none'
        owner._cleanup = ()
        owner._counters = [0] * len(_CODES)
        owner._recording_failed = False
        primary, cleanup = None, ()
        try:
            owner._check(deadline, cancel)
            dial, port, identity, pem, username, password, host = values
            if mode == _BENCH_LOOPBACK:
                owner._lower = Connection.open_loopback_bounded(dial_address=dial, port=port,
                    username=username, passcode=password, vhost=host, deadline=deadline, cancel=cancel)
            else:
                owner._lower = Connection.open_bounded(dial_address=dial, port=port,
                    tls_identity=identity, ssl_context=context, username=username,
                    passcode=password, vhost=host, deadline=deadline, cancel=cancel)
            if owner._lower.bounded_endpoint != _endpoint(mode, values):
                raise MessengerError('admission')
            owner._check(deadline, cancel)
            return owner
        except (MessengerError, _LowerError) as error:
            primary, cleanup = error.primary, error.cleanup
        except BaseException:
            primary = 'acquisition'
        owner._gate = True
        if owner._lower is not None:
            cleanup += owner._passive(deadline)
        raise owner._error(primary, cleanup) from None

    def _check(self, deadline, cancel, passive=False):
        if not passive:
            if type(cancel) is not threading.Event:
                raise MessengerError('admission')
            if self._cancel.is_set():
                self._gate = True
                raise MessengerError('cancelled')
            if cancel.is_set():
                raise MessengerError('cancelled')
            if self._gate or (self._lower is not None and not self._lower.is_connected()):
                self._gate = True
                raise MessengerError('disconnected')
        if deadline is not None and monotonic() >= deadline:
            raise MessengerError('deadline')

    def _remaining(self, deadline, cancel, passive=False):
        self._check(deadline, cancel, passive)
        remaining = .010 if deadline is None else deadline - monotonic()
        if remaining <= 0:
            self._check(None, cancel, passive)
            raise MessengerError('deadline')
        return min(.010, remaining)

    def _lock(self, deadline, cancel, passive=False):
        while True:
            remaining = self._remaining(deadline, cancel, passive)
            if self._state_lock.acquire(timeout=remaining):
                try:
                    self._check(deadline, cancel, passive)
                except BaseException:
                    self._state_lock.release()
                    raise
                return

    def _record(self, code):
        acquired = False
        try:
            acquired = self._ledger_lock.acquire(False)
            if acquired:
                index = _CODES.index(code)
                self._counters[index] = min(2 ** 31 - 1, self._counters[index] + 1)
            else:
                self._recording_failed = True
        except BaseException:
            self._recording_failed = True
        finally:
            if acquired:
                try:
                    self._ledger_lock.release()
                except BaseException:
                    self._recording_failed = True

    def _debt(self):
        debt = []
        if any(not ticket.done for ticket in self._tickets):
            debt.append('active-operation')
        if self._callback is not None and not self._callback.done:
            debt.append('active-callback')
        if not self._lower_released and (any(topic.state == 'debt' for topic in tuple(self._topics.values()))
                or any(item.state in ('debt', 'removing') for item in tuple(self._registrations))):
            debt.append('registration-debt')
        return tuple(debt)

    def _error(self, primary, cleanup=()):
        error = MessengerError(primary, cleanup + self._debt())
        if self._primary == 'none':
            self._primary = error.primary
        self._cleanup = error.cleanup
        self._record(error.primary)
        return error

    def _passive(self, deadline):
        try:
            self._lower.close_bounded(deadline=deadline)
        except _LowerError as error:
            self._lower_released = not error.cleanup
            return error.cleanup
        except BaseException:
            return ('socket-release',)
        self._lower_released = True
        return ()

    def diagnostics(self):
        if not getattr(self, '_strict', False):
            raise MessengerError('legacy-path')
        return {'primary': self._primary, 'cleanup': self._cleanup,
                'recording_failed': self._recording_failed,
                'counters': tuple(zip(_CODES, self._counters))}

    def strict_instance_compatible(self, settings):
        return self._instance_compatible(settings, _TLS)

    def bench_loopback_instance_compatible(self, settings):
        return self._instance_compatible(settings, _BENCH_LOOPBACK)

    def _instance_compatible(self, settings, mode):
        if (type(self) is not Messenger or not getattr(self, '_strict', False)
                or getattr(self, '_transport_mode', None) != mode):
            return False
        try:
            values = (_bench_loopback_settings(settings) if mode == _BENCH_LOOPBACK
                      else _settings(settings))
        except Exception:
            return False
        if not self._state_lock.acquire(False):
            return False
        try:
            return (self._provenance is _PROVENANCE and self._settings == values
                    and not self._gate and not self._closed and not self._cancel.is_set()
                    and self._lower.bounded_endpoint == _endpoint(mode, values)
                    and self._lower.is_connected())
        finally:
            self._state_lock.release()

    def _admit(self, deadline, cancel):
        self._lock(deadline, cancel)
        try:
            self._tickets = [ticket for ticket in self._tickets if not ticket.done]
            if len(self._tickets) >= 64:
                raise MessengerError('operation-limit')
            ticket = _Ticket()
            self._tickets.append(ticket)
            return ticket
        finally:
            self._state_lock.release()

    def _run(self, action, topic, value, identifier, priority, deadline, cancel):
        _deadline(deadline)
        if type(cancel) is not threading.Event:
            raise MessengerError('admission')
        ticket, primary, cleanup = None, None, ()
        try:
            self._check(deadline, cancel)
            _text(topic, 256, 1024)
            if action == 'publish':
                if type(value) is not bytes or len(value) > 262144:
                    raise MessengerError('admission')
                if priority is not None and (type(priority) is not int or not 0 <= priority <= 9):
                    raise MessengerError('admission')
            else:
                _text(identifier, 256, 1024, empty=True, wire=False)
                if not callable(value):
                    raise MessengerError('admission')
            ticket = self._admit(deadline, cancel)
            if action == 'publish':
                self._lower.send_bounded(topic, value, priority, deadline=deadline, cancel=cancel)
                self._check(deadline, cancel)
                ticket.committed = True
            elif action == 'subscribe':
                self._subscribe(topic, value, identifier, ticket, deadline, cancel)
            else:
                self._cancel_registration(topic, value, identifier, ticket, deadline, cancel)
        except (MessengerError, _LowerError) as error:
            primary, cleanup = error.primary, error.cleanup
        except BaseException:
            primary = 'send' if action == 'publish' else 'state'
            self._gate = True
        finally:
            try:
                if primary is not None:
                    if self._cancel.is_set() or not self._lower.is_connected():
                        self._gate = True
                    if self._gate:
                        cleanup += self._passive(deadline)
            finally:
                if ticket is not None:
                    ticket.done = True
        if primary is not None:
            raise self._error(primary, cleanup) from None

    def _subscribe(self, name, callback, identifier, ticket, deadline, cancel):
        registration, topic, first = None, None, False
        try:
            while registration is None:
                self._lock(deadline, cancel)
                try:
                    topic = self._topics.get(name)
                    if topic is not None and topic.state == 'debt':
                        raise MessengerError('registration-debt')
                    waiting = (topic is not None and topic.state != 'active')
                    if topic is None and self._opening is not None and not self._opening.ticket.done:
                        waiting = True
                    if not waiting:
                        if len(self._registrations) >= 256:
                            raise MessengerError('registration-limit')
                        if topic is None:
                            if len(self._topics) >= 128:
                                raise MessengerError('topic-limit')
                            if self._last_id >= 2 ** 63 - 1:
                                raise MessengerError('wire-id')
                            self._last_id += 1
                            topic = _Topic(name, self._last_id, ticket, deadline, cancel)
                            self._topics[name] = topic
                            self._opening = topic
                            first = True
                        registration = _Registration(topic, callback, identifier, ticket)
                        self._registrations.append(registration)
                        if not first:
                            self._check(deadline, cancel)
                            registration.state = 'active'
                            ticket.committed = True
                finally:
                    self._state_lock.release()
                if registration is None:
                    time.sleep(self._remaining(deadline, cancel))
            if not first:
                return
            self._check(deadline, cancel)
            if registration.state != 'pending':
                raise MessengerError('registration-debt')
            self._lower.subscribe_bounded(name, topic.wire_id, deadline=deadline,
                                          cancel=cancel, dispatch=self._dispatch_method)
            self._lock(deadline, cancel)
            try:
                if registration.state != 'pending' or topic.state != 'pending':
                    raise MessengerError('registration-debt')
                self._check(deadline, cancel)
                registration.state = 'active'
                topic.state = 'active'
                ticket.committed = True
            finally:
                self._state_lock.release()
        except BaseException:
            if registration is not None and not ticket.committed:
                registration.state = 'debt'
                if first:
                    topic.state = 'debt'
                    try:
                        self._remove_wire(topic, ticket, deadline, cancel)
                    except (MessengerError, _LowerError):
                        pass
            raise

    def _remove_wire(self, topic, ticket, deadline, cancel):
        retired = None
        while True:
            self._lock(deadline, cancel)
            try:
                if self._topics.get(topic.name) is not topic:
                    return
                waiting = topic.removal is not None and topic.removal is not ticket and not topic.removal.done
                if not waiting:
                    topic.removal = ticket
                    break
            finally:
                self._state_lock.release()
            time.sleep(self._remaining(deadline, cancel))
        try:
            self._lower.unsubscribe_bounded(topic.wire_id, deadline=deadline, cancel=cancel)
        except _LowerError as error:
            if error.primary != 'wire-id':
                raise
        self._lock(deadline, cancel)
        try:
            self._check(deadline, cancel)
            if self._topics.get(topic.name) is topic:
                retired = self._registrations
                self._registrations = [item for item in retired if item.topic is not topic]
                del self._topics[topic.name]
        finally:
            self._state_lock.release()
            retired = None

    def _cancel_registration(self, name, callback, identifier, ticket, deadline, cancel):
        registration, retired = None, None
        self._lock(deadline, cancel)
        try:
            topic = self._topics.get(name)
            for item in self._registrations:
                if item.topic is topic and item.matches(callback, identifier):
                    registration = item
                    break
            if registration is None:
                raise MessengerError('admission')
            registration.state = 'removing'
            survivors = any(item is not registration and item.topic is topic
                            and item.state in ('pending', 'active') for item in self._registrations)
            if survivors:
                self._check(deadline, cancel)
                retired = self._registrations
                self._registrations = [item for item in retired if item is not registration]
                ticket.committed = True
            else:
                topic.state = 'debt'
        finally:
            self._state_lock.release()
            retired = None
        if survivors:
            return
        while not topic.ticket.done:
            time.sleep(self._remaining(deadline, cancel))
        self._remove_wire(topic, ticket, deadline, cancel)
        self._check(deadline, cancel)
        ticket.committed = True

    def _dispatch_remaining(self, topic):
        self._check(None, self._cancel)
        done = topic.ticket.done
        committed = topic.ticket.committed
        if topic.state == 'debt' or (done and not committed):
            return None
        if committed:
            return .010
        if topic.cancel.is_set():
            return None
        remaining = topic.deadline - monotonic()
        self._check(None, self._cancel)
        # Completion may publish while the clock is sampled; commit outlives setup.
        done = topic.ticket.done
        committed = topic.ticket.committed
        if topic.state == 'debt' or (done and not committed):
            return None
        if committed:
            return .010
        if topic.cancel.is_set():
            return None
        return min(.010, remaining) if remaining > 0 else None

    def _dispatch(self, wire_id, frame):
        self._check(None, self._cancel)
        # The bounded CPython snapshot retains the published generation before waits.
        topic = next((item for item in tuple(self._topics.values()) if item.wire_id == wire_id), None)
        if topic is None:
            return
        registrations = ()
        while True:
            remaining = self._dispatch_remaining(topic)
            if remaining is None:
                return
            if not self._state_lock.acquire(timeout=remaining):
                continue
            try:
                if (self._dispatch_remaining(topic) is None
                        or self._topics.get(topic.name) is not topic or topic.wire_id != wire_id):
                    return
                if topic.ticket.committed and topic.state == 'active':
                    registrations = tuple(item for item in self._registrations
                        if item.topic is topic and item.state == 'active' and item.ticket.committed)
                    break
            finally:
                self._state_lock.release()
            remaining = self._dispatch_remaining(topic)
            if remaining is None:
                return
            time.sleep(remaining)
        for registration in registrations:
            callback_ticket = None
            self._lock(None, self._cancel)
            try:
                if (self._topics.get(topic.name) is topic and topic.state == 'active'
                        and topic.ticket.committed and registration.topic is topic
                        and registration.state == 'active' and registration.ticket.committed
                        and registration in self._registrations):
                    callback_ticket = _Ticket()
                    self._callback = callback_ticket
                    self._callback_thread = threading.get_ident()
            finally:
                self._state_lock.release()
            if callback_ticket is None:
                continue
            try:
                registration.callback(frame[2], registration.identifier)
            except BaseException:
                self._gate = True
                raise self._error('callback') from None
            finally:
                callback_ticket.done = True

    def close(self, deadline):
        if not getattr(self, '_strict', False):
            raise MessengerError('legacy-path')
        _deadline(deadline)
        self._gate = True
        primary, cleanup, retired = None, (), None
        try:
            try:
                self._lower.close_bounded(deadline=deadline)
                self._lower_released = True
            except _LowerError as error:
                self._lower_released = not error.cleanup
                raise MessengerError(error.primary, error.cleanup) from None
            while True:
                self._lock(deadline, self._cancel, passive=True)
                try:
                    self._tickets = [ticket for ticket in self._tickets if not ticket.done]
                    active_callback = self._callback is not None and not self._callback.done
                    if not self._tickets and not active_callback:
                        retired = self._registrations
                        self._registrations = []
                        self._topics = {}
                        self._closed = True
                        self._cleanup = ()
                        break
                    if active_callback and self._callback_thread == threading.get_ident():
                        raise MessengerError('non-quiescent')
                finally:
                    self._state_lock.release()
                time.sleep(self._remaining(deadline, self._cancel, passive=True))
            self._check(deadline, self._cancel, passive=True)
        except MessengerError as error:
            primary, cleanup = error.primary, error.cleanup
        except BaseException:
            primary, cleanup = 'state', ('socket-release',)
        finally:
            retired = None
        if primary is not None:
            raise self._error(primary, cleanup) from None

    def __init__(self, serverAddr, serverPort, credentials, use_ssl = True, amq_login = True, verbose=False, reconnect_attempts_max=20):
        """
        :param serverAddr: Address formatted for stomp of the Activemq broker
        :param serverPort: Address formatted for stomp of the Activemq server port
        :param credentials: Object with structure credentials = {'username':uname, 'password':passwd}
        :param use_ssl: Whether to use SSL (True or False)
        :param amq_login: Whether to log into AMQ (True or False)
        """
        self.connected = False
        self.serverAddr = serverAddr
        self.serverPort = serverPort
        self.credentials = credentials
        self.use_ssl = use_ssl
        self.amq_login = amq_login
        self.reconnect_attempts_max = reconnect_attempts_max

        if (verbose):
            logging.getLogger("stomp.py").setLevel(logging.INFO) # The default appears to be DEBUG which is way too much (it prints out each packet)
        else:
            logging.getLogger("stomp.py").setLevel(logging.ERROR)

        self.establishStompConnection()

    def establishStompConnection(self):
        if getattr(self, '_strict', False):
            raise MessengerError('legacy-path')
        while not self.connected:
            try:
                logging.info("Connecting to %s on port %d" % (self.serverAddr, self.serverPort))
                self.global_stomp_connection = Connection([(self.serverAddr, self.serverPort)], auto_decode = False, reconnect_attempts_max = self.reconnect_attempts_max) #https://stackoverflow.com/questions/46770328/activemq-stompssl-with-python-stomp-client
                if(self.use_ssl):
                    logging.debug("Setting ssl")
                    self.global_stomp_connection.set_ssl(for_hosts=[(self.serverAddr, self.serverPort)], ssl_version = ssl.PROTOCOL_TLS)
                    logging.debug("Done setting ssl")
                else:
                    logging.debug("Not setting SSL. Not CUI Compliant.")
                if(self.amq_login):
                    self.global_stomp_connection.connect(self.credentials['username'], self.credentials['password'], wait=True)
                else:
                    self.global_stomp_connection.connect(wait=True)
                self.global_stomp_listener = Messenger.StompListener(self.global_stomp_connection, auto_reconnect = True, amq_login = self.amq_login, credentials = self.credentials)
                self.global_stomp_connection.set_listener('', self.global_stomp_listener)
                self.connected = True
            except Exception as e:
                logging.info(e)
                logging.warning("Failed to connect to stomp server.  Will try again in 3 seconds...")
                time.sleep(3)
        logging.info("Successfully connected to stomp server.")
        for sub in self.pre_connection_subscriptions:
            logging.info("Subscribing to " + sub[0] + " that was requested before the connection was established.")
            self.subscribe(sub[0], sub[1], sub[2])
        self.pre_connection_subscriptions = []

    def subscribe(self, topic_name, callback, identifier, *, deadline=_MISSING, cancel=_MISSING):
        if getattr(self, '_strict', False):
            return self._run('subscribe', topic_name, callback, identifier, None, deadline, cancel)
        if deadline is not _MISSING or cancel is not _MISSING:
            raise MessengerError('legacy-path')
        if self.global_stomp_listener is not None:
            self.global_stomp_listener.subscribe(topic_name, callback, identifier)
        else:
            logging.warning("Tried to subscribe to " + topic_name + " but the global stomp listener is not initialized...  Will subscribe after initialization.")
            self.pre_connection_subscriptions = self.pre_connection_subscriptions + [(topic_name, callback, identifier)]

    def cancelSubscribe(self, topic_name, callback, identifier, *, deadline=_MISSING, cancel=_MISSING):
        if getattr(self, '_strict', False):
            return self._run('cancel', topic_name, callback, identifier, None, deadline, cancel)
        if deadline is not _MISSING or cancel is not _MISSING:
            raise MessengerError('legacy-path')
        if self.global_stomp_listener is not None:
            self.global_stomp_listener.cancel_subscribe(topic_name, callback, identifier)
        else:
            if (topic_name, callback, identifier) in self.pre_connection_subscriptions:
                self.pre_connection_subscriptions.remove((topic_name, callback, identifier))

    def publish(self, topic_name, protobuf, priority:int = None, *, deadline=_MISSING, cancel=_MISSING):
        if getattr(self, '_strict', False):
            return self._run('publish', topic_name, protobuf, None, priority, deadline, cancel)
        if deadline is not _MISSING or cancel is not _MISSING:
            raise MessengerError('legacy-path')
        if self.global_stomp_connection is not None:
            # check if we got a protobuf, or something else
            serialize_func = getattr(protobuf, "SerializeToString", None)
            if callable(serialize_func):
                msg_body = protobuf.SerializeToString()
            else:# assume it's bytes-likely
                msg_body = protobuf
            
            if priority is not None:
                self.global_stomp_connection.send(body=msg_body, destination=topic_name,  headers={'priority': str(priority)})
            else:
                self.global_stomp_connection.send(body=msg_body, destination=topic_name)
        else:
            logging.error("Tried to publish to " + topic_name + " but the global stomp connection is not initialized...")

    class StompListener(listener.ConnectionListener):
        def __init__(self, conn, auto_reconnect = True, amq_login = True, credentials = None):
            self.conn = conn
            self.auto_reconnect = auto_reconnect
            self.amq_login = amq_login
            self.credentials = credentials
            self.message_handlers = []
            self.subscriptions = {}
            self.subscription_id_counter = 1

        def on_error(self, frame, **kwargs):
            logging.warning('received an error "%s"' % frame)

        def on_send(self, frame):
            pass

        def subscribe(self, topic_name, callback, identifier):
            self.message_handlers += [(topic_name, callback, identifier)]
            if topic_name not in self.subscriptions:
                self.conn.subscribe(topic_name, self.subscription_id_counter)
                self.subscriptions[topic_name] = self.subscription_id_counter
                logging.debug("Subscribing to " + topic_name + " with id "+str(self.subscription_id_counter))
                self.subscription_id_counter += 1

        def cancel_subscribe(self, topic_name, callback, identifier):
            self.message_handlers.remove((topic_name, callback, identifier))
            still_has_topic_name = False
            for (tn, call, ident) in self.message_handlers:
                if tn == topic_name:
                    still_has_topic_name = True
            if not still_has_topic_name:
                self.conn.unsubscribe(destination=topic_name, id=self.subscriptions[topic_name])
                self.subscriptions.pop(topic_name)

        def on_message(self, frame):
            if (frame.headers == None):
                logging.warning("Headers are None.")
            if (frame.body == None):
                logging.warning("Body is None.")
            self.on_message_further(frame.headers, frame.body)

        def on_message_further(self, headers, body):
            fired_callback = False
            for sub in self.message_handlers:
                if sub[0] == headers["destination"]:
                    sub[1](bytes(body), sub[2])
                    fired_callback = True
            if not fired_callback:
                logging.warning("Received a message callback for a topic that I don't have a handler for: " + headers["destination"])

        def on_disconnected(self):
            logging.info("Disconnected from Stomp Server")
            if self.auto_reconnect:
                if(self.amq_login):
                    self.conn.connect(self.credentials['username'], self.credentials['password'], wait=True)
                else:
                    self.conn.connect(wait=True)
                logging.info("Reconnected to Stomp Server")
                for topic_name, subscription_id_counter in self.subscriptions.items():
                    self.conn.subscribe(topic_name, subscription_id_counter)
                    logging.info("Resubscribed to "+topic_name+" with id "+str(subscription_id_counter))
