#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2022 The MITRE Corporation. All Rights Reserved.                #
#############################################################################
from meteor_api.meteor_app_driver import *  
from meteor_api.protobufs import Meteor_pb2 as mpb  
import time
import argparse


class SamplePulses:

    """
    A sample application using the METEOR python driver that does the following:
    Determine radio ID; assign RX frontend to ES application; set radio frontend parameters; subscribe to parameterized
    pulses; start an RX stream; determine the RX stream ID; print received pulses; wait for the user to press enter to
    exit; stop the RX stream
    """

    def __init__(self, credentials_json="", name="", ip_address='127.0.0.1', verbose=False):
        self.meteor_driver = MeteorAppDriver(name, credentials_json=credentials_json, ip_address=ip_address,
                                             verbose=verbose)
        self.radio_id = None
        self.frontend_id = None
        self.rx_stream_id = None
        self.radio_type = None

    def radio_id_cb(self, msg, id):
        # Callback for Radio Status Topic that identifies the radio ID
        status_msg = mpb.RadioStatusMsg()
        status_msg.ParseFromString(msg)
        self.meteor_driver.logger.debug(f"Got radio status message: \n{status_msg}")
        if self.radio_type in status_msg.radio_identifier.lower():
            self.radio_id = status_msg.radio_identifier
            self.frontend_id = status_msg.rx_frontend_statuses[0].name
            self.meteor_driver.logger.info(f"Found {self.radio_type} radio; setting radio_id={self.radio_id}, "
                                           f"frontend_id={self.frontend_id}")
            # Unsubscribe from radio status topic
            self.meteor_driver.cancel_subscribe([RADIO_STATUS_TOPIC], self.radio_id_cb)

    def pulse_cb(self, msg, id):
        pulse_msg = mpb.PulseBatchMsg()
        pulse_msg.ParseFromString(msg)
        for p in pulse_msg.pulses:
            if 2.445E9 < p.center_frequency < 2.455E9:
                print("Pulse:\n{}".format(p))
                print("\nPress enter to exit \n")


if __name__ == "__main__":

    parser = argparse.ArgumentParser("AMQ credentials")
    parser.add_argument("cred_file", help="The METEOR AMQ credentials file for this application")
    parser.add_argument("--ip_addr", default="127.0.0.1", type=str, help="IP Address of the METEOR machine")
    parser.add_argument("--mock", default=False, action="store_true",
                        help="Indicate the user is using a mock radio for the application")
    parser.add_argument("-v", "--verbose", default=False, action="store_true", help="Set logger level to DEBUG")

    args = parser.parse_args()

    # Instantiate application driver
    app_driver = SamplePulses(credentials_json=args.cred_file, name="SamplePulsesApp", ip_address=args.ip_addr,
                              verbose=args.verbose)

    # Determine radio ID
    if args.mock:
        app_driver.radio_type = "mock"
    else:
        app_driver.radio_type = "usrp"
    app_driver.meteor_driver.logger.info(f"Using {app_driver.radio_type.upper()} radio")
    app_driver.meteor_driver.subscribe([RADIO_STATUS_TOPIC], app_driver.radio_id_cb)
    tstart = time.time()
    while app_driver.radio_id is None:
        if time.time() > tstart + 10:
            app_driver.meteor_driver.logger.error(f"No radio of type {app_driver.radio_type} found")
            exit(1)
        time.sleep(0.5)

    # Publish Frontend Assignment to ES app
    app_driver.meteor_driver.assign_frontend(app_driver.radio_id, app_driver.frontend_id, "ES")

    # Set Frontend parameters
    app_driver.meteor_driver.set_frequency(app_driver.radio_id, app_driver.frontend_id, int(2.45E9))
    app_driver.meteor_driver.set_bandwidth(app_driver.radio_id, app_driver.frontend_id, int(160E6))
    app_driver.meteor_driver.set_sample_rate(app_driver.radio_id, app_driver.frontend_id, int(66E6))
    app_driver.meteor_driver.set_gain(app_driver.radio_id, app_driver.frontend_id, 0)

    # Subscribe to Parameterized Pulses
    app_driver.meteor_driver.subscribe([PARAMETERIZED_PULSES], app_driver.pulse_cb)

    # Start RX stream and determine RX Stream ID
    stream_id = app_driver.meteor_driver.start_rx_stream(app_driver.radio_id, app_driver.frontend_id,
                                                         get_stream_id=True)

    # Wait and print pulses until user wants to exit
    _ = input("Press enter to exit \n")

    app_driver.meteor_driver.logger.info("Exiting...")

    # Unsubscribe from parameterized pulses
    app_driver.meteor_driver.cancel_subscribe([PARAMETERIZED_PULSES], app_driver.pulse_cb)

    # Stop RX stream
    if stream_id is not None:
        app_driver.meteor_driver.stop_rx_stream(app_driver.radio_id, stream_id)
    else:
        app_driver.meteor_driver.logger.warning("Unable to stop RX stream")
