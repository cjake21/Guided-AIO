#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2023 The MITRE Corporation. All Rights Reserved.                #
#############################################################################
import logging
import time
import zmq
import numpy as np
import signal
from meteor_api.meteor_app_driver import MeteorAppDriver
from meteor_api.meteor_api_constants import NEW_TX_IQ, RADIO_STATUS_TOPIC
from meteor_api.internal_helpers import timer
import meteor_api.protobufs.Meteor_pb2 as mpb

BATCH_DURATION_SECONDS=0.1

class MeteorZMQSender:
    """
    Sender component of the Python IQ driver for METEOR. Currently only supports single-channel transmit.

    Allows applications to receive raw IQ from a radio connected to METEOR.
    Designed to work in tandem with the METEOR App Driver.


    The METEOR ZMQ Sender is not ready to receive data until a ZeroMQ URI is available. This happens either:
        a. Initially, if provided in the constructor.
        b. After a Radio Status Message is received.

    The user is expected to call ready() and wait for it to return True.
    """
    def __init__(self, driver, radio_id, frontend, sample_rate, bandwidth, iq_description = "", iq_uhd_version = "ZMQ", zmq_uri = None):
        """
        Constructs the ZMQ Sender

        :param driver: An instance of the METEOR App Driver connected to the METEOR system this will use
        :param radio_id: Radio name to send IQ to
        :param frontend: Frontend to send IQ data out of.
        :param sample_rate: Sample rate of the IQ data. DOES NOT CONFIGURE THE RADIO. Just used in the IQ header
        :param bandwidth: Bandwidth of the IQ data. DOES NOT CONFIGURE THE RADIO. Just used in the IQ Header
        :param iq_description: Describe the IQ data. Used in the IQ Header as metadata
        :param iq_uhd_version: Short-description of the IQ Data. Used in the IQ Header as metadata, and as the "Type" on the File table in METEOR
        :param zmq_uri: ZeroMQ URI that the IQ is going to. Will automatically determine it from the radio if not provided (and possible).
        """
        self.logger = logging.getLogger(__name__)
        self.radio_id = radio_id
        self.frontend = frontend
        self.driver = driver
        self.txIqTopic = [self.radio_id, NEW_TX_IQ]
        

        self.iq_header = mpb.IqHeaderMsg() # Template created here and then updated below
        self.iq_header.description = iq_description
        self.iq_header.uhd_version = iq_uhd_version
        self.iq_header.channel_names.extend([frontend])
        #self.iq_header.samples_per_channel = (int)(sample_rate * BATCH_DURATION_SECONDS) # This gets filled in later
        self.iq_header.sampling_frequency = (int)(sample_rate)
        self.iq_header.bandwidth = (int) (bandwidth)
        self.iq_header.batch_num = 0

        self.zmq_context = zmq.Context()
        self.socket = self.zmq_context.socket(zmq.PUSH) # Send with a push socket to a pull socket
        self.zmq_uri = zmq_uri
        self.ready = False # Only can start sending data once a ZMQ URI arrives. If not provided in the constructor (which is most common when working with a radio), wait until it comes from the radio status message. Will change each time the radio driver is restarted.
        if (self.zmq_uri is None):
            self.driver.subscribe([self.radio_id, RADIO_STATUS_TOPIC], self.radio_status_cb)
        else:
            self.connect_to_zmq()

    def __del__(self):
        self.zmq_context.destroy()

    def radio_status_cb(self, msg, id):
        """
        Internal callback used to determine the ZeroMQ Address. Not used if the user provides a ZeroMQ address
        """
        statusMsg = mpb.RadioStatusMsg()
        statusMsg.ParseFromString(msg)
        if (self.zmq_uri is None): # if we weren't given one when the process started
            self.zmq_uri = statusMsg.radio_driver_zeromq_address
            self.connect_to_zmq()

    def connect_to_zmq(self):
        """
        Internal. Used to actually make the ZeroMQ connection
        """
        self.socket.connect(self.zmq_uri) # Connect = client, Bind = server Transmit URL is defiend by the Receiving end - whether it's the receiver or a radio driver. Don't define here.
        self.iq_header.destination_zmq_addresses.extend([self.zmq_uri])
        self.ready = True
        self.logger.warning("ZMQ Connected to socket: {}".format(self.zmq_uri))

    def is_ready(self):
        """
        Returns True if the ZeroMQ Sender is ready to send data.
        """
        return self.ready


    @timer
    def transmit_iq_batch(self, tx_buffer, type, num_samples):
        """
        Sends a batch of IQ data to the radio.
        Sender _MUST_ be ready() and IQ stream should be running. If this is the first batch, will start the IQ stream
        """
        if (not self.is_ready()):
            raise RuntimeError("ZMQ Sender not yet ready")
        #self.logger.debug(f"Sending: {tx_buffer}")
        # Update the IQ header for this batch
        self.iq_header.batch_num = self.iq_header.batch_num + 1
        self.iq_header.iq_format = type
        self.iq_header.samples_per_channel = num_samples
        self.logger.debug(self.txIqTopic)
        if (self.iq_header.batch_num == 1): # First batch, start the stream
            self.driver.start_non_reactive(self.radio_id, self.frontend, "") # No filename because not transmitting from file
        self.driver.publish(self.txIqTopic, self.iq_header)
        msgTracker = self.socket.send(tx_buffer, copy=False, track=True)
        msgTracker.wait(1)
        self.logger.debug("Sent")

def cast_vec_float_to_short(input):
    # From hmi/generate_functions/helpers/save_to_binary.py
    maxScale = np.max([np.max(np.real(input)),np.max(np.imag(input))])
    maxShort = np.iinfo(np.short).max

    I_short = np.array(maxShort*np.real(input)/maxScale,dtype=np.short)
    Q_short = np.array(maxShort*np.imag(input)/maxScale,dtype=np.short)


    return I_short, Q_short

def send_qpsk(zmqSender):
    # QPSK
    a = 1
    phi = 0 #np.pi/2
    samples = np.array([0, 1, 2, 3] * 1, dtype=np.csingle)
    print(samples)
    sig = a*np.exp(1j * (2 * np.pi * samples) / 4)*np.exp(1j*phi) # 4 for qpsk
    print(sig)
    while (not zmqSender.is_ready()):
        time.sleep(0.1)
    # zmqSender.transmit_iq_batch(sig.tobytes())

    print(f"Sending {len(sig)} samples")
    current_sig = sig
    dtype = np.single
    interleaved_signal = np.empty([2*len(current_sig)], dtype=dtype)
    interleaved_signal[::2] = np.real(current_sig).astype(dtype=dtype)
    interleaved_signal[1::2] = np.imag(current_sig).astype(dtype=dtype)
    print(interleaved_signal)
    interleaved_bytes = interleaved_signal.tobytes()
    print(f"Sending {len(interleaved_bytes)} bytes")
    zmqSender.transmit_iq_batch(interleaved_bytes, mpb.IQFormatEnum.eComplexFloat, len(sig))

    short_sig_I, short_sig_Q = cast_vec_float_to_short(current_sig)
    # print(short_sig_I)
    # print(short_sig_Q)
    interleaved_short_signal = np.empty([2*len(current_sig)], dtype=np.short)
    interleaved_short_signal[::2] = short_sig_I
    interleaved_short_signal[1::2] = short_sig_Q
    print(interleaved_short_signal)
    interleaved_short_bytes = interleaved_short_signal.tobytes()
    print(f"Sending {len(interleaved_short_bytes)} bytes")
    zmqSender.transmit_iq_batch(interleaved_short_signal.tobytes(), mpb.IQFormatEnum.eComplexShort, len(sig))

# Python code inspired by LoopRate.cpp in the main METEOR code base
def preciseSleep(frequency, action, zmqSender, file, batchSize):
    delay = 1/frequency
    now = time.time()
    lastSleepExitTime = now
    catchUpTime = 0
    
    while True:
        retVal = action(zmqSender, file, batchSize)
        print(retVal)
        if (not retVal): # If the action returns False, we're done with the periodic action
            break 

        now = time.time()
        print(f"Delay: {delay}, time since last sleep: {now - lastSleepExitTime}, catchup: {catchUpTime}")
        sleepDuration = delay - (now - lastSleepExitTime) - catchUpTime
        if (sleepDuration < 0): # If we're running too slowly
            catchUpTime = -1*sleepDuration # offset to sleep less next time?
        else:
            print(f"Sleeping for {sleepDuration}")
            time.sleep(sleepDuration)

        lastSleepExitTime = time.time()

def sendBatch(zmqSender, file, batchSize):
    batchBytes = (int)(batchSize * 2 * 32 / 8)
    buffer = file.read(batchBytes) # batchSize is samples, 2 samples/sample, floats so 32-bit samples, /8 for bytes
    if (len(buffer) != batchBytes):
       print(f"File over. Length of buffer: {len(buffer)}, batch size (bytes) {batchBytes}")
       return False
    zmqSender.transmit_iq_batch(buffer, mpb.IQFormatEnum.eComplexFloat, batchSize)
    return True

def send_file(zmqSender, filename, sample_rate, loops, batch_duration = 0.1):
    file = open(filename, "rb")
    loopRate = 1/batch_duration
    # 0.1 seconds / loop ==> 10e6 sample/second ==> 10e5 samples/0.1 second
    batchSize = (int)(sample_rate * batch_duration) # 10e5 samples
    logging.info(f"Sample rate {sample_rate}, Batch Duration {batch_duration}, Batch Size {batchSize}")

    while (not zmqSender.is_ready()):
        time.sleep(0.1)
    for i in range(loops):
        preciseSleep(1/batch_duration, sendBatch, zmqSender, file, batchSize)
        file.seek(0)

    driver.stop_non_reactive(radio_id, frontend)


def sigHandler(signum, frame):
    driver.stop_non_reactive(radio_id, frontend)
    exit(1)

if __name__ == '__main__': # For debugging
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    handler.setFormatter(formatter)
    log.addHandler(handler)

    driver = MeteorAppDriver("../../credentials.json", "zmq")

    sample_rate = 5e6
    bandwidth = 1e6
    radio_id = "USRP-323DF53"
    frontend = "B:0-TX"

    signal.signal(signal.SIGINT, sigHandler)
    signal.signal(signal.SIGTERM, sigHandler)

    # zmqSender = MeteorZMQSender("../../credentials.json", "zmq", "TEST", "FRONT", log, sample_rate, bandwidth, "Test IQ", "ZMQ Test", "ipc:///tmp/meteor-zmq-ipc-TEST",)
    zmqSender = MeteorZMQSender(driver, radio_id, frontend, sample_rate, bandwidth, "Test IQ", "ZMQ Test")
    
    #send_qpsk(zmqSender)

    # send_file(zmqSender, "/opt/meteor/ES_Data/new_loopback_am_comb/channel_0.dat", sample_rate, 1000000, 0.01)
    sample_rate = 10e6
    #send_file(zmqSender, "/opt/meteor/ES_Data/new_loopback_am_comb_10MHz/channel_0.dat", sample_rate, 1000000, 0.01)
    #send_file(zmqSender, "/opt/meteor/ES_Data/new_loopback_am_comb_10MHz_no_pulse/channel_0.dat", sample_rate, 1000000, 0.01)
    #send_file(zmqSender, "/home/treiss/meteor/standalone-python-messenger/src/meteor_api/zmq_record_nr_tx_loop_10MHz_from_new_loopback_am_comb_10MHz_no_pulse.dat", sample_rate, 1000000, 0.01)
    send_file(zmqSender, "/home/treiss/meteor/standalone-python-messenger/src/meteor_api/zmq_record_nr_tx_loop_10MHz_from_new_loopback_am_comb_10MHz.dat", sample_rate, 1000000, 0.01)
    
    
