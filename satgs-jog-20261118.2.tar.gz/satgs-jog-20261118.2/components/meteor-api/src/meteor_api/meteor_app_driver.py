#############################################################################
#                                                                           #
# NOTICE                                                                    #
#                                                                           #
# Portions of this software were produced for the U. S. Government under    #
# Contract No. FA8702-19-C-0001 and W56KGU-18-D-0004, and is subject to the #
# Rights in Noncommercial Computer Software and Noncommercial Computer      #
# Software Documentation Clause DFARS 252.227-7014 (FEB 2014)               #
#                                                                           #
# Copyright 2022 The MITRE Corporation. All Rights Reserved.                #
#############################################################################
from .messenger import Messenger
from .meteor_api_constants import *
from .protobufs import Meteor_pb2 as mpb
import logging
import json
import time
import typing


class MeteorAppDriver:
    """
    Python application driver for METEOR
    """

    def __init__(self, name, credentials_json=None, ip_address='127.0.0.1', port=61613, use_ssl=True, amq_login=True,
                 verbose=False, messenger_verbose=False):

        # Set up logger
        self.logger = logging.getLogger(__name__)
        if verbose:
            self.logger.setLevel(logging.DEBUG)
        else:
            self.logger.setLevel(logging.INFO)

        # Connect to METEOR AMQ
        if credentials_json is not None:
            with open(credentials_json) as credentials_file:
                credentials = json.load(credentials_file)
        else:
            if amq_login:
                self.logger.error("Credentials file is required for AMQ login")
                exit(1)
            credentials = None

        self.logger.info("Authenticating to METEOR AMQ")
        self.messenger = Messenger(ip_address, port, credentials, use_ssl, amq_login, messenger_verbose)

        self.name = name

        # Initialize variables used for getting RX stream ID
        self.stream_id_radio = None
        self.stream_id_channels = None
        self.rx_stream_id = None
        # Initialize variables for getting current PDAP parameters and initial parameters for default values
        self.current_pdap_params = None
        self.initial_pdap_params = self.get_current_pdap_params()

    # GENERAL HELPER FUNCTIONS

    def format_topic_name(self, name_list: list):
        """
        Helper function to format an AMQ topic name from a list
        """
        topic_name = TOPIC
        # Check that list is not empty
        if name_list:
            for component in name_list:
                try:
                    topic_name += f"/{component}"
                except TypeError:
                    self.logger.error("ERROR: components in name_list must be strings")
                    return None

            return topic_name
        else:
            self.logger.error("ERROR: name_list must not be empty")
            return None

    def subscribe(self, topic_name: list, callback: typing.Callable[[bytes, str], None]):
        """
        Wrapper to the messenger subscribe that formats the topic name and fills in the object instance's name
        """
        tn = self.format_topic_name(topic_name)
        self.messenger.subscribe(tn, callback, self.name)
        self.logger.debug(f"Subscribed to {tn}")

    def cancel_subscribe(self, topic_name: list, callback: typing.Callable[[bytes, str], None]):
        """
        Wrapper to the messenger cancel-subscribe that formats the topic name, fills in the object instance's name,
        and catches the exception if a user tries to unsubscribe from something they're not subscribed to
        """
        tn = self.format_topic_name(topic_name)
        try:
            self.messenger.cancelSubscribe(tn, callback, self.name)
            self.logger.debug(f"Unsubscribed from {tn}")
        except ValueError:
            self.logger.info(f"Topic {tn} with Callback {callback.__qualname__} is not in current subscriptions list; "
                             f"cannot unsubscribe")

    def publish(self, topic_name: list, protobuf_msg):
        """
        Wrapper to the messenger publish that formats the topic name and fills in the object instance's name
        """
        tn = self.format_topic_name(topic_name)
        self.messenger.publish(tn, protobuf_msg)
        self.logger.debug(f"Published to {tn}")

    # METEOR CONTROL FUNCTIONS

    def set_frequency(self, radio_id, frontend_id, frequency):
        """
        Set the center frequency of a radio frontend

        :param radio_id: Radio name
        :param frontend_id: Frontend name
        :param frequency: Frequency value in Hz (int)
        :return: Nothing
        """
        tune_msg = mpb.TuneMsg()
        tune_msg.center_frequencies.append(frequency)
        self.publish([radio_id, frontend_id, RETUNE_COMMAND], tune_msg)

    def set_bandwidth(self, radio_id, frontend_id, bandwidth):
        """
        Set the bandwidth of a radio frontend

        :param radio_id: Radio name
        :param frontend_id: Frontend name
        :param bandwidth: Bandwidth value in Hz (int)
        :return: Nothing
        """
        longint_msg = mpb.LongIntMsg()
        longint_msg.data = bandwidth
        self.publish([radio_id, frontend_id, SET_BANDWIDTH_COMMAND], longint_msg)

    def set_sample_rate(self, radio_id, frontend_id, sample_rate):
        """
        Set the sample rate of a radio frontend

        :param radio_id: Radio name
        :param frontend_id: Frontend name
        :param sample_rate: Sample rate value in Hz (int)
        :return: Nothing
        """
        longint_msg = mpb.LongIntMsg()
        longint_msg.data = sample_rate
        self.publish([radio_id, frontend_id, SET_STREAM_RATE_COMMAND], longint_msg)

    def set_gain(self, radio_id, frontend_id, gain):
        """
        Set the gain of a radio frontend

        :param radio_id: Radio name
        :param frontend_id: Frontend name
        :param gain: Gain value in dB (float)
        :return: Nothing
        """
        float_msg = mpb.FloatMsg()
        float_msg.data = gain
        self.publish([radio_id, frontend_id, SET_GAIN_COMMAND], float_msg)

    def assign_frontend(self, radio_id, frontend_id, application, frontend_type=None):
        """
        Assign a frontend to an application

        :param radio_id: Radio name
        :param frontend_id: Frontend name
        :param application: Name of the application to assign the frontend to (str)
        :param frontend_type: The type of the frontend being assigned. Leave at default None if frontend follows
                              standard naming to automatically determine the type from the frontend's name; or provide a
                              value of the FrondEndType enum
        :return: Nothing
        """
        assign_msg = mpb.NewFrontEndAssignmentMsg()
        assign_msg.application_name = application
        assign_msg.application_should_use_frontend = True
        if frontend_type is None:
            if "RX" in frontend_id:
                assign_msg.frontend_type = FRONT_END_TYPE_RX
            elif "TX" in frontend_id:
                assign_msg.frontend_type = FRONT_END_TYPE_TX
            elif "Reactive" in frontend_id:
                assign_msg.frontend_type = FRONT_END_TYPE_REACTIVE
            else:
                self.logger.warning("Unable to determine frontend type from frontend id")
                return
        else:
            assign_msg.frontend_type = frontend_type
        assign_msg.frontend_name = f"{radio_id}-{frontend_id}"
        self.publish([FRONTEND_ASSIGNMENT_COMMAND], assign_msg)

    def unassign_frontend(self, radio_id, frontend_id, application, frontend_type=None):
        """
        Unassign a frontend from an application

        :param radio_id: Radio name
        :param frontend_id: Frontend name
        :param application: Name of the application to unassign the frontend from (str)
        :param frontend_type: The type of the frontend being unassigned. Leave at default None if frontend follows
                              standard naming to automatically determine the type from the frontend's name; or provide a
                              value of the FrondEndType enum
        :return: Nothing
        """
        assign_msg = mpb.NewFrontEndAssignmentMsg()
        assign_msg.application_name = application
        assign_msg.application_should_use_frontend = False
        if frontend_type is None:
            if "RX" in frontend_id:
                assign_msg.frontend_type = FRONT_END_TYPE_RX
            elif "TX" in frontend_id:
                assign_msg.frontend_type = FRONT_END_TYPE_TX
            elif "Reactive" in frontend_id:
                assign_msg.frontend_type = FRONT_END_TYPE_REACTIVE
            else:
                self.logger.warning("Unable to determine frontend type from frontend id")
                return
        else:
            assign_msg.frontend_type = frontend_type
        assign_msg.frontend_name = f"{radio_id}-{frontend_id}"
        self.publish([FRONTEND_ASSIGNMENT_COMMAND], assign_msg)

    def start_rx_stream(self, radio_id, frontend_ids, sync_stream_to_pps=True, offset_from_pps=0, phase_locked=None,
                        zmq_addrs=None, get_stream_id=False):
        """
        Start an RX stream

        :param radio_id: Radio name
        :param frontend_ids: Frontend name or list of frontend names
        :param sync_stream_to_pps:
        :param offset_from_pps:
        :param phase_locked:
        :param zmq_addrs:
        :param get_stream_id: If True, will attempt to determine the Stream ID of this RX stream that was just started.
                              Will return the stream ID int if successful, None if not.
                              If False, will simply start the RX stream and return None.
        :return: RX stream ID or None
        """
        # Publish command to start RX stream
        rx_stream_msg = mpb.RxStreamMsg()
        if type(frontend_ids) is list:
            rx_stream_msg.channels.extend(frontend_ids)
        else:
            rx_stream_msg.channels.append(frontend_ids)
        rx_stream_msg.sync_stream_to_pps = sync_stream_to_pps
        rx_stream_msg.offset_from_pps = offset_from_pps
        if phase_locked is not None:
            rx_stream_msg.phase_locked = phase_locked
        if zmq_addrs is not None:
            if type(zmq_addrs) is list:
                rx_stream_msg.iq_destination_zeromq_addresses.extend(zmq_addrs)
            else:
                rx_stream_msg.iq_destination_zeromq_addresses.append(zmq_addrs)
        self.publish([radio_id, START_IQ_RX_COMMAND], rx_stream_msg)
        # Determine the stream ID if desired
        if get_stream_id:
            self.rx_stream_id = None
            self.stream_id_radio = radio_id
            if type(frontend_ids) is list:
                self.stream_id_channels = frontend_ids
            else:
                self.stream_id_channels = [frontend_ids]
            self.subscribe([radio_id, RADIO_STATUS_TOPIC], self.rx_stream_id_cb)
            tstart = time.time()
            while self.rx_stream_id is None:
                # time out after 10 seconds
                if time.time() > tstart + 10:
                    self.logger.warning("Unable to determine RX Stream ID")
                    break
                time.sleep(0.5)
            return self.rx_stream_id
        else:
            return None

    def stop_rx_stream(self, radio_id, stream_id):
        """
        Stop an RX stream

        :param radio_id: Radio name
        :param stream_id: Stream ID of the RX stream to stop
        :return: Nothing
        """
        stream_msg = mpb.StreamMsg()
        stream_msg.stream_id = stream_id
        self.publish([radio_id, STOP_IQ_RX_COMMAND], stream_msg)

    def start_non_reactive(self, radio_id, frontend_ids, filename, loop=True, data_type=IQ_FORMAT_COMPLEX_SHORT,
                           buffer_in_memory=False, sync_stream_to_pps=False, offset_from_pps=0,
                           sync_to_file_metadata=False):
        """
        Start Non-Reactive Jamming (Start a TX Stream)

        :param radio_id: Radio name
        :param frontend_ids: Frontend name or list of frontend names
        :param filename: The name of the IQ data file to transmit
        :param loop: Continuously loop transmitting the file
        :param data_type: The data type of the IQ data in the file; IQFormatEnum enum
        :param buffer_in_memory:
        :param sync_stream_to_pps:
        :param offset_from_pps:
        :param sync_to_file_metadata:
        :return: Nothing
        """
        tx_stream_msg = mpb.TxStreamMsg()
        if type(frontend_ids) is list:
            tx_stream_msg.channels.extend(frontend_ids)
        else:
            tx_stream_msg.channels.append(frontend_ids)
        tx_stream_msg.file_name = filename
        tx_stream_msg.loop_file_transmit = loop
        tx_stream_msg.iq_format = data_type
        tx_stream_msg.buffer_iq_in_memory = buffer_in_memory
        tx_stream_msg.sync_stream_to_pps = sync_stream_to_pps
        tx_stream_msg.offset_from_pps = offset_from_pps
        tx_stream_msg.sync_radio_to_file_metadata = sync_to_file_metadata
        self.publish([radio_id, START_IQ_TX_COMMAND], tx_stream_msg)

    def stop_non_reactive(self, radio_id, frontend_ids=None, stream_id=None):
        """
        Stop Non-Reactive Jamming (Stop a TX Stream)
        This can be done using either frontend ID(s) OR stream ID; only one of these arguments needs to be specified

        :param radio_id: Radio name
        :param frontend_ids: Frontend name or list of frontend names; if used, this must match the frontend ID(s) used
                             to start the non-reactive jamming
        :param stream_id: Stream ID of the TX stream to stop
        :return: Nothing
        """
        stream_msg = mpb.StreamMsg()
        if stream_id is not None:
            stream_msg.stream_id = stream_id
        if frontend_ids is not None:
            if type(frontend_ids) is list:
                stream_msg.channels.extend(frontend_ids)
            else:
                stream_msg.channels.append(frontend_ids)
        if stream_id is None and frontend_ids is None:
            self.logger.warning("Either stream ID or frontend ID must be specified")
            return
        self.publish([radio_id, STOP_IQ_TX_COMMAND], stream_msg)

    def start_reactive(self, radio_id, frontend_id, threat_mode, ff_response_time=100, ff_tx_time=250000,
                       ff_min_power=-100, drfm_cycle_time=80, freq_list_type=None, freq_list=None):
        """
        Start Reactive Jamming

        :param radio_id: Radio name
        :param frontend_id: Frontend name
        :param threat_mode: Reactive jamming mode to use; ThreatModeEnum enum
        :param ff_response_time: Response time of the frequency follower, in us
        :param ff_tx_time: Transmit time of the frequency follower, in us
        :param ff_min_power: Minimum power detection threshold of the frequency follower, in dBm
        :param drfm_cycle_time: Cycle time of the DRFM, in us
        :param freq_list_type: Type to interpret the items in the frequency list as; FrequencyListType enum
        :param freq_list: Frequency ranges to mask or allow; list of FrequencyRange messages
        :return: Nothing
        """
        reactive_msg = mpb.ReactiveJammingMsg()
        reactive_msg.target_frontend_name = frontend_id
        # params type: ReactiveJammingParamsMsg
        reactive_msg.params.threat_mode = threat_mode
        if threat_mode == THREAT_MODE_FREQUENCY_FOLLOWER:
            reactive_msg.params.ff_response_us = ff_response_time
            reactive_msg.params.ff_tx_us = ff_tx_time
            reactive_msg.params.ff_min_power_dbm = ff_min_power
        elif threat_mode == THREAT_MODE_DRFM:
            reactive_msg.params.drfm_cycle_time_us = drfm_cycle_time
        else:
            self.logger.warning(f"Threat mode {threat_mode} is not recognized")
            return
        if freq_list_type is not None:
            reactive_msg.params.frequency_list_type = freq_list_type
        if freq_list is not None:
            reactive_msg.params.frequency_list.extend(freq_list)
        self.publish([radio_id, START_REACTIVE_COMMAND], reactive_msg)

    def stop_reactive(self, radio_id):
        """
        Stop Reactive Jamming

        :param radio_id: Radio name
        :return: Nothing
        """
        cmd_msg = mpb.ActionCommandMsg()
        cmd_msg.command_name = "STOP_REACTIVE_COMMAND"
        cmd_msg.command_says_start = False
        self.publish([radio_id, STOP_REACTIVE_COMMAND], cmd_msg)

    def update_reactive_params(self, radio_id, threat_mode, ff_response_time=100, ff_tx_time=250000, ff_min_power=-100,
                               drfm_cycle_time=80, freq_list_type=None, freq_list=None):
        """
        Update Reactive Jamming Parameters while radio is actively performing reactive jamming
        NOTE: all parameters for the chosen threat mode must be specified, otherwise the currently set parameters will
        be overwritten by the default values.

        :param radio_id: Radio name
        :param threat_mode: Reactive jamming mode to use; ThreatModeEnum enum
        :param ff_response_time: Response time of the frequency follower, in us
        :param ff_tx_time: Transmit time of the frequency follower, in us
        :param ff_min_power: Minimum power detection threshold of the frequency follower, in dBm
        :param drfm_cycle_time: Cycle time of the DRFM, in us
        :param freq_list_type: Type to interpret the items in the frequency list as; FrequencyListType enum
        :param freq_list: Frequency ranges to mask or allow; list of FrequencyRange messages
        :return: Nothing
        """
        params_msg = mpb.ReactiveJammingParamsMsg()
        params_msg.threat_mode = threat_mode
        if threat_mode == THREAT_MODE_FREQUENCY_FOLLOWER:
            params_msg.ff_response_us = ff_response_time
            params_msg.ff_tx_us = ff_tx_time
            params_msg.ff_min_power_dbm = ff_min_power
        elif threat_mode == THREAT_MODE_DRFM:
            params_msg.drfm_cycle_time_us = drfm_cycle_time
        else:
            self.logger.warning(f"Threat mode {threat_mode} is not recognized")
            return
        if freq_list_type is not None:
            params_msg.frequency_list_type = freq_list_type
        if freq_list is not None:
            params_msg.frequency_list = freq_list
        self.publish([radio_id, UPDATE_REACTIVE_PARAMETERS_COMMAND], params_msg)

    def start_recording(self, radio_id, frontend_ids, recording_name, len_seconds=0, len_samples=0, attach_next=False):
        """
        Start an RX Recording of IQ data to a file

        :param radio_id: Radio name
        :param frontend_ids: Frontend name or list of frontend names
        :param recording_name: The name to save the recording as
        :param len_seconds: Specify the maximum duration of the recording in seconds; float. Value of 0 is ignored
        :param len_samples: Specify the maximum duration of the recording in samples; int. Value of 0 is ignored
        :param attach_next: Whether or not to attach the recording to the next start of an RX stream; set to True
                            if you would like the recording to start when the next stream is started.
        :return: Nothing
        """
        rx_recording_msg = mpb.RxRecordingCommandMsg()
        rx_recording_msg.recording_name = recording_name
        if type(frontend_ids) is list:
            rx_recording_msg.channels.extend(frontend_ids)
        else:
            rx_recording_msg.channels.append(frontend_ids)
        # if len_seconds != 0:
        rx_recording_msg.max_recording_duration_seconds = len_seconds
        # if len_samples != 0:
        rx_recording_msg.max_recording_duration_samples = len_samples
        if len_seconds == 0 and len_samples == 0:
            # Do anything? Warning?
            self.logger.info("No recording length is specified")
        rx_recording_msg.attach_to_next_stream = attach_next
        self.publish([radio_id, START_RECORDING_RX_TO_FILE_COMMAND], rx_recording_msg)

    def stop_recording(self, radio_id, frontend_ids=None, stream_id=None):
        """
        Stop the recording of IQ data
        This can be done using either frontend ID(s) OR stream ID; only one of these arguments needs to be specified

        :param radio_id: Radio name
        :param frontend_ids: Frontend name or list of frontend names; if used, this must match the frontend ID(s) used
                             to start the recording
        :param stream_id: The stream ID of the RX stream being used for the recording
        :return: Nothing
        """
        stream_msg = mpb.StreamMsg()
        if stream_id is not None:
            stream_msg.stream_id = stream_id
        if frontend_ids is not None:
            if type(frontend_ids) is list:
                stream_msg.channels.extend(frontend_ids)
            else:
                stream_msg.channels.append(frontend_ids)
        if stream_id is None and frontend_ids is None:
            self.logger.warning("Either stream ID or frontend ID must be specified")
            return
        self.publish([radio_id, STOP_RECORDING_RX_TO_FILE_COMMAND], stream_msg)

    def launch_recording_application(self):
        """
        Launches a new Recording application (tab in the UI)

        :return: Nothing. Currently does not support returning the tab name.
        """
        app_launch_message = mpb.ActionCommandMsg()
        app_launch_message.command_name = START_RECORDING_APPLICATION_COMMAND_NAME
        app_launch_message.command_says_start = True
        self.publish([START_RECORDING_APPLICATION_COMMAND], app_launch_message)
        
    def launch_non_reactive_application(self):
        """
        Launches a new Non Reactive application (tab in the UI).

        :return: Nothing. Currently does not support returning the tab name.
        """
        app_launch_message = mpb.ActionCommandMsg()
        app_launch_message.command_name = START_NON_REACTIVE_APPLICATION_COMMAND_NAME
        app_launch_message.command_says_start = True
        self.publish([START_NON_REACTIVE_APPLICATION_COMMAND], app_launch_message)
        
    def launch_df_calibration_application(self):
        """
        Launches a new DF Calibration application (tab in the UI).

        :return: Nothing. Currently does not support returning the tab name.
        """
        app_launch_message = mpb.ActionCommandMsg()
        app_launch_message.command_name = START_DF_CALIBRATION_TX_APPLICATION_COMMAND_NAME
        app_launch_message.command_says_start = True
        self.publish([START_DF_CALIBRATION_TX_APPLICATION_COMMAND], app_launch_message)

    def get_current_pdap_params(self):
        """
        Determine the current PDAP parameters of the meteor system from the ES system metrics

        :return: current PDAP parameters of system as a full PdapParamsMsg protobuf,
                 or None if parameters are not found in 10 seconds
        """
        self.current_pdap_params = None
        self.subscribe([ES_SYSTEM_METRICS], self.current_pdap_params_cb)

        tstart = time.time()
        while self.current_pdap_params is None:
            # time out after 10 seconds
            if time.time() > tstart + 10:
                self.logger.warning("Unable to get current PDAP parameters")
                break
            time.sleep(0.5)
        return self.current_pdap_params

    def update_pdap_params(self, pdap_params_msg=None, freq_res=None, time_res=None, min_pulse_size=None,
                           intra_fft_smoothing=None, inter_fft_smoothing=None, detect_thresh=None, reject_thresh=None,
                           intra_fft_decimation=None, inter_fft_decimation=None, num_blob_detectors=None,
                           dft_padding_multiplier=None, spectrogram_use_db=None, adaptive_thresh=None,
                           adaptive_thresh_len=None, morph_close_kern=None, morph_open_kern=None, window_type=None,
                           algorithm=None, should_null_center_freq=None, center_freq_null_width=None,
                           percent_threshold=None, cluster_redundancy_enable=None, detection_bounds_simple=None,
                           csv_enable=None):
        """
        Update PDAP Parameters
        Specify either a full set of parameters at once via the pdap_params_msg argument, or targeted individual
        parameters via one or more of the rest of the arguments. The pdap_params_msg full-set method takes priority over
        the individual parameters method.
        If specifying a full set, all parameters should be specified and the argument type must be a fully formed
        PdapParamsMsg protobuf message. All other arguments will be ignored.
        If specifying targeted individual settings, the parameter arguments that are not specified will be filled in
        with default values; the defaults are the values of the parameters at the start of run time, captured during the
        instantiation of this class. For individual arguments, this function currently only exposes the parameters that
        are configurable in the Web UI.

        :param pdap_params_msg: full PDAP params protobuf message (PdapParamsMsg)
        :param freq_res: target frequency resolution, in Hz (float)
        :param time_res: target time resolution, in us (float)
        :param min_pulse_size:
        :param intra_fft_smoothing:
        :param inter_fft_smoothing:
        :param detect_thresh: pulse detection threshold in standard deviations above noise floor (float)
        :param reject_thresh: pulse rejection threshold in standard deviations above noise floor (float)
        :param intra_fft_decimation:
        :param inter_fft_decimation:
        :param num_blob_detectors:
        :param dft_padding_multiplier:
        :param spectrogram_use_db:
        :param adaptive_thresh:
        :param adaptive_thresh_len:
        :param morph_close_kern:
        :param morph_open_kern:
        :param window_type:
        :param algorithm:
        :param should_null_center_freq:
        :param center_freq_null_width:
        :param percent_threshold:
        :param cluster_redundancy_enable:
        :param detection_bounds_simple:
        :param csv_enable:
        :return: Nothing
        """
        if pdap_params_msg is not None:
            params_msg = pdap_params_msg
        else:
            params_msg = mpb.PdapParamsMsg()
            params_msg.target_frequency_resolution = (self.initial_pdap_params.target_frequency_resolution
                                                      if (freq_res is None) else freq_res)
            params_msg.target_time_resolution = (self.initial_pdap_params.target_time_resolution
                                                 if (time_res is None) else time_res)
            params_msg.min_pulse_size = (self.initial_pdap_params.min_pulse_size
                                         if (min_pulse_size is None) else min_pulse_size)
            params_msg.intra_fft_smoothing = (self.initial_pdap_params.intra_fft_smoothing
                                              if (intra_fft_smoothing is None) else intra_fft_smoothing)
            params_msg.inter_fft_smoothing = (self.initial_pdap_params.inter_fft_smoothing
                                              if (inter_fft_smoothing is None) else inter_fft_smoothing)
            params_msg.detect_thresh = (self.initial_pdap_params.detect_thresh
                                        if (detect_thresh is None) else detect_thresh)
            params_msg.reject_thresh = (self.initial_pdap_params.reject_thresh
                                        if (reject_thresh is None) else reject_thresh)
            params_msg.intra_fft_decimation = (self.initial_pdap_params.intra_fft_decimation
                                               if (intra_fft_decimation is None) else intra_fft_decimation)
            params_msg.inter_fft_decimation = (self.initial_pdap_params.inter_fft_decimation
                                               if (inter_fft_decimation is None) else inter_fft_decimation)
            params_msg.num_blob_detectors = (self.initial_pdap_params.num_blob_detectors
                                             if (num_blob_detectors is None) else num_blob_detectors)
            params_msg.dft_padding_multiplier = (self.initial_pdap_params.dft_padding_multiplier
                                                 if (dft_padding_multiplier is None) else dft_padding_multiplier)
            params_msg.spectrogram_use_db = (self.initial_pdap_params.spectrogram_use_db
                                             if (spectrogram_use_db is None) else spectrogram_use_db)
            params_msg.adaptive_thresh = (self.initial_pdap_params.adaptive_thresh
                                          if (adaptive_thresh is None) else adaptive_thresh)
            params_msg.adaptive_thresh_len = (self.initial_pdap_params.adaptive_thresh_len
                                              if (adaptive_thresh_len is None) else adaptive_thresh_len)
            params_msg.morph_close_kern.extend(self.initial_pdap_params.morph_close_kern
                                               if (morph_close_kern is None) else morph_close_kern)
            params_msg.morph_open_kern.extend(self.initial_pdap_params.morph_open_kern
                                              if (morph_open_kern is None) else morph_open_kern)
            params_msg.window_type = (self.initial_pdap_params.window_type if (window_type is None) else window_type)
            params_msg.algorithm_type = (self.initial_pdap_params.algorithm_type if (algorithm is None) else algorithm)
            params_msg.should_null_center_freq = (self.initial_pdap_params.should_null_center_freq
                                                  if (should_null_center_freq is None) else should_null_center_freq)
            params_msg.center_freq_null_width = (self.initial_pdap_params.center_freq_null_width
                                                 if (center_freq_null_width is None) else center_freq_null_width)
            params_msg.percent_threshold = (self.initial_pdap_params.percent_threshold
                                            if (percent_threshold is None) else percent_threshold)
            params_msg.cluster_redundancy_enable = (self.initial_pdap_params.cluster_redundancy_enable if
                                                    (cluster_redundancy_enable is None) else cluster_redundancy_enable)
            params_msg.detection_bounds_simple = (self.initial_pdap_params.detection_bounds_simple
                                                  if (detection_bounds_simple is None) else detection_bounds_simple)
            params_msg.csv_enable = (self.initial_pdap_params.csv_enable if (csv_enable is None) else csv_enable)
        self.publish([UPDATE_PDAP_PARAMS_COMMAND], params_msg)
    
    # CALLBACK FUNCTIONS

    def rx_stream_id_cb(self, msg, id):
        """
        Callback for Radio Status Topic that identifies the RX Stream ID
        """
        status_msg = mpb.RadioStatusMsg()
        status_msg.ParseFromString(msg)
        stream_msg_list = status_msg.rx_streams  # rx_streams type: StreamMsg
        for stream in stream_msg_list:
            if stream.channels == self.stream_id_channels:
                self.rx_stream_id = int(stream.stream_id)
                self.logger.info(f"Found rx_stream_id={self.rx_stream_id}")
                self.cancel_subscribe([self.stream_id_radio, RADIO_STATUS_TOPIC], self.rx_stream_id_cb)

    def current_pdap_params_cb(self, msg, id):
        """
        Callback for ES System Metrics topic that gets the current PDAP parameters
        """
        metrics_msg = mpb.EsSystemMetricsMsg()
        metrics_msg.ParseFromString(msg)
        self.current_pdap_params = metrics_msg.active_pdap_params  # type: PdapParamsMsg
        self.logger.info("Got PDAP Parameters from ES System Metrics Message")
        self.cancel_subscribe([ES_SYSTEM_METRICS], self.current_pdap_params_cb)

