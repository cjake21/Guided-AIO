import logging
import math
from types import MappingProxyType
from google.protobuf.message import DecodeError
import threading
import time
import signal
import argparse
from meteor_api.messenger import Messenger, MessengerError
from dataclasses import fields,asdict, fields
from pixhawk.constants import Topics
from pixhawk import pixhawk_pb2
import yaml
from datetime import datetime, timezone
from pixhawk.pixhawk_msg import FusedMsg, pixhawk_pb2data
import csv
from pathlib import Path

logger = logging.getLogger(__name__)
default_cfg = Path('~/ground_station/config/config.yaml').expanduser()


class PixhawkSubscriber:
    '''
    Records data from the Pixhawk IMU. 
    
    '''
    @classmethod
    def open_pointing(cls, *, messenger, settings, pix_id, log_dir, deadline, cancel):
        if cls is not PixhawkSubscriber:
            raise PixhawkError('admission')
        return _PointingSubscriber._open(messenger, settings, pix_id, log_dir, deadline, cancel)

    def close(self, *, deadline):
        if type(self) is not _PointingSubscriber:
            raise PixhawkError('legacy-path')
        return self._close(deadline)

    def __init__(self, messenger:Messenger, config:Path,  pix_id:int=0,
                 filename:Path=None, standalone:bool = True):
        """Connect to the pixhawk manager and subscribes to pixhawk DATA_MSG topic. 
        If a file path is provided, data messages are logged to the file after calling
        start_logging(). 
        If running standalone, add sig handler to catch control-c and exit clean. 
        Otherwise parent controller is assumed to handle start/ quitting. 

        Args:
            messenger (Messenger): Meteor API messenger
            pixhawk_id (int): which pixhawk ID to subscribe to
            filename (Path): output file, should be .csv extension. 
            standalone (bool, optional): _description_. Defaults to True.
        """
        
        self.started = False
        self.manuallyStopped = False
        self.pix_id = pix_id
        self.lock = threading.Lock()
    
        # Load config File
        with open(config) as f:
            self.config = yaml.safe_load(f)
        pix_ids = []
        pix_dict = {}
        for pix in self.config['pixhawk_sensors']:
            if (pix_id == 0) or (pix_id == pix['id']):
                pix_dict[pix['id']] = pix
                pix_ids.append(pix['id'])
                
        self.pix_dict = pix_dict
        self.pix_ids  = pix_ids
        self.connection_status = {id:False for id in self.pix_ids}
        self._datamsg = FusedMsg(pix_id= self.pix_ids[0], pc_time=datetime.now(timezone.utc))
        
        self.pix_status = {id:FusedMsg(pix_id= id, pc_time=datetime.now(timezone.utc)) for id in self.pix_ids}
    
        self.messenger = messenger
        self.do_logging = False
        if filename is None:
            logger.info("Not logging data")
        else:
            self.do_logging=True
            # Create Log File:
            self.filenames = {}  
            self.csv_files = {}        
            self.csv_writers = {}          
              
            for pix_id in self.pix_ids:
                t_dir = filename.parent
                t_stem = filename.stem
                t_suffix = filename.suffix
                self.filenames[pix_id] = t_dir / "{}_{}{}".format(t_stem, pix_id, t_suffix)
                logger.info("Logging Pix ID {} data to {}".format(pix_id, str(self.filenames[pix_id])))
                self.csv_files[pix_id] = open(self.filenames[pix_id], 'w+')
                col_name = [fld.name for fld in fields(FusedMsg)]
                self.csv_writers[pix_id] = csv.DictWriter(self.csv_files[pix_id], fieldnames=col_name)
                self.csv_writers[pix_id].writeheader()  
        
        # Subscribe to data messages
        for pix_id in self.pix_ids:             
            self.messenger.subscribe("{}_{}".format(Topics.DATA_MSG, pix_id), self.log_msg_cb, "")        
            self.messenger.subscribe("{}_{}".format(Topics.PONG_RESPONSE, pix_id), self.pong_cmd_cb, "")        
                                 
        # Handler to clean exit
        self.standalone = standalone
        if self.standalone:
            signal.signal(signal.SIGINT, self.sig_handler)
            signal.signal(signal.SIGTERM, self.sig_handler)  

    def check_connection(self, timeout:int=5)->bool:
        connection_status = {id:False for id in self.pix_ids}
        for pix_id in self.pix_ids:
            logging.info("Pinging Pix {} Manager, will wait {} seconds for response".format(pix_id, timeout))      
            self.publish_wrapper("{}_{}".format(Topics.PING_CMD, pix_id), pixhawk_pb2.PingCmd(ping=True))
            self.got_pong = False
            start_time = time.time()
            while not self.got_pong:
                if time.time()-start_time>timeout:
                    logging.error("Did not get response from Pix {} in alloted time. Could be issue with activemq, or pixhawk.service on server side".format(pix_id))
                    connection_status[pix_id]=False
                    break
            connection_status[pix_id]=self.got_pong                
        if not (all(connection_status.values())):
            logging.error("Did not get response from all Managers")    
            logging.error("Pong Status: {}".format(connection_status))
        return all(connection_status.values())    
    
    def pong_cmd_cb(self, msg:str, id:int):
        """Call back for when Pong is received
        """             
        logger.info("Pong Received.")      
        self.got_pong = True                
        
    def log_msg_cb(self, msg:str, id)->None:
        """Callback function to log data messages

        Args:
            msg (str): _description_
            id (_type_): _description_
        """
        data_msg=pixhawk_pb2.fused_msg()
        data_msg.ParseFromString(msg)
        # pc_time_utc = datetime.strptime(data_msg.pc_time, time_format_tzone)
        if self.started:
            if self.do_logging:
                self.csv_writers[data_msg.pix_id].writerow(asdict(pixhawk_pb2data(data_msg)))
        self.pix_status[data_msg.pix_id] = data_msg
                
        logger.info("Pix ID: {} {}".format(data_msg.pix_id, data_msg.pc_time))        
        logger.info("{:<11}: R: {:.2f} deg, P: {:.2f} deg, Y: {:.2f} deg".format(
            'RPW',
            data_msg.roll*180/3.14, 
            data_msg.pitch*180/3.14, 
            data_msg.yaw*180/3.14))
        logger.info("{:<10}: FIX_TYPE: {}({}), SVs Vis. {}({}), yaw: {:.1f}({:.1f})".format(
            'RAW GPS', 
            data_msg.gpsStatus, data_msg.gps2Status,
            data_msg.gpsVis, data_msg.gps2Vis,
            data_msg.gpsYaw/100, data_msg.gps2Yaw/100 ))       
        logger.info("{:<10}: Lat: {:.3f}, Lon. {:.3f}, Alt: {:.1f} Heading: {:.1f}".format(
            'POS INT', 
            data_msg.lat, data_msg.lon, data_msg.alt, data_msg.hdg/100
            ))
        # self._datamsg = data_msg
        
    def sig_handler(self, signum, frame):
        '''
        If this is running standalone, ensures we have a clean exit. Intercepts SIGINT and SIGTERM.
        '''
        logger.info("Cntl C, shutting down")
        self.clean_exit()
        exit()

    def start_logging(self):
        '''
        Starts logging in a background thread to enable background logging. record() can be called directly, but will block.
        '''
        if (not self.started):
            self.pixhawkThread = threading.Thread(target=self.run)
            self.pixhawkThread.start()
            self.started = True
            logger.warning("Started recording attitude from Pixhawk")
        else:
            logger.debug("Already logging from pixhawk")
            
    def clean_exit(self):
        '''
        Ensures the connection and CSV file are closed before exiting. Hopefully results in the pixhawk either not needing reset, or being resettable with usbreset.
        '''
        
        self.stopLogging()
        if self.do_logging:
            for id in self.pix_ids:
                logger.info("Closing File for pix {}".format(id))        
                self.csv_files[id].close()
                logger.info("{} Closed".format(str(self.filenames[id])))
        if not self.standalone:
            logger.info("Pixhawk unsubscribing")            
            try:
                for pix_id in self.pix_ids:             
                    self.messenger.cancelSubscribe("{}_{}".format(Topics.DATA_MSG, pix_id), self.log_msg_cb, "")        
                    self.messenger.cancelSubscribe("{}_{}".format(Topics.PONG_RESPONSE, pix_id), self.pong_cmd_cb, "")                    
            except:
                logger.info("Pixhawk already unsubscribed")                                        
                            
    def stopLogging(self):
        '''
        Allows external classes to stop logging. Most useful when logging with duration = 0 (infinite). Thread safe.

        Blocking until the thread stops.
        '''
        logger.info("Stopping Thread")        
        with (self.lock):
            self.manuallyStopped = True
            self.started = False
        if (hasattr(self, "pixhawkThread")):
            self.pixhawkThread.join()            
        logger.info("Thread Stopped")        
            
    def is_manually_stopped(self):
        '''
        Thread-safe check to see if the logger has been stopped with stopLogging
        '''
        with (self.lock):
            return self.manuallyStopped
        
    def publish_wrapper(self, topic, msg):
        '''
        Catches exceptions from publish. Useful if the remote AMQ server restarts (or something like that). The Messenger object handles reconnecting.
        '''
        try:
            self.messenger.publish(topic, msg)
        except Exception as e:
            logger.info("Exception when sending message to Orin's ActiveMQ Broker.", exc_info = e)
    
    def run(self):
        """
        Runs indefinitely until shutdown is received and log file is closed. 
        """
        # Listen for messages
        while self.started:
            time.sleep(1)
            
_POINTING_CODES = ('admission', 'deadline', 'cancelled', 'closed', 'state',
                   'activation', 'logging', 'legacy-path')
_POINTING_DEBT = ('active-operation', 'active-callback', 'registration-debt', 'file-release')
_POINTING_PATH = type(Path())
_POINTING_MAX_BODY = 4096
_POINTING_FLOATS = ('gps_time', 'roll', 'pitch', 'yaw', 'gpsStatus', 'gpsVis',
                   'gpsYaw', 'lat', 'lon', 'alt', 'hdg', 'gps2Status', 'gps2Vis', 'gps2Yaw')


class PixhawkError(Exception):
    def __init__(self, primary, cleanup=()):
        self.primary = primary if primary in _POINTING_CODES else 'state'
        self.cleanup = tuple(item for item in _POINTING_DEBT if item in cleanup)
        Exception.__init__(self, self.primary)


def _pointing_deadline(deadline):
    valid = type(deadline) in (int, float)
    if valid:
        try:
            valid = math.isfinite(deadline)
        except OverflowError:
            valid = False
    if not valid:
        raise PixhawkError('admission')


def _pointing_remaining(deadline, cancel):
    _pointing_deadline(deadline)
    if type(cancel) is not threading.Event:
        raise PixhawkError('admission')
    if cancel.is_set():
        raise PixhawkError('cancelled')
    remaining = deadline - time.monotonic()
    if cancel.is_set():
        raise PixhawkError('cancelled')
    if remaining <= 0:
        raise PixhawkError('deadline')
    return min(.010, remaining)


class _PointingSubscriber(PixhawkSubscriber):
    @classmethod
    def _open(cls, messenger, settings, pix_id, log_dir, deadline, cancel):
        _pointing_remaining(deadline, cancel)
        if (type(pix_id) is not int or not 1 <= pix_id <= 2147483647
                or type(log_dir) is not _POINTING_PATH or not log_dir.is_absolute()
                or len(str(log_dir)) > 4096 or '..' in log_dir.parts
                or type(settings) not in (dict, MappingProxyType)):
            raise PixhawkError('admission')
        rows = settings.get('pixhawk_sensors')
        if type(rows) not in (list, tuple) or len(rows) != 1:
            raise PixhawkError('admission')
        row = rows[0]
        if (type(row) not in (dict, MappingProxyType)
                or type(row.get('id')) is not int or row['id'] != pix_id
                or type(row.get('ptu_id')) is not int
                or not 1 <= row['ptu_id'] <= 2147483647
                or type(messenger) is not Messenger
                or messenger.strict_instance_compatible(settings) is not True):
            raise PixhawkError('admission')
        owner = object.__new__(cls)
        owner.messenger = messenger
        owner.pix_id = pix_id
        owner.pix_ids = (pix_id,)
        owner.pix_dict = {pix_id: {'id': pix_id, 'ptu_id': row['ptu_id']}}
        owner.pix_status = {}
        owner.started = False
        owner.standalone = False
        owner.do_logging = False
        owner._filename = log_dir / ('pixhawk_log_{}.csv'.format(pix_id))
        owner._operation = threading.Lock()
        owner._state = threading.Lock()
        owner._closing = threading.Event()
        owner._pong = threading.Event()
        owner._pong_window = threading.Event()
        owner._fault = None
        owner._closed = False
        owner._connected = False
        owner._activated = False
        owner._registrations = []
        owner._file = None
        owner._writer = None
        owner._rejected = 0
        owner._callbacks = (
            ('{}_{}'.format(Topics.PONG_RESPONSE, pix_id), owner._receive_pong, ''),
            ('{}_{}'.format(Topics.DATA_MSG, pix_id), owner._receive_data, ''),
        )
        _pointing_remaining(deadline, cancel)
        return owner

    def _check(self, deadline, cancel, passive=False):
        remaining = _pointing_remaining(deadline, cancel)
        if not passive:
            if self._closing.is_set():
                raise PixhawkError('closed')
            if self._fault is not None:
                raise PixhawkError(self._fault)
        return remaining

    def _lock(self, lock, deadline, cancel, passive=False):
        while True:
            remaining = self._check(deadline, cancel, passive)
            if lock.acquire(timeout=remaining):
                try:
                    self._check(deadline, cancel, passive)
                except BaseException:
                    lock.release()
                    raise
                return

    def _activate(self, deadline, cancel):
        if self._activated:
            return
        try:
            for registration in self._callbacks:
                self._check(deadline, cancel)
                self._registrations.append(registration)
                self.messenger.subscribe(*registration, deadline=deadline, cancel=cancel)
                self._check(deadline, cancel)
            self._activated = True
        except BaseException:
            if self._registrations:
                self._fault = 'activation'
            raise

    def check_connection(self, *, deadline, cancel):
        self._lock(self._operation, deadline, cancel)
        try:
            self._activate(deadline, cancel)
            self._lock(self._state, deadline, cancel)
            try:
                self._connected = False
                self._pong.clear()
                self._pong_window.set()
            finally:
                self._state.release()
            self._check(deadline, cancel)
            self.messenger.publish('{}_{}'.format(Topics.PING_CMD, self.pix_id),
                pixhawk_pb2.PingCmd(ping=True).SerializeToString(),
                deadline=deadline, cancel=cancel)
            while True:
                remaining = self._check(deadline, cancel)
                if self._pong.is_set():
                    self._connected = True
                    return True
                self._pong.wait(remaining)
        finally:
            self._pong_window.clear()
            self._operation.release()

    def start_logging(self, *, deadline, cancel):
        self._lock(self._operation, deadline, cancel)
        try:
            if not self._connected:
                raise PixhawkError('state')
            self._lock(self._state, deadline, cancel)
            try:
                if self.started:
                    return
                self._check(deadline, cancel)
                try:
                    self._file = open(self._filename, 'x', encoding='utf-8', newline='')
                    self._check(deadline, cancel)
                    self._writer = csv.DictWriter(self._file,
                        fieldnames=[field.name for field in fields(FusedMsg)])
                    self._writer.writeheader()
                    self._check(deadline, cancel)
                    self._file.flush()
                    self._check(deadline, cancel)
                except PixhawkError:
                    raise
                except Exception:
                    self._fault = 'logging'
                    raise PixhawkError('logging') from None
                self.do_logging = True
                self.started = True
            finally:
                self._state.release()
        finally:
            self._operation.release()

    def _reject_message(self):
        self._rejected = min(2147483647, self._rejected + 1)

    def _callback_lock(self):
        if self._closing.is_set() or self._fault is not None:
            return False
        if not self._state.acquire(False):
            self._reject_message()
            return False
        if self._closing.is_set() or self._fault is not None:
            self._state.release()
            return False
        return True

    def _receive_pong(self, body, identifier):
        if not self._callback_lock():
            return
        try:
            if (type(body) is not bytes or len(body) > _POINTING_MAX_BODY
                    or type(identifier) is not str or identifier != ''):
                self._reject_message()
                return
            try:
                message = pixhawk_pb2.PongResponse()
                message.ParseFromString(body)
            except (DecodeError, ValueError):
                self._reject_message()
                return
            if message.pix_id != self.pix_id:
                self._reject_message()
                return
            if not self._closing.is_set() and self._pong_window.is_set():
                self._pong.set()
        finally:
            self._state.release()

    def _receive_data(self, body, identifier):
        if not self._callback_lock():
            return
        try:
            if (type(body) is not bytes or len(body) > _POINTING_MAX_BODY
                    or type(identifier) is not str or identifier != ''):
                self._reject_message()
                return
            try:
                message = pixhawk_pb2.fused_msg()
                message.ParseFromString(body)
                if (message.pix_id != self.pix_id or not 1 <= len(message.pc_time) <= 64
                        or not message.pc_time.endswith(' UTC')
                        or any(not math.isfinite(getattr(message, name))
                               for name in _POINTING_FLOATS)):
                    self._reject_message()
                    return
                row = asdict(pixhawk_pb2data(message))
            except (DecodeError, ValueError, OverflowError):
                self._reject_message()
                return
            if self._closing.is_set():
                return
            self.pix_status[self.pix_id] = message
            if self.started:
                try:
                    self._writer.writerow(row)
                    self._file.flush()
                except Exception:
                    self.started = False
                    self._fault = 'logging'
        finally:
            self._state.release()

    def diagnostics(self):
        return {'closed': self._closed, 'fault': self._fault,
                'rejected_messages': self._rejected,
                'registrations': len(self._registrations),
                'cleanup': self._debt()}

    def _debt(self):
        return tuple(code for code, present in (
            ('active-operation', self._operation.locked()),
            ('active-callback', self._state.locked()),
            ('registration-debt', bool(self._registrations)),
            ('file-release', self._file is not None)) if present)

    def _close(self, deadline):
        _pointing_deadline(deadline)
        self._closing.set()
        self._pong_window.clear()
        self.started = False
        cancel = threading.Event()
        acquired = False
        error = None
        try:
            self._lock(self._operation, deadline, cancel, passive=True)
            acquired = True
            for registration in tuple(self._registrations):
                try:
                    self._check(deadline, cancel, passive=True)
                    self.messenger.cancelSubscribe(*registration, deadline=deadline, cancel=cancel)
                except MessengerError as caught:
                    # These fixed valid inputs make admission the exact-match absence result.
                    if caught.primary != 'admission':
                        if error is None:
                            error = caught
                        continue
                except Exception as caught:
                    if error is None:
                        error = caught
                    continue
                self._registrations.remove(registration)
            self._lock(self._state, deadline, cancel, passive=True)
            try:
                self.started = False
                if self._file is not None:
                    try:
                        self._file.close()
                    except Exception:
                        if error is None:
                            error = PixhawkError('logging')
                    else:
                        self._file = None
                        self._writer = None
                        self.do_logging = False
                self._check(deadline, cancel, passive=True)
                self._closed = not self._registrations and self._file is None
            finally:
                self._state.release()
        except Exception as caught:
            if error is None:
                error = caught
        finally:
            if acquired:
                self._operation.release()
        if error is not None:
            if isinstance(error, PixhawkError):
                raise PixhawkError(error.primary, self._debt()) from None
            raise error

    def _legacy_path(self, *args, **kwargs):
        raise PixhawkError('legacy-path')

    __init__ = _legacy_path
    clean_exit = _legacy_path
    stopLogging = _legacy_path
    run = _legacy_path
    sig_handler = _legacy_path
    publish_wrapper = _legacy_path
    log_msg_cb = _legacy_path
    pong_cmd_cb = _legacy_path
    is_manually_stopped = _legacy_path

def echo():
    parser = argparse.ArgumentParser(
        description = 'Command line script for echoing the Pixhawk status and displaying to console') 
    parser.add_argument('pix_id', nargs='?', default = 0, type=int, 
                        help = ('Which Pixhawk to connect to. 0 = all, default to 0/all'))    
    parser.add_argument("-f","--filename", type=str, default=None, 
                        help="Output Filename")    
    parser.add_argument('-config', default = str(default_cfg), type=str, 
                        help = ('Config File, Defaults to {}.' \
                            'Yaml contains activeMQ connection information'.format(str(default_cfg))))  
    parser.add_argument("-ll", "--loglevel", type=str, default="info" , 
                        help="logging level. default info")  
    args = parser.parse_args()        
    
    main(args)
            
def main(args=None):
    import pixhawk.constants as px_consts
    from pathlib import Path
        
    package_dir = Path(px_consts.__file__).parent 
    if args is None:
        parser = argparse.ArgumentParser(description = 'Remote client for interacting with and logging data from pixhawk')
        parser.add_argument('pix_id', nargs='?', default = 0, type=int, 
                            help = ('Which Pixhawk to connect to. 0 = all, default to 0/all'))            
        parser.add_argument("-f","--filename", type=str, default=None, 
                            help="Output Filename")    
        parser.add_argument('-config', default = str(default_cfg), type=str, 
                            help = ('Config File, Defaults to ~/ground_station/config.yaml.' \
                                'Yaml contains activeMQ connection information'))  
        parser.add_argument("-ll", "--loglevel", type=str, default="info" , 
                            help="logging level. default info")  
        args = parser.parse_args()        
           

    logging_level = logging.INFO # Will change to WARN later
    log = logging.getLogger()
    log.setLevel(logging_level) # the logging instance must be set to the lowest level of all streams    
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    handler.setFormatter(formatter)
    log.addHandler(handler)

    # Load config File
    with open(args.config) as f:
        config = yaml.safe_load(f)             
    credentials = {
                "username": config["amq_username"], 
                "password": config["amq_password"]}    
    messenger = Messenger(config['amq_server'], config['amq_port'], credentials, use_ssl=config['amq_use_ssl'])
    if args.filename is None:
        pixhawk = PixhawkSubscriber(messenger=messenger, config=args.config, pix_id=args.pix_id, standalone=True)        
    else:
        pixhawk = PixhawkSubscriber(messenger=messenger, config=args.config, pix_id=args.pix_id, filename=Path(args.filename), standalone=True)
    pixhawk.check_connection()
    
    pixhawk.start_logging()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print('!!FINISH!!')
        pixhawk.stopLogging()    
            
if __name__ == '__main__':
    main()

