from dataclasses import dataclass
from pixhawk import pixhawk_pb2
from typing import Optional
from datetime import datetime, timezone
from pixhawk.constants import time_format_tzone

@dataclass
class FusedMsg:
    """
    Args:
        pc_time (datetime)
        roll (float): Radians, Defaults to 0 
        pitch (float): Radians, Defaults to 0 
        yaw (float): Radians, Defaults to 0 
        gps_time (float): Obsolete. Defaults to 0   
        gpsStatus (float): Fix Type. Defaults to 0 
        gpsVis (float): Num of SVs visible, Defaults to 0 
        gpsYaw (float): radians, Defaults to 0 
        gps2Status (float): Fix Type. Defaults to 0 
        gps2Vis (float): Num of SVs visible. Defaults to 0 
        gps2Yaw (float): radians. Defaults to 0 
        lat (float): Deg WGS84, EGM96 ellipsoid. Defaults to 0 
        lon (float): Deg WGS84, EGM96 ellipsoid. Defaults to 0 
        alt (float): Meters MSL. Defaults to 0 
        hdg (float): Degrees*100. Defaults to 0 
    """

    pc_time:datetime
    pix_id:int
    roll:float=0
    pitch:float=0
    yaw:float=0  

    gps_time: Optional[float]=0  

    gpsStatus: Optional[float]=0
    gpsVis: Optional[float]=0
    gpsYaw: Optional[float]=0

    gps2Status: Optional[float]=0
    gps2Vis: Optional[float]=0
    gps2Yaw: Optional[float]=0

    lat: Optional[float]=0
    lon: Optional[float]=0
    alt: Optional[float]=0
    hdg: Optional[float]=0    
    
    def to_pb(self):
        return pixhawk_pb2.fused_msg(
            pc_time=self.pc_time.strftime(time_format_tzone), pix_id = self.pix_id, gps_time=self.gps_time,            
            roll=self.roll, pitch=self.pitch, yaw=self.yaw,
            gpsStatus=self.gpsStatus, gpsVis=self.gpsVis, gpsYaw=self.gpsYaw,
            lat=self.lat, lon=self.lon, alt=self.alt, hdg=self.hdg, 
            gps2Status=self.gps2Status, gps2Vis=self.gps2Vis, gps2Yaw=self.gps2Yaw,
        )
        
def pixhawk_pb2data(pb:pixhawk_pb2)->FusedMsg:
    
    return FusedMsg(
        datetime.strptime(pb.pc_time, time_format_tzone).replace(tzinfo=timezone.utc), 
        pix_id=pb.pix_id,
        roll=pb.roll, pitch=pb.pitch, yaw= pb.yaw,
        gps_time = pb.gps_time, hdg=pb.hdg,
        gpsStatus=pb.gpsStatus, gpsVis=pb.gpsVis, gpsYaw=pb.gpsYaw,
        lat=pb.lat, lon=pb.lon, alt=pb.alt,
        gps2Status=pb.gps2Status, gps2Vis=pb.gps2Vis, gps2Yaw=pb.gps2Yaw,
        )
