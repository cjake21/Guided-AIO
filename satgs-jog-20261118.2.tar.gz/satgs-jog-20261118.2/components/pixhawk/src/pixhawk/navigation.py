"""Pure checks for explicitly qualified, normalized navigation observations.

The caller owns source qualification and must provide sensor ages at receipt.
Receipt time and the legacy fused message cannot establish those ages.
"""

import math
from dataclasses import dataclass
from typing import FrozenSet, Optional, Tuple


@dataclass(frozen=True)
class NavigationBinding:
    pixhawk_id: int
    ptu_id: int
    source_contract_id: str
    source_session_id: str
    time_basis_id: str
    heading_reference: str
    position_frame: str
    attitude_frame: str
    altitude_datum: str
    calibration_id: str


@dataclass(frozen=True)
class NavigationPolicy:
    binding: NavigationBinding
    max_receipt_age_seconds: float
    max_sensor_age_seconds: float
    max_component_skew_seconds: float
    accepted_primary_fix_types: FrozenSet[int]
    accepted_secondary_fix_types: FrozenSet[int]
    accepted_heading_states: FrozenSet[str]


@dataclass(frozen=True)
class NavigationObservation:
    binding: NavigationBinding
    generation: int
    received_monotonic: float
    attitude_age_at_receipt_seconds: Optional[float]
    primary_gps_age_at_receipt_seconds: Optional[float]
    secondary_gps_age_at_receipt_seconds: Optional[float]
    position_age_at_receipt_seconds: Optional[float]
    heading_age_at_receipt_seconds: Optional[float]
    attitude_age_uncertainty_seconds: Optional[float]
    primary_gps_age_uncertainty_seconds: Optional[float]
    secondary_gps_age_uncertainty_seconds: Optional[float]
    position_age_uncertainty_seconds: Optional[float]
    heading_age_uncertainty_seconds: Optional[float]
    primary_fix_type: Optional[int]
    secondary_fix_type: Optional[int]
    heading_state: Optional[str]
    heading_degrees: Optional[float]
    roll_radians: Optional[float]
    pitch_radians: Optional[float]
    yaw_radians: Optional[float]
    latitude_degrees: Optional[float]
    longitude_degrees: Optional[float]
    altitude_metres: Optional[float]


@dataclass(frozen=True)
class NavigationDecision:
    reasons: Tuple[str, ...]

    @property
    def admitted(self) -> bool:
        return not self.reasons


_REASONS = (
    'policy-required', 'invalid-policy', 'invalid-request',
    'observation-required', 'invalid-observation', 'identity-mismatch',
    'source-mismatch', 'time-basis-mismatch', 'frame-mismatch', 'calibration-mismatch',
    'generation-mismatch', 'missing-data', 'invalid-data', 'invalid-time',
    'invalid-fix', 'invalid-heading', 'receipt-stale', 'sensor-stale',
    'component-skew',
)
_SOURCE_FIELDS = ('source_contract_id', 'source_session_id')
_FRAME_FIELDS = ('heading_reference', 'position_frame', 'attitude_frame', 'altitude_datum')
_TOKEN_FIELDS = _SOURCE_FIELDS + _FRAME_FIELDS + ('time_basis_id', 'calibration_id')
_AGE_FIELDS = (
    'attitude_age_at_receipt_seconds', 'primary_gps_age_at_receipt_seconds',
    'secondary_gps_age_at_receipt_seconds', 'position_age_at_receipt_seconds',
    'heading_age_at_receipt_seconds',
)
_VALUE_FIELDS = (
    'heading_degrees', 'roll_radians', 'pitch_radians', 'yaw_radians',
    'latitude_degrees', 'longitude_degrees', 'altitude_metres',
)
_UNCERTAINTY_FIELDS = (
    'attitude_age_uncertainty_seconds', 'primary_gps_age_uncertainty_seconds',
    'secondary_gps_age_uncertainty_seconds', 'position_age_uncertainty_seconds',
    'heading_age_uncertainty_seconds',
)


def _finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _token(value):
    return (type(value) is str and 1 <= len(value) <= 128 and value.isascii()
            and all(character.isalnum() or character in '-._:/' for character in value))


def _binding_valid(binding):
    return (type(binding) is NavigationBinding
            and all(type(value) is int and 1 <= value <= 2147483647
                    for value in (binding.pixhawk_id, binding.ptu_id))
            and all(_token(getattr(binding, name)) for name in _TOKEN_FIELDS))


def _fix_set_valid(values):
    return (type(values) is frozenset and 1 <= len(values) <= 256
            and all(type(value) is int and 0 <= value <= 255 for value in values))


def _policy_valid(policy):
    if type(policy) is not NavigationPolicy or not _binding_valid(policy.binding):
        return False
    limits = (policy.max_receipt_age_seconds, policy.max_sensor_age_seconds,
              policy.max_component_skew_seconds)
    return (all(_finite(value) and value > 0 for value in limits)
            and _fix_set_valid(policy.accepted_primary_fix_types)
            and _fix_set_valid(policy.accepted_secondary_fix_types)
            and type(policy.accepted_heading_states) is frozenset
            and 1 <= len(policy.accepted_heading_states) <= 256
            and all(_token(value) for value in policy.accepted_heading_states))


def _decision(reasons):
    return NavigationDecision(tuple(reason for reason in _REASONS if reason in reasons))


def evaluate_navigation(policy: Optional[NavigationPolicy],
                        observation: Optional[NavigationObservation], *,
                        expected_generation: int,
                        now_monotonic: float) -> NavigationDecision:
    """Evaluate supplied evidence, without qualifying its source or authorizing motion.

    Age intervals must cover acquisition-to-receipt delay and timing uncertainty
    in the bound common time basis. Freshness and skew equality reject.
    """
    if policy is None:
        return _decision(('policy-required',))
    if not _policy_valid(policy):
        return _decision(('invalid-policy',))
    if (type(expected_generation) is not int or expected_generation < 1
            or not _finite(now_monotonic)):
        return _decision(('invalid-request',))
    if observation is None:
        return _decision(('observation-required',))
    if (type(observation) is not NavigationObservation
            or not _binding_valid(observation.binding)
            or type(observation.generation) is not int or observation.generation < 1):
        return _decision(('invalid-observation',))

    reasons = set()
    binding = observation.binding
    if (binding.pixhawk_id, binding.ptu_id) != (policy.binding.pixhawk_id, policy.binding.ptu_id):
        reasons.add('identity-mismatch')
    if any(getattr(binding, name) != getattr(policy.binding, name) for name in _SOURCE_FIELDS):
        reasons.add('source-mismatch')
    if binding.time_basis_id != policy.binding.time_basis_id:
        reasons.add('time-basis-mismatch')
    if any(getattr(binding, name) != getattr(policy.binding, name) for name in _FRAME_FIELDS):
        reasons.add('frame-mismatch')
    if binding.calibration_id != policy.binding.calibration_id:
        reasons.add('calibration-mismatch')
    if observation.generation != expected_generation:
        reasons.add('generation-mismatch')

    ages = tuple(getattr(observation, name) for name in _AGE_FIELDS)
    uncertainties = tuple(getattr(observation, name) for name in _UNCERTAINTY_FIELDS)
    values = tuple(getattr(observation, name) for name in _VALUE_FIELDS)
    required = ages + uncertainties + values + (observation.received_monotonic,
        observation.primary_fix_type, observation.secondary_fix_type, observation.heading_state)
    if any(value is None for value in required):
        reasons.add('missing-data')
        return _decision(reasons)

    if (not all(_finite(value) for value in values)
            or not 0 <= observation.heading_degrees < 360
            or not -90 <= observation.latitude_degrees <= 90
            or not -180 <= observation.longitude_degrees <= 180):
        reasons.add('invalid-data')
    if (type(observation.primary_fix_type) is not int
            or type(observation.secondary_fix_type) is not int
            or observation.primary_fix_type not in policy.accepted_primary_fix_types
            or observation.secondary_fix_type not in policy.accepted_secondary_fix_types):
        reasons.add('invalid-fix')
    if (not _token(observation.heading_state)
            or observation.heading_state not in policy.accepted_heading_states):
        reasons.add('invalid-heading')

    if (not _finite(observation.received_monotonic)
            or not all(_finite(value) and value >= 0 for value in ages + uncertainties)):
        reasons.add('invalid-time')
        return _decision(reasons)
    lower_ages = tuple(max(0, age - uncertainty) for age, uncertainty in zip(ages, uncertainties))
    upper_ages = tuple(age + uncertainty for age, uncertainty in zip(ages, uncertainties))
    if not all(_finite(value) for value in upper_ages):
        reasons.add('invalid-time')
        return _decision(reasons)
    receipt_age = now_monotonic - observation.received_monotonic
    if not _finite(receipt_age) or receipt_age < 0:
        reasons.add('invalid-time')
        return _decision(reasons)
    if receipt_age >= policy.max_receipt_age_seconds:
        reasons.add('receipt-stale')
    sensor_ages = tuple(age + receipt_age for age in upper_ages)
    if any(not _finite(age) or age >= policy.max_sensor_age_seconds for age in sensor_ages):
        reasons.add('sensor-stale')
    worst_case_skew = max(upper - lower
        for upper_index, upper in enumerate(upper_ages)
        for lower_index, lower in enumerate(lower_ages) if upper_index != lower_index)
    if worst_case_skew >= policy.max_component_skew_seconds:
        reasons.add('component-skew')
    return _decision(reasons)
