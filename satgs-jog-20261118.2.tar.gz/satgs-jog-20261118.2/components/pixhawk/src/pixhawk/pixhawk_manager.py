import logging
import threading
import time
import serial
from datetime import datetime, timezone
import signal
from pymavlink import mavutil
import argparse
from meteor_api.messenger import Messenger
from dataclasses import dataclass
from pixhawk.constants import Topics, PxMsg
from pixhawk import pixhawk_pb2
import json
import yaml
import numpy as np
from pixhawk.pixhawk_msg import FusedMsg, pixhawk_pb2data
from pathlib import Path
from pixhawk.constants import time_format_tzone

default_cfg = Path('~/ground_station/config/config.yaml').expanduser()

class PixhawkManager:
    """
    Records data from the Pixhawk IMU. Messages are published to activeMQ broker. 
    
    """
    
    def __init__(self, pixhawk_port:str, baud:int, messenger:Messenger, pix_id:int,
                 debug:bool = False, standalone:bool = True, logger = None,
                 simulate_hw:bool=False):
        """Constructor
        Opens the connection for five seconds and listens for messages that should come 1x/second. 
        If standalone, handles signals (SIGINT/SIGTERM) internally. If not, assumes that the wrapper 
        will handle the signals, and call clean_exit() in the signal handler BEFORE exiting.        

        Args:
            pixhawk_port (str): Usually /dev/ttyAMC0
            baud (int): Usually 115200
            messenger (Messenger): METEOR Api Messenger
            debug (bool, optional): _description_. Defaults to False.
            standalone (bool, optional): _description_. Defaults to True.
            logger (_type_, optional): _description_. Defaults to None.
            simulate_hw (bool): If True, HW is simulated. Used for test modes 
                when HW is unavailable            
        """
        self.debug = debug
        self.started = False
        self.manuallyStopped = False
        self.lock = threading.Lock()
        self._datamsg = None
        self.pix_id = pix_id
        self.messenger = messenger
        self.simulate_hw = simulate_hw        
        
        # Listen for rate change configurations
        # self.messenger.subscribe(Topics.CFG_RATE, self.change_rate_cb, "")                       

        if (standalone):
            signal.signal(signal.SIGINT, self.sig_handler)
            signal.signal(signal.SIGTERM, self.sig_handler)
        
        if self.simulate_hw:
            logging.warning("Running in test mode! HW is simulated!")
            self.template_msg = FusedMsg(
                            pc_time=datetime.now(timezone.utc),                
                            roll= 0,
                            pitch = 0,
                            gps2Status= 4,
                            gps2Vis= 28,
                            gps2Yaw= 0,
                            gpsStatus= 6,
                            gpsVis= 28,
                            lat=  42.505680084228516, 
                            lon= -71.23587036, 
                            alt= 19,
                            pix_id=self.pix_id)            
        else:
            logging.info("Connecting to Pixhawk")
            self.connection = mavutil.mavlink_connection(pixhawk_port, baud=baud, autoreconnect=True) # returns a mavfile
            self.connection.set_rtscts(False) # The USB Serial cable does NOT have RTS/CTS connected
            logging.info("Connected opened")
        
            # Disable all messages
            # self.disable_all_msgs()
            # self.request_message_interval(msg=PxMsg.TERRAIN_REPORT, frequencyHz=-1)
                        
            self.request_message_interval(msg=PxMsg.ATTITUDE, frequencyHz=1)
            self.request_message_interval(msg=PxMsg.GPS_RAW_INT, frequencyHz=1)
            self.request_message_interval(msg=PxMsg.GPS2_RAW, frequencyHz=1)              
            self.request_message_interval(msg=PxMsg.GLOBAL_POSITION_INT, frequencyHz=1)   
            
        self.messenger.subscribe("{}_0".format(Topics.PING_CMD), self.ping_cmd_cb, "")
        self.messenger.subscribe("{}_{}".format(Topics.PING_CMD, self.pix_id), self.ping_cmd_cb, "")
        

        
    def ping_cmd_cb(self, msg:str, id:int):
        """Call back for when Ping is received

        Args:
            msg (str): 
            id (int): 
        """             
        logging.info("Ping Received.")      
        logging.info("Pix ID {} Sending Pong Response".format(self.pix_id))
        self.publish_wrapper("{}_{}".format(Topics.PONG_RESPONSE, self.pix_id), pixhawk_pb2.PongResponse(pix_id=self.pix_id))               

    def disable_all_msgs(self):
        for msg in PxMsg:
            logging.info("Disabling {} ID {}".format(msg.name, msg.value))
            self.request_message_interval(msg, frequencyHz=-1)         
            time.sleep(0.1)               

    def sig_handler(self, signum, frame):
        '''
        If this is running standalone, ensures we have a clean exit. Intercepts SIGINT and SIGTERM.
        '''
        logging.info("Control-C detected")
        self.clean_exit()
        exit()

    def clean_exit(self):
        '''
        Ensures the connection and CSV file are closed before exiting. 
        '''
        self.stop_logging()
        if (hasattr(self, 'connection')): # this could get called before the connection exists if it takes a while.
            self.connection.close()
        logging.info("Closed connection. Exiting")


    def stop_logging(self):
        '''
        Allows external classes to stop logging. Most useful when logging with duration = 0 (infinite). Thread safe.

        Blocking until the thread stops.
        '''
        with (self.lock):
            self.manuallyStopped = True
            self.started = False
        if (hasattr(self, "pixhawkThread")):
            self.pixhawkThread.join()
            
    def is_manually_stopped(self):
        '''
        Thread-safe check to see if the logger has been stopped with stop_logging
        '''
        with (self.lock):
            return self.manuallyStopped
        
    def start_logging(self):
        '''
        Starts logging in a background thread to enable background logging. record() can be called directly, but will block.
        '''
        if (not self.started):
            self.pixhawkThread = threading.Thread(target=self.run)
            self.pixhawkThread.start()
            self.started = True
            logging.warning("Started recording attitude from Pixhawk")
        else:
            logging.debug("Already logging from pixhawk")

    def request_message_interval(self, msg:PxMsg, frequencyHz: float):
        """
        Request MAVLink message in a desired frequency,
        documentation for SET_MESSAGE_INTERVAL:
            https://mavlink.io/en/messages/common.html#MAV_CMD_SET_MESSAGE_INTERVAL

        Args:
            msgId (int): MAVLink message ID
            frequencyHz (float): Desired frequency in Hz
        """
        if frequencyHz<0:
            interval = -1
        else:
            interval = 1e6 / frequencyHz   
        logging.info("Requesting msg {}, ID {} at rate of {} Hz".format(msg.name, msg.value, frequencyHz))
        self.connection.mav.command_long_send(
            self.connection.target_system,
            self.connection.target_component,
            mavutil.mavlink.MAV_CMD_SET_MESSAGE_INTERVAL,
            0,
            msg.value, # The MAVLink message ID
            interval, # The interval between two messages in microseconds. Set to -1 to disable and 0 to request default rate.
            0, 0, 0, 0, # Unused parameters
            0, # Target address of message stream (if message has target address fields). 0: Flight-stack default (recommended), 1: address of requestor, 2: broadcast.
        )
        
    def publish_wrapper(self, topic, msg):
        '''
        Catches exceptions from publish. Useful if the remote AMQ server restarts (or something like that). The Messenger object handles reconnecting.
        '''
        try:
            self.messenger.publish(topic, msg)
        except Exception as e:
            logging.info("Exception when sending message to Orin's ActiveMQ Broker.", exc_info = e)
                
    def publish_msg(self):
        try:
            self.publish_wrapper("{}_{}".format(Topics.DATA_MSG, self.pix_id), msg=self._datamsg.to_pb())
            logging.info("Published MSG")
        except:
            logging.warning("Incomplete Message")
                
    def run(self):
        """
        Runs forever until logger is shutdown. 
        """
        dummy_az = 0 
        dummy_el = 0
        while True:
            if self.simulate_hw:
                dummy_az = ((dummy_az+3) % 360)
                dummy_el = 90*(np.sin(dummy_az/90)+1)/2
                self.template_msg.pc_time=datetime.now(timezone.utc)
                
                self.template_msg.pitch= dummy_el*(np.pi/180)
                self.template_msg.yaw = dummy_az*(np.pi/180)
                self.template_msg.gps2Yaw= dummy_az*(np.pi/180)
                self.template_msg.hdg= (dummy_az)*100
                self._datamsg = self.template_msg
                logging.info("Simulated HW {:<15}: Pix ID: {} {}".format('', self._datamsg.pix_id, self.template_msg.pc_time))
                logging.info("Simulated HW {:<15}: R: {:.2f} deg, P: {:.2f} deg, Y: {:.2f} deg".format(
                    'RPW',
                    self._datamsg.roll*(180/np.pi), 
                    self._datamsg.pitch*(180/np.pi), 
                    self._datamsg.yaw*(180/np.pi) ))       
                logging.info("Simulated HW {:<15}: Lat: {:.3f}, Lon {:.3f}, Alt: {:.1f}, Hdg {:.2f}".format(
                    'Fused Pos', 
                    self._datamsg.lat, 
                    self._datamsg.lon,
                    self._datamsg.alt, 
                    self._datamsg.hdg/100,))                                                 
                self.publish_msg()
                time.sleep(1)
                continue
            
            try:
                nextMessage = self.connection.recv_msg(); # Receives the next message
                if (nextMessage != None ):                        
                    if (nextMessage.get_type() == "ATTITUDE"):
                        self.publish_msg()
                        self._datamsg = FusedMsg(
                            pc_time=datetime.now(timezone.utc),
                            pix_id=self.pix_id,
                            roll= nextMessage.format_attr("roll"),
                            pitch = nextMessage.format_attr("pitch"),
                            yaw = nextMessage.format_attr("yaw"),
                            )
                        logging.info("UTC TIME: {}".format(self._datamsg.pc_time.strftime(time_format_tzone)))
                        
                        logging.info("{:<15}: R: {:.2f} deg, P: {:.2f} deg, Y: {:.2f} deg".format(
                            'RPW',
                            nextMessage.format_attr("roll")*180/3.14, 
                            nextMessage.format_attr("pitch")*180/3.14, 
                            nextMessage.format_attr("yaw")*180/3.14 ))                             
                        continue
                    
                    if (nextMessage.get_type() == "GPS2_RAW"):
                        if self._datamsg is not None:
                            self._datamsg.gps2Status= nextMessage.format_attr("fix_type")
                            self._datamsg.gps2Vis= nextMessage.format_attr("satellites_visible")
                            self._datamsg.gps2Yaw= nextMessage.format_attr("yaw")  
                            logging.info("{:<15}: FIX_TYPE: {}, SVs Vis. {}, yaw: {}".format(
                                'GPS 2 RAW', 
                                nextMessage.format_attr("fix_type"), 
                                nextMessage.format_attr("satellites_visible"),
                                nextMessage.format_attr("yaw")/100 , ))                                                                    
                        continue
                                    
                    if (nextMessage.get_type() == "GPS_RAW_INT"):
                        if self._datamsg is not None:
                            self._datamsg.gpsStatus= nextMessage.format_attr("fix_type")
                            self._datamsg.gpsVis= nextMessage.format_attr("satellites_visible")
                            self._datamsg.gpsYaw= nextMessage.format_attr("yaw")                             
                            logging.info("{:<15}: FIX_TYPE: {}, SVs Vis. {}, yaw: {}".format(
                                'RAW GPS', 
                                self._datamsg.gpsStatus, 
                                self._datamsg.gpsVis,
                                self._datamsg.gpsYaw/100 , ))
                            
                            self._datamsg.lat = nextMessage.format_attr("lat")*1e-7
                            self._datamsg.lon = nextMessage.format_attr("lon")*1e-7
                            self._datamsg.alt = nextMessage.format_attr("alt")*1e-3                        
                            logging.info("{:<15}: Lat: {:.3f}, Lon {:.3f}, Alt: {:.1f}".format(
                                'RAW GPS LLA', 
                                self._datamsg.lat, 
                                self._datamsg.lon,
                                self._datamsg.alt, ))                                                                                        
                        continue 
                    
                    if (nextMessage.get_type() == "GLOBAL_POSITION_INT"):
                        if self._datamsg is not None:
                            self._datamsg.lat= nextMessage.format_attr("lat")*1e-7
                            self._datamsg.lon= nextMessage.format_attr("lon")*1e-7
                            self._datamsg.alt= nextMessage.format_attr("alt") *1e-3
                            self._datamsg.hdg= nextMessage.format_attr("hdg") 
                                                        
                            logging.info("{:<15}: Lat: {:.3f}, Lon {:.3f}, Alt: {:.1f}, Hdg {:.2f}".format(
                                'Fused Pos', 
                                self._datamsg.lat, 
                                self._datamsg.lon,
                                self._datamsg.alt, 
                                self._datamsg.hdg/100,))                        
                    else:
                        logging.debug("Other Messages {}, ID {}".format(nextMessage.get_type(), nextMessage.id))                                
                        
            except serial.serialutil.PortNotOpenError as e:
                logging.exception("Port not open")
                exit(1)
            except Exception as e:
                logging.exception(e)
            time.sleep(0.001)
            # now = time.time()
            
def main():
    import pixhawk
    from pathlib import Path
        
    package_dir = Path(pixhawk.__file__).parent
        
    parser = argparse.ArgumentParser(description = 'PixHawk Manager for the Cubesat Mission')
    parser.add_argument('--pix-id', type = int, required = True, 
                        help='ID of pixhawk unit')
    parser.add_argument('-p','--port', type = str, required = True, 
                        help='Serial port of the pixhawk, usually /dev/ttyAMC0')
    parser.add_argument('-b', '--baud', type = int, default=115200, 
                        help='Baud rate of pixhawk serial connection. defaults to 115200 for /dev/ttyACM0, (57600 for /dev/ttyUSB0)')
    parser.add_argument('-config', default = str(default_cfg), type=str, 
                        help = ('Config File, Defaults to {}.' \
                            'Yaml contains activeMQ connection information pixhawk information'.format(str(default_cfg))))  
    parser.add_argument('--nohw', action = 'store_true', default = False, help= "Flag for running in test mode with simulated HW.")
    # parser.add_argument("-ll", "--loglevel", type=str, default="info" , 
    #                     help="logging level. default info")  
    args = parser.parse_args()    

    logging_level = logging.INFO # Will change to WARN later
    log = logging.getLogger()
    log.setLevel(logging_level) # the logging instance must be set to the lowest level of all streams    
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s] [line %(lineno)d] -- %(message)s')
    handler.setFormatter(formatter)
    log.addHandler(handler)

    with open(args.config) as f:
        config = yaml.safe_load(f)             
    credentials = {
                "username": config["amq_username"], 
                "password": config["amq_password"]}    
    messenger = Messenger(config['amq_server'], config['amq_port'], credentials, use_ssl=config['amq_use_ssl'])

    pixhawk = PixhawkManager(args.port, args.baud, messenger=messenger, 
                             simulate_hw=args.nohw, pix_id=args.pix_id)
    pixhawk.run()    
    

if __name__ == '__main__':
    main()


