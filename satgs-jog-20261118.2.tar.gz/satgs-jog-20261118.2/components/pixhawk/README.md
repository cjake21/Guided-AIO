# Pixhawk Logging Package
This repository is used to log the orientation of MSELs ground station antennae. The orientation is measured using a PIXHAWK and 2 GPS units. The antenna elevation is logged with the IMU, however the antenna frame and possible magnets in the pan and tilt unit (PTU) result in the pixhawk's azimuthal estimate to be garbage. Instead of relying on the pixhawk's magnetometer, we use two GPS antenna's for yaw (see [ArduPilot moving baseline](https://ardupilot.org/copter/docs/common-gps-for-yaw.html)).   

At present this library logs the following messages:

1. [Attitude](https://mavlink.io/en/messages/common.html#ATTITUDE)
    1. Roll
    2. Pitch 
    3. Yaw
2. [GPS_RAW_INT](https://mavlink.io/en/messages/common.html#GPS_RAW_INT). Data from primary GPS
    1. lat (degrees, WGS84)
    2. lon (degrees, WGS84)
    3. alt (meter, MSL WGS84)
    4. [Fix Type](https://mavlink.io/en/messages/common.html#GPS_FIX_TYPE)
    5. satellite_visible
    6. Yaw
3. [GPS2_RAW](https://mavlink.io/en/messages/common.html#GPS_RAW_INT). Data from 2nd GPS
    1. [Fix Type](https://mavlink.io/en/messages/common.html#GPS_FIX_TYPE)
    2. satellite_visible    

# Usage

This library logs data using activeMQ. The machine that is physically connected to the pixhawk runs the `pixhawk.service` and publishes each data message to the activeMQ broker. Users can subscribe and log messages using the [`pixhawkSubscriber`](https://git.codev.mitre.org/projects/SATGS/repos/pixhawk/browse/pixhawk/pixhawk_subscriber.py) given that they are connected to the activeMQ server. 

# Requirements
- [stomp](https://pypi.org/project/stomp-py/)
- [pymavlink](https://pypi.org/project/pymavlink/)
- [Python meteor-api](https://gitlab.mitre.org/meteor/meteor-api)
- A running active MQ broker

# Setup
For setting up the activeMQ server see these instructions. Otherwise you just need to follow the steps below. 

```
git clone ssh://git@git.codev.mitre.org/satgs/pixhawk.git
cd pixhawk
python3 -m venv .env
source .env/bin/activate
 
python3 -m pip install --upgrade pip 
python3 -m pip install -e .
```

## Installed development packages

The checkout commands above are retained as legacy documentation. For the
installed development candidate, use non-editable wheels from the reviewed
local wheelhouse. Select `pixhawk==0.0.1` for subscribers or
`pixhawk[manager]==0.0.1` for a local manager. Only the manager extra selects
pyserial, pymavlink and NumPy. The complete manager source remains included;
client installation does not import, construct or start it.

This candidate requires Python 3.9 or newer for protobuf 6.33.6 and declares
Meteor 2.2.0 and PyYAML as client dependencies. These are development metadata
decisions, not production pin activation or interpreter qualification.
Python 3.11 execution remains a separate validation requirement.

Before a normal setuptools build, explicitly generate
`src/pixhawk/pixhawk_pb2.py` from `pixhawk.proto` using the separately reviewed
pinned compiler and includes. A wheel build fails if that module is absent; it
does not download a compiler or generate code. Wheels contain the generated module
and schema, and source distributions include both. No credential JSON is a
package resource. Keep compiler and installer tools in the isolated build
environment. Installed-origin, dependency, resource and behavior checks must
establish the resulting artifact's validity.

# Running Pixhawk as a service
To run the pixhawk server and publish its status you will need to run `pixhawk_manager.py` as service. The service file is included [in this repo](./etc/systemd/pixhawk.service).
When run in this mode the pixhawk will constantly be publishing the measurements.

Generally, this program is expecting configuration parameters to be read from a file, usually located in: `~/ground_station/config/config.yaml`. This allows assigning different Pixhawk assemblies to different PTU assemblies.  

As such, you must specify the `--ptu-id <your_pix_id>` flag in the ExecStart line whether running standalone or part of the ground station software suite, and this must be reflected in your config file.

Lastly, determine which logical USB port the Pixhawk is connected on to the host (usually `/dev/ttyACM0` or `/dev/ttyUSB0` nomenclature) by doing:
```
ls -al /dev/serial/by-id
# or
ls -al /dev/serial/by-path
```

Then, pass this port via the `--port` flag on the ExecStart line in the service file.


# Provisional bounded pointing client

The additive `PixhawkSubscriber.open_pointing(*, messenger, settings, pix_id,
log_dir, deadline, cancel)` factory returns an inert, selected-ID client. This is
a provisional source candidate, not a declared or activated owner release.
The existing positional constructor and its methods retain legacy behavior.

Strict input requires one selected `pixhawk_sensors` record matching the positive
int32 manager ID and a positive int32 `ptu_id`, an absolute caller-owned output
directory, and a compatible already-open bounded Messenger. Settings may be a
dict or the ground station's frozen mapping. No configuration file is read,
credentials retained, subscription created, file opened, signal installed or
worker started by the factory. Record ownership of `close` before activation.

`check_connection(*, deadline, cancel)` activates exactly the selected
`/topic/PX_PONG_<id>` and `/topic/PIXHAWK_DATA_<id>` registrations, then submits
serialized real `PingCmd` bytes to `/topic/PX_PING_<id>`. Reply state resets before
submission, including synchronous callbacks. Only a parsed matching-ID pong
observed during that request window completes the operation. The unchanged
schema has no correlation nonce: this does not prove a fresh acknowledgment,
hardware readiness or physical completion.

`start_logging(*, deadline, cancel)` requires that matching-ID observation.
It exclusively creates `pixhawk_log_<id>.csv` within the supplied directory;
existing files are never overwritten. The caller owns that directory and its
ancestor integrity. There is no background logging worker. The Messenger callback
writes and flushes selected-ID CSV rows directly. Bodies must be exact bytes at
most4096 bytes, with finite numeric fields and a valid UTC timestamp of at most64
characters. Malformed, oversized, wrong-ID and invalid-time data is rejected
without logging raw payloads. Callback state-lock contention rejects a sample or
pong immediately and increments the bounded rejection counter. This is not a
lossless logging or message-delivery guarantee.

Each invocation uses its supplied exact built-in threading.Event and original
absolute monotonic deadline. Equality is expired; checks surround lock waits
and resource acquisition. Cancellation is not automatic unregister or rollback.
Committed callbacks do not inherit a completed setup invocation's Event or
deadline. Do not clear an operation Event while any invocation using it remains
active. A failed partial activation or logging acquisition must be followed by
passive close; retained resources are visible through `diagnostics()`.

`close(*, deadline)` first gates future callback effects, then removes only this
client's two exact callback/identifier registrations and waits for in-flight
owner state before closing its file. Removal uses one new cleanup Event and the
supplied deadline. It never closes or cancels the borrowed Messenger's lifecycle.
With the fixed validated removal inputs, Messenger's `admission` absence result
retires an attempted registration already absent after a failed subscribe;
other owner errors propagate unchanged and keep unresolved registration debt.
Close failures expose fixed local categories and residual resources, and can be
retried with a fresh caller-supplied deadline. Successful repeated close is
idempotent. Native file write/flush/close calls cannot be made preemptible by these
software checks; a live callback or uncertain stream remains owned until a
later cleanup succeeds. Callback write failures record a local logging fault
without throwing into or poisoning the shared Messenger.

The strict instance rejects inherited legacy construction, signal, worker,
publish-wrapper and cleanup paths. Use only the bounded methods above. The
installed development packaging restores the genuine manager module and updates
development dependencies; it does not change this schema or strict subscriber
behavior, activate a production map, or declare a production source release.

The new tests use real generated protobuf messages. Unit cases substitute the
Messenger public boundary; separate integration cases use the actual bounded
Messenger/lower with controlled socket/TLS/readiness primitives. The harness must
supply `PIXHAWK_TEST_OUTPUT` as its admitted temporary-output root, exact generated
module/runtime paths and the normal selected package initializer. Compiler3.20.1
and patched runtime5.29.6 are isolated test tooling, not normal package dependency
resolution. Execution results and independent acceptance are recorded separately. Python3.11,
ARM64, native files/network, broker behavior and physical hardware remain
unqualified.

# Explicit navigation admission inputs

`pixhawk.navigation.evaluate_navigation(policy, observation,
expected_generation=..., now_monotonic=...)` is a pure contract evaluator.
It performs no I/O, makes no motion request, and does not alter the subscriber,
runner or wire schema. Its immutable decision exposes `admitted` and fixed
`reasons`. Admission means only that the supplied normalized observation matches
the supplied policy. It is not firmware qualification, source authentication,
hardware readiness, a physical heading guarantee or motion authorization.

There is deliberately no adapter from the current `fused_msg` to a qualified
observation. Its proto3 numeric fields have no explicit presence, and it lacks
per-component source time, source session, validity and geometry bindings.
Current-wire data, matching-ID pong and successful logging remain unqualified.
Zero values must not be used to infer either presence or absence. The reference
manager's aggregate timestamp is not a substitute for component sensor age.

The caller must independently establish the source contract and construct:

- `NavigationBinding`: selected positive int32 Pixhawk/PTU IDs, source contract
  and session IDs, a qualified common time-basis ID, heading reference, position and attitude frames, altitude
  datum and calibration ID. String fields are nonempty bounded ASCII identifiers.
  They bind externally established semantics; matching arbitrary labels does not
  establish those semantics or perform a coordinate transformation.
- `NavigationPolicy`: that expected binding, explicit positive finite maximum
  receipt age, sensor age and component skew, and nonempty immutable sets of
  accepted primary/secondary fix codes and heading states. Fix codes use the
  normalized unsigned-byte domain. No actual acceptable fix code, heading state,
  freshness limit, offset or calibration is supplied by this module.
- `NavigationObservation`: that binding, a positive sample generation, local
  monotonic receipt time, separate attitude/primary-GPS/secondary-GPS/position/
  heading age estimates at receipt and five explicit nonnegative finite age
  uncertainties, explicit dual-GPS fix codes and heading state, and
  finite normalized heading, attitude and geodetic position values. Missing
  values must be `None`, which denies admission. Heading is in degrees in
  `[0, 360)`; attitude is in radians; latitude/longitude are degrees within
  `[-90, 90]` and `[-180, 180]`; altitude is metres in the bound datum.

The expected generation must come from the caller's selected owner snapshot,
not be copied uncritically from untrusted telemetry. It is compared exactly.
Receipt and evaluation times must use the same local monotonic clock domain.
Each component uses the interval `[max(0, age - uncertainty), age + uncertainty]`.
The qualified caller must bound acquisition-to-receipt delay and clock/transport
uncertainty in a common time basis. Matching labels alone do not qualify clocks.
The lower endpoint is clipped because physical sensor age cannot be negative.
Freshness uses the upper endpoint plus elapsed local receipt time. Worst-case
skew is the largest upper-minus-lower difference across distinct component
pairs, so unequal uncertainties cannot conceal component skew. Missing or
invalid uncertainty, or a missing/mismatched time basis, denies admission.
Equality with any maximum rejects. A freshly received old sample remains old. Replays,
source restarts and clock synchronization must be resolved by the qualified
source adapter; this stateless evaluator does not discover them from wire data.

Invalid policy, absent evidence, invalid numbers or times, stale components,
unaccepted fix/heading states and mismatched bindings/generation deny. No fallback
to fused heading, magnetometer yaw, cached samples or default limits occurs.
The synthetic tests use fixture-only codes, labels and limits. Passing those
tests establishes evaluator behavior, not a deployable navigation policy. Their
positive observations specify a common fixture time basis and zero uncertainty;
those synthetic values do not assert that a deployed source has zero uncertainty.

Before a source adapter or navigation-dependent operation can use this contract,
Cole must establish these facts:

1. Exact Pixhawk/firmware stack and release, GPS models/firmware, MAVLink
   dialect/version and selected sensor/PTU mapping.
2. Authoritative heading field, its units, extension presence, unavailable
   sentinels and validity states. Existing `gpsYaw` documentation and reference
   simulation/logging use inconsistent units and are not authoritative.
3. Required primary/secondary fix states and independent dual-GPS heading or
   baseline health evidence, including loss and reacquisition behavior.
4. Component timestamp meaning, source session/sequence evidence, update rates,
   clock/transport uncertainty, maximum ages and inter-component skew limits.
5. Authoritative raw or fused position source and altitude datum, including how
   mixed-source aggregates are identified or rejected.
6. Heading reference, axes/signs, antenna-baseline direction, IMU orientation,
   PTU frame and measured mounting/calibration revision, offsets and uncertainty.
7. Which operations require navigation admission and what their owner must do
   when validity is lost after admission.
