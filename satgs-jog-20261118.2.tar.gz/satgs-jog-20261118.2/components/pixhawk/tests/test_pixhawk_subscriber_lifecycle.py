"""Hardware-free strict Pixhawk tests using real generated protobuf messages.

Unit cases substitute only the Messenger's supported public methods. The final
cases compose actual Messenger/lower ownership with controlled socket primitives.
"""
import csv
import inspect
import sys
import os
import tempfile
import threading
import time
import unittest
from contextlib import ExitStack
from pathlib import Path
from types import MappingProxyType
from unittest import mock

from meteor_api.messenger import Messenger, MessengerError
from pixhawk import pixhawk_pb2
from pixhawk import pixhawk_subscriber as subscriber
from pixhawk.constants import Topics


class PublicMessengerScript:
    def __init__(self):
        self.instance = object.__new__(Messenger)
        self.registrations = []
        self.calls = []
        self.pong_id = 7
        self.subscribe_error = None
        self.cancel_error = None

    def subscribe(self, topic, callback, identifier, **controls):
        self.calls.append(('subscribe', topic, callback, identifier, controls))
        if self.subscribe_error is not None:
            self.subscribe_error(topic)
        self.registrations.append((topic, callback, identifier))

    def cancel(self, topic, callback, identifier, **controls):
        self.calls.append(('cancel', topic, callback, identifier, controls))
        if self.cancel_error is not None:
            raise self.cancel_error
        registration = (topic, callback, identifier)
        if registration not in self.registrations:
            raise MessengerError('admission')
        self.registrations.remove(registration)

    def publish(self, topic, payload, **controls):
        self.calls.append(('publish', topic, payload, controls))
        if type(payload) is not bytes:
            raise AssertionError('strict payload must be serialized bytes')
        request = pixhawk_pb2.PingCmd()
        request.ParseFromString(payload)
        if request.ping and self.pong_id is not None:
            self.deliver(Topics.PONG_RESPONSE + '_7',
                         pixhawk_pb2.PongResponse(pix_id=self.pong_id).SerializeToString())

    def deliver(self, topic, body):
        for current, callback, identifier in tuple(self.registrations):
            if current == topic:
                callback(body, identifier)

    def install(self, stack):
        stack.enter_context(mock.patch.object(Messenger, 'strict_instance_compatible',
                                               return_value=True))
        stack.enter_context(mock.patch.object(Messenger, 'subscribe', side_effect=self.subscribe))
        stack.enter_context(mock.patch.object(Messenger, 'cancelSubscribe', side_effect=self.cancel))
        stack.enter_context(mock.patch.object(Messenger, 'publish', side_effect=self.publish))
        stack.enter_context(mock.patch.object(Messenger, 'close',
            side_effect=AssertionError('borrowed Messenger must not be closed')))


class PixhawkPointingTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(
            prefix='pixhawk-', dir=os.environ['PIXHAWK_TEST_OUTPUT'])
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.script = PublicMessengerScript()
        self.script.install(self.stack)
        self.clients = []
        self.addCleanup(self.release_clients)

    def release_clients(self):
        self.script.cancel_error = None
        self.script.subscribe_error = None
        for client in self.clients:
            client.close(deadline=time.monotonic() + 1)

    def controls(self, seconds=1):
        return dict(deadline=time.monotonic() + seconds, cancel=threading.Event())

    def opened(self, **changes):
        options = dict(messenger=self.script.instance,
            settings={'pixhawk_sensors': [{'id': 7, 'ptu_id': 2}]},
            pix_id=7, log_dir=self.root, **self.controls())
        options.update(changes)
        client = subscriber.PixhawkSubscriber.open_pointing(**options)
        self.clients.append(client)
        return client

    def connected(self):
        client = self.opened()
        self.assertIs(client.check_connection(**self.controls()), True)
        return client

    def body(self, **changes):
        values = dict(pix_id=7, pc_time='2026-09-29 12:00:00 UTC', roll=.25,
                      pitch=.5, yaw=.75, gpsYaw=12300, gpsStatus=4)
        values.update(changes)
        return pixhawk_pb2.fused_msg(**values).SerializeToString()

    def deliver(self, body):
        self.script.deliver(Topics.DATA_MSG + '_7', body)

    def test_factory_is_inert_and_keeps_only_selected_local_identity(self):
        before = tuple(threading.enumerate())
        with mock.patch.object(subscriber, 'open', create=True,
                               side_effect=AssertionError('factory file I/O')), \
             mock.patch.object(subscriber.signal, 'signal',
                               side_effect=AssertionError('signal mutation')):
            client = self.opened()
        self.assertEqual(tuple(threading.enumerate()), before)
        self.assertEqual(self.script.calls, [])
        self.assertEqual(tuple(self.root.iterdir()), ())
        self.assertEqual(client.pix_ids, (7,))
        self.assertEqual(client.pix_dict, {7: {'id': 7, 'ptu_id': 2}})
        self.assertFalse(hasattr(client, 'config'))

    def test_factory_rejects_nonexact_ids_paths_and_unselected_rows(self):
        for changes in (
            {'pix_id': True}, {'pix_id': 0}, {'pix_id': 2 ** 31},
            {'log_dir': 'relative'}, {'log_dir': Path('relative')},
            {'log_dir': self.root / '..' / 'outside'},
            {'settings': {'pixhawk_sensors': []}},
            {'settings': {'pixhawk_sensors': [{'id': True, 'ptu_id': 2}]}},
            {'settings': {'pixhawk_sensors': [{'id': 7, 'ptu_id': 2},
                                             {'id': 8, 'ptu_id': 2}]}},
            {'settings': {'pixhawk_sensors': [{'id': 7, 'ptu_id': True}]}},
            {'messenger': object()},
        ):
            with self.subTest(changes=tuple(changes)):
                with self.assertRaises(subscriber.PixhawkError) as caught:
                    self.opened(**changes)
                self.assertEqual(caught.exception.primary, 'admission')
        self.assertEqual(self.script.calls, [])

    def test_frozen_selected_settings_are_admitted_without_retaining_mutable_input(self):
        row = {'id': 7, 'ptu_id': 2}
        settings = MappingProxyType({'pixhawk_sensors': (MappingProxyType(row),)})
        client = self.opened(settings=settings)
        row['id'] = 99
        row['ptu_id'] = 88
        self.assertEqual(client.pix_dict, {7: {'id': 7, 'ptu_id': 2}})
        self.assertEqual(client.pix_ids, (7,))

    def test_factory_rejects_incompatible_messenger(self):
        with mock.patch.object(Messenger, 'strict_instance_compatible', return_value=False):
            with self.assertRaises(subscriber.PixhawkError):
                self.opened()

    def test_exact_finite_controls_and_equal_deadline_fail_without_effects(self):
        for invalid in (True, float('nan'), float('inf'), 10 ** 400, '1', None):
            with self.subTest(kind=type(invalid).__name__):
                with self.assertRaises(subscriber.PixhawkError) as caught:
                    self.opened(deadline=invalid)
                self.assertEqual(caught.exception.primary, 'admission')
        with self.assertRaises(subscriber.PixhawkError) as caught:
            self.opened(cancel=object())
        self.assertEqual(caught.exception.primary, 'admission')
        with mock.patch.object(subscriber.time, 'monotonic', return_value=50):
            for deadline in (49, 50):
                with self.assertRaises(subscriber.PixhawkError) as caught:
                    self.opened(deadline=deadline)
                self.assertEqual(caught.exception.primary, 'deadline')
        self.assertEqual(self.script.calls, [])

    def test_set_operation_event_rejects_before_subscribe(self):
        client = self.opened()
        controls = self.controls()
        controls['cancel'].set()
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.check_connection(**controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        self.assertEqual(self.script.calls, [])

    def test_cancel_set_during_clock_sample_prevents_activation(self):
        client = self.opened()
        controls = self.controls()
        clock = time.monotonic
        def sample():
            controls['cancel'].set()
            return clock()
        with mock.patch.object(subscriber.time, 'monotonic', side_effect=sample):
            with self.assertRaises(subscriber.PixhawkError) as caught:
                client.check_connection(**controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        self.assertEqual(self.script.calls, [])

    def test_synchronous_matching_pong_and_original_controls(self):
        client = self.opened()
        controls = self.controls()
        self.assertIs(client.check_connection(**controls), True)
        self.assertEqual([call[1] for call in self.script.calls],
                         [Topics.PONG_RESPONSE + '_7', Topics.DATA_MSG + '_7',
                          Topics.PING_CMD + '_7'])
        for call in self.script.calls:
            self.assertEqual(call[-1]['deadline'], controls['deadline'])
            self.assertIs(call[-1]['cancel'], controls['cancel'])
        self.assertEqual(self.script.calls[-1][2], b'\x08\x01')

    def test_cancellation_after_synchronous_pong_wins_and_new_operation_can_retry(self):
        client = self.opened()
        controls = self.controls()
        original = self.script.publish
        def publish(*args, **kwargs):
            original(*args, **kwargs)
            controls['cancel'].set()
        with mock.patch.object(Messenger, 'publish', side_effect=publish):
            with self.assertRaises(subscriber.PixhawkError) as caught:
                client.check_connection(**controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        self.assertFalse(client._connected)
        self.assertIs(client.check_connection(**self.controls()), True)
        self.assertEqual(len(self.script.registrations), 2)

    def test_wrong_id_pong_and_previous_reply_do_not_complete_next_request(self):
        client = self.connected()
        self.script.pong_id = 8
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.check_connection(**self.controls(.02))
        self.assertEqual(caught.exception.primary, 'deadline')
        self.assertFalse(client._connected)
        self.assertEqual(len(self.script.registrations), 2)
        self.assertGreater(client.diagnostics()['rejected_messages'], 0)

    def test_partial_activation_after_registration_retains_exact_cleanup(self):
        client = self.opened()
        original = self.script.subscribe
        def partial(topic, callback, identifier, **controls):
            original(topic, callback, identifier, **controls)
            if topic == Topics.DATA_MSG + '_7':
                raise MessengerError('deadline')
        with mock.patch.object(Messenger, 'subscribe', side_effect=partial):
            with self.assertRaises(MessengerError) as caught:
                client.check_connection(**self.controls())
        self.assertEqual(caught.exception.primary, 'deadline')
        retained = tuple(self.script.registrations)
        client.close(deadline=time.monotonic() + 1)
        removed = [call for call in self.script.calls if call[0] == 'cancel']
        self.assertEqual(tuple(call[1:4] for call in removed), retained)
        self.assertEqual(self.script.registrations, [])
        self.assertEqual(client.diagnostics()['cleanup'], ())

    def test_failed_subscribe_before_registration_reconciles_public_absence(self):
        client = self.opened()
        def fail(topic):
            if topic == Topics.DATA_MSG + '_7':
                raise MessengerError('operation-limit')
        self.script.subscribe_error = fail
        with self.assertRaises(MessengerError) as caught:
            client.check_connection(**self.controls())
        self.assertEqual(caught.exception.primary, 'operation-limit')
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client.diagnostics()['registrations'], 0)
        self.assertTrue(client.diagnostics()['closed'])

    def test_passive_close_uses_fresh_event_and_never_borrowed_close(self):
        client = self.opened()
        controls = self.controls()
        client.check_connection(**controls)
        controls['cancel'].set()
        deadline = time.monotonic() + 1
        client.close(deadline=deadline)
        removals = [call for call in self.script.calls if call[0] == 'cancel']
        self.assertEqual(len(removals), 2)
        for call in removals:
            self.assertEqual(call[-1]['deadline'], deadline)
            self.assertIsNot(call[-1]['cancel'], controls['cancel'])
            self.assertFalse(call[-1]['cancel'].is_set())
        count = len(self.script.calls)
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(len(self.script.calls), count)
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.start_logging(**self.controls())
        self.assertEqual(caught.exception.primary, 'closed')

    def test_owner_cleanup_failure_is_propagated_and_registration_debt_retried(self):
        client = self.connected()
        failure = MessengerError('disconnected')
        self.script.cancel_error = failure
        with self.assertRaises(MessengerError) as caught:
            client.close(deadline=time.monotonic() + 1)
        self.assertIs(caught.exception, failure)
        self.assertIn('registration-debt', client.diagnostics()['cleanup'])
        self.assertFalse(client.diagnostics()['closed'])
        self.script.cancel_error = None
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client.diagnostics()['cleanup'], ())

    def test_logging_needs_connectivity_and_creates_no_worker(self):
        client = self.opened()
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.start_logging(**self.controls())
        self.assertEqual(caught.exception.primary, 'state')
        client.check_connection(**self.controls())
        before = tuple(threading.enumerate())
        client.start_logging(**self.controls())
        client.start_logging(**self.controls())
        self.assertEqual(tuple(threading.enumerate()), before)
        self.assertFalse(hasattr(client, 'pixhawkThread'))
        self.assertEqual(len(tuple(self.root.iterdir())), 1)

    def test_selected_real_message_is_logged_after_setup_event_is_cancelled(self):
        client = self.connected()
        controls = self.controls()
        client.start_logging(**controls)
        controls['cancel'].set()
        self.deliver(self.body())
        client.close(deadline=time.monotonic() + 1)
        with open(self.root / 'pixhawk_log_7.csv', newline='') as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['pix_id'], '7')
        self.assertEqual(float(rows[0]['gpsYaw']), 12300)
        self.assertEqual(set(client.pix_status), {7})

    def test_malformed_wrong_id_oversize_nonfinite_and_invalid_time_have_no_row(self):
        client = self.connected()
        client.start_logging(**self.controls())
        bad = (b'\x80', self.body(pix_id=8), b'x' * 4097, bytearray(self.body()),
               self.body(roll=float('nan')), self.body(alt=float('inf')),
               self.body(pc_time='invalid'), self.body(pc_time='x' * 65))
        for body in bad:
            self.deliver(body)
        self.assertEqual(client.pix_status, {})
        self.assertEqual(client.diagnostics()['rejected_messages'], len(bad))
        self.assertIsNone(client.diagnostics()['fault'])
        client.close(deadline=time.monotonic() + 1)
        with open(self.root / 'pixhawk_log_7.csv', newline='') as stream:
            self.assertEqual(list(csv.DictReader(stream)), [])

    def test_exclusive_file_does_not_overwrite_existing_content(self):
        path = self.root / 'pixhawk_log_7.csv'
        path.write_text('existing\n')
        client = self.connected()
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.start_logging(**self.controls())
        self.assertEqual(caught.exception.primary, 'logging')
        self.assertEqual(path.read_text(), 'existing\n')
        self.assertEqual(client.diagnostics()['fault'], 'logging')

    def test_cancellation_after_file_acquisition_keeps_owned_stream_for_close(self):
        client = self.connected()
        controls = self.controls()
        actual_open = open
        acquired = []
        def opening(*args, **kwargs):
            stream = actual_open(*args, **kwargs)
            acquired.append(stream)
            controls['cancel'].set()
            return stream
        with mock.patch.object(subscriber, 'open', create=True, side_effect=opening):
            with self.assertRaises(subscriber.PixhawkError) as caught:
                client.start_logging(**controls)
        self.assertEqual(caught.exception.primary, 'cancelled')
        self.assertIn('file-release', client.diagnostics()['cleanup'])
        self.assertFalse(acquired[0].closed)
        client.close(deadline=time.monotonic() + 1)
        self.assertTrue(acquired[0].closed)

    def test_header_failure_retains_owned_stream_without_started_success(self):
        client = self.connected()
        with mock.patch.object(subscriber.csv.DictWriter, 'writeheader',
                               side_effect=OSError('private header canary')):
            with self.assertRaises(subscriber.PixhawkError) as caught:
                client.start_logging(**self.controls())
        self.assertEqual(str(caught.exception), 'logging')
        self.assertFalse(client.started)
        self.assertFalse(client._file.closed)
        stream = client._file
        self.assertIn('file-release', client.diagnostics()['cleanup'])
        client.close(deadline=time.monotonic() + 1)
        self.assertTrue(stream.closed)

    def test_expired_close_gates_callbacks_and_preserves_cleanup_debt(self):
        client = self.connected()
        client.start_logging(**self.controls())
        with mock.patch.object(subscriber.time, 'monotonic', return_value=50):
            with self.assertRaises(subscriber.PixhawkError) as caught:
                client.close(deadline=50)
        self.assertEqual(caught.exception.primary, 'deadline')
        self.assertIn('registration-debt', caught.exception.cleanup)
        self.assertIn('file-release', caught.exception.cleanup)
        self.deliver(self.body())
        self.assertEqual(client.pix_status, {})
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client.diagnostics()['cleanup'], ())

    def test_callback_file_fault_is_local_and_retains_passive_cleanup(self):
        client = self.connected()
        client.start_logging(**self.controls())
        with mock.patch.object(client._writer, 'writerow', side_effect=OSError('private canary')):
            self.deliver(self.body())
        self.assertEqual(client.diagnostics()['fault'], 'logging')
        self.assertFalse(client.started)
        self.assertIn('file-release', client.diagnostics()['cleanup'])
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.start_logging(**self.controls())
        self.assertEqual(str(caught.exception), 'logging')
        client.close(deadline=time.monotonic() + 1)

    def test_nonblocking_callback_contention_drops_without_fault(self):
        client = self.connected()
        client.start_logging(**self.controls())
        client._state.acquire()
        try:
            self.deliver(self.body())
        finally:
            client._state.release()
        self.assertEqual(client.diagnostics()['rejected_messages'], 1)
        self.assertIsNone(client.diagnostics()['fault'])
        self.assertEqual(client.pix_status, {})

    def test_operation_contention_obeys_original_deadline(self):
        client = self.opened()
        client._operation.acquire()
        try:
            with self.assertRaises(subscriber.PixhawkError) as caught:
                client.check_connection(**self.controls(.02))
            self.assertEqual(caught.exception.primary, 'deadline')
            self.assertEqual(self.script.calls, [])
        finally:
            client._operation.release()

    def test_close_reports_live_callback_and_retains_file_until_completion(self):
        client = self.connected()
        client.start_logging(**self.controls())
        entered, release = threading.Event(), threading.Event()
        original = client._writer.writerow
        errors = []
        def blocking(row):
            entered.set()
            if not release.wait(1):
                raise AssertionError('fixture release timeout')
            return original(row)
        def callback():
            try:
                self.deliver(self.body())
            except BaseException as error:
                errors.append(error)
        with mock.patch.object(client._writer, 'writerow', side_effect=blocking):
            worker = threading.Thread(target=callback, name='pixhawk-test-callback')
            worker.start()
            try:
                self.assertTrue(entered.wait(1))
                with self.assertRaises(subscriber.PixhawkError) as caught:
                    client.close(deadline=time.monotonic() + .02)
                self.assertEqual(caught.exception.primary, 'deadline')
                self.assertIn('active-callback', caught.exception.cleanup)
                self.assertIn('file-release', caught.exception.cleanup)
                self.assertFalse(client._file.closed)
            finally:
                release.set()
                worker.join(1)
            self.assertFalse(worker.is_alive())
        self.assertEqual(errors, [])
        client.close(deadline=time.monotonic() + 1)
        self.assertEqual(client.diagnostics()['cleanup'], ())
        before = (self.root / 'pixhawk_log_7.csv').read_bytes()
        client._receive_data(self.body(), '')
        self.assertEqual((self.root / 'pixhawk_log_7.csv').read_bytes(), before)

    def test_close_after_final_logging_check_clears_late_started_state(self):
        client = self.connected()
        paused, release, gated = threading.Event(), threading.Event(), threading.Event()
        finished = threading.Event()
        failures, outcomes, restored = [], [], []
        original_main_trace = sys.gettrace()
        deadline = time.monotonic() + 4

        def source_line(method, statement):
            lines, first = inspect.getsourcelines(method)
            matches = [first + offset for offset, line in enumerate(lines)
                       if line.strip() == statement]
            self.assertEqual(len(matches), 1)
            return matches[0]

        start_code = client.start_logging.__func__.__code__
        close_code = client._close.__func__.__code__
        start_line = source_line(client.start_logging, 'self.do_logging = True')
        close_line = source_line(client._close,
                                 'self._lock(self._operation, deadline, cancel, passive=True)')

        def start_trace(frame, event, arg):
            if frame.f_code is start_code and event == 'line' and frame.f_lineno == start_line:
                paused.set()
                if not release.wait(2):
                    raise AssertionError('logging trace release timeout')
            return start_trace

        def close_trace(frame, event, arg):
            if frame.f_code is close_code and event == 'line' and frame.f_lineno == close_line:
                gated.set()
            return close_trace

        def run_start():
            previous = sys.gettrace()
            try:
                sys.settrace(start_trace)
                client.start_logging(deadline=deadline, cancel=threading.Event())
                outcomes.append('start')
            except BaseException as error:
                failures.append(error)
            finally:
                sys.settrace(previous)
                restored.append(sys.gettrace() is previous)

        def run_close():
            previous = sys.gettrace()
            try:
                sys.settrace(close_trace)
                client.close(deadline=deadline)
                outcomes.append('close')
            except BaseException as error:
                failures.append(error)
            finally:
                sys.settrace(previous)
                restored.append(sys.gettrace() is previous)
                finished.set()

        starter = threading.Thread(target=run_start, name='pixhawk-start-barrier')
        closer = threading.Thread(target=run_close, name='pixhawk-close-barrier')
        started_threads = []
        try:
            starter.start()
            started_threads.append(starter)
            self.assertTrue(paused.wait(1))
            self.assertTrue(client._operation.locked())
            self.assertTrue(client._state.locked())
            closer.start()
            started_threads.append(closer)
            self.assertTrue(gated.wait(1))
            self.assertTrue(client._closing.is_set())
            self.assertFalse(client.started)
            self.assertFalse(finished.is_set())
            release.set()
            for worker in started_threads:
                worker.join(2)
            self.assertTrue(all(not worker.is_alive() for worker in started_threads))
            self.assertEqual(failures, [])
            self.assertCountEqual(outcomes, ['start', 'close'])
            self.assertFalse(client.started)
            self.assertFalse(client.do_logging)
            self.assertIsNone(client._file)
            self.assertIsNone(client._writer)
            self.assertEqual(client.diagnostics()['registrations'], 0)
            self.assertEqual(client.diagnostics()['cleanup'], ())
            self.assertTrue(client.diagnostics()['closed'])
            self.assertEqual(self.script.registrations, [])
        finally:
            release.set()
            for worker in started_threads:
                worker.join(4)
            self.assertTrue(all(not worker.is_alive() for worker in started_threads))
            self.assertEqual(restored, [True] * len(started_threads))
            self.assertIs(sys.gettrace(), original_main_trace)

    def test_file_close_failure_is_retained_then_retried(self):
        client = self.connected()
        client.start_logging(**self.controls())
        stream = client._file
        class Stream:
            first = True
            def close(self):
                if self.first:
                    self.first = False
                    raise OSError('private close canary')
                stream.close()
        client._file = Stream()
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.close(deadline=time.monotonic() + 1)
        self.assertEqual(str(caught.exception), 'logging')
        self.assertIn('file-release', caught.exception.cleanup)
        self.assertFalse(stream.closed)
        client.close(deadline=time.monotonic() + 1)
        self.assertTrue(stream.closed)

    def test_strict_legacy_entry_points_are_rejected_without_effects(self):
        client = self.opened()
        for method in ('__init__', 'clean_exit', 'stopLogging', 'run', 'sig_handler',
                       'publish_wrapper', 'log_msg_cb', 'pong_cmd_cb', 'is_manually_stopped'):
            with self.subTest(method=method):
                with self.assertRaises(subscriber.PixhawkError) as caught:
                    getattr(client, method)()
                self.assertEqual(caught.exception.primary, 'legacy-path')
        self.assertEqual(self.script.calls, [])

    def test_legacy_constructor_still_selects_all_ids_and_legacy_cleanup(self):
        config = self.root / 'legacy.json'
        config.write_text('{"pixhawk_sensors":[{"id":7},{"id":8}]}')
        client = subscriber.PixhawkSubscriber(self.script.instance, config, standalone=False)
        self.assertIs(type(client), subscriber.PixhawkSubscriber)
        self.assertEqual(client.pix_ids, [7, 8])
        self.assertEqual(len(self.script.registrations), 4)
        self.assertTrue(all(call[-1] == {} for call in self.script.calls))
        client.clean_exit()
        self.assertEqual(self.script.registrations, [])
        with self.assertRaises(subscriber.PixhawkError) as caught:
            client.close(deadline=time.monotonic() + 1)
        self.assertEqual(caught.exception.primary, 'legacy-path')


class PixhawkRealMessengerTests(unittest.TestCase):
    def test_real_owner_absence_after_pre_effect_cancel_is_reconciled_without_borrowed_close(self):
        from test_messenger_lifecycle import PrimitiveHarness, settings
        with tempfile.TemporaryDirectory(prefix='pixhawk-real-',
                dir=os.environ['PIXHAWK_TEST_OUTPUT']) as directory, PrimitiveHarness() as harness:
            values = settings(pixhawk_sensors=[{'id': 7, 'ptu_id': 2}])
            messenger = harness.open(values)
            operation = threading.Event()
            client = subscriber.PixhawkSubscriber.open_pointing(messenger=messenger,
                settings=values, pix_id=7, log_dir=Path(directory),
                deadline=harness.deadline(), cancel=operation)
            actual_subscribe = messenger.subscribe
            def cancelled_before_effect(topic, callback, identifier, **controls):
                if topic == Topics.DATA_MSG + '_7':
                    operation.set()
                return actual_subscribe(topic, callback, identifier, **controls)
            try:
                with mock.patch.object(messenger, 'subscribe', side_effect=cancelled_before_effect):
                    with self.assertRaises(MessengerError) as caught:
                        client.check_connection(deadline=harness.deadline(), cancel=operation)
                self.assertEqual(caught.exception.primary, 'cancelled')
                self.assertEqual(client.diagnostics()['registrations'], 2)
                client.close(deadline=harness.deadline())
                self.assertEqual(client.diagnostics()['cleanup'], ())
                self.assertTrue(messenger.strict_instance_compatible(values))
                self.assertFalse(harness.cancel.is_set())
                messenger.publish('/topic/caller', b'alive', deadline=harness.deadline(),
                                  cancel=threading.Event())
                frames = harness.tls_sockets[0].sent
                self.assertEqual(sum(frame.startswith(b'SUBSCRIBE\n') for frame in frames), 1)
                self.assertEqual(sum(frame.startswith(b'UNSUBSCRIBE\n') for frame in frames), 1)
                self.assertFalse(harness.raws[0].resource['closed'])
            finally:
                client.close(deadline=harness.deadline())


    def test_real_borrowed_owner_selected_payload_logging_and_cleanup(self):
        from test_messenger_lifecycle import PrimitiveHarness, settings
        with tempfile.TemporaryDirectory(prefix='pixhawk-real-',
                dir=os.environ['PIXHAWK_TEST_OUTPUT']) as directory, PrimitiveHarness() as harness:
            values = settings(pixhawk_sensors=[{'id': 7, 'ptu_id': 2}])
            messenger = harness.open(values)
            operation = threading.Event()
            client = subscriber.PixhawkSubscriber.open_pointing(messenger=messenger,
                settings=values, pix_id=7, log_dir=Path(directory),
                deadline=harness.deadline(), cancel=operation)
            requests = []
            def sent(frame):
                if frame.startswith(b'SEND\n') and b'/topic/PX_PING_7' in frame:
                    request = pixhawk_pb2.PingCmd()
                    request.ParseFromString(frame.split(b'\n\n', 1)[1][:-1])
                    requests.append(request.ping)
                    harness.message(1, pixhawk_pb2.PongResponse(pix_id=7).SerializeToString(),
                                    destination=Topics.PONG_RESPONSE + '_7')
            harness.hooks['send'] = sent
            try:
                self.assertIs(client.check_connection(deadline=harness.deadline(), cancel=operation), True)
                self.assertEqual(requests, [True])
                client.start_logging(deadline=harness.deadline(), cancel=operation)
                operation.set()
                body = pixhawk_pb2.fused_msg(pix_id=7, pc_time='2026-09-29 12:00:00 UTC',
                                             gpsYaw=12300).SerializeToString()
                harness.message(2, body, destination=Topics.DATA_MSG + '_7')
                end = time.monotonic() + 1
                while 7 not in client.pix_status and time.monotonic() < end:
                    threading.Event().wait(.001)
                self.assertIn(7, client.pix_status)
                self.assertFalse(harness.cancel.is_set())
                client.close(deadline=harness.deadline())
                self.assertTrue(messenger.strict_instance_compatible(values))
                messenger.publish('/topic/caller', b'alive', deadline=harness.deadline(),
                                  cancel=threading.Event())
                self.assertFalse(harness.raws[0].resource['closed'])
                self.assertEqual(client.diagnostics()['cleanup'], ())
                with open(Path(directory) / 'pixhawk_log_7.csv', newline='') as stream:
                    rows = list(csv.DictReader(stream))
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]['pix_id'], '7')
            finally:
                client.close(deadline=harness.deadline())
                harness.hooks.clear()


if __name__ == '__main__':
    unittest.main(verbosity=2)
