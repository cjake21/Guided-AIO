"""Synthetic policy checks, not firmware, telemetry or hardware qualification."""

import unittest
from dataclasses import FrozenInstanceError, fields, replace

from pixhawk.navigation import (
    NavigationBinding, NavigationObservation, NavigationPolicy, evaluate_navigation,
)


class NavigationTests(unittest.TestCase):
    def setUp(self):
        self.binding = NavigationBinding(
            pixhawk_id=7, ptu_id=2, source_contract_id='synthetic-contract',
            source_session_id='fixture-session', time_basis_id='fixture-common-time',
            heading_reference='fixture-heading',
            position_frame='fixture-position', attitude_frame='fixture-attitude',
            altitude_datum='fixture-datum', calibration_id='fixture-calibration')
        self.policy = NavigationPolicy(
            binding=self.binding, max_receipt_age_seconds=2,
            max_sensor_age_seconds=5, max_component_skew_seconds=1,
            accepted_primary_fix_types=frozenset((42,)),
            accepted_secondary_fix_types=frozenset((43,)),
            accepted_heading_states=frozenset(('fixture-valid',)))
        self.observation = NavigationObservation(
            binding=self.binding, generation=9, received_monotonic=100,
            attitude_age_at_receipt_seconds=0,
            primary_gps_age_at_receipt_seconds=0,
            secondary_gps_age_at_receipt_seconds=0,
            position_age_at_receipt_seconds=0,
            heading_age_at_receipt_seconds=0,
            attitude_age_uncertainty_seconds=0,
            primary_gps_age_uncertainty_seconds=0,
            secondary_gps_age_uncertainty_seconds=0,
            position_age_uncertainty_seconds=0,
            heading_age_uncertainty_seconds=0,
            primary_fix_type=42, secondary_fix_type=43,
            heading_state='fixture-valid', heading_degrees=45,
            roll_radians=0, pitch_radians=0, yaw_radians=0,
            latitude_degrees=0, longitude_degrees=0, altitude_metres=0)

    def evaluate(self, *, policy=None, observation=None, now=100.25, generation=9):
        return evaluate_navigation(
            self.policy if policy is None else policy,
            self.observation if observation is None else observation,
            expected_generation=generation, now_monotonic=now)

    def assert_rejected(self, result, reason):
        self.assertFalse(result.admitted)
        self.assertIn(reason, result.reasons)

    def test_complete_synthetic_observation_matches_explicit_policy(self):
        result = self.evaluate()
        self.assertTrue(result.admitted)
        self.assertEqual(result.reasons, ())

    def test_missing_policy_or_observation_never_admits(self):
        self.assert_rejected(evaluate_navigation(None, self.observation,
            expected_generation=9, now_monotonic=100), 'policy-required')
        self.assert_rejected(evaluate_navigation(self.policy, None,
            expected_generation=9, now_monotonic=100), 'observation-required')

    def test_wrong_record_types_never_admit(self):
        self.assert_rejected(self.evaluate(policy={}), 'invalid-policy')
        self.assert_rejected(self.evaluate(observation={}), 'invalid-observation')
        self.assert_rejected(self.evaluate(policy=replace(self.policy, binding={})),
                             'invalid-policy')
        self.assert_rejected(self.evaluate(observation=replace(self.observation, binding={})),
                             'invalid-observation')

    def test_current_wire_shaped_data_is_not_a_qualified_observation(self):
        wire_fields = dict(pix_id=7, pc_time='2026-09-30 12:00:00 UTC',
                           gpsStatus=42, gps2Status=43, gpsYaw=4500, hdg=4500)
        self.assert_rejected(self.evaluate(observation=wire_fields), 'invalid-observation')

    def test_every_policy_field_is_required(self):
        values = {field.name: getattr(self.policy, field.name) for field in fields(self.policy)}
        for name in values:
            with self.subTest(field=name):
                omitted = dict(values)
                del omitted[name]
                with self.assertRaises(TypeError):
                    NavigationPolicy(**omitted)

    def test_nonpositive_nonfinite_and_nonexact_limits_reject(self):
        for name in ('max_receipt_age_seconds', 'max_sensor_age_seconds',
                     'max_component_skew_seconds'):
            for value in (0, -1, True, None, '2', float('nan'), float('inf'), 10 ** 400):
                with self.subTest(field=name, kind=type(value).__name__):
                    self.assert_rejected(self.evaluate(policy=replace(self.policy, **{name: value})),
                                         'invalid-policy')

    def test_policy_requires_explicit_immutable_nonempty_states(self):
        for name in ('accepted_primary_fix_types', 'accepted_secondary_fix_types'):
            for value in (set((42,)), frozenset(), frozenset((True,)),
                          frozenset((-1,)), frozenset((256,)), frozenset(('42',))):
                with self.subTest(field=name, value=value):
                    self.assert_rejected(self.evaluate(policy=replace(self.policy, **{name: value})),
                                         'invalid-policy')
        for value in (set(('fixture-valid',)), frozenset(), frozenset(('',)),
                      frozenset(('unknown\n',))):
            with self.subTest(states=value):
                self.assert_rejected(self.evaluate(policy=replace(self.policy,
                    accepted_heading_states=value)), 'invalid-policy')

    def test_all_binding_fields_reject_missing_or_malformed_values(self):
        for field in fields(self.binding):
            for value in (None, True, '', 'bad\nvalue'):
                with self.subTest(field=field.name, value=value):
                    binding = replace(self.binding, **{field.name: value})
                    self.assert_rejected(self.evaluate(policy=replace(self.policy, binding=binding)),
                                         'invalid-policy')
                    self.assert_rejected(self.evaluate(observation=replace(self.observation,
                        binding=binding)), 'invalid-observation')

    def test_selected_pixhawk_and_ptu_must_both_match(self):
        for name in ('pixhawk_id', 'ptu_id'):
            with self.subTest(field=name):
                binding = replace(self.binding, **{name: 8})
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    binding=binding)), 'identity-mismatch')

    def test_source_contract_and_session_must_match(self):
        for name in ('source_contract_id', 'source_session_id'):
            with self.subTest(field=name):
                binding = replace(self.binding, **{name: 'different'})
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    binding=binding)), 'source-mismatch')

    def test_qualified_time_basis_must_match(self):
        binding = replace(self.binding, time_basis_id='different-time-basis')
        self.assert_rejected(self.evaluate(observation=replace(self.observation,
            binding=binding)), 'time-basis-mismatch')

    def test_every_reference_and_calibration_binding_must_match(self):
        for name in ('heading_reference', 'position_frame', 'attitude_frame',
                     'altitude_datum', 'calibration_id'):
            with self.subTest(field=name):
                binding = replace(self.binding, **{name: 'different'})
                reason = 'calibration-mismatch' if name == 'calibration_id' else 'frame-mismatch'
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    binding=binding)), reason)

    def test_expected_generation_is_exact_and_old_generation_rejects(self):
        self.assert_rejected(self.evaluate(generation=10), 'generation-mismatch')
        for value in (None, True, 0, -1, 9.0, '9'):
            with self.subTest(value=value):
                self.assert_rejected(self.evaluate(generation=value), 'invalid-request')
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    generation=value)), 'invalid-observation')

    def test_each_missing_component_value_or_presence_evidence_rejects(self):
        names = tuple(field.name for field in fields(self.observation)
                      if field.name not in ('binding', 'generation'))
        for name in names:
            with self.subTest(field=name):
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    **{name: None})), 'missing-data')

    def test_nonfinite_and_nonexact_navigation_values_reject(self):
        names = ('heading_degrees', 'roll_radians', 'pitch_radians', 'yaw_radians',
                 'latitude_degrees', 'longitude_degrees', 'altitude_metres')
        for name in names:
            for value in (True, '0', float('nan'), float('inf'), 10 ** 400):
                with self.subTest(field=name, kind=type(value).__name__):
                    self.assert_rejected(self.evaluate(observation=replace(self.observation,
                        **{name: value})), 'invalid-data')

    def test_normalized_heading_and_geodetic_ranges_reject_outside_values(self):
        for name, value in (('heading_degrees', -1), ('heading_degrees', 360),
                            ('latitude_degrees', -91), ('latitude_degrees', 91),
                            ('longitude_degrees', -181), ('longitude_degrees', 181)):
            with self.subTest(field=name, value=value):
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    **{name: value})), 'invalid-data')

    def test_each_gps_fix_must_be_explicitly_accepted(self):
        for name in ('primary_fix_type', 'secondary_fix_type'):
            for value in (0, 1, 255, True, 42.0, '42', []):
                with self.subTest(field=name, kind=type(value).__name__):
                    self.assert_rejected(self.evaluate(observation=replace(self.observation,
                        **{name: value})), 'invalid-fix')

    def test_heading_requires_explicit_accepted_state(self):
        for value in ('unknown', 'invalid', '', True, []):
            with self.subTest(kind=type(value).__name__):
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    heading_state=value)), 'invalid-heading')

    def test_bad_clock_future_receipt_and_negative_component_age_reject(self):
        for value in (True, '100', float('nan'), float('inf'), 10 ** 400):
            with self.subTest(kind=type(value).__name__):
                self.assert_rejected(self.evaluate(now=value), 'invalid-request')
                self.assert_rejected(self.evaluate(observation=replace(self.observation,
                    received_monotonic=value)), 'invalid-time')
        self.assert_rejected(self.evaluate(now=99), 'invalid-time')
        for name in (field.name for field in fields(self.observation)
                     if field.name.endswith('_age_at_receipt_seconds')):
            for value in (-1, True, '0', float('nan'), float('inf'), 10 ** 400):
                with self.subTest(field=name, kind=type(value).__name__):
                    self.assert_rejected(self.evaluate(observation=replace(self.observation,
                        **{name: value})), 'invalid-time')

    def test_receipt_age_equality_is_stale(self):
        self.assertTrue(self.evaluate(now=101.999).admitted)
        self.assert_rejected(self.evaluate(now=102), 'receipt-stale')

    def test_each_sensor_age_includes_elapsed_receipt_time_and_equality_is_stale(self):
        policy = replace(self.policy, max_component_skew_seconds=10)
        for name in (field.name for field in fields(self.observation)
                     if field.name.endswith('_age_at_receipt_seconds')):
            with self.subTest(field=name):
                observation = replace(self.observation, **{name: 4})
                self.assertTrue(self.evaluate(policy=policy, observation=observation, now=100.9).admitted)
                self.assert_rejected(self.evaluate(policy=policy, observation=observation,
                    now=101), 'sensor-stale')

    def test_fresh_receipt_cannot_rescue_stale_or_missing_sensor_age(self):
        for value, reason in ((5, 'sensor-stale'), (None, 'missing-data')):
            with self.subTest(value=value):
                observation = replace(self.observation, received_monotonic=101,
                    heading_age_at_receipt_seconds=value)
                self.assert_rejected(self.evaluate(observation=observation, now=101), reason)

    def test_component_skew_equality_rejects(self):
        observation = replace(self.observation, heading_age_at_receipt_seconds=.999)
        self.assertTrue(self.evaluate(observation=observation).admitted)
        self.assert_rejected(self.evaluate(observation=replace(observation,
            heading_age_at_receipt_seconds=1)), 'component-skew')

    def test_each_uncertainty_is_required_and_must_be_finite_nonnegative(self):
        names = (field.name for field in fields(self.observation) if '_uncertainty_' in field.name)
        for name in names:
            for value in (None, -1, True, '0', float('nan'), float('inf'), 10 ** 400):
                with self.subTest(field=name, kind=type(value).__name__):
                    reason = 'missing-data' if value is None else 'invalid-time'
                    self.assert_rejected(self.evaluate(observation=replace(self.observation,
                        **{name: value})), reason)

    def test_asymmetric_uncertainty_cannot_hide_component_skew(self):
        ages = {field.name: 1 for field in fields(self.observation)
                if field.name.endswith('_age_at_receipt_seconds')}
        observation = replace(self.observation, **ages,
            heading_age_uncertainty_seconds=.75, primary_gps_age_uncertainty_seconds=.25)
        self.assert_rejected(self.evaluate(observation=observation), 'component-skew')
        self.assertTrue(self.evaluate(observation=replace(observation,
            primary_gps_age_uncertainty_seconds=.24)).admitted)

    def test_freshness_includes_uncertain_upper_age_and_receipt_elapsed(self):
        policy = replace(self.policy, max_component_skew_seconds=10)
        observation = replace(self.observation, heading_age_at_receipt_seconds=4,
                              heading_age_uncertainty_seconds=.75)
        self.assertTrue(self.evaluate(policy=policy, observation=observation, now=100.249).admitted)
        self.assert_rejected(self.evaluate(policy=policy, observation=observation,
            now=100.25), 'sensor-stale')

    def test_age_interval_lower_end_is_clipped_to_physical_zero(self):
        observation = replace(self.observation, heading_age_uncertainty_seconds=.75)
        self.assertTrue(self.evaluate(observation=observation).admitted)

    def test_skew_compares_distinct_components_not_one_interval_with_itself(self):
        ages = {field.name: 2 for field in fields(self.observation)
                if field.name.endswith('_age_at_receipt_seconds')}
        observation = replace(self.observation, **ages, heading_age_uncertainty_seconds=.75)
        self.assertTrue(self.evaluate(observation=observation).admitted)

    def test_overflowing_uncertainty_interval_denies(self):
        observation = replace(self.observation, heading_age_at_receipt_seconds=1e308,
                              heading_age_uncertainty_seconds=1e308)
        self.assert_rejected(self.evaluate(observation=observation), 'invalid-time')

    def test_arithmetic_overflow_rejects(self):
        self.assert_rejected(self.evaluate(observation=replace(self.observation,
            received_monotonic=-1e308), now=1e308), 'invalid-time')
        policy = replace(self.policy, max_receipt_age_seconds=1e308,
                         max_sensor_age_seconds=1e308, max_component_skew_seconds=1e308)
        changes = {field.name: 1e308 for field in fields(self.observation)
                   if field.name.endswith('_age_at_receipt_seconds')}
        observation = replace(self.observation, received_monotonic=0, **changes)
        self.assert_rejected(self.evaluate(policy=policy, observation=observation,
            now=9e307), 'sensor-stale')

    def test_records_and_decision_are_immutable(self):
        for record, name, value in ((self.binding, 'pixhawk_id', 8),
                                     (self.policy, 'max_receipt_age_seconds', 99),
                                     (self.observation, 'generation', 10),
                                     (self.evaluate(), 'reasons', ('invalid-data',))):
            with self.subTest(record=type(record).__name__):
                with self.assertRaises(FrozenInstanceError):
                    setattr(record, name, value)

    def test_reasons_are_fixed_deterministic_and_do_not_echo_source_values(self):
        observation = replace(self.observation,
            binding=replace(self.binding, pixhawk_id=8, source_contract_id='private-source',
                calibration_id='private-calibration'), generation=8, heading_state='private-state')
        result = self.evaluate(observation=observation, now=102)
        self.assertEqual(result.reasons, ('identity-mismatch', 'source-mismatch',
            'calibration-mismatch', 'generation-mismatch', 'invalid-heading', 'receipt-stale'))
        self.assertEqual(result, self.evaluate(observation=observation, now=102))


if __name__ == '__main__':
    unittest.main()
