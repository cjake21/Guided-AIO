# Practice without hardware

Historical October 2026 tutorial. Use the maintained
[handbook walkthroughs](../components/ground_station/docs/operator-tutorial.md)
for the current release. The commands below preserve earlier behavior and are
not today's installation or acceptance procedure.

Use the separately installed candidate, not the passing Pi application. These
steps use a new synthetic station directory and the bundled historical NOAA 15
data. They never open a device or start managers/services. Run each command from
a writable practice directory outside the source checkout.

Start with `satgs-operator --help`, then:

```sh
satgs-operator --workspace ./practice-station init
satgs-operator --workspace ./practice-station status
satgs-operator-gui --workspace ./practice-station
```

In the native window:

1. Home shows an unconfigured station and independent unknown/unqualified
   evidence dimensions. Nothing is connected merely by opening the window.
2. In Setup select Guided Arrow, preview, review its real constraints, then
   confirm and save. Alternatively preview Full M-SEL, switch to Custom and
   inspect the retained displayed choices. Without explicit hardware instances,
   that conversion is an unapplied draft, not an automatically valid selection.
   Its missing-identity message and disabled confirmation are expected. Return
   to Guided Arrow for this practice run.
3. In Location enter latitude 42, longitude -71 and altitude 12.5. Choose
   `unspecified` for altitude reference. These are synthetic practice values,
   not measurements. Preview the previous/proposed values, then cancel. Reload
   demonstrates that the saved location did not change.
4. Preview those values again and confirm. Reload shows manual source and the
   new revision. GPS selection remains disabled with its unmet requirements.
5. Calculate the default local plan. It uses the saved location and actual orbit
   calculations, while retaining historical-TLE, altitude and owner limits.
6. Change longitude to -70, confirm and calculate again. Inspect the new plan
   and the old plan's revalidation requirement.
7. In a terminal run `satgs-operator --workspace ./practice-station replay --state critical`,
   then Reload in Home. Inspect transport pass alongside critical health and
   unqualified heading. Replay selection is CLI-only; both interfaces display
   the same saved observation. It does not turn the station ready.
8. Export the Results report to a new file outside the checkout. Exporting again
   to that same filename must fail without overwriting the first report.

The CLI performs the same operation. A preview returns `result.preview_id`.
Use the returned identity with `apply --preview ID --confirm`, or `cancel
--preview ID`; `ID` is an argument description, not a runnable fixed identity.
The following shell sequence obtains the real identity from the current preview:

```sh
operator_preview=$(satgs-operator --workspace ./practice-station --format json location-preview --latitude-deg 42 --longitude-deg -71 --altitude-m 12.5 --altitude-reference unspecified)
operator_preview_id=$(printf '%s' "$operator_preview" | python3 -c 'import json,sys; print(json.load(sys.stdin)["result"]["preview_id"])')
satgs-operator --workspace ./practice-station apply --preview "$operator_preview_id" --confirm
satgs-operator --workspace ./practice-station reload
satgs-operator --workspace ./practice-station plan
satgs-operator --workspace ./practice-station replay --state critical
satgs-operator --workspace ./practice-station report
satgs-operator --workspace ./practice-station export --output ./practice-report.json
```

Do not continue the apply line if preview or JSON extraction fails. Invalid
`--latitude-deg nan` must return 2 without changing the station. Applying without
`--confirm` must return 2. A preview made before another saved change must return
3 on apply. No force option exists. The consolidated tests exercise concurrent
and real runner-held lease conflicts without opening hardware.

Close the window normally when finished. Keep the workspace and report as local
practice data or remove them deliberately later. They do not belong in Git and
are not operational station configuration or an installed telemetry result.
