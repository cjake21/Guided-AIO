# Operator application

Historical October 2026 source-candidate guide. Use the current canonical
[operator handbook](../components/ground_station/docs/operator-guide.md).
The retained procedures below are not the current release installation or PTU
feature reference. They are preserved for source/history comparison.

This development candidate adds a native Tkinter/ttk application and a headless
CLI to ground_station. They share one managed-workspace operation. The browser
dashboard is separate and is not started or replaced by this application.

The supported slice is local configuration, explicit manual station selection,
historical/local pass calculation and report export. It does not install or
activate owners, start managers or services, or control hardware. Opening a
window does not connect to a broker, database, Box or Cube.

## Source and installed entry points

The six component directories retain their ownership. New source is in
`components/ground_station/src/satgs/operator_core.py`, `operator_activity.py`,
`operator_cli.py`, `operator_gui.py` and `operator_planning.py`. The existing
station-location operation and canonical deployment planner are reused.
PassRunner participates in the managed-workspace activity lease; it is not
duplicated by the interface.

Installed commands are `satgs-operator` and `satgs-operator-gui`. The optional
`gui` extra adds no Python distribution: Tk must be provided by the selected
Python installation. Tk is imported only when opening a native window. The CLI
works without Tk or DISPLAY. Local pass calculation loads ephem and the existing
scientific utilities when a plan is requested. Those scientific packages remain
selected runtime dependencies. Build/compiler tooling is not an application
dependency.

Use a separate candidate environment. Never upgrade the accepted Pi environment
in place, copy an x86-64 environment to the Pi, or change the diagnostic venv.
The candidate installation and consolidated-check instructions accompany the
versioned artifact. A missing optional Tk/display is reported explicitly, not
as a successful GUI check.

## Commands

Global options precede the command:

`satgs-operator --workspace ./practice-station --format json status`

The workspace defaults to `./satgs-workspace`. Human output is indented JSON;
`--format json` produces compact machine-readable JSON. Arguments are not
abbreviated. There are no credentials, operational endpoints or device defaults
in a newly created scratch station.

| Command | Inputs and effect | Native action |
| --- | --- | --- |
| `init` | Creates a NEW private workspace; `--case pelican-qpt130` is the only supported case | Create scratch station |
| `status`, `reload` | Read saved station, revision, available evidence and stale-plan indicators | Home / Reload |
| `catalog` | Read canonical component/profile constraints | Setup |
| `components-preview` | Required `--profile guided_arrow`, `full_msel` or `custom`; optional `--changes FILE` JSON and `--expected-revision SHA256`; `--ptu-model` defaults to QPT130 | Setup / Preview |
| `location-preview` | Required `--latitude-deg`, `--longitude-deg`, `--altitude-m`, `--altitude-reference`; optional `--expected-revision SHA256`; creates a revision-bound preview, not a saved change | Location / Preview |
| `apply` | Required `--preview ID --confirm`; saves exactly that reviewed preview | Review / Confirm and save |
| `cancel` | Required `--preview ID`; cancels an unapplied current preview without changing station settings | Review / Cancel |
| `plan` | Defaults: `--start 2025-05-16T03:00:00Z --norad-id 25338 --span-days 1 --elevation-deg 20`; optional `--tle-file LOCAL_CSV`; creates a planning-only result | Results / Calculate local plan |
| `replay` | Required `--state` from the named synthetic scenarios below; saves only display/replay metadata | CLI-only scenario selection; Home Reload displays it |
| `report` | Read the redacted operation report | Results |
| `export` | Required `--output NEW_FILE`; writes one exclusive private JSON report; never overwrites an existing file | Results / Export |

Latitude is in [-90, 90] degrees; longitude is in [-180, 180] degrees. Nonfinite
and boolean numeric inputs are rejected. Altitude is metres and must satisfy
the shared station validator. References are `unspecified` or an explicitly
operator-declared `mean_sea_level`. Neither choice establishes a survey, measured
offset or datum conversion. GPS-derived coordinates are displayed separately,
never silently selected as manual or effective station coordinates.

Custom JSON accepts the canonical selection document or a component-to-change
mapping. It is subject to the same canonical validator as GUI controls. Full
M-SEL and Guided Arrow retain their real planning constraints. A planned
component is not evidence that it is installed or operational. This Pelican case
rejects a non-QPT130 model, including Custom. Other supported models remain in
the wider product's existing contracts.

Custom local hardware needs explicit stable instance identities. The GUI retains
declared instances while editing modes and providers; it does not invent new
ones. Full M-SEL's local hardware has no such declared identities, so changing
that preview to Custom correctly produces an unapplied draft with the missing
requirements and confirmation disabled. The displayed intent is preserved.
An explicit operator omission can produce a valid selection, still subject to
planning diagnostics. Use the CLI's complete canonical JSON input for new
instance definitions, or start from Guided Arrow's existing declared instances.

## Save, conflicts and planning

Previews show previous/proposed data and affected plans. Confirm is required.
Applying the same completed preview returns its immutable receipt without
incrementing the station generation again. Repeating cancel is idempotent.
A cancelled preview cannot apply; preview the desired values again. A stale
revision or active managed runner returns conflict rather than a force bypass.

The station document is saved atomically under a cooperative activity lease.
Receipt or final durability failure can still produce a partial result after a
real save. Such a result is FAIL/exit 4 with the actual saved state retained.
Reload before recovery. If the saved operation is still current, repeating apply
can recover its receipt without applying the coordinates twice. Once a later
change supersedes it, do not claim that cancelling the older partial operation
reverted its save. Ordinary cancellation is not rollback.

Plans bind the station revision, explicit location/reference, TLE identity and
calculation inputs. A later station change marks old plans as requiring
revalidation. A fresh plan reloads the saved station before real orbit
calculation. The bundled NOAA 15 example is historical replay data, not current
orbit freshness. A local CSV is read without refresh or modification and must
pass the existing selected-NORAD, line and checksum checks. The supported span
is one hour through seven days; at most 256 opportunities are retained.

Manual selection remains planning-only. The downstream PTU owner snapshots its
own location and does not yet bind it to the selected station revision.
PassRunner therefore still rejects a manual source before operational owner
acquisition. A plan or restart is not a successful owner reinitialization.

## Evidence and errors

The interface keeps configuration, installation, connection, message receipt,
fix, freshness, system health, calibration, heading and operation result separate.
Installed metadata is identified as metadata, not an installed-byte check.

Synthetic states are `unknown`, `disconnected`, `silent`, `no_fix`, `reported_3d`,
`stale`, `mismatched`, `incomplete` and `critical`. Every replay is explicitly
labelled synthetic. A transport pass can coexist with critical health and
unqualified heading. Incomplete messages and final unpublished aggregates remain
known limitations; the UI does not manufacture a final observation.

GPS selection is unavailable until source binding, validity, timing/freshness
and coordinate/altitude reference are established. No-fix is not automatically
a transport failure. A matching-ID message is not navigation or physical health.

| Exit | Meaning |
| --- | --- |
| 0 | Selected local operation completed, not operational readiness |
| 2 | Invalid input or unsupported arguments |
| 3 | Conflict, apply of a cancelled preview, active work, stale revision, or unavailable selected workspace/dependency/display |
| 4 | I/O, calculation, partial or unexpected local operation failure |
| 130 | Local CLI interruption |

The native interface shows the same failure/result document. Tab navigation,
focused actions and Escape cancellation are supported. It does not offer a
hardware stop button or describe client cancellation as a physical stop.
Cancelling an unapplied current preview is a successful local operation, exit 0.

Configuration and reports belong outside the checkout, with private permissions.
Do not commit workspace data, credentials, logs, captures, environments or review
evidence. Product source, examples, validation support and binary artifacts have
separate locations and identities.

The intended integration topology uses one explicitly allocated isolated test
broker for every test controller, manager, client and dashboard backend, with no
production fallback, bridge or discovery. Database and remote storage require
assigned test resources and credentials. Those services, live GPS selection,
owner reinitialization, navigation/heading qualification and physical
commissioning are not implemented by this operator slice.
