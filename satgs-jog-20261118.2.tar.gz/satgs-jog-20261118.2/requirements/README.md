# Selected dependency inputs

Current release inputs are `client.in`, `manager.in` and
`runtime-constraints.txt`. They pair satgs/PTU/serialptu at
`0.0.1+ptu.20261117.1`. They are portable version selections, not platform
artifact locks. Build all six local owners using the exact `build.lock` tools;
see [BUILDING.md](../BUILDING.md) and [release.json](../release.json).

The `development-*` locks/artifact metadata and `operator-artifact.json` below
are retained historical delivery records. They name older owner versions and
hashes and must not install the current PTU release. Current builds emit fresh
filename/hash metadata. The Pi updater reuses the existing r3 platform closure
while replacing the three reviewed pure wheels, not these historical locks.

## Historical development records

These relative name/version inputs are portable specifications, not a target artifact lock. `development-artifacts.json` describes genuine artifacts already used on Linux x86-64 with CPython 3.11.16; it does not qualify them for ARM64 or authorize downloads. No absolute workstation path or internal repository is a dependency URL in these files.

Build each of the six supplied component directories with the pinned tools in build.txt, using a separate build environment and the included generated Python modules. The exact five build-tool hashes are in build.lock; bootstrap.lock pins the separately verified pip26.2 installer. build-artifacts.json records all six artifact filenames, sizes and hashes without workstation paths. These files do not contain or acquire the artifacts. Resolve the complete intended local wheel set together, including both sides of the ground_station/PTU cycle. Local amended packages must come from this delivery's builds, even when unrelated distributions share their version numbers. A version constraint by itself does not establish this identity.

The client selects satgs[pointing]. The manager selection adds PTU/Pixhawk manager extras. Keep pip and build/compiler tooling outside application environments that do not need them. The four unchanged protobuf inputs were generated with protoc 33.6 for protobuf 6.33.6; runtime generation is unnecessary.

All six local wheels were built from the frozen delivery source. development-local-artifacts.json identifies those exact artifacts; development-client.lock and development-manager.lock contain the complete 26/31 development selections with hashes and selected extras. They were verified against the actual fresh installations. A later rebuild may produce different ZIP bytes and requires new artifact verification before replacing a hash. Artifact binaries are not included.

The guarded local build/install and application results are summarized in ../DELIVERY.md. Target installation needs a separately reviewed artifact closure with exact filenames, hashes, notices and target ABI compatibility. Do not use the development locks as ARM64 locks or copy a development environment to the Pi.
