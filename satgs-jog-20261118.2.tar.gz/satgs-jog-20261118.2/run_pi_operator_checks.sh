#!/bin/sh
set -eu
SATGS_GUIDE_CHECK_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
if [ "$#" -ne 1 ] || [ "$1" != '--accept-trusted-native' ]; then
    printf '%s\n' 'Usage: ./run_pi_operator_checks.sh --accept-trusted-native' >&2
    exit 2
fi
exec /usr/bin/python3.11 -I -B -S "$SATGS_GUIDE_CHECK_DIR/support/run_pi_operator_checks.py" \
    --accept-trusted-native
