"""Inspect or stage an explicit offline SATGS release without changing station data."""

import argparse
import hashlib
import json
from pathlib import Path
import sys
import types


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SCHEMA = 'satgs-offline-release.v1'
CHAPTERS = ('operator-guide', 'configurations', 'component-handbook', 'installation',
            'daily-operation', 'station-location', 'ptu-operation', 'operator-tutorial',
            'results', 'legacy-comparison', 'updates-troubleshooting',
            'operator-cli-reference', 'maintainer-reference')


def module(path, name):
    value = types.ModuleType(name)
    value.__file__ = str(path)
    sys.modules[name] = value
    exec(compile(path.read_bytes(), str(path), 'exec', dont_inherit=True), vars(value))
    return value


def daily_module():
    return module(ROOT / 'launchers/daily.py', '_satgs_release_daily')


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Release JSON contains a duplicate field.')
        result[key] = value
    return result


def release_manifest(path=None):
    daily = daily_module()
    value = json.loads(daily.regular_bytes(path or ROOT / 'release.json', mode=0o644),
                       object_pairs_hook=unique_object)
    fields = {'schema', 'release', 'selection', 'application_version', 'source_date_epoch',
              'packages', 'replacement_wheels', 'paths', 'dependency_base', 'workspace',
              'activity_source_sha256'}
    if not isinstance(value, dict) or set(value) != fields or value['schema'] != SCHEMA:
        raise ValueError('Unsupported release manifest shape or schema.')
    version = daily.VERSIONS['jog']
    packages = {'satgs': version, 'ptu-control': version,
                'serialptu': version, 'pixhawk': '0.0.1',
                'meteor-api': '2.2.0+bench.20261117.1', 'stomp-py': '8.1.0+bench.20261117.1'}
    replacements = {name: 'wheels/' + name.replace('-', '_') + '-' + packages[name]
                    + '-py3-none-any.whl' for name in ('satgs', 'ptu-control', 'serialptu', 'meteor-api', 'stomp-py')}
    expected_base = dict(source_commit='7e7ffdf26e4f5dabcf1574738e6c55af168132fb',
                         client_distributions=26, manager_distributions=31)
    if (value['release'] != 'jog-20261118.1' or value['selection'] != 'jog'
            or value['application_version'] != version or value['packages'] != packages
            or value['replacement_wheels'] != replacements or value['dependency_base'] != expected_base
            or value['workspace'] != dict(marker='satgs_operator_workspace', schema_version=1, migrations=[])
            or type(value['source_date_epoch']) is not int or value['source_date_epoch'] != 1794873600
            or value['activity_source_sha256'] != daily.ACTIVITY_SOURCE_SHA256):
        raise ValueError('Release identities, dependency base or workspace compatibility differ.')
    paths = value['paths']
    if not isinstance(paths, dict) or set(paths) != {
            'application', 'installer', 'setup_output', 'acceptance_output', 'previous_bundle'}:
        raise ValueError('Release paths are incomplete.')
    for path in paths.values():
        if not isinstance(path, str) or not Path(path).is_absolute() or '..' in Path(path).parts:
            raise ValueError('Release paths must be absolute without traversal.')
    if len(set(paths.values())) != len(paths):
        raise ValueError('Release application, dependency and evidence paths must be distinct.')
    if paths['application'] != daily.DEFAULT_IDENTITIES['jog']['application']:
        raise ValueError('Release application differs from its reviewed daily identity.')
    return value


def status(path=None, *, home=None):
    release = release_manifest(path)
    daily = daily_module()
    selection = daily._paths(home or Path.home())['selection']
    try:
        current = daily._selection(selection, daily.registered())
    except FileNotFoundError:
        current = None
    wheels = {}
    for name, relative in release['replacement_wheels'].items():
        path = ROOT / relative
        try:
            raw = daily.regular_bytes(path, 512 * 1024 * 1024, mode=0o644)
        except FileNotFoundError:
            wheels[name] = dict(path=relative, status='MISSING')
        else:
            wheels[name] = dict(path=relative, status='AVAILABLE', bytes=len(raw),
                                sha256=hashlib.sha256(raw).hexdigest())
    return dict(release=release, current_selection=current, replacement_wheels=wheels,
                activation='Explicit idle-only selection after acceptance; staging never selects.',
                network_requested=False)


def stage(args):
    if not args.accept_trusted_native:
        raise ValueError('Use --accept-trusted-native for the documented runtime trust boundary.')
    release = release_manifest()
    print('Staging release ' + release['release'] + '; existing daily selection is retained.', flush=True)
    setup = module(HERE / 'setup_operator_update.py', '_satgs_release_setup')
    arguments = []
    for option in ('previous_bundle', 'application', 'installer', 'output_root'):
        value = getattr(args, option, None)
        if value is not None:
            arguments.extend(('--' + option.replace('_', '-'), str(value)))
    return setup.main(arguments)


def main(argv=None):
    if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise ValueError('Use isolated Python: -I -B -S.')
    parser = argparse.ArgumentParser(allow_abbrev=False, description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('status', allow_abbrev=False)
    staging = commands.add_parser('stage', allow_abbrev=False)
    staging.add_argument('--accept-trusted-native', action='store_true')
    for option in ('previous-bundle', 'application', 'installer', 'output-root'):
        staging.add_argument('--' + option, type=Path)
    commands.add_parser('select', allow_abbrev=False)
    rollback = commands.add_parser('rollback', allow_abbrev=False)
    rollback.add_argument('--target', choices=('bench', 'ptu', 'handbook', 'guide', 'ui', 'runtime'), default='ptu')
    args = parser.parse_args(argv)
    release = release_manifest()
    if args.command == 'stage':
        return stage(args)
    if args.command == 'status':
        result = status()
    else:
        daily = daily_module()
        target = release['selection'] if args.command == 'select' else args.target
        result = daily.select(Path.home(), target)
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError) as error:
        print('SATGS update: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
